<?php
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();

if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';

$conn = db_connect();
if ($conn->connect_error) {
    error_log('menu.php DB connect error: ' . $conn->connect_error);
    http_response_code(500);
    exit('Ошибка подключения к базе данных.');
}
$conn->set_charset('utf8mb4');

$user_id = (int)$_SESSION['user_id'];
$stmt = $conn->prepare('SELECT id, username, avatar, status, is_admin FROM users WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
$stmt->close();

if (!$current_user_data) {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php?account_missing=1');
    exit;
}

$is_admin = !empty($current_user_data['is_admin']);
$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';
if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    setcookie('theme', $_GET['theme'], [
        'expires' => time() + 365 * 24 * 60 * 60,
        'path' => '/',
        'samesite' => 'Lax',
    ]);
    header('Location: menu.php');
    exit;
}

$notifications = [];
$notif_count = 0;
$unread_count = 0;
$pending_reports_count = 0;
try {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar AS sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS count
        FROM notifications
        WHERE user_id = ? AND is_read = 0
          AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $unread_count = shell_unread_messages($conn, $user_id);
    if ($is_admin) {
        $result = $conn->query("SELECT COUNT(*) AS count FROM reports WHERE status = 'pending'");
        if ($result) {
            $pending_reports_count = (int)($result->fetch_assoc()['count'] ?? 0);
        }
    }
} catch (Throwable $e) {
    error_log('menu.php shell data error: ' . $e->getMessage());
}

// Встроенные SVG-иконки: не зависят от файлов, регистра имён и шрифтов устройства
$inline_icons = [
    'bell'     => '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"></path>',
    'code'     => '<path d="m8 7-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"></path>',
    'shield'   => '<path d="M12 3 4 6v6c0 4.5 3.4 8.2 8 9 4.6-.8 8-4.5 8-9V6l-8-3Z"></path><path d="m9 12 2 2 4-4"></path>',
    'settings' => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle>',
];
function menu_inline_icon(array $icons, string $key): string {
    return '<svg viewBox="0 0 24 24" aria-hidden="true">' . ($icons[$key] ?? '') . '</svg>';
}

$menu_items = [
    ['news.php', 'news.svg', ui_t('nav_news')],
    ['messages.php', 'nav-messages.svg', ui_t('nav_messages')],
    ['friends.php', 'nav-friends.svg', ui_t('nav_friends')],
    ['spaces.php', 'nav-spaces.svg', ui_t('nav_spaces')],
    ['photos.php', 'nav-photo.svg', ui_t('nav_photos')],
    ['music.php', 'nav-music.svg', ui_t('nav_music')],
    ['video.php', 'nav-video.svg', ui_t('nav_video')],
    ['favorite.php', 'nav-favorite.svg', ui_t('nav_favorites')],
    ['notifications.php', 'inline:bell', ui_t('notifications')],
    ['support.php', 'nav-support.svg', ui_t('nav_support')],
    ['about.php', 'nav-about.svg', ui_t('nav_about')],
    ['developers.php', 'inline:code', ui_t('nav_developers')],
];
?>
<!DOCTYPE html>
<html lang="<?= ui_lang() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ui_e('Меню') ?></title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/menu.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/menu.css') ?>">
    <?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>">
    <?php include __DIR__ . '/includes/site_header.php'; ?>
    <div class="layout">
        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>
        <main class="menu-page">
            <header class="menu-page-heading">
                <h1><?= ui_e('Меню') ?></h1>
                <p><?= ui_e('Быстрый переход ко всем разделам') ?></p>
            </header>
            <?php
            $menu_username = (string)($current_user_data['username'] ?? ui_t('user_default'));
            $menu_avatar = (string)($current_user_data['avatar'] ?? '');
            ?>
            <a class="menu-profile-card" href="<?= $user_id ?>">
                <span class="menu-profile-avatar">
                    <?php if ($menu_avatar !== '' && file_exists($menu_avatar)): ?>
                        <img src="<?= htmlspecialchars($menu_avatar, ENT_QUOTES, 'UTF-8') ?>" alt="">
                    <?php else: ?>
                        <?= htmlspecialchars(mb_strtoupper(mb_substr($menu_username, 0, 1, 'UTF-8'), 'UTF-8'), ENT_QUOTES, 'UTF-8') ?>
                    <?php endif; ?>
                </span>
                <span class="menu-profile-info">
                    <span class="menu-profile-label"><?= ui_e('my_profile') ?></span>
                    <span class="menu-profile-name"><?= htmlspecialchars($menu_username, ENT_QUOTES, 'UTF-8') ?></span>
                </span>
                <span class="menu-profile-arrow" aria-hidden="true">→</span>
            </a>
            <nav class="menu-page-grid" aria-label="<?= ui_e('Разделы сайта') ?>">
                <?php foreach ($menu_items as [$href, $icon, $label]): ?>
                    <a class="menu-page-card" href="<?= htmlspecialchars($href, ENT_QUOTES, 'UTF-8') ?>">
                        <span class="menu-page-icon">
                            <?php if (strpos($icon, 'inline:') === 0): ?>
                                <?= menu_inline_icon($inline_icons, substr($icon, 7)) ?>
                            <?php else: ?>
                                <img src="images/<?= htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') ?>" alt="">
                            <?php endif; ?>
                        </span>
                        <span><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></span>
                        <?php if ($href === 'messages.php' && $unread_count > 0): ?>
                            <span class="menu-page-badge"><?= $unread_count > 99 ? '99+' : $unread_count ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
                <a class="menu-page-card" href="settings.php">
                    <span class="menu-page-icon"><?= menu_inline_icon($inline_icons, 'settings') ?></span>
                    <span><?= ui_e('settings') ?></span>
                </a>
                <?php if ($is_admin): ?>
                    <a class="menu-page-card" href="reports.php">
                        <span class="menu-page-icon"><?= menu_inline_icon($inline_icons, 'shield') ?></span>
                        <span><?= ui_e('moderation') ?></span>
                        <?php if ($pending_reports_count > 0): ?>
                            <span class="menu-page-badge"><?= $pending_reports_count > 99 ? '99+' : $pending_reports_count ?></span>
                        <?php endif; ?>
                    </a>
                <?php endif; ?>
            </nav>
        </main>
    </div>
    <?php include __DIR__ . '/includes/footer.php'; ?>
</body>
</html>

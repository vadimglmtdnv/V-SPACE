<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
if (is_file(__DIR__ . '/includes/error_logger.php')) { require_once __DIR__ . '/includes/error_logger.php'; }
require_once __DIR__ . '/account_state.php';
require_once __DIR__ . '/maintenance.php';
require_once __DIR__ . '/includes/session_guard.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $user_id = isset($_SESSION["user_id"]) ? (int)$_SESSION["user_id"] : 0;
    
    if ($user_id > 0 && ($_POST['confirm'] ?? '') === 'yes'
        && hash_equals((string)$_SESSION['csrf_token'], (string)($_POST['csrf_token'] ?? ''))) {
        $conn = db_connect();
        if (!$conn->connect_error) {
            $conn->set_charset("utf8mb4");
            require_once __DIR__ . '/account_state.php';
            ensureAccountStateColumns($conn);

            $stmt = $conn->prepare("
                UPDATE users
                SET avatar = NULL,
                    status = 'offline', deleted_at = NOW(),
                    remember_token = NULL, token_expires = NULL
                WHERE id = ?
            ");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->close();
            
            // Удаляем историю IP, если таблица уже существует.
            $history_table = $conn->query("SHOW TABLES LIKE 'user_ip_history'");
            if ($history_table && $history_table->num_rows > 0) {
                $stmt = $conn->prepare("DELETE FROM user_ip_history WHERE user_id = ?");
                if ($stmt) {
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $stmt->close();
                }
            }
            
            $conn->close();
        }
        
        $_SESSION = array();
        session_destroy();
        header("Location: login.php?deleted=1");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'deactivate') {
    $user_id = isset($_SESSION["user_id"]) ? (int)$_SESSION["user_id"] : 0;

    if ($user_id > 0 && ($_POST['confirm'] ?? '') === 'yes'
        && hash_equals((string)$_SESSION['csrf_token'], (string)($_POST['csrf_token'] ?? ''))) {
        $conn = db_connect();
        if (!$conn->connect_error) {
            $conn->set_charset("utf8mb4");

            // Колонка могла ещё не существовать, если пользователь ни разу не заходил
            // через обновлённый login.php — создаём её и здесь на всякий случай.
            $daCol = $conn->query("SHOW COLUMNS FROM users LIKE 'deactivated_at'");
            if ($daCol && $daCol->num_rows === 0) {
                $conn->query("ALTER TABLE users ADD COLUMN deactivated_at DATETIME NULL DEFAULT NULL");
            }

            // В отличие от «Удалить профиль» это не мягкое удаление: данные, сообщения
            // и профиль остаются как есть, просто аккаунт помечается неактивным и человек
            // выходит из системы. Любой следующий успешный вход по паролю (см. login.php)
            // сам снимает деактивацию — отдельного экрана «восстановления» не требуется.
            $stmt = $conn->prepare("
                UPDATE users
                SET status = 'offline', deactivated_at = NOW(),
                    remember_token = NULL, token_expires = NULL
                WHERE id = ?
            ");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->close();

            $conn->close();
        }

        $_SESSION = array();
        session_destroy();
        header("Location: login.php?deactivated=1");
        exit;
    }
}

// Пометить уведомления прочитанными — тот же контракт, что и в help.php:
// обычный POST (в том числе через fetch из шапки), без отдельного API.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_notifications_read') {
    $user_id = isset($_SESSION["user_id"]) ? (int)$_SESSION["user_id"] : 0;
    if ($user_id > 0) {
        $conn = db_connect();
        if (!$conn->connect_error) {
            $conn->set_charset("utf8mb4");
            $notifTable = $conn->query("SHOW TABLES LIKE 'notifications'");
            if ($notifTable && $notifTable->num_rows > 0) {
                $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
                $stmt->bind_param('i', $user_id);
                $stmt->execute();
                $stmt->close();
            }
            $conn->close();
        }
    }
    // Если запрос пришёл через fetch() из JS в шапке — просто подтверждаем,
    // без редиректа (сама шапка уже обновляется на клиенте).
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || stripos($_SERVER['CONTENT_TYPE'] ?? '', 'x-www-form-urlencoded') !== false) {
        header('Content-Type: text/plain; charset=utf-8');
        echo 'ok';
        exit;
    }
    header('Location: settings.php');
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'restore') {
    $user_id = isset($_SESSION["user_id"]) ? (int)$_SESSION["user_id"] : 0;
    if ($user_id > 0) {
        $conn = db_connect();
        if (!$conn->connect_error) {
            $conn->set_charset("utf8mb4");
            require_once __DIR__ . '/account_state.php';
            ensureAccountStateColumns($conn);
            $stmt = $conn->prepare("
                UPDATE users
                SET deleted_at = NULL, status = 'offline'
                WHERE id = ? AND deleted_at IS NOT NULL AND is_blocked = 0
            ");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->close();
            $conn->close();
        }
        unset($_SESSION['deleted_account_pending']);
        header("Location: index.php?account_restored=1");
        exit;
    }
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
ensureTwoFactorColumns($conn);

$user_id = (int)$_SESSION["user_id"];
enforceSessionVersion($conn, $user_id);   // сеанс отозван кнопкой «Выйти со всех устройств»?

// Получаем данные пользователя
$stmt = $conn->prepare("
    SELECT username, email, avatar, status, is_admin, ip_address, totp_secret, totp_enabled
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$unread_count = 0;
$unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

$username = $user["username"] ?? "";
$email = $user["email"] ?? "";
$avatar = $user["avatar"] ?? "";
$status = $user["status"] ?? "offline";
// Основатель сайта — жёстко закреплённый id=1. У него доступ уровня админа
// всегда есть, даже если флаг is_admin в БД по какой-то причине снят.
$is_founder = $user_id === 1;
$is_admin = (isset($user['is_admin']) && $user['is_admin'] == 1) || $is_founder;
$ip_address = $user["ip_address"] ?? "";
$totp_enabled = !empty($user['totp_enabled']);
$totp_secret_stored = $user['totp_secret'] ?? null;

// ============================================================
// РЕАЛЬНЫЙ IP-АДРЕС КЛИЕНТА
// ::1 и 127.0.0.1 — это "localhost" (сервер видит сам себя). Так бывает, когда
// сайт открыт локально (XAMPP/OpenServer/php -S) или стоит за прокси (nginx,
// Cloudflare), который сам подключается к PHP с loopback-адреса.
//
// Заголовки X-Forwarded-For / X-Real-IP может подделать любой клиент, поэтому
// им доверяем ТОЛЬКО если запрос пришёл с локального/приватного адреса или из
// списка $trusted_proxies (например, IP-адреса вашего прокси/балансировщика).
// ============================================================

// Приводит IP к единому виду: убирает порт, [ ] и ::ffff:, ::1 -> 127.0.0.1
function normalizeIpAddress(?string $ip): string {
    $ip = trim((string)$ip);
    if ($ip === '') {
        return '';
    }
    if (preg_match('/^\[([0-9a-f:.]+)\](?::\d+)?$/i', $ip, $m)) {
        $ip = $m[1];
    } elseif (preg_match('/^(\d{1,3}(?:\.\d{1,3}){3}):\d+$/', $ip, $m)) {
        $ip = $m[1];
    }
    $bin = @inet_pton($ip);
    if ($bin === false) {
        return '';
    }
    // IPv4, завёрнутый в IPv6 (::ffff:192.168.0.5)
    if (strlen($bin) === 16 && substr($bin, 0, 12) === "\0\0\0\0\0\0\0\0\0\0\xff\xff") {
        $bin = substr($bin, 12);
    }
    $ip = inet_ntop($bin);
    return $ip === '::1' ? '127.0.0.1' : (string)$ip;
}

function isPublicIpAddress(string $ip): bool {
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}

function getClientIpAddress(): string {
    // IP ваших прокси/балансировщиков, которым можно верить (если есть)
    $trusted_proxies = [
        // '203.0.113.10',
    ];

    $remote = normalizeIpAddress($_SERVER['REMOTE_ADDR'] ?? '');

    // Прямое подключение с публичного IP — это и есть адрес клиента
    if ($remote !== '' && isPublicIpAddress($remote) && !in_array($remote, $trusted_proxies, true)) {
        return $remote;
    }

    // Запрос пришёл через прокси / локально — читаем заголовки
    $headers = [
        'HTTP_CF_CONNECTING_IP',     // Cloudflare
        'HTTP_TRUE_CLIENT_IP',
        'HTTP_X_REAL_IP',            // nginx
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_CLIENT_IP',
    ];
    $fallback = '';
    foreach ($headers as $header) {
        if (empty($_SERVER[$header])) {
            continue;
        }
        foreach (explode(',', (string)$_SERVER[$header]) as $candidate) {
            $candidate = normalizeIpAddress($candidate);
            if ($candidate === '') {
                continue;
            }
            if (isPublicIpAddress($candidate)) {
                return $candidate;
            }
            if ($fallback === '') {
                $fallback = $candidate;
            }
        }
    }

    return $fallback !== '' ? $fallback : $remote;
}

function detectBrowserLabel(?string $userAgent): string {
    $ua = (string)$userAgent;
    if ($ua === '') {
        return '—';
    }

    if (preg_match('/Edg\//i', $ua)) {
        $browser = 'Edge';
    } elseif (preg_match('/OPR\//i', $ua) || stripos($ua, 'Opera') !== false) {
        $browser = 'Opera';
    } elseif (preg_match('/YaBrowser/i', $ua)) {
        $browser = 'Яндекс.Браузер';
    } elseif (preg_match('/Firefox\//i', $ua)) {
        $browser = 'Firefox';
    } elseif (preg_match('/Chrome\//i', $ua) && stripos($ua, 'Chromium') === false) {
        $browser = 'Chrome';
    } elseif (preg_match('/Safari\//i', $ua) && stripos($ua, 'Chrome') === false) {
        $browser = 'Safari';
    } else {
        $browser = 'Другой браузер';
    }

    if (stripos($ua, 'Windows') !== false) {
        $os = 'Windows';
    } elseif (stripos($ua, 'Mac OS') !== false || stripos($ua, 'Macintosh') !== false) {
        $os = 'macOS';
    } elseif (stripos($ua, 'Android') !== false) {
        $os = 'Android';
    } elseif (stripos($ua, 'iPhone') !== false || stripos($ua, 'iPad') !== false || stripos($ua, 'iOS') !== false) {
        $os = 'iOS';
    } elseif (stripos($ua, 'Linux') !== false) {
        $os = 'Linux';
    } else {
        $os = '';
    }

    return $os !== '' ? "$browser · $os" : $browser;
}

function requireSettingsCsrf(): void {
    if (!hash_equals((string)($_SESSION['csrf_token'] ?? ''), (string)($_POST['csrf_token'] ?? ''))) {
        http_response_code(419);
        exit('Invalid request token');
    }
}

// ============================================================
// 2FA: колонки/таблица
// ============================================================
function ensureTwoFactorColumns(mysqli $conn): void {
    $checks = [
        'totp_secret'  => "ALTER TABLE users ADD COLUMN totp_secret VARCHAR(64) NULL DEFAULT NULL",
        'totp_enabled' => "ALTER TABLE users ADD COLUMN totp_enabled TINYINT(1) NOT NULL DEFAULT 0",
    ];
    foreach ($checks as $col => $sql) {
        $check = $conn->query("SHOW COLUMNS FROM users LIKE '" . $conn->real_escape_string($col) . "'");
        if ($check && $check->num_rows === 0) {
            if (!$conn->query($sql)) {
                error_log("ALTER TABLE failed for users.$col: " . $conn->error);
            }
        }
    }
    $conn->query("
        CREATE TABLE IF NOT EXISTS user_backup_codes (
            id INT NOT NULL AUTO_INCREMENT,
            user_id INT NOT NULL,
            code_hash VARCHAR(255) NOT NULL,
            used_at DATETIME NULL DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

// ============================================================
// 2FA: TOTP по RFC 6238 (Google Authenticator / Authy и т.п.), реализовано
// без внешних библиотек — только встроенные функции PHP.
// ============================================================
function base32Encode(string $data): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    if ($data === '') return '';
    $bits = '';
    foreach (str_split($data) as $char) {
        $bits .= str_pad(decbin(ord($char)), 8, '0', STR_PAD_LEFT);
    }
    $output = '';
    foreach (str_split($bits, 5) as $chunk) {
        $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
        $output .= $alphabet[bindec($chunk)];
    }
    return $output;
}

function base32Decode(string $data): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $data = strtoupper(preg_replace('/[^A-Z2-7]/i', '', (string)$data));
    $bits = '';
    foreach (str_split($data) as $char) {
        $pos = strpos($alphabet, $char);
        if ($pos === false) continue;
        $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    foreach (str_split($bits, 8) as $chunk) {
        if (strlen($chunk) < 8) break;
        $bytes .= chr(bindec($chunk));
    }
    return $bytes;
}

function generateTotpSecret(int $length = 20): string {
    return base32Encode(random_bytes($length));
}

function getTotpCode(string $base32Secret, ?int $timeSlice = null, int $period = 30, int $digits = 6): string {
    if ($timeSlice === null) {
        $timeSlice = (int)floor(time() / $period);
    }
    $secretKey = base32Decode($base32Secret);
    $time = pack('J', $timeSlice); // 8-байтный big-endian счётчик (PHP >= 5.6.3)
    $hash = hash_hmac('sha1', $time, $secretKey, true);
    $offset = ord(substr($hash, -1)) & 0x0F;
    $part = substr($hash, $offset, 4);
    $unpacked = unpack('N', $part);
    $value = ($unpacked[1] ?? 0) & 0x7FFFFFFF;
    $code = $value % (10 ** $digits);
    return str_pad((string)$code, $digits, '0', STR_PAD_LEFT);
}

function verifyTotpCode(string $base32Secret, string $code, int $window = 1, int $period = 30): bool {
    $code = trim($code);
    if (!preg_match('/^\d{6}$/', $code)) {
        return false;
    }
    $currentSlice = (int)floor(time() / $period);
    for ($i = -$window; $i <= $window; $i++) {
        if (hash_equals(getTotpCode($base32Secret, $currentSlice + $i, $period), $code)) {
            return true;
        }
    }
    return false;
}

// ============================================================
// 2FA: резервные коды (на случай утери устройства с приложением-аутентификатором)
// ============================================================
function generateBackupCodes(int $count = 8): array {
    $codes = [];
    for ($i = 0; $i < $count; $i++) {
        $raw = strtoupper(bin2hex(random_bytes(5)));
        $codes[] = substr($raw, 0, 5) . '-' . substr($raw, 5, 5);
    }
    return $codes;
}

function verifyBackupCode(mysqli $conn, int $user_id, string $code): bool {
    $code = trim($code);
    if ($code === '') return false;
    $stmt = $conn->prepare("SELECT id, code_hash FROM user_backup_codes WHERE user_id = ? AND used_at IS NULL");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $matchedId = null;
    while ($row = $result->fetch_assoc()) {
        if (password_verify($code, $row['code_hash'])) {
            $matchedId = (int)$row['id'];
            break;
        }
    }
    $stmt->close();
    if ($matchedId === null) {
        return false;
    }
    $update = $conn->prepare("UPDATE user_backup_codes SET used_at = NOW() WHERE id = ?");
    $update->bind_param('i', $matchedId);
    $update->execute();
    $update->close();
    return true;
}

// ============================================================
// 2FA: обработка действий формы
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'logout_all') {
    requireSettingsCsrf();
    revokeAllSessions($conn, $user_id);
    $conn->close();
    destroyCurrentSession();
    header('Location: login.php');
    exit;
}

$message = "";
$error = "";
$lang = $_COOKIE['lang'] ?? $_SESSION['lang'] ?? 'ru';
$lang = in_array($lang, ['ru', 'en'], true) ? $lang : 'ru';

if (isset($_GET['account_updated'])) {
    $message = $lang === 'en' ? 'Account details updated.' : 'Данные аккаунта обновлены.';
} elseif (isset($_GET['password_updated'])) {
    $message = $lang === 'en' ? 'Password changed successfully.' : 'Пароль успешно изменён.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['action'] ?? '', ['update_password', 'update_email'], true)) {
    requireSettingsCsrf();
    $accountAction = (string)$_POST['action'];
    $currentPassword = (string)($_POST['current_password'] ?? '');

    $stmt = $conn->prepare('SELECT password FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $passwordHash = (string)($stmt->get_result()->fetch_assoc()['password'] ?? '');
    $stmt->close();

    if ($passwordHash === '' || !password_verify($currentPassword, $passwordHash)) {
        $error = $lang === 'en' ? 'Current password is incorrect.' : 'Текущий пароль указан неверно.';
    } elseif ($accountAction === 'update_password') {
        $newPassword = (string)($_POST['new_password'] ?? '');
        $confirmPassword = (string)($_POST['confirm_password'] ?? '');
        if (strlen($newPassword) < 6) {
            $error = $lang === 'en' ? 'Password must contain at least 6 characters.' : 'Пароль должен содержать не менее 6 символов.';
        } elseif (!hash_equals($newPassword, $confirmPassword)) {
            $error = $lang === 'en' ? 'Passwords do not match.' : 'Пароли не совпадают.';
        } else {
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('UPDATE users SET password = ? WHERE id = ?');
            $stmt->bind_param('si', $newHash, $user_id);
            $stmt->execute();
            $stmt->close();
            header('Location: settings.php?password_updated=1');
            exit;
        }
    } else {
        $newEmail = trim((string)($_POST['new_email'] ?? ''));
        if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $error = $lang === 'en' ? 'Enter a valid email address.' : 'Введите корректный адрес электронной почты.';
        } else {
            $stmt = $conn->prepare('SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1');
            $stmt->bind_param('si', $newEmail, $user_id);
            $stmt->execute();
            $emailExists = (bool)$stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($emailExists) {
                $error = $lang === 'en' ? 'This email is already in use.' : 'Этот адрес электронной почты уже используется.';
            } else {
                $stmt = $conn->prepare('UPDATE users SET email = ? WHERE id = ?');
                $stmt->bind_param('si', $newEmail, $user_id);
                try {
                    $stmt->execute();
                    $stmt->close();
                    header('Location: settings.php?account_updated=1');
                    exit;
                } catch (mysqli_sql_exception $exception) {
                    $stmt->close();
                    if ($exception->getCode() !== 1062) {
                        throw $exception;
                    }
                    $error = $lang === 'en' ? 'This email is already in use.' : 'Этот адрес электронной почты уже используется.';
                }
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['twofa_action'])) {
    $twofa_action = (string)$_POST['twofa_action'];

    if ($twofa_action === 'start') {
        requireSettingsCsrf();
        $_SESSION['pending_totp_secret'] = generateTotpSecret();
        header('Location: settings.php?twofa=setup');
        exit;
    }

    if ($twofa_action === 'cancel') {
        requireSettingsCsrf();
        unset($_SESSION['pending_totp_secret']);
        header('Location: settings.php');
        exit;
    }

    if ($twofa_action === 'confirm') {
        requireSettingsCsrf();
        $pending_secret = (string)($_SESSION['pending_totp_secret'] ?? '');
        $code = (string)($_POST['totp_code'] ?? '');
        if ($pending_secret === '' || !verifyTotpCode($pending_secret, $code)) {
            $error = ($lang === 'en') ? 'Invalid code. Please try again.' : 'Неверный код. Попробуйте снова.';
        } else {
            $stmt = $conn->prepare("UPDATE users SET totp_secret = ?, totp_enabled = 1 WHERE id = ?");
            $stmt->bind_param('si', $pending_secret, $user_id);
            $stmt->execute();
            $stmt->close();
            unset($_SESSION['pending_totp_secret']);

            $del = $conn->prepare("DELETE FROM user_backup_codes WHERE user_id = ?");
            $del->bind_param('i', $user_id);
            $del->execute();
            $del->close();

            $codes = generateBackupCodes();
            $insertCode = $conn->prepare("INSERT INTO user_backup_codes (user_id, code_hash) VALUES (?, ?)");
            foreach ($codes as $plainCode) {
                $hash = password_hash($plainCode, PASSWORD_DEFAULT);
                $insertCode->bind_param('is', $user_id, $hash);
                $insertCode->execute();
            }
            $insertCode->close();

            $_SESSION['show_backup_codes'] = $codes;
            header('Location: settings.php?twofa=enabled');
            exit;
        }
    }

    if ($twofa_action === 'disable') {
        requireSettingsCsrf();
        $code = (string)($_POST['totp_code'] ?? '');
        $ok = $totp_secret_stored && verifyTotpCode((string)$totp_secret_stored, $code);
        if (!$ok) {
            $ok = verifyBackupCode($conn, $user_id, $code);
        }
        if (!$ok) {
            $error = ($lang === 'en') ? 'Invalid code.' : 'Неверный код.';
        } else {
            $stmt = $conn->prepare("UPDATE users SET totp_secret = NULL, totp_enabled = 0 WHERE id = ?");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $stmt->close();
            $del = $conn->prepare("DELETE FROM user_backup_codes WHERE user_id = ?");
            $del->bind_param('i', $user_id);
            $del->execute();
            $del->close();
            header('Location: settings.php?twofa=disabled');
            exit;
        }
    }

    if ($twofa_action === 'regenerate_codes') {
        requireSettingsCsrf();
        $code = (string)($_POST['totp_code'] ?? '');
        $ok = $totp_secret_stored && verifyTotpCode((string)$totp_secret_stored, $code);
        if (!$ok) {
            $error = ($lang === 'en') ? 'Invalid code.' : 'Неверный код.';
        } else {
            $del = $conn->prepare("DELETE FROM user_backup_codes WHERE user_id = ?");
            $del->bind_param('i', $user_id);
            $del->execute();
            $del->close();

            $codes = generateBackupCodes();
            $insertCode = $conn->prepare("INSERT INTO user_backup_codes (user_id, code_hash) VALUES (?, ?)");
            foreach ($codes as $plainCode) {
                $hash = password_hash($plainCode, PASSWORD_DEFAULT);
                $insertCode->bind_param('is', $user_id, $hash);
                $insertCode->execute();
            }
            $insertCode->close();

            $_SESSION['show_backup_codes'] = $codes;
            header('Location: settings.php?twofa=codes');
            exit;
        }
    }
}

$twofa_setup_pending = !$totp_enabled && !empty($_SESSION['pending_totp_secret']);
$twofa_pending_secret = $twofa_setup_pending ? (string)$_SESSION['pending_totp_secret'] : '';
$twofa_qr_uri = '';
if ($twofa_pending_secret !== '') {
    $issuer = 'VS';
    $label = rawurlencode($issuer . ':' . ($username !== '' ? $username : 'user'));
    $twofa_qr_uri = 'otpauth://totp/' . $label
        . '?secret=' . $twofa_pending_secret
        . '&issuer=' . rawurlencode($issuer)
        . '&algorithm=SHA1&digits=6&period=30';
}

$backup_codes_to_show = $_SESSION['show_backup_codes'] ?? [];
unset($_SESSION['show_backup_codes']);

$avatarLetter = mb_strtoupper(mb_substr($username ?: "Я", 0, 1, "UTF-8"), "UTF-8");

// Получаем историю IP
$conn->query("
    CREATE TABLE IF NOT EXISTS user_ip_history (
        id INT NOT NULL AUTO_INCREMENT,
        user_id INT NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        user_agent VARCHAR(255) NULL,
        action VARCHAR(20) DEFAULT 'login',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX user_id (user_id),
        INDEX ip_address (ip_address)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$ip_history = [];
$ip_history_map = [];
$stmt = $conn->prepare("
    SELECT ip_address, user_agent, MAX(created_at) as created_at,
           COUNT(*) as login_count,
           SUM(CASE WHEN action = 'login' THEN 1 ELSE 0 END) as login_actions,
           SUM(CASE WHEN action = 'logout' THEN 1 ELSE 0 END) as logout_actions
    FROM user_ip_history
    WHERE user_id = ?
    GROUP BY ip_address, user_agent
    ORDER BY MAX(created_at) DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    // ::1 / ::ffff:x.x.x.x -> нормальный вид, одинаковые IP объединяем
    $row['ip_address'] = normalizeIpAddress($row['ip_address']) ?: $row['ip_address'];
    $key = $row['ip_address'] . '|' . ($row['user_agent'] ?? '');
    if (isset($ip_history_map[$key])) {
        $ip_history_map[$key]['login_count']   += (int)$row['login_count'];
        $ip_history_map[$key]['login_actions'] += (int)$row['login_actions'];
        $ip_history_map[$key]['logout_actions'] += (int)$row['logout_actions'];
        if ($row['created_at'] > $ip_history_map[$key]['created_at']) {
            $ip_history_map[$key]['created_at'] = $row['created_at'];
        }
    } else {
        $ip_history_map[$key] = $row;
    }
}
$stmt->close();
$ip_history = array_values($ip_history_map);
usort($ip_history, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));

$current_ip = getClientIpAddress();

// Есть входы с IP, отличающегося от текущего — предлагаем выйти со всех устройств
$ip_mismatch = false;
if ($current_ip !== '') {
    foreach ($ip_history as $h) {
        if ($h['ip_address'] !== $current_ip) {
            $ip_mismatch = true;
            break;
        }
    }
}

// ============================================================
// ДАННЫЕ ДЛЯ ШАПКИ (как на index.php): уведомления, аватар, модерация
// ============================================================
function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;

    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function isOnline(?string $status): bool {
    return $status === 'online';
}

$notifications = [];
$notif_count = 0;

$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar as sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC
    LIMIT 30
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    if (empty($row['sender_avatar']) && !empty($row['sender_id'])) {
        $stmt2 = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
        $stmt2->bind_param("i", $row['sender_id']);
        $stmt2->execute();
        $res2 = $stmt2->get_result();
        if ($sender_row = $res2->fetch_assoc()) {
            $row['sender_avatar'] = $sender_row['avatar'];
        }
        $stmt2->close();
    }
    $notifications[] = $row;
}
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$notif_count = (int)($result->fetch_assoc()['count'] ?? 0);
$stmt->close();

$current_user_data = ['id' => $user_id, 'username' => $username, 'avatar' => $avatar, 'status' => $status];

$pending_reports_count = 0;
if ($is_admin) {
    $result = $conn->query("SELECT COUNT(*) as c FROM reports WHERE status = 'pending'");
    $pending_reports_count = (int)($result->fetch_assoc()['c'] ?? 0);
}

// Получаем настройки темы и языка из кук или сессии
$theme = $_COOKIE['theme'] ?? $_SESSION['theme'] ?? 'dark';
$lang = $_COOKIE['lang'] ?? $_SESSION['lang'] ?? 'ru';
$theme = in_array($theme, ['dark', 'light', 'system'], true) ? $theme : 'dark';
$lang = in_array($lang, ['ru', 'en'], true) ? $lang : 'ru';

// Положение панели навигации (ПК): снизу, сверху или слева. На телефоне панель всегда снизу:
// это применяют bottom_nav.php и nav-position.js, сохранённое значение при этом не теряется.
$nav_positions = ['bottom', 'top', 'left'];
$nav_pos = $_COOKIE['nav_pos'] ?? ($_SESSION['nav_pos'] ?? 'bottom');
if (!in_array($nav_pos, $nav_positions, true)) { $nav_pos = 'bottom'; }

// Закреплённая панель навигации: включено — панель всегда на виду и не прячется
$nav_pin = (($_COOKIE['nav_pin'] ?? $_SESSION['nav_pin'] ?? '0') === '1');
if ($nav_pos === 'left') { $nav_pin = true; }   // панель слева всегда закреплена и не прячется

// Выбор темы из меню профиля в шапке (includes/site_header.php): это обычные
// ссылки ?theme=dark|light|system, то есть GET. Раньше страница настроек
// принимала тему только через POST, и клик по теме в меню ничего не менял.
if (isset($_GET['theme']) && in_array($_GET['theme'], ['dark', 'light', 'system'], true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, time() + 365 * 24 * 60 * 60, '/');
    $_SESSION['theme'] = $theme;
    header('Location: settings.php');
    exit;
}

// Тема в настройках больше не меняется: переключатель живёт в меню профиля в шапке
// и синхронизируется между страницами, вкладками и «Пространствами» (assets/js/theme-switch.js).
// Сохраняем остальные настройки, если переданы
if (isset($_POST['lang'])) {
    $lang = in_array($_POST['lang'], ['ru', 'en'], true) ? $_POST['lang'] : 'ru';
    setcookie('lang', $lang, time() + 365 * 24 * 60 * 60, '/');
    $_SESSION['lang'] = $lang;
}

$prev_nav_pos = $nav_pos;   // положение до этого запроса (при уходе с «слева» закрепление не сбрасываем)
if (isset($_POST['nav_pos']) && in_array($_POST['nav_pos'], $nav_positions, true)) {
    $nav_pos = $_POST['nav_pos'];
    setcookie('nav_pos', $nav_pos, time() + 365 * 24 * 60 * 60, '/');
    $_SESSION['nav_pos'] = $nav_pos;
}

// Переключатель «Закрепить панель»: чекбокс при выключении не отправляется,
// поэтому форма всегда шлёт скрытое поле nav_pin_submitted.
if (isset($_POST['nav_pin_submitted'])) {
    $nav_pin = isset($_POST['nav_pin']) || $nav_pos === 'left' || $prev_nav_pos === 'left';
    setcookie('nav_pin', $nav_pin ? '1' : '0', time() + 365 * 24 * 60 * 60, '/');
    $_SESSION['nav_pin'] = $nav_pin ? '1' : '0';
}

// После сохранения общих настроек перенаправляем на эту же страницу (Post/Redirect/Get),
// чтобы обновление (F5) не вызывало окно «Подтвердите повторную отправку формы».
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['lang']) || isset($_POST['nav_pos']) || isset($_POST['nav_pin_submitted']))) {
    header('Location: settings.php');
    exit;
}

// Тексты для локализации
$translations = [
    'ru' => [
        'settings' => 'Настройки',
        'general' => 'Общие',
        'profile' => 'Профиль',
        'account' => 'Аккаунт',
        'vspace_id' => 'V SPACE ID',
        'password_change' => 'Сменить пароль',
        'password_change_hint' => 'Подтвердите текущий пароль и введите новый.',
        'current_password' => 'Текущий пароль',
        'new_password' => 'Новый пароль',
        'confirm_password' => 'Повторите новый пароль',
        'save_password' => 'Сменить пароль',
        'email_change' => 'Сменить почту',
        'email_change_hint' => 'Подтвердите пароль, чтобы изменить адрес электронной почты.',
        'new_email' => 'Новый адрес электронной почты',
        'save_email' => 'Сменить почту',
        'ip_history' => 'IP адреса входов',
        'danger_zone' => 'Опасная зона',
        'language' => 'Язык',
        'russian' => 'Русский',
        'english' => 'Английский',
        'nav_position' => 'Положение панели навигации',
        'nav_position_hint' => 'На компьютере панель можно разместить снизу, сверху или слева. На телефоне она всегда внизу.',
        'nav_bottom' => 'Снизу',
        'nav_top' => 'Сверху',
        'nav_left' => 'Слева',
        'nav_pin' => 'Закрепить панель навигации',
        'nav_pin_hint' => 'Включено — панель всегда на виду и не прячется. Выключено — панель выезжает при наведении и прокрутке.',
        'nav_pin_locked' => 'Панель слева всегда закреплена — отключить это нельзя. Выберите другое положение, чтобы изменить.',
        'nm_title' => 'Вид панели навигации',
        'nm_hint' => 'Настройки применяются только на этом устройстве и сразу сохраняются. На телефоне и на компьютере они хранятся отдельно.',
        'nm_style' => 'Вид панели',
        'nm_dock' => 'Док',
        'nm_labels' => 'С подписями',
        'nm_compact' => 'Компакт',
        'nm_accent' => 'Цвет подсветки',
        'nm_c_red' => 'Космический красный',
        'nm_c_blue' => 'Синий',
        'nm_c_violet' => 'Фиолетовый',
        'nm_c_green' => 'Зелёный',
        'nm_c_gold' => 'Золотой',
        'nm_c_site' => 'По умолчанию',
        'nm_c_custom' => 'Свой цвет',
        'nm_eyedropper' => 'Пипетка',
        'nm_save_color' => 'Сохранить цвет',
        'nm_color_saved' => 'Цвет сохранён',
        'nm_color_remove' => 'Удалить цвет',
        'nm_autohide' => 'Скрывать при прокрутке вниз',
        'nm_autohide_desc' => 'На компьютере панель скрывается при прокрутке вниз и возвращается при прокрутке вверх.',
        'nm_items' => 'Пункты панели',
        'nm_items_hint' => 'Включайте и выключайте пункты, порядок меняйте стрелками. Хотя бы один пункт остаётся всегда.',
        'nm_up' => 'Выше',
        'nm_down' => 'Ниже',
        'nm_reset' => 'Сбросить настройки панели',
        'delete_profile' => 'Удалить профиль',
        'delete_confirm' => 'Вы уверены, что хотите удалить свой профиль? Это действие необратимо!',
        'deactivate_profile' => 'Временно отключить учётную запись',
        'deactivate_confirm' => 'Временно отключить учётную запись? Вы выйдете из аккаунта, но сможете включить его обратно, просто войдя снова с прежним паролем.',
        'deactivate_warning' => 'Пока аккаунт отключён, вы будете выглядеть офлайн. Обычный вход с логином и паролем сразу включит аккаунт обратно.',
        'support' => 'Поддержка',
        'current_ip' => 'Текущий IP',
        'ip_address' => 'IP адрес',
        'last_login' => 'Последний вход',
        'logins' => 'Входов',
        'logouts' => 'Выходов',
        'device' => 'Устройство',
        'no_ip_history' => 'Нет записей об IP адресах',
        'ip_not_determined' => 'не определен',
        'logout_all_title' => 'Есть входы с другого IP-адреса',
        'logout_all_text' => 'В истории есть входы с IP, отличающимся от вашего текущего. Если это были не вы — завершите все сеансы и смените пароль.',
        'logout_all_btn' => 'Выйти со всех устройств',
        'logout_all_confirm' => 'Выйти из аккаунта на всех устройствах, включая это? Потребуется войти заново.',
        'profile_info' => 'Основная информация',
        'account_info' => 'Информация о вашей учётной записи',
        'ip_list' => 'Список IP адресов, с которых вы входили',
        'danger_warning' => 'После удаления профиля восстановление невозможно. Все данные будут удалены безвозвратно.',
        'zone_deactivate_btn' => 'Отключить',
        'zone_delete_btn' => 'Удалить',
        'zone_support_text' => 'Не уверены или что-то пошло не так? Мы поможем разобраться.',
        'showing' => 'Показано',
        'unique_ips' => 'уникальных IP',
        'email' => 'Email',
        'discord_title' => 'Discord',
        'discord_text' => 'Присоединяйтесь к нашему Discord-серверу для общения и помощи.',
        'discord_button' => 'Открыть Discord',
        'logout' => 'Выход',
        '2fa_title' => 'Двухфакторная аутентификация (2FA)',
        '2fa_subtitle' => 'Дополнительная защита входа с помощью приложения-аутентификатора',
        '2fa_enabled_badge' => 'ВКЛЮЧЕНА',
        '2fa_disabled_text' => '2FA сейчас отключена. Рекомендуем включить её для защиты аккаунта.',
        '2fa_enable_button' => 'Включить 2FA',
        '2fa_setup_intro' => 'Отсканируйте QR-код приложением-аутентификатором (Google Authenticator, Authy и т.п.) или введите ключ вручную, затем введите 6-значный код для подтверждения.',
        '2fa_manual_key' => 'Ключ для ручного ввода',
        '2fa_code_placeholder' => '6-значный код',
        '2fa_confirm_button' => 'Подтвердить и включить',
        '2fa_cancel_button' => 'Отмена',
        '2fa_enabled_text' => '2FA включена и защищает вход в ваш аккаунт.',
        '2fa_disable_button' => 'Отключить 2FA',
        '2fa_regen_button' => 'Обновить резервные коды',
        '2fa_backup_codes_title' => 'Резервные коды',
        '2fa_backup_codes_warning' => 'Сохраните эти коды в надёжном месте — они показываются только один раз. Каждый код можно использовать один раз вместо кода из приложения, если у вас нет доступа к нему.',
        '2fa_disable_confirm_title' => 'Для отключения введите код из приложения или резервный код',
        '2fa_open_app' => 'Открыть в приложении-аутентификаторе',
        '2fa_qr_failed' => 'Не удалось построить QR-код — используйте ключ для ручного ввода.',
        'verification_title' => 'Верификация',
        'verification_subtitle' => 'Галочка подтверждает, что страница защищена двухфакторной аутентификацией',
        'verified_badge' => 'ВЕРИФИЦИРОВАНА',
        'verified_text' => 'Страница верифицирована — 2FA подключена.',
        'not_verified_text' => 'Страница не верифицирована.',
        'not_verified_hint' => 'Подключите двухфакторную аутентификацию (2FA) ниже, и страница получит галочку.'
    ],
    'en' => [
        'settings' => 'Settings',
        'general' => 'General',
        'profile' => 'Profile',
        'account' => 'Account',
        'vspace_id' => 'V SPACE ID',
        'password_change' => 'Change Password',
        'password_change_hint' => 'Confirm your current password and enter a new one.',
        'current_password' => 'Current password',
        'new_password' => 'New password',
        'confirm_password' => 'Confirm new password',
        'save_password' => 'Change password',
        'email_change' => 'Change email',
        'email_change_hint' => 'Confirm your password to change your email address.',
        'new_email' => 'New email address',
        'save_email' => 'Change email',
        'ip_history' => 'IP Login History',
        'danger_zone' => 'Danger Zone',
        'language' => 'Language',
        'russian' => 'Russian',
        'english' => 'English',
        'nav_position' => 'Navigation panel position',
        'nav_position_hint' => 'On a computer the panel can be at the bottom, top or left. On a phone it is always at the bottom.',
        'nav_bottom' => 'Bottom',
        'nav_top' => 'Top',
        'nav_left' => 'Left',
        'nav_pin' => 'Pin the navigation panel',
        'nav_pin_hint' => 'On — the panel is always visible and never hides. Off — the panel slides in on hover and scroll.',
        'nav_pin_locked' => 'The left panel is always pinned and this cannot be turned off. Choose another position to change it.',
        'nm_title' => 'Navigation bar style',
        'nm_hint' => 'These settings apply only on this device and are saved immediately. Phone and computer keep separate settings.',
        'nm_style' => 'Bar style',
        'nm_dock' => 'Dock',
        'nm_labels' => 'With labels',
        'nm_compact' => 'Compact',
        'nm_accent' => 'Highlight color',
        'nm_c_red' => 'Cosmic red',
        'nm_c_blue' => 'Blue',
        'nm_c_violet' => 'Violet',
        'nm_c_green' => 'Green',
        'nm_c_gold' => 'Gold',
        'nm_c_site' => 'Default',
        'nm_c_custom' => 'Custom color',
        'nm_eyedropper' => 'Eyedropper',
        'nm_save_color' => 'Save color',
        'nm_color_saved' => 'Color saved',
        'nm_color_remove' => 'Remove color',
        'nm_autohide' => 'Hide while scrolling down',
        'nm_autohide_desc' => 'On desktop, the bar hides while scrolling down and returns when you scroll up.',
        'nm_items' => 'Bar items',
        'nm_items_hint' => 'Turn items on or off and reorder them with the arrows. At least one item always stays.',
        'nm_up' => 'Move up',
        'nm_down' => 'Move down',
        'nm_reset' => 'Reset bar settings',
        'delete_profile' => 'Delete Profile',
        'delete_confirm' => 'Are you sure you want to delete your profile? This action is irreversible!',
        'deactivate_profile' => 'Temporarily Deactivate Account',
        'deactivate_confirm' => 'Temporarily deactivate your account? You will be logged out, but you can turn it back on any time just by logging in again with your usual password.',
        'deactivate_warning' => 'While deactivated, you will appear offline. A normal login with your username and password turns the account back on immediately.',
        'support' => 'Support',
        'current_ip' => 'Current IP',
        'ip_address' => 'IP Address',
        'last_login' => 'Last login',
        'logins' => 'Logins',
        'logouts' => 'Logouts',
        'device' => 'Device',
        'no_ip_history' => 'No IP address records',
        'ip_not_determined' => 'not determined',
        'logout_all_title' => 'Logins from a different IP address',
        'logout_all_text' => 'The history contains logins from an IP different from your current one. If that was not you, log out everywhere and change your password.',
        'logout_all_btn' => 'Log out of all devices',
        'logout_all_confirm' => 'Log out of your account on all devices, including this one? You will need to sign in again.',
        'profile_info' => 'Profile information',
        'account_info' => 'Your account information',
        'ip_list' => 'List of IP addresses you have logged in from',
        'danger_warning' => 'After profile deletion, recovery is impossible. All data will be permanently deleted.',
        'zone_deactivate_btn' => 'Deactivate',
        'zone_delete_btn' => 'Delete',
        'zone_support_text' => 'Not sure, or something went wrong? We will help you sort it out.',
        'showing' => 'Showing',
        'unique_ips' => 'unique IPs',
        'email' => 'Email',
        'discord_title' => 'Discord',
        'discord_text' => 'Join our Discord server for communication and support.',
        'discord_button' => 'Open Discord',
        'logout' => 'Logout',
        '2fa_title' => 'Two-Factor Authentication (2FA)',
        '2fa_subtitle' => 'Extra sign-in protection using an authenticator app',
        '2fa_enabled_badge' => 'ENABLED',
        '2fa_disabled_text' => '2FA is currently disabled. We recommend enabling it to protect your account.',
        '2fa_enable_button' => 'Enable 2FA',
        '2fa_setup_intro' => 'Scan the QR code with an authenticator app (Google Authenticator, Authy, etc.) or enter the key manually, then enter the 6-digit code to confirm.',
        '2fa_manual_key' => 'Manual entry key',
        '2fa_code_placeholder' => '6-digit code',
        '2fa_confirm_button' => 'Confirm and enable',
        '2fa_cancel_button' => 'Cancel',
        '2fa_enabled_text' => '2FA is enabled and protecting sign-in to your account.',
        '2fa_disable_button' => 'Disable 2FA',
        '2fa_regen_button' => 'Regenerate backup codes',
        '2fa_backup_codes_title' => 'Backup codes',
        '2fa_backup_codes_warning' => 'Save these codes somewhere safe — they are shown only once. Each code can be used once instead of your app code if you lose access to it.',
        '2fa_disable_confirm_title' => 'Enter your app code or a backup code to disable',
        '2fa_open_app' => 'Open in authenticator app',
        '2fa_qr_failed' => 'Could not build the QR code — use the manual entry key.',
        'verification_title' => 'Verification',
        'verification_subtitle' => 'The check mark confirms the account is protected with two-factor authentication',
        'verified_badge' => 'VERIFIED',
        'verified_text' => 'Account is verified — 2FA is enabled.',
        'not_verified_text' => 'Account is not verified.',
        'not_verified_hint' => 'Enable two-factor authentication (2FA) below and the account will get a check mark.'
    ]
];

$t = $translations[$lang] ?? $translations['ru'];


function getSettingsAvatarUrl(string $avatar): string {
    return ltrim(str_replace('\\', '/', trim($avatar)), '/');
}

function settingsAvatarExists(string $avatar): bool {
    return $avatar !== '' && is_file(__DIR__ . DIRECTORY_SEPARATOR . ltrim($avatar, '/\\'));
}

?>
<!DOCTYPE html>
<html lang="<?= $lang === 'en' ? 'en' : 'ru' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/nav-position.css">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title><?= $t['settings'] ?></title>
    <style>
        /* ============================================================
           Страница настроек — оформление на переменных темы из index.css
           (цвета берутся из [data-theme], поэтому светлая/тёмная/системная
           темы работают без PHP-подстановок)
           ============================================================ */
        * { box-sizing: border-box; margin: 0; padding: 0; }

        html { overflow-x: hidden; }

        /* Цвет «ок» (текущий IP, верификация) — палитра Сатурна: бледное золото на тёмной теме,
           тёмная охра на светлой. Бейджи — тёмно-коричневая плашка со светлым золотом. */
        :root {
            --ok-text: #e8cd8c;
            --ok-badge-bg: #43361a;
            --ok-badge-text: #ecd391;
            /* Фон карточек .settings-card — штатный белый/тёмный из темы */
            --settings-card-bg: var(--bg-card);
            /* Фон страницы по бокам от карточек (на светлой теме затемняется ниже) */
            --settings-page-bg: var(--bg-primary);
            /* Обводка и тень карточек (на светлой теме усиливаются ниже) */
            --settings-card-border: var(--border-color);
            --settings-card-shadow: var(--card-shadow);
        }
        [data-theme="light"] {
            --ok-text: #8a6414;
            --settings-page-bg: #d6d9e0;
            --settings-card-bg: #FFFFFF;
            --settings-card-border: rgba(0, 0, 0, 0.22);
            --settings-card-border-hover: rgba(0, 0, 0, 0.34);
            --settings-card-shadow: 0 8px 26px rgba(0, 0, 0, 0.18), 0 2px 4px rgba(0, 0, 0, 0.10);
        }
        @media (prefers-color-scheme: light) {
            [data-theme="system"] {
                --ok-text: #8a6414;
                --settings-page-bg: #d6d9e0;
                --settings-card-bg: #FFFFFF;
                --settings-card-border: rgba(0, 0, 0, 0.22);
                --settings-card-border-hover: rgba(0, 0, 0, 0.34);
                --settings-card-shadow: 0 8px 26px rgba(0, 0, 0, 0.18), 0 2px 4px rgba(0, 0, 0, 0.10);
            }
        }

        body {
            min-height: 100vh;
            font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            background: var(--settings-page-bg);
            color: var(--text-primary);
            transition: background 0.3s ease, color 0.3s ease;
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: var(--scrollbar-track); border-radius: 4px; }
        ::-webkit-scrollbar-thumb { background: var(--scrollbar-thumb); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--scrollbar-thumb-hover); }
        * { scrollbar-width: thin; scrollbar-color: var(--scrollbar-thumb) var(--scrollbar-track); }

        .header-left { display: flex; align-items: center; gap: 20px; }

        .layout {
            width: min(100% - 32px, 900px);
            max-width: 900px;
            min-width: 0;
            margin: 20px auto !important;
            padding: 0 0 90px;
            display: grid;
            grid-template-columns: minmax(0, 1fr);
            gap: 16px;
        }

        main { width: 100%; min-width: 0; }

        .settings-container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
            display: grid;
            gap: 16px;
        }

        /* ===== Заголовок страницы ===== */
        .page-title {
            margin-bottom: 4px;
            font-size: 30px;
            font-weight: 800;
            letter-spacing: -0.3px;
            color: var(--text-white);
        }

        /* ===== Карточки ===== */
        .settings-card {
            position: relative;
            background: var(--settings-card-bg);
            border: 1px solid var(--settings-card-border);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--settings-card-shadow);
            transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
        }
        .settings-card:hover { border-color: var(--settings-card-border-hover, var(--border-light)); }

        .card-title {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            padding: 22px 24px 4px;
            color: var(--text-white);
            font-size: 17px;
            font-weight: 700;
        }

        .card-subtitle {
            padding: 0 24px 18px;
            color: var(--text-secondary);
            font-size: 13px;
            line-height: 1.5;
        }

        .settings-body {
            padding: 8px 24px 24px;
            overflow-x: auto;
        }

        /* ===== Формы ===== */
        .settings-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }
        .form-group { margin: 0; }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-secondary);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.6px;
            text-transform: uppercase;
        }

        .form-select, .form-input {
            width: 100%;
            max-width: 340px;
            height: 44px;
            padding: 0 14px;
            border: 1px solid var(--border-light);
            outline: none;
            border-radius: 10px;
            background: var(--bg-input);
            color: var(--text-primary);
            font-family: inherit;
            font-size: 14px;
            transition: border-color 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
        }
        .form-input { cursor: not-allowed; color: var(--text-secondary); }

        select.form-select {
            appearance: none;
            -webkit-appearance: none;
            cursor: pointer;
            padding-right: 38px;
            background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'><path d='M1 1.5l5 5 5-5' fill='none' stroke='%23949ba4' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'/></svg>");
            background-repeat: no-repeat;
            background-position: right 14px center;
        }
        select.form-select option { background: var(--bg-card); color: var(--text-primary); }

        .form-select:hover, .form-input:hover { border-color: var(--text-muted); }
        .form-select:focus, .form-input:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(88, 101, 242, 0.25);
            background-color: var(--bg-input-focus);
        }
        .form-select::placeholder { color: var(--text-muted); }

        /* ===== Кнопки ===== */
        .save-button, .danger-button, .zone-action-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border: none;
            padding: 11px 20px;
            border-radius: 10px;
            font-family: inherit;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: transform 0.18s ease, box-shadow 0.18s ease, background-color 0.18s ease, filter 0.18s ease;
        }

        .save-button {
            background: var(--accent-color);
            color: #fff;
            box-shadow: 0 2px 8px rgba(88, 101, 242, 0.25);
        }
        .save-button:hover {
            filter: brightness(1.1);
        }
        .save-button:active { transform: translateY(0) scale(0.98); box-shadow: none; }

        .save-button.ghost {
            background: transparent;
            color: var(--text-secondary);
            border: 1px solid var(--border-light);
            box-shadow: none;
            filter: none;
        }
        .save-button.ghost:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
            box-shadow: none;
        }

        .danger-button {
            background: var(--danger-color);
            color: #fff;
            box-shadow: 0 2px 8px rgba(237, 66, 69, 0.25);
        }
        .danger-button:hover {
            filter: brightness(1.1);
        }
        .danger-button:active { transform: translateY(0) scale(0.98); box-shadow: none; }

        .zone-action-button { color: #fff; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18); }
        .zone-action-button:hover { filter: brightness(1.1); }
        .zone-action-button:active { transform: translateY(0) scale(0.98); }

        .zone-action-icon { display: inline-block; transition: transform 0.25s ease; }
        .zone-action-button:hover .zone-action-icon { transform: rotate(-8deg) scale(1.15); }
        .danger-button:hover .zone-action-icon { transform: rotate(8deg) scale(1.15); }

        .zone-action-support { background: var(--accent-color); }

        .zone-action-deactivate { background: #faa61a; color: #241a00; }

        .settings-actions {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 12px;
            margin-top: 8px;
        }
        .settings-actions form { margin: 0; }
        .settings-actions .action-group { display: flex; gap: 8px; align-items: center; }

        /* ===== Опасная зона ===== */
        .danger-card {
            border-color: rgba(218, 55, 60, 0.45);
            background: var(--settings-card-bg);
        }
        .danger-card:hover { border-color: rgba(218, 55, 60, 0.7); }
        .danger-card .settings-body { background: rgba(218, 55, 60, 0.04); }

        .dz-head-ico {
            display: inline-flex; align-items: center; justify-content: center; flex: none;
            width: 34px; height: 34px; border-radius: 10px;
            background: rgba(237, 66, 69, 0.15);
        }

        .dz-list { display: flex; flex-direction: column; gap: 12px; }

        .dz-row {
            display: grid;
            grid-template-columns: auto minmax(0, 1fr) auto;
            align-items: center;
            gap: 16px;
            margin: 0;
            padding: 16px 18px;
            border: 1px solid var(--divider-color);
            border-radius: 14px;
            background: var(--bg-card);
            transition: border-color 0.2s ease, background-color 0.2s ease;
        }
        .dz-row-warn:hover   { border-color: rgba(250, 166, 26, 0.55); }
        .dz-row-danger       { border-color: rgba(237, 66, 69, 0.3); background: rgba(237, 66, 69, 0.05); }
        .dz-row-danger:hover { border-color: rgba(237, 66, 69, 0.65); }

        .dz-ico {
            display: inline-flex; align-items: center; justify-content: center;
            width: 46px; height: 46px; border-radius: 13px;
            transition: transform 0.25s ease;
        }
        .dz-row-warn .dz-ico   { color: #faa61a; background: rgba(250, 166, 26, 0.15); }
        .dz-row-danger .dz-ico { color: #ed4245; background: rgba(237, 66, 69, 0.15); }

        .dz-title { color: var(--text-white); font-size: 15px; font-weight: 700; line-height: 1.3; }
        .dz-desc  { margin-top: 3px; color: var(--text-secondary); font-size: 13px; line-height: 1.5; max-width: 62ch; }

        .dz-btn {
            display: inline-flex; align-items: center; justify-content: center;
            padding: 10px 20px; border: 1px solid transparent; border-radius: 10px;
            font-family: inherit; font-size: 14px; font-weight: 600; white-space: nowrap; cursor: pointer;
            transition: transform 0.18s ease, box-shadow 0.18s ease, filter 0.18s ease, background-color 0.18s ease;
        }
        .dz-btn:active { transform: translateY(0) scale(0.98); }
        .dz-btn:focus-visible { outline: 2px solid var(--accent-color); outline-offset: 2px; }

        .dz-btn-warn {
            color: #faa61a;
            color: color-mix(in srgb, #faa61a 70%, var(--text-white));
            background: rgba(250, 166, 26, 0.14);
            border-color: rgba(250, 166, 26, 0.5);
        }
        .dz-btn-warn:hover { background: rgba(250, 166, 26, 0.24); }

        .dz-btn-danger { color: #fff; background: var(--danger-color); box-shadow: 0 2px 8px rgba(237, 66, 69, 0.25); }
        .dz-btn-danger:hover { filter: brightness(1.1); }

        .dz-help {
            display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;
            gap: 12px 20px; margin-top: 18px;
        }
        .dz-help-text { display: inline-flex; align-items: center; gap: 10px; color: var(--text-secondary); font-size: 13px; line-height: 1.5; }
        .dz-help-text .s-ico { color: var(--accent-color); }

        /* ===== Строки информации ===== */
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 4px 16px;
            padding: 12px 0;
            color: var(--text-secondary);
            font-size: 14px;
        }
        .info-row:first-child { padding-top: 0; }
        .info-row:last-child { padding-bottom: 0; }
        .info-row > span:last-child:not(:first-child) { color: var(--text-primary); font-weight: 600; }

        /* ===== Статус верификации ===== */
        .verify-status {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 16px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            background: var(--bg-input);
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 600;
        }
        .verify-status img { flex: none; display: block; }
        .verify-status.is-ok .verify-text { color: var(--ok-text); }
        .verify-hint { margin-top: 10px; color: var(--text-secondary); font-size: 13px; line-height: 1.5; }

        /* ===== Бейджи ===== */
        .ip-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 999px;
            background: var(--accent-color);
            color: #fff;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        .ip-count-badge {
            display: inline-block;
            padding: 2px 9px;
            border-radius: 999px;
            background: var(--bg-hover);
            color: var(--text-secondary);
            font-size: 11px;
            font-weight: 600;
        }

        /* ===== Таблица IP ===== */
        .ip-history-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .ip-history-table th {
            text-align: left;
            padding: 10px 10px;
            color: var(--text-secondary);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            border-bottom: 1px solid var(--border-light);
            white-space: nowrap;
        }
        .ip-history-table td {
            padding: 11px 10px;
            border-bottom: 1px solid var(--divider-color);
            color: var(--text-primary);
        }
        .ip-history-table tr:last-child td { border-bottom: none; }
        .ip-history-table tbody tr { transition: background 0.15s ease; }
        .ip-history-table tbody tr:hover td { background: var(--bg-hover); }
        .ip-history-table .ip-current { color: var(--ok-text); font-weight: 600; }
        .ip-history-table .ip-old { color: var(--text-secondary); }
        .ip-alert {
            display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;
            margin-bottom: 16px; padding: 14px 16px; border-radius: 12px;
            background: rgba(250, 166, 26, 0.12); border: 1px solid rgba(250, 166, 26, 0.45);
        }
        .ip-alert-title { color: var(--text-white); font-size: 14px; font-weight: 700; }
        .ip-alert-desc { margin-top: 3px; color: var(--text-secondary); font-size: 13px; line-height: 1.5; max-width: 62ch; }
        .ip-history-empty { color: var(--text-secondary); font-size: 13px; padding: 20px 0; text-align: center; line-height: 1.7; }

        /* ===== Сообщения ===== */
        .error, .success {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 13px 16px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            border: 1px solid;
        }
        .error::before, .success::before {
            display: grid;
            place-items: center;
            flex: none;
            width: 22px; height: 22px;
            border-radius: 50%;
            font-size: 13px;
            font-weight: 800;
            color: #fff;
        }
        .success {
            background: var(--notification-success-bg);
            border-color: var(--notification-success-border);
            color: var(--notification-success-color);
        }
        .success::before { content: '✓'; background: var(--notification-success-border); }
        .error {
            background: var(--notification-error-bg);
            border-color: var(--notification-error-border);
            color: var(--notification-error-color);
        }
        .error::before { content: '!'; background: var(--notification-error-border); }

        /* ===== 2FA ===== */
        .twofa-backup-box {
            margin-bottom: 18px;
            padding: 16px;
            border-radius: 12px;
            background: rgba(240, 178, 50, 0.10);
            border: 1px solid rgba(240, 178, 50, 0.4);
        }
        .twofa-backup-title { margin-bottom: 6px; font-weight: 700; color: var(--mention-special-color); }
        .twofa-backup-warning { margin-bottom: 12px; font-size: 12px; line-height: 1.5; color: var(--text-secondary); }
        .twofa-backup-codes { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 8px; }
        .twofa-backup-codes code {
            display: block;
            padding: 8px 10px;
            text-align: center;
            border-radius: 8px;
            background: var(--bg-input);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            font-family: ui-monospace, 'SFMono-Regular', Consolas, monospace;
            font-size: 13px;
            letter-spacing: 1px;
        }

        .twofa-action-details {
            margin-top: 12px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            background: var(--bg-input);
            overflow: hidden;
        }
        .twofa-action-details summary {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            cursor: pointer;
            list-style: none;
            color: var(--text-primary);
            font-size: 14px;
            font-weight: 600;
            transition: background 0.15s ease;
        }
        .twofa-action-details summary::-webkit-details-marker { display: none; }
        .twofa-action-details summary::after {
            content: '›';
            font-size: 20px;
            line-height: 1;
            color: var(--text-secondary);
            transition: transform 0.2s ease;
        }
        .twofa-action-details summary:hover { background: var(--bg-hover); }
        .twofa-action-details[open] summary::after { transform: rotate(90deg); }
        .twofa-action-details .twofa-code-form { margin: 0; padding: 14px 16px 16px; max-width: 320px; }

        .twofa-code-form { margin-top: 12px; display: flex; flex-direction: column; gap: 8px; max-width: 280px; }
        .twofa-setup-grid { display: flex; gap: 24px; align-items: flex-start; flex-wrap: wrap; margin: 16px 0; }
        .twofa-qr {
            background: #fff;
            padding: 12px;
            border-radius: 14px;
            display: inline-block;
            line-height: 0;
            max-width: 100%;
            box-shadow: 0 6px 20px var(--shadow-color);
        }
        .twofa-qr svg { display: block; max-width: 100%; height: auto; }
        .twofa-manual { min-width: 200px; }
        .twofa-secret {
            display: inline-block;
            margin-top: 4px;
            padding: 9px 12px;
            border-radius: 8px;
            background: var(--bg-input);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            font-family: ui-monospace, 'SFMono-Regular', Consolas, monospace;
            font-size: 13px;
            letter-spacing: 1px;
            word-break: break-all;
        }

        /* ===== Подвал ===== */
        .site-footer {
            grid-column: 1 / -1;
            margin-top: 8px;
            padding: 20px 0;
            text-align: center;
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 500;
            letter-spacing: 0.5px;
        }
        .site-footer .year { color: var(--text-secondary); font-weight: 600; }

        /* ===== Оформление в стиле мессенджера: плоские карточки, один акцентный цвет ===== */
        .layout { gap: 16px; }

        .page-title { font-size: 32px; }

        .settings-card { border-radius: 16px; }
        .settings-card:hover { border-color: var(--settings-card-border-hover, var(--border-light)); }

        .card-title { font-size: 18px; padding-top: 24px; }
        .card-subtitle { padding-bottom: 20px; }

        .form-select, .form-input { border-radius: 10px; height: 46px; }

        .save-button { background: var(--accent-color); box-shadow: none; }
        .save-button:hover { box-shadow: none; }

        .info-row { padding: 12px 0; }

        /* ===== Выбор положения панели навигации ===== */
        .settings-grid .nav-group { grid-column: 1 / -1; }

        .nav-picker {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
            max-width: 420px;
        }
        .nav-option {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            padding: 14px 10px 12px;
            border: 1px solid var(--border-light);
            border-radius: 14px;
            background: var(--bg-input);
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            user-select: none;
            transition: border-color 0.18s ease, background 0.18s ease, color 0.18s ease, box-shadow 0.18s ease, transform 0.18s ease;
        }
        .nav-option input { position: absolute; opacity: 0; pointer-events: none; }
        .nav-option svg { display: block; max-width: 100%; height: auto; }
        .nav-option:hover { border-color: var(--accent-color); color: var(--text-primary); }
        .nav-option:focus-within { box-shadow: 0 0 0 3px rgba(88, 101, 242, 0.25); }
        .nav-option.is-active {
            border-color: var(--accent-color);
            background: rgba(88, 101, 242, 0.12);
            color: var(--text-primary);
            box-shadow: 0 0 0 3px rgba(88, 101, 242, 0.2);
        }
        @media (max-width: 640px) { .nav-option-pc { display: none; } }   /* на телефоне остаётся один вариант: «Снизу» */
        .nav-hint { margin-top: 10px; color: var(--text-muted); font-size: 12px; line-height: 1.5; }

        /* ===== Настройки панели на телефоне ===== */
        .nm-hint-top { margin: 0 0 12px; }
        .nm-sub { margin: 20px 0 10px; color: var(--text-primary); font-size: 13px; font-weight: 700; }
        .nm-group {
            margin-top: 24px;
            padding: 20px;
            border: 1px solid color-mix(in srgb, var(--accent-color) 34%, var(--border-light));
            border-radius: 18px;
            background:
                radial-gradient(ellipse at top right, color-mix(in srgb, var(--accent-color) 16%, transparent), transparent 58%),
                var(--settings-card-bg);
            box-shadow: 0 12px 32px rgba(0, 0, 0, .14);
        }
        .nm-group > .form-label { font-size: 16px; }
        .nm-group .nm-hint-top { margin-bottom: 16px; }
        .account-form { display: grid; gap: 14px; max-width: 520px; }
        .account-form .form-group { margin: 0; }
        .account-form .save-button { justify-self: start; }
        .account-form .form-input { width: 100%; max-width: none; }
        .account-form-card { overflow: hidden; }
        .nm-styles .nav-option { font-family: inherit; }
        .nm-preview {
            position: relative;
            max-width: 420px;
            height: 84px;
            margin-bottom: 4px;
            border: 1px solid var(--border-light);
            border-radius: 16px;
            overflow: hidden;
            background:
                radial-gradient(120% 90% at 50% 130%, color-mix(in srgb, var(--pv-accent, #ff2a4a) 28%, transparent), transparent 62%),
                var(--bg-input);
        }
        .nm-pv-nav {
            position: absolute; left: 10px; right: 10px; bottom: 10px;
            display: flex; align-items: center; justify-content: center; gap: 2px;
            padding: 0 8px; height: 52px; border-radius: 22px; overflow: hidden;
            background: linear-gradient(180deg, rgba(38, 28, 38, .86), rgba(15, 11, 18, .94));
            border: 1px solid rgba(255, 255, 255, .1);
            box-shadow: 0 8px 22px rgba(0, 0, 0, .4);
        }
        .nm-pv-item {
            position: relative; flex: none; display: flex; align-items: center; justify-content: center; gap: 6px;
            height: 38px; min-width: 38px; padding: 0 9px; border-radius: 19px;
            color: rgba(255, 255, 255, .6); font-size: 11px; font-weight: 700; white-space: nowrap;
        }
        .nm-pv-item img, .nm-pv-item svg { width: 19px; height: 19px; display: block; }
        .nm-pv-item.is-on { color: #fff; }
        .nm-pv-item.is-on img, .nm-pv-item.is-on svg { filter: drop-shadow(0 0 5px var(--pv-accent)); }
        .nm-pv-nav[data-s="dock"] .nm-pv-item.is-on {
            background: linear-gradient(135deg, color-mix(in srgb, var(--pv-accent) 42%, transparent), color-mix(in srgb, var(--pv-accent) 14%, transparent));
            box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--pv-accent) 60%, transparent), 0 0 14px -2px color-mix(in srgb, var(--pv-accent) 60%, transparent);
        }
        .nm-pv-nav[data-s="dock"] .nm-pv-item span { display: none; }
        .nm-pv-nav[data-s="dock"] .nm-pv-item.is-on span { display: inline; }
        .nm-pv-nav[data-s="labels"] { height: 56px; }
        .nm-pv-nav[data-s="labels"] .nm-pv-item { flex-direction: column; gap: 2px; height: 44px; min-width: 48px; border-radius: 12px; font-size: 9px; font-weight: 500; }
        .nm-pv-nav[data-s="labels"] .nm-pv-item.is-on { background: color-mix(in srgb, var(--pv-accent) 18%, transparent); }
        .nm-pv-nav[data-s="labels"] .nm-pv-item.is-on::after {
            content: ''; position: absolute; top: 0; left: 22%; right: 22%; height: 3px; border-radius: 0 0 4px 4px;
            background: var(--pv-accent); box-shadow: 0 0 8px 1px var(--pv-accent);
        }
        .nm-pv-nav[data-s="compact"] { height: 44px; border-radius: 18px; }
        .nm-pv-nav[data-s="compact"] .nm-pv-item { height: 36px; min-width: 38px; border-radius: 12px; }
        .nm-pv-nav[data-s="compact"] .nm-pv-item span { display: none; }
        .nm-pv-nav[data-s="compact"] .nm-pv-item.is-on::after {
            content: ''; position: absolute; bottom: 2px; left: 50%; width: 14px; height: 3px; margin-left: -7px; border-radius: 3px;
            background: var(--pv-accent); box-shadow: 0 0 7px 1px var(--pv-accent);
        }

        .nm-swatches { display: flex; flex-wrap: wrap; gap: 12px; }
        .nm-swatch {
            width: 38px; height: 38px; padding: 0; border-radius: 50%; cursor: pointer;
            border: 2px solid var(--border-light);
            background: var(--sw, #ff2a4a);
            box-shadow: inset 0 0 0 3px var(--bg-card, rgba(0, 0, 0, .35));
            transition: transform .15s, box-shadow .2s, border-color .2s;
        }
        .nm-swatch:hover { transform: scale(1.08); }
        .nm-swatch[aria-checked="true"] { border-color: var(--sw); box-shadow: inset 0 0 0 3px var(--bg-card, rgba(0, 0, 0, .35)), 0 0 14px 1px var(--sw); }
        .nm-swatch:focus-visible { outline: 2px solid var(--accent-color); outline-offset: 3px; }
        .nm-swatch-red    { --sw: #ff2a4a; }
        .nm-swatch-blue   { --sw: #4f8cff; }
        .nm-swatch-violet { --sw: #9b5cff; }
        .nm-swatch-green  { --sw: #2fd47a; }
        .nm-swatch-gold   { --sw: #ffb020; }
        .nm-swatch-site   { --sw: var(--accent-color); }
        .nm-swatch-l1 { --sw: #80ffe8; }
        .nm-swatch-l2 { --sw: #80ffd9; }
        .nm-swatch-l3 { --sw: #80d0ff; }
        .nm-swatch-l4 { --sw: #dab4ff; }
        .nm-swatch-l5 { --sw: #ff80d4; }
        .nm-swatch-l6 { --sw: #f4ff80; }
        .nm-swatch-l7 { --sw: #ffcc80; }
        .nm-swatch-l8 { --sw: #fecdb0; }
        .nm-swatch-l9 { --sw: #c4c4c4; }
        .nm-swatch-l10 { --sw: #b8bec4; }
        .nm-swatch-d1 { --sw: #009479; }
        .nm-swatch-d2 { --sw: #009468; }
        .nm-swatch-d3 { --sw: #005e94; }
        .nm-swatch-d4 { --sw: #683d94; }
        .nm-swatch-d5 { --sw: #940063; }
        .nm-swatch-d6 { --sw: #889400; }
        .nm-swatch-d7 { --sw: #945900; }
        .nm-swatch-d8 { --sw: #925a39; }
        .nm-swatch-d9 { --sw: #505050; }
        .nm-swatch-d10 { --sw: #424950; }
        .nm-swatches-extra { margin-top: 12px; }
        /* кружок «+» — добавить свой цвет */
        .nm-swatch-add {
            position: relative; display: block; flex: none;
            background: transparent; border: 2px dashed var(--border-light);
            box-shadow: none; color: var(--text-secondary);
            transition: transform .15s, border-color .2s, color .2s;
        }
        .nm-swatch-add::before, .nm-swatch-add::after {
            content: ''; position: absolute; left: 50%; top: 50%; border-radius: 2px;
            background: currentColor; transform: translate(-50%, -50%);
        }
        .nm-swatch-add::before { width: 14px; height: 2px; }
        .nm-swatch-add::after  { width: 2px; height: 14px; }
        .nm-swatch-add:hover, .nm-swatch-add[aria-expanded="true"] { border-color: var(--accent-color); color: var(--text-primary); }
        /* сохранённые свои цвета */
        .nm-saved-list { display: contents; }
        .nm-saved { position: relative; display: inline-flex; }
        .nm-saved .nm-swatch { background: var(--sw); }
        .nm-saved-del {
            position: absolute; top: -5px; right: -5px; width: 18px; height: 18px; padding: 0;
            display: flex; align-items: center; justify-content: center; border-radius: 50%; cursor: pointer;
            border: 1px solid var(--border-light); background: var(--bg-card); color: var(--text-secondary);
            opacity: 0; transform: scale(.8); transition: opacity .15s, transform .15s, color .15s;
        }
        .nm-saved-del svg { width: 9px; height: 9px; display: block; }
        .nm-saved:hover .nm-saved-del, .nm-saved:focus-within .nm-saved-del { opacity: 1; transform: none; }
        .nm-saved-del:hover { color: var(--danger-color, #ed4245); }
        @media (hover: none) { .nm-saved-del { opacity: 1; transform: none; } }
        .nm-pop-add {
            width: 100%; margin-top: 14px; height: 36px; border: 0; border-radius: 10px; cursor: pointer;
            background: var(--accent-color); color: #fff; font: inherit; font-size: 13px; font-weight: 600;
            transition: filter .15s;
        }
        .nm-pop-add:hover { filter: brightness(1.1); }
        .nm-pop-add:disabled { opacity: .55; cursor: default; filter: none; }
        .nm-autohide-row { margin-top: 20px; }

        /* ===== Своё мини-окно палитры (вместо системного выбора цвета) ===== */
        .nm-pop {
            position: fixed; z-index: 10000; left: 0; top: 0;
            width: 264px; max-width: calc(100vw - 16px);
            padding: 12px; border-radius: 16px;
            background: var(--bg-card); color: var(--text-primary);
            border: 1px solid var(--border-light);
            box-shadow: 0 18px 44px rgba(0, 0, 0, .42), 0 2px 6px rgba(0, 0, 0, .2);
            opacity: 0; transform: translateY(-4px) scale(.98); visibility: hidden; pointer-events: none;
            transition: opacity .14s ease, transform .14s ease, visibility 0s linear .14s;
            user-select: none; -webkit-user-select: none;
        }
        .nm-pop.is-open { opacity: 1; transform: none; visibility: visible; pointer-events: auto; transition-delay: 0s; }
        .nm-pop-sv {
            position: relative; height: 150px; border-radius: 10px; cursor: crosshair;
            touch-action: none; overflow: visible;
            box-shadow: inset 0 0 0 1px rgba(128, 132, 142, .35);
        }
        .nm-pop-knob {
            position: absolute; width: 16px; height: 16px; margin: -8px 0 0 -8px; border-radius: 50%;
            border: 2px solid #fff; box-shadow: 0 0 0 1px rgba(0, 0, 0, .45), 0 2px 5px rgba(0, 0, 0, .4);
            pointer-events: none;
        }
        .nm-pop-mid { display: flex; align-items: center; gap: 12px; margin-top: 14px; }
        .nm-pop-eye {
            flex: none; width: 34px; height: 34px; padding: 0; border-radius: 10px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            border: 1px solid var(--border-light); background: transparent; color: var(--text-secondary);
            transition: border-color .15s, color .15s;
        }
        .nm-pop-eye:hover { border-color: var(--accent-color); color: var(--text-primary); }
        .nm-pop-eye svg { width: 18px; height: 18px; }
        .nm-pop-dot {
            flex: none; width: 34px; height: 34px; border-radius: 50%;
            box-shadow: inset 0 0 0 1px rgba(128, 132, 142, .45);
        }
        .nm-pop-hue {
            position: relative; flex: 1; height: 12px; border-radius: 999px; cursor: pointer; touch-action: none;
            background: linear-gradient(to right, #f00 0%, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);
        }
        .nm-pop-hue .nm-pop-knob { top: 50%; }
        .nm-pop-fields { display: grid; grid-template-columns: 1.7fr 1fr 1fr 1fr; gap: 6px; margin-top: 14px; }
        .nm-pop-field { display: flex; flex-direction: column; align-items: center; gap: 5px; min-width: 0; }
        .nm-pop-field input {
            width: 100%; height: 32px; padding: 0 4px; text-align: center; outline: none;
            border: 1px solid var(--border-light); border-radius: 8px;
            background: var(--bg-input); color: var(--text-primary);
            font: inherit; font-size: 13px; -moz-appearance: textfield; appearance: textfield;
        }
        .nm-pop-field input::-webkit-outer-spin-button,
        .nm-pop-field input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
        .nm-pop-field input:focus { border-color: var(--accent-color); box-shadow: 0 0 0 3px rgba(88, 101, 242, .25); }
        .nm-pop-field span { color: var(--text-secondary); font-size: 11px; font-weight: 700; letter-spacing: .4px; }
        @media (prefers-reduced-motion: reduce) { .nm-pop { transition: none; } }

        .nm-items { display: flex; flex-direction: column; gap: 8px; max-width: 560px; }
        .nm-row {
            display: flex; align-items: center; gap: 12px; padding: 8px 10px 8px 14px;
            border: 1px solid var(--border-light); border-radius: 14px; background: var(--bg-input);
            transition: opacity .2s, border-color .2s;
        }
        .nm-row.is-off { opacity: .5; }
        .nm-row-icon { flex: none; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; color: var(--text-primary); }
        .nm-row-icon img, .nm-row-icon svg { width: 22px; height: 22px; display: block; }
        .nm-row-name { flex: 1; min-width: 0; color: var(--text-primary); font-size: 14px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .nm-move { display: flex; gap: 4px; }
        .nm-move button {
            width: 34px; height: 34px; padding: 0; border-radius: 10px; cursor: pointer;
            border: 1px solid var(--border-light); background: transparent; color: var(--text-secondary);
            display: flex; align-items: center; justify-content: center; transition: border-color .15s, color .15s, opacity .15s;
        }
        .nm-move button:hover:not(:disabled) { border-color: var(--accent-color); color: var(--text-primary); }
        .nm-move button:disabled { opacity: .3; cursor: default; }
        .nm-move svg { width: 16px; height: 16px; }
        .nm-row .nm-tgl { position: relative; flex: none; display: flex; cursor: pointer; }
        .nm-row .nm-tgl .switch-ui { width: 44px; height: 26px; }
        .nm-row .nm-tgl .switch-ui::after { width: 20px; height: 20px; }
        .nm-row .nm-tgl .switch-input:checked + .switch-ui::after { transform: translateX(18px); }
        .nm-reset {
            margin-top: 18px; padding: 10px 16px; border-radius: 12px; cursor: pointer;
            border: 1px solid var(--border-light); background: transparent; color: var(--text-secondary);
            font: inherit; font-size: 13px; font-weight: 600; transition: border-color .15s, color .15s;
        }
        .nm-reset:hover { border-color: var(--accent-color); color: var(--text-primary); }

        /* Редактор панели на телефоне */
        @media (max-width: 640px) {
            .nm-group { margin-top: 20px; padding: 16px; border-radius: 16px; }
            .nm-group > .form-label { font-size: 15px; }
            .nm-sub { margin: 18px 0 8px; }
            .nm-preview { max-width: none; }
            .nm-pv-nav { left: 6px; right: 6px; padding: 0 4px; }
            .nm-pv-nav[data-s="labels"] .nm-pv-item { min-width: 44px; padding: 0 6px; }
            .nm-styles { gap: 8px; }
            .nm-styles .nav-option { padding: 12px 6px 10px; font-size: 12px; text-align: center; }
            .nm-swatch { width: 40px; height: 40px; }
            .nm-autohide-row { display: none; }   /* на телефоне панель всегда на виду */
            .nm-items { max-width: none; gap: 6px; }
            .nm-row { gap: 8px; padding: 6px 8px 6px 12px; }
            .nm-row-name { font-size: 13px; }
            .nm-move button { width: 36px; height: 36px; }
            .nm-reset { width: 100%; }
        }
        @media (max-width: 360px) {
            .nm-pv-item:nth-child(n+5) { display: none; }
        }

        /* ===== Переключатель «Закрепить панель»: шарик вправо — включено, влево — выключено ===== */
        .switch-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            max-width: 560px;
            padding: 14px 16px;
            border: 1px solid var(--border-light);
            border-radius: 14px;
            background: var(--bg-input);
            cursor: pointer;
            user-select: none;
            transition: border-color 0.18s ease, background 0.18s ease;
        }
        .switch-row:hover { border-color: var(--accent-color); }
        .switch-text { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
        .switch-title { color: var(--text-primary); font-size: 14px; font-weight: 700; }
        .switch-desc { color: var(--text-secondary); font-size: 12px; line-height: 1.5; }

        .switch-input { position: absolute; opacity: 0; width: 1px; height: 1px; pointer-events: none; }

        .switch-ui {
            position: relative;
            flex: none;
            width: 52px;
            height: 30px;
            border-radius: 999px;
            background: var(--text-muted, #6d6f78);
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.35);
            transition: background 0.25s ease, box-shadow 0.25s ease;
        }
        .switch-ui::after {
            content: '';
            position: absolute;
            top: 3px;
            left: 3px;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
            transition: transform 0.25s cubic-bezier(0.3, 1.4, 0.5, 1);
        }
        .switch-input:checked + .switch-ui {
            background: var(--accent-color);
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.2);
        }
        .switch-input:checked + .switch-ui::after { transform: translateX(22px); }
        .switch-input:focus-visible + .switch-ui { outline: 2px solid var(--accent-color); outline-offset: 3px; }

        @media (max-width: 640px) {
            .nav-picker { grid-template-columns: repeat(3, minmax(0, 1fr)); max-width: none; }
            .page-title { font-size: 26px; }
            .email-change-card { display: none !important; }
            .account-form .save-button { width: 100%; }
        }

        /* Нижняя навигация и bottom-handle стилизуются из assets/css/index.css — как в index.php */

        @media (max-width: 1200px) {
            .layout { width: min(100% - 24px, 900px); }
            .header { padding-left: 16px; padding-right: 16px; }
        }

        @media (max-width: 640px) {
            .layout { width: calc(100% - 16px); margin-top: 12px !important; }
            .page-title { font-size: 24px; }
            .settings-grid { grid-template-columns: 1fr; gap: 16px; }
            .card-title { padding: 18px 18px 4px; }
            .card-subtitle { padding: 0 18px 16px; }
            .settings-body { padding: 16px 18px 20px; }
            .form-select, .form-input { max-width: none; }
            .settings-actions { flex-direction: column; align-items: stretch; }
            .settings-actions .save-button, .settings-actions .zone-action-button,
            .settings-actions .danger-button { width: 100%; }
            .dz-row { grid-template-columns: auto minmax(0, 1fr); padding: 14px; gap: 12px 14px; }
            .dz-row .dz-btn { grid-column: 1 / -1; width: 100%; }
            .dz-ico { width: 40px; height: 40px; }
            .dz-help { flex-direction: column; align-items: stretch; }
            .dz-help .zone-action-button { width: 100%; }
            .twofa-code-form, .twofa-action-details .twofa-code-form { max-width: none; }
        }

        /* ===== Выбор языка с флагами ===== */
        .lang-picker { position: relative; max-width: 340px; }
        .lang-picker .lang-trigger {
            display: flex; align-items: center; gap: 12px; max-width: none;
            text-align: left; cursor: pointer;
        }
        .lang-flag {
            flex: none; width: 24px; height: 16px; border-radius: 3px;
            box-shadow: 0 0 0 1px rgba(128, 132, 142, .45);
        }
        .lang-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .lang-chev { flex: none; width: 12px; height: 8px; color: var(--text-secondary); transition: transform .18s ease; }
        .lang-trigger[aria-expanded="true"] { border-color: var(--accent-color); }
        .lang-trigger[aria-expanded="true"] .lang-chev { transform: rotate(180deg); }
        .lang-menu {
            position: absolute; z-index: 30; left: 0; right: 0; top: calc(100% + 6px);
            margin: 0; padding: 4px; list-style: none; outline: none;
            background: var(--bg-card); border: 1px solid var(--border-light); border-radius: 12px;
            box-shadow: 0 14px 34px rgba(0, 0, 0, .35);
            opacity: 0; transform: translateY(-4px); visibility: hidden; pointer-events: none;
            transition: opacity .14s ease, transform .14s ease, visibility 0s linear .14s;
        }
        .lang-menu.is-open { opacity: 1; transform: none; visibility: visible; pointer-events: auto; transition-delay: 0s; }
        .lang-option {
            display: flex; align-items: center; gap: 12px; height: 40px; padding: 0 12px;
            border-radius: 8px; color: var(--text-primary); font-size: 14px; cursor: pointer;
        }
        .lang-option:hover, .lang-option.is-active { background: var(--bg-hover, rgba(128, 132, 142, .16)); }
        .lang-option .lang-check { flex: none; width: 16px; height: 16px; color: var(--accent-color); visibility: hidden; }
        .lang-option[aria-selected="true"] { font-weight: 600; }
        .lang-option[aria-selected="true"] .lang-check { visibility: visible; }
        @media (prefers-reduced-motion: reduce) { .lang-menu, .lang-chev { transition: none; } }

        /* Панель слева: закрепление включено всегда */
        .switch-row.is-locked { cursor: not-allowed; }
        .switch-row.is-locked:hover { border-color: inherit; }
        .switch-row.is-locked .switch-ui { opacity: .55; }

        /* ===== Карточки настроек — по ширине панели навигации (90% окна, до 1200px) ===== */
        @media (min-width: 769px) {
            body[data-nav-pos="top"] .layout,
            body[data-nav-pos="bottom"] .layout { width: min(90%, 1200px); max-width: 1200px; }
        }
        @media (min-width: 641px) and (max-width: 768px) {
            body[data-nav-pos="top"] .layout,
            body[data-nav-pos="bottom"] .layout { width: calc(100% - 24px); max-width: 1200px; }
        }
        @media (min-width: 641px) {
            body[data-nav-pos="top"] .settings-container,
            body[data-nav-pos="bottom"] .settings-container { max-width: none; }

            /* поля подгоняем под новую ширину: тянутся на всю колонку, а не обрываются на 340px */
            body[data-nav-pos="top"] .form-select, body[data-nav-pos="top"] .form-input,
            body[data-nav-pos="bottom"] .form-select, body[data-nav-pos="bottom"] .form-input,
            body[data-nav-pos="top"] .lang-picker, body[data-nav-pos="bottom"] .lang-picker,
            body[data-nav-pos="top"] .switch-row, body[data-nav-pos="bottom"] .switch-row { max-width: none; }
        }
    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>" data-nav-pos="<?= htmlspecialchars($nav_pos, ENT_QUOTES, 'UTF-8') ?>" data-nav-pin="<?= $nav_pin ? '1' : '0' ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main>

            <div class="settings-container">

                <div class="page-title">
                    <?= $t['settings'] ?>
                </div>

                <?php if ($message !== ""): ?>
                    <div class="success"><?= htmlspecialchars($message) ?></div>
                <?php endif; ?>

                <?php if ($error !== ""): ?>
                    <div class="error"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <!-- ОБЩИЕ НАСТРОЙКИ -->
                <div class="settings-card">
                    <div class="card-title"><?= $t['general'] ?></div>
                    <div class="card-subtitle">Настройки внешнего вида и языка</div>
                    <div class="settings-body">
                        <form method="POST" action="">
                            <div class="settings-grid">
                                <div class="form-group">
                                    <label class="form-label" for="langTrigger"><?= $t['language'] ?></label>
                                    <div class="lang-picker" id="langPicker">
                                        <!-- Флаги: Россия и Великобритания (английский) -->
                                        <svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
                                            <defs>
                                                <clipPath id="ukClipS"><path d="M0,0 v40 h60 v-40 z"/></clipPath>
                                                <clipPath id="ukClipT"><path d="M30,20 h30 v20 z v20 h-30 z h-30 v-20 z v-20 h30 z"/></clipPath>
                                            </defs>
                                            <symbol id="flag-ru" viewBox="0 0 30 20">
                                                <rect width="30" height="20" fill="#fff"/>
                                                <rect y="6.67" width="30" height="6.67" fill="#0039A6"/>
                                                <rect y="13.33" width="30" height="6.67" fill="#D52B1E"/>
                                            </symbol>
                                            <symbol id="flag-en" viewBox="0 0 60 40">
                                                <rect width="60" height="40" fill="#012169"/>
                                                <g clip-path="url(#ukClipS)">
                                                    <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
                                                    <path d="M0,0 L60,40 M60,0 L0,40" clip-path="url(#ukClipT)" stroke="#C8102E" stroke-width="4.5"/>
                                                    <path d="M30,0 v40 M0,20 h60" stroke="#fff" stroke-width="13"/>
                                                    <path d="M30,0 v40 M0,20 h60" stroke="#C8102E" stroke-width="7.5"/>
                                                </g>
                                            </symbol>
                                        </svg>
                                        <input type="hidden" name="lang" id="langInput" value="<?= $lang ?>">
                                        <button type="button" class="form-select lang-trigger" id="langTrigger"
                                                aria-haspopup="listbox" aria-expanded="false" aria-controls="langMenu">
                                            <svg class="lang-flag" aria-hidden="true"><use href="#flag-<?= $lang ?>"/></svg>
                                            <span class="lang-name"><?= $lang === 'en' ? $t['english'] : $t['russian'] ?></span>
                                            <svg class="lang-chev" viewBox="0 0 12 8" aria-hidden="true"><path d="M1 1.5l5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                        </button>
                                        <ul class="lang-menu" id="langMenu" role="listbox" tabindex="-1" aria-labelledby="langTrigger">
                                            <li class="lang-option" role="option" data-value="ru" aria-selected="<?= $lang === 'ru' ? 'true' : 'false' ?>">
                                                <svg class="lang-flag" aria-hidden="true"><use href="#flag-ru"/></svg>
                                                <span class="lang-name"><?= $t['russian'] ?></span>
                                                <svg class="lang-check" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                            </li>
                                            <li class="lang-option" role="option" data-value="en" aria-selected="<?= $lang === 'en' ? 'true' : 'false' ?>">
                                                <svg class="lang-flag" aria-hidden="true"><use href="#flag-en"/></svg>
                                                <span class="lang-name"><?= $t['english'] ?></span>
                                                <svg class="lang-check" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="form-group nav-group">
                                    <label class="form-label"><?= $t['nav_position'] ?></label>
                                    <div class="nav-picker" role="radiogroup" aria-label="<?= htmlspecialchars($t['nav_position'], ENT_QUOTES, 'UTF-8') ?>">
                                        <?php
                                        // Положение «панели» на миниатюре: x, y, ширина, высота
                                        $nav_previews = [
                                            'bottom' => [8, 37, 48, 6],
                                            'top'    => [8, 5, 48, 6],
                                            'left'   => [5, 9, 7, 30],
                                        ];
                                        foreach ($nav_previews as $val => $r):
                                        ?>
                                            <label class="nav-option<?= $nav_pos === $val ? ' is-active' : '' ?><?= $val !== 'bottom' ? ' nav-option-pc' : '' ?>">
                                                <input type="radio" name="nav_pos" value="<?= $val ?>" <?= $nav_pos === $val ? 'checked' : '' ?> onchange="this.closest('.nav-picker').querySelectorAll('.nav-option').forEach(function (o) { o.classList.toggle('is-active', o.contains(this)); }, this); this.form.submit()">
                                                <svg viewBox="0 0 64 48" width="64" height="48" fill="none" aria-hidden="true">
                                                    <rect x="1" y="1" width="62" height="46" rx="6" stroke="currentColor" stroke-opacity=".45" stroke-width="2"/>
                                                    <rect x="17" y="15" width="30" height="4" rx="2" fill="currentColor" opacity=".22"/>
                                                    <rect x="17" y="22" width="22" height="4" rx="2" fill="currentColor" opacity=".22"/>
                                                    <rect x="17" y="29" width="26" height="4" rx="2" fill="currentColor" opacity=".22"/>
                                                    <rect x="<?= $r[0] ?>" y="<?= $r[1] ?>" width="<?= $r[2] ?>" height="<?= $r[3] ?>" rx="3" fill="#5865f2"/>
                                                </svg>
                                                <span><?= $t['nav_' . $val] ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="nav-hint"><?= $t['nav_position_hint'] ?></div>
                                </div>

                                <div class="form-group nav-group">
                                    <input type="hidden" name="nav_pin_submitted" value="1">
                                    <?php $pin_locked = ($nav_pos === 'left'); ?>
                                    <label class="switch-row<?= $pin_locked ? ' is-locked' : '' ?>">
                                        <span class="switch-text">
                                            <span class="switch-title"><?= $t['nav_pin'] ?></span>
                                            <span class="switch-desc"><?= $pin_locked ? $t['nav_pin_locked'] : $t['nav_pin_hint'] ?></span>
                                        </span>
                                        <input type="checkbox" name="nav_pin" value="1" class="switch-input" role="switch" <?= $nav_pin ? 'checked' : '' ?> <?= $pin_locked ? 'disabled aria-disabled="true"' : '' ?> onchange="this.form.submit()">
                                        <span class="switch-ui" aria-hidden="true"></span>
                                    </label>
                                </div>

                                <div class="form-group nav-group nm-group" id="nmGroup">
                                    <label class="form-label"><?= $t['nm_title'] ?></label>
                                    <div class="nav-hint nm-hint-top"><?= $t['nm_hint'] ?></div>

                                    <div class="nm-preview" id="nmPreview" aria-hidden="true"></div>

                                    <div class="nm-sub"><?= $t['nm_style'] ?></div>
                                    <div class="nav-picker nm-styles" id="nmStyles" role="radiogroup" aria-label="<?= htmlspecialchars($t['nm_style'], ENT_QUOTES, 'UTF-8') ?>">
                                        <?php foreach (['dock', 'labels', 'compact'] as $nm_s): ?>
                                            <button type="button" class="nav-option" role="radio" aria-checked="false" data-style="<?= $nm_s ?>">
                                                <svg viewBox="0 0 64 36" width="64" height="36" fill="none" aria-hidden="true">
                                                    <rect x="1" y="1" width="62" height="34" rx="6" stroke="currentColor" stroke-opacity=".4" stroke-width="2"/>
                                                    <?php if ($nm_s === 'dock'): ?>
                                                        <rect x="8" y="23" width="48" height="8" rx="4" fill="currentColor" opacity=".22"/>
                                                        <rect x="25" y="24.5" width="17" height="5" rx="2.5" fill="#ff2a4a"/>
                                                    <?php elseif ($nm_s === 'labels'): ?>
                                                        <rect x="6" y="21" width="52" height="11" rx="4" fill="currentColor" opacity=".22"/>
                                                        <rect x="24" y="21" width="16" height="2" rx="1" fill="#ff2a4a"/>
                                                    <?php else: ?>
                                                        <rect x="12" y="25" width="40" height="6" rx="3" fill="currentColor" opacity=".22"/>
                                                        <rect x="29" y="29" width="6" height="2" rx="1" fill="#ff2a4a"/>
                                                    <?php endif; ?>
                                                </svg>
                                                <span><?= $t['nm_' . $nm_s] ?></span>
                                            </button>
                                        <?php endforeach; ?>
                                    </div>

                                    <div class="nm-sub"><?= $t['nm_accent'] ?></div>
                                    <div class="nm-swatches" id="nmAccents" role="radiogroup" aria-label="<?= htmlspecialchars($t['nm_accent'], ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="button" class="nm-swatch nm-swatch-site" role="radio" aria-checked="false" data-accent="site" title="<?= htmlspecialchars($t['nm_c_site'], ENT_QUOTES, 'UTF-8') ?>" aria-label="<?= htmlspecialchars($t['nm_c_site'], ENT_QUOTES, 'UTF-8') ?>"></button>
                                        <span class="nm-saved-list" id="nmSaved"></span>
                                        <button type="button" class="nm-swatch nm-swatch-add" id="nmCustomSwatch" aria-haspopup="dialog" aria-expanded="false" data-eyedropper="<?= htmlspecialchars($t['nm_eyedropper'], ENT_QUOTES, 'UTF-8') ?>" data-save="<?= htmlspecialchars($t['nm_save_color'], ENT_QUOTES, 'UTF-8') ?>" data-saved-label="<?= htmlspecialchars($t['nm_color_saved'], ENT_QUOTES, 'UTF-8') ?>" data-remove="<?= htmlspecialchars($t['nm_color_remove'], ENT_QUOTES, 'UTF-8') ?>" title="<?= htmlspecialchars($t['nm_c_custom'], ENT_QUOTES, 'UTF-8') ?>" aria-label="<?= htmlspecialchars($t['nm_c_custom'], ENT_QUOTES, 'UTF-8') ?>"></button>
                                        <input type="hidden" id="nmCustomColor" value="#ff2a4a">
                                    </div>

                                    <div class="nm-swatches nm-swatches-extra" id="nmAccentsLight" role="radiogroup" aria-label="<?= htmlspecialchars($t['nm_accent'], ENT_QUOTES, 'UTF-8') ?>">
                                        <?php foreach (['#80ffe8', '#80ffd9', '#80d0ff', '#dab4ff', '#ff80d4', '#f4ff80', '#ffcc80', '#fecdb0', '#c4c4c4', '#b8bec4'] as $nm_i => $nm_hex): ?>
                                            <button type="button" class="nm-swatch nm-swatch-l<?= $nm_i + 1 ?>" role="radio" aria-checked="false" data-hex="<?= $nm_hex ?>"></button>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="nm-swatches nm-swatches-extra" id="nmAccentsDark" role="radiogroup" aria-label="<?= htmlspecialchars($t['nm_accent'], ENT_QUOTES, 'UTF-8') ?>">
                                        <?php foreach (['#009479', '#009468', '#005e94', '#683d94', '#940063', '#889400', '#945900', '#925a39', '#505050', '#424950'] as $nm_i => $nm_hex): ?>
                                            <button type="button" class="nm-swatch nm-swatch-d<?= $nm_i + 1 ?>" role="radio" aria-checked="false" data-hex="<?= $nm_hex ?>"></button>
                                        <?php endforeach; ?>
                                    </div>

                                    <label class="switch-row nm-autohide-row">
                                        <span class="switch-text">
                                            <span class="switch-title"><?= $t['nm_autohide'] ?></span>
                                            <span class="switch-desc"><?= $t['nm_autohide_desc'] ?></span>
                                        </span>
                                        <input type="checkbox" id="nmAutohide" class="switch-input" role="switch">
                                        <span class="switch-ui" aria-hidden="true"></span>
                                    </label>

                                    <div class="nm-sub"><?= $t['nm_items'] ?></div>
                                    <div class="nav-hint nm-hint-top"><?= $t['nm_items_hint'] ?></div>
                                    <div class="nm-items" id="nmItems" data-up="<?= htmlspecialchars($t['nm_up'], ENT_QUOTES, 'UTF-8') ?>" data-down="<?= htmlspecialchars($t['nm_down'], ENT_QUOTES, 'UTF-8') ?>"></div>

                                    <button type="button" class="nm-reset" id="nmReset"><?= $t['nm_reset'] ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- АККАУНТ -->
                <div class="settings-card">
                    <div class="card-title"><?= $t['account'] ?></div>
                    <div class="card-subtitle"><?= $t['account_info'] ?></div>
                    <div class="settings-body">
                        <div class="info-row">
                            <span><?= $t['vspace_id'] ?></span>
                            <span><?= $user_id ?></span>
                        </div>
                        <div class="info-row">
                            <span><?= $t['email'] ?></span>
                            <span><?= htmlspecialchars($email) ?></span>
                        </div>
                        <div class="info-row">
                            <span><?= $t['current_ip'] ?></span>
                            <span style="color:var(--ok-text);font-weight:600;">
                                <?= htmlspecialchars($current_ip ?: $t['ip_not_determined']) ?>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="settings-card account-form-card">
                    <div class="card-title"><?= $t['password_change'] ?></div>
                    <div class="card-subtitle"><?= $t['password_change_hint'] ?></div>
                    <div class="settings-body">
                        <form method="POST" action="settings.php" class="account-form" autocomplete="on">
                            <input type="hidden" name="action" value="update_password">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                            <div class="form-group">
                                <label class="form-label" for="passwordCurrent"><?= $t['current_password'] ?></label>
                                <input class="form-input" id="passwordCurrent" type="password" name="current_password" autocomplete="current-password" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="passwordNew"><?= $t['new_password'] ?></label>
                                <input class="form-input" id="passwordNew" type="password" name="new_password" minlength="6" autocomplete="new-password" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="passwordConfirm"><?= $t['confirm_password'] ?></label>
                                <input class="form-input" id="passwordConfirm" type="password" name="confirm_password" minlength="6" autocomplete="new-password" required>
                            </div>
                            <button type="submit" class="save-button"><?= $t['save_password'] ?></button>
                        </form>
                    </div>
                </div>

                <div class="settings-card account-form-card email-change-card">
                    <div class="card-title"><?= $t['email_change'] ?></div>
                    <div class="card-subtitle"><?= $t['email_change_hint'] ?></div>
                    <div class="settings-body">
                        <form method="POST" action="settings.php" class="account-form" autocomplete="on">
                            <input type="hidden" name="action" value="update_email">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                            <div class="form-group">
                                <label class="form-label" for="emailCurrentPassword"><?= $t['current_password'] ?></label>
                                <input class="form-input" id="emailCurrentPassword" type="password" name="current_password" autocomplete="current-password" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="emailNew"><?= $t['new_email'] ?></label>
                                <input class="form-input" id="emailNew" type="email" name="new_email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" autocomplete="email" required>
                            </div>
                            <button type="submit" class="save-button"><?= $t['save_email'] ?></button>
                        </form>
                    </div>
                </div>

                <!-- ВЕРИФИКАЦИЯ: галочка выдаётся, если подключена 2FA -->
                <div class="settings-card">
                    <div class="card-title"><?= $t['verification_title'] ?></div>
                    <div class="card-subtitle"><?= $t['verification_subtitle'] ?></div>
                    <div class="settings-body">
                        <?php if ($totp_enabled): ?>
                            <div class="verify-status is-ok">
                                <img src="images/verified.svg" alt="" width="32" height="33">
                                <span class="verify-text"><?= $t['verified_text'] ?></span>
                            </div>
                        <?php else: ?>
                            <div class="verify-status">
                                <span class="verify-text"><?= $t['not_verified_text'] ?></span>
                            </div>
                            <p class="verify-hint"><?= $t['not_verified_hint'] ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ДВУХФАКТОРНАЯ АУТЕНТИФИКАЦИЯ (2FA) -->
                <div class="settings-card">
                    <div class="card-title">
                        <svg class="s-ico" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;vertical-align:-0.2em;width:20px;height:20px;fill:none;stroke:currentColor;"><path d="M12 3l7 3v5.5c0 4.4-2.9 8.2-7 9.5-4.1-1.3-7-5.1-7-9.5V6z"/><path d="M9 12l2.2 2.2L15.5 10"/></svg> <?= $t['2fa_title'] ?>
                        <?php if ($totp_enabled): ?>
                            <span class="ip-badge" style="background:var(--ok-badge-bg);color:var(--ok-badge-text);"><?= $t['2fa_enabled_badge'] ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="card-subtitle"><?= $t['2fa_subtitle'] ?></div>
                    <div class="settings-body">

                        <?php if (!empty($backup_codes_to_show)): ?>
                            <div class="twofa-backup-box">
                                <div class="twofa-backup-title"><?= $t['2fa_backup_codes_title'] ?></div>
                                <div class="twofa-backup-warning"><span style="color:#faa61a;"><svg class="s-ico" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;vertical-align:-0.2em;width:14px;height:14px;fill:none;stroke:currentColor;"><path d="M12 3.5 2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17.2h.01"/></svg></span> <?= $t['2fa_backup_codes_warning'] ?></div>
                                <div class="twofa-backup-codes">
                                    <?php foreach ($backup_codes_to_show as $bcode): ?>
                                        <code><?= htmlspecialchars($bcode, ENT_QUOTES, 'UTF-8') ?></code>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($totp_enabled): ?>
                            <div class="info-row">
                                <span><?= $t['2fa_enabled_text'] ?></span>
                            </div>
                            <details class="twofa-action-details">
                                <summary><?= $t['2fa_disable_button'] ?></summary>
                                <form method="POST" action="" class="twofa-code-form">
                                    <input type="hidden" name="twofa_action" value="disable">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                    <label class="form-label"><?= $t['2fa_disable_confirm_title'] ?></label>
                                    <input type="text" name="totp_code" class="form-select" placeholder="<?= $t['2fa_code_placeholder'] ?>" autocomplete="off" required>
                                    <button type="submit" class="danger-button" style="margin-top:8px;"><?= $t['2fa_disable_button'] ?></button>
                                </form>
                            </details>
                            <details class="twofa-action-details">
                                <summary><?= $t['2fa_regen_button'] ?></summary>
                                <form method="POST" action="" class="twofa-code-form">
                                    <input type="hidden" name="twofa_action" value="regenerate_codes">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                    <label class="form-label"><?= $t['2fa_disable_confirm_title'] ?></label>
                                    <input type="text" name="totp_code" class="form-select" placeholder="<?= $t['2fa_code_placeholder'] ?>" autocomplete="off" required>
                                    <button type="submit" class="save-button" style="margin-top:8px;"><?= $t['2fa_regen_button'] ?></button>
                                </form>
                            </details>

                        <?php elseif ($twofa_setup_pending): ?>
                            <div class="info-row">
                                <span><?= $t['2fa_setup_intro'] ?></span>
                            </div>
                            <div class="twofa-setup-grid">
                                <div id="twofaQr" class="twofa-qr"></div>
                                <div class="twofa-manual">
                                    <div class="form-label"><?= $t['2fa_manual_key'] ?></div>
                                    <code class="twofa-secret"><?= htmlspecialchars($twofa_pending_secret, ENT_QUOTES, 'UTF-8') ?></code>
                                    <div style="margin-top:12px;">
                                        <a href="<?= htmlspecialchars($twofa_qr_uri, ENT_QUOTES, 'UTF-8') ?>" class="save-button" style="text-decoration:none;display:inline-flex;">
                                            <svg class="s-ico" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;vertical-align:-0.2em;width:18px;height:18px;fill:none;stroke:currentColor;"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg> <?= $t['2fa_open_app'] ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <form method="POST" action="" class="twofa-code-form">
                                <input type="hidden" name="twofa_action" value="confirm">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                <input type="text" name="totp_code" class="form-select" placeholder="<?= $t['2fa_code_placeholder'] ?>" autocomplete="off" inputmode="numeric" pattern="\d{6}" required autofocus>
                                <div class="settings-actions" style="margin-top:8px;">
                                    <button type="submit" class="save-button"><?= $t['2fa_confirm_button'] ?></button>
                                </div>
                            </form>
                            <form method="POST" action="" style="margin-top:6px;">
                                <input type="hidden" name="twofa_action" value="cancel">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                <button type="submit" class="save-button ghost"><?= $t['2fa_cancel_button'] ?></button>
                            </form>
                            <script>
                                /* QR-генератор встроен в страницу: без внешних библиотек и без отправки секрета третьим лицам */
(function (global) {
    'use strict';

    // Уровни коррекции ошибок L и M, версии 1–10 (до 271 байта) — этого с запасом
    // хватает для otpauth-ссылки. Таблицы: ECC-кодслов на блок и число блоков.
    var LEVELS = {
        M: { fmt: 0, ecc: [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26], blocks: [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5] },
        L: { fmt: 1, ecc: [0, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18], blocks: [0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4] }
    };

    function utf8Bytes(str) {
        if (typeof TextEncoder !== 'undefined') return Array.prototype.slice.call(new TextEncoder().encode(str));
        var s = unescape(encodeURIComponent(str)), out = [];
        for (var i = 0; i < s.length; i++) out.push(s.charCodeAt(i));
        return out;
    }

    function getBit(x, i) { return ((x >>> i) & 1) !== 0; }

    function rawCodewords(v) {
        var n = (16 * v + 128) * v + 64;
        if (v >= 2) {
            var a = Math.floor(v / 7) + 2;
            n -= (25 * a - 10) * a - 55;
            if (v >= 7) n -= 36;
        }
        return n >> 3;
    }

    function alignPositions(v, size) {
        if (v === 1) return [];
        var n = Math.floor(v / 7) + 2;
        var step = Math.ceil((v * 4 + 4) / (n * 2 - 2)) * 2;
        var res = [6];
        for (var p = size - 7; res.length < n; p -= step) res.splice(1, 0, p);
        return res;
    }

    // --- Рид–Соломон над GF(256), полином 0x11D ---
    function gfMul(x, y) {
        var z = 0;
        for (var i = 7; i >= 0; i--) {
            z = (z << 1) ^ ((z >>> 7) * 0x11D);
            z ^= ((y >>> i) & 1) * x;
        }
        return z;
    }

    function rsDivisor(degree) {
        var res = [], i, j;
        for (i = 0; i < degree - 1; i++) res.push(0);
        res.push(1);
        var root = 1;
        for (i = 0; i < degree; i++) {
            for (j = 0; j < res.length; j++) {
                res[j] = gfMul(res[j], root);
                if (j + 1 < res.length) res[j] ^= res[j + 1];
            }
            root = gfMul(root, 2);
        }
        return res;
    }

    function rsRemainder(data, divisor) {
        var res = divisor.map(function () { return 0; });
        data.forEach(function (b) {
            var factor = b ^ res.shift();
            res.push(0);
            divisor.forEach(function (coef, i) { res[i] ^= gfMul(coef, factor); });
        });
        return res;
    }

    // --- Основная функция: текст -> матрица true/false ---
    function encode(text) {
        var data = utf8Bytes(text), lvl, ver, dataCw, ok = false;
        var order = ['M', 'L'];
        for (var li = 0; li < order.length && !ok; li++) {
            lvl = LEVELS[order[li]];
            for (ver = 1; ver <= 10; ver++) {
                dataCw = rawCodewords(ver) - lvl.ecc[ver] * lvl.blocks[ver];
                if (4 + (ver < 10 ? 8 : 16) + data.length * 8 <= dataCw * 8) { ok = true; break; }
            }
        }
        if (!ok) throw new Error('QR: text too long');

        // 1) биты данных
        var bits = [];
        function put(val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); }
        put(4, 4);                                  // режим «байты»
        put(data.length, ver < 10 ? 8 : 16);
        data.forEach(function (b) { put(b, 8); });
        var capBits = dataCw * 8;
        put(0, Math.min(4, capBits - bits.length)); // терминатор
        while (bits.length % 8) bits.push(0);
        for (var pad = 0xEC; bits.length < capBits; pad ^= 0xEC ^ 0x11) put(pad, 8);
        var cws = [], i, j, k;
        for (i = 0; i < bits.length; i += 8) {
            var byte = 0;
            for (k = 0; k < 8; k++) byte = (byte << 1) | bits[i + k];
            cws.push(byte);
        }

        // 2) блоки + коды коррекции + чередование
        var numBlocks = lvl.blocks[ver], eccLen = lvl.ecc[ver], raw = rawCodewords(ver);
        var numShort = numBlocks - raw % numBlocks, shortLen = Math.floor(raw / numBlocks);
        var blocks = [], div = rsDivisor(eccLen);
        for (i = 0, k = 0; i < numBlocks; i++) {
            var dat = cws.slice(k, k + shortLen - eccLen + (i < numShort ? 0 : 1));
            k += dat.length;
            var ecc = rsRemainder(dat, div);
            if (i < numShort) dat.push(0);
            blocks.push(dat.concat(ecc));
        }
        var all = [];
        for (i = 0; i < blocks[0].length; i++) {
            for (j = 0; j < blocks.length; j++) {
                if (i !== shortLen - eccLen || j >= numShort) all.push(blocks[j][i]);
            }
        }

        // 3) матрица
        var size = ver * 4 + 17, modules = [], isFn = [];
        for (i = 0; i < size; i++) {
            modules.push(new Array(size).fill(false));
            isFn.push(new Array(size).fill(false));
        }
        function setFn(x, y, dark) { modules[y][x] = dark; isFn[y][x] = true; }

        function drawFormat(mask) {
            var d = (lvl.fmt << 3) | mask, rem = d, n;
            for (n = 0; n < 10; n++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
            var f = ((d << 10) | rem) ^ 0x5412;
            for (n = 0; n <= 5; n++) setFn(8, n, getBit(f, n));
            setFn(8, 7, getBit(f, 6));
            setFn(8, 8, getBit(f, 7));
            setFn(7, 8, getBit(f, 8));
            for (n = 9; n < 15; n++) setFn(14 - n, 8, getBit(f, n));
            for (n = 0; n < 8; n++) setFn(size - 1 - n, 8, getBit(f, n));
            for (n = 8; n < 15; n++) setFn(8, size - 15 + n, getBit(f, n));
            setFn(8, size - 8, true);
        }

        function drawFinder(cx, cy) {
            for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
                var dist = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy;
                if (xx >= 0 && xx < size && yy >= 0 && yy < size) setFn(xx, yy, dist !== 2 && dist !== 4);
            }
        }

        function drawAlign(cx, cy) {
            for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) {
                setFn(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
            }
        }

        for (i = 0; i < size; i++) { setFn(6, i, i % 2 === 0); setFn(i, 6, i % 2 === 0); }
        drawFinder(3, 3); drawFinder(size - 4, 3); drawFinder(3, size - 4);
        var ap = alignPositions(ver, size), na = ap.length;
        for (i = 0; i < na; i++) for (j = 0; j < na; j++) {
            if (!((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0))) drawAlign(ap[i], ap[j]);
        }
        drawFormat(0);
        if (ver >= 7) {
            var vr = ver;
            for (i = 0; i < 12; i++) vr = (vr << 1) ^ ((vr >>> 11) * 0x1F25);
            var vbits = (ver << 12) | vr;
            for (i = 0; i < 18; i++) {
                var a = size - 11 + i % 3, b = Math.floor(i / 3), c = getBit(vbits, i);
                setFn(a, b, c); setFn(b, a, c);
            }
        }

        // 4) размещение данных зигзагом
        i = 0;
        for (var right = size - 1; right >= 1; right -= 2) {
            if (right === 6) right = 5;
            for (var vert = 0; vert < size; vert++) {
                for (j = 0; j < 2; j++) {
                    var x = right - j, upward = ((right + 1) & 2) === 0, y = upward ? size - 1 - vert : vert;
                    if (!isFn[y][x] && i < all.length * 8) {
                        modules[y][x] = getBit(all[i >>> 3], 7 - (i & 7));
                        i++;
                    }
                }
            }
        }

        // 5) маска (выбираем с минимальным штрафом)
        function applyMask(mask) {
            for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
                var inv;
                switch (mask) {
                    case 0: inv = (x + y) % 2 === 0; break;
                    case 1: inv = y % 2 === 0; break;
                    case 2: inv = x % 3 === 0; break;
                    case 3: inv = (x + y) % 3 === 0; break;
                    case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
                    case 5: inv = x * y % 2 + x * y % 3 === 0; break;
                    case 6: inv = (x * y % 2 + x * y % 3) % 2 === 0; break;
                    default: inv = ((x + y) % 2 + x * y % 3) % 2 === 0;
                }
                if (!isFn[y][x] && inv) modules[y][x] = !modules[y][x];
            }
        }

        function penalty() {
            var res = 0, x, y;
            function addHist(run, h) { if (h[0] === 0) run += size; h.pop(); h.unshift(run); }
            function countPat(h) {
                var n = h[1];
                var core = n > 0 && h[2] === n && h[3] === n * 3 && h[4] === n && h[5] === n;
                return (core && h[0] >= n * 4 && h[6] >= n ? 1 : 0) + (core && h[6] >= n * 4 && h[0] >= n ? 1 : 0);
            }
            function endCount(color, run, h) {
                if (color) { addHist(run, h); run = 0; }
                run += size;
                addHist(run, h);
                return countPat(h);
            }
            for (var pass = 0; pass < 2; pass++) {
                for (y = 0; y < size; y++) {
                    var color = false, run = 0, hist = [0, 0, 0, 0, 0, 0, 0];
                    for (x = 0; x < size; x++) {
                        var cell = pass === 0 ? modules[y][x] : modules[x][y];
                        if (cell === color) {
                            run++;
                            if (run === 5) res += 3; else if (run > 5) res++;
                        } else {
                            addHist(run, hist);
                            if (!color) res += countPat(hist) * 40;
                            color = cell; run = 1;
                        }
                    }
                    res += endCount(color, run, hist) * 40;
                }
            }
            var dark = 0;
            for (y = 0; y < size; y++) for (x = 0; x < size; x++) {
                if (modules[y][x]) dark++;
                if (y < size - 1 && x < size - 1) {
                    var c = modules[y][x];
                    if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) res += 3;
                }
            }
            var total = size * size;
            res += (Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1) * 10;
            return res;
        }

        var best = 0, bestPen = Infinity;
        for (var m = 0; m < 8; m++) {
            applyMask(m);
            drawFormat(m);
            var p = penalty();
            if (p < bestPen) { bestPen = p; best = m; }
            applyMask(m); // отмена
        }
        applyMask(best);
        drawFormat(best);
        return modules;
    }

    // --- SVG: чёрное на белом, «тихая зона» 4 модуля ---
    function toSvg(text, px) {
        var m = encode(text), n = m.length, q = 4, d = '', x, y, run;
        for (y = 0; y < n; y++) {
            for (x = 0; x < n; x++) {
                if (!m[y][x]) continue;
                run = 1;
                while (x + run < n && m[y][x + run]) run++;
                d += 'M' + (x + q) + ',' + (y + q) + 'h' + run + 'v1h-' + run + 'z';
                x += run;
            }
        }
        var side = n + 2 * q;
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + side + ' ' + side + '" width="' + px + '" height="' + px +
            '" shape-rendering="crispEdges" role="img" aria-label="QR"><rect width="' + side + '" height="' + side +
            '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
    }

    global.SpaceQR = { encode: encode, toSvg: toSvg };
})(typeof window !== 'undefined' ? window : globalThis);

                                (function () {
                                    var box = document.getElementById('twofaQr');
                                    try {
                                        box.innerHTML = SpaceQR.toSvg(<?= json_encode($twofa_qr_uri, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?>, 240);
                                    } catch (e) {
                                        box.style.cssText = 'color:#333;font-size:13px;line-height:1.4;max-width:240px;';
                                        box.textContent = <?= json_encode($t['2fa_qr_failed'], JSON_UNESCAPED_UNICODE) ?>;
                                    }
                                })();
                            </script>

                        <?php else: ?>
                            <div class="info-row">
                                <span><?= $t['2fa_disabled_text'] ?></span>
                            </div>
                            <form method="POST" action="">
                                <input type="hidden" name="twofa_action" value="start">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                <button type="submit" class="save-button"><?= $t['2fa_enable_button'] ?></button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- IP ИСТОРИЯ (только для администрации) -->
                <?php if ($is_admin): ?>
                <div class="settings-card">
                    <div class="card-title">
                        <svg class="s-ico" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;vertical-align:-0.2em;width:20px;height:20px;fill:none;stroke:currentColor;"><circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.6 2.7 3.9 5.7 3.9 9s-1.3 6.3-3.9 9c-2.6-2.7-3.9-5.7-3.9-9S9.4 5.7 12 3z"/></svg> <?= $t['ip_history'] ?>
                        <span class="ip-badge">ADMIN</span>
                    </div>
                    <div class="card-subtitle">
                        <?= $t['ip_list'] ?>
                    </div>
                    <div class="settings-body">
                        <?php if ($ip_mismatch): ?>
                            <form method="POST" action="" class="ip-alert" onsubmit="return confirm('<?= htmlspecialchars($t['logout_all_confirm'], ENT_QUOTES, 'UTF-8') ?>')">
                                <input type="hidden" name="action" value="logout_all">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                <div>
                                    <div class="ip-alert-title"><?= $t['logout_all_title'] ?></div>
                                    <div class="ip-alert-desc"><?= $t['logout_all_text'] ?></div>
                                </div>
                                <button type="submit" class="dz-btn dz-btn-danger"><?= $t['logout_all_btn'] ?></button>
                            </form>
                        <?php endif; ?>
                        <?php if (empty($ip_history)): ?>
                            <div class="ip-history-empty">
                                <?= $t['no_ip_history'] ?><br>
                                <span style="font-size:11px;color:var(--text-muted);">
                                    <?= $t['current_ip'] ?>: <?= htmlspecialchars($current_ip ?: $t['ip_not_determined']) ?>
                                </span>
                            </div>
                        <?php else: ?>
                            <table class="ip-history-table">
                                <thead>
                                    <tr>
                                        <th><?= $t['ip_address'] ?></th>
                                        <th><?= $t['last_login'] ?></th>
                                        <th><?= $t['logins'] ?></th>
                                        <th><?= $t['logouts'] ?></th>
                                        <th><?= $t['device'] ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    foreach ($ip_history as $ip): 
                                        $is_current = ($ip['ip_address'] === $current_ip);
                                    ?>
                                        <tr>
                                            <td class="<?= $is_current ? 'ip-current' : 'ip-old' ?>">
                                                <strong><?= htmlspecialchars($ip['ip_address']) ?></strong>
                                                <?php if ($is_current): ?>
                                                    <span style="color:var(--ok-text);font-size:10px;margin-left:4px;"><svg class="s-ico" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;vertical-align:-0.2em;width:11px;height:11px;fill:none;stroke:currentColor;margin-right:2px;"><path d="M19 12H5M11 6l-6 6 6 6"/></svg> <?= $t['current_ip'] ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= date('d.m.Y H:i', strtotime($ip['created_at'])) ?></td>
                                            <td><span class="ip-count-badge" style="background:var(--ok-badge-bg);color:var(--ok-badge-text);"><svg class="s-ico" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;vertical-align:-0.2em;width:12px;height:12px;fill:none;stroke:currentColor;"><path d="M12 19V5M6 11l6-6 6 6"/></svg> <?= $ip['login_actions'] ?? 0 ?></span></td>
                                            <td><span class="ip-count-badge" style="background:#4a2527;color:#ff6b6b;"><svg class="s-ico" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;vertical-align:-0.2em;width:12px;height:12px;fill:none;stroke:currentColor;"><path d="M12 5v14M6 13l6 6 6-6"/></svg> <?= $ip['logout_actions'] ?? 0 ?></span></td>
                                            <td style="font-size:11px;color:var(--text-secondary);max-width:150px;word-break:break-all;" title="<?= htmlspecialchars($ip['user_agent'] ?? '') ?>">
                                                <?= htmlspecialchars(detectBrowserLabel($ip['user_agent'] ?? '')) ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <div style="margin-top:12px;color:var(--text-secondary);font-size:11px;">
                                <?= $t['showing'] ?> <?= count(array_unique(array_column($ip_history, 'ip_address'))) ?> <?= $t['unique_ips'] ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- ОПАСНАЯ ЗОНА -->
                <div class="settings-card danger-card">
                    <div class="card-title" style="color:#ed4245;">
                        <span class="dz-head-ico"><svg class="s-ico" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;width:20px;height:20px;fill:none;stroke:currentColor;"><path d="M12 3.5 2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17.2h.01"/></svg></span>
                        <?= $t['danger_zone'] ?>
                    </div>
                    <div class="card-subtitle">Действия, влияющие на аккаунт</div>
                    <div class="settings-body">

                        <div class="dz-list">

                            <form method="POST" action="" class="dz-row dz-row-warn" onsubmit="return confirm('<?= htmlspecialchars($t['deactivate_confirm'], ENT_QUOTES, 'UTF-8') ?>')">
                                <input type="hidden" name="action" value="deactivate">
                                <input type="hidden" name="confirm" value="yes">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                <span class="dz-ico"><svg class="s-ico" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;width:22px;height:22px;fill:none;stroke:currentColor;"><circle cx="12" cy="12" r="9"/><path d="M10 9v6M14 9v6"/></svg></span>
                                <div class="dz-text">
                                    <div class="dz-title"><?= $t['deactivate_profile'] ?></div>
                                    <div class="dz-desc"><?= $t['deactivate_warning'] ?></div>
                                </div>
                                <button type="submit" class="dz-btn dz-btn-warn"><?= $t['zone_deactivate_btn'] ?></button>
                            </form>

                            <form method="POST" action="" class="dz-row dz-row-danger" onsubmit="return confirm('<?= htmlspecialchars($t['delete_confirm'], ENT_QUOTES, 'UTF-8') ?>')">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="confirm" value="yes">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                <span class="dz-ico"><svg class="s-ico" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;width:22px;height:22px;fill:none;stroke:currentColor;"><path d="M4 7h16"/><path d="M9 7V4.5h6V7"/><path d="M6.5 7l.9 12.5a2 2 0 0 0 2 1.9h5.2a2 2 0 0 0 2-1.9L17.5 7"/><path d="M10 11v6M14 11v6"/></svg></span>
                                <div class="dz-text">
                                    <div class="dz-title"><?= $t['delete_profile'] ?></div>
                                    <div class="dz-desc"><?= $t['danger_warning'] ?></div>
                                </div>
                                <button type="submit" class="dz-btn dz-btn-danger"><?= $t['zone_delete_btn'] ?></button>
                            </form>

                        </div>

                        <div class="dz-help">
                            <span class="dz-help-text"><svg class="s-ico" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;width:18px;height:18px;fill:none;stroke:currentColor;"><path d="M20 12a8 8 0 0 1-8 8 8 8 0 0 1-3.7-.9L4 20l1.1-4.1A8 8 0 1 1 20 12z"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01" stroke-width="2.4"/></svg><span><?= $t['zone_support_text'] ?></span></span>
                            <a href="help.php" class="zone-action-button zone-action-support"><?= $t['support'] ?></a>
                        </div>

                    </div>
                </div>

            </div>

        </main>

        <div class="site-footer">
            &copy; <span class="year">2026</span>
        </div>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const handleBtn = document.getElementById('handleBtn');
            const bottomNav = document.getElementById('site-navigator');

            if (handleBtn && bottomNav) {
                let isNavVisible = false;
                let lastScrollTop = window.pageYOffset || document.documentElement.scrollTop;
                bottomNav.classList.add('nav-hidden');
                handleBtn.classList.remove('handle-hidden');

                const showNav = function() {
                    isNavVisible = true;
                    bottomNav.classList.remove('nav-hidden');
                    handleBtn.classList.add('handle-hidden');
                };

                const hideNav = function() {
                    isNavVisible = false;
                    bottomNav.classList.add('nav-hidden');
                    handleBtn.classList.remove('handle-hidden');
                };

                handleBtn.addEventListener('click', function() {
                    isNavVisible = !isNavVisible;
                    bottomNav.classList.toggle('nav-hidden', !isNavVisible);
                    this.classList.toggle('handle-hidden', !isNavVisible);
                });

                handleBtn.addEventListener('mouseenter', function() {
                    showNav();
                });

                bottomNav.addEventListener('mouseleave', function() {
                    if (!handleBtn.matches(':hover')) {
                        hideNav();
                    }
                });

                window.addEventListener('scroll', function() {
                    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

                    if (scrollTop > lastScrollTop) {
                        showNav();
                    } else if (scrollTop < lastScrollTop) {
                        hideNav();
                    }

                    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
                });
            }
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var markAllReadBtn = document.getElementById('markAllReadBtn');
            if (!markAllReadBtn) return;
            markAllReadBtn.addEventListener('click', function () {
                fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=mark_notifications_read'
                }).then(function (response) {
                    if (!response.ok) throw new Error('Не удалось отметить уведомления прочитанными.');
                    document.querySelectorAll('.notification-item.unread').forEach(function (item) {
                        item.classList.remove('unread');
                        item.classList.add('read');
                        var dot = item.querySelector('.notif-dot');
                        if (dot) dot.remove();
                    });
                    var badge = document.getElementById('notificationsBadge');
                    if (badge) badge.style.display = 'none';
                    var count = document.getElementById('notificationsCount');
                    if (count) count.textContent = '0 новых';
                    markAllReadBtn.remove();
                }).catch(function (error) {
                    console.error(error);
                });
            });
        });
    </script>

    <script>
        // Выбор языка с флагами: выбор значения сразу отправляет форму (как раньше onchange у select)
        (function () {
            var picker = document.getElementById('langPicker');
            if (!picker) return;
            var trigger = document.getElementById('langTrigger');
            var menu = document.getElementById('langMenu');
            var input = document.getElementById('langInput');
            var opts = Array.prototype.slice.call(menu.querySelectorAll('.lang-option'));
            var active = -1;

            function setActive(i) {
                active = (i + opts.length) % opts.length;
                opts.forEach(function (o, k) { o.classList.toggle('is-active', k === active); });
            }
            function open() {
                var cur = opts.findIndex(function (o) { return o.getAttribute('aria-selected') === 'true'; });
                setActive(cur < 0 ? 0 : cur);
                menu.classList.add('is-open');
                trigger.setAttribute('aria-expanded', 'true');
            }
            function close() {
                menu.classList.remove('is-open');
                trigger.setAttribute('aria-expanded', 'false');
                opts.forEach(function (o) { o.classList.remove('is-active'); });
            }
            function choose(o) {
                var val = o.getAttribute('data-value');
                if (val === input.value) { close(); return; }
                input.value = val;
                if (input.form) input.form.submit();
            }

            trigger.addEventListener('click', function () {
                menu.classList.contains('is-open') ? close() : open();
            });
            trigger.addEventListener('keydown', function (e) {
                var isOpen = menu.classList.contains('is-open');
                if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    if (!isOpen) open(); else setActive(active + (e.key === 'ArrowDown' ? 1 : -1));
                } else if ((e.key === 'Enter' || e.key === ' ') && isOpen) {
                    e.preventDefault();
                    choose(opts[active]);
                } else if (e.key === 'Escape' && isOpen) {
                    e.preventDefault();
                    close();
                }
            });
            opts.forEach(function (o, k) {
                o.addEventListener('mouseenter', function () { setActive(k); });
                o.addEventListener('click', function () { choose(o); });
            });
            document.addEventListener('click', function (e) {
                if (!picker.contains(e.target)) close();
            });
        })();
    </script>
    <script src="assets/js/nav-position.js"></script>
<script>
/* Редактор вида панели (телефон и компьютер): настройки сохраняются через window.NavMobile. */
(function () {
    function init() {
        var NM = window.NavMobile;
        var group = document.getElementById('nmGroup');
        if (!NM || !group) return;

        var preview = document.getElementById('nmPreview');
        var stylesBox = document.getElementById('nmStyles');
        var accentsBox = document.getElementById('nmAccents');
        var customSwatch = document.getElementById('nmCustomSwatch');
        var customColor = document.getElementById('nmCustomColor');
        var savedBox = document.getElementById('nmSaved');
        var LBL_SAVE = customSwatch.getAttribute('data-save'), LBL_SAVED = customSwatch.getAttribute('data-saved-label'), LBL_REMOVE = customSwatch.getAttribute('data-remove');
        var SAVE_KEY = 'nm_saved_colors', SAVE_MAX = 12;
        var X_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
        var autohide = document.getElementById('nmAutohide');
        var itemsBox = document.getElementById('nmItems');
        var UP = itemsBox.getAttribute('data-up'), DOWN = itemsBox.getAttribute('data-down');
        var ARROW_UP = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 15l6-6 6 6"/></svg>';
        var ARROW_DOWN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>';

        var cfg = NM.load();

        function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
        function accentHex() {
            var h = NM.accentHex(cfg);
            if (h) return h;
            var v = getComputedStyle(document.body).getPropertyValue('--accent-color').trim();
            return v || '#5865f2';
        }
        function persist() { NM.save(cfg); render(); }

        /* ---------- Сохранённые цвета (хранятся в браузере) ---------- */
        function loadSaved() {
            try {
                var a = JSON.parse(localStorage.getItem(SAVE_KEY) || '[]');
                if (!Array.isArray(a)) return [];
                return a.filter(function (h) { return /^#[0-9a-f]{6}$/i.test(h); })
                        .map(function (h) { return h.toLowerCase(); })
                        .filter(function (h, i, arr) { return arr.indexOf(h) === i; })
                        .slice(0, SAVE_MAX);
            } catch (err) { return []; }
        }
        function storeSaved() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(saved)); } catch (err) {} }
        var saved = loadSaved();
        function removeSaved(hex) {
            saved = saved.filter(function (h) { return h !== hex; });
            storeSaved();
            if (cfg.accent === 'custom' && String(cfg.custom).toLowerCase() === hex) {   // убрали выбранный цвет — возвращаем «по умолчанию»
                cfg.accent = NM.DEFAULTS.accent; cfg.custom = '';
                persist();
            } else {
                render();
            }
        }
        function renderSaved() {
            savedBox.innerHTML = '';
            var cur = (cfg.accent === 'custom' && cfg.custom) ? String(cfg.custom).toLowerCase() : '';
            var list = saved.slice();
            var isPalette = !!document.querySelector('#nmAccentsLight [data-hex="' + cur + '"], #nmAccentsDark [data-hex="' + cur + '"]');
            if (cur && !isPalette && list.indexOf(cur) === -1) list.push(cur);   // выбранный, но ещё не сохранённый цвет
            list.forEach(function (hex) {
                var wrap = document.createElement('span');
                wrap.className = 'nm-saved';
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'nm-swatch';
                b.setAttribute('role', 'radio');
                b.setAttribute('aria-checked', hex === cur ? 'true' : 'false');
                b.setAttribute('data-saved', hex);
                b.setAttribute('title', hex.toUpperCase());
                b.setAttribute('aria-label', hex.toUpperCase());
                b.style.setProperty('--sw', hex);
                wrap.appendChild(b);
                {
                    var d = document.createElement('button');
                    d.type = 'button';
                    d.className = 'nm-saved-del';
                    d.setAttribute('data-del', hex);
                    d.setAttribute('title', LBL_REMOVE);
                    d.setAttribute('aria-label', LBL_REMOVE + ' ' + hex.toUpperCase());
                    d.innerHTML = X_ICON;
                    wrap.appendChild(d);
                }
                savedBox.appendChild(wrap);
            });
        }

        function render() {
            var list = NM.ordered(cfg);
            var visible = list.filter(function (it) { return cfg.hidden.indexOf(it.key) === -1; });

            // кнопки вида и цвета
            Array.prototype.forEach.call(stylesBox.querySelectorAll('[data-style]'), function (b) {
                var on = b.getAttribute('data-style') === NM.effectiveStyle(cfg);
                b.classList.toggle('is-active', on); b.setAttribute('aria-checked', on ? 'true' : 'false');
            });
            Array.prototype.forEach.call(document.querySelectorAll('#nmAccents [data-accent]'), function (b) {
                b.setAttribute('aria-checked', b.getAttribute('data-accent') === cfg.accent ? 'true' : 'false');
            });
            Array.prototype.forEach.call(document.querySelectorAll('#nmAccentsLight [data-hex], #nmAccentsDark [data-hex]'), function (b) {
                var on = cfg.accent === 'custom' && String(cfg.custom).toLowerCase() === b.getAttribute('data-hex');
                b.setAttribute('aria-checked', on ? 'true' : 'false');
            });
            // сохранённые свои цвета + кружок «+»
            renderSaved();
            customColor.value = cfg.custom || '#ff2a4a';
            if (isPickerOpen()) placePicker();
            autohide.checked = !!cfg.autohide;

            // предпросмотр
            var accent = accentHex();
            preview.style.setProperty('--pv-accent', accent);
            var activeKey = visible.length ? (visible.filter(function (v) { return v.key === 'profile'; })[0] || visible[0]).key : '';
            var html = '<div class="nm-pv-nav" data-s="' + NM.effectiveStyle(cfg) + '">';
            visible.slice(0, 5).forEach(function (it) {
                html += '<div class="nm-pv-item' + (it.key === activeKey ? ' is-on' : '') + '"><i class="nm-pv-ic" style="display:contents">' + it.icon + '</i><span>' + esc(it.label) + '</span></div>';
            });
            preview.innerHTML = html + '</div>';

            // список пунктов
            itemsBox.innerHTML = '';
            list.forEach(function (it, i) {
                var off = cfg.hidden.indexOf(it.key) !== -1;
                var isLastVisible = !off && visible.length === 1;
                var row = document.createElement('div');
                row.className = 'nm-row' + (off ? ' is-off' : '');
                row.innerHTML =
                    '<span class="nm-row-icon">' + it.icon + '</span>' +
                    '<span class="nm-row-name">' + esc(it.label) + '</span>' +
                    '<span class="nm-move">' +
                        '<button type="button" data-act="up" aria-label="' + esc(UP) + '"' + (i === 0 ? ' disabled' : '') + '>' + ARROW_UP + '</button>' +
                        '<button type="button" data-act="down" aria-label="' + esc(DOWN) + '"' + (i === list.length - 1 ? ' disabled' : '') + '>' + ARROW_DOWN + '</button>' +
                    '</span>' +
                    '<label class="nm-tgl"><input type="checkbox" class="switch-input" role="switch"' + (off ? '' : ' checked') + (isLastVisible ? ' disabled' : '') + ' aria-label="' + esc(it.label) + '"><span class="switch-ui" aria-hidden="true"></span></label>';
                row.querySelector('input').addEventListener('change', function (e) {
                    var h = cfg.hidden.filter(function (k) { return k !== it.key; });
                    if (!e.target.checked) h.push(it.key);
                    cfg.hidden = h; persist();
                });
                Array.prototype.forEach.call(row.querySelectorAll('[data-act]'), function (b) {
                    b.addEventListener('click', function () {
                        var keys = NM.ordered(cfg).map(function (x) { return x.key; });
                        var j = b.getAttribute('data-act') === 'up' ? i - 1 : i + 1;
                        if (j < 0 || j >= keys.length) return;
                        var t = keys[i]; keys[i] = keys[j]; keys[j] = t;
                        cfg.order = keys; persist();
                    });
                });
                itemsBox.appendChild(row);
            });
        }

        stylesBox.addEventListener('click', function (e) {
            var b = e.target.closest('[data-style]'); if (!b) return;
            cfg.style = b.getAttribute('data-style'); persist();
        });
        accentsBox.addEventListener('click', function (e) {
            var b = e.target.closest('[data-accent]'); if (!b) return;
            cfg.accent = b.getAttribute('data-accent'); persist();
        });
        ['nmAccentsLight', 'nmAccentsDark'].forEach(function (id) {
            var box = document.getElementById(id);
            if (!box) return;
            box.addEventListener('click', function (e) {
                var b = e.target.closest('[data-hex]'); if (!b) return;
                cfg.custom = b.getAttribute('data-hex'); cfg.accent = 'custom';   // оттенок применяется как свой цвет
                closePicker(); persist();
            });
        });
        savedBox.addEventListener('click', function (e) {
            var d = e.target.closest('[data-del]');
            if (d) { removeSaved(d.getAttribute('data-del')); return; }
            var b = e.target.closest('[data-saved]'); if (!b) return;
            cfg.custom = b.getAttribute('data-saved'); cfg.accent = 'custom'; persist();
        });
        customSwatch.addEventListener('click', togglePicker);   // «+» — своё мини-окно палитры
        /* ---------- Своё мини-окно палитры ---------- */
        var pop = null, pH = 0, pS = 1, pV = 1, commitRaf = 0;
        var elSV, elSVKnob, elHue, elHueKnob, elDot, elHex, elR, elG, elB, elSave;

        function clamp01(x) { return Math.max(0, Math.min(1, x)); }
        function hsv2rgb(h, s, v) {
            function f(n) { var k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); }
            return [Math.round(f(5) * 255), Math.round(f(3) * 255), Math.round(f(1) * 255)];
        }
        function rgb2hsv(r, g, b) {
            r /= 255; g /= 255; b /= 255;
            var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
            if (d) {
                if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
                h *= 60; if (h < 0) h += 360;
            }
            return [h, mx ? d / mx : 0, mx];
        }
        function toHex(rgb) { return '#' + rgb.map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
        function parseHex(s) {
            s = String(s).trim().replace(/^#/, '');
            if (/^[0-9a-f]{3}$/i.test(s)) s = s.replace(/(.)/g, '$1$1');
            if (!/^[0-9a-f]{6}$/i.test(s)) return null;
            return [parseInt(s.substr(0, 2), 16), parseInt(s.substr(2, 2), 16), parseInt(s.substr(4, 2), 16)];
        }
        function setFromRgb(rgb) {
            var hsv = rgb2hsv(rgb[0], rgb[1], rgb[2]);
            if (hsv[1] > 0 && hsv[2] > 0) pH = hsv[0];   // у серого и чёрного оттенок не определён — оставляем прежний
            pS = hsv[1]; pV = hsv[2];
        }

        function paint() {
            var rgb = hsv2rgb(pH, pS, pV), hex = toHex(rgb);
            elSV.style.background = 'linear-gradient(to top,#000,rgba(0,0,0,0)),linear-gradient(to right,#fff,hsl(' + pH + ',100%,50%))';
            elSVKnob.style.left = (pS * 100) + '%';
            elSVKnob.style.top = ((1 - pV) * 100) + '%';
            elSVKnob.style.background = hex;
            elHueKnob.style.left = (pH / 360 * 100) + '%';
            elHueKnob.style.background = 'hsl(' + pH + ',100%,50%)';
            elDot.style.background = hex;
            var focused = document.activeElement;
            if (focused !== elHex) elHex.value = hex;
            if (focused !== elR) elR.value = rgb[0];
            if (focused !== elG) elG.value = rgb[1];
            if (focused !== elB) elB.value = rgb[2];
            var isSaved = saved.indexOf(hex) !== -1;
            elSave.disabled = isSaved || saved.length >= SAVE_MAX;
            elSave.textContent = isSaved ? LBL_SAVED : LBL_SAVE;
            return hex;
        }
        function commit() {
            var hex = paint();
            cfg.custom = hex; cfg.accent = 'custom';
            if (commitRaf) return;
            commitRaf = requestAnimationFrame(function () { commitRaf = 0; persist(); });
        }

        function makeDrag(el, fn) {
            el.addEventListener('pointerdown', function (e) {
                e.preventDefault();
                try { el.setPointerCapture(e.pointerId); } catch (err) {}
                fn(e);
                function mv(ev) { fn(ev); }
                function up() {
                    el.removeEventListener('pointermove', mv);
                    el.removeEventListener('pointerup', up);
                    el.removeEventListener('pointercancel', up);
                }
                el.addEventListener('pointermove', mv);
                el.addEventListener('pointerup', up);
                el.addEventListener('pointercancel', up);
            });
        }

        function buildPicker() {
            pop = document.createElement('div');
            pop.className = 'nm-pop';
            pop.setAttribute('role', 'dialog');
            pop.innerHTML =
                '<div class="nm-pop-sv"><div class="nm-pop-knob"></div></div>' +
                '<div class="nm-pop-mid">' +
                    (window.EyeDropper ? '<button type="button" class="nm-pop-eye" title="' + esc(accentsBox.querySelector('#nmCustomSwatch').getAttribute('data-eyedropper')) + '" aria-label="' + esc(accentsBox.querySelector('#nmCustomSwatch').getAttribute('data-eyedropper')) + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 3.5a2.1 2.1 0 0 0-3 0l-3 3-1-1-2 2 1 1-7.2 7.2a1.5 1.5 0 0 0-.4.8l-.4 3.3 3.3-.4a1.5 1.5 0 0 0 .8-.4l7.2-7.2 1 1 2-2-1-1 3-3a2.1 2.1 0 0 0 0-3z"/></svg></button>' : '') +
                    '<span class="nm-pop-dot"></span>' +
                    '<div class="nm-pop-hue"><div class="nm-pop-knob"></div></div>' +
                '</div>' +
                '<div class="nm-pop-fields">' +
                    '<label class="nm-pop-field"><input type="text" class="nm-pop-hex" maxlength="7" spellcheck="false" autocomplete="off"><span>HEX</span></label>' +
                    '<label class="nm-pop-field"><input type="number" class="nm-pop-r" min="0" max="255"><span>R</span></label>' +
                    '<label class="nm-pop-field"><input type="number" class="nm-pop-g" min="0" max="255"><span>G</span></label>' +
                    '<label class="nm-pop-field"><input type="number" class="nm-pop-b" min="0" max="255"><span>B</span></label>' +
                '</div>' +
                '<button type="button" class="nm-pop-add"></button>';
            document.body.appendChild(pop);

            elSV = pop.querySelector('.nm-pop-sv');
            elSVKnob = elSV.querySelector('.nm-pop-knob');
            elHue = pop.querySelector('.nm-pop-hue');
            elHueKnob = elHue.querySelector('.nm-pop-knob');
            elDot = pop.querySelector('.nm-pop-dot');
            elHex = pop.querySelector('.nm-pop-hex');
            elR = pop.querySelector('.nm-pop-r');
            elG = pop.querySelector('.nm-pop-g');
            elB = pop.querySelector('.nm-pop-b');
            elSave = pop.querySelector('.nm-pop-add');
            elSave.addEventListener('click', function () {
                var hex = paint();
                if (saved.indexOf(hex) === -1 && saved.length < SAVE_MAX) { saved.push(hex); storeSaved(); }
                cfg.custom = hex; cfg.accent = 'custom';
                closePicker(); persist();
            });

            makeDrag(elSV, function (e) {
                var r = elSV.getBoundingClientRect();
                pS = clamp01((e.clientX - r.left) / r.width);
                pV = 1 - clamp01((e.clientY - r.top) / r.height);
                commit();
            });
            makeDrag(elHue, function (e) {
                var r = elHue.getBoundingClientRect();
                pH = clamp01((e.clientX - r.left) / r.width) * 360;
                commit();
            });

            elHex.addEventListener('input', function () {
                var rgb = parseHex(elHex.value);
                if (rgb) { setFromRgb(rgb); commit(); }
            });
            elHex.addEventListener('blur', paint);
            [elR, elG, elB].forEach(function (inp) {
                inp.addEventListener('input', function () {
                    if (inp.value === '') return;
                    var rgb = [elR, elG, elB].map(function (x) { return Math.max(0, Math.min(255, parseInt(x.value, 10) || 0)); });
                    setFromRgb(rgb); commit();
                });
                inp.addEventListener('blur', paint);
            });

            var eye = pop.querySelector('.nm-pop-eye');
            if (eye) eye.addEventListener('click', function () {
                new window.EyeDropper().open().then(function (res) {
                    var rgb = parseHex(res.sRGBHex);
                    if (rgb) { setFromRgb(rgb); commit(); }
                }).catch(function () {});
            });

            pop.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') { closePicker(); customSwatch.focus(); }
            });
        }

        function placePicker() {
            if (!pop) return;
            var r = customSwatch.getBoundingClientRect();
            var w = pop.offsetWidth, h = pop.offsetHeight;
            var left = Math.max(8, Math.min(window.innerWidth - w - 8, r.left + r.width / 2 - w / 2));
            var top = r.bottom + 10;
            if (top + h > window.innerHeight - 8) top = r.top - h - 10;
            pop.style.left = left + 'px';
            pop.style.top = Math.max(8, top) + 'px';
        }

        function isPickerOpen() { return !!pop && pop.classList.contains('is-open'); }
        function openPicker() {
            if (!pop) buildPicker();
            var rgb = parseHex(cfg.custom || accentHex()) || [255, 42, 74];
            setFromRgb(rgb);
            paint();
            pop.classList.add('is-open');
            customSwatch.setAttribute('aria-expanded', 'true');
            placePicker();
        }
        function closePicker() {
            if (!pop) return;
            pop.classList.remove('is-open');
            customSwatch.setAttribute('aria-expanded', 'false');
        }
        function togglePicker() { isPickerOpen() ? closePicker() : openPicker(); }

        document.addEventListener('pointerdown', function (e) {
            if (isPickerOpen() && !pop.contains(e.target) && !customSwatch.contains(e.target)) closePicker();
        });
        window.addEventListener('resize', placePicker);
        window.addEventListener('scroll', placePicker, true);
        autohide.addEventListener('change', function () { cfg.autohide = autohide.checked; persist(); });
        document.getElementById('nmReset').addEventListener('click', function () {
            NM.reset(); cfg = NM.load(); render();
        });

        render();
    }
    // nav-mobile.js подключён с defer (из includes/bottom_nav.php) и выполняется до DOMContentLoaded
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
</script>
    <script src="assets/js/error-reporter.js"></script>
</body>
</html>

<?php
$conn->close();
?>
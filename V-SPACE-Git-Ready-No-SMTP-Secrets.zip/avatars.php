<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    require_once __DIR__ . '/includes/helpers.php';
    start_secure_session();
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

require_once __DIR__ . '/includes/db.php';

// true — файл открыт напрямую (форма загрузки/удаления), false — подключён через include.
$avatarsIsEntryPoint = realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__;

/* =========================================================
   ХЕЛПЕРЫ
   ========================================================= */

/** Разрешаем возврат только на свои страницы (защита от open redirect). */
if (!function_exists('avatarSafeReturn')) {
function avatarSafeReturn($value): string
{
    $value = is_string($value) ? $value : '';
    if (preg_match('/^(edit|index)\.php(\?user=\d+)?$/', $value)) {
        return $value;
    }
    return 'index.php';
}
}

/** Завершает запрос: JSON для fetch, иначе flash-сообщение + редирект обратно. */
if (!function_exists('avatarFinish')) {
function avatarFinish(bool $ok, string $message, string $return, int $status = 200, array $extra = []): void
{
    $wantsJson = strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

    if ($wantsJson) {
        http_response_code($ok ? 200 : $status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array_merge(['ok' => $ok, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $_SESSION['flash_avatar'] = ['ok' => $ok, 'msg' => $message];
    header('Location: ' . $return);
    exit;
}
}

/** Совместимость со старым именем: ошибка + возврат на страницу. */
if (!function_exists('avatarFail')) {
function avatarFail(string $message, int $status = 400): void
{
    global $avatarReturn;
    avatarFinish(false, $message, $avatarReturn ?? 'index.php', $status);
}
}

/** Удаляет файл аватарки, только если он лежит именно в uploads/avatars/. */
if (!function_exists('avatarDeleteFile')) {
function avatarDeleteFile(?string $relativePath): void
{
    if (empty($relativePath)) {
        return;
    }
    $root = realpath(__DIR__ . '/uploads/avatars');
    $file = realpath(__DIR__ . '/' . $relativePath);

    if ($root !== false && $file !== false && is_file($file)
        && strpos($file, $root . DIRECTORY_SEPARATOR) === 0) {
        @unlink($file);
    }
}
}

/** Переводит значение memory_limit (128M, 1G, -1) в байты. -1 (без лимита) -> PHP_INT_MAX. */
if (!function_exists('avatarMemoryLimitBytes')) {
function avatarMemoryLimitBytes(): int
{
    $v = trim((string)ini_get('memory_limit'));
    if ($v === '' || $v === '-1') {
        return PHP_INT_MAX;
    }
    $num = (float)$v;
    switch (strtolower(substr($v, -1))) {
        case 'g': $num *= 1024;   // no break
        case 'm': $num *= 1024;   // no break
        case 'k': $num *= 1024;
    }
    return (int)$num;
}
}

/**
 * Готовит аватарку для чёткого отображения:
 *  - исправляет поворот по EXIF (после пересохранения EXIF пропадает);
 *  - обрезает по центру до квадрата (так же, как раньше делал object-fit: cover);
 *  - уменьшает до $maxSide x $maxSide качественной интерполяцией (маленькие фото не растягивает);
 *  - слегка повышает резкость при сильном уменьшении (только JPEG).
 * Возвращает false, если обработать нельзя (нет GD, анимированный WebP, мало памяти и т.п.) —
 * тогда вызывающий код сохраняет оригинал как раньше.
 */
if (!function_exists('avatarProcessImage')) {
function avatarProcessImage(string $src, string $dst, string $mime, int $maxSide = 512): bool
{
    if (!extension_loaded('gd')) {
        return false;
    }
    // GIF не обрабатываем: GD сохранил бы только первый кадр и анимация пропала бы.
    // Возврат false → вызывающий код сохранит оригинальный файл как есть.
    if ($mime === 'image/gif') {
        return false;
    }
    $loaders = [
        'image/jpeg' => 'imagecreatefromjpeg',
        'image/png'  => 'imagecreatefrompng',
        'image/webp' => 'imagecreatefromwebp',
    ];
    $loader = $loaders[$mime] ?? null;
    if ($loader === null || !function_exists($loader)) {
        return false;
    }

    $info = @getimagesize($src);
    if (!$info || $info[0] < 1 || $info[1] < 1) {
        return false;
    }
    $w = (int)$info[0];
    $h = (int)$info[1];

    // Анимированный WebP не трогаем: GD оставил бы только первый кадр.
    if ($mime === 'image/webp') {
        $head = @file_get_contents($src, false, null, 0, 256);
        if ($head !== false && strpos($head, 'ANIM') !== false) {
            return false;
        }
    }

    // Память: распакованная картинка занимает ~4 байта на пиксель (плюс копия при повороте).
    $needed = $w * $h * 8 + 16 * 1024 * 1024;
    $limit  = avatarMemoryLimitBytes();
    if ($limit < 512 * 1024 * 1024 && memory_get_usage(true) + $needed > $limit) {
        @ini_set('memory_limit', '512M');
        $limit = avatarMemoryLimitBytes();
    }
    if (memory_get_usage(true) + $needed > $limit) {
        return false;
    }

    $orientation = 1;
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $exif = @exif_read_data($src);
        if (is_array($exif) && isset($exif['Orientation'])) {
            $orientation = (int)$exif['Orientation'];
        }
    }

    try {
        $img = @$loader($src);
        if (!$img) {
            return false;
        }

        $angle = [3 => 180, 6 => -90, 8 => 90][$orientation] ?? 0;
        if ($angle !== 0) {
            $rotated = imagerotate($img, $angle, 0);
            if ($rotated) {
                $img = $rotated;
            }
        }
        $w = imagesx($img);
        $h = imagesy($img);

        $side = min($w, $h);
        $sx   = intdiv($w - $side, 2);
        $sy   = intdiv($h - $side, 2);
        $out  = max(1, min($maxSide, $side));

        $canvas = imagecreatetruecolor($out, $out);
        if ($mime !== 'image/jpeg') {
            // сохраняем прозрачность PNG / WebP
            imagealphablending($canvas, false);
            imagesavealpha($canvas, true);
            imagefilledrectangle($canvas, 0, 0, $out, $out, imagecolorallocatealpha($canvas, 0, 0, 0, 127));
        }
        if (!imagecopyresampled($canvas, $img, 0, 0, $sx, $sy, $out, $out, $side, $side)) {
            return false;
        }

        // Небольшая резкость, чтобы после сильного уменьшения фото не выглядело «мыльным».
        if ($mime === 'image/jpeg' && $side > $out * 1.25) {
            @imageconvolution($canvas, [[0, -0.5, 0], [-0.5, 3, -0.5], [0, -0.5, 0]], 1, 0);
        }

        switch ($mime) {
            case 'image/jpeg': $ok = imagejpeg($canvas, $dst, 92); break;
            case 'image/png':  $ok = imagepng($canvas, $dst, 6);   break;
            default:           $ok = imagewebp($canvas, $dst, 90); break;
        }
        unset($img, $canvas);

        if (!$ok || !is_file($dst) || filesize($dst) === 0) {
            if (is_file($dst)) {
                @unlink($dst);
            }
            return false;
        }
        return true;
    } catch (Throwable $e) {
        error_log('avatars.php image processing error: ' . $e->getMessage());
        if (is_file($dst)) {
            @unlink($dst);
        }
        return false;
    }
}
}

/** Генерирует или возвращает CSRF-токен для текущей сессии. */
if (!function_exists('avatarCsrfToken')) {
function avatarCsrfToken(): string
{
    if (empty($_SESSION['avatar_csrf_token'])) {
        $_SESSION['avatar_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['avatar_csrf_token'];
}
}

/** Проверяет CSRF-токен из POST-запроса. Завершает запрос при ошибке. */
if (!function_exists('avatarRequireCsrf')) {
function avatarRequireCsrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || $token === '' || !hash_equals(avatarCsrfToken(), $token)) {
        avatarFail("Ошибка безопасности (CSRF). Обновите страницу и попробуйте снова.", 403);
    }
}
}

$avatarReturn = avatarSafeReturn($_POST['return'] ?? '');

/* =========================================================
   ПОДКЛЮЧЕНИЕ К БД
   ========================================================= */

try {
    if (!$avatarsIsEntryPoint && isset($conn) && $conn instanceof mysqli) {
        $avatarsDb = $conn; // переиспользуем соединение страницы, не затирая её $conn
    } else {
        $avatarsDb = db_connect(true);
    }
} catch (Throwable $e) {
    error_log('avatars.php DB connect error: ' . $e->getMessage());
    if ($avatarsIsEntryPoint) {
        avatarFail("Сервис временно недоступен. Попробуйте позже.", 503);
    }
    return;
}

/* =========================================================
   ЗАГРУЗКА / УДАЛЕНИЕ АВАТАРКИ (только при прямом обращении)
   ========================================================= */

if ($avatarsIsEntryPoint && $_SERVER["REQUEST_METHOD"] === "POST") {

    // Проверка CSRF-токена перед любыми действиями
    avatarRequireCsrf();

    /* ---------- Удаление ---------- */
    if (isset($_POST["remove_avatar"])) {
        try {
            $stmt = $avatarsDb->prepare("SELECT avatar FROM users WHERE id = ? LIMIT 1");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $oldUser = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $stmt = $avatarsDb->prepare("UPDATE users SET avatar = NULL WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->close();
        } catch (Throwable $e) {
            error_log('avatars.php remove error: ' . $e->getMessage());
            avatarFail("Не удалось удалить фотографию.", 500);
        }

        avatarDeleteFile($oldUser["avatar"] ?? null);
        avatarFinish(true, "Аватар удалён!", $avatarReturn, 200, ['avatar' => '']);
    }

    /* ---------- Загрузка ---------- */

    // Если файл больше post_max_size, PHP полностью очищает $_FILES и $_POST.
    if (!isset($_FILES["avatar"])) {
        avatarFail("Файл не получен. Возможно, он слишком большой (максимум — 5 МБ).", 413);
    }

    $file = $_FILES["avatar"];

    if (!is_array($file) || ($file["error"] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $uploadErrors = [
            UPLOAD_ERR_INI_SIZE   => "Фотография слишком большая. Максимальный размер — 5 МБ.",
            UPLOAD_ERR_FORM_SIZE  => "Фотография слишком большая. Максимальный размер — 5 МБ.",
            UPLOAD_ERR_PARTIAL    => "Фотография загрузилась не полностью. Попробуйте ещё раз.",
            UPLOAD_ERR_NO_FILE    => "Выберите фотографию для загрузки.",
            UPLOAD_ERR_NO_TMP_DIR => "На сервере не настроена временная папка.",
            UPLOAD_ERR_CANT_WRITE => "Не удалось записать файл на диск.",
            UPLOAD_ERR_EXTENSION  => "Загрузка остановлена расширением PHP.",
        ];
        $code = (int)($file["error"] ?? UPLOAD_ERR_NO_FILE);
        avatarFail($uploadErrors[$code] ?? "Ошибка загрузки фотографии.");
    }

    if (!is_uploaded_file($file["tmp_name"])) {
        avatarFail("Ошибка загрузки фотографии.");
    }

    if ($file["size"] > 5 * 1024 * 1024) {
        avatarFail("Фотография слишком большая. Максимальный размер — 5 МБ.", 413);
    }

    $imageInfo = @getimagesize($file["tmp_name"]);

    if ($imageInfo === false) {
        avatarFail("Файл не является изображением.");
    }

    // Защита от "бомб распаковки": маленький файл, но огромное разрешение
    if ($imageInfo[0] > 6000 || $imageInfo[1] > 6000 || $imageInfo[0] < 1 || $imageInfo[1] < 1) {
        avatarFail("Слишком большое разрешение. Максимум — 6000×6000 пикселей.");
    }

    $allowedTypes = [
        "image/jpeg" => "jpg",
        "image/png"  => "png",
        "image/webp" => "webp",
        "image/gif"  => "gif"
    ];

    $mime = $imageInfo["mime"] ?? "";

    if (!isset($allowedTypes[$mime])) {
        avatarFail("Разрешены только JPG, PNG, WEBP и GIF.");
    }

    $extension = $allowedTypes[$mime];

    $uploadDir = __DIR__ . "/uploads/avatars/";

    if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
        error_log('avatars.php: cannot create ' . $uploadDir);
        avatarFail("Не удалось создать папку для фотографий.", 500);
    }

    $fileName = "avatar_" . $user_id . "_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $extension;
    $filePath = $uploadDir . $fileName;

    // Квадрат до 512x512 с качественным уменьшением — аватарка получается чёткой.
    // Если обработать нельзя (нет GD, анимированный WebP и т.п.), сохраняем оригинал как раньше.
    if (!avatarProcessImage($file["tmp_name"], $filePath, $mime, 512)) {
        if (!move_uploaded_file($file["tmp_name"], $filePath)) {
            error_log('avatars.php: move_uploaded_file failed for ' . $filePath);
            avatarFail("Не удалось сохранить фотографию.", 500);
        }
    }

    @chmod($filePath, 0644);

    $avatarPath = "uploads/avatars/" . $fileName;

    try {
        $stmt = $avatarsDb->prepare("SELECT avatar FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $oldUser = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $stmt = $avatarsDb->prepare("UPDATE users SET avatar = ? WHERE id = ?");
        $stmt->bind_param("si", $avatarPath, $user_id);
        $stmt->execute();
        $stmt->close();
    } catch (Throwable $e) {
        // БД не обновилась — удаляем загруженный файл, чтобы не копить мусор
        error_log('avatars.php DB error: ' . $e->getMessage());
        if (is_file($filePath)) {
            @unlink($filePath);
        }
        avatarFail("Не удалось сохранить фотографию в базе данных.", 500);
    }

    if (($oldUser["avatar"] ?? '') !== $avatarPath) {
        avatarDeleteFile($oldUser["avatar"] ?? null);
    }

    avatarFinish(true, "Аватар успешно обновлён!", $avatarReturn, 200, ['avatar' => $avatarPath]);
}


/* =========================================================
   ДАННЫЕ ПОЛЬЗОВАТЕЛЯ
   (для страниц, которые подключают файл ради $user, $username, $avatar)
   ========================================================= */

// Прямое открытие по GET — показывать нечего, форма живёт на edit.php / index.php.
if ($avatarsIsEntryPoint) {
    header("Location: " . avatarSafeReturn($_GET['return'] ?? ''));
    exit;
}

try {
    $stmt = $avatarsDb->prepare("
        SELECT id, username, email, avatar, created_at, last_seen, status
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} catch (Throwable $e) {
    error_log('avatars.php user fetch error: ' . $e->getMessage());
    $user = null;
}

$username = ($user["username"] ?? '') ?: "Пользователь";
$avatar = ($user["avatar"] ?? '') ?: "";
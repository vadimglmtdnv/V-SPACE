<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
// Если в настройках выбран English — содержимое страницы переводится «на лету» (includes/lang.php)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();
require_once __DIR__ . '/maintenance.php';
header("Content-Security-Policy: script-src 'self' 'unsafe-inline';");
header('Content-Type: text/html; charset=utf-8');

$db_error = '';
$conn = null;

try {
    $conn = db_connect();

    if ($conn->connect_error) {
        throw new Exception("Ошибка подключения: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");

} catch (Exception $e) {
    $db_error = $e->getMessage();
    error_log("MySQL Error: " . $db_error);
}

if (!$conn || $conn->connect_error) {
    // Единая страница ошибок (error.php) вместо отдельной вёрстки
    $error_code   = 503;
    $error_title  = 'Нет связи с базой данных';
    $error_text   = 'Не удалось подключиться к серверу MySQL, поддержка сейчас недоступна. Попробуйте чуть позже.';
    $error_detail = $db_error;   // показывается только при заходе с localhost
    require __DIR__ . '/error.php';
    exit;
}

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: support.php");
    exit;
}

// ===== СОЗДАЁМ ТАБЛИЦУ ПОДДЕРЖКИ =====
$conn->query("
    CREATE TABLE IF NOT EXISTS support_tickets (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('open', 'in_progress', 'closed') DEFAULT 'open',
        admin_response TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        PRIMARY KEY (id),
        INDEX user_id (user_id),
        INDEX status (status)
    ) ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_unicode_ci
");

// Проверяем и добавляем столбец admin_response (если его нет)
$result = $conn->query("SHOW COLUMNS FROM support_tickets LIKE 'admin_response'");
if ($result->num_rows === 0) {
    $conn->query("ALTER TABLE support_tickets ADD COLUMN admin_response TEXT NULL");
}
$result->close();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

// Получаем данные текущего пользователя
$current_user_data = [];
$stmt = $conn->prepare("SELECT id, username, email, avatar, status, is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$current_user_data = $result->fetch_assoc();
$stmt->close();
$is_admin = (int)($current_user_data['is_admin'] ?? 0) === 1;

// Получаем количество непрочитанных сообщений
$unread_count = 0;
$unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

// Получаем уведомления в том же формате, что и messages.php.
$notifications = [];
$stmt = $conn->prepare("
    SELECT *
    FROM notifications
    WHERE user_id = ?
      AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY created_at DESC
    LIMIT 20
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

$notification_count = 0;
$stmt = $conn->prepare("
    SELECT COUNT(*) AS count
    FROM notifications
    WHERE user_id = ?
      AND is_read = 0
      AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$notification_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
$stmt->close();
$notif_count = $notification_count;   // имя переменной, как в шапке index.php

$pending_reports_count = 0;
if ($is_admin) {
    $result = $conn->query("SELECT COUNT(*) AS count FROM reports WHERE status = 'pending'");
    if ($result) {
        $pending_reports_count = (int)($result->fetch_assoc()['count'] ?? 0);
    }
}

// ===== ПОДКЛЮЧЕНИЕ PHPMailer =====
$phpMailerSrc = __DIR__ . '/includes/PHPMailer/src/';

$files = ['Exception.php', 'PHPMailer.php', 'SMTP.php'];
foreach ($files as $file) {
    $path = $phpMailerSrc . $file;
    if (file_exists($path)) {
        require_once $path;
    }
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
// =================================

// Обработка отправки сообщения в поддержку
$support_error = "";
$support_success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["send_support"])) {
    $subject = trim($_POST["subject"] ?? "");
    $message = trim($_POST["message"] ?? "");
    
    if ($subject === "" || $message === "") {
        $support_error = "Заполните все поля.";
    } else {
        // Сохраняем в базу данных
        $stmt = $conn->prepare("
            INSERT INTO support_tickets (user_id, subject, message, status, created_at)
            VALUES (?, ?, ?, 'open', NOW())
        ");
        $stmt->bind_param("iss", $user_id, $subject, $message);
        
        if ($stmt->execute()) {
            $ticket_id = $stmt->insert_id;
            $stmt->close();
            
            // ===== ОТПРАВКА НА ПОЧТУ (MAIL.RU + GMAIL) =====
            $mail_sent = false;
            $mail_error = "";
            
            $user_email = $current_user_data['email'] ?? 'Не указан';
            $username = $current_user_data['username'] ?? 'Пользователь';
            
            $mailConfig = require __DIR__ . '/mail_config.php';
            $mailProviders = is_array($mailConfig['providers'] ?? null) ? $mailConfig['providers'] : [];
            $mailSent = false;
            $mailError = '';

            foreach (['mailru', 'gmail'] as $providerKey) {
                $provider = $mailProviders[$providerKey] ?? null;
                if (!is_array($provider)) {
                    continue;
                }

                $smtpUsername = trim((string)($provider['username'] ?? ''));
                $smtpPassword = trim((string)($provider['password'] ?? ''));
                if ($smtpUsername === '' || $smtpPassword === '') {
                    continue;
                }

                try {
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->SMTPAuth = true;
                    $mail->Host = trim((string)($provider['host'] ?? 'smtp.mail.ru'));
                    $mail->Username = $smtpUsername;
                    $mail->Password = $smtpPassword;
                    $mail->SMTPSecure = strtolower(trim((string)($provider['encryption'] ?? 'ssl'))) === 'starttls'
                        ? PHPMailer::ENCRYPTION_STARTTLS
                        : PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port = (int)($provider['port'] ?? 465);
                    $mail->CharSet = 'UTF-8';
                    $mail->setFrom($smtpUsername, 'V SPACE Support');
                    $mail->addAddress('playerchat@mail.ru');
                    $mail->isHTML(true);
                    $mail->Subject = '[SUPPORT] ' . $subject;
                    $mail->Body = "
                    <html>
                    <head>
                        <style>
                            body { font-family: 'Segoe UI', Arial, sans-serif; color: #333; }
                            .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px; }
                            .header { background: #5865f2; color: #fff; padding: 15px 20px; border-radius: 8px 8px 0 0; }
                            .content { padding: 20px; }
                            .field { margin-bottom: 12px; }
                            .field-label { font-weight: 600; color: #555; }
                            .field-value { color: #222; }
                            .message-box { background: #f5f5f5; padding: 15px; border-radius: 6px; margin-top: 8px; }
                            .footer { font-size: 12px; color: #999; text-align: center; padding-top: 15px; border-top: 1px solid #e0e0e0; margin-top: 20px; }
                        </style>
                    </head>
                    <body>
                        <div class='container'>
                            <div class='header'>
                                <h2>🆘 Новое обращение в поддержку</h2>
                            </div>
                            <div class='content'>
                                <div class='field'>
                                    <div class='field-label'>Отправитель:</div>
                                    <div class='field-value'><strong>{$username}</strong> ({$user_email})</div>
                                </div>
                                <div class='field'>
                                    <div class='field-label'>ID пользователя:</div>
                                    <div class='field-value'>{$user_id}</div>
                                </div>
                                <div class='field'>
                                    <div class='field-label'>Тема:</div>
                                    <div class='field-value'><strong>" . htmlspecialchars($subject, ENT_QUOTES, 'UTF-8') . "</strong></div>
                                </div>
                                <div class='field'>
                                    <div class='field-label'>Сообщение:</div>
                                    <div class='message-box'>" . nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8')) . "</div>
                                </div>
                                <div class='field'>
                                    <div class='field-label'>Номер обращения:</div>
                                    <div class='field-value'>#{$ticket_id}</div>
                                </div>
                                <div class='field'>
                                    <div class='field-label'>Дата:</div>
                                    <div class='field-value'>" . date('d.m.Y H:i:s') . "</div>
                                </div>
                            </div>
                            <div class='footer'>
                                V SPACE — Система поддержки
                            </div>
                        </div>
                    </body>
                    </html>
                    ";
                    $mail->AltBody = "Новое обращение в поддержку!\n\nОтправитель: {$username} ({$user_email})\nID пользователя: {$user_id}\nТема: {$subject}\nСообщение:\n{$message}\nНомер обращения: #{$ticket_id}\nДата: " . date('d.m.Y H:i:s');

                    if ($mail->send()) {
                        $mailSent = true;
                        break;
                    }
                } catch (Exception $e) {
                    $mailError = $e->getMessage();
                    error_log('PHPMailer (' . $providerKey . ') Error: ' . $mailError);
                }
            }

            if (!$mailSent && $mailError !== '') {
                error_log('Support email delivery failed: ' . $mailError);
            }
            
            // Сообщение пользователю
            $support_success = "✅ Ваше сообщение отправлено. Мы ответим вам в ближайшее время.";
            if ($mailSent) {
                $support_success .= " 📧 Копии отправлены на почту администратора.";
            } else {
                $support_success .= " ⚠️ Почтовый сервис не настроен, но сообщение сохранено в системе.";
                error_log("Mail error: " . $mailError);
            }
            
        } else {
            $support_error = "❌ Ошибка сохранения: " . $conn->error;
        }
    }
}

// Получаем историю обращений пользователя
$tickets = [];
$stmt = $conn->prepare("
    SELECT id, subject, message, status, admin_response, created_at, updated_at
    FROM support_tickets
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 20
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $tickets[] = $row;
}
$stmt->close();

if (!function_exists('isOnline')) {
    function isOnline(?string $status): bool {
        return $status === 'online';
    }
}

if (!function_exists('getNotificationIcon')) {
    function getNotificationIcon(string $type): string {
        $icons = [
            'friend_request' => '👋', 'friend_accepted' => '✅', 'friend_removed' => '❌',
            'like' => '❤️', 'comment' => '💭', 'repost' => '🔁', 'message' => '💬',
            'news' => '📰', 'tag' => '🔖', 'mention' => '@', 'info' => 'ℹ️'
        ];
        return $icons[$type] ?? '🔔';
    }
}

function getAvatarLetter(?string $username) {
    return mb_strtoupper(mb_substr($username ?: "?", 0, 1, 'UTF-8'), 'UTF-8');
}

function getStatusBadge(string $status): string {
    $labels = [
        'open' => 'Открыто',
        'in_progress' => 'В обработке',
        'closed' => 'Решено'
    ];
    $key = isset($labels[$status]) ? $status : 'open';
    $label = $labels[$status] ?? $status;
    return '<span class="ticket-status ' . $key . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>';
}

function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . 'м';
    if ($diff < 86400) return floor($diff / 3600) . 'ч';
    if ($diff < 604800) return floor($diff / 86400) . 'д';
    return date('d.m.Y', $timestamp);
}

$conn->close();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/index.css">
    <title>Поддержка</title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <link rel="stylesheet" href="assets/css/support.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/support.css') ?>">
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= $theme ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main class="support-main">
            <?php
            $form_subject = $support_error !== '' ? (string)($_POST['subject'] ?? '') : '';
            $form_message = $support_error !== '' ? (string)($_POST['message'] ?? '') : '';
            ?>

            <section class="card support-head">
                <span class="support-head-icon"><img src="images/nav-support.svg" alt=""></span>
                <div>
                    <h1>Поддержка</h1>
                    <p class="head-long">Если у вас возникли проблемы или вопросы, напишите нам. Мы постараемся ответить как можно быстрее.</p>
                    <p class="head-short">Ответим как можно быстрее</p>
                </div>
            </section>

            <section class="card support-block">
                <h2><span class="block-ico"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></span>Отправить сообщение</h2>

                <?php if ($support_error !== ""): ?>
                    <div class="support-alert error"><?= htmlspecialchars($support_error, ENT_QUOTES, "UTF-8") ?></div>
                <?php endif; ?>

                <?php if ($support_success !== ""): ?>
                    <div class="support-alert ok"><?= $support_success ?></div>
                <?php endif; ?>

                <form method="POST" class="support-form">
                    <div class="field">
                        <label for="subject">Тема</label>
                        <input type="text" id="subject" name="subject" placeholder="Кратко опишите проблему" value="<?= htmlspecialchars($form_subject, ENT_QUOTES, 'UTF-8') ?>" required>
                    </div>
                    <div class="field">
                        <label for="message">Сообщение</label>
                        <textarea id="message" name="message" placeholder="Опишите вашу проблему подробно..." required><?= htmlspecialchars($form_message, ENT_QUOTES, 'UTF-8') ?></textarea>
                    </div>
                    <div class="form-foot">
                        <span class="form-hint">Не указывайте пароль в обращении</span>
                        <button type="submit" name="send_support">Отправить</button>
                    </div>
                </form>
            </section>

            <section class="card support-block">
                <h2><span class="block-ico"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg></span>Мои обращения</h2>
                <p class="support-note">Ответы, передача в обработку и закрытие обращений выполняются только модерацией.</p>

                <?php if (empty($tickets)): ?>
                    <div class="support-empty">
                        <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>
                        <b>У вас нет обращений</b>
                        Отправьте сообщение выше, и мы свяжемся с вами.
                    </div>
                <?php else: ?>
                    <?php foreach ($tickets as $ticket): ?>
                        <div class="ticket">
                            <div class="ticket-top">
                                <span class="ticket-subject"><?= htmlspecialchars($ticket['subject'], ENT_QUOTES, "UTF-8") ?></span>
                                <span class="ticket-info">
                                    <?= getStatusBadge($ticket['status']) ?>
                                    <span title="<?= htmlspecialchars(date('d.m.Y H:i', strtotime($ticket['created_at'])), ENT_QUOTES, 'UTF-8') ?>"><?= timeAgo($ticket['created_at']) ?></span>
                                </span>
                            </div>
                            <div class="ticket-text"><?= nl2br(htmlspecialchars($ticket['message'], ENT_QUOTES, "UTF-8")) ?></div>
                            <?php if (!empty($ticket['admin_response'])): ?>
                                <div class="ticket-reply">
                                    <div class="ticket-reply-label">Ответ поддержки</div>
                                    <div class="ticket-reply-text"><?= nl2br(htmlspecialchars($ticket['admin_response'], ENT_QUOTES, "UTF-8")) ?></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>

        </main>

        <aside class="right-sidebar">

            <div class="right-card">
                <div class="faq-title">Часто задаваемые вопросы</div>
                <ul class="faq-list">
                    <li class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">Как восстановить пароль?</button>
                        <div class="faq-answer">Откройте страницу входа, нажмите «Забыли пароль?» и следуйте инструкции из письма.</div>
                    </li>
                    <li class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">Как добавить друзей?</button>
                        <div class="faq-answer">Перейдите в раздел «Друзья», найдите пользователя и отправьте ему заявку.</div>
                    </li>
                    <li class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">Как сменить аватар?</button>
                        <div class="faq-answer">Откройте настройки профиля и загрузите новое изображение в разделе аватара.</div>
                    </li>
                    <li class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">Как удалить аккаунт?</button>
                        <div class="faq-answer">Для удаления аккаунта отправьте отдельное обращение в поддержку с подтверждением этого действия.</div>
                    </li>
                </ul>
            </div>

        </aside>

        <div class="site-footer">
            SPACE &copy; <span class="year">2026</span>
        </div>

    </div>

    <script src="assets/js/script.js"></script>

    <script>
    document.querySelectorAll('.faq-question').forEach(function (question) {
        question.addEventListener('click', function () {
            var item = question.closest('.faq-item');
            var isOpen = item.classList.toggle('open');
            question.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    });
    </script>

</body>
</html>
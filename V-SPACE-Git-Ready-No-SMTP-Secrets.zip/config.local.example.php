<?php
declare(strict_types=1);

/* Legacy compatibility shim. Keep all secrets in the ignored .env file. */
require_once __DIR__ . '/includes/env.php';

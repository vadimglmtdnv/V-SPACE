<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
require_once __DIR__ . '/maintenance.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function requireReportsCsrf(): void {
    if (!hash_equals((string)$_SESSION['csrf_token'], (string)($_POST['csrf_token'] ?? ''))) {
        http_response_code(419);
        exit('Invalid request token');
    }
    // Следующий GET (редирект после действия) не считается «заходом на страницу».
    $_SESSION['reports_keep_once'] = true;
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$conn = db_connect();
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
require_once __DIR__ . '/account_state.php';
ensureAccountStateColumns($conn);

$conn->query("
    CREATE TABLE IF NOT EXISTS admin_audit_log (
        id INT(11) NOT NULL AUTO_INCREMENT,
        actor_id INT(11) NOT NULL,
        action VARCHAR(80) NOT NULL,
        entity_type VARCHAR(40) NOT NULL,
        entity_id INT(11) NULL DEFAULT NULL,
        details TEXT NULL,
        ip_address VARCHAR(45) NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX actor_id (actor_id),
        INDEX action (action),
        INDEX created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Тарифы V+: цена (в VS) и скидка. Читает donate.php, менять их можно только здесь.
$conn->query("
    CREATE TABLE IF NOT EXISTS v_plus_plans (
        duration INT UNSIGNED NOT NULL,
        label VARCHAR(50) NOT NULL,
        cost INT UNSIGNED NOT NULL,
        discount_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
        updated_by INT UNSIGNED NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (duration)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    INSERT IGNORE INTO v_plus_plans (duration, label, cost, discount_percent)
    VALUES (30, '1 месяц', 150, 0), (90, '3 месяца', 400, 0), (365, '12 месяцев', 1290, 0)
");
$conn->query("UPDATE v_plus_plans SET label = '12 месяцев' WHERE duration = 365 AND label = '1 год'");

// Разовый перенос цен и скидок из прежней рублёвой таблицы (пока тариф не правили здесь вручную).
try {
    $old_rub_table = $conn->query("SHOW TABLES LIKE 'vplus_rub_plans'");
    if ($old_rub_table && $old_rub_table->num_rows > 0) {
        $conn->query("
            UPDATE v_plus_plans p
            JOIN vplus_rub_plans r ON r.days = p.duration
            SET p.cost = r.cost, p.discount_percent = r.discount_percent, p.label = r.label
            WHERE p.updated_by IS NULL
        ");
    }
} catch (Throwable $e) {
    error_log('reports.php vplus plans migration: ' . $e->getMessage());
}

// Единый баланс — VS. Колонку rub_balance больше не создаём (её удаляет donate.php).
$vs_col = $conn->query("SHOW COLUMNS FROM users LIKE 'v_space_balance'");
if ($vs_col && $vs_col->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN v_space_balance INT UNSIGNED NOT NULL DEFAULT 0");
}
$conn->query("
    CREATE TABLE IF NOT EXISTS v_space_transactions (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NOT NULL,
        operation ENUM('credit', 'debit') NOT NULL,
        amount INT UNSIGNED NOT NULL,
        balance_after INT UNSIGNED NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX idx_v_space_user_created (user_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
// Таблицы тарифов (белый список — имена подставляются в SQL только из него).
const VPLUS_TABLES = [
    'vs' => ['table' => 'v_plus_plans', 'key' => 'duration', 'unit' => 'VS', 'title' => 'Тарифы подписки'],
];
const VPLUS_MAX_COST = 1000000;
const VPLUS_MAX_DISCOUNT = 90;
const VS_TOPUP_MAX = 1000000000; // максимум за одно начисление (баланс — INT UNSIGNED, до ~4,29 млрд)

function writeAdminAuditLog(mysqli $conn, int $actorId, string $action, string $entityType, ?int $entityId = null, string $details = ''): void {
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $stmt = $conn->prepare("
        INSERT INTO admin_audit_log (actor_id, action, entity_type, entity_id, details, ip_address)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("ississ", $actorId, $action, $entityType, $entityId, $details, $ipAddress);
    $stmt->execute();
    $stmt->close();
}

// Колонка для хранения хэша личного PIN-кода консоли (привязан к аккаунту).
function ensureConsolePinColumn(mysqli $conn): void {
    $check = $conn->query("
        SELECT COUNT(*) AS cnt
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = 'users'
          AND column_name = 'console_pin_hash'
    ");
    $exists = $check && (int)($check->fetch_assoc()['cnt'] ?? 0) > 0;
    if (!$exists) {
        $conn->query("ALTER TABLE users ADD COLUMN console_pin_hash VARCHAR(255) NULL DEFAULT NULL AFTER is_admin");
    }
}
ensureConsolePinColumn($conn);

// Защита от перебора PIN-кода: счётчик неудач и время блокировки.
function ensurePinThrottleColumns(mysqli $conn): void {
    $cols = ['console_pin_fails' => 'TINYINT UNSIGNED NOT NULL DEFAULT 0',
             'console_pin_locked_until' => 'INT UNSIGNED NOT NULL DEFAULT 0',
             'console_pin_lock_level' => 'TINYINT UNSIGNED NOT NULL DEFAULT 0'];
    foreach ($cols as $name => $def) {
        $res = $conn->query("SHOW COLUMNS FROM users LIKE '" . $conn->real_escape_string($name) . "'");
        if ($res && $res->num_rows === 0) {
            $conn->query("ALTER TABLE users ADD COLUMN `$name` $def");
        }
    }
}
ensurePinThrottleColumns($conn);

// ============================================================
// ТАБЛИЦА admins: уровни доступа
// 1 — Хелпер, 2 — Администратор, 3 — Основатель, 4 — Разработчик
// ============================================================
const REPORTS_LEVELS = [1 => 'Хелпер', 2 => 'Администратор', 3 => 'Основатель', 4 => 'Разработчик'];

$conn->query("
    CREATE TABLE IF NOT EXISTS admins (
        user_id INT UNSIGNED NOT NULL,
        level TINYINT UNSIGNED NOT NULL DEFAULT 1,
        granted_by INT UNSIGNED NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id),
        INDEX idx_admins_level (level)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
// Перенос прежних админов (users.is_admin = 1): id=1 → Основатель, остальные → Администратор.
$conn->query("
    INSERT IGNORE INTO admins (user_id, level)
    SELECT id, IF(id = 1, 3, 2) FROM users WHERE is_admin = 1
");
// Аккаунт id=1 всегда имеет уровень не ниже «Основатель».
$conn->query("
    INSERT INTO admins (user_id, level)
    SELECT id, 3 FROM users WHERE id = 1
    ON DUPLICATE KEY UPDATE level = GREATEST(level, 3)
");
// users.is_admin остаётся флагом для остальных страниц сайта — держим его в синхроне с admins.
$conn->query("UPDATE users u JOIN admins a ON a.user_id = u.id SET u.is_admin = 1 WHERE u.is_admin = 0");

// Названия действий журнала на русском (в БД хранится технический код).
function reportsActionName(string $action): string {
    static $names = [
        'unlock_panel'          => 'Вход в панель',
        'create_console_pin'    => 'Создание PIN-кода',
        'change_console_pin'    => 'Смена PIN-кода',
        'pin_lockout'           => 'Блокировка по PIN-коду',
        'grant_admin'           => 'Выдача прав',
        'set_admin_level'       => 'Смена уровня',
        'revoke_admin'          => 'Снятие прав',
        'backup_create'         => 'Создание бэкапа',
        'backup_download'       => 'Скачивание бэкапа',
        'backup_restore'        => 'Откат из бэкапа',
        'backup_delete'         => 'Удаление бэкапа',
        'topup_vs'              => 'Начисление VS',
        'withdraw_vs'           => 'Снятие VS',
        'update_vplus_plan'     => 'Изменение тарифа V+',
        'send_vs_space_message' => 'Сообщение от V SPACE',
        'close_ticket'          => 'Закрытие обращения',
        'start_ticket'          => 'Обращение в работу',
        'respond_ticket'        => 'Ответ на обращение',
        'update_report'         => 'Решение по жалобе',
    ];
    return $names[$action] ?? $action;
}

function reportsLevelName(int $level): string {
    return REPORTS_LEVELS[$level] ?? 'Нет доступа';
}
function reportsWelcomeNewAdmin(mysqli $conn, int $serviceAccountId, int $newAdminId, int $level): void {
    if ($serviceAccountId <= 0 || $newAdminId <= 0 || $serviceAccountId === $newAdminId) {
        error_log('Could not welcome newly appointed admin: invalid account IDs.');
        return;
    }

    $friend_stmt = $conn->prepare("
        SELECT id, status
        FROM friend_requests
        WHERE (sender_id = ? AND receiver_id = ?)
           OR (sender_id = ? AND receiver_id = ?)
        LIMIT 1
    ");
    if (!$friend_stmt) {
        error_log('Could not prepare V SPACE friendship lookup: ' . $conn->error);
    } else {
        $friend_stmt->bind_param('iiii', $serviceAccountId, $newAdminId, $newAdminId, $serviceAccountId);
        if (!$friend_stmt->execute()) {
            error_log('Could not look up V SPACE friendship: ' . $friend_stmt->error);
        } else {
            $friend = $friend_stmt->get_result()->fetch_assoc();
            if ($friend) {
                if ($friend['status'] !== 'accepted') {
                    $accept_stmt = $conn->prepare("UPDATE friend_requests SET status = 'accepted' WHERE id = ?");
                    if (!$accept_stmt) {
                        error_log('Could not prepare V SPACE friendship acceptance: ' . $conn->error);
                    } else {
                        $friend_id = (int)$friend['id'];
                        $accept_stmt->bind_param('i', $friend_id);
                        if (!$accept_stmt->execute()) {
                            error_log('Could not accept V SPACE friendship: ' . $accept_stmt->error);
                        }
                        $accept_stmt->close();
                    }
                }
            } else {
                $add_friend_stmt = $conn->prepare("
                    INSERT INTO friend_requests (sender_id, receiver_id, status)
                    VALUES (?, ?, 'accepted')
                ");
                if (!$add_friend_stmt) {
                    error_log('Could not prepare V SPACE friendship creation: ' . $conn->error);
                } else {
                    $add_friend_stmt->bind_param('ii', $serviceAccountId, $newAdminId);
                    if (!$add_friend_stmt->execute()) {
                        error_log('Could not create V SPACE friendship: ' . $add_friend_stmt->error);
                    }
                    $add_friend_stmt->close();
                }
            }
        }
        $friend_stmt->close();
    }

    $profile_stmt = $conn->prepare("SELECT city FROM user_profiles WHERE user_id = ? LIMIT 1");
    if (!$profile_stmt) {
        error_log('Could not prepare V SPACE admin location lookup: ' . $conn->error);
        return;
    }
    $profile_stmt->bind_param('i', $newAdminId);
    if (!$profile_stmt->execute()) {
        error_log('Could not look up V SPACE admin location: ' . $profile_stmt->error);
        $profile_stmt->close();
        return;
    }
    $profile = $profile_stmt->get_result()->fetch_assoc();
    $profile_stmt->close();

    $foreign_cities = [
        'Минск', 'Гомель', 'Брест', 'Гродно', 'Витебск', 'Могилёв',
        'Киев', 'Харьков', 'Одесса', 'Днепр', 'Львов',
        'Астана', 'Алматы', 'Шымкент', 'Ташкент', 'Бишкек', 'Баку', 'Ереван', 'Тбилиси', 'Кишинёв',
        'Хельсинки', 'Таллин', 'Рига', 'Вильнюс', 'Варшава', 'Берлин', 'Прага', 'Тель-Авив',
    ];
    $is_foreign_resident = in_array(trim((string)($profile['city'] ?? '')), $foreign_cities, true);
    $role = reportsLevelName($level);
    $english_role = [1 => 'Helper', 2 => 'Administrator', 3 => 'Founder', 4 => 'Developer'][$level] ?? 'Team member';
    $congratulation = $is_foreign_resident
        ? "Congratulations on your appointment as {$english_role} in the V SPACE team! We wish you success and appreciate your contribution to the community."
        : "Поздравляем с назначением на должность «{$role}» в команде V SPACE! Желаем успехов и благодарим за вклад в развитие сообщества.";
    $message_stmt = $conn->prepare("
        INSERT INTO messages
            (sender_id, receiver_id, message, message_type, is_encrypted, is_read, created_at)
        VALUES (?, ?, ?, 'text', 0, 0, NOW())
    ");
    if (!$message_stmt) {
        error_log('Could not prepare V SPACE admin congratulation: ' . $conn->error);
        return;
    }
    $message_stmt->bind_param('iis', $serviceAccountId, $newAdminId, $congratulation);
    if (!$message_stmt->execute()) {
        error_log('Could not send V SPACE admin congratulation: ' . $message_stmt->error);
        $message_stmt->close();
        return;
    }
    $message_stmt->close();

    $notification_text = $is_foreign_resident
        ? 'V SPACE congratulated you on your appointment'
        : 'Команда V SPACE поздравила вас с назначением';
    $notification_link = 'messages.php?dialog=' . $serviceAccountId;
    $notification_stmt = $conn->prepare("
        INSERT INTO notifications (user_id, sender_id, type, message, link, created_at)
        VALUES (?, ?, 'message', ?, ?, NOW())
    ");
    if (!$notification_stmt) {
        error_log('Could not prepare V SPACE admin congratulation notification: ' . $conn->error);
        return;
    }
    $notification_stmt->bind_param('iiss', $newAdminId, $serviceAccountId, $notification_text, $notification_link);
    if (!$notification_stmt->execute()) {
        error_log('Could not create V SPACE admin congratulation notification: ' . $notification_stmt->error);
    }
    $notification_stmt->close();
}
// Какие уровни актор может выдавать. id=1 и Разработчик — любые, Основатель — Хелпер и Администратор.
function reportsAssignableLevels(int $userId, int $level): array {
    if ($userId === 1 || $level >= 4) return [1, 2, 3, 4];
    if ($level === 3) return [1, 2];
    return [];
}
// Кем актор может управлять (id=1 неприкосновенен, себя менять нельзя).
function reportsCanManage(int $actorId, int $actorLevel, int $targetId, int $targetLevel): bool {
    if ($targetId === 1 || $targetId === $actorId) return false;
    if ($actorId === 1 || $actorLevel >= 4) return true;
    return $actorLevel >= 3 && $targetLevel < $actorLevel;
}

// Получаем данные пользователя
$stmt = $conn->prepare("SELECT id, username, email, avatar, status, last_seen, is_admin, console_pin_hash, console_pin_fails, console_pin_locked_until, console_pin_lock_level FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$admin_level = 0;
$stmt = $conn->prepare("SELECT level FROM admins WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$lvl_row = $stmt->get_result()->fetch_assoc();
$stmt->close();
if ($lvl_row) {
    $admin_level = (int)$lvl_row['level'];
}
$is_admin = $admin_level >= 1;

if (!$is_admin) {
    header("Location: messages.php");
    exit;
}

// ============================================================
// PIN-ЗАЩИТА ВСЕЙ СТРАНИЦЫ
// Пока PIN не введён, сервер вообще не отдаёт содержимое панели.
// PIN спрашивается при каждом заходе на страницу (в т.ч. после входа в аккаунт)
// и повторно после REPORTS_PIN_IDLE_TTL секунд бездействия.
// ============================================================
const REPORTS_PIN_IDLE_TTL = 900;
const REPORTS_PIN_MAX_FAILS = 4;   // неверных вводов подряд до блокировки
// Таймауты растут с каждой следующей блокировкой: 30 мин → 1 ч → 2 ч → 6 ч → 24 ч (дальше всегда 24 ч).
// Уровень сбрасывается после верного ввода PIN-кода.
const REPORTS_PIN_LOCK_STEPS = [1800, 3600, 7200, 21600, 86400];

function reportsPinLockSeconds(int $level): int {
    return REPORTS_PIN_LOCK_STEPS[min(max($level, 0), count(REPORTS_PIN_LOCK_STEPS) - 1)];
}

// 1800 → «30 мин», 3725 → «1 ч 2 мин», 45 → «45 сек»
function reportsPinWaitText(int $sec): string {
    $h = intdiv($sec, 3600);
    $m = intdiv($sec % 3600, 60);
    $s = $sec % 60;
    $parts = [];
    if ($h > 0) $parts[] = $h . ' ч';
    if ($m > 0) $parts[] = $m . ' мин';
    if ($h === 0 && $m === 0 && $s > 0) $parts[] = $s . ' сек';
    return $parts ? implode(' ', $parts) : '1 сек';
}

header('Referrer-Policy: same-origin');
header('Cache-Control: no-store, max-age=0');

$has_console_pin = !empty($user['console_pin_hash']);

function isValidConsolePinFormat(string $pin): bool {
    return (bool)preg_match('/^\d{4}$/', $pin);
}

// Контурные SVG-иконки в стиле панели (24×24, цвет берут у текста через currentColor).
function reportsIcon(string $name, int $size = 18): string {
    static $paths = [
        'gem' => '<path d="M6 3h12l4 6-10 12L2 9Z"/><path d="M11 3 8 9l4 12 4-12-3-6"/><path d="M2 9h20"/>',
        'shield' => '<path d="M12 3 4 6v6c0 4.6 3.2 7.8 8 9 4.8-1.2 8-4.4 8-9V6l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
        'folder' => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>',
        'drive' => '<path d="M22 12H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11Z"/><path d="M6 16h.01M10 16h.01"/>',
        'lock' => '<rect x="4" y="11" width="16" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'alert' => '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
        'restore' => '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
        'trash' => '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6M14 11v6"/>',
        'check' => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
        'crown' => '<path d="m3 8 4.5 4L12 5l4.5 7L21 8l-2 11H5Z"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'archive' => '<rect x="3" y="4" width="18" height="5" rx="1.5"/><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9"/><path d="M10 13h4"/>',
        'wrench' => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
        'flag' => '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><path d="M4 22v-7"/>',
        'terminal' => '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="m7 9 3 3-3 3"/><path d="M13 15h4"/>',
        'wallet' => '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
        'user' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'message' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'target' => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
        'pen' => '<path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/>',
        'inbox' => '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11Z"/>',
        'hourglass' => '<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>',
        'eye' => '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
        'xcircle' => '<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/>',
        'x' => '<path d="M18 6 6 18M6 6l12 12"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
        'refresh' => '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
        'minus' => '<path d="M5 12h14"/>',
        'chevron' => '<path d="m6 9 6 6 6-6"/>',
    ];
    if (!isset($paths[$name])) { return ''; }
    return '<svg class="ico" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
         . 'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>';
}

// Блокировка панели (автоблокировка по бездействию).
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['lock'])) {
    unset($_SESSION['reports_unlock'], $_SESSION['reports_keep_once']);
    header("Location: reports.php");
    exit;
}

// Заход на страницу «снаружи» (из другого раздела, по закладке, после логина) = снова PIN.
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Запоминаем, откуда пришли, чтобы «Отмена» возвращала на ту же страницу, а не всегда в messages.php
    $ret_ref = (string)($_SERVER['HTTP_REFERER'] ?? '');
    $ret_host = (string)parse_url($ret_ref, PHP_URL_HOST);
    $ret_own = (string)parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);
    if ($ret_host !== '' && strcasecmp($ret_host, $ret_own) === 0) {
        $ret_file = basename((string)parse_url($ret_ref, PHP_URL_PATH));
        if (preg_match('/^[A-Za-z0-9_\-]+\.php$/', $ret_file) && $ret_file !== 'reports.php') {
            $ret_query = (string)parse_url($ret_ref, PHP_URL_QUERY);
            $_SESSION['reports_return'] = $ret_file . (($ret_query !== '' && strlen($ret_query) <= 200) ? '?' . $ret_query : '');
        }
    }

    $keep_once = !empty($_SESSION['reports_keep_once']);
    unset($_SESSION['reports_keep_once']);
    if (!$keep_once) {
        $ref = (string)($_SERVER['HTTP_REFERER'] ?? '');
        $ref_host = (string)parse_url($ref, PHP_URL_HOST);
        $ref_path = (string)parse_url($ref, PHP_URL_PATH);
        $own_host = (string)parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);
        $from_self = $ref_host !== '' && strcasecmp($ref_host, $own_host) === 0 && basename($ref_path) === 'reports.php';
        if (!$from_self) {
            unset($_SESSION['reports_unlock']);
        }
    }
}

$pin_unlocked = isset($_SESSION['reports_unlock'])
    && (int)($_SESSION['reports_unlock']['uid'] ?? 0) === $user_id
    && (time() - (int)($_SESSION['reports_unlock']['at'] ?? 0)) <= REPORTS_PIN_IDLE_TTL;
if ($pin_unlocked) {
    $_SESSION['reports_unlock']['at'] = time();
} else {
    unset($_SESSION['reports_unlock']);
}

function renderReportsPinGate(bool $hasPin, string $error, string $username): void {
    $allowed = ['dark', 'light', 'system'];
    $theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed, true) ? $_COOKIE['theme'] : 'dark';
    $token = htmlspecialchars((string)$_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
    $name = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
    http_response_code(200);
    ?><!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <meta name="referrer" content="same-origin">
    <title>Подтверждение доступа</title>
    <link rel="stylesheet" href="assets/css/reports.css">
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body class="pin-gate-body" data-theme="<?= $theme ?>">
    <main class="pin-gate">
        <form method="POST" class="pin-card<?= $error !== '' ? ' has-error' : '' ?>" autocomplete="off" data-welcome="Добро пожаловать, <?= $name ?>!">
            <input type="hidden" name="csrf_token" value="<?= $token ?>">
            <input type="hidden" name="<?= $hasPin ? 'pin_gate_unlock' : 'pin_gate_create' ?>" value="1">
            <div class="pin-icon" aria-hidden="true">
                <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="16" r="1.2" fill="currentColor"/></svg>
            </div>
            <h1><?= $hasPin ? 'Доступ к модерации' : 'Создайте PIN-код' ?></h1>
            <p class="pin-sub">
                <?php if ($hasPin): ?>
                    <?= $name ?>, введите свой PIN-код, чтобы открыть панель.
                <?php else: ?>
                    <?= $name ?>, придумайте личный PIN-код (4 цифры). Он будет запрашиваться при каждом входе в панель.
                <?php endif; ?>
            </p>
            <?php if ($error !== ''): ?>
                <div class="pin-error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($hasPin): ?>
                <label class="pin-label" for="pinInput">PIN-код</label>
                <input class="pin-input" type="password" id="pinInput" name="pin" inputmode="numeric" maxlength="4" autocomplete="off" placeholder="••••" required autofocus>
            <?php else: ?>
                <label class="pin-label" for="pinInput">Новый PIN-код</label>
                <input class="pin-input" type="password" id="pinInput" name="new_pin" inputmode="numeric" pattern="\d{4}" maxlength="4" autocomplete="off" placeholder="••••" required autofocus>
                <label class="pin-label" for="pinConfirm">Повторите PIN-код</label>
                <input class="pin-input" type="password" id="pinConfirm" name="new_pin_confirm" inputmode="numeric" pattern="\d{4}" maxlength="4" autocomplete="off" placeholder="••••" required>
            <?php endif; ?>
            <div class="pin-actions">
                <a href="<?= htmlspecialchars((string)($_SESSION['reports_return'] ?? 'messages.php'), ENT_QUOTES, 'UTF-8') ?>" class="pin-cancel">Отмена</a>
                <button type="submit" class="pin-submit"><?= $hasPin ? 'Открыть панель' : 'Создать и войти' ?></button>
            </div>
        </form>
    </main>
    <script src="assets/js/pin-cells.js"></script>
    <script src="assets/js/pin-gate-anim.js"></script>
    <script>
        (function () {
            if (document.body.dataset.theme === 'system') {
                var mq = window.matchMedia('(prefers-color-scheme: light)');
                var apply = function () { document.body.dataset.theme = mq.matches ? 'light' : 'dark'; };
                apply();
                mq.addEventListener && mq.addEventListener('change', apply);
            }
            document.querySelectorAll('.pin-input').forEach(function (el) {
                el.addEventListener('input', function () { el.value = el.value.replace(/\D/g, '').slice(0, 4); });
            });
        })();
    </script>
</body>
</html>
<?php
    exit;
}

$pin_error = '';

// Первое создание PIN-кода (у аккаунта его ещё нет).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pin_gate_create'])) {
    requireReportsCsrf();
    $new_pin = (string)($_POST['new_pin'] ?? '');
    $new_pin_confirm = (string)($_POST['new_pin_confirm'] ?? '');
    if ($has_console_pin) {
        $pin_error = 'PIN-код уже создан.';
    } elseif (!isValidConsolePinFormat($new_pin)) {
        $pin_error = 'PIN-код должен состоять из 4 цифр.';
    } elseif (!hash_equals($new_pin, $new_pin_confirm)) {
        $pin_error = 'PIN-коды не совпадают.';
    } else {
        $pin_hash = password_hash($new_pin, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET console_pin_hash = ?, console_pin_fails = 0, console_pin_locked_until = 0, console_pin_lock_level = 0 WHERE id = ?");
        $stmt->bind_param("si", $pin_hash, $user_id);
        $stmt->execute();
        $stmt->close();
        writeAdminAuditLog($conn, $user_id, 'create_console_pin', 'user', $user_id, 'Создан личный PIN-код панели');
        session_regenerate_id(true);
        $_SESSION['reports_unlock'] = ['uid' => $user_id, 'at' => time()];
        $_SESSION['reports_keep_once'] = true;
        header("Location: reports.php");
        exit;
    }
}

// Проверка PIN-кода при входе (с защитой от перебора).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pin_gate_unlock'])) {
    requireReportsCsrf();
    // Запрос из assets/js/pin-gate-anim.js (анимация входа): отвечаем JSON, а не редиректом/страницей.
    $pin_ajax = (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch');
    $now = time();
    $locked_until = (int)($user['console_pin_locked_until'] ?? 0);
    if (!$has_console_pin) {
        $pin_error = 'Сначала создайте PIN-код.';
    } elseif ($locked_until > $now) {
        $pin_error = 'Слишком много попыток. Повторите через ' . reportsPinWaitText($locked_until - $now) . '.';
    } else {
        $submitted_pin = (string)($_POST['pin'] ?? '');
        if (password_verify($submitted_pin, $user['console_pin_hash'])) {
            $stmt = $conn->prepare("UPDATE users SET console_pin_fails = 0, console_pin_locked_until = 0, console_pin_lock_level = 0 WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->close();
            writeAdminAuditLog($conn, $user_id, 'unlock_panel', 'user', $user_id, 'Вход в панель по PIN-коду');
            session_regenerate_id(true);
            $_SESSION['reports_unlock'] = ['uid' => $user_id, 'at' => time()];
            $_SESSION['reports_keep_once'] = true;
            if ($pin_ajax) {
                header('Content-Type: application/json; charset=UTF-8');
                echo json_encode(['ok' => true]);
                exit;
            }
            header("Location: reports.php");
            exit;
        }
        $fails = (int)($user['console_pin_fails'] ?? 0) + 1;
        if ($fails >= REPORTS_PIN_MAX_FAILS) {
            $lock_level = (int)($user['console_pin_lock_level'] ?? 0);
            $lock_secs = reportsPinLockSeconds($lock_level);
            $until = $now + $lock_secs;
            $next_level = min($lock_level + 1, 250);
            $stmt = $conn->prepare("UPDATE users SET console_pin_fails = 0, console_pin_locked_until = ?, console_pin_lock_level = ? WHERE id = ?");
            $stmt->bind_param("iii", $until, $next_level, $user_id);
            $stmt->execute();
            $stmt->close();
            writeAdminAuditLog($conn, $user_id, 'pin_lockout', 'user', $user_id, 'Превышено число неверных попыток PIN-кода (блокировка на ' . reportsPinWaitText($lock_secs) . ')');
            $pin_error = 'Слишком много неверных попыток. Вход заблокирован на ' . reportsPinWaitText($lock_secs) . '.';
        } else {
            $stmt = $conn->prepare("UPDATE users SET console_pin_fails = ? WHERE id = ?");
            $stmt->bind_param("ii", $fails, $user_id);
            $stmt->execute();
            $stmt->close();
            $pin_error = 'Неверный PIN-код. Осталось попыток: ' . (REPORTS_PIN_MAX_FAILS - $fails) . '.';
        }
    }
    if ($pin_ajax) {
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['ok' => false, 'error' => $pin_error], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Пока PIN не введён — показываем только экран подтверждения, ничего больше.
if (!$pin_unlocked) {
    renderReportsPinGate($has_console_pin, $pin_error, (string)$user['username']);
}

// ---- Дальше выполняется только после ввода PIN-кода ----

// Права по уровням:
//   1 · Хелпер         — только ответы на обращения в поддержку
//   2 · Администратор  — + жалобы и блокировка аккаунтов
//   3 · Основатель     — + консоль, начисление VS, управление админами
//   4 · Разработчик    — + цены V+, резервные копии (полный доступ)
$is_founder = $admin_level >= 3;      // консоль, начисление VS, управление админами
$can_reports = $admin_level >= 2;     // жалобы (статистика, поиск, смена статуса)
$can_block_accounts = $admin_level >= 2; // блокировка аккаунтов
$can_prices = $admin_level >= 4;      // цены и скидки V+ — только Разработчик

// ============================================================
// РЕЗЕРВНЫЕ КОПИИ — только уровень 4 (Разработчик).
// Создание, скачивание, откат и удаление. Модуль: includes/backup.php
// ============================================================
$can_backup = $admin_level >= 4;
if ($can_backup) {
    require_once __DIR__ . '/includes/backup.php';
}

function reportsBackupRedirect(string $query): void {
    header("Location: reports.php?" . $query . "#backups");
    exit;
}

// Скачивание бэкапа (GET)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['backup_download'])) {
    if (!$can_backup) {
        http_response_code(403);
        exit('Доступ запрещён: резервные копии доступны только уровню 4 (Разработчик).');
    }
    $dl_id = (string)$_GET['backup_download'];
    $dl_path = vsb_find($dl_id);
    if ($dl_path === null) {
        http_response_code(404);
        exit('Бэкап не найден.');
    }
    writeAdminAuditLog($conn, $user_id, 'backup_download', 'backup', null, 'Скачан бэкап ' . $dl_id);
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    $dl_ext = vsb_ext_of($dl_path);
    $dl_types = ['zip' => 'application/zip', 'tar.gz' => 'application/gzip', 'tar' => 'application/x-tar'];
    header('Content-Type: ' . ($dl_types[$dl_ext] ?? 'application/octet-stream'));
    header('Content-Disposition: attachment; filename="' . $dl_id . '.' . $dl_ext . '"');
    header('Content-Length: ' . filesize($dl_path));
    header('X-Content-Type-Options: nosniff');
    readfile($dl_path);
    exit;
}

// Создание / удаление / откат (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && (isset($_POST['backup_create']) || isset($_POST['backup_delete']) || isset($_POST['backup_restore']))) {
    requireReportsCsrf();
    if (!$can_backup) {
        http_response_code(403);
        exit('Доступ запрещён: резервные копии доступны только уровню 4 (Разработчик).');
    }
    $actor = ['id' => $user_id, 'name' => (string)$user['username']];

    try {
        if (isset($_POST['backup_create'])) {
            $b_type = (string)($_POST['backup_type'] ?? 'full');
            $b_label = trim(mb_substr((string)($_POST['backup_label'] ?? ''), 0, 80));
            $b_user = !empty($_POST['backup_userdata']);
            $meta = vsb_create($conn, $b_type, $b_user, $b_label, $actor, 'manual');
            writeAdminAuditLog($conn, $user_id, 'backup_create', 'backup', null,
                'Создан бэкап ' . $meta['id'] . ' (' . vsb_type_name($b_type) . ', ' . vsb_fmt_size((int)$meta['size']) . ')');
            reportsBackupRedirect('backup_msg=' . urlencode('Бэкап создан и проверен: ' . $meta['file'] . ' (' . vsb_fmt_size((int)$meta['size']) . ')'));
        }

        $b_id = (string)($_POST['backup_id'] ?? '');

        if (isset($_POST['backup_delete'])) {
            if (!vsb_delete($b_id)) {
                reportsBackupRedirect('backup_error=' . urlencode('Бэкап не найден.'));
            }
            writeAdminAuditLog($conn, $user_id, 'backup_delete', 'backup', null, 'Удалён бэкап ' . $b_id);
            reportsBackupRedirect('backup_msg=' . urlencode('Бэкап удалён.'));
        }

        // backup_restore
        if (mb_strtoupper(trim((string)($_POST['confirm_text'] ?? ''))) !== 'ОТКАТ') {
            reportsBackupRedirect('backup_error=' . urlencode('Для отката введите слово ОТКАТ.'));
        }
        $r_db = !empty($_POST['restore_db']);
        $r_files = !empty($_POST['restore_files']);
        $res = vsb_restore($conn, $b_id, $r_db, $r_files, $actor);
        writeAdminAuditLog($conn, $user_id, 'backup_restore', 'backup', null,
            'Откат на ' . $b_id . ' (БД: ' . ($r_db ? 'да' : 'нет') . ', файлы: ' . ($r_files ? $res['files'] : 'нет')
            . '). Страховочный бэкап: ' . $res['safety_id']);
        reportsBackupRedirect('backup_msg=' . urlencode(
            'Откат выполнен. Страховочная копия состояния до отката: ' . $res['safety_id']
            . ($r_files ? ' · восстановлено файлов: ' . $res['files'] : '')));
    } catch (Throwable $e) {
        error_log('reports.php backup: ' . $e->getMessage());
        reportsBackupRedirect('backup_error=' . urlencode($e->getMessage()));
    }
}

// Смена PIN-кода (требует ввода текущего).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_console_pin'])) {
    requireReportsCsrf();
    $current_pin = (string)($_POST['current_pin'] ?? '');
    $new_pin = (string)($_POST['new_pin'] ?? '');
    $new_pin_confirm = (string)($_POST['new_pin_confirm'] ?? '');
    $err = '';
    if (!password_verify($current_pin, (string)$user['console_pin_hash'])) {
        $err = 'Текущий PIN-код указан неверно.';
    } elseif (!isValidConsolePinFormat($new_pin)) {
        $err = 'Новый PIN-код должен состоять из 4 цифр.';
    } elseif (!hash_equals($new_pin, $new_pin_confirm)) {
        $err = 'Новые PIN-коды не совпадают.';
    }
    if ($err !== '') {
        header("Location: reports.php?pin_error=" . urlencode($err) . "#security");
        exit;
    }
    $pin_hash = password_hash($new_pin, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET console_pin_hash = ?, console_pin_fails = 0, console_pin_locked_until = 0, console_pin_lock_level = 0 WHERE id = ?");
    $stmt->bind_param("si", $pin_hash, $user_id);
    $stmt->execute();
    $stmt->close();
    writeAdminAuditLog($conn, $user_id, 'change_console_pin', 'user', $user_id, 'PIN-код панели изменён');
    header("Location: reports.php?pin_changed=1#security");
    exit;
}

// Нужно ли раскрыть консоль сразу при загрузке (после отправки сообщения).
$console_should_open = $is_founder && (isset($_GET['console_sent']) || isset($_GET['console_error']));

// Учётная запись сервиса V SPACE: сообщения из консоли отправляются от её имени,
// а не от личного аккаунта основателя.
function ensureVsSpaceServiceAccount(mysqli $conn): ?int {
    $service_username = 'V SPACE';
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param('s', $service_username);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($existing) {
        return (int)$existing['id'];
    }

    $legacy_username = 'VS SPACE';
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param('s', $legacy_username);
    $stmt->execute();
    $legacy = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($legacy) {
        $legacy_id = (int)$legacy['id'];
        $stmt = $conn->prepare("UPDATE users SET username = ? WHERE id = ? AND username = ?");
        $stmt->bind_param('sis', $service_username, $legacy_id, $legacy_username);
        $renamed = $stmt->execute();
        $stmt->close();
        if ($renamed) {
            return $legacy_id;
        }
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param('s', $service_username);
        $stmt->execute();
        $canonical = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $canonical ? (int)$canonical['id'] : $legacy_id;
    }

    // Считываем реальную структуру таблицы users, чтобы создать системный аккаунт,
    // не полагаясь на предположения о её точной схеме.
    $columns = [];
    $colsResult = $conn->query("
        SELECT column_name, is_nullable, column_default, extra
        FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = 'users'
    ");
    if (!$colsResult) {
        return null;
    }
    while ($col = $colsResult->fetch_assoc()) {
        $columns[$col['column_name']] = $col;
    }

    $values = [];
    if (isset($columns['username'])) $values['username'] = $service_username;
    if (isset($columns['email'])) $values['email'] = 'v-space@system.local';
    if (isset($columns['password'])) $values['password'] = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
    if (isset($columns['is_admin'])) $values['is_admin'] = 0;
    if (isset($columns['status'])) $values['status'] = 'offline';
    if (isset($columns['avatar'])) $values['avatar'] = '';

    // Любая другая обязательная колонка без значения по умолчанию получает
    // безопасное пустое значение, чтобы вставка не завершилась ошибкой.
    foreach ($columns as $name => $col) {
        if (array_key_exists($name, $values)) continue;
        if (stripos((string)$col['extra'], 'auto_increment') !== false) continue;
        if ($col['is_nullable'] === 'YES') continue;
        if ($col['column_default'] !== null) continue;
        $values[$name] = '';
    }

    if (empty($values)) {
        return null;
    }

    $columnNames = array_keys($values);
    $columnList = implode(', ', array_map(function ($c) { return "`$c`"; }, $columnNames));
    $placeholders = implode(', ', array_fill(0, count($columnNames), '?'));
    $types = str_repeat('s', count($columnNames));

    $insertStmt = $conn->prepare("INSERT INTO users ($columnList) VALUES ($placeholders)");
    if (!$insertStmt) {
        return null;
    }
    $bindArgs = [$types];
    foreach ($columnNames as $name) {
        $bindArgs[] = &$values[$name];
    }
    call_user_func_array([$insertStmt, 'bind_param'], $bindArgs);
    $ok = $insertStmt->execute();
    $newId = (int)$insertStmt->insert_id;
    $insertStmt->close();

    return $ok ? $newId : null;
}
$vs_space_account_id = $is_founder ? ensureVsSpaceServiceAccount($conn) : null;

$vplus_groups = [];
foreach (VPLUS_TABLES as $cur => $meta) {
    $vplus_groups[$cur] = [];
    $res = $conn->query("SELECT `{$meta['key']}` AS plan_key, label, cost, discount_percent FROM `{$meta['table']}` ORDER BY `{$meta['key']}`");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $vplus_groups[$cur][] = $row;
        }
    }
}

$notifications = [];
$notif_count = 0;
$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar AS sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC
    LIMIT 30
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS count
    FROM notifications
    WHERE user_id = ? AND is_read = 0
      AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
$stmt->close();

$username = $user["username"];
$user_avatar = $user["avatar"] ?? '';
$user_letter = mb_substr($username ?: "А", 0, 1, "UTF-8");
$user_status = $user["status"] ?? 'offline';
$current_user_data = ['id' => $user_id, 'username' => $username, 'avatar' => $user_avatar, 'status' => 'online'];   // для общей шапки

function isOnline(string $status) {
    return $status === 'online';
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

// ============================================================
// ФУНКЦИЯ ДЛЯ ФОРМАТИРОВАНИЯ СООБЩЕНИЙ С ЭМОДЗИ И ФЛАГАМИ
// ============================================================
function formatMessageForReport(string $message) {
    $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    
    // Упоминания
    $message = preg_replace('/@(all|here|everyone)/i', '<span class="mention-special">@$1</span>', $message);
    $message = preg_replace('/@(\w+)/', '<span class="mention-highlight">@$1</span>', $message);
    
    // ===== ФЛАГИ - ОСНОВНАЯ ОБРАБОТКА =====
    // Обработка флагов в формате 🇬🇧 (два региональных индикатора)
    $message = preg_replace_callback(
        '/[\x{1F1E6}-\x{1F1FF}][\x{1F1E6}-\x{1F1FF}]/u',
        function($matches) {
            return '<span class="flag-emoji">' . $matches[0] . '</span>';
        },
        $message
    );
    
    // Также обрабатываем флаги в формате [FLAG:GB] если такие есть
    $message = preg_replace_callback(
        '/\[FLAG:([A-Z]{2})\]/i',
        function($matches) {
            $code = strtoupper($matches[1]);
            $regional = '';
            for ($i = 0; $i < strlen($code); $i++) {
                $regional .= mb_chr(0x1F1E6 + ord($code[$i]) - ord('A'));
            }
            return '<span class="flag-emoji">' . $regional . '</span>';
        },
        $message
    );
    
    // ===== ОБРАБОТКА ФАЙЛОВ =====
    // Аудио
    if (preg_match('/\[AUDIO:(.+?)\]/', $message, $matches)) {
        $text = preg_replace('/\[AUDIO:.+?\]/', '', $message);
        if (empty(trim($text))) {
            $text = '🎤 Голосовое сообщение';
        }
        return trim($text) . ' 🔊 [Аудио]';
    }
    
    // Видео
    if (preg_match('/\[VIDEO:(.+?)\]/', $message, $matches)) {
        $text = preg_replace('/\[VIDEO:.+?\]/', '', $message);
        if (empty(trim($text))) {
            $text = '🎬 Видео';
        }
        return trim($text) . ' 🎬 [Видео]';
    }
    
    // Изображения
    if (preg_match('/\[IMAGE:(.+?)\]/', $message, $matches)) {
        $text = preg_replace('/\[IMAGE:.+?\]/', '', $message);
        if (empty(trim($text))) {
            $text = '🖼 Изображение';
        }
        return trim($text) . ' 🖼 [Изображение]';
    }
    
    return $message;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_vs_space_message'])) {
    requireReportsCsrf();
    if (!$is_founder) {
        http_response_code(403);
        exit('Доступ запрещён: раздел консоли доступен только основателю.');
    }
    if (!$vs_space_account_id) {
        header("Location: reports.php?console_error=" . urlencode("Не удалось подготовить аккаунт V SPACE. Проверьте структуру таблицы users."));
        exit;
    }
    $receiver_id = (int)($_POST['receiver_id'] ?? 0);
    $message_text = trim((string)($_POST['message'] ?? ''));

    if ($receiver_id <= 0 || $receiver_id === $user_id || $receiver_id === $vs_space_account_id) {
        header("Location: reports.php?console_error=" . urlencode("Выберите корректного получателя."));
        exit;
    }
    if ($message_text === '') {
        header("Location: reports.php?console_error=" . urlencode("Введите текст сообщения."));
        exit;
    }
    if (mb_strlen($message_text, 'UTF-8') > 5000) {
        header("Location: reports.php?console_error=" . urlencode("Сообщение не должно быть длиннее 5000 символов."));
        exit;
    }

    $receiver_stmt = $conn->prepare("SELECT id FROM users WHERE id = ?");
    $receiver_stmt->bind_param("i", $receiver_id);
    $receiver_stmt->execute();
    $receiver_exists = $receiver_stmt->get_result()->num_rows > 0;
    $receiver_stmt->close();

    if (!$receiver_exists) {
        header("Location: reports.php?console_error=" . urlencode("Пользователь не найден."));
        exit;
    }

    $message_stmt = $conn->prepare("
        INSERT INTO messages
            (sender_id, receiver_id, message, message_type, is_encrypted, is_read, created_at)
        VALUES (?, ?, ?, 'text', 0, 0, NOW())
    ");
    if (!$message_stmt) {
        header("Location: reports.php?console_error=" . urlencode("Не удалось подготовить отправку сообщения."));
        exit;
    }
    $message_stmt->bind_param("iis", $vs_space_account_id, $receiver_id, $message_text);
    $sent = $message_stmt->execute();
    $message_id = (int)$message_stmt->insert_id;
    $message_stmt->close();

    if (!$sent) {
        header("Location: reports.php?console_error=" . urlencode("Не удалось отправить сообщение."));
        exit;
    }

    $notification_text = "Команда V SPACE отправила вам сообщение";
    $notification_link = "messages.php?dialog=" . $vs_space_account_id;
    $notification_stmt = $conn->prepare("
        INSERT INTO notifications (user_id, sender_id, type, message, link, created_at)
        VALUES (?, ?, 'message', ?, ?, NOW())
    ");
    if ($notification_stmt) {
        $notification_stmt->bind_param("iiss", $receiver_id, $vs_space_account_id, $notification_text, $notification_link);
        $notification_stmt->execute();
        $notification_stmt->close();
    }

    writeAdminAuditLog(
        $conn,
        $user_id,
        'send_vs_space_message',
        'message',
        $message_id,
        'Сообщение от V SPACE отправлено пользователю #' . $receiver_id
    );
    header("Location: reports.php?console_sent=1");
    exit;
}

// Цены и скидки V+ — только уровень 4 (Разработчик).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_vplus_plan'])) {
    requireReportsCsrf();
    if (!$can_prices) {
        http_response_code(403);
        exit('Доступ запрещён: тарифы доступны только уровню «Разработчик».');
    }
    $cur = (string)($_POST['plan_currency'] ?? '');
    if (!isset(VPLUS_TABLES[$cur])) {
        header("Location: reports.php?plans_error=" . urlencode("Неизвестный раздел тарифов.") . "#vplus-prices");
        exit;
    }
    $tbl = VPLUS_TABLES[$cur]['table'];
    $keyCol = VPLUS_TABLES[$cur]['key'];
    $plan_key = (int)($_POST['plan_key'] ?? 0);
    $plan_cost = (int)($_POST['plan_cost'] ?? 0);
    $plan_discount = (int)($_POST['plan_discount'] ?? -1);

    if ($plan_cost < 1 || $plan_cost > VPLUS_MAX_COST) {
        header("Location: reports.php?plans_error=" . urlencode("Цена должна быть от 1 до " . VPLUS_MAX_COST . ".") . "#vplus-prices");
        exit;
    }
    if ($plan_discount < 0 || $plan_discount > VPLUS_MAX_DISCOUNT) {
        header("Location: reports.php?plans_error=" . urlencode("Скидка должна быть от 0 до " . VPLUS_MAX_DISCOUNT . "%.") . "#vplus-prices");
        exit;
    }

    $stmt = $conn->prepare("SELECT cost, discount_percent FROM `$tbl` WHERE `$keyCol` = ?");
    $stmt->bind_param("i", $plan_key);
    $stmt->execute();
    $old_plan = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$old_plan) {
        header("Location: reports.php?plans_error=" . urlencode("Тариф не найден.") . "#vplus-prices");
        exit;
    }

    $stmt = $conn->prepare("UPDATE `$tbl` SET cost = ?, discount_percent = ?, updated_by = ? WHERE `$keyCol` = ?");
    $stmt->bind_param("iiii", $plan_cost, $plan_discount, $user_id, $plan_key);
    $stmt->execute();
    $stmt->close();

    writeAdminAuditLog(
        $conn, $user_id, 'update_vplus_plan', 'vplus_plan', $plan_key,
        '[' . VPLUS_TABLES[$cur]['unit'] . '] тариф #' . $plan_key . ': цена ' . $old_plan['cost'] . '→' . $plan_cost
        . ', скидка ' . $old_plan['discount_percent'] . '%→' . $plan_discount . '%'
    );
    header("Location: reports.php?plans_saved=1#vplus-prices");
    exit;
}

// Пополнение / списание VS у пользователя — Основатель и Разработчик. Пользователь выбирается по ID или имени.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['topup_vs'])) {
    requireReportsCsrf();
    if (!$is_founder) {
        http_response_code(403);
        exit('Доступ запрещён: менять баланс VS могут только Основатель и Разработчик.');
    }
    $target_raw = trim((string)($_POST['target_user'] ?? ''));
    $target_pick = (string)($_POST['target_id'] ?? '');   // ID, выбранный из выпадающего списка
    $amount = (int)($_POST['vs_amount'] ?? 0);
    $vs_mode = (($_POST['vs_mode'] ?? 'credit') === 'debit') ? 'debit' : 'credit';
    if ($target_raw === '' || mb_strlen($target_raw, 'UTF-8') > 60) {
        header("Location: reports.php?topup_error=" . urlencode("Укажите ID или имя пользователя.") . "&vs_mode=" . $vs_mode . "#vs-balance");
        exit;
    }
    if ($amount < 1 || $amount > VS_TOPUP_MAX) {
        header("Location: reports.php?topup_error=" . urlencode("Сумма должна быть от 1 до " . number_format(VS_TOPUP_MAX, 0, ',', ' ') . " VS.") . "&vs_mode=" . $vs_mode . "#vs-balance");
        exit;
    }

    $conn->begin_transaction();
    try {
        if ($target_pick !== '' && ctype_digit($target_pick)) {
            $lookup_id = (int)$target_pick;
            $stmt = $conn->prepare("SELECT id, username, v_space_balance FROM users WHERE id = ? LIMIT 1 FOR UPDATE");
            $stmt->bind_param("i", $lookup_id);
        } elseif (ctype_digit($target_raw)) {
            $lookup_id = (int)$target_raw;
            $stmt = $conn->prepare("SELECT id, username, v_space_balance FROM users WHERE id = ? LIMIT 1 FOR UPDATE");
            $stmt->bind_param("i", $lookup_id);
        } else {
            $stmt = $conn->prepare("SELECT id, username, v_space_balance FROM users WHERE username = ? LIMIT 1 FOR UPDATE");
            $stmt->bind_param("s", $target_raw);
        }
        $stmt->execute();
        $target_row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$target_row) {
            $conn->rollback();
            header("Location: reports.php?topup_error=" . urlencode("Пользователь не найден.") . "&vs_mode=" . $vs_mode . "#vs-balance");
            exit;
        }
        if ((int)$target_row['id'] === (int)$vs_space_account_id) {
            $conn->rollback();
            header("Location: reports.php?topup_error=" . urlencode("Баланс служебного аккаунта V SPACE менять нельзя.") . "&vs_mode=" . $vs_mode . "#vs-balance");
            exit;
        }

        $target_id = (int)$target_row['id'];
        $old_balance = (int)$target_row['v_space_balance'];
        if ($vs_mode === 'debit') {
            if ($amount > $old_balance) {
                $conn->rollback();
                header("Location: reports.php?topup_error=" . urlencode("Нельзя снять " . number_format($amount, 0, ',', ' ') . " VS: у пользователя только " . number_format($old_balance, 0, ',', ' ') . " VS.") . "&vs_mode=" . $vs_mode . "#vs-balance");
                exit;
            }
            $new_balance = $old_balance - $amount;
        } else {
            $new_balance = $old_balance + $amount;
            if ($new_balance > 4294967295) {
                $conn->rollback();
                header("Location: reports.php?topup_error=" . urlencode("Баланс пользователя превысит допустимый максимум.") . "&vs_mode=" . $vs_mode . "#vs-balance");
                exit;
            }
        }

        $stmt = $conn->prepare("UPDATE users SET v_space_balance = ? WHERE id = ?");
        $stmt->bind_param("ii", $new_balance, $target_id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("
            INSERT INTO v_space_transactions (user_id, operation, amount, balance_after)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("isii", $target_id, $vs_mode, $amount, $new_balance);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
        error_log('reports.php topup_vs error: ' . $e->getMessage());
        header("Location: reports.php?topup_error=" . urlencode($vs_mode === 'debit' ? "Не удалось снять VS." : "Не удалось начислить VS.") . "&vs_mode=" . $vs_mode . "#vs-balance");
        exit;
    }

    $fmt = function (int $n): string { return number_format($n, 0, ',', ' '); };
    $verb_log  = $vs_mode === 'debit' ? 'Снято' : 'Начислено';
    $prep_log  = $vs_mode === 'debit' ? 'у пользователя' : 'пользователю';
    writeAdminAuditLog($conn, $user_id, $vs_mode === 'debit' ? 'withdraw_vs' : 'topup_vs', 'user', $target_id,
        $verb_log . ' ' . $amount . ' VS ' . $prep_log . ' ' . $target_row['username'] . ' (#' . $target_id . '), баланс: ' . $new_balance);
    $done = $verb_log . ' ' . $fmt($amount) . ' VS ' . $prep_log . ' ' . $target_row['username'] . ' (#' . $target_id . '). Баланс: ' . $fmt($new_balance) . ' VS.';
    header("Location: reports.php?topup_msg=" . urlencode($done) . "#vs-balance");
    exit;
}

// Подтверждение опасного действия PIN-кодом. Защита от перебора та же, что и при входе в панель:
// общий счётчик неверных попыток и временная блокировка. Возвращает текст ошибки или '' если PIN верный.
function reportsCheckActionPin(mysqli $conn, array $user, int $userId, string $pin): string {
    $now = time();
    $lockedUntil = (int)($user['console_pin_locked_until'] ?? 0);
    if ($lockedUntil > $now) {
        return 'Слишком много неверных попыток. Повторите через ' . reportsPinWaitText($lockedUntil - $now) . '.';
    }
    if (empty($user['console_pin_hash'])) {
        return 'Сначала создайте PIN-код.';
    }
    if (!isValidConsolePinFormat($pin)) {
        return 'Введите PIN-код — 4 цифры.';
    }
    if (password_verify($pin, (string)$user['console_pin_hash'])) {
        if ((int)($user['console_pin_fails'] ?? 0) > 0 || (int)($user['console_pin_lock_level'] ?? 0) > 0) {
            $stmt = $conn->prepare("UPDATE users SET console_pin_fails = 0, console_pin_lock_level = 0 WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $stmt->close();
        }
        return '';
    }
    $fails = (int)($user['console_pin_fails'] ?? 0) + 1;
    if ($fails >= REPORTS_PIN_MAX_FAILS) {
        $lockLevel = (int)($user['console_pin_lock_level'] ?? 0);
        $lockSecs = reportsPinLockSeconds($lockLevel);
        $until = $now + $lockSecs;
        $nextLevel = min($lockLevel + 1, 250);
        $stmt = $conn->prepare("UPDATE users SET console_pin_fails = 0, console_pin_locked_until = ?, console_pin_lock_level = ? WHERE id = ?");
        $stmt->bind_param("iii", $until, $nextLevel, $userId);
        $stmt->execute();
        $stmt->close();
        writeAdminAuditLog($conn, $userId, 'pin_lockout', 'user', $userId, 'Превышено число неверных попыток PIN-кода (выдача прав, блокировка на ' . reportsPinWaitText($lockSecs) . ')');
        return 'Слишком много неверных попыток. PIN-код заблокирован на ' . reportsPinWaitText($lockSecs) . '.';
    }
    $stmt = $conn->prepare("UPDATE users SET console_pin_fails = ? WHERE id = ?");
    $stmt->bind_param("ii", $fails, $userId);
    $stmt->execute();
    $stmt->close();
    return 'Неверный PIN-код. Осталось попыток: ' . (REPORTS_PIN_MAX_FAILS - $fails) . '.';
}

// Управление составом админов (таблица admins): Основатель и Разработчик.
function reportsAdminRedirect(string $query): void {
    header("Location: reports.php?" . $query . "#admins");
    exit;
}
function reportsAdminLevel(mysqli $conn, int $id): int {
    $stmt = $conn->prepare("SELECT level FROM admins WHERE user_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $r ? (int)$r['level'] : 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['grant_admin']) || isset($_POST['set_admin_level']) || isset($_POST['revoke_admin']))) {
    requireReportsCsrf();
    if (!$is_founder) {
        http_response_code(403);
        exit('Доступ запрещён: управлять админами могут Основатель и Разработчик.');
    }
    $assignable = reportsAssignableLevels($user_id, $admin_level);
    $new_level = (int)($_POST['level'] ?? 0);

    if (isset($_POST['grant_admin'])) {
        // Выдача прав подтверждается личным PIN-кодом (проверяем первым, чтобы без PIN ничего не раскрывать).
        $pin_err = reportsCheckActionPin($conn, $user, $user_id, (string)($_POST['grant_pin'] ?? ''));
        if ($pin_err !== '') {
            reportsAdminRedirect("admins_error=" . urlencode($pin_err));
        }
        $target = trim((string)($_POST['admin_target'] ?? ''));
        $row = null;
        $err = '';
        if ($target === '' || mb_strlen($target, 'UTF-8') > 60) {
            $err = 'Укажите ID или имя пользователя.';
        } elseif (!in_array($new_level, $assignable, true)) {
            $err = 'Вы не можете выдавать этот уровень.';
        } else {
            if (ctype_digit($target)) {
                $lookup_id = (int)$target;
                $stmt = $conn->prepare("SELECT id, username FROM users WHERE id = ? LIMIT 1");
                $stmt->bind_param("i", $lookup_id);
            } else {
                $stmt = $conn->prepare("SELECT id, username FROM users WHERE username = ? LIMIT 1");
                $stmt->bind_param("s", $target);
            }
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$row) {
                $err = 'Пользователь не найден.';
            } elseif ((int)$row['id'] === (int)$vs_space_account_id) {
                $err = 'Служебному аккаунту V SPACE права выдавать нельзя.';
            } elseif (reportsAdminLevel($conn, (int)$row['id']) > 0) {
                $err = 'Пользователь уже в списке админов — измените ему уровень.';
            }
        }
        if ($err !== '') {
            reportsAdminRedirect("admins_error=" . urlencode($err));
        }
        $gid = (int)$row['id'];
        $stmt = $conn->prepare("INSERT INTO admins (user_id, level, granted_by) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $gid, $new_level, $user_id);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("UPDATE users SET is_admin = 1 WHERE id = ?");
        $stmt->bind_param("i", $gid);
        $stmt->execute();
        $stmt->close();
        reportsWelcomeNewAdmin($conn, (int)$vs_space_account_id, $gid, $new_level);
        writeAdminAuditLog($conn, $user_id, 'grant_admin', 'user', $gid, 'Выдан уровень ' . $new_level . ' (' . reportsLevelName($new_level) . '): ' . $row['username'] . ' (#' . $gid . ')');
        reportsAdminRedirect("admins_saved=granted");
    }

    $target_id = (int)($_POST['admin_id'] ?? 0);
    $target_level = reportsAdminLevel($conn, $target_id);
    if ($target_level === 0) {
        reportsAdminRedirect("admins_error=" . urlencode('Администратор не найден.'));
    }
    if (!reportsCanManage($user_id, $admin_level, $target_id, $target_level)) {
        reportsAdminRedirect("admins_error=" . urlencode('Вы не можете изменять этого администратора.'));
    }

    if (isset($_POST['set_admin_level'])) {
        if (!in_array($new_level, $assignable, true)) {
            reportsAdminRedirect("admins_error=" . urlencode('Вы не можете выдавать этот уровень.'));
        }
        $stmt = $conn->prepare("UPDATE admins SET level = ?, granted_by = ? WHERE user_id = ?");
        $stmt->bind_param("iii", $new_level, $user_id, $target_id);
        $stmt->execute();
        $stmt->close();
        if ($new_level > $target_level) {
            reportsWelcomeNewAdmin($conn, (int)$vs_space_account_id, $target_id, $new_level);
        }
        writeAdminAuditLog($conn, $user_id, 'set_admin_level', 'user', $target_id, 'Уровень #' . $target_id . ': ' . $target_level . '→' . $new_level . ' (' . reportsLevelName($new_level) . ')');
        reportsAdminRedirect("admins_saved=level");
    }

    // revoke_admin: снимаем права и сбрасываем PIN (новый админ создаст свой).
    $stmt = $conn->prepare("DELETE FROM admins WHERE user_id = ?");
    $stmt->bind_param("i", $target_id);
    $stmt->execute();
    $stmt->close();
    $stmt = $conn->prepare("UPDATE users SET is_admin = 0, console_pin_hash = NULL, console_pin_fails = 0, console_pin_locked_until = 0, console_pin_lock_level = 0 WHERE id = ?");
    $stmt->bind_param("i", $target_id);
    $stmt->execute();
    $stmt->close();
    writeAdminAuditLog($conn, $user_id, 'revoke_admin', 'user', $target_id, 'Сняты права (был уровень ' . $target_level . ') у пользователя #' . $target_id);
    reportsAdminRedirect("admins_saved=revoked");
}

// Управление обращениями поддержки доступно только модерации.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["close_ticket"]) && is_numeric($_POST["close_ticket"])) {
    requireReportsCsrf();
    $ticket_id = (int)$_POST["close_ticket"];
    $stmt = $conn->prepare("UPDATE support_tickets SET status = 'closed', updated_at = NOW() WHERE id = ? AND status <> 'closed'");
    if (!$stmt) {
        header("Location: reports.php?support_error=" . urlencode("Не удалось подготовить закрытие обращения."));
        exit;
    }
    $stmt->bind_param("i", $ticket_id);
    $updated = $stmt->execute();
    $affected_rows = $stmt->affected_rows;
    $stmt->close();
    if ($updated && $affected_rows > 0) {
        writeAdminAuditLog($conn, $user_id, 'close_ticket', 'support_ticket', $ticket_id, 'Обращение закрыто');
    }
    if (!$updated) {
        header("Location: reports.php?support_error=" . urlencode("Ошибка базы данных при закрытии обращения."));
    } elseif ($affected_rows === 0) {
        header("Location: reports.php?support_error=" . urlencode("Обращение уже закрыто или не найдено."));
    } else {
        header("Location: reports.php?support_closed=1");
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["inprogress_ticket"]) && is_numeric($_POST["inprogress_ticket"])) {
    requireReportsCsrf();
    $ticket_id = (int)$_POST["inprogress_ticket"];
    $stmt = $conn->prepare("UPDATE support_tickets SET status = 'in_progress', updated_at = NOW() WHERE id = ? AND status = 'open'");
    if (!$stmt) {
        header("Location: reports.php?support_error=" . urlencode("Не удалось подготовить передачу обращения."));
        exit;
    }
    $stmt->bind_param("i", $ticket_id);
    $updated = $stmt->execute();
    $affected_rows = $stmt->affected_rows;
    $stmt->close();
    if ($updated && $affected_rows > 0) {
        writeAdminAuditLog($conn, $user_id, 'start_ticket', 'support_ticket', $ticket_id, 'Обращение передано в работу');
    }
    if (!$updated) {
        header("Location: reports.php?support_error=" . urlencode("Ошибка базы данных при передаче обращения."));
    } elseif ($affected_rows === 0) {
        header("Location: reports.php?support_error=" . urlencode("Обращение уже передано или не найдено."));
    } else {
        header("Location: reports.php?support_in_progress=1");
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_support_response'])) {
    requireReportsCsrf();
    $ticket_id = (int)($_POST['ticket_id'] ?? 0);
    $response = trim($_POST['response'] ?? '');
    $status = $_POST['ticket_status'] ?? 'open';

    if ($ticket_id > 0 && $response !== '' && in_array($status, ['open', 'in_progress', 'closed'], true)) {
        $stmt = $conn->prepare("UPDATE support_tickets SET admin_response = ?, status = ?, updated_at = NOW() WHERE id = ? AND status <> 'closed'");
        $stmt->bind_param("ssi", $response, $status, $ticket_id);
        $updated = $stmt->execute();
        $affected_rows = $stmt->affected_rows;
        $stmt->close();
        if ($updated && $affected_rows > 0) {
            writeAdminAuditLog($conn, $user_id, 'respond_ticket', 'support_ticket', $ticket_id, 'Ответ поддержки сохранён');
        }
        header("Location: reports.php?" . ($updated && $affected_rows > 0 ? ($status === 'closed' ? "support_closed=1" : "support_success=1") : "support_error=" . urlencode("Решённое обращение нельзя изменить.")));
        exit;
    }

    header("Location: reports.php?support_error=" . urlencode("Заполните ответ и выберите корректный статус."));
    exit;
}

// Обработка действий с жалобами
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    requireReportsCsrf();
    if (!$can_reports) {
        http_response_code(403);
        exit('Доступ запрещён: жалобы доступны с уровня «Администратор».');
    }
    $report_id = isset($_POST['report_id']) ? (int)$_POST['report_id'] : 0;
    $status = isset($_POST['status']) ? trim((string)$_POST['status']) : '';
    $moderator_comment = isset($_POST['moderator_comment']) ? trim((string)$_POST['moderator_comment']) : '';
    
    if ($report_id > 0 && in_array($status, ['pending', 'reviewed', 'resolved', 'rejected'], true)) {
        $stmt = $conn->prepare("UPDATE reports SET status = ?, moderator_comment = ?, moderator_id = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("ssii", $status, $moderator_comment, $user_id, $report_id);
        $updated = $stmt->execute();
        $affected_rows = $stmt->affected_rows;
        $stmt->close();

        if (!$updated) {
            header("Location: reports.php?report_error=" . urlencode("Ошибка базы данных при обновлении жалобы."));
            exit;
        }

        if ($status === 'resolved') {
            $stmt = $conn->prepare("UPDATE reports r JOIN messages m ON r.message_id = m.id SET m.is_hidden = 1 WHERE r.id = ?");
            $stmt->bind_param("i", $report_id);
            $stmt->execute();
            $stmt->close();
        }
        if ($affected_rows > 0) {
            writeAdminAuditLog($conn, $user_id, 'update_report', 'report', $report_id, 'Статус изменён на ' . $status);
        }

        header("Location: reports.php?success=1");
        exit;
    }

    header("Location: reports.php?report_error=" . urlencode("Некорректные данные жалобы: не выбрана жалоба или статус."));
    exit;
}

// Получение всех жалоб
$status_filter = isset($_GET['status']) ? trim((string)$_GET['status']) : 'all';
$search = isset($_GET['search']) ? trim((string)$_GET['search']) : '';

$where = [];
$params = [];
$types = "";

if ($status_filter !== 'all') {
    $where[] = "r.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if (!empty($search)) {
    $where[] = "(u.username LIKE ? OR m.message LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types .= "ss";
}

$where_clause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

$query = "
    SELECT 
        r.id,
        r.reason,
        r.comment,
        r.status,
        r.created_at,
        r.moderator_comment,
        u.username as reported_user,
        reporter.username as reporter_name,
        m.message,
        m.id as message_id,
        m.created_at as message_date
    FROM reports r
    JOIN users u ON r.reported_user_id = u.id
    JOIN users reporter ON r.reporter_id = reporter.id
    JOIN messages m ON r.message_id = m.id
    $where_clause
    ORDER BY 
        CASE r.status 
            WHEN 'pending' THEN 1 
            WHEN 'reviewed' THEN 2 
            ELSE 3 
        END,
        r.created_at DESC
";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$reports = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Статистика
$stats = [];
$stmt = $conn->query("SELECT status, COUNT(*) as count FROM reports GROUP BY status");
while ($row = $stmt->fetch_assoc()) {
    $stats[$row['status']] = $row['count'];
}
$stmt->close();

// Получаем обращения пользователей для модерации.
$support_tickets = [];
$resolved_support_count = 0;
$stmt = $conn->prepare("
    SELECT t.*, u.username, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS display_name, u.email
    FROM support_tickets t
    INNER JOIN users u ON u.id = t.user_id
    LEFT JOIN user_profiles sp ON sp.user_id = u.id
    ORDER BY FIELD(t.status, 'open', 'in_progress', 'closed'), t.created_at DESC
");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $support_tickets[] = $row;
    if ($row['status'] === 'closed') {
        $resolved_support_count++;
    }
}
$stmt->close();

// Считаем количество непрочитанных сообщений
$unread_count = 0;
$unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

// Считаем количество жалоб для бейджа
$pending_reports_count = 0;
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM reports WHERE status = 'pending'");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    $pending = $result->fetch_assoc();
    $pending_reports_count = $pending['count'] ?? 0;
    $stmt->close();
}

$message_recipients = [];
$excluded_recipient_id = $vs_space_account_id ?: 0;
$stmt = $conn->prepare("
    SELECT u.id, u.username, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS display_name, u.email, u.is_admin
    FROM users u
    LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE u.id <> ? AND u.id <> ?
    ORDER BY u.username ASC
");
$stmt->bind_param("ii", $user_id, $excluded_recipient_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $message_recipients[] = $row;
}
$stmt->close();

$audit_logs = [];
$stmt = $conn->prepare("
    SELECT l.*, u.username
    FROM admin_audit_log l
    LEFT JOIN users u ON u.id = l.actor_id
    ORDER BY l.created_at DESC
    LIMIT 100
");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $audit_logs[] = $row;
}
$stmt->close();

$backup_list = [];
$backup_env = ['dir' => '', 'free' => null, 'zip' => class_exists('ZipArchive'), 'format' => 'zip', 'error' => '', 'in_web' => false];
if ($can_backup) {
    $backup_env['format'] = vsb_format();   // zip, а без расширения zip — tar.gz / tar
    try {
        $backup_list = vsb_list();
        $b_dir = vsb_dir();
        $backup_env['dir'] = $b_dir;
        $backup_env['free'] = @disk_free_space($b_dir);
        $b_real = realpath($b_dir) ?: $b_dir;
        $backup_env['in_web'] = strpos(str_replace('\\', '/', $b_real), str_replace('\\', '/', __DIR__) . '/') === 0;
    } catch (Throwable $e) {
        $backup_env['error'] = $e->getMessage();
    }
}

$admins_list = [];
if ($is_founder) {
    $res = $conn->query("
        SELECT u.id, u.username, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS display_name, u.email, a.level,
               (u.console_pin_hash IS NOT NULL AND u.console_pin_hash <> '') AS has_pin
        FROM admins a
        JOIN users u ON u.id = a.user_id
        LEFT JOIN user_profiles sp ON sp.user_id = u.id
        ORDER BY a.level DESC, u.id ASC
    ");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $admins_list[] = $row;
        }
    }
}

$conn->close();

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: reports.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="referrer" content="same-origin">
    <meta name="csrf-token" content="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
    <title>Модерация жалоб</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/reports.css">
<?php if (!empty($can_backup)): ?>
    <link rel="stylesheet" href="assets/css/reports-backup.css">
<?php endif; ?>
    <!-- Подключаем Twemoji для поддержки флагов -->
    <script src="https://cdn.jsdelivr.net/npm/@twemoji/api@latest/dist/twemoji.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var token = document.querySelector('meta[name="csrf-token"]').content;
            document.querySelectorAll('form[method="POST"]').forEach(function (form) {
                if (!form.querySelector('input[name="csrf_token"]')) {
                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'csrf_token';
                    input.value = token;
                    form.appendChild(input);
                }
            });
        });
    </script>
    <style>
        /* Стили для флагов и эмодзи */
        .flag-emoji {
            display: inline-block;
            font-size: 1.4em !important;
            line-height: 1.2;
            vertical-align: middle;
            font-weight: normal;
            font-family: 'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', 'Android Emoji', sans-serif !important;
        }
        .flag-emoji:hover {
            transform: scale(1.2);
        }
        .mention-highlight {
            color: #5865F2;
            background: rgba(88, 101, 242, 0.15);
            padding: 0 4px;
            border-radius: 4px;
            font-weight: 500;
        }
        .mention-special {
            color: #ED4245;
            background: rgba(237, 66, 69, 0.15);
            padding: 0 4px;
            border-radius: 4px;
            font-weight: 600;
        }
        .message-preview-formatted {
            font-size: 14px;
            line-height: 1.7;
            white-space: pre-wrap;
            word-break: break-word;
        }
        .message-preview-formatted .flag-emoji {
            font-size: 1.5em !important;
        }
        .message-preview-formatted img.emoji {
            width: 1.2em;
            height: 1.2em;
            vertical-align: middle;
        }
        
        /* Стили для тёмной темы */
        body[data-theme="dark"] .mention-highlight {
            background: rgba(88, 101, 242, 0.2);
        }
        body[data-theme="dark"] .mention-special {
            background: rgba(237, 66, 69, 0.2);
        }
        
        /* Стили для светлой темы */
        body[data-theme="light"] .mention-highlight {
            background: rgba(88, 101, 242, 0.1);
            color: #4752C4;
        }
        body[data-theme="light"] .mention-special {
            background: rgba(237, 66, 69, 0.1);
            color: #C53030;
        }

    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= $theme ?>">
    
    <!-- ===== ХЕДЕР (как в index.php) ===== -->
    <?php
    $site_header_cosmic = true;
    $hide_moderation_button = true;
    ?>
    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <!-- ===== ГЛАВНЫЙ КОНТЕЙНЕР ===== -->
    <div class="main-container">
        
        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <!-- ===== КОНТЕНТ ===== -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="page-title-block">
                    <h1>Панель модерации</h1>
                    <p class="page-subtitle">Ваш уровень: <span class="badge lvl-<?= $admin_level ?>"><?= $admin_level ?> · <?= htmlspecialchars(reportsLevelName($admin_level), ENT_QUOTES, 'UTF-8') ?></span></p>
                </div>
                <div class="page-actions">
                    <?php if ($user_id === 1): ?>
                        <a href="restart.php" class="restart-site-btn"
                           onclick="return confirm('Включить технический режим на 5 минут?')">
                            <?= reportsIcon('refresh', 16) ?> Тех. перезагрузка · 5 мин
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="flash-stack">
                <?php if (isset($_GET['success'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>Действие выполнено успешно</span></div>
                <?php endif; ?>
                <?php if (isset($_GET['report_error'])): ?>
                    <div class="error-msg"><?= htmlspecialchars($_GET['report_error'], ENT_QUOTES, 'UTF-8') ?></div>
                <?php endif; ?>
                <?php if (isset($_GET['restart'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>Технический рестарт включён на 5 минут. Для владельца сайта сверху отображается таймер.</span></div>
                <?php endif; ?>
            </div>
            
            <?php if ($can_reports): ?>
            <!-- ===== СТАТИСТИКА ===== -->
            <div class="stats-row">
                <div class="stat-card <?= $status_filter === 'all' ? 'active' : '' ?>">
                    <a href="?status=all#reports">
                        <div class="stat-number"><?= array_sum($stats) ?></div>
                        <div class="stat-label"><?= reportsIcon('flag', 16) ?>Всего жалоб</div>
                    </a>
                </div>
                <div class="stat-card pending <?= $status_filter === 'pending' ? 'active' : '' ?>">
                    <a href="?status=pending#reports">
                        <div class="stat-number"><?= $stats['pending'] ?? 0 ?></div>
                        <div class="stat-label"><?= reportsIcon('hourglass', 16) ?>В ожидании</div>
                    </a>
                </div>
                <div class="stat-card reviewed <?= $status_filter === 'reviewed' ? 'active' : '' ?>">
                    <a href="?status=reviewed#reports">
                        <div class="stat-number"><?= $stats['reviewed'] ?? 0 ?></div>
                        <div class="stat-label"><?= reportsIcon('eye', 16) ?>Просмотрены</div>
                    </a>
                </div>
                <div class="stat-card resolved <?= $status_filter === 'resolved' ? 'active' : '' ?>">
                    <a href="?status=resolved#reports">
                        <div class="stat-number"><?= $stats['resolved'] ?? 0 ?></div>
                        <div class="stat-label"><?= reportsIcon('check', 16) ?>Решены</div>
                    </a>
                </div>
                <div class="stat-card rejected <?= $status_filter === 'rejected' ? 'active' : '' ?>">
                    <a href="?status=rejected#reports">
                        <div class="stat-number"><?= $stats['rejected'] ?? 0 ?></div>
                        <div class="stat-label"><?= reportsIcon('xcircle', 16) ?>Отклонены</div>
                    </a>
                </div>
            </div>
            
            <!-- ===== ПОИСК ===== -->
            <div class="search-bar">
                <form method="GET" action="reports.php#reports">
                    <input type="hidden" name="status" value="<?= htmlspecialchars($status_filter) ?>">
                    <span class="search-field"><?= reportsIcon('search', 18) ?><input type="text" name="search" placeholder="Поиск по пользователю или тексту сообщения..." value="<?= htmlspecialchars($search) ?>"></span>
                    <button type="submit" class="search-btn">Найти</button>
                    <?php if (!empty($search)): ?>
                        <a href="?status=<?= htmlspecialchars($status_filter) ?>#reports" class="clear-search" aria-label="Сбросить поиск"><?= reportsIcon('x', 16) ?></a>
                    <?php endif; ?>
                </form>
            </div>
            <?php endif; ?>

            <?php if ($is_founder): ?>
            <section class="admin-console" id="admin-console">
                <div class="admin-console-header">
                    <div>
                        <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('terminal', 20) ?></span>Консоль администратора</h2>
                        <span class="console-hint">Открыть или закрыть: Shift+F12</span>
                    </div>
                    <button type="button" class="console-toggle" id="consoleToggle" aria-expanded="<?= $console_should_open ? 'true' : 'false' ?>" aria-controls="consolePanel">
                        <?= $console_should_open ? 'Скрыть консоль' : 'Открыть консоль' ?>
                    </button>
                </div>

                <div class="console-panel" id="consolePanel" <?= $console_should_open ? '' : 'hidden' ?>>
                    <div class="console-status">● Журналирование включено</div>
                    <?php if (isset($_GET['console_sent'])): ?>
                        <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>Сообщение от команды V SPACE отправлено.</span></div>
                    <?php endif; ?>
                    <?php if (isset($_GET['console_error'])): ?>
                        <div class="error-msg"><?= htmlspecialchars($_GET['console_error'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                    <form method="POST" class="vs-space-message-form">
                        <input type="hidden" name="send_vs_space_message" value="1">
                        <label for="vsSpaceRecipient">Получатель</label>
                        <select id="vsSpaceRecipient" name="receiver_id" required>
                            <option value="">Выберите пользователя</option>
                            <?php foreach ($message_recipients as $recipient): ?>
                                <option value="<?= (int)$recipient['id'] ?>">
                                    <?= htmlspecialchars(($recipient['display_name'] ?? '') !== '' ? $recipient['display_name'] : $recipient['username'], ENT_QUOTES, 'UTF-8') ?>
                                    <?php if (!empty($recipient['email'])): ?>
                                        (<?= htmlspecialchars($recipient['email'], ENT_QUOTES, 'UTF-8') ?>)
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <label for="vsSpaceMessage">Сообщение от V SPACE</label>
                        <textarea id="vsSpaceMessage" name="message" maxlength="5000" rows="4" placeholder="Введите сообщение для пользователя..." required></textarea>
                        <button type="submit" class="console-send-message">Отправить от команды V SPACE</button>
                    </form>
                    <div class="console-summary">
                    <div class="console-stat">
                        <strong><?= count($reports) ?></strong>
                        <span>Жалоб в выборке</span>
                    </div>
                    <div class="console-stat">
                        <strong><?= $pending_reports_count ?></strong>
                        <span>Ожидают решения</span>
                    </div>
                    <div class="console-stat">
                        <strong><?= count($support_tickets) ?></strong>
                        <span>Обращений поддержки</span>
                    </div>
                    <div class="console-stat">
                        <strong><?= count($audit_logs) ?></strong>
                        <span>Последних записей</span>
                    </div>
                    </div>
                    <div class="audit-log" aria-label="Журнал административных действий">
                    <?php if (empty($audit_logs)): ?>
                        <div class="audit-empty">Административных действий пока нет.</div>
                    <?php else: ?>
                        <?php foreach ($audit_logs as $log): ?>
                            <div class="audit-row">
                                <strong><?= htmlspecialchars($log['created_at'], ENT_QUOTES, 'UTF-8') ?></strong>
                                <span title="<?= htmlspecialchars($log['action'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(reportsActionName((string)$log['action']), ENT_QUOTES, 'UTF-8') ?></span>
                                <span><?= htmlspecialchars($log['details'] ?: 'Без описания', ENT_QUOTES, 'UTF-8') ?></span>
                                <span><?= htmlspecialchars($log['username'] ?: 'Система', ENT_QUOTES, 'UTF-8') ?> · <?= htmlspecialchars($log['ip_address'] ?: 'IP неизвестен', ENT_QUOTES, 'UTF-8') ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </div>
                </div>
            </section>
            <?php endif; ?>

            <?php if ($is_founder): ?>
            <!-- ===== АДМИНИСТРАТОРЫ ===== -->
            <?php $assignable_levels = reportsAssignableLevels($user_id, $admin_level); ?>
            <section class="support-moderation-section admins-section" id="admins">
                <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('crown', 20) ?></span>Администраторы</h2>
                <div class="support-ticket-summary">Таблица <code>admins</code> · Всего: <?= count($admins_list) ?>. Нажмите на кнопку — откроется отдельное окно.</div>

                <div class="vsb-actions">
                    <button type="button" class="vsb-action admins-open" data-modal-open="adminsModal">
                        <span class="vsb-sign"><?= reportsIcon('users', 22) ?></span>
                        <span class="vsb-text"><b>Управление админами</b><small>Выдача прав — по PIN-коду · смена уровней · снятие прав</small></span>
                    </button>
                </div>

                <!-- Отдельное окно управления админами -->
                <dialog id="adminsModal" class="vs-modal admins-modal" aria-labelledby="adminsModalTitle">
                    <div class="vs-modal-head">
                        <div class="vs-modal-titles">
                            <h3 id="adminsModalTitle"><?= reportsIcon('crown', 18) ?> Администраторы</h3>
                            <div class="vs-modal-sub">Таблица admins · Всего: <?= count($admins_list) ?></div>
                        </div>
                        <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                    </div>
                    <div class="admins-modal-body">
                        <?php $level_desc = [
                            1 => 'Только отвечает на обращения в поддержку',
                            2 => '+ жалобы и блокировка аккаунтов',
                            3 => '+ консоль, начисление VS, управление админами',
                            4 => '+ цены V+, резервные копии, полный доступ',
                        ]; ?>
                        <div class="level-cards">
                            <?php foreach (REPORTS_LEVELS as $lv => $lname): ?>
                                <div class="level-card lvl-card-<?= $lv ?>">
                                    <span class="badge lvl-<?= $lv ?>"><?= $lv ?> · <?= htmlspecialchars($lname, ENT_QUOTES, 'UTF-8') ?></span>
                                    <span class="level-card-text"><?= htmlspecialchars($level_desc[$lv] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <?php if (isset($_GET['admins_saved'])): ?>
                            <?php $saved_map = ['granted' => 'Права выданы.', 'level' => 'Уровень изменён.', 'revoked' => 'Права сняты.']; ?>
                            <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span><?= htmlspecialchars($saved_map[$_GET['admins_saved']] ?? 'Сохранено.', ENT_QUOTES, 'UTF-8') ?></span></div>
                        <?php endif; ?>
                        <?php if (isset($_GET['admins_error'])): ?>
                            <div class="error-msg"><?= htmlspecialchars($_GET['admins_error'], ENT_QUOTES, 'UTF-8') ?></div>
                        <?php endif; ?>

                        <form method="POST" class="panel-form admin-grant-form" autocomplete="off">
                            <input type="hidden" name="grant_admin" value="1">
                            <label class="grow">Кому выдать (ID или имя пользователя)
                                <input type="text" name="admin_target" list="adminCandidates" maxlength="60" placeholder="Например: 42 или nickname" autocomplete="off" required>
                            </label>
                            <datalist id="adminCandidates">
                                <?php $candidate_shown = 0; foreach ($message_recipients as $cand): ?>
                                    <?php if ((int)$cand['is_admin'] === 0 && $candidate_shown++ < 500): ?>
                                        <option value="<?= htmlspecialchars($cand['username'], ENT_QUOTES, 'UTF-8') ?>">#<?= (int)$cand['id'] ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </datalist>
                            <label>Уровень
                                <select name="level" required>
                                    <?php foreach ($assignable_levels as $lv): ?>
                                        <option value="<?= $lv ?>" <?= $lv === 1 ? 'selected' : '' ?>><?= $lv ?> — <?= htmlspecialchars(reportsLevelName($lv), ENT_QUOTES, 'UTF-8') ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            <div class="admin-grant-pin">
                                <label class="pin-label" for="grantPin"><?= reportsIcon('lock', 14) ?> Ваш PIN-код — подтверждение выдачи прав</label>
                                <input class="pin-input" type="password" id="grantPin" name="grant_pin" inputmode="numeric" maxlength="4" autocomplete="off" placeholder="••••" required>
                            </div>
                            <button type="submit" class="search-btn">Выдать</button>
                        </form>

                        <div class="admin-list">
                            <?php foreach ($admins_list as $adm):
                                $adm_id = (int)$adm['id'];
                                $adm_level = (int)$adm['level'];
                                $adm_letter = mb_strtoupper(mb_substr((string)$adm['username'] ?: '?', 0, 1, 'UTF-8'), 'UTF-8');
                                $adm_manageable = reportsCanManage($user_id, $admin_level, $adm_id, $adm_level); ?>
                                <div class="admin-row">
                                    <div class="admin-avatar"><?= htmlspecialchars($adm_letter, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="admin-info">
                                        <div class="admin-name"><?= htmlspecialchars(($adm['display_name'] ?? '') !== '' ? $adm['display_name'] : $adm['username'], ENT_QUOTES, 'UTF-8') ?><?= $adm_id === $user_id ? ' (вы)' : '' ?></div>
                                        <div class="admin-meta">#<?= $adm_id ?><?php if (!empty($adm['email'])): ?> · <?= htmlspecialchars($adm['email'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?></div>
                                    </div>
                                    <div class="admin-badges">
                                        <span class="badge lvl-<?= $adm_level ?>"><?= $adm_level ?> · <?= htmlspecialchars(reportsLevelName($adm_level), ENT_QUOTES, 'UTF-8') ?></span>
                                        <?php if ((int)$adm['has_pin'] === 1): ?>
                                            <span class="badge badge-ok">PIN задан</span>
                                        <?php else: ?>
                                            <span class="badge badge-warn">PIN не задан</span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($adm_manageable): ?>
                                        <div class="admin-actions">
                                            <form method="POST" class="inline-form level-form">
                                                <input type="hidden" name="admin_id" value="<?= $adm_id ?>">
                                                <select name="level" aria-label="Уровень">
                                                    <?php foreach ($assignable_levels as $lv): ?>
                                                        <option value="<?= $lv ?>" <?= $lv === $adm_level ? 'selected' : '' ?>><?= $lv ?> — <?= htmlspecialchars(reportsLevelName($lv), ENT_QUOTES, 'UTF-8') ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <button type="submit" name="set_admin_level" value="1" class="btn-ghost">Сменить</button>
                                            </form>
                                            <form method="POST" class="inline-form" onsubmit="return confirm('Снять права? Его PIN-код будет сброшен.')">
                                                <input type="hidden" name="admin_id" value="<?= $adm_id ?>">
                                                <button type="submit" name="revoke_admin" value="1" class="btn-danger-ghost">Снять</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </dialog>
            </section>
            <?php endif; ?>

            <?php if ($can_prices): ?>
            <!-- ===== ЦЕНЫ И СКИДКИ V+ ===== -->
            <section class="support-moderation-section vplus-prices" id="vplus-prices">
                <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('gem', 20) ?></span>Цены V+</h2>
                <div class="support-ticket-summary">Скидка применяется к цене автоматически. Нажмите на кнопку — откроется отдельное окно.</div>

                <div class="vsb-actions">
                    <button type="button" class="vsb-action vplus-open" data-modal-open="vplusModal">
                        <span class="vsb-sign"><?= reportsIcon('gem', 22) ?></span>
                        <span class="vsb-text"><b>Тарифы подписки</b><small>Цены и скидки · изменения действуют сразу</small></span>
                    </button>
                </div>

                <!-- Отдельное окно с тарифами -->
                <dialog id="vplusModal" class="vs-modal vplus-modal" aria-labelledby="vplusModalTitle">
                    <div class="vs-modal-head">
                        <div class="vs-modal-titles">
                            <h3 id="vplusModalTitle"><?= reportsIcon('gem', 18) ?> Цены V+</h3>
                            <div class="vs-modal-sub">Скидка применяется к цене автоматически. Изменения действуют сразу.</div>
                        </div>
                        <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                    </div>
                    <div class="vplus-modal-body">
                        <?php if (isset($_GET['plans_saved'])): ?>
                            <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>Сохранено.</span></div>
                        <?php endif; ?>
                        <?php if (isset($_GET['plans_error'])): ?>
                            <div class="error-msg"><?= htmlspecialchars($_GET['plans_error'], ENT_QUOTES, 'UTF-8') ?></div>
                        <?php endif; ?>

                        <?php foreach (VPLUS_TABLES as $cur => $meta): ?>
                            <h3 class="vplus-group-title"><?= htmlspecialchars($meta['title'], ENT_QUOTES, 'UTF-8') ?></h3>
                            <?php foreach ($vplus_groups[$cur] as $plan):
                                $plan_final = max(1, (int)round($plan['cost'] * (100 - (int)$plan['discount_percent']) / 100)); ?>
                                <form method="POST" class="vplus-plan-row">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="save_vplus_plan" value="1">
                                    <input type="hidden" name="plan_currency" value="<?= htmlspecialchars($cur, ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="plan_key" value="<?= (int)$plan['plan_key'] ?>">
                                    <strong class="vplus-plan-name"><?= htmlspecialchars($plan['label'], ENT_QUOTES, 'UTF-8') ?></strong>
                                    <label>Цена, <?= $meta['unit'] ?>
                                        <input type="number" name="plan_cost" min="1" max="<?= VPLUS_MAX_COST ?>" step="1" value="<?= (int)$plan['cost'] ?>" required>
                                    </label>
                                    <label>Скидка, %
                                        <input type="number" name="plan_discount" min="0" max="<?= VPLUS_MAX_DISCOUNT ?>" step="1" value="<?= (int)$plan['discount_percent'] ?>" required>
                                    </label>
                                    <span class="vplus-plan-final">Итог: <?= number_format($plan_final, 0, ',', ' ') ?> <?= $meta['unit'] ?></span>
                                    <button type="submit" class="search-btn">Сохранить</button>
                                </form>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </div>
                </dialog>
            </section>

            <?php endif; ?>

            <?php if ($can_backup): ?>
            <!-- ===== РЕЗЕРВНЫЕ КОПИИ (только уровень 4) ===== -->
            <section class="support-moderation-section backups-section" id="backups">
                <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('shield', 20) ?></span>Резервные копии V SPACE</h2>
                <div class="support-ticket-summary">Доступно только уровню 4 · Разработчик · Всего копий: <?= count($backup_list) ?>. Нажмите на кнопку — откроется отдельное окно.</div>

                <div class="vsb-actions">
                    <button type="button" class="vsb-action backups-open" data-modal-open="backupsModal">
                        <span class="vsb-sign"><?= reportsIcon('shield', 22) ?></span>
                        <span class="vsb-text"><b>Управление копиями</b><small>Создание · скачивание · откат · удаление</small></span>
                    </button>
                </div>

                <!-- Отдельное окно резервных копий -->
                <dialog id="backupsModal" class="vs-modal backups-modal" aria-labelledby="backupsModalTitle">
                    <div class="vs-modal-head">
                        <div class="vs-modal-titles">
                            <h3 id="backupsModalTitle"><?= reportsIcon('shield', 18) ?> Резервные копии V SPACE</h3>
                            <div class="vs-modal-sub">Всего копий: <?= count($backup_list) ?> · формат новых копий: .<?= htmlspecialchars($backup_env['format'], ENT_QUOTES, 'UTF-8') ?></div>
                        </div>
                        <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                    </div>
                    <div class="backups-modal-body">
                <?php if (isset($_GET['backup_msg'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span><?= htmlspecialchars((string)$_GET['backup_msg'], ENT_QUOTES, 'UTF-8') ?></span></div>
                <?php endif; ?>
                <?php if (isset($_GET['backup_error'])): ?>
                    <div class="error-msg"><?= htmlspecialchars((string)$_GET['backup_error'], ENT_QUOTES, 'UTF-8') ?></div>
                <?php endif; ?>
                <?php if ($backup_env['error'] !== ''): ?>
                    <div class="error-msg"><?= htmlspecialchars($backup_env['error'], ENT_QUOTES, 'UTF-8') ?></div>
                <?php endif; ?>
                <?php if ($backup_env['format'] !== 'zip'): ?>
                    <div class="backup-warn"><?= reportsIcon('alert', 18) ?><span class="backup-warn-text">Расширение PHP <code>zip</code> на сервере не включено, поэтому копии сохраняются в формате <code>.<?= htmlspecialchars($backup_env['format'], ENT_QUOTES, 'UTF-8') ?></code><?= $backup_env['format'] === 'tar' ? ' (без сжатия — нет zlib)' : '' ?>. Создание, скачивание и откат работают так же. Чтобы получать <code>.zip</code>, включите <code>extension=zip</code> в php.ini. Ранее созданные <code>.zip</code>-копии открываются только при включённом zip.</span></div>
                <?php endif; ?>

                <div class="backup-info">
                    <span><?= reportsIcon('folder', 16) ?> <code><?= htmlspecialchars(str_replace(str_replace('\\', '/', __DIR__) . '/', '', str_replace('\\', '/', (string)$backup_env['dir'])), ENT_QUOTES, 'UTF-8') ?></code></span>
                    <?php if ($backup_env['free'] !== null && $backup_env['free'] !== false): ?>
                        <span><?= reportsIcon('drive', 16) ?> Свободно: <?= htmlspecialchars(vsb_fmt_size((int)$backup_env['free']), ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>
                    <span><?= reportsIcon('lock', 16) ?> В бэкапе лежат пароли и ключи шифрования (<code>.env</code>) — не передавайте файлы третьим лицам.</span>
                </div>
                <?php if ($backup_env['in_web']): ?>
                    <div class="backup-warn"><?= reportsIcon('alert', 18) ?><span class="backup-warn-text">Папка бэкапов находится внутри сайта. Apache закрывает её файлом <code>.htaccess</code>, но на nginx её нужно закрыть вручную или вынести за сайт: добавьте в <code>.env</code> строку <code>BACKUP_DIR=/путь/вне/сайта</code>.</span></div>
                <?php endif; ?>

                <form method="POST" class="panel-form backup-create-form" action="reports.php#backups">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="backup_create" value="1">
                    <label>Что сохранить
                        <select name="backup_type">
                            <option value="full">Полный — код сайта + база данных</option>
                            <option value="db">Только база данных</option>
                            <option value="code">Только код сайта</option>
                        </select>
                    </label>
                    <label class="grow">Пометка (необязательно)
                        <input type="text" name="backup_label" maxlength="80" placeholder="Например: перед обновлением чата">
                    </label>
                    <label class="backup-check">
                        <input type="checkbox" name="backup_userdata" value="1">
                        <span>Включить загруженные файлы (<code>uploads</code>, <code>storage</code>) — архив будет заметно больше</span>
                    </label>
                    <button type="submit" class="btn-apply"><?= reportsIcon('plus', 18) ?> Создать бэкап</button>
                </form>

                <?php if (!$backup_list): ?>
                    <div class="backup-empty"><span class="backup-empty-ico"><?= reportsIcon('archive', 30) ?></span>Резервных копий пока нет. Создайте первую — например, перед любым обновлением сайта.</div>
                <?php else: ?>
                    <div class="backup-table-wrap">
                    <table class="backup-table">
                        <thead>
                            <tr><th>Дата</th><th>Тип</th><th>Пометка</th><th>Размер</th><th>Кто</th><th>Действия</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($backup_list as $bk_idx => $bk):
                            $bk_id = (string)$bk['id'];
                            $bk_type = (string)$bk['type'];
                            $bk_ts = strtotime((string)$bk['created_at']);
                            $bk_origin = (string)($bk['origin'] ?? 'manual');
                        ?>
                            <tr>
                                <td><?= $bk_ts ? htmlspecialchars(date('d.m.Y H:i', $bk_ts), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                                <td>
                                    <span class="badge bk-type-<?= htmlspecialchars($bk_type, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(vsb_type_name($bk_type), ENT_QUOTES, 'UTF-8') ?></span>
                                    <?php if (!empty($bk['includes_userdata'])): ?><span class="bk-tag">+ uploads</span><?php endif; ?>
                                    <?php if ($bk_origin === 'auto'): ?><span class="bk-tag">авто · перед откатом</span><?php endif; ?>
                                    <?php if ($bk_origin === 'cron'): ?><span class="bk-tag">по расписанию</span><?php endif; ?>
                                </td>
                                <td class="bk-label"><?= htmlspecialchars((string)($bk['label'] ?? ''), ENT_QUOTES, 'UTF-8') ?: '—' ?></td>
                                <td><?= htmlspecialchars(vsb_fmt_size((int)$bk['size']), ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars((string)($bk['created_by_name'] ?? '') !== '' ? (string)$bk['created_by_name'] : '—', ENT_QUOTES, 'UTF-8') ?></td>
                                <td class="bk-actions">
                                    <a class="btn-ghost" href="reports.php?backup_download=<?= urlencode($bk_id) ?>"><?= reportsIcon('download', 16) ?> Скачать</a>
                                    <button type="button" class="btn-ghost" data-modal-open="bkRestore<?= (int)$bk_idx ?>"><?= reportsIcon('restore', 16) ?> Откат</button>
                                    <dialog id="bkRestore<?= (int)$bk_idx ?>" class="vs-modal bk-modal" aria-labelledby="bkRestore<?= (int)$bk_idx ?>Title">
                                        <div class="vs-modal-head">
                                            <div class="vs-modal-titles">
                                                <h3 id="bkRestore<?= (int)$bk_idx ?>Title"><?= reportsIcon('restore', 18) ?> Откат из резервной копии</h3>
                                                <div class="vs-modal-sub"><?= $bk_ts ? htmlspecialchars(date('d.m.Y H:i', $bk_ts), ENT_QUOTES, 'UTF-8') : '' ?> · <?= htmlspecialchars(vsb_type_name($bk_type), ENT_QUOTES, 'UTF-8') ?></div>
                                            </div>
                                            <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                                        </div>
                                        <div class="bk-modal-body">
                                            <form method="POST" class="bk-restore-form" action="reports.php#backups">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="backup_restore" value="1">
                                            <input type="hidden" name="backup_id" value="<?= htmlspecialchars($bk_id, ENT_QUOTES, 'UTF-8') ?>">
                                            <p class="bk-restore-note">Сайт на время отката уйдёт в техрежим. Перед откатом автоматически создаётся копия текущего состояния — вы сможете вернуться обратно.</p>
                                            <?php if ($bk_type !== 'code'): ?>
                                                <label class="backup-check"><input type="checkbox" name="restore_db" value="1" checked> <span>Восстановить базу данных (журнал действий админов не затрагивается)</span></label>
                                            <?php endif; ?>
                                            <?php if ($bk_type !== 'db'): ?>
                                                <label class="backup-check"><input type="checkbox" name="restore_files" value="1" checked> <span>Восстановить файлы сайта (<code>.env</code> не перезаписывается)</span></label>
                                            <?php endif; ?>
                                            <label>Для подтверждения введите <b>ОТКАТ</b>
                                                <input type="text" name="confirm_text" autocomplete="off" placeholder="ОТКАТ" required>
                                            </label>
                                            <div class="vs-modal-foot-row"><button type="button" class="btn-ghost" data-modal-close>Отмена</button><button type="submit" class="btn-danger-solid">Выполнить откат</button></div>
                                        </form>
                                        </div>
                                    </dialog>
                                    <form method="POST" class="bk-inline" action="reports.php#backups" onsubmit="return confirm('Удалить этот бэкап безвозвратно?')">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                        <input type="hidden" name="backup_delete" value="1">
                                        <input type="hidden" name="backup_id" value="<?= htmlspecialchars($bk_id, ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="submit" class="btn-danger-ghost" title="Удалить бэкап" aria-label="Удалить бэкап"><?= reportsIcon('trash', 16) ?></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>

                <div class="backup-hint">
                    Автоматически по расписанию: добавьте в cron <code>php backup_cron.php</code> (только БД) или <code>php backup_cron.php full</code>.
                    Откат не удаляет файлы и таблицы, появившиеся после бэкапа, — он только возвращает сохранённое.
                </div>
                    </div>
                </dialog>
            </section>
            <?php endif; ?>

            <?php if ($is_founder): ?>
            <!-- ===== БАЛАНС VS ПОЛЬЗОВАТЕЛЯ (ОТДЕЛЬНАЯ ПАНЕЛЬ) ===== -->
            <section class="support-moderation-section vs-balance-section" id="vs-balance">
                <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('wallet', 20) ?></span>Баланс VS пользователя</h2>
                <div class="support-ticket-summary">Пополнение и снятие VS. Нажмите на операцию — откроется отдельное окно.</div>

                <?php if (isset($_GET['topup_msg'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span><?= htmlspecialchars($_GET['topup_msg'], ENT_QUOTES, 'UTF-8') ?></span></div>
                <?php endif; ?>

                <div class="vsb-actions">
                    <button type="button" class="vsb-action vsb-credit" data-topup-open="credit">
                        <span class="vsb-sign"><?= reportsIcon('plus', 22) ?></span>
                        <span class="vsb-text"><b>Пополнить</b><small>Начислить VS пользователю</small></span>
                    </button>
                    <button type="button" class="vsb-action vsb-debit" data-topup-open="debit">
                        <span class="vsb-sign"><?= reportsIcon('minus', 22) ?></span>
                        <span class="vsb-text"><b>Снять</b><small>Списать VS с баланса пользователя</small></span>
                    </button>
                </div>

                <!-- Отдельное окно операции -->
                <dialog id="topupModal" class="vs-modal topup-modal" aria-labelledby="topupModalTitle">
                    <div class="vs-modal-head">
                        <div class="vs-modal-titles">
                            <h3 id="topupModalTitle">Пополнение баланса VS</h3>
                            <div class="vs-modal-sub">Выберите пользователя и сумму</div>
                        </div>
                        <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                    </div>
                    <div class="topup-modal-body">
                        <?php if (isset($_GET['topup_error'])): ?>
                            <div class="error-msg"><?= htmlspecialchars($_GET['topup_error'], ENT_QUOTES, 'UTF-8') ?></div>
                        <?php endif; ?>
                        <form method="POST" class="panel-form topup-form" id="topupForm" data-mode="credit" novalidate>
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="topup_vs" value="1">
                    <input type="hidden" name="vs_mode" id="topupMode" value="credit">
                    <input type="hidden" name="target_id" id="topupTargetId" value="">

                    <div class="topup-modes" role="group" aria-label="Операция">
                        <button type="button" class="topup-mode is-active" data-mode="credit"><?= reportsIcon('plus', 15) ?> Пополнить</button>
                        <button type="button" class="topup-mode" data-mode="debit"><?= reportsIcon('minus', 15) ?> Снять</button>
                    </div>

                    <div class="field grow">
                        <span class="field-label" id="topupTargetLabel">Пользователь (ID или имя)</span>
                        <div class="user-combo" id="topupCombo">
                            <input type="text" name="target_user" id="topupTarget" maxlength="60" placeholder="Например: 42 или nickname" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="topupList" aria-labelledby="topupTargetLabel" required>
                            <button type="button" class="user-combo-toggle" id="topupToggle" tabindex="-1" aria-label="Показать список"><?= reportsIcon('chevron', 16) ?></button>
                            <ul class="user-combo-list" id="topupList" role="listbox" hidden>
                                <?php foreach (array_slice($message_recipients, 0, 500) as $cand): ?>
                                    <li role="option" data-id="<?= (int)$cand['id'] ?>" data-name="<?= htmlspecialchars($cand['username'], ENT_QUOTES, 'UTF-8') ?>">
                                        <span class="uc-name"><?= htmlspecialchars(($cand['display_name'] ?? '') !== '' ? $cand['display_name'] : $cand['username'], ENT_QUOTES, 'UTF-8') ?></span>
                                        <span class="uc-id">#<?= (int)$cand['id'] ?></span>
                                    </li>
                                <?php endforeach; ?>
                                <li class="user-combo-empty" hidden>Никого не найдено — можно ввести ID вручную</li>
                            </ul>
                        </div>
                    </div>
                    <label>Сумма, VS
                        <input type="number" name="vs_amount" id="topupAmount" min="1" max="<?= VS_TOPUP_MAX ?>" step="1" placeholder="0" required>
                        <span class="field-hint" id="topupHint" hidden></span>
                    </label>
                    <button type="submit" class="search-btn" id="topupSubmit">Пополнить</button>
                    <div class="topup-chips" role="group" aria-label="Быстрый выбор суммы">
                        <?php foreach ([100, 500, 1000, 5000] as $chip): ?>
                            <button type="button" class="chip" data-amount="<?= $chip ?>"><span class="chip-sign">+</span><?= number_format($chip, 0, ',', ' ') ?></button>
                        <?php endforeach; ?>
                    </div>
                </form>
                    </div>
                </dialog>
            </section>
            <?php endif; ?>

            <section class="support-moderation-section" id="support">
                <?php
                $tk_names = ['open' => 'Открыто', 'in_progress' => 'В обработке', 'closed' => 'Решено'];
                $tk_csrf = htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');

                // Активные — в основном списке. Решённые («closed») уходят в архив и из списка пропадают.
                $tk_active = [];
                $tk_archive = [];
                foreach ($support_tickets as $tk_c) {
                    if ($tk_c['status'] === 'closed') { $tk_archive[] = $tk_c; } else { $tk_active[] = $tk_c; }
                }
                usort($tk_archive, function ($a, $b) {
                    return strcmp((string)($b['updated_at'] ?? $b['created_at'] ?? ''), (string)($a['updated_at'] ?? $a['created_at'] ?? ''));
                });
                $tk_archive_limit = 200;
                $tk_archive_shown = array_slice($tk_archive, 0, $tk_archive_limit);
                $tk_counts = ['open' => 0, 'in_progress' => 0];
                foreach ($tk_active as $tk_c) {
                    if (isset($tk_counts[$tk_c['status']])) { $tk_counts[$tk_c['status']]++; }
                }

                // Разметка одной карточки (+ её окна диалога)
                $tk_render = function (array $ticket) use ($tk_names, $tk_csrf): string {
                    ob_start();
                    $tk_id = (int)$ticket['id'];
                        $tk_status = (string)$ticket['status'];
                        $tk_status_name = $tk_names[$tk_status] ?? 'Открыто';
                        $tk_uid = (int)($ticket['user_id'] ?? 0);
                        $tk_user = (string)(($ticket['display_name'] ?? '') !== '' ? $ticket['display_name'] : $ticket['username']);
                        $tk_letter = mb_strtoupper(mb_substr($tk_user !== '' ? $tk_user : '?', 0, 1, 'UTF-8'), 'UTF-8');
                        $tk_ts = !empty($ticket['created_at']) ? strtotime((string)$ticket['created_at']) : false;
                        $tk_date = $tk_ts ? date('d.m.Y H:i', $tk_ts) : '';
                        $tk_has_reply = !empty($ticket['admin_response']);
                        $tk_preview = mb_strimwidth(preg_replace('/\s+/u', ' ', (string)$ticket['message']), 0, 140, '…', 'UTF-8');
                        $tk_modal_id = 'tkModal' . $tk_id;
                        $tk_cts = !empty($ticket['updated_at']) ? strtotime((string)$ticket['updated_at']) : false;
                        $tk_closed_date = $tk_cts ? date('d.m.Y H:i', $tk_cts) : '';
                    ?>
                    <article class="tk-card tk-<?= htmlspecialchars($tk_status, ENT_QUOTES, 'UTF-8') ?>" data-status="<?= htmlspecialchars($tk_status, ENT_QUOTES, 'UTF-8') ?>">
                            <div class="tk-avatar"><?= htmlspecialchars($tk_letter, ENT_QUOTES, 'UTF-8') ?></div>
                            <div class="tk-body">
                                <div class="tk-top">
                                    <span class="tk-id">#<?= $tk_id ?></span>
                                    <span class="tk-subject"><?= htmlspecialchars((string)$ticket['subject'], ENT_QUOTES, 'UTF-8') ?></span>
                                    <span class="status-pill status-<?= htmlspecialchars($tk_status, ENT_QUOTES, 'UTF-8') ?>"><?= $tk_status_name ?></span>
                                </div>
                                <div class="tk-preview"><?= htmlspecialchars($tk_preview, ENT_QUOTES, 'UTF-8') ?></div>
                                <div class="tk-meta">
                                    <span><?= reportsIcon('user', 14) ?> <?= htmlspecialchars($tk_user, ENT_QUOTES, 'UTF-8') ?><?php if ($tk_uid > 0): ?> <span class="tk-uid">ID <?= $tk_uid ?></span><?php endif; ?></span>
                                    <?php if ($tk_date !== ''): ?><span><?= reportsIcon('clock', 14) ?> <?= $tk_date ?></span><?php endif; ?>
                                    <?php if ($tk_has_reply): ?><span class="tk-replied"><?= reportsIcon('message', 14) ?> Есть ответ</span><?php endif; ?>
                                    <?php if ($tk_status === 'closed' && $tk_closed_date !== ''): ?><span><?= reportsIcon('archive', 14) ?> Закрыто <?= $tk_closed_date ?></span><?php endif; ?>
                                </div>
                            </div>
                            <button type="button" class="tk-dialog-btn" data-modal-open="<?= $tk_modal_id ?>"><?= $tk_status === 'closed' ? 'Просмотр' : 'Открыть диалог' ?></button>

                            <!-- Отдельное окно диалога -->
                            <dialog id="<?= $tk_modal_id ?>" class="vs-modal tk-modal" aria-labelledby="<?= $tk_modal_id ?>Title">
                                <div class="vs-modal-head">
                                    <div class="vs-modal-titles">
                                        <h3 id="<?= $tk_modal_id ?>Title"><?= htmlspecialchars((string)$ticket['subject'], ENT_QUOTES, 'UTF-8') ?></h3>
                                        <div class="vs-modal-sub tk-ids">
                                            <span class="tk-chip" title="Номер тикета">Тикет #<?= $tk_id ?></span>
                                            <?php if ($tk_uid > 0): ?><span class="tk-chip" title="Номер аккаунта (ID)">Аккаунт #<?= $tk_uid ?></span><?php endif; ?>
                                            <span class="tk-ids-text">
                                                <?= htmlspecialchars($tk_user, ENT_QUOTES, 'UTF-8') ?>
                                                <?php if (!empty($ticket['email'])): ?> · <?= htmlspecialchars((string)$ticket['email'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                                                <?php if ($tk_date !== ''): ?> · <?= $tk_date ?><?php endif; ?>
                                            </span>
                                        </div>
                                    </div>
                                    <span class="status-pill status-<?= htmlspecialchars($tk_status, ENT_QUOTES, 'UTF-8') ?>"><?= $tk_status_name ?></span>
                                    <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                                </div>

                                <div class="tk-thread">
                                    <div class="tk-msg tk-msg-user">
                                        <div class="tk-msg-avatar"><?= htmlspecialchars($tk_letter, ENT_QUOTES, 'UTF-8') ?></div>
                                        <div class="tk-msg-bubble">
                                            <div class="tk-msg-author"><?= htmlspecialchars($tk_user, ENT_QUOTES, 'UTF-8') ?><?php if ($tk_uid > 0): ?> <small>#<?= $tk_uid ?></small><?php endif; ?><?php if ($tk_date !== ''): ?> <small><?= $tk_date ?></small><?php endif; ?></div>
                                            <div class="tk-msg-text"><?= nl2br(htmlspecialchars((string)$ticket['message'], ENT_QUOTES, 'UTF-8')) ?></div>
                                        </div>
                                    </div>
                                    <?php if ($tk_has_reply): ?>
                                        <div class="tk-msg tk-msg-mod">
                                            <div class="tk-msg-avatar"><?= reportsIcon('shield', 16) ?></div>
                                            <div class="tk-msg-bubble">
                                                <div class="tk-msg-author">Ответ модерации</div>
                                                <div class="tk-msg-text"><?= nl2br(htmlspecialchars((string)$ticket['admin_response'], ENT_QUOTES, 'UTF-8')) ?></div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($tk_status === 'closed'): ?>
                                        <div class="tk-system"><?= reportsIcon('check', 15) ?> Обращение закрыто и перенесено в архив</div>
                                    <?php endif; ?>
                                </div>

                                <?php if ($tk_status !== 'closed'): ?>
                                <div class="vs-modal-foot">
                                    <form method="POST" class="tk-reply-form">
                                        <input type="hidden" name="csrf_token" value="<?= $tk_csrf ?>">
                                        <input type="hidden" name="ticket_id" value="<?= $tk_id ?>">
                                        <label class="tk-reply-label" for="tkResp<?= $tk_id ?>"><?= $tk_has_reply ? 'Новый ответ (заменит предыдущий)' : 'Ваш ответ пользователю' ?></label>
                                        <textarea id="tkResp<?= $tk_id ?>" name="response" rows="4" placeholder="Напишите ответ…  (Ctrl+Enter — отправить)" required><?= htmlspecialchars($ticket['admin_response'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                                        <div class="tk-reply-row">
                                            <select name="ticket_status" aria-label="Статус после ответа">
                                                <option value="open" <?= $tk_status === 'open' ? 'selected' : '' ?>>Статус: Открыто</option>
                                                <option value="in_progress" <?= $tk_status === 'in_progress' ? 'selected' : '' ?>>Статус: В обработке</option>
                                                <option value="closed">Статус: Решено</option>
                                            </select>
                                            <button type="submit" name="send_support_response" class="search-btn">Отправить ответ</button>
                                        </div>
                                    </form>
                                    <div class="tk-actions">
                                        <?php if ($tk_status === 'open'): ?>
                                            <form method="POST" class="inline-form">
                                                <input type="hidden" name="csrf_token" value="<?= $tk_csrf ?>">
                                                <button type="submit" class="tk-btn tk-btn-progress" name="inprogress_ticket" value="<?= $tk_id ?>">Передать в работу</button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="POST" class="inline-form" onsubmit="return confirm('Закрыть обращение?')">
                                            <input type="hidden" name="csrf_token" value="<?= $tk_csrf ?>">
                                            <button type="submit" class="tk-btn tk-btn-close" name="close_ticket" value="<?= $tk_id ?>">Закрыть обращение</button>
                                        </form>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </dialog>
                        </article>
                    <?php
                    return ob_get_clean();
                };
                ?>
                <div class="tk-head">
                    <div>
                        <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('wrench', 20) ?></span>Обращения в поддержку</h2>
                        <div class="support-ticket-summary">
                            Активных: <?= count($tk_active) ?> · В архиве: <?= count($tk_archive) ?>
                        </div>
                    </div>
                    <div class="tk-head-tools">
                        <?php if (!empty($tk_active)): ?>
                        <div class="tk-filters" role="group" aria-label="Фильтр обращений">
                            <button type="button" class="tk-filter is-active" data-filter="all">Все <span><?= count($tk_active) ?></span></button>
                            <button type="button" class="tk-filter" data-filter="open">Открытые <span><?= $tk_counts['open'] ?></span></button>
                            <button type="button" class="tk-filter" data-filter="in_progress">В работе <span><?= $tk_counts['in_progress'] ?></span></button>
                        </div>
                        <?php endif; ?>
                        <button type="button" class="tk-archive-btn" data-modal-open="tkArchive"><?= reportsIcon('archive', 16) ?> Архив <span><?= count($tk_archive) ?></span></button>
                    </div>
                </div>

                <?php if (isset($_GET['support_success'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>Ответ поддержки сохранён.</span></div>
                <?php endif; ?>
                <?php if (isset($_GET['support_closed'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>Обращение закрыто и перенесено в архив.</span></div>
                <?php endif; ?>
                <?php if (isset($_GET['support_in_progress'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>Обращение передано в работу.</span></div>
                <?php endif; ?>
                <?php if (isset($_GET['support_error'])): ?>
                    <div class="error-msg"><?= htmlspecialchars($_GET['support_error'], ENT_QUOTES, 'UTF-8') ?></div>
                <?php endif; ?>

                <?php if (empty($tk_active)): ?>
                    <div class="tk-empty">
                        <div class="tk-empty-icon<?= empty($tk_archive) ? '' : ' is-ok' ?>"><?= reportsIcon(empty($tk_archive) ? 'inbox' : 'check', 30) ?></div>
                        <div><?= empty($tk_archive) ? 'Обращений в поддержку пока нет.' : 'Активных обращений нет — все решены и лежат в архиве.' ?></div>
                    </div>
                <?php else: ?>
                    <div class="tk-list" id="tkList">
                        <?php foreach ($tk_active as $ticket) { echo $tk_render($ticket); } ?>
                        <div class="tk-empty tk-empty-filter" id="tkEmptyFilter" hidden>В этой категории обращений нет.</div>
                    </div>
                <?php endif; ?>

                <!-- Архив решённых обращений -->
                <dialog id="tkArchive" class="vs-modal tk-archive" aria-labelledby="tkArchiveTitle">
                    <div class="vs-modal-head">
                        <div class="vs-modal-titles">
                            <h3 id="tkArchiveTitle"><?= reportsIcon('archive', 18) ?> Архив обращений</h3>
                            <div class="vs-modal-sub">Решённые обращения · <?= count($tk_archive) ?></div>
                        </div>
                        <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                    </div>
                    <?php if (empty($tk_archive)): ?>
                        <div class="tk-archive-body">
                            <div class="tk-empty"><div class="tk-empty-icon"><?= reportsIcon('archive', 30) ?></div><div>Архив пуст. Сюда попадают обращения со статусом «Решено».</div></div>
                        </div>
                    <?php else: ?>
                        <div class="tk-archive-search">
                            <input type="text" id="tkArchiveSearch" placeholder="Поиск: номер тикета, ID, имя, тема…" autocomplete="off">
                        </div>
                        <div class="tk-archive-body" id="tkArchiveList">
                            <?php foreach ($tk_archive_shown as $ticket) { echo $tk_render($ticket); } ?>
                            <div class="tk-empty" id="tkArchiveEmpty" hidden>Ничего не найдено.</div>
                            <?php if (count($tk_archive) > $tk_archive_limit): ?>
                                <div class="rp-more">Показаны последние <?= $tk_archive_limit ?> из <?= count($tk_archive) ?>.</div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </dialog>
            </section>

            <!-- ===== БЕЗОПАСНОСТЬ: СВОЙ PIN ===== -->
            <section class="support-moderation-section security-section" id="security">
                <div class="security-head">
                    <div>
                        <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('lock', 20) ?></span>Мой PIN-код</h2>
                        <div class="support-ticket-summary">PIN запрашивается при каждом заходе на страницу и после <?= (int)(REPORTS_PIN_IDLE_TTL / 60) ?> мин бездействия.</div>
                    </div>
                    <button type="button" class="search-btn" id="pinModalOpen">Сменить PIN-код</button>
                </div>
                <?php if (isset($_GET['pin_changed'])): ?>
                    <div class="success-msg has-ico"><?= reportsIcon('check', 18) ?><span>PIN-код изменён.</span></div>
                <?php endif; ?>

                <dialog id="pinModal" class="pin-modal" aria-labelledby="pinModalTitle">
                    <form method="POST" class="pin-modal-form" autocomplete="off">
                        <input type="hidden" name="change_console_pin" value="1">
                        <div class="pin-modal-icon" aria-hidden="true"><?= reportsIcon('lock', 28) ?></div>
                        <h3 id="pinModalTitle">Смена PIN-кода</h3>
                        <p>Введите текущий PIN и придумайте новый (4 цифры).</p>
                        <?php if (isset($_GET['pin_error'])): ?>
                            <div class="pin-error" role="alert"><?= htmlspecialchars($_GET['pin_error'], ENT_QUOTES, 'UTF-8') ?></div>
                        <?php endif; ?>
                        <label class="pin-label" for="pmCurrent">Текущий PIN-код</label>
                        <input class="pin-input" type="password" id="pmCurrent" name="current_pin" inputmode="numeric" maxlength="4" autocomplete="off" placeholder="••••" required>
                        <label class="pin-label" for="pmNew">Новый PIN-код</label>
                        <input class="pin-input" type="password" id="pmNew" name="new_pin" inputmode="numeric" pattern="\d{4}" maxlength="4" autocomplete="off" placeholder="••••" required>
                        <label class="pin-label" for="pmConfirm">Повторите новый PIN-код</label>
                        <input class="pin-input" type="password" id="pmConfirm" name="new_pin_confirm" inputmode="numeric" pattern="\d{4}" maxlength="4" autocomplete="off" placeholder="••••" required>
                        <div class="pin-modal-actions">
                            <button type="button" class="btn-ghost" id="pinModalCancel">Отмена</button>
                            <button type="submit" class="search-btn">Сохранить PIN</button>
                        </div>
                    </form>
                </dialog>
            </section>

            <!-- ===== ЖАЛОБЫ НА ПОЛЬЗОВАТЕЛЕЙ (только здесь, уровень 2+) ===== -->
            <?php if ($can_reports): ?>
            <?php
            $rp_status_names = ['pending' => 'В ожидании', 'reviewed' => 'Просмотрена', 'resolved' => 'Решена', 'rejected' => 'Отклонена'];
            $rp_limit = 100;
            $rp_total = count($reports);
            $rp_shown = array_slice($reports, 0, $rp_limit);
            $rp_csrf = htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
            ?>
            <section class="support-moderation-section reports-section" id="reports">
                <h2 class="sec-title"><span class="sec-ico"><?= reportsIcon('flag', 20) ?></span>Жалобы на пользователей</h2>
                <div class="support-ticket-summary">
                    Найдено: <?= $rp_total ?>
                    <?php if ($status_filter !== 'all' && isset($rp_status_names[$status_filter])): ?> · Фильтр: <?= $rp_status_names[$status_filter] ?><?php endif; ?>
                    <?php if ($search !== ''): ?> · Поиск: «<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>»<?php endif; ?>
                </div>

                <?php if ($rp_total === 0): ?>
                    <div class="tk-empty">
                        <div class="tk-empty-icon is-ok"><?= reportsIcon('check', 30) ?></div>
                        <div><?= ($search !== '' || $status_filter !== 'all') ? 'По выбранному фильтру жалоб нет.' : 'Жалоб на пользователей пока нет.' ?></div>
                    </div>
                <?php else: ?>
                    <div class="rp-list">
                    <?php foreach ($rp_shown as $rp):
                        $rp_id = (int)$rp['id'];
                        $rp_st = (string)$rp['status'];
                        $rp_st_name = $rp_status_names[$rp_st] ?? $rp_st;
                        $rp_target = (string)$rp['reported_user'];
                        $rp_by = (string)$rp['reporter_name'];
                        $rp_letter = mb_strtoupper(mb_substr($rp_target !== '' ? $rp_target : '?', 0, 1, 'UTF-8'), 'UTF-8');
                        $rp_ts = !empty($rp['created_at']) ? strtotime((string)$rp['created_at']) : false;
                        $rp_date = $rp_ts ? date('d.m.Y H:i', $rp_ts) : '';
                        $rp_mts = !empty($rp['message_date']) ? strtotime((string)$rp['message_date']) : false;
                        $rp_mdate = $rp_mts ? date('d.m.Y H:i', $rp_mts) : '';
                        $rp_preview = mb_strimwidth(preg_replace('/\s+/u', ' ', (string)$rp['message']), 0, 140, '…', 'UTF-8');
                        $rp_modal = 'rpModal' . $rp_id;
                        $rp_reason = (string)$rp['reason'];
                    ?>
                        <article class="rp-card rp-<?= htmlspecialchars($rp_st, ENT_QUOTES, 'UTF-8') ?>">
                            <div class="tk-avatar"><?= htmlspecialchars($rp_letter, ENT_QUOTES, 'UTF-8') ?></div>
                            <div class="tk-body">
                                <div class="tk-top">
                                    <span class="tk-id">#<?= $rp_id ?></span>
                                    <span class="tk-subject"><?= htmlspecialchars($rp_reason !== '' ? $rp_reason : 'Без причины', ENT_QUOTES, 'UTF-8') ?></span>
                                    <span class="rp-pill rp-pill-<?= htmlspecialchars($rp_st, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($rp_st_name, ENT_QUOTES, 'UTF-8') ?></span>
                                </div>
                                <div class="tk-preview"><?= htmlspecialchars($rp_preview, ENT_QUOTES, 'UTF-8') ?></div>
                                <div class="tk-meta">
                                    <span><?= reportsIcon('target', 14) ?> На: <b><?= htmlspecialchars($rp_target, ENT_QUOTES, 'UTF-8') ?></b></span>
                                    <span><?= reportsIcon('pen', 14) ?> От: <?= htmlspecialchars($rp_by, ENT_QUOTES, 'UTF-8') ?></span>
                                    <?php if ($rp_date !== ''): ?><span><?= reportsIcon('clock', 14) ?> <?= $rp_date ?></span><?php endif; ?>
                                </div>
                            </div>
                            <button type="button" class="tk-dialog-btn" data-modal-open="<?= $rp_modal ?>">Открыть</button>

                            <dialog id="<?= $rp_modal ?>" class="vs-modal rp-modal" aria-labelledby="<?= $rp_modal ?>Title">
                                <div class="vs-modal-head">
                                    <div class="vs-modal-titles">
                                        <h3 id="<?= $rp_modal ?>Title">Жалоба #<?= $rp_id ?> — <?= htmlspecialchars($rp_reason !== '' ? $rp_reason : 'Без причины', ENT_QUOTES, 'UTF-8') ?></h3>
                                        <div class="vs-modal-sub">На <?= htmlspecialchars($rp_target, ENT_QUOTES, 'UTF-8') ?> · от <?= htmlspecialchars($rp_by, ENT_QUOTES, 'UTF-8') ?><?php if ($rp_date !== ''): ?> · <?= $rp_date ?><?php endif; ?></div>
                                    </div>
                                    <span class="rp-pill rp-pill-<?= htmlspecialchars($rp_st, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($rp_st_name, ENT_QUOTES, 'UTF-8') ?></span>
                                    <button type="button" class="vs-modal-x" data-modal-close aria-label="Закрыть окно"><?= reportsIcon('x', 16) ?></button>
                                </div>
                                <div class="rp-details">
                                    <div class="rp-block">
                                        <div class="rp-label">Сообщение, на которое пожаловались<?php if ($rp_mdate !== ''): ?> <small><?= $rp_mdate ?></small><?php endif; ?></div>
                                        <div class="rp-text rp-message message-preview-formatted"><?= htmlspecialchars((string)$rp['message'], ENT_QUOTES, 'UTF-8') ?></div>
                                    </div>
                                    <?php if (!empty($rp['comment'])): ?>
                                    <div class="rp-block">
                                        <div class="rp-label">Комментарий автора жалобы</div>
                                        <div class="rp-text"><?= nl2br(htmlspecialchars((string)$rp['comment'], ENT_QUOTES, 'UTF-8')) ?></div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="vs-modal-foot">
                                    <form method="POST" class="rp-form">
                                        <input type="hidden" name="csrf_token" value="<?= $rp_csrf ?>">
                                        <input type="hidden" name="action" value="update_report">
                                        <input type="hidden" name="report_id" value="<?= $rp_id ?>">
                                        <label class="tk-reply-label" for="rpComment<?= $rp_id ?>">Комментарий модератора</label>
                                        <textarea id="rpComment<?= $rp_id ?>" name="moderator_comment" rows="3" maxlength="2000" placeholder="Что решили и почему (необязательно)"><?= htmlspecialchars((string)($rp['moderator_comment'] ?? ''), ENT_QUOTES, 'UTF-8') ?></textarea>
                                        <div class="tk-reply-row">
                                            <select name="status" aria-label="Решение">
                                                <?php foreach ($rp_status_names as $k => $v): ?>
                                                    <option value="<?= $k ?>" <?= $rp_st === $k ? 'selected' : '' ?>><?= $k === 'resolved' ? 'Решена (сообщение будет скрыто)' : $v ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" class="search-btn">Сохранить решение</button>
                                        </div>
                                    </form>
                                </div>
                            </dialog>
                        </article>
                    <?php endforeach; ?>
                    </div>
                    <?php if ($rp_total > $rp_limit): ?>
                        <div class="rp-more">Показаны первые <?= $rp_limit ?> из <?= $rp_total ?>. Уточните фильтр или поиск, чтобы увидеть остальные.</div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- ===== ПОДКЛЮЧЕНИЕ JAVASCRIPT ===== -->
    <script src="assets/js/pin-cells.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Одноразовые сообщения: убираем их параметры из адреса, чтобы после F5 / Ctrl+R они не появлялись снова
            try {
                const flashKeys = ['success', 'report_error', 'restart', 'console_sent', 'console_error',
                    'plans_saved', 'plans_error', 'topup_msg', 'topup_error', 'support_success', 'support_closed', 'support_in_progress',
                    'support_error', 'admins_saved', 'admins_error', 'pin_changed', 'pin_error', 'vs_mode', 'backup_msg', 'backup_error'];
                const url = new URL(window.location.href);
                let changed = false;
                flashKeys.forEach(function(key) {
                    if (url.searchParams.has(key)) { url.searchParams.delete(key); changed = true; }
                });
                if (changed) {
                    window.history.replaceState(null, '', url.pathname + url.search + url.hash);
                }
            } catch (e) {}

            // Баланс VS: режим (пополнить / снять), список пользователей, быстрые суммы, подсветка ошибок
            const topupForm = document.getElementById('topupForm');
            if (topupForm) {
                const amountInput = document.getElementById('topupAmount');
                const targetInput = document.getElementById('topupTarget');
                const targetId = document.getElementById('topupTargetId');
                const modeInput = document.getElementById('topupMode');
                const submitBtn = document.getElementById('topupSubmit');
                const hint = document.getElementById('topupHint');
                const combo = document.getElementById('topupCombo');
                const list = document.getElementById('topupList');
                const toggle = document.getElementById('topupToggle');
                const emptyRow = list.querySelector('.user-combo-empty');
                const options = Array.prototype.slice.call(list.querySelectorAll('li[data-id]'));
                const maxAmount = parseInt(amountInput.max, 10) || 1000000000;
                let activeIdx = -1;

                // --- режим: пополнить / снять ---
                function setMode(mode) {
                    modeInput.value = mode;
                    topupForm.dataset.mode = mode;
                    submitBtn.textContent = mode === 'debit' ? 'Снять' : 'Пополнить';
                    topupForm.querySelectorAll('.topup-mode').forEach(function(b) {
                        b.classList.toggle('is-active', b.dataset.mode === mode);
                    });
                    topupForm.querySelectorAll('.chip-sign').forEach(function(el) {
                        el.textContent = mode === 'debit' ? '\u2212' : '+';
                    });
                }
                topupForm.querySelectorAll('.topup-mode').forEach(function(b) {
                    b.addEventListener('click', function() { setMode(b.dataset.mode); });
                });

                // --- выпадающий список пользователей ---
                function visibleOptions() { return options.filter(function(o) { return !o.hidden; }); }
                function setActive(i) {
                    const vis = visibleOptions();
                    options.forEach(function(o) { o.classList.remove('is-active'); });
                    if (!vis.length) { activeIdx = -1; return; }
                    activeIdx = (i + vis.length) % vis.length;
                    vis[activeIdx].classList.add('is-active');
                    vis[activeIdx].scrollIntoView({ block: 'nearest' });
                }
                function filterList(q) {
                    q = q.trim().toLowerCase().replace(/^#/, '');
                    options.forEach(function(o) {
                        const hit = q === '' || o.dataset.name.toLowerCase().indexOf(q) !== -1 || o.dataset.id.indexOf(q) !== -1;
                        o.hidden = !hit;
                    });
                    emptyRow.hidden = visibleOptions().length > 0;
                    activeIdx = -1;
                }
                function openList(filter) {
                    filterList(filter ? targetInput.value : '');
                    list.hidden = false;
                    targetInput.setAttribute('aria-expanded', 'true');
                }
                function closeList() {
                    list.hidden = true;
                    targetInput.setAttribute('aria-expanded', 'false');
                    activeIdx = -1;
                }
                function pick(li) {
                    targetInput.value = li.dataset.name;
                    targetId.value = li.dataset.id;
                    targetInput.classList.remove('is-invalid');
                    closeList();
                    amountInput.focus();
                }

                targetInput.addEventListener('focus', function() { openList(targetInput.value.trim() !== ''); });
                targetInput.addEventListener('input', function() {
                    targetId.value = '';                       // текст изменили вручную — выбор сбрасываем
                    targetInput.classList.remove('is-invalid');
                    openList(true);
                });
                targetInput.addEventListener('keydown', function(e) {
                    if (e.key === 'ArrowDown') { e.preventDefault(); if (list.hidden) openList(true); setActive(activeIdx + 1); }
                    else if (e.key === 'ArrowUp') { e.preventDefault(); if (list.hidden) openList(true); setActive(activeIdx - 1); }
                    else if (e.key === 'Enter' && !list.hidden && activeIdx >= 0) { e.preventDefault(); pick(visibleOptions()[activeIdx]); }
                    else if (e.key === 'Escape') { closeList(); }
                });
                toggle.addEventListener('mousedown', function(e) { e.preventDefault(); });
                toggle.addEventListener('click', function() {
                    if (list.hidden) { openList(false); targetInput.focus(); } else { closeList(); }
                });
                list.addEventListener('mousedown', function(e) { e.preventDefault(); });   // не терять фокус поля
                list.addEventListener('click', function(e) {
                    const li = e.target.closest('li[data-id]');
                    if (li) pick(li);
                });
                document.addEventListener('click', function(e) { if (!combo.contains(e.target)) closeList(); });

                // --- сумма ---
                function checkAmount(strict) {
                    const raw = amountInput.value.trim();
                    const v = Number(raw);
                    let msg = '';
                    if (raw === '') {
                        if (strict) msg = 'Введите сумму';
                    } else if (!isFinite(v) || v < 1) {
                        msg = 'Минимум 1 VS';
                    } else if (v > maxAmount) {
                        msg = 'Предел — ' + maxAmount.toLocaleString('ru-RU') + ' VS';
                    }
                    amountInput.classList.toggle('is-invalid', msg !== '');
                    hint.textContent = msg;
                    hint.hidden = msg === '';
                    return msg === '' && raw !== '';
                }
                amountInput.addEventListener('input', function() { checkAmount(false); });

                topupForm.querySelectorAll('.chip').forEach(function(chip) {
                    chip.addEventListener('click', function() {
                        const sum = (parseInt(amountInput.value, 10) || 0) + parseInt(chip.dataset.amount, 10);
                        amountInput.value = sum;   // выход за предел не обрезаем — подсветим красным
                        checkAmount(false);
                        amountInput.focus();
                    });
                });

                topupForm.addEventListener('submit', function(e) {
                    const targetOk = targetInput.value.trim() !== '';
                    targetInput.classList.toggle('is-invalid', !targetOk);
                    const amountOk = checkAmount(true);
                    if (!targetOk || !amountOk) {
                        e.preventDefault();
                        (targetOk ? amountInput : targetInput).focus();
                    }
                });
            }

            // Жалобы: подтверждение, если решение скрывает сообщение
            document.querySelectorAll('.rp-form').forEach(function(f) {
                f.addEventListener('submit', function(e) {
                    const st = f.querySelector('select[name="status"]');
                    if (st && st.value === 'resolved' && !confirm('Пометить жалобу решённой? Сообщение будет скрыто.')) {
                        e.preventDefault();
                    }
                });
            });

            // Окно «Баланс VS»: открывается по кнопкам «Пополнить» / «Снять»
            (function() {
                const modal = document.getElementById('topupModal');
                const form = document.getElementById('topupForm');
                if (!modal || !form) { return; }
                const title = document.getElementById('topupModalTitle');
                const list = document.getElementById('topupList');
                const titles = { credit: 'Пополнение баланса VS', debit: 'Снятие VS с баланса' };
                function syncTitle() { title.textContent = titles[form.dataset.mode] || titles.credit; }
                form.querySelectorAll('.topup-mode').forEach(function(b) { b.addEventListener('click', syncTitle); });
                function openModal(mode) {
                    const btn = form.querySelector('.topup-mode[data-mode="' + mode + '"]');
                    if (btn) { btn.click(); }
                    syncTitle();
                    modal.showModal();
                    document.documentElement.style.overflow = 'hidden';
                    document.getElementById('topupTarget').focus();
                }
                document.querySelectorAll('[data-topup-open]').forEach(function(b) {
                    b.addEventListener('click', function() { openModal(b.getAttribute('data-topup-open')); });
                });
                // Esc сначала закрывает выпадающий список пользователей, а не всё окно
                let listWasOpen = false;
                modal.addEventListener('keydown', function(e) { if (e.key === 'Escape') { listWasOpen = !list.hidden; } }, true);
                modal.addEventListener('cancel', function(e) { if (listWasOpen) { e.preventDefault(); listWasOpen = false; } });
                <?php if (isset($_GET['topup_error'])): ?>
                openModal(<?= json_encode(($_GET['vs_mode'] ?? '') === 'debit' ? 'debit' : 'credit') ?>);
                <?php endif; ?>
            })();

            // Окно смены PIN-кода
            const pinModal = document.getElementById('pinModal');
            if (pinModal) {
                const pinModalForm = pinModal.querySelector('form');
                document.getElementById('pinModalOpen').addEventListener('click', function() {
                    pinModal.showModal();
                    document.getElementById('pmCurrent').focus();
                });
                document.getElementById('pinModalCancel').addEventListener('click', function() { pinModal.close(); });
                pinModal.addEventListener('click', function(e) { if (e.target === pinModal) pinModal.close(); });
                pinModal.addEventListener('close', function() { pinModalForm.reset(); });
                pinModal.querySelectorAll('.pin-input').forEach(function(el) {
                    el.addEventListener('input', function() { el.value = el.value.replace(/\D/g, '').slice(0, 4); });
                });
                <?php if (isset($_GET['pin_error'])): ?>
                pinModal.showModal();
                <?php endif; ?>
            }

            // Отдельные окна (диалоги обращений, откат бэкапа)
            (function() {
                function lockScroll(lock) { document.documentElement.style.overflow = (lock || document.querySelector('dialog[open]')) ? 'hidden' : ''; }
                document.querySelectorAll('[data-modal-open]').forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        const dlg = document.getElementById(btn.getAttribute('data-modal-open'));
                        if (!dlg || typeof dlg.showModal !== 'function') { return; }
                        dlg.showModal();
                        lockScroll(true);
                        const thread = dlg.querySelector('.tk-thread');
                        if (thread) { thread.scrollTop = thread.scrollHeight; }
                        const field = dlg.querySelector('textarea, input[type="text"]');
                        if (field) { field.focus(); }
                    });
                });
                document.querySelectorAll('dialog.vs-modal').forEach(function(dlg) {
                    dlg.addEventListener('click', function(e) { if (e.target === dlg) { dlg.close(); } });
                    dlg.addEventListener('close', function() { lockScroll(false); });
                    dlg.querySelectorAll('[data-modal-close]').forEach(function(b) {
                        b.addEventListener('click', function() { dlg.close(); });
                    });
                    const ta = dlg.querySelector('.tk-reply-form textarea');
                    if (ta) {
                        ta.addEventListener('keydown', function(e) {
                            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                                e.preventDefault();
                                const f = ta.form;
                                if (f.reportValidity()) {
                                    const submitBtn = f.querySelector('[name="send_support_response"]');
                                    if (f.requestSubmit) { f.requestSubmit(submitBtn); } else { f.submit(); }
                                }
                            }
                        });
                    }
                });

                // Окно «Администраторы»: после действия (или ошибки PIN) остаётся открытым
                <?php if ($is_founder && (isset($_GET['admins_saved']) || isset($_GET['admins_error']))): ?>
                const adminsDlg = document.getElementById('adminsModal');
                if (adminsDlg && typeof adminsDlg.showModal === 'function') { adminsDlg.showModal(); lockScroll(true); }
                <?php endif; ?>
                // PIN выдачи прав: только цифры; при закрытии окна форма и PIN очищаются
                const grantPin = document.getElementById('grantPin');
                if (grantPin) {
                    grantPin.addEventListener('input', function() { grantPin.value = grantPin.value.replace(/\D/g, '').slice(0, 4); });
                    const adminsModalEl = document.getElementById('adminsModal');
                    if (adminsModalEl) {
                        adminsModalEl.addEventListener('close', function() {
                            if (grantPin.form) { grantPin.form.reset(); }
                            grantPin.dispatchEvent(new Event('input', { bubbles: true }));
                        });
                    }
                }

                // Окно «Цены V+»: после сохранения тарифа остаётся открытым
                <?php if ($can_prices && (isset($_GET['plans_saved']) || isset($_GET['plans_error']))): ?>
                const vplusDlg = document.getElementById('vplusModal');
                if (vplusDlg && typeof vplusDlg.showModal === 'function') { vplusDlg.showModal(); lockScroll(true); }
                <?php endif; ?>

                // Окно «Резервные копии»: после создания / отката / удаления остаётся открытым с результатом
                <?php if ($can_backup && (isset($_GET['backup_msg']) || isset($_GET['backup_error']))): ?>
                const backupsDlg = document.getElementById('backupsModal');
                if (backupsDlg && typeof backupsDlg.showModal === 'function') { backupsDlg.showModal(); lockScroll(true); }
                <?php endif; ?>

                // Фильтр обращений
                const filters = document.querySelectorAll('.tk-filter');
                const emptyMsg = document.getElementById('tkEmptyFilter');
                filters.forEach(function(fb) {
                    fb.addEventListener('click', function() {
                        filters.forEach(function(x) { x.classList.toggle('is-active', x === fb); });
                        const f = fb.getAttribute('data-filter');
                        let shown = 0;
                        document.querySelectorAll('#tkList .tk-card').forEach(function(card) {
                            const ok = f === 'all' || card.getAttribute('data-status') === f;
                            card.hidden = !ok;
                            if (ok) { shown++; }
                        });
                        if (emptyMsg) { emptyMsg.hidden = shown !== 0; }
                    });
                });

                // Поиск по архиву обращений
                const arcSearch = document.getElementById('tkArchiveSearch');
                if (arcSearch) {
                    const arcEmpty = document.getElementById('tkArchiveEmpty');
                    arcSearch.addEventListener('input', function() {
                        const q = arcSearch.value.trim().toLowerCase().replace(/^#/, '');
                        let shown = 0;
                        document.querySelectorAll('#tkArchiveList > .tk-card').forEach(function(card) {
                            const hay = (card.querySelector('.tk-body') ? card.querySelector('.tk-body').textContent : '').toLowerCase();
                            const ok = q === '' || hay.indexOf(q) !== -1;
                            card.hidden = !ok;
                            if (ok) { shown++; }
                        });
                        if (arcEmpty) { arcEmpty.hidden = shown !== 0; }
                    });
                }
            })();

            // Системная тема
            if (document.body.dataset.theme === 'system') {
                const mq = window.matchMedia('(prefers-color-scheme: light)');
                const applySystemTheme = function() { document.body.dataset.theme = mq.matches ? 'light' : 'dark'; };
                applySystemTheme();
                if (mq.addEventListener) mq.addEventListener('change', applySystemTheme);
            }

            // Автоблокировка: после бездействия возвращаемся на экран ввода PIN-кода
            (function() {
                const idleMs = <?= (int)REPORTS_PIN_IDLE_TTL ?> * 1000;
                let timer;
                function arm() {
                    clearTimeout(timer);
                    timer = setTimeout(function() { window.location.href = 'reports.php?lock=1'; }, idleMs);
                }
                ['click', 'keydown', 'mousemove', 'scroll', 'touchstart'].forEach(function(evt) {
                    document.addEventListener(evt, arm, { passive: true });
                });
                arm();
            })();

            // Нижняя панель: показ/скрытие (как в index.php)
            const handle = document.getElementById('handleBtn');
            const nav = document.querySelector('.bottom-nav');
            if (handle && nav) {
                nav.classList.add('nav-hidden');
                handle.classList.remove('handle-hidden');

                handle.addEventListener('click', function(e) {
                    e.stopPropagation();
                    nav.classList.toggle('nav-hidden');
                    handle.classList.toggle('handle-hidden');
                });
                handle.addEventListener('mouseenter', function() {
                    nav.classList.remove('nav-hidden');
                    handle.classList.add('handle-hidden');
                });
                nav.addEventListener('mouseleave', function() {
                    if (!handle.matches(':hover')) {
                        nav.classList.add('nav-hidden');
                        handle.classList.remove('handle-hidden');
                    }
                });
                nav.addEventListener('mouseenter', function() {
                    nav.classList.remove('nav-hidden');
                    handle.classList.add('handle-hidden');
                });
            }

            // Подменю выбора темы (как в index.php)
            const themeTrigger = document.getElementById('themeTrigger');
            const themeSubmenu = document.getElementById('themeSubmenu');
            const themeArrow = document.getElementById('themeArrow');
            if (themeTrigger && themeSubmenu) {
                themeTrigger.addEventListener('click', function(e) {
                    e.stopPropagation();
                    themeSubmenu.classList.toggle('open');
                    if (themeArrow) themeArrow.classList.toggle('open');
                });
            }

            // Кнопка «Все прочитано»
            const markAllReadBtn = document.getElementById('markAllReadBtn');
            if (markAllReadBtn) {
                markAllReadBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    fetch('api/mark_notifications_read.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'user_id=<?= $user_id ?>'
                    }).then(function() {
                        document.querySelectorAll('.notification-item.unread').forEach(function(item) {
                            item.classList.remove('unread');
                            item.classList.add('read');
                        });
                        const badge = document.getElementById('notificationsBadge');
                        if (badge) badge.style.display = 'none';
                        const count = document.getElementById('notificationsCount');
                        if (count) count.textContent = '0 новых';
                        markAllReadBtn.remove();
                    }).catch(function(error) {
                        console.error('Не удалось отметить уведомления прочитанными:', error);
                    });
                });
            }

            const notificationsBtn = document.getElementById('notificationsBtn');
            const notificationsDropdown = document.getElementById('notificationsDropdown');
            const consoleToggle = document.getElementById('consoleToggle');
            const consolePanel = document.getElementById('consolePanel');

            function setConsoleVisibility(isVisible) {
                if (!consoleToggle || !consolePanel) {
                    return;
                }
                consolePanel.hidden = !isVisible;
                consoleToggle.setAttribute('aria-expanded', isVisible ? 'true' : 'false');
                consoleToggle.textContent = isVisible ? 'Скрыть консоль' : 'Открыть консоль';
            }

            // Страница уже защищена PIN-кодом, поэтому консоль просто раскрывается/скрывается.
            if (consoleToggle && consolePanel) {
                consoleToggle.addEventListener('click', function() {
                    setConsoleVisibility(consolePanel.hidden);
                });
                document.addEventListener('keydown', function(event) {
                    if (event.shiftKey && event.key === 'F12') {
                        event.preventDefault();
                        setConsoleVisibility(consolePanel.hidden);
                    }
                });
            }

            if (notificationsBtn && notificationsDropdown) {
                notificationsBtn.addEventListener('click', function(event) {
                    event.stopPropagation();
                    notificationsDropdown.classList.toggle('active');
                    if (notificationsDropdown.classList.contains('active')) {
                        fetch('api/mark_notifications_read.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                            body: 'user_id=<?= $user_id ?>'
                        }).catch(function(error) {
                            console.error('Не удалось отметить уведомления прочитанными:', error);
                        });
                    }
                });
                document.addEventListener('click', function(event) {
                    if (!notificationsDropdown.contains(event.target) && !notificationsBtn.contains(event.target)) {
                        notificationsDropdown.classList.remove('active');
                    }
                });
            }

            const supportError = document.querySelector('#consolePanel .error-msg');
            const retryKey = 'reports-support-error-retry';

            if (supportError) {
                if (sessionStorage.getItem(retryKey) !== '1') {
                    sessionStorage.setItem(retryKey, '1');
                    const retryNotice = document.createElement('div');
                    retryNotice.className = 'error-msg';
                    retryNotice.textContent = 'Повторная загрузка страницы через 3 секунды...';
                    supportError.insertAdjacentElement('afterend', retryNotice);
                    window.setTimeout(function() {
                        window.location.reload();
                    }, 3000);
                } else {
                    sessionStorage.removeItem(retryKey);
                }
            } else {
                sessionStorage.removeItem(retryKey);
            }

            // Автоматическое скрытие сообщения об успехе
            const successMsg = document.querySelector('.success-msg');
            if (successMsg) {
                setTimeout(() => {
                    successMsg.style.opacity = '0';
                    setTimeout(() => successMsg.remove(), 500);
                }, 3000);
            }
            
            // Кнопка "Применить" - подтверждение
            document.querySelectorAll('.btn-apply').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    const form = this.closest('.action-form');
                    const select = form.querySelector('.status-select');
                    const status = select.value;
                    const statusLabels = {
                        'pending': 'В ожидании',
                        'reviewed': 'Просмотрена',
                        'resolved': 'Решена (сообщение будет скрыто)',
                        'rejected': 'Отклонена'
                    };
                    
                    if (!confirm(`Вы уверены, что хотите изменить статус на "${statusLabels[status]}"?`)) {
                        e.preventDefault();
                    }
                });
            });
            
            // Дропдаун аватара
            const avatarBtn = document.getElementById('avatarBtn');
            const dropdown = document.getElementById('avatarDropdown');
            
            if (avatarBtn && dropdown) {
                avatarBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    dropdown.classList.toggle('active');
                });
            }
            
            document.addEventListener('click', function(e) {
                if (dropdown && avatarBtn) {
                    if (!dropdown.contains(e.target) && e.target !== avatarBtn && !avatarBtn.contains(e.target)) {
                        dropdown.classList.remove('active');
                    }
                }
            });
            
            // =============================================
            // ОБРАБОТКА ФЛАГОВ ЧЕРЕЗ TWEMOJI
            // =============================================
            function renderFlags() {
                if (typeof twemoji !== 'undefined') {
                    try {
                        // Обрабатываем все элементы с флагами
                        const elements = document.querySelectorAll('.flag-emoji, .message-preview-formatted');
                        elements.forEach(function(el) {
                            twemoji.parse(el, {
                                folder: 'svg',
                                ext: '.svg',
                                size: '72x72'
                            });
                        });
                        
                        // Также обрабатываем все сообщения
                        const previews = document.querySelectorAll('.message-preview');
                        previews.forEach(function(preview) {
                            twemoji.parse(preview, {
                                folder: 'svg',
                                ext: '.svg',
                                size: '72x72'
                            });
                        });
                    } catch(e) {
                        console.log('Twemoji error:', e);
                    }
                }
            }
            
            // Запускаем через несколько интервалов
            setTimeout(renderFlags, 100);
            setTimeout(renderFlags, 300);
            setTimeout(renderFlags, 500);
            setTimeout(renderFlags, 1000);
            
            // Наблюдатель за новыми элементами
            if (typeof MutationObserver !== 'undefined') {
                const observer = new MutationObserver(function() {
                    setTimeout(renderFlags, 100);
                });
                
                const container = document.querySelector('.reports-list');
                if (container) {
                    observer.observe(container, {
                        childList: true,
                        subtree: true
                    });
                }
            }
        });
    </script>
    
</body>
</html>
<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
header('Content-Type: application/json');

if (!isset($_SESSION["user_id"])) {
    echo json_encode([]);
    exit;
}

$conn = db_connect();
$conn->set_charset("utf8mb4");

$user_id = (int)$_SESSION["user_id"];

$stmt = $conn->prepare("SELECT id, username FROM users WHERE id != ? ORDER BY username ASC LIMIT 50");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = [
        'id' => $row['id'],
        'username' => $row['username'],
        'avatar_letter' => mb_substr($row['username'], 0, 1, "UTF-8")
    ];
}

$stmt->close();
$conn->close();

echo json_encode($users);
?>
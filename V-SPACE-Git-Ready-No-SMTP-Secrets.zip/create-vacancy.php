<?php
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

// ============================================================
// 1. ПРОВЕРКА АВТОРИЗАЦИИ
// ============================================================
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// ============================================================
// 2. ПОДКЛЮЧЕНИЕ К БД (ДОБАВЛЕНО ДЛЯ СИНХРОНИЗАЦИИ)
// ============================================================
require_once __DIR__ . '/includes/db.php';

try {
    $db = db_connect();
} catch (Throwable $e) {
    error_log('create-vacancy.php DB connect error: ' . $e->getMessage());
    die('Ошибка подключения к базе данных.');
}

if ($db->connect_error) {
    error_log('create-vacancy.php DB connect error: ' . $db->connect_error);
    die('Ошибка подключения к базе данных.');
}

$db->set_charset('utf8mb4');

// ============================================================
// 3. ПРОВЕРКА ПРАВ АДМИНИСТРАТОРА (УЛУЧШЕННАЯ)
// ============================================================
$userId = (int)$_SESSION['user_id'];
$isAdmin = false;

// Сначала проверяем сессию
if (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) {
    $isAdmin = true;
}

// Если в сессии нет - проверяем БД (на случай, если админ был назначен позже)
if (!$isAdmin) {
    // Проверяем наличие колонки role
    $columnCheck = $db->query("SHOW COLUMNS FROM users LIKE 'role'");
    
    if ($columnCheck && $columnCheck->num_rows > 0) {
        $stmt = $db->prepare("SELECT role FROM users WHERE id = ? LIMIT 1");
        
        if ($stmt) {
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $currentUser = $result->fetch_assoc();
            
            if (($currentUser['role'] ?? '') === 'admin') {
                $isAdmin = true;
                $_SESSION['is_admin'] = true; // Синхронизируем сессию
            }
            
            $stmt->close();
        }
    }
}

// СТРОГАЯ ПРОВЕРКА - если не админ, перенаправляем
if (!$isAdmin) {
    header('Location: vacancies.php');
    exit;
}

// ============================================================
// 4. ПРОВЕРКА ТАБЛИЦЫ VACANCIES (ДОБАВЛЕНО)
// ============================================================
$tableCheck = $db->query("SHOW TABLES LIKE 'vacancies'");

if (!$tableCheck || $tableCheck->num_rows === 0) {
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Ошибка — V SPACE</title>
        <style>
            *{box-sizing:border-box}
            body{
                margin:0;
                min-height:100vh;
                display:flex;
                align-items:center;
                justify-content:center;
                background:#303136;
                color:#f1f1f3;
                font-family:Arial,Helvetica,sans-serif;
            }
            .card{
                width:min(520px,calc(100% - 30px));
                padding:30px;
                background:#1d1e21;
                border:1px solid #292a2f;
                border-radius:12px;
                box-shadow:0 10px 35px rgba(0,0,0,.25);
            }
            h1{margin:0 0 12px;font-size:23px}
            p{
                margin:0 0 18px;
                color:#999ba4;
                line-height:1.6;
                font-size:14px;
            }
            a{
                display:inline-block;
                padding:11px 18px;
                background:#5865f2;
                color:#fff;
                border-radius:7px;
                text-decoration:none;
                font-size:13px;
                font-weight:700;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>Таблица вакансий не найдена</h1>
            <p>
                Сначала создайте таблицу <b>vacancies</b> в базе данных.
            </p>
            <a href="vacancies.php">Вернуться к вакансиям</a>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ============================================================
// 5. ОБРАБОТКА ОТПРАВКИ ФОРМЫ
// ============================================================
$errors = [];
$success = false;
$vacancyId = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные и очищаем от лишних пробелов
    $title = trim($_POST['title'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $salary = trim($_POST['salary'] ?? '');
    $employment = trim($_POST['employment'] ?? '');
    $experience = trim($_POST['experience'] ?? '');
    $description = trim($_POST['description'] ?? '');
    
    // Валидация
    if (empty($title)) {
        $errors[] = 'Название вакансии обязательно';
    } elseif (mb_strlen($title) > 255) {
        $errors[] = 'Название вакансии не должно превышать 255 символов';
    }
    
    if (empty($company)) {
        $errors[] = 'Название компании обязательно';
    } elseif (mb_strlen($company) > 255) {
        $errors[] = 'Название компании не должно превышать 255 символов';
    }
    
    if (empty($description)) {
        $errors[] = 'Описание вакансии обязательно';
    } elseif (mb_strlen($description) < 20) {
        $errors[] = 'Описание должно содержать минимум 20 символов';
    }
    
    // Если ошибок нет - сохраняем
    if (empty($errors)) {
        $stmt = $db->prepare("
            INSERT INTO vacancies 
            (title, company, location, salary, employment, experience, description, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        if ($stmt) {
            $stmt->bind_param(
                "sssssss",
                $title,
                $company,
                $location,
                $salary,
                $employment,
                $experience,
                $description
            );
            
            if ($stmt->execute()) {
                $success = true;
                $vacancyId = $stmt->insert_id;
                
                // Очищаем POST данные после успешного сохранения
                $_POST = [];
            } else {
                $errors[] = 'Ошибка при сохранении: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $errors[] = 'Ошибка подготовки запроса';
        }
    }
}

// ============================================================
// 6. ФУНКЦИЯ ДЛЯ БЕЗОПАСНОГО ВЫВОДА
// ============================================================
function vacancyEscape($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// Сохраняем старые значения для формы
$oldValues = [
    'title' => $_POST['title'] ?? '',
    'company' => $_POST['company'] ?? '',
    'location' => $_POST['location'] ?? '',
    'salary' => $_POST['salary'] ?? '',
    'employment' => $_POST['employment'] ?? '',
    'experience' => $_POST['experience'] ?? '',
    'description' => $_POST['description'] ?? '',
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создание вакансии — V SPACE</title>
    <style>
        * { box-sizing: border-box; }
        
        body {
            margin: 0;
            min-height: 100vh;
            background: #303136;
            color: #f1f1f3;
            font-family: Arial, Helvetica, sans-serif;
            padding: 20px;
        }
        
        .container {
            max-width: 700px;
            margin: 50px auto;
            background: #1d1e21;
            border: 1px solid #292a2f;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 10px 35px rgba(0,0,0,.25);
        }
        
        h1 {
            margin: 0 0 8px;
            font-size: 24px;
        }
        
        .subtitle {
            color: #858791;
            font-size: 13px;
            margin-bottom: 25px;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #5865f2;
            text-decoration: none;
            font-size: 13px;
        }
        
        .back-link:hover {
            color: #7d88ff;
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-size: 13px;
            font-weight: 600;
            color: #bfc0c6;
        }
        
        label .required {
            color: #f04747;
        }
        
        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 10px 12px;
            background: #25262a;
            border: 1px solid #323338;
            border-radius: 7px;
            color: #f1f1f3;
            font-size: 14px;
            transition: 0.2s;
        }
        
        input[type="text"]:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #5865f2;
            box-shadow: 0 0 0 3px rgba(88, 101, 242, 0.2);
        }
        
        textarea {
            min-height: 150px;
            resize: vertical;
            font-family: Arial, Helvetica, sans-serif;
        }
        
        select {
            appearance: none;
            cursor: pointer;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .alert {
            padding: 12px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        
        .alert-error {
            background: rgba(240, 71, 71, 0.15);
            border: 1px solid rgba(240, 71, 71, 0.3);
            color: #f04747;
        }
        
        .alert-success {
            background: rgba(67, 181, 129, 0.15);
            border: 1px solid rgba(67, 181, 129, 0.3);
            color: #43b581;
        }
        
        .alert ul {
            margin: 5px 0;
            padding-left: 20px;
        }
        
        .btn-submit {
            width: 100%;
            padding: 13px;
            background: #5865f2;
            color: #fff;
            border: none;
            border-radius: 7px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }
        
        .btn-submit:hover {
            background: #6875ff;
            transform: translateY(-1px);
        }
        
        .btn-submit:active {
            transform: translateY(0);
        }
        
        .success-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .success-actions a {
            display: inline-block;
            padding: 10px 16px;
            border-radius: 7px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: .2s;
        }
        
        .btn-view {
            background: #5865f2;
            color: #fff;
        }
        
        .btn-view:hover {
            background: #6875ff;
        }
        
        .btn-create-new {
            background: #25262a;
            color: #bfc0c6;
            border: 1px solid #323338;
        }
        
        .btn-create-new:hover {
            background: #323338;
        }
        
        @media (max-width: 600px) {
            .container {
                padding: 20px;
                margin: 20px auto;
            }
            
            .form-row {
                grid-template-columns: 1fr;
                gap: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="vacancies.php" class="back-link">← Назад к вакансиям</a>
        
        <h1>Создание вакансии</h1>
        <div class="subtitle">Заполните все обязательные поля</div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <strong>Ошибка:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= vacancyEscape($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <strong>✅ Вакансия успешно создана!</strong>
                
                <div class="success-actions">
                    <a href="vacancy-detail.php?id=<?= $vacancyId ?>" class="btn-view">
                        Просмотреть вакансию →
                    </a>
                    <a href="create-vacancy.php" class="btn-create-new">
                        ＋ Создать ещё
                    </a>
                </div>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>
                    Название вакансии <span class="required">*</span>
                </label>
                <input 
                    type="text" 
                    name="title" 
                    value="<?= vacancyEscape($oldValues['title']) ?>"
                    placeholder="Например: Senior PHP Developer"
                    maxlength="255"
                    required
                >
            </div>
            
            <div class="form-group">
                <label>
                    Компания <span class="required">*</span>
                </label>
                <input 
                    type="text" 
                    name="company" 
                    value="<?= vacancyEscape($oldValues['company']) ?>"
                    placeholder="Название компании"
                    maxlength="255"
                    required
                >
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Локация</label>
                    <input 
                        type="text" 
                        name="location" 
                        value="<?= vacancyEscape($oldValues['location']) ?>"
                        placeholder="Москва, Киев, Удаленно"
                        maxlength="255"
                    >
                </div>
                
                <div class="form-group">
                    <label>Зарплата</label>
                    <input 
                        type="text" 
                        name="salary" 
                        value="<?= vacancyEscape($oldValues['salary']) ?>"
                        placeholder="От 200 000 ₽"
                        maxlength="255"
                    >
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Тип занятости</label>
                    <select name="employment">
                        <option value="">Выберите...</option>
                        <option value="Полная занятость" <?= $oldValues['employment'] === 'Полная занятость' ? 'selected' : '' ?>>Полная занятость</option>
                        <option value="Частичная занятость" <?= $oldValues['employment'] === 'Частичная занятость' ? 'selected' : '' ?>>Частичная занятость</option>
                        <option value="Стажировка" <?= $oldValues['employment'] === 'Стажировка' ? 'selected' : '' ?>>Стажировка</option>
                        <option value="Проектная работа" <?= $oldValues['employment'] === 'Проектная работа' ? 'selected' : '' ?>>Проектная работа</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Опыт работы</label>
                    <select name="experience">
                        <option value="">Выберите...</option>
                        <option value="Без опыта" <?= $oldValues['experience'] === 'Без опыта' ? 'selected' : '' ?>>Без опыта</option>
                        <option value="1-3 года" <?= $oldValues['experience'] === '1-3 года' ? 'selected' : '' ?>>1-3 года</option>
                        <option value="3-6 лет" <?= $oldValues['experience'] === '3-6 лет' ? 'selected' : '' ?>>3-6 лет</option>
                        <option value="Более 6 лет" <?= $oldValues['experience'] === 'Более 6 лет' ? 'selected' : '' ?>>Более 6 лет</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label>
                    Описание вакансии <span class="required">*</span>
                </label>
                <textarea 
                    name="description" 
                    placeholder="Опишите требования, обязанности и условия работы..."
                    minlength="20"
                    required
                ><?= vacancyEscape($oldValues['description']) ?></textarea>
            </div>
            
            <button type="submit" class="btn-submit">
                Опубликовать вакансию
            </button>
        </form>
    </div>
</body>
</html>
<?php

require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/bug_reports.php';
require_once __DIR__ . '/includes/shell.php';

start_secure_session();

// Перевод страницы на английский (если выбран English в настройках)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$theme   = resolve_theme('developers.php');

// Подключение к БД и данные пользователя
try {
    $conn = db_connect(true);
    bug_reports_ensure_table($conn);
    $user = fetch_user($conn, $user_id);
} catch (Throwable $e) {
    error_log('developers.php DB error: ' . $e->getMessage());
    http_response_code(503);
    die('Сервис временно недоступен. Попробуйте позже.');
}

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$username     = $user['username'] ?: 'Пользователь';
$avatar       = $user['avatar'] ?: '';
$avatarLetter = mb_strtoupper(mb_substr($username, 0, 1, 'UTF-8'), 'UTF-8');
$avatar_ok    = ($avatar !== '' && file_exists($avatar));

[$notifications, $notif_count] = fetch_notifications($conn, $user_id);

// Данные для общей шапки и значка «Сообщения» (как в index.php)
extract(shell_prepare($conn, $user_id));

// CSRF-токен формы
if (empty($_SESSION['dev_form_token'])) {
    $_SESSION['dev_form_token'] = bin2hex(random_bytes(32));
}

$success = '';
$error   = '';

// Одноразовое сообщение после успешной отправки (Post/Redirect/Get)
if (isset($_SESSION['dev_flash'])) {
    $success = (string)$_SESSION['dev_flash'];
    unset($_SESSION['dev_flash']);
}

$title       = '';
$description = '';
$page        = '';

$page_options = [
    'Мой профиль',
    'Сообщения',
    'Друзья',
    'Уведомления',
    'Настройки',
    'V+ (подписка)',
    'Другое',
];

// Отправка бага
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title       = trim((string)($_POST['title'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));
    $page        = trim((string)($_POST['page'] ?? ''));
    // Значения списка при English приходят переведёнными — возвращаем русские (так они хранятся в базе)
    $page_from_en = [
        'My profile' => 'Мой профиль', 'Messages' => 'Сообщения', 'Friends' => 'Друзья',
        'Notifications' => 'Уведомления', 'Settings' => 'Настройки',
        'V+ (subscription)' => 'V+ (подписка)', 'Other' => 'Другое',
    ];
    if (isset($page_from_en[$page])) {
        $page = $page_from_en[$page];
    }
    if ($page !== '' && !in_array($page, $page_options, true)) {
        $page = '';
    }
    $token       = (string)($_POST['form_token'] ?? '');

    if (!hash_equals($_SESSION['dev_form_token'], $token)) {
        $error = 'Недействительный запрос. Обновите страницу и попробуйте снова.';
    } elseif (($validation = bug_reports_validate($title, $description, $page)) !== '') {
        $error = $validation;
    } elseif (time() - (int)($_SESSION['dev_last_report'] ?? 0) < 30) {
        // Защита от спама и случайных двойных отправок
        $error = 'Подождите немного перед отправкой следующего сообщения.';
    } else {
        try {
            bug_reports_insert($conn, $user_id, $username, $title, $description, $page);

            $_SESSION['dev_last_report'] = time();
            $_SESSION['dev_form_token']  = bin2hex(random_bytes(32));
            $_SESSION['dev_flash']       = 'Баг успешно отправлен разработчикам.';

            $conn->close();
            header('Location: developers.php');
            exit;
        } catch (Throwable $e) {
            error_log('developers.php insert error: ' . $e->getMessage());
            $error = 'Не удалось отправить баг. Попробуйте позже.';
        }
    }
}

$conn->close();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>Разработчикам</title>

    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/developers.css">
    <style>
        /* ===== Страница «Разработчикам»: оформление поверх developers.css ===== */
        body[data-theme] .dev-page { --dv-accent: var(--accent, #5865f2); --dv-line: rgba(128,128,128,.3); --dv-fill: rgba(128,128,128,.08); }
        @supports (color: color-mix(in srgb, red 10%, transparent)) {
            body[data-theme] .dev-page { --dv-line: color-mix(in srgb, currentColor 16%, transparent); --dv-fill: color-mix(in srgb, currentColor 5%, transparent); }
        }
        body[data-theme] .dev-page{display:flex;flex-direction:column;gap:18px}
        body[data-theme] .dev-page > .dev-hero, body[data-theme] .dev-page > .dev-card, body[data-theme] .dev-page > .dev-alert{margin:0}
        
        /* Шапка страницы */
        body[data-theme] .dev-page .dev-hero{position:relative;overflow:hidden;padding:30px;border-radius:22px;border:1px solid var(--dv-line);
          background:
            radial-gradient(1px 1px at 11% 30%,rgba(255,255,255,.8),transparent 100%),
            radial-gradient(1px 1px at 37% 74%,rgba(255,255,255,.55),transparent 100%),
            radial-gradient(1.5px 1.5px at 63% 21%,rgba(255,255,255,.75),transparent 100%),
            radial-gradient(1px 1px at 80% 66%,rgba(255,255,255,.5),transparent 100%),
            radial-gradient(1px 1px at 93% 17%,rgba(255,255,255,.65),transparent 100%),
            radial-gradient(520px 230px at 100% 0%,rgba(88,101,242,.34),transparent 70%),
            linear-gradient(135deg,rgba(88,101,242,.16),rgba(88,101,242,.04))}
        body[data-theme] .dev-page .dev-hero-row{display:flex;align-items:center;gap:20px}
        body[data-theme] .dev-page .dev-hero-icon{flex:none;width:68px;height:68px;display:grid;place-items:center;border-radius:21px;color:#fff;
          background:linear-gradient(145deg,#707bff,#4350d6);
          box-shadow:0 10px 26px -10px rgba(88,101,242,.9),inset 0 1px 0 rgba(255,255,255,.28)}
        body[data-theme] .dev-page .dev-hero-icon svg{width:34px;height:34px}
        body[data-theme] .dev-page .dev-hero h1{margin:0 0 8px;font-size:clamp(24px,3.6vw,32px);line-height:1.15;letter-spacing:-.015em}
        body[data-theme] .dev-page .dev-hero p{margin:0;max-width:52ch;line-height:1.55;opacity:.8}
        
        /* Карточки */
        body[data-theme] .dev-page .dev-card{padding:26px;border-radius:20px;border:1px solid var(--dv-line)}
        body[data-theme] .dev-page .dev-card-head{display:flex;align-items:center;gap:12px;margin:0 0 10px}
        body[data-theme] .dev-page .dev-card-ico{flex:none;width:42px;height:42px;display:grid;place-items:center;border-radius:13px;
          color:var(--dv-accent);background:rgba(88,101,242,.16);font-size:0}
        body[data-theme] .dev-page .dev-card-ico svg{width:22px;height:22px}
        body[data-theme] .dev-page .dev-card-title{margin:0;font-size:19px;line-height:1.25;letter-spacing:-.01em}
        body[data-theme] .dev-page .dev-card-text{margin:0 0 22px;max-width:62ch;line-height:1.6;opacity:.76}
        
        /* Форма */
        body[data-theme] .dev-page .dev-group{margin:0 0 20px}
        body[data-theme] .dev-page .dev-label{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 8px;font-size:14px;font-weight:600}
        body[data-theme] .dev-page .dev-label small{padding:3px 9px;border-radius:999px;border:1px solid var(--dv-line);background:var(--dv-fill);
          font-size:11px;font-weight:600;line-height:1.3;opacity:.85}
        body[data-theme] .dev-page .dev-label small.dev-req{color:var(--dv-accent);background:rgba(88,101,242,.14);border-color:rgba(88,101,242,.38);opacity:1}
        body[data-theme] .dev-page .dev-input,body[data-theme] .dev-page .dev-textarea{display:block;width:100%;box-sizing:border-box;padding:13px 15px;border-radius:12px;
          border:1px solid var(--dv-line);font:inherit;line-height:1.4;
          transition:border-color .15s ease,box-shadow .15s ease}
        body[data-theme] .dev-page .dev-input:not(.dev-select),body[data-theme] .dev-page .dev-textarea{background:var(--dv-fill);color:inherit}
        body[data-theme] .dev-page .dev-textarea{min-height:160px;resize:vertical;line-height:1.55}
        body[data-theme] .dev-page .dev-input::placeholder,body[data-theme] .dev-page .dev-textarea::placeholder{color:inherit;opacity:.45}
        body[data-theme] .dev-page .dev-input:hover,body[data-theme] .dev-page .dev-textarea:hover{border-color:rgba(88,101,242,.55)}
        body[data-theme] .dev-page .dev-input:focus,body[data-theme] .dev-page .dev-textarea:focus{outline:none;border-color:var(--dv-accent);box-shadow:0 0 0 3px rgba(88,101,242,.28)}
        body[data-theme] .dev-page .dev-counter{margin-top:6px;text-align:right;font-size:12px;font-variant-numeric:tabular-nums;opacity:.6}
        
        body[data-theme] .dev-page .dev-submit{display:inline-flex;align-items:center;justify-content:center;gap:10px;padding:14px 24px;border:0;border-radius:12px;
          cursor:pointer;font:inherit;font-weight:600;color:#fff;
          background:linear-gradient(180deg,#6a76ff,#4955e6);
          box-shadow:0 8px 20px -8px rgba(88,101,242,.8),inset 0 1px 0 rgba(255,255,255,.22);
          transition:transform .15s ease,filter .15s ease,box-shadow .15s ease}
        body[data-theme] .dev-page .dev-submit svg{width:18px;height:18px;flex:none}
        body[data-theme] .dev-page .dev-submit:hover{transform:translateY(-1px);filter:brightness(1.07)}
        body[data-theme] .dev-page .dev-submit:active{transform:none}
        body[data-theme] .dev-page .dev-submit:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(88,101,242,.45)}
        body[data-theme] .dev-page .dev-submit:disabled{opacity:.6;cursor:not-allowed;transform:none;filter:none}
        
        /* Подсказки */
        body[data-theme] .dev-page .dev-tips{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:26px 0 0;padding:22px 0 0;border-top:1px solid var(--dv-line)}
        body[data-theme] .dev-page .dev-tip{display:flex;flex-direction:column;align-items:flex-start;gap:6px;padding:16px;border-radius:14px;
          border:1px solid var(--dv-line);background:var(--dv-fill);font-size:13px;line-height:1.5;text-align:left}
        body[data-theme] .dev-page .dev-tip > span{flex:none;width:36px;height:36px;display:grid;place-items:center;margin:0 0 4px;border-radius:11px;
          color:var(--dv-accent);background:rgba(88,101,242,.16);font-size:0}
        body[data-theme] .dev-page .dev-tip > span svg{width:19px;height:19px}
        body[data-theme] .dev-page .dev-tip b{display:block;font-size:14px}
        body[data-theme] .dev-page .dev-tip p{margin:0;opacity:.74}
        
        /* Уведомления */
        body[data-theme] .dev-page .dev-alert{display:flex;align-items:flex-start;gap:12px;padding:14px 16px;border-radius:14px;border:1px solid;line-height:1.5}
        body[data-theme] .dev-page .dev-alert-ico{flex:none;display:grid;place-items:center;width:22px;height:22px;font-size:0}
        body[data-theme] .dev-page .dev-alert-ico svg{width:22px;height:22px}
        body[data-theme] .dev-page .dev-alert-success{background:rgba(47,182,122,.12);border-color:rgba(47,182,122,.42)}
        body[data-theme] .dev-page .dev-alert-success .dev-alert-ico{color:#2fb67a}
        body[data-theme] .dev-page .dev-alert-error{background:rgba(237,66,69,.11);border-color:rgba(237,66,69,.42)}
        body[data-theme] .dev-page .dev-alert-error .dev-alert-ico{color:#ed4245}
        
        /* Информация о пользователе */
        body[data-theme] .dev-page .dev-user{display:flex;align-items:center;gap:16px}
        body[data-theme] .dev-page .dev-user-avatar{flex:none;width:58px;height:58px;display:grid;place-items:center;overflow:hidden;border-radius:50%;
          font-size:22px;font-weight:700;color:#fff;background:linear-gradient(145deg,#707bff,#4350d6);box-shadow:0 0 0 3px rgba(88,101,242,.3)}
        body[data-theme] .dev-page .dev-user-avatar img{display:block;width:100%;height:100%;object-fit:cover}
        body[data-theme] .dev-page .dev-user-name{margin:0 0 4px;font-size:16px;font-weight:700}
        body[data-theme] .dev-page .dev-user-note{margin:0;font-size:13px;line-height:1.55;opacity:.74}
        @media (max-width: 640px) {
            body[data-theme] .dev-page .dev-tips { grid-template-columns: 1fr; }
            body[data-theme] .dev-page .dev-hero { padding: 22px; }
            body[data-theme] .dev-page .dev-card { padding: 20px; }
            body[data-theme] .dev-page .dev-hero-icon { width: 54px; height: 54px; border-radius: 17px; }
            body[data-theme] .dev-page .dev-hero-icon svg { width: 28px; height: 28px; }
            body[data-theme] .dev-page .dev-submit { width: 100%; }
        }
        @media (prefers-reduced-motion: reduce) {
            body[data-theme] .dev-page .dev-submit, body[data-theme] .dev-page .dev-input, body[data-theme] .dev-page .dev-textarea { transition: none; }
            body[data-theme] .dev-page .dev-submit:hover { transform: none; }
        }
    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= e($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main>
            <div class="dev-page">

                <section class="dev-hero">
                    <div class="dev-hero-row">
                        <div class="dev-hero-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M8 2l1.5 2M16 2l-1.5 2"/>
                                <path d="M9 7.5a3 3 0 0 1 6 0"/>
                                <rect x="7" y="7.5" width="10" height="12" rx="5"/>
                                <path d="M12 11v8M3 12h4M17 12h4M4 19l3-2M20 19l-3-2M4 6l3 2M20 6l-3 2"/>
                            </svg>
                        </div>
                        <div>
                            <h1>Разработчикам</h1>
                            <p>Нашли ошибку или столкнулись с проблемой? Сообщите нам, и мы постараемся её исправить.</p>
                        </div>
                    </div>
                </section>

                <?php if ($success): ?>
                    <div class="dev-alert dev-alert-success" role="status">
                        <span class="dev-alert-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="m8 12.5 2.8 2.8L16 9.5"/></svg></span>
                        <span><?= e($success) ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="dev-alert dev-alert-error" role="alert">
                        <span class="dev-alert-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3.5 2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17.2h.01"/></svg></span>
                        <span><?= e($error) ?></span>
                    </div>
                <?php endif; ?>

                <section class="dev-card">
                    <div class="dev-card-head">
                        <div class="dev-card-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 21V4"/><path d="M5 4h11l-2 4 2 4H5"/></svg></div>
                        <h2 class="dev-card-title">Сообщить об ошибке</h2>
                    </div>
                    <p class="dev-card-text">
                        Опишите проблему как можно подробнее. Это поможет разработчикам быстрее найти и исправить ошибку.
                    </p>

                    <form method="POST" action="developers.php" id="bugForm">
                        <input type="hidden" name="form_token" value="<?= e($_SESSION['dev_form_token']) ?>">

                        <div class="dev-group">
                            <label class="dev-label" for="bugTitle">
                                Название ошибки
                                <small class="dev-req">обязательно</small>
                            </label>
                            <input type="text" id="bugTitle" name="title" class="dev-input"
                                   placeholder="Например: Не открываются сообщения"
                                   maxlength="255" value="<?= e($title) ?>" required>
                        </div>

                        <div class="dev-group">
                            <label class="dev-label" for="bugPage">
                                Где произошла ошибка?
                                <small class="dev-opt">необязательно</small>
                            </label>
                            <select id="bugPage" name="page" class="dev-input dev-select">
                                <option value="">Не выбрано</option>
                                <?php foreach ($page_options as $option): ?>
                                    <option value="<?= e($option) ?>"<?= $page === $option ? ' selected' : '' ?>><?= e($option) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="dev-group">
                            <label class="dev-label" for="bugDesc">
                                Описание проблемы
                                <small class="dev-req">обязательно</small>
                            </label>
                            <textarea id="bugDesc" name="description" class="dev-textarea"
                                      placeholder="Что произошло? Какие действия привели к ошибке?"
                                      maxlength="10000" required><?= e($description) ?></textarea>
                            <div class="dev-counter"><span id="descCount">0</span> / 10000</div>
                        </div>

                        <button type="submit" class="dev-submit" id="submitBtn">
                            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M3.4 20.4 20.85 12.92a1 1 0 0 0 0-1.84L3.4 3.6a1 1 0 0 0-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91z"/></svg>
                            <span id="submitText">Отправить разработчикам</span>
                        </button>
                    </form>

                    <div class="dev-tips">
                        <div class="dev-tip"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.4"/></svg></span><b>Где</b><p>Укажите страницу, на которой возникла ошибка.</p></div>
                        <div class="dev-tip"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M9 6h11M9 12h11M9 18h11"/><path d="M4.5 6h.01M4.5 12h.01M4.5 18h.01" stroke-width="2.8"/></svg></span><b>Что делали</b><p>Опишите действия, после которых появилась проблема.</p></div>
                        <div class="dev-tip"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M20 12a8 8 0 0 1-8 8 8 8 0 0 1-3.7-.9L4 20l1.1-4.1A8 8 0 1 1 20 12z"/><path d="M9 10.5h6M9 13.5h4"/></svg></span><b>Текст ошибки</b><p>Если на экране появилось сообщение, приложите его.</p></div>
                    </div>
                </section>

                <section class="dev-card">
                    <div class="dev-card-head">
                        <div class="dev-card-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="8" r="4"/><path d="M4.5 21v-.5a6.5 6.5 0 0 1 6.5-6.5h2a6.5 6.5 0 0 1 6.5 6.5v.5"/></svg></div>
                        <h2 class="dev-card-title">Ваша информация</h2>
                    </div>
                    <div class="dev-user">
                        <div class="dev-user-avatar">
                            <?php if ($avatar_ok): ?>
                                <img src="<?= e($avatar) ?>" alt="">
                            <?php else: ?>
                                <?= e($avatarLetter) ?>
                            <?php endif; ?>
                        </div>
                        <div>
                            <div class="dev-user-name"><?= e($username) ?></div>
                            <p class="dev-user-note">
                                Обращение будет отправлено от вашего аккаунта. Разработчики смогут увидеть описание проблемы и страницу, на которой она возникла.
                            </p>
                        </div>
                    </div>
                </section>

            </div>
        </main>

        <?php include __DIR__ . '/includes/footer.php'; ?>
    </div>

    <script src="assets/js/developers.js"></script>
    <script src="assets/js/script.js"></script>

</body>
</html>

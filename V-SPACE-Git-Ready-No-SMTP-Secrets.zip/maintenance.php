<?php
declare(strict_types=1);

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
// Камера, микрофон, показ экрана и автозвук разрешены (нужны для звонков), геоданные — запрещены.
// Раньше здесь стояло camera=() — это выключало камеру на всех страницах, где подключён этот файл.
header('Permissions-Policy: microphone=(self), camera=(self), display-capture=(self), autoplay=(self), fullscreen=(self), speaker-selection=(self), geolocation=()');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; media-src 'self' blob:; font-src 'self' data:;");

if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'restart.php') {
    return;
}

$maintenanceFile = __DIR__ . DIRECTORY_SEPARATOR . 'maintenance.lock';
if (!is_file($maintenanceFile)) {
    return;
}

$expiresAt = (int)trim((string)file_get_contents($maintenanceFile));
if ($expiresAt <= time()) {
    unlink($maintenanceFile);
    return;
}

if (isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] === 1) {
    $remaining = max(1, $expiresAt - time());
    ?>
    <style>
        .server-restart-banner {
            position: fixed;
            top: 0;
            left: 50%;
            z-index: 100000;
            width: min(90%, 720px);
            min-height: 42px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 8px 18px;
            box-sizing: border-box;
            overflow: hidden;
            background: rgba(197, 22, 46, 0.92);
            border: 1px solid rgba(255, 255, 255, 0.18);
            border-top: 0;
            border-radius: 0 0 16px 16px;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            color: #fff;
            font: 700 13px/1.2 Arial, sans-serif;
            text-align: center;
            box-shadow: 0 2px 14px rgba(197, 22, 46, 0.45);
            transform: translateX(-50%);
        }

        .server-restart-banner::after {
            position: absolute;
            top: 0;
            bottom: 0;
            left: -35%;
            width: 24%;
            content: "";
            background: linear-gradient(105deg, transparent, rgba(255, 255, 255, 0.85), transparent);
            transform: skewX(-20deg);
            animation: serverRestartShine 1.8s linear infinite;
            pointer-events: none;
        }

        .server-restart-banner > * {
            position: relative;
            z-index: 1;
        }

        .server-restart-label {
            letter-spacing: 0.2px;
        }

        .server-restart-timer {
            min-width: 38px;
            color: #fff;
            font-variant-numeric: tabular-nums;
        }

        @keyframes serverRestartShine {
            from { left: -35%; }
            to { left: 115%; }
        }

        @media (prefers-reduced-motion: reduce) {
            .server-restart-banner::after {
                animation: none;
            }
        }
    </style>
    <div class="server-restart-banner" id="serverRestartBanner" role="status">
        <span aria-hidden="true">⚠</span>
        <span class="server-restart-label">Технические рестарт</span>
        <span class="server-restart-timer" id="serverRestartTimer">05:00</span>
    </div>
    <script>
        (function () {
            var expiresAt = <?= $expiresAt ?> * 1000;
            var timer = document.getElementById('serverRestartTimer');
            if (!timer) return;

            function updateRestartTimer() {
                var seconds = Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000));
                var minutes = Math.floor(seconds / 60);
                var remainder = seconds % 60;
                timer.textContent = String(minutes).padStart(2, '0') + ':' + String(remainder).padStart(2, '0');

                if (seconds === 0) {
                    window.location.reload();
                    return;
                }

                window.setTimeout(updateRestartTimer, 1000);
            }

            updateRestartTimer();
        }());
    </script>
    <?php
    return;
}

$remaining = max(1, $expiresAt - time());
http_response_code(503);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="<?= $remaining ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Технические работы — VS SPACE</title>
    <style>
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #10121c; color: #f2f3f5; font-family: Arial, sans-serif; }
        .maintenance { max-width: 520px; padding: 36px; text-align: center; border: 1px solid #3f4147; border-radius: 16px; background: #1e1f2a; }
        h1 { margin-top: 0; color: #8ea1ff; }
        p { color: #b5bac1; line-height: 1.6; }
    </style>
</head>
<body>
    <main class="maintenance">
        <h1>Технические работы</h1>
        <p>Сайт временно перезапускается. Страница обновится автоматически через 5 минут.</p>
    </main>
</body>
</html>
<?php
exit;

<?php
/**
 * Бэкап по расписанию (только из консоли / cron).
 *
 *   php backup_cron.php            — только база данных
 *   php backup_cron.php full       — база + код сайта
 *   php backup_cron.php full --uploads   — + загруженные пользователями файлы
 *
 * Пример crontab (каждую ночь в 03:30):
 *   30 3 * * * /usr/bin/php /путь/к/сайту/backup_cron.php >> /путь/к/сайту/storage/backups/cron.log 2>&1
 *
 * Хранится последних VSB_KEEP_CRON (14) таких бэкапов, старые удаляются автоматически.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/backup.php';

$args = array_slice($argv, 1);
$type = 'db';
foreach ($args as $a) {
    if (in_array($a, ['db', 'code', 'full'], true)) {
        $type = $a;
    }
}
$withUploads = in_array('--uploads', $args, true);

try {
    $conn = db_connect(true);
    $meta = vsb_create($conn, $type, $withUploads, 'Автобэкап по расписанию', [], 'cron');
    echo '[' . date('Y-m-d H:i:s') . '] OK ' . $meta['file'] . ' (' . vsb_fmt_size((int)$meta['size']) . ")\n";
} catch (Throwable $e) {
    fwrite(STDERR, '[' . date('Y-m-d H:i:s') . '] ОШИБКА: ' . $e->getMessage() . "\n");
    exit(1);
}

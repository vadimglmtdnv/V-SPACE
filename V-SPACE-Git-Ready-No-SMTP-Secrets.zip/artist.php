<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| ПОДКЛЮЧЕНИЕ К MYSQL
|--------------------------------------------------------------------------
*/

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

$user_id = (int)$_SESSION["user_id"];

/*
|--------------------------------------------------------------------------
| СТРАНИЦА АРТИСТА: artist.php?id=ID
| Раньше жила внутри music.php (?artist=ID). Вид, шапка и CSS — те же.
|--------------------------------------------------------------------------
*/

$viewArtistId = isset($_GET["id"]) && ctype_digit((string)$_GET["id"]) ? (int)$_GET["id"] : 0;

/*
|--------------------------------------------------------------------------
| СОЗДАНИЕ ТАБЛИЦЫ MUSIC ЕСЛИ ЕЁ НЕТ
|--------------------------------------------------------------------------
*/

$conn->query("
    CREATE TABLE IF NOT EXISTS music (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        title VARCHAR(255) NOT NULL,
        filename VARCHAR(255) NOT NULL,
        filepath VARCHAR(255) NOT NULL,
        filesize INT(11) DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX user_id (user_id),
        INDEX title (title)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Проверяем и добавляем колонки если их нет
$columns = [
    'filename' => 'VARCHAR(255) NOT NULL AFTER title',
    'filepath' => 'VARCHAR(255) NOT NULL AFTER filename',
    'filesize' => 'INT(11) DEFAULT 0 AFTER filepath'
];

foreach ($columns as $col_name => $col_def) {
    $check = $conn->query("SHOW COLUMNS FROM music LIKE '$col_name'");
    if ($check && $check->num_rows == 0) {
        $conn->query("ALTER TABLE music ADD COLUMN $col_name $col_def");
    }
}

// Роль «музыкант / продюсер»: загружать музыку могут только они и администраторы.
// Колонка создаётся автоматически; выдаёт и забирает роль продюсер (блок справа).
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'is_musician'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN is_musician TINYINT(1) NOT NULL DEFAULT 0");
}

// Роль «продюсер»: только продюсер управляет музыкантами (выдаёт и забирает им доступ к загрузке).
// Колонка создаётся автоматически, роль выдаётся вручную в SQL:
//   UPDATE users SET is_producer = 1 WHERE id = 123;
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'is_producer'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN is_producer TINYINT(1) NOT NULL DEFAULT 0");
}

// Альбомы: отдельная таблица + колонка album_id в music (NULL = трек вне альбома)
$conn->query("
    CREATE TABLE IF NOT EXISTS music_albums (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description VARCHAR(1000) NOT NULL DEFAULT '',
        cover VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$check = $conn->query("SHOW COLUMNS FROM music LIKE 'album_id'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE music ADD COLUMN album_id INT(11) NULL DEFAULT NULL");
    $conn->query("ALTER TABLE music ADD INDEX album_id (album_id)");
}

// Счётчик прослушиваний: по нему строится блок «Популярное» на странице артиста
$check = $conn->query("SHOW COLUMNS FROM music LIKE 'plays'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE music ADD COLUMN plays INT(11) NOT NULL DEFAULT 0");
}

// Шапка (баннер) страницы артиста: путь к картинке в uploads/music/banners/
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'music_banner'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN music_banner VARCHAR(255) NULL DEFAULT NULL");
}

// Имя артиста на его странице (необязательно): пусто = показывается обычный ник
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'music_name'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN music_name VARCHAR(40) NULL DEFAULT NULL");
}

// Обложка трека (необязательная): её ставит тот, кто загружает трек
$check = $conn->query("SHOW COLUMNS FROM music LIKE 'cover'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE music ADD COLUMN cover VARCHAR(255) NULL DEFAULT NULL");
}

// «Моя музыка»: личная подборка — чужие треки, которые пользователь добавил себе
$conn->query("
    CREATE TABLE IF NOT EXISTS music_library (
        user_id INT(11) NOT NULL,
        track_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, track_id),
        INDEX track_id (track_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Подписки на артистов
$conn->query("
    CREATE TABLE IF NOT EXISTS music_follows (
        follower_id INT(11) NOT NULL,
        artist_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (follower_id, artist_id),
        INDEX artist_id (artist_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

/*
|--------------------------------------------------------------------------
| CSRF-ТОКЕН (общий с остальными страницами сайта)
|--------------------------------------------------------------------------
*/

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION["csrf_token"];

function musicCsrfOk(): bool
{
    $token = $_POST["csrf_token"] ?? ($_GET["csrf"] ?? "");
    return is_string($token) && $token !== ""
        && hash_equals($_SESSION["csrf_token"] ?? "", $token);
}

/*
|--------------------------------------------------------------------------
| ДАННЫЕ ПОЛЬЗОВАТЕЛЯ
|--------------------------------------------------------------------------
*/

$username = "Пользователь";
$avatarLetter = "P";
$is_admin = false;
$is_musician = false;
$is_producer = false;

$stmt = $conn->prepare("
    SELECT username, avatar, is_admin, is_musician, is_producer
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    if (!empty($user["username"])) {
        $username = $user["username"];
    }
    $avatarLetter = mb_strtoupper(
        mb_substr($username, 0, 1, "UTF-8"),
        "UTF-8"
    );
    $is_admin = !empty($user["is_admin"]);
    $is_musician = !empty($user["is_musician"]);
    $is_producer = !empty($user["is_producer"]);
}

$stmt->close();

// Как и в ленте, пользователь с id 1 считается администратором
if ($user_id === 1) {
    $is_admin = true;
}

// Добавлять треки и альбомы может любой вошедший пользователь (роль музыканта больше не нужна)
$can_upload = true;

// Какие треки пользователь уже добавил себе (для кнопки «+» в строке трека)
$libraryIds = [];
$stmt = $conn->prepare("SELECT track_id FROM music_library WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$libRes = $stmt->get_result();
while ($libRes && ($libRow = $libRes->fetch_row())) {
    $libraryIds[(int)$libRow[0]] = true;
}
$stmt->close();
/*
|--------------------------------------------------------------------------
| ПАПКА МУЗЫКИ
|--------------------------------------------------------------------------
*/

$musicDir = __DIR__ . "/uploads/music/";
$musicUrl = "uploads/music/";

if (!is_dir($musicDir)) {
    mkdir($musicDir, 0755, true);
}


/*
|--------------------------------------------------------------------------
| СООБЩЕНИЯ И РЕДИРЕКТЫ (один раз после POST)
|--------------------------------------------------------------------------
*/

$error = "";
$success = "";

if (!empty($_SESSION["music_flash"]) && is_array($_SESSION["music_flash"])) {
    $flash = $_SESSION["music_flash"];
    unset($_SESSION["music_flash"]);
    if (($flash["type"] ?? "") === "success") {
        $success = (string)($flash["text"] ?? "");
    } else {
        $error = (string)($flash["text"] ?? "");
    }
}

function musicRedirect(string $type, string $text, string $to): void
{
    $_SESSION["music_flash"] = ["type" => $type, "text" => $text];
    header("Location: " . $to);
    exit;
}

$action = $_POST["action"] ?? "";

/*
|--------------------------------------------------------------------------
| ПОДПИСКА И СМЕНА ШАПКИ
|--------------------------------------------------------------------------
*/

// Подписаться / отписаться
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($action === "artist_follow" || $action === "artist_unfollow")) {
    $followId = (int)($_POST["artist_id"] ?? 0);
    $back = "artist.php?id=" . $followId;

    if (!musicCsrfOk()) {
        musicRedirect("error", "Сессия устарела. Обновите страницу и попробуйте снова.", $back);
    }
    if ($followId <= 0 || $followId === $user_id) {
        musicRedirect("error", "На эту страницу подписаться нельзя.", "music.php");
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $followId);
    $stmt->execute();
    $exists = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$exists) {
        musicRedirect("error", "Артист не найден.", "music.php");
    }

    if ($action === "artist_follow") {
        $stmt = $conn->prepare("INSERT IGNORE INTO music_follows (follower_id, artist_id) VALUES (?, ?)");
    } else {
        $stmt = $conn->prepare("DELETE FROM music_follows WHERE follower_id = ? AND artist_id = ?");
    }
    $stmt->bind_param("ii", $user_id, $followId);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $back);
    exit;
}

// Сменить имя артиста: только сам артист (пусто = вернуть обычный ник)
if ($_SERVER["REQUEST_METHOD"] === "POST" && $action === "artist_rename") {
    $renameId = (int)($_POST["artist_id"] ?? 0);
    $back = "artist.php?id=" . $renameId;

    if (!musicCsrfOk()) {
        musicRedirect("error", "Сессия устарела. Обновите страницу и попробуйте снова.", $back);
    }
    if ($renameId <= 0 || $renameId !== $user_id) {
        musicRedirect("error", "Менять имя может только сам артист.", $back);
    }

    $newName = (string)($_POST["music_name"] ?? "");
    $newName = (string)preg_replace('/[\x00-\x1F\x7F]+/u', " ", $newName);
    $newName = trim((string)preg_replace('/\s+/u', " ", $newName));
    if (mb_strlen($newName, "UTF-8") > 40) {
        musicRedirect("error", "Имя не должно быть длиннее 40 символов.", $back);
    }

    $stored = $newName === "" ? null : $newName;
    $stmt = $conn->prepare("UPDATE users SET music_name = ? WHERE id = ?");
    $stmt->bind_param("si", $stored, $renameId);
    $ok = $stmt->execute();
    $stmt->close();

    if ($ok) {
        musicRedirect("success", $newName === "" ? "Имя сброшено: показывается ваш ник." : "Имя обновлено.", $back);
    }
    musicRedirect("error", "Не удалось сохранить имя.", $back);
}

// Сменить / убрать шапку: только сам артист
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($action === "artist_banner" || $action === "artist_banner_remove")) {
    $bannerOwner = (int)($_POST["artist_id"] ?? 0);
    $back = "artist.php?id=" . $bannerOwner;
    $bannerDir = $musicDir . "banners/";

    if (!musicCsrfOk()) {
        musicRedirect("error", "Сессия устарела. Обновите страницу и попробуйте снова.", $back);
    }
    if ($bannerOwner <= 0 || $bannerOwner !== $user_id) {
        musicRedirect("error", "Менять шапку может только владелец страницы.", $back);
    }

    $stmt = $conn->prepare("SELECT music_banner FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $bannerOwner);
    $stmt->execute();
    $oldRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$oldRow) {
        musicRedirect("error", "Артист не найден.", "music.php");
    }
    $oldBanner = (string)($oldRow["music_banner"] ?? "");

    // Удаляем только файлы из своей папки баннеров, чужие пути из БД не трогаем
    $deleteOldBanner = function () use ($oldBanner, $bannerDir) {
        if ($oldBanner !== "" && strpos($oldBanner, "uploads/music/banners/") === 0) {
            $f = $bannerDir . basename($oldBanner);
            if (is_file($f)) {
                @unlink($f);
            }
        }
    };

    if ($action === "artist_banner_remove") {
        $stmt = $conn->prepare("UPDATE users SET music_banner = NULL WHERE id = ?");
        $stmt->bind_param("i", $bannerOwner);
        $stmt->execute();
        $stmt->close();
        $deleteOldBanner();
        musicRedirect("success", "Шапка убрана.", $back);
    }

    if (!isset($_FILES["banner"]) || $_FILES["banner"]["error"] === UPLOAD_ERR_NO_FILE) {
        musicRedirect("error", "Выберите картинку для шапки.", $back);
    }
    $bf = $_FILES["banner"];
    $bannerTypes = [IMAGETYPE_JPEG => "jpg", IMAGETYPE_PNG => "png", IMAGETYPE_WEBP => "webp"];

    if ($bf["error"] !== UPLOAD_ERR_OK) {
        musicRedirect("error", "Не удалось загрузить шапку.", $back);
    }
    if ($bf["size"] > 8 * 1024 * 1024) {
        musicRedirect("error", "Шапка не должна быть больше 8 МБ.", $back);
    }
    $bi = @getimagesize($bf["tmp_name"]);
    if (!$bi || !isset($bannerTypes[$bi[2]])) {
        musicRedirect("error", "Шапка должна быть JPG, PNG или WEBP.", $back);
    }
    if (!is_dir($bannerDir)) {
        mkdir($bannerDir, 0755, true);
    }
    $bannerName = "banner_" . $bannerOwner . "_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $bannerTypes[$bi[2]];
    if (!move_uploaded_file($bf["tmp_name"], $bannerDir . $bannerName)) {
        musicRedirect("error", "Не удалось сохранить шапку.", $back);
    }
    $bannerPath = $musicUrl . "banners/" . $bannerName;
    $stmt = $conn->prepare("UPDATE users SET music_banner = ? WHERE id = ?");
    $stmt->bind_param("si", $bannerPath, $bannerOwner);
    if ($stmt->execute()) {
        $stmt->close();
        $deleteOldBanner();
        musicRedirect("success", "Шапка обновлена.", $back);
    }
    $stmt->close();
    @unlink($bannerDir . $bannerName);
    musicRedirect("error", "Не удалось сохранить шапку.", $back);
}


/*
|--------------------------------------------------------------------------
| ДАННЫЕ АРТИСТА
|--------------------------------------------------------------------------
*/

function musicRows(mysqli_stmt $stmt): array
{
    $stmt->execute();
    $rows = [];
    $res = $stmt->get_result();
    while ($res && ($row = $res->fetch_assoc())) {
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

$trackSelect = "
    SELECT m.id, m.user_id, m.title, m.filename, m.filepath, m.filesize, m.created_at,
           m.plays, m.album_id, m.cover AS track_cover, al.title AS album_title, al.cover AS album_cover,
           COALESCE(NULLIF(u.music_name, ''), u.username) AS username
    FROM music m
    LEFT JOIN users u ON u.id = m.user_id
    LEFT JOIN music_albums al ON al.id = m.album_id
";
$albumSelect = "
    SELECT a.id, a.user_id, a.title, a.description, a.cover, a.created_at, COALESCE(NULLIF(u.music_name, ''), u.username) AS username,
           (SELECT COUNT(*) FROM music mm WHERE mm.album_id = a.id) AS tracks_count
    FROM music_albums a
    LEFT JOIN users u ON u.id = a.user_id
";

$artist = null;
$artist_albums = [];
$artist_tracks = [];
$artist_popular = [];
$artist_followers = 0;
$artist_following = false;
$artistName = "";

if ($viewArtistId > 0) {
    $stmt = $conn->prepare("SELECT id, username, avatar, status, is_musician, is_producer, is_admin, music_banner, music_name FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $viewArtistId);
    $rows = musicRows($stmt);
    $artist = $rows[0] ?? null;
}

if ($artist) {
    // Имя артиста: своё, если задано, иначе ник
    $artistName = trim((string)($artist["music_name"] ?? "")) !== ""
        ? trim((string)$artist["music_name"])
        : (string)$artist["username"];

    $stmt = $conn->prepare($albumSelect . " WHERE a.user_id = ? ORDER BY a.id DESC");
    $stmt->bind_param("i", $viewArtistId);
    $artist_albums = musicRows($stmt);

    $stmt = $conn->prepare($trackSelect . " WHERE m.user_id = ? ORDER BY m.id DESC");
    $stmt->bind_param("i", $viewArtistId);
    $artist_tracks = musicRows($stmt);

    // Подписчики и состояние подписки
    $stmt = $conn->prepare("SELECT COUNT(*) FROM music_follows WHERE artist_id = ?");
    $stmt->bind_param("i", $viewArtistId);
    $stmt->execute();
    $artist_followers = (int)($stmt->get_result()->fetch_row()[0] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT 1 FROM music_follows WHERE follower_id = ? AND artist_id = ? LIMIT 1");
    $stmt->bind_param("ii", $user_id, $viewArtistId);
    $stmt->execute();
    $artist_following = (bool)$stmt->get_result()->fetch_row();
    $stmt->close();

    // «Популярное»: сначала самые прослушиваемые, при равенстве — новые; не больше 9 (3 колонки по 3)
    $artist_popular = $artist_tracks;
    usort($artist_popular, function ($a, $b) {
        return ((int)$b["plays"] <=> (int)$a["plays"]) ?: ((int)$b["id"] <=> (int)$a["id"]);
    });
    $artist_popular = array_slice($artist_popular, 0, 9);
} else {
    http_response_code(404);
    if ($error === "") {
        $error = "Артист не найден.";
    }
}

function formatFileSize($bytes)
{
    if ($bytes < 1024) {
        return $bytes . " Б";
    }
    if ($bytes < 1024 * 1024) {
        return round($bytes / 1024, 1) . " КБ";
    }
    return round($bytes / 1024 / 1024, 1) . " МБ";
}

/*
|--------------------------------------------------------------------------
| ОДНА СТРОКА ТРЕКА (общая для поиска и общего списка)
|--------------------------------------------------------------------------
*/

function renderTrack(array $track, int $user_id, bool $is_admin, string $csrf_token, int $removeFromAlbum = 0): void
{
    $author = $track["username"] ?: "Пользователь";
    $can_delete = $is_admin || (int)$track["user_id"] === $user_id;
    // Обложка трека; если её нет — обложка альбома (когда она есть в выборке)
    $trackCover = !empty($track["track_cover"]) ? (string)$track["track_cover"]
        : (!empty($track["album_cover"]) ? (string)$track["album_cover"] : "");
    $hasCover = $trackCover !== "" && is_file(__DIR__ . "/" . $trackCover);
    // Кнопка «+ / ✓» — только на чужих треках: добавить в свою музыку или убрать оттуда
    $showLib = (int)$track["user_id"] !== $user_id;
    $inLib = !empty($GLOBALS["libraryIds"][(int)$track["id"]]);
    $libTitle = $inLib ? "Убрать из моей музыки" : "Добавить в мою музыку";
    ?>
    <div class="track">
        <button type="button" class="track-icon track-play<?= $hasCover ? " has-cover" : "" ?>"<?= $hasCover ? ' style="background-image:url(\'' . htmlspecialchars($trackCover, ENT_QUOTES, "UTF-8") . '\')"' : "" ?> aria-label="Воспроизвести" title="Воспроизвести">
            <svg class="i-play" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.52.85l10.4-6.5a1 1 0 0 0 0-1.7L9.52 4.65A1 1 0 0 0 8 5.5z"/></svg>
            <svg class="i-pause" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4.2" height="14" rx="1.2"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.2"/></svg>
        </button>
        <div class="track-info">
            <div class="track-name"><?= htmlspecialchars($track["title"], ENT_QUOTES, "UTF-8") ?></div>
            <div class="track-author">
                Исполнитель: <a href="artist.php?id=<?= (int)$track["user_id"] ?>" class="artist-link"><?= htmlspecialchars($author, ENT_QUOTES, "UTF-8") ?></a>
                <?php if (!empty($track["album_id"]) && !empty($track["album_title"])): ?>
                    · Альбом: <a href="music.php?album=<?= (int)$track["album_id"] ?>" class="artist-link"><?= htmlspecialchars($track["album_title"], ENT_QUOTES, "UTF-8") ?></a>
                <?php endif; ?>
                · Размер: <?= formatFileSize((int)$track["filesize"]) ?>
            </div>
        </div>
        <div class="mp" data-title="<?= htmlspecialchars($track["title"], ENT_QUOTES, "UTF-8") ?>" data-artist="<?= htmlspecialchars($author, ENT_QUOTES, "UTF-8") ?>">
            <audio controls preload="metadata">
                <source src="<?= htmlspecialchars($track["filepath"], ENT_QUOTES, "UTF-8") ?>" type="audio/mpeg">
                Ваш браузер не поддерживает аудио.
            </audio>
            <div class="mp-ui">
                <span class="mp-time mp-cur">0:00</span>
                <input type="range" class="mp-seek" min="0" max="100" value="0" step="any" aria-label="Перемотка">
                <span class="mp-time mp-dur">0:00</span>
                <div class="mp-vol">
                    <button type="button" class="mp-btn mp-mute" aria-label="Выключить звук" title="Выключить звук">
                        <svg class="i-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z" fill="currentColor"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>
                        <svg class="i-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z" fill="currentColor"/><path d="m16 9 5 6M21 9l-5 6"/></svg>
                    </button>
                    <input type="range" class="mp-volume" min="0" max="1" step="0.01" value="1" aria-label="Громкость">
                </div>
            </div>
        </div>
        <?php if ($can_delete || $removeFromAlbum > 0 || $showLib): ?>
            <div class="track-actions">
                <?php if ($showLib): ?>
                    <button type="button" class="track-lib<?= $inLib ? " is-added" : "" ?>"
                            data-track-id="<?= (int)$track["id"] ?>"
                            data-csrf="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>"
                            aria-pressed="<?= $inLib ? "true" : "false" ?>"
                            title="<?= $libTitle ?>" aria-label="<?= $libTitle ?>">
                        <svg class="i-plus" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                        <svg class="i-check" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>
                    </button>
                <?php endif; ?>
                <?php if ($removeFromAlbum > 0): ?>
                    <form method="POST" class="track-remove-form">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                        <input type="hidden" name="action" value="album_remove_track">
                        <input type="hidden" name="album_id" value="<?= $removeFromAlbum ?>">
                        <input type="hidden" name="track_id" value="<?= (int)$track["id"] ?>">
                        <button type="submit" class="track-delete" data-confirm="Убрать трек из альбома? Сам трек останется на сайте.">− Из альбома</button>
                    </form>
                <?php endif; ?>
                <?php if ($can_delete): ?>
                    <a href="music.php?delete=<?= (int)$track["id"] ?>&amp;csrf=<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>&amp;back=artist"
                       class="track-delete" title="Удалить трек" aria-label="Удалить трек"
                       data-confirm="Удалить этот трек? Это нельзя отменить.">✕</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/*
|--------------------------------------------------------------------------
| КАРТОЧКА АЛЬБОМА И АВАТАР (общие для всех видов страницы)
|--------------------------------------------------------------------------
*/

function renderAlbumCard(array $a): void
{
    $count = (int)$a["tracks_count"];
    ?>
    <a class="album-card" href="music.php?album=<?= (int)$a["id"] ?>">
        <div class="album-cover">
            <?php if (!empty($a["cover"])): ?>
                <img src="<?= htmlspecialchars($a["cover"], ENT_QUOTES, "UTF-8") ?>" alt="" loading="lazy">
            <?php else: ?>
                <span>♪</span>
            <?php endif; ?>
        </div>
        <div class="album-title"><?= htmlspecialchars($a["title"], ENT_QUOTES, "UTF-8") ?></div>
        <div class="album-meta">
            <?= htmlspecialchars($a["username"] ?: "Пользователь", ENT_QUOTES, "UTF-8") ?> · <?= $count ?> <?= $count === 1 ? "трек" : "треков" ?>
        </div>
    </a>
    <?php
}

// Путь к аватару: берём как в БД, а если там только имя файла — ищем в uploads/avatars/
function musicAvatarUrl(?string $avatar): string
{
    $avatar = trim((string)$avatar);
    if ($avatar === "") {
        return "";
    }
    if (preg_match('~^(https?:)?//~', $avatar)) {
        return $avatar;
    }
    if (is_file(__DIR__ . "/" . $avatar)) {
        return $avatar;
    }
    if (is_file(__DIR__ . "/uploads/avatars/" . $avatar)) {
        return "uploads/avatars/" . $avatar;
    }
    return "";
}

/*
|--------------------------------------------------------------------------
| ОБОЛОЧКА СТРАНИЦЫ (шапка, уведомления, тема) — как в music.php
|--------------------------------------------------------------------------
*/

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: artist.php?id=" . $viewArtistId);
    exit;
}

$notifications = [];
$notif_count = 0;
$unread_count = 0;
$pending_reports_count = 0;
$current_user_data = [];

try {
    $stmt = $conn->prepare("
        SELECT n.*, u.username as sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

    $stmt = $conn->prepare("SELECT id, username, avatar, status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    if ($is_admin) {
        $result = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
        if ($result) {
            $pending_reports_count = (int)$result->fetch_assoc()['c'];
        }
    }
} catch (Throwable $e) {
    error_log('artist.php shell: ' . $e->getMessage());
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function isOnline(?string $status): bool {
    return $status === 'online';
}


$pageTitle = $artist ? $artistName . " — Музыка" : "Артист не найден";

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, "UTF-8") ?> — PLAYERCHAT</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/music.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/music.css') ?>">
    <link rel="stylesheet" href="assets/css/music-player.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/music-player.css') ?>">
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout music-layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main class="music-main">

            <?php if ($success): ?>
                <div class="alert success"><?= htmlspecialchars($success, ENT_QUOTES, "UTF-8") ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
            <?php endif; ?>


            <?php if ($artist):
                $artistAvatar = musicAvatarUrl($artist["avatar"] ?? "");
                $artistLetter = mb_strtoupper(mb_substr($artistName, 0, 1, "UTF-8"), "UTF-8");
                $artistRole = !empty($artist["is_producer"]) ? "Продюсер"
                    : (!empty($artist["is_musician"]) ? "Музыкант"
                    : (!empty($artist["is_admin"]) || (int)$artist["id"] === 1 ? "Администратор" : ""));
                $artistSize = 0;
                foreach ($artist_tracks as $t) { $artistSize += (int)$t["filesize"]; }
            ?>
                <?php
                $bannerUrl = "";
                if (!empty($artist["music_banner"]) && is_file(__DIR__ . "/" . $artist["music_banner"])) {
                    $bannerUrl = (string)$artist["music_banner"];
                }
                $heroImg = $bannerUrl !== "" ? $bannerUrl : $artistAvatar;
                $isOwnPage = (int)$artist["id"] === $user_id;
                $canEditBanner = $isOwnPage;   // шапку и имя меняет только сам артист
                $followersWord = function (int $n): string {
                    $m10 = $n % 10; $m100 = $n % 100;
                    if ($m10 === 1 && $m100 !== 11) return "подписчик";
                    if ($m10 >= 2 && $m10 <= 4 && ($m100 < 12 || $m100 > 14)) return "подписчика";
                    return "подписчиков";
                };
                ?>
                <section class="card artist-page">
                    <nav class="artist-crumbs" aria-label="Навигация">
                        <a href="music.php">Музыка</a>
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>
                        <span aria-current="page"><?= htmlspecialchars($artistName, ENT_QUOTES, "UTF-8") ?></span>
                    </nav>

                    <div class="artist-hero<?= $heroImg === "" ? " no-image" : "" ?><?= $bannerUrl === "" && $artistAvatar !== "" ? " from-avatar" : "" ?>">
                        <?php if ($heroImg !== ""): ?>
                            <img class="artist-hero-img" src="<?= htmlspecialchars($heroImg, ENT_QUOTES, "UTF-8") ?>" alt="">
                        <?php endif; ?>
                        <div class="artist-hero-shade"></div>

                        <?php if ($canEditBanner): ?>
                            <div class="artist-banner-tools">
                                <form method="POST" enctype="multipart/form-data" class="artist-banner-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                    <input type="hidden" name="action" value="artist_banner">
                                    <input type="hidden" name="artist_id" value="<?= (int)$artist["id"] ?>">
                                    <label class="artist-banner-btn" title="Сменить шапку">
                                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8a2 2 0 0 1 2-2h1.5l1.4-2h6.2l1.4 2H18a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3.5"/></svg>
                                        <span>Сменить шапку</span>
                                        <input type="file" name="banner" id="bannerInput" accept="image/jpeg,image/png,image/webp" hidden>
                                    </label>
                                </form>
                                <?php if ($bannerUrl !== ""): ?>
                                    <form method="POST" class="artist-banner-form">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                        <input type="hidden" name="action" value="artist_banner_remove">
                                        <input type="hidden" name="artist_id" value="<?= (int)$artist["id"] ?>">
                                        <button type="submit" class="artist-banner-btn" title="Убрать шапку" aria-label="Убрать шапку" data-confirm="Убрать шапку страницы?">✕</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="artist-hero-body">
                            <div class="artist-hero-text">
                                <div class="artist-hero-title" id="artistTitleRow">
                                    <h1 class="artist-hero-name"><?= htmlspecialchars($artistName, ENT_QUOTES, "UTF-8") ?></h1>
                                    <?php if ($isOwnPage): ?>
                                        <button type="button" class="artist-name-edit" id="artistNameBtn" title="Изменить имя" aria-label="Изменить имя">
                                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h4L19 9a2.1 2.1 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/></svg>
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <?php if ($isOwnPage): ?>
                                    <form method="POST" class="artist-name-form" id="artistNameForm" hidden>
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                        <input type="hidden" name="action" value="artist_rename">
                                        <input type="hidden" name="artist_id" value="<?= (int)$artist["id"] ?>">
                                        <input type="text" name="music_name" class="artist-name-input" maxlength="40" autocomplete="off"
                                               value="<?= htmlspecialchars($artistName, ENT_QUOTES, "UTF-8") ?>"
                                               placeholder="<?= htmlspecialchars((string)$artist["username"], ENT_QUOTES, "UTF-8") ?>"
                                               aria-label="Имя артиста">
                                        <button type="submit" class="artist-banner-btn">Сохранить</button>
                                        <button type="button" class="artist-banner-btn" id="artistNameCancel">Отмена</button>
                                    </form>
                                <?php endif; ?>
                                <div class="artist-hero-meta">
                                    <?php if ($artistRole !== "" && ($is_admin || $isOwnPage)): ?><span class="artist-badge"><?= $artistRole ?></span><?php endif; ?>
                                    <span><?= $artist_followers ?> <?= $followersWord($artist_followers) ?></span>
                                    <span><?= count($artist_tracks) ?> <?= count($artist_tracks) === 1 ? "трек" : "треков" ?></span>
                                    <?php if (!empty($artist_albums)): ?><span><?= count($artist_albums) ?> <?= count($artist_albums) === 1 ? "альбом" : "альбомов" ?></span><?php endif; ?>
                                </div>
                            </div>
                            <div class="artist-hero-actions">
                                <?php if (!$isOwnPage): ?>
                                    <form method="POST" class="artist-follow-form">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                        <input type="hidden" name="action" value="<?= $artist_following ? "artist_unfollow" : "artist_follow" ?>">
                                        <input type="hidden" name="artist_id" value="<?= (int)$artist["id"] ?>">
                                        <button type="submit" class="hero-btn"<?= $artist_following ? ' title="Нажмите, чтобы отписаться"' : "" ?>>
                                            <?php if ($artist_following): ?>
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4.5 12.5 5 5 10-11"/></svg>
                                                <span>Вы подписаны</span>
                                            <?php else: ?>
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                                                <span>Подписаться</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <?php if (!empty($artist_popular)): ?>
                                    <button type="button" class="hero-btn" id="artistListen">
                                        <svg class="i-play" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.52.85l10.4-6.5a1 1 0 0 0 0-1.7L9.52 4.65A1 1 0 0 0 8 5.5z"/></svg>
                                        <svg class="i-pause" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4.2" height="14" rx="1.2"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.2"/></svg>
                                        <span>Слушать</span>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($artist_popular)): ?>
                        <div class="artist-popular" id="artistPopular" data-csrf="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                            <div class="artist-popular-head">
                                <h2>Популярное</h2>
                                <a href="#artistTracks" class="artist-popular-all" id="artistAll">
                                    Показать все
                                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>
                                </a>
                            </div>
                            <div class="artist-popular-grid">
                                <?php foreach ($artist_popular as $pt):
                                    $ptCover = !empty($pt["track_cover"]) ? (string)$pt["track_cover"]
                        : (!empty($pt["album_cover"]) ? (string)$pt["album_cover"] : $artistAvatar);
                                    ?>
                                    <button type="button" class="pop-row"
                                            data-id="<?= (int)$pt["id"] ?>"
                                            data-src="<?= htmlspecialchars($pt["filepath"], ENT_QUOTES, "UTF-8") ?>"
                                            data-size="<?= (int)$pt["filesize"] ?>">
                                        <span class="pop-cover">
                                            <?php if ($ptCover !== ""): ?>
                                                <img src="<?= htmlspecialchars($ptCover, ENT_QUOTES, "UTF-8") ?>" alt="" loading="lazy">
                                            <?php else: ?>
                                                <span class="pop-cover-note">♪</span>
                                            <?php endif; ?>
                                            <span class="pop-state" aria-hidden="true">
                                                <svg class="i-play" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M8 5.5v13a1 1 0 0 0 1.52.85l10.4-6.5a1 1 0 0 0 0-1.7L9.52 4.65A1 1 0 0 0 8 5.5z"/></svg>
                                                <svg class="i-pause" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><rect x="6" y="5" width="4.2" height="14" rx="1.2"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.2"/></svg>
                                            </span>
                                        </span>
                                        <span class="pop-info">
                                            <span class="pop-title"><?= htmlspecialchars($pt["title"], ENT_QUOTES, "UTF-8") ?></span>
                                            <span class="pop-artist"><?= htmlspecialchars($pt["username"] ?: $artistName, ENT_QUOTES, "UTF-8") ?></span>
                                        </span>
                                        <span class="pop-meta">
                                            <span class="pop-dur">–:––</span>
                                            <span class="pop-kbps" hidden></span>
                                        </span>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="artist-tracks" id="artistTracks">
                        <div class="artist-tracks-head">
                            <h2>Треки <span class="search-result-count"><?= count($artist_tracks) ?></span></h2>
                            <?php if ($isOwnPage && $can_upload): ?>
                                <button type="button" class="artist-add-btn" data-panel="panelArtistUpload" aria-expanded="false" aria-controls="panelArtistUpload">
                                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                                    <span>Добавить музыку</span>
                                </button>
                            <?php endif; ?>
                        </div>

                        <?php if ($isOwnPage && $can_upload): ?>
                            <div class="head-panel artist-upload" id="panelArtistUpload" hidden>
                                <div class="head-panel-title">Добавить музыку</div>
                                <form method="POST" action="music.php" enctype="multipart/form-data" class="upload-form head-form"
                                      id="uploadForm" data-max-bytes="<?= 20 * 1024 * 1024 ?>">
                                    <input type="hidden" name="action" value="upload">
                                    <input type="hidden" name="return_to" value="artist">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                    <input type="file" name="music" class="file-input" accept=".mp3,audio/mpeg" required>
                                    <label class="cover-pick">
                                        <span>Обложка трека (необязательно)</span>
                                        <input type="file" name="track_cover" class="file-input" accept="image/jpeg,image/png,image/webp">
                                    </label>
                                    <button type="submit" class="button">Загрузить MP3</button>
                                </form>
                                <div class="alert error upload-error" id="uploadError" hidden></div>
                            </div>
                        <?php endif; ?>

                        <?php if (empty($artist_tracks)): ?>
                            <div class="empty">
                                <div class="empty-icon">🎵</div>
                                <div>У этого артиста пока нет треков.</div>
                                <?php if ($isOwnPage && $can_upload): ?>
                                    <div class="empty-hint">Нажмите «Добавить музыку», чтобы загрузить первый трек.</div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="track-list">
                                <?php foreach ($artist_tracks as $track): renderTrack($track, $user_id, $is_admin, $csrf_token); endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

                <?php if (!empty($artist_albums)): ?>
                    <section class="card music-block">
                        <div class="music-block-title">Альбомы <span class="search-result-count"><?= count($artist_albums) ?></span></div>
                        <div class="album-grid">
                            <?php foreach ($artist_albums as $a): renderAlbumCard($a); endforeach; ?>
                        </div>
                    </section>
                <?php endif; ?>


            <?php else: ?>
                <section class="card music-block">
                    <div class="empty">
                        <div class="empty-icon">🎵</div>
                        <div>Такой страницы артиста нет.</div>
                        <div class="empty-hint"><a href="music.php" class="artist-link">Вернуться к музыке</a></div>
                    </div>
                </section>
            <?php endif; ?>

        </main>

        <aside class="music-aside"></aside>

        <div class="site-footer">
            SPACE &copy; <span class="year">2026</span>
        </div>

    </div>

    <script src="assets/js/script.js"></script>
    <script src="assets/js/music.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/music.js') ?>"></script>
    <script src="assets/js/music-player.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/music-player.js') ?>"></script>

</body>
</html>

<?php
$conn->close();

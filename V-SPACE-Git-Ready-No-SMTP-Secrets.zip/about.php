<?php

require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
if (is_file(__DIR__ . '/includes/error_logger.php')) { require_once __DIR__ . '/includes/error_logger.php'; }

// Перевод страницы на английский (если выбран English в настройках)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';

try {
    $conn = db_connect();
} catch (Throwable $e) {
    error_log('about.php DB connect error: ' . $e->getMessage());
    die("Ошибка подключения к базе данных.");
}

if ($conn->connect_error) {
    error_log('about.php DB connect error: ' . $conn->connect_error);
    die("Ошибка подключения к базе данных.");
}

$conn->set_charset("utf8mb4");

$user_id = (int)$_SESSION["user_id"];

/* Получаем пользователя */

$stmt = $conn->prepare("
    SELECT id, username, avatar, status, is_admin
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$username = $user["username"] ?: "Пользователь";
$user_status = $user["status"] ?? "offline";
$user_avatar = $user["avatar"] ?? "";
$is_admin = !empty($user["is_admin"]);
$current_user_data = $user;

/* Буква аватарки */

$avatarLetter = mb_strtoupper(
    mb_substr($username, 0, 1, "UTF-8"),
    "UTF-8"
);

/* Онлайн */

function isOnline(string $status): bool
{
    return $status === "online";
}

/* Время уведомления */

function timeAgo(string $datetime): string
{
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;

    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationIcon(string $type): string
{
    $icons = [
        'friend_request' => '👋', 'friend_accepted' => '✅', 'friend_removed' => '❌',
        'like' => '❤️', 'comment' => '💭', 'repost' => '🔁', 'message' => '💬',
        'news' => '📰', 'tag' => '🔖', 'mention' => '@', 'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function getNotificationTypeName(string $type): string
{
    $names = [
        'friend_request' => 'Заявка в друзья', 'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей', 'like' => 'Лайк', 'comment' => 'Комментарий',
        'repost' => 'Репост', 'message' => 'Сообщение', 'news' => 'Новость',
        'tag' => 'Отметка', 'mention' => 'Упоминание', 'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

/* Уведомления и счётчик модерации для шапки (как в index.php) */

$notifications = [];
$notif_count = 0;
$notifTable = $conn->query("SHOW TABLES LIKE 'notifications'");
if ($notifTable && $notifTable->num_rows > 0) {
    $stmt = $conn->prepare("
        SELECT n.*, u.username as sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();
}

$pending_reports_count = 0;
if ($is_admin) {
    $reportsTable = $conn->query("SHOW TABLES LIKE 'reports'");
    if ($reportsTable && $reportsTable->num_rows > 0) {
        $res = $conn->query("SELECT COUNT(*) as c FROM reports WHERE status = 'pending'");
        $pending_reports_count = (int)($res->fetch_assoc()['c'] ?? 0);
    }
}

// Значок «Сообщения» на нижней панели (как в index.php)
$unread_count = shell_unread_messages($conn, $user_id);

/* Статистика для страницы */

// Не считаем удалённые и заблокированные аккаунты (если такие колонки есть)
$activeWhere = "1=1";
$cols = [];
if ($r = $conn->query("SHOW COLUMNS FROM users")) {
    while ($c = $r->fetch_assoc()) {
        $cols[$c['Field']] = true;
    }
}
if (isset($cols['deleted_at'])) {
    $activeWhere .= " AND deleted_at IS NULL";
}
if (isset($cols['is_blocked'])) {
    $activeWhere .= " AND (is_blocked = 0 OR is_blocked IS NULL)";
}

$stats_users = 0;
$stats_online = 0;
if ($r = $conn->query("SELECT COUNT(*) AS c FROM users WHERE $activeWhere")) {
    $stats_users = (int)($r->fetch_assoc()['c'] ?? 0);
}
// «Онлайн» = статус online И активность за последние 5 минут
// (иначе тот, кто закрыл вкладку, висел бы онлайн вечно). Время сравниваем
// средствами MySQL, чтобы не зависеть от часового пояса PHP.
if ($r = $conn->query("
    SELECT COUNT(*) AS c FROM users
    WHERE $activeWhere
      AND status = 'online'
      AND last_seen >= (NOW() - INTERVAL 300 SECOND)
")) {
    $stats_online = (int)($r->fetch_assoc()['c'] ?? 0);
}

/* Тема: обработка переключения через GET + валидация */

$allowedThemes = ['dark', 'light', 'system'];

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowedThemes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, [
        'expires'  => time() + 60 * 60 * 24 * 365,
        'path'     => '/',
        'samesite' => 'Lax',
    ]);
} elseif (isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowedThemes, true)) {
    $theme = $_COOKIE['theme'];
} else {
    $theme = 'dark';
}

/* Человеческое название темы */

$themeNames = [
    'dark'   => 'Тёмная',
    'light'  => 'Светлая',
    'system' => 'Системная',
];
$theme_name = $themeNames[$theme] ?? 'Тёмная';

?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>О нас</title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/about.css">
    <style>
    /* ===== Страница «О нас» (стили изолированы префиксом .ab) ===== */
    .ab{--ink:#eceef7;--mute:#9aa0b8;--surf:rgba(255,255,255,.045);--surf2:rgba(255,255,255,.07);--line:rgba(255,255,255,.09);
        --acc:#b4b6ff;--acc-soft:rgba(138,140,255,.16);--cy:#35d6d0;--btn:#5b5ff0;--orb:.35;--star:rgba(255,255,255,.55);
        --hero:linear-gradient(135deg,rgba(138,140,255,.20),rgba(53,214,208,.07) 60%,transparent);
        display:flex;flex-direction:column;gap:16px;width:100%;color:var(--ink)}
    body[data-theme="light"] .ab{--ink:#14172a;--mute:#5c627a;--surf:#fff;--surf2:#f2f3fa;--line:rgba(20,23,42,.10);
        --acc:#4549c9;--acc-soft:rgba(91,95,240,.10);--cy:#0b9d98;--orb:.18;--star:rgba(91,95,240,.35);
        --hero:linear-gradient(135deg,rgba(91,95,240,.13),rgba(11,157,152,.06) 60%,#fff)}
    @media (prefers-color-scheme:light){
        body[data-theme="system"] .ab{--ink:#14172a;--mute:#5c627a;--surf:#fff;--surf2:#f2f3fa;--line:rgba(20,23,42,.10);
            --acc:#4549c9;--acc-soft:rgba(91,95,240,.10);--cy:#0b9d98;--orb:.18;--star:rgba(91,95,240,.35);
            --hero:linear-gradient(135deg,rgba(91,95,240,.13),rgba(11,157,152,.06) 60%,#fff)}
    }
    .ab *{box-sizing:border-box}

    /* Герой — космос (одинаково во всех темах) */
    .ab-hero{--ink:#f4f5ff;--mute:rgba(222,226,255,.78);--line:rgba(255,255,255,.14);--surf2:rgba(255,255,255,.10);--acc:#c9cbff;
        position:relative;overflow:hidden;isolation:isolate;border:1px solid rgba(255,255,255,.14);border-radius:28px;
        padding:clamp(28px,6vw,60px);min-height:clamp(340px,52vw,460px);
        background:
            radial-gradient(ellipse 60% 70% at 85% 0%,rgba(110,95,255,.55),transparent 65%),
            radial-gradient(ellipse 55% 60% at 5% 105%,rgba(30,200,190,.30),transparent 65%),
            radial-gradient(ellipse 45% 40% at 55% 55%,rgba(170,90,255,.16),transparent 70%),
            linear-gradient(165deg,#1b1d52 0%,#12133a 52%,#0a0b22 100%);
        box-shadow:0 18px 50px rgba(10,10,40,.45)}
    /* два слоя звёзд с разным мерцанием */
    .ab-hero::before,.ab-hero::after{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;background-repeat:repeat}
    .ab-hero::before{background-size:340px 260px;opacity:.9;animation:abTwinkle 4s ease-in-out infinite alternate;
        background-image:
            radial-gradient(1.6px 1.6px at 12px 30px,#fff,transparent),
            radial-gradient(1px 1px at 70px 150px,#fff,transparent),
            radial-gradient(1.4px 1.4px at 130px 60px,#cfd3ff,transparent),
            radial-gradient(1px 1px at 190px 210px,#fff,transparent),
            radial-gradient(1.6px 1.6px at 250px 110px,#fff,transparent),
            radial-gradient(1px 1px at 310px 40px,#cfd3ff,transparent),
            radial-gradient(1px 1px at 40px 230px,#fff,transparent),
            radial-gradient(1.2px 1.2px at 280px 235px,#fff,transparent)}
    .ab-hero::after{background-size:230px 190px;opacity:.6;animation:abTwinkle 6s ease-in-out -3s infinite alternate;
        background-image:
            radial-gradient(1px 1px at 20px 20px,#fff,transparent),
            radial-gradient(1.3px 1.3px at 95px 120px,#ffe9c9,transparent),
            radial-gradient(1px 1px at 160px 60px,#fff,transparent),
            radial-gradient(1px 1px at 200px 170px,#cfd3ff,transparent),
            radial-gradient(1px 1px at 60px 175px,#fff,transparent)}
    .ab-orb{position:absolute;z-index:-1;border-radius:50%;filter:blur(56px);pointer-events:none;animation:abDrift 16s ease-in-out infinite alternate}
    .ab-orb-1{width:320px;height:320px;right:-90px;top:-110px;background:#6d63ff;opacity:.45}
    .ab-orb-2{width:240px;height:240px;left:-70px;bottom:-120px;background:#22cfc4;opacity:.28;animation-delay:-8s}
    /* Земля (реальная текстура NASA Blue Marble, рисуется в canvas как настоящая сфера) */
    .ab-planet{position:absolute;z-index:-1;right:clamp(24px,8vw,110px);bottom:clamp(24px,8vw,80px);width:clamp(110px,19vw,190px);aspect-ratio:1;border-radius:50%;
        background:radial-gradient(circle at 35% 30%,#3d86d6,#14438f 60%,#071a45);
        box-shadow:0 0 0 1px rgba(140,200,255,.18),0 0 34px rgba(80,160,255,.42),0 0 90px rgba(60,120,255,.20);
        animation:abFloat 9s ease-in-out infinite alternate;pointer-events:none}
    .ab-planet canvas{display:block;width:100%;height:100%;border-radius:50%}
    /* падающая звезда */
    .ab-comet{position:absolute;z-index:-1;top:14%;left:-20%;width:140px;height:2px;border-radius:2px;pointer-events:none;opacity:0;
        background:linear-gradient(90deg,transparent,rgba(255,255,255,.95));transform:rotate(18deg);animation:abComet 9s ease-in 2s infinite}
    .ab-hero-body{max-width:640px;animation:abIn .8s cubic-bezier(.2,.7,.2,1) both}
    .ab-title{margin:20px 0 18px;font-family:'Unbounded',system-ui,sans-serif;font-weight:700;
        font-size:clamp(44px,11vw,96px);line-height:1.02;letter-spacing:-.035em;color:var(--ink)}
    .ab-lead{max-width:46ch;margin:0 0 28px;font-size:clamp(16px,2.4vw,19px);line-height:1.6;color:var(--mute)}
    .ab-actions{display:flex;flex-wrap:wrap;gap:12px}
    .ab-btn{display:inline-flex;align-items:center;justify-content:center;height:46px;padding:0 22px;border:1px solid transparent;
        border-radius:14px;font-family:inherit;font-size:15px;font-weight:600;line-height:1;text-decoration:none;cursor:pointer;transition:background .2s,border-color .2s}
    .ab-btn-primary{background:var(--btn);color:#fff}
    .ab-btn-primary:hover{background:#4c50dd}
    .ab-btn-ghost{border-color:var(--line);background:var(--surf2);color:var(--ink)}
    .ab-btn-ghost:hover{border-color:var(--acc)}
    .ab-btn:focus-visible{outline:2px solid var(--btn);outline-offset:2px}

    /* Цифры */
    .ab-stats{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--line);border-radius:22px;background:var(--surf);overflow:hidden}
    .ab-stat{padding:22px 24px;border-left:1px solid var(--line)}
    .ab-stat:first-child{border-left:0}
    .ab-stat-value{font-family:'Unbounded',system-ui,sans-serif;font-weight:700;font-size:clamp(24px,4vw,34px);letter-spacing:-.02em;line-height:1.1}
    .ab-stat-label{margin-top:8px;font-size:13px;color:var(--mute)}
    .ab-stat-live .ab-stat-label::before{content:"";display:inline-block;width:8px;height:8px;margin-right:8px;border-radius:50%;
        background:var(--cy);box-shadow:0 0 0 0 var(--cy);animation:abPulse 2s ease-out infinite}

    /* Блоки */
    .ab-block{padding:clamp(20px,3.5vw,30px);border:1px solid var(--line);border-radius:24px;background:var(--surf)}
    .ab-h2{margin:0 0 20px;font-size:20px;font-weight:700;letter-spacing:-.01em;color:var(--ink)}

    .ab-features{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}
    .ab-feature{display:flex;gap:16px;padding:18px;border-radius:18px;background:var(--surf2)}
    .ab-feature-icon{display:flex;align-items:center;justify-content:center;flex:0 0 48px;width:48px;height:48px;border-radius:14px;background:var(--acc-soft);font-size:24px}
    .ab-feature-title{margin:0 0 4px;font-size:16px;font-weight:600;color:var(--ink)}
    .ab-feature-text{margin:0;font-size:14px;line-height:1.55;color:var(--mute)}

    .ab-principles{display:grid;grid-template-columns:repeat(3,1fr)}
    .ab-principle{padding:4px 24px;border-left:1px solid var(--line)}
    .ab-principle:first-child{padding-left:0;border-left:0}
    .ab-principle-emoji{margin-bottom:12px;font-size:30px;line-height:1}
    .ab-principle-title{margin-bottom:6px;font-size:16px;font-weight:600}
    .ab-principle-text{font-size:14px;line-height:1.55;color:var(--mute)}

    .ab-info-row{display:flex;align-items:center;gap:14px;padding:14px 0;border-top:1px solid var(--line)}
    .ab-info-row:first-child{padding-top:0;border-top:0}
    .ab-info-row:last-child{padding-bottom:0}
    .ab-info-icon{display:flex;align-items:center;justify-content:center;flex:0 0 38px;width:38px;height:38px;border-radius:11px;background:var(--surf2);font-size:18px}
    .ab-info-text{display:flex;flex:1;align-items:center;justify-content:space-between;gap:12px;min-width:0}
    .ab-info-label{font-size:14px;color:var(--mute)}
    .ab-info-value{font-size:15px;font-weight:600;text-align:right;overflow-wrap:anywhere}


    @keyframes abTwinkle{from{opacity:.35}to{opacity:1}}
    @keyframes abFloat{to{transform:translateY(-14px)}}
    @keyframes abComet{0%{opacity:0;transform:translate(0,0) rotate(18deg)}6%{opacity:1}22%{opacity:0;transform:translate(120vw,40vw) rotate(18deg)}100%{opacity:0}}
    @keyframes abIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
    @keyframes abDrift{to{transform:translate(-24px,18px) scale(1.08)}}
    @keyframes abPulse{70%{box-shadow:0 0 0 8px transparent}100%{box-shadow:0 0 0 0 transparent}}

    @media (max-width:720px){
        .ab-hero{border-radius:22px}
        .ab-stats{grid-template-columns:1fr}
        .ab-stat{border-left:0;border-top:1px solid var(--line)}
        .ab-stat:first-child{border-top:0}
        .ab-features,.ab-principles{grid-template-columns:1fr}
        .ab-principle{padding:18px 0;border-left:0;border-top:1px solid var(--line)}
        .ab-principle:first-child{padding-top:4px;border-top:0}
        .ab-btn{flex:1 1 auto}
    }
    @media (prefers-reduced-motion:reduce){
        .ab-orb,.ab-planet,.ab-comet,.ab-hero::before,.ab-hero::after,.ab-hero-body,.ab-stat-live .ab-stat-label::before{animation:none}
    }
    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>

<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout">

        <!-- БОКОВАЯ ПАНЕЛЬ (СКРЫТА) -->
        <aside class="sidebar" style="display:none !important;"></aside>

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main class="about-page">
            <div class="ab">

                <section class="ab-hero">
                    <i class="ab-orb ab-orb-1"></i>
                    <i class="ab-orb ab-orb-2"></i>
                    <div class="ab-planet" aria-hidden="true"><canvas id="abEarth" width="380" height="380"></canvas></div>
                    <i class="ab-comet"></i>
                    <div class="ab-hero-body">
                        <h1 class="ab-title" style="margin-top:0">О нас</h1>
                        <p class="ab-lead">
                            Мы делаем место для общения: переписывайтесь с друзьями, делитесь фотографиями и находите новых знакомых.
                        </p>
                        <div class="ab-actions">
                            <a href="index.php" class="ab-btn ab-btn-primary">← Назад в профиль</a>
                            <a href="help.php" class="ab-btn ab-btn-ghost">Помощь</a>
                        </div>
                    </div>
                </section>

                <section class="ab-stats">
                    <div class="ab-stat">
                        <div class="ab-stat-value"><?= number_format($stats_users, 0, '', ' ') ?></div>
                        <div class="ab-stat-label">Пользователей</div>
                    </div>
                    <div class="ab-stat ab-stat-live">
                        <div class="ab-stat-value"><?= number_format($stats_online, 0, '', ' ') ?></div>
                        <div class="ab-stat-label">Сейчас онлайн</div>
                    </div>
                    <div class="ab-stat">
                        <div class="ab-stat-value">24/7</div>
                        <div class="ab-stat-label">Поддержка</div>
                    </div>
                </section>

                <section class="ab-block">
                    <h2 class="ab-h2">Возможности</h2>
                    <div class="ab-features">
                        <div class="ab-feature">
                            <div class="ab-feature-icon">👤</div>
                            <div>
                                <h3 class="ab-feature-title">Профили</h3>
                                <p class="ab-feature-text">Своя страница с аватаром, обложкой и лентой публикаций.</p>
                            </div>
                        </div>
                        <div class="ab-feature">
                            <div class="ab-feature-icon">💬</div>
                            <div>
                                <h3 class="ab-feature-title">Сообщения</h3>
                                <p class="ab-feature-text">Личные чаты с друзьями — быстро и без лишнего.</p>
                            </div>
                        </div>
                        <div class="ab-feature">
                            <div class="ab-feature-icon">🤝</div>
                            <div>
                                <h3 class="ab-feature-title">Друзья</h3>
                                <p class="ab-feature-text">Находите новых знакомых и оставайтесь на связи.</p>
                            </div>
                        </div>
                        <div class="ab-feature">
                            <div class="ab-feature-icon">🖼️</div>
                            <div>
                                <h3 class="ab-feature-title">Фотографии</h3>
                                <p class="ab-feature-text">Сохраняйте и делитесь важными моментами.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="ab-block">
                    <h2 class="ab-h2">Наши принципы</h2>
                    <div class="ab-principles">
                        <div class="ab-principle">
                            <div class="ab-principle-emoji">✨</div>
                            <div class="ab-principle-title">Простота</div>
                            <div class="ab-principle-text">Ничего лишнего — только то, что нужно для общения.</div>
                        </div>
                        <div class="ab-principle">
                            <div class="ab-principle-emoji">🧭</div>
                            <div class="ab-principle-title">Удобство</div>
                            <div class="ab-principle-text">Понятная навигация и быстрый доступ к главному.</div>
                        </div>
                        <div class="ab-principle">
                            <div class="ab-principle-emoji">🎨</div>
                            <div class="ab-principle-title">Современный вид</div>
                            <div class="ab-principle-text">Аккуратный интерфейс в стиле Discord.</div>
                        </div>
                    </div>
                </section>

                <section class="ab-block">
                    <h2 class="ab-h2">Информация</h2>
                    <div class="ab-info">
                        <div class="ab-info-row">
                            <div class="ab-info-icon">🛟</div>
                            <div class="ab-info-text">
                                <div class="ab-info-label">Поддержка</div>
                                <div class="ab-info-value">24/7</div>
                            </div>
                        </div>
                        <div class="ab-info-row">
                            <div class="ab-info-icon">👤</div>
                            <div class="ab-info-text">
                                <div class="ab-info-label">Ваш аккаунт</div>
                                <div class="ab-info-value"><?= htmlspecialchars($username) ?></div>
                            </div>
                        </div>
                    </div>
                </section>


            </div>
        </main>

        <aside class="right-sidebar">

        </aside>

        <div class="site-footer">
            &copy; <span class="year">2026</span>
        </div>

    </div>

    <script>
(function () {
    var cv = document.getElementById('abEarth');
    if (!cv || !cv.getContext) return;
    var ctx = cv.getContext('2d'), N = cv.width;
    var img = new Image();
    img.crossOrigin = 'anonymous';
    img.onerror = function () { cv.style.display = 'none'; };   // останется синий шар из CSS
    img.onload = function () {
        var TW = 1024, TH = 512, tex;
        try {
            var t = document.createElement('canvas');
            t.width = TW; t.height = TH;
            var tc = t.getContext('2d');
            tc.drawImage(img, 0, 0, TW, TH);
            tex = tc.getImageData(0, 0, TW, TH).data;
        } catch (e) { cv.style.display = 'none'; return; }

        // Предрасчёт: для каждого пикселя диска — широта, базовая долгота, свет, ореол
        var tilt = 0.41, ct = Math.cos(tilt), st = Math.sin(tilt);
        var L = [-0.55, 0.42, 0.72], ll = Math.hypot(L[0], L[1], L[2]);
        L = [L[0] / ll, L[1] / ll, L[2] / ll];
        var P = N * N;
        var row = new Int16Array(P), lon0 = new Float32Array(P), shade = new Float32Array(P),
            rim = new Float32Array(P), alpha = new Uint8ClampedArray(P);
        for (var py = 0; py < N; py++) {
            for (var px = 0; px < N; px++) {
                var k = py * N + px;
                var x = (px + 0.5) / N * 2 - 1, y = 1 - (py + 0.5) / N * 2;
                var r2 = x * x + y * y;
                if (r2 >= 1) { row[k] = -1; continue; }
                var z = Math.sqrt(1 - r2), r = Math.sqrt(r2);
                var ym = y * ct - z * st, zm = y * st + z * ct;
                row[k] = Math.min(TH - 1, Math.max(0, Math.floor((0.5 - Math.asin(ym) / Math.PI) * TH)));
                lon0[k] = Math.atan2(x, zm);
                var d = Math.max(0, x * L[0] + y * L[1] + z * L[2]);
                shade[k] = 0.10 + 1.0 * Math.pow(d, 0.85);
                rim[k] = Math.pow(1 - z, 3);
                alpha[k] = Math.max(0, Math.min(1, (1 - r) / 0.012)) * 255;
            }
        }

        var frame = ctx.createImageData(N, N), out = frame.data;
        var rot = 0.6, last = 0;
        var still = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

        function draw() {
            var inv = 1 / (2 * Math.PI);
            for (var k = 0; k < P; k++) {
                var o = k * 4, rw = row[k];
                if (rw < 0) { out[o + 3] = 0; continue; }
                var u = ((lon0[k] + rot) * inv + 0.5) % 1;
                if (u < 0) u += 1;
                var ti = (rw * TW + ((u * TW) | 0)) * 4;
                var s = shade[k], g = rim[k];
                var rr = tex[ti] * s + 70 * g * (0.35 + s), gg = tex[ti + 1] * s + 140 * g * (0.35 + s), bb = tex[ti + 2] * s + 255 * g * (0.35 + s);
                out[o] = rr > 255 ? 255 : rr; out[o + 1] = gg > 255 ? 255 : gg; out[o + 2] = bb > 255 ? 255 : bb;
                out[o + 3] = alpha[k];
            }
            ctx.putImageData(frame, 0, 0);
        }

        function tick(ts) {
            if (ts - last > 33) { last = ts; rot += 0.0045; draw(); }
            requestAnimationFrame(tick);
        }
        draw();
        if (!still) requestAnimationFrame(tick);
    };
    img.src = 'https://cdn.jsdelivr.net/npm/three-globe/example/img/earth-blue-marble.jpg';
})();
</script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/about.js"></script>

    <script src="assets/js/error-reporter.js"></script>
</body>
</html>

<?php

$conn->close();

?>

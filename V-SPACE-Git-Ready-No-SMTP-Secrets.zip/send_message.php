<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
header('Content-Type: application/json; charset=utf-8');

$conn = db_connect();

if ($conn->connect_error) {
    error_log("Ошибка подключения к БД: " . $conn->connect_error);
    echo json_encode(['success' => false, 'error' => 'Ошибка подключения к БД'], JSON_UNESCAPED_UNICODE);
    exit;
}

$conn->set_charset("utf8mb4");
$conn->query("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");

if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => false, 'error' => 'Сессия истекла'], JSON_UNESCAPED_UNICODE);
    exit;
}

$user_id = (int)$_SESSION["user_id"];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Неверный метод запроса'], JSON_UNESCAPED_UNICODE);
    exit;
}

$receiver_id  = isset($_POST['receiver_id']) ? (int)$_POST['receiver_id'] : 0;
$message_text = isset($_POST['message']) ? trim($_POST['message']) : '';

if ($receiver_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Не выбран получатель'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($receiver_id === $user_id) {
    echo json_encode(['success' => false, 'error' => 'Нельзя отправить сообщение самому себе'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($message_text === '') {
    echo json_encode(['success' => false, 'error' => 'Введите сообщение'], JSON_UNESCAPED_UNICODE);
    exit;
}

$max_length = 5000;
if (mb_strlen($message_text, "UTF-8") > $max_length) {
    $message_text = mb_substr($message_text, 0, $max_length, "UTF-8");
}

// Получатель + имя отправителя одним махом
$stmt_users = $conn->prepare("
    SELECT 
        (SELECT username FROM users WHERE id = ?) AS sender_username,
        (SELECT username FROM users WHERE id = ?) AS receiver_username,
        (SELECT avatar   FROM users WHERE id = ?) AS sender_avatar
");
$stmt_users->bind_param("iii", $user_id, $receiver_id, $user_id);
$stmt_users->execute();
$users_data = $stmt_users->get_result()->fetch_assoc();
$stmt_users->close();

if (empty($users_data['receiver_username'])) {
    echo json_encode(['success' => false, 'error' => 'Получатель не найден'], JSON_UNESCAPED_UNICODE);
    exit;
}

$sender_username = $users_data['sender_username'] ?: 'Пользователь';
$sender_avatar   = $users_data['sender_avatar'] ?? null;

// Сохранение сообщения
$stmt = $conn->prepare("
    INSERT INTO messages (sender_id, receiver_id, message, created_at, is_read)
    VALUES (?, ?, ?, NOW(), 0)
");
if (!$stmt) {
    error_log("Ошибка подготовки запроса: " . $conn->error);
    echo json_encode(['success' => false, 'error' => 'Ошибка системы'], JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

$stmt->bind_param("iis", $user_id, $receiver_id, $message_text);

if (!$stmt->execute()) {
    error_log("Ошибка выполнения запроса: " . $stmt->error);
    echo json_encode(['success' => false, 'error' => 'Ошибка сохранения сообщения'], JSON_UNESCAPED_UNICODE);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// Не создаём уведомление для сообщений самому себе («Избранное»).
if ($receiver_id !== $user_id) {
    $notif_message = $sender_username . ' отправил(а) вам сообщение';
    $notif_link    = 'messages.php?dialog=' . $user_id;

    $notif_stmt = $conn->prepare("
        INSERT INTO notifications (user_id, sender_id, sender_avatar, type, message, link, created_at)
        VALUES (?, ?, ?, 'message', ?, ?, NOW())
    ");
    if ($notif_stmt) {
        $notif_stmt->bind_param("iisss", $receiver_id, $user_id, $sender_avatar, $notif_message, $notif_link);
        $notif_stmt->execute();
        $notif_stmt->close();
    } else {
        error_log("Ошибка подготовки уведомления: " . $conn->error);
    }
}

echo json_encode(['success' => true, 'message' => 'Сообщение отправлено'], JSON_UNESCAPED_UNICODE);

$conn->close();
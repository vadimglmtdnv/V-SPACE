<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/seasons.php';

if (!function_exists('db_connect')) {
    function db_connect() {
        $host = getenv('DB_HOST') ?: '127.0.0.1';
        $user = getenv('DB_USER') ?: 'root';
        $pass = getenv('DB_PASS') ?: '';
        $db   = getenv('DB_NAME') ?: 'playerchat';
        $port = (int)(getenv('DB_PORT') ?: 3306);

        $conn = new mysqli($host, $user, $pass, $db, $port);
        if ($conn->connect_error) {
            throw new RuntimeException('Ошибка подключения: ' . $conn->connect_error);
        }

        return $conn;
    }
}

// Токен бота: заголовок "Authorization: Bearer <токен>" (или X-Bot-Token). Для таких запросов сессия не нужна.
function spBearerToken(): string {
    $h = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if ($h === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) {
            if (strcasecmp((string)$k, 'Authorization') === 0) { $h = (string)$v; break; }
        }
    }
    if (preg_match('/^Bearer\s+(\S+)$/i', trim($h), $m)) return $m[1];
    return trim((string)($_SERVER['HTTP_X_BOT_TOKEN'] ?? ''));
}

function spEnsureTokenTable(mysqli $conn): void {
    $conn->query("
        CREATE TABLE IF NOT EXISTS space_api_tokens (
            id INT NOT NULL AUTO_INCREMENT,
            user_id INT NOT NULL,
            space_id INT NOT NULL,
            name VARCHAR(80) NOT NULL,
            scope VARCHAR(5) NOT NULL DEFAULT 'read',
            token_hash CHAR(64) NOT NULL,
            token_hint VARCHAR(12) NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_used DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY token_hash (token_hash),
            KEY user_space (user_id, space_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

$bot_token = isset($_GET['api']) ? spBearerToken() : '';
if ($bot_token === '') {
    require_once __DIR__ . '/includes/helpers.php';
    start_secure_session();
}
// Если в настройках выбран English — содержимое страницы переводится «на лету» (includes/lang.php)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();

/*
|--------------------------------------------------------------------------
| PLAYERCHAT — Пространства
|--------------------------------------------------------------------------
| Текстовые сообщения, названия и сигналы звонков автоматически шифруются
| на сервере при хранении. Передача должна идти по HTTPS; медиа WebRTC защищены
| DTLS-SRTP. Содержимое не является сквозным E2EE.
|--------------------------------------------------------------------------
*/

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// ---------- Аутентификация бота по API-токену ----------
$bot_auth = null;
if ($bot_token !== '') {
    spEnsureTokenTable($conn);
    $bot_hash = hash('sha256', $bot_token);
    $bot_row = spOne($conn, "SELECT id, user_id, space_id, scope FROM space_api_tokens WHERE token_hash = ?", "s", $bot_hash);
    if (!$bot_row) {
        spJson(['ok' => false, 'error' => 'bad_token', 'message' => 'Неверный или отозванный токен.'], 401);
    }
    // токен работает, только пока владелец остаётся участником пространства
    if (spRole($conn, (int)$bot_row['space_id'], (int)$bot_row['user_id']) === null) {
        spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Владелец токена больше не участник пространства.'], 403);
    }
    spExec($conn, "UPDATE space_api_tokens SET last_used = NOW() WHERE id = ? AND (last_used IS NULL OR last_used < (NOW() - INTERVAL 60 SECOND))", "i", (int)$bot_row['id']);
    $bot_auth = [
        'id' => (int)$bot_row['id'], 'user_id' => (int)$bot_row['user_id'],
        'space_id' => (int)$bot_row['space_id'], 'scope' => (string)$bot_row['scope'],
    ];
}

if (!$bot_auth && !isset($_SESSION["user_id"])) {
    if (isset($_GET['api'])) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'auth']);
        exit;
    }
    header("Location: login.php");
    exit;
}

$user_id = $bot_auth ? $bot_auth['user_id'] : (int)$_SESSION["user_id"];

$stmt = $conn->prepare("SELECT id, username, email, avatar, status, last_seen, is_admin FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    if ($bot_auth) spJson(['ok' => false, 'error' => 'bad_token'], 401);
    $_SESSION = [];
    session_destroy();
    header("Location: login.php?account_missing=1");
    exit;
}

$username = $user["username"];
$is_admin = isset($user["is_admin"]) && $user["is_admin"] == 1;

if ($bot_auth) {
    $spaces_csrf = '';
} else {
    if (empty($_SESSION['spaces_csrf'])) {
        $_SESSION['spaces_csrf'] = bin2hex(random_bytes(32));
    }
    $spaces_csrf = $_SESSION['spaces_csrf'];
}

// Лёгкий «пинг» для индикатора связи: отвечает сразу, без обращения к таблицам пространств.
if (isset($_GET['api']) && $_GET['api'] === 'ping') {
    if ($bot_auth) spJson(['ok' => false, 'error' => 'bot_forbidden'], 403);
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') spJson(['ok' => false, 'error' => 'method'], 405);
    if (!hash_equals($spaces_csrf, (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) spJson(['ok' => false, 'error' => 'csrf'], 403);
    session_write_close();
    spJson(['ok' => true]);
}

// ---------- Таблицы ----------
$conn->query("
    CREATE TABLE IF NOT EXISTS spaces (
        id INT NOT NULL AUTO_INCREMENT,
        owner_id INT NOT NULL,
        name_enc TEXT NOT NULL,
        avatar_path VARCHAR(255) NULL,
        invite_code VARCHAR(32) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY invite_code (invite_code),
        KEY owner_id (owner_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    CREATE TABLE IF NOT EXISTS space_members (
        space_id INT NOT NULL,
        user_id INT NOT NULL,
        role VARCHAR(10) NOT NULL DEFAULT 'member',
        joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (space_id, user_id),
        KEY user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    CREATE TABLE IF NOT EXISTS space_messages (
        id BIGINT NOT NULL AUTO_INCREMENT,
        space_id INT NOT NULL,
        user_id INT NOT NULL,
        body_enc MEDIUMTEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY space_id_id (space_id, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    CREATE TABLE IF NOT EXISTS space_call_presence (
        space_id INT NOT NULL,
        user_id INT NOT NULL,
        last_seen DATETIME NOT NULL,
        PRIMARY KEY (space_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    CREATE TABLE IF NOT EXISTS space_bans (
        space_id INT NOT NULL,
        user_id INT NOT NULL,
        banned_until DATETIME NOT NULL,
        created_by INT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (space_id, user_id),
        KEY banned_until (banned_until)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    CREATE TABLE IF NOT EXISTS space_signals (
        id BIGINT NOT NULL AUTO_INCREMENT,
        space_id INT NOT NULL,
        from_user INT NOT NULL,
        to_user INT NOT NULL,
        payload_enc MEDIUMTEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY inbox (space_id, to_user, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$conn->query("
    CREATE TABLE IF NOT EXISTS space_presence (
        user_id INT NOT NULL,
        status VARCHAR(10) NOT NULL DEFAULT 'online',
        seen DATETIME NULL DEFAULT NULL,
        PRIMARY KEY (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// ---------- Каналы, категории, роли (v2) ----------
function spColumnExists(mysqli $conn, string $table, string $col): bool {
    $stmt = $conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
    $stmt->bind_param("ss", $table, $col);
    $stmt->execute();
    $has = (bool)$stmt->get_result()->fetch_row();
    $stmt->close();
    return $has;
}

if (!$bot_auth && (int)($_SESSION['spaces_schema'] ?? 0) < 6) {
    $schema_ok = true;
    try {
        $conn->query("
            CREATE TABLE IF NOT EXISTS space_categories (
                id INT NOT NULL AUTO_INCREMENT,
                space_id INT NOT NULL,
                name_enc TEXT NOT NULL,
                position INT NOT NULL DEFAULT 0,
                PRIMARY KEY (id),
                KEY space_id (space_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $conn->query("
            CREATE TABLE IF NOT EXISTS space_channels (
                id INT NOT NULL AUTO_INCREMENT,
                space_id INT NOT NULL,
                category_id INT NOT NULL DEFAULT 0,
                type VARCHAR(5) NOT NULL DEFAULT 'text',
                name_enc TEXT NOT NULL,
                topic_enc TEXT NULL,
                position INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY space_id (space_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $conn->query("
            CREATE TABLE IF NOT EXISTS space_roles (
                id INT NOT NULL AUTO_INCREMENT,
                space_id INT NOT NULL,
                name_enc TEXT NOT NULL,
                color VARCHAR(7) NOT NULL DEFAULT '#99aab5',
                perms INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY space_id (space_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $alters = [
            ['space_members',       'role_id',       "ALTER TABLE space_members ADD COLUMN role_id INT NOT NULL DEFAULT 0"],
            ['space_messages',      'channel_id',    "ALTER TABLE space_messages ADD COLUMN channel_id INT NOT NULL DEFAULT 0, ADD KEY space_channel_id (space_id, channel_id, id)"],
            ['space_call_presence', 'channel_id',    "ALTER TABLE space_call_presence ADD COLUMN channel_id INT NOT NULL DEFAULT 0"],
            ['spaces',              'default_perms', "ALTER TABLE spaces ADD COLUMN default_perms INT NOT NULL DEFAULT 11"],
            ['space_channels',      'topic_enc',     "ALTER TABLE space_channels ADD COLUMN topic_enc TEXT NULL"],
            ['space_members',       'server_nick_enc', "ALTER TABLE space_members ADD COLUMN server_nick_enc TEXT NULL"],
            ['space_members',       'voice_muted',   "ALTER TABLE space_members ADD COLUMN voice_muted TINYINT(1) NOT NULL DEFAULT 0"],
            ['spaces',              'avatar_path',   "ALTER TABLE spaces ADD COLUMN avatar_path VARCHAR(255) NULL"],
            ['space_messages',      'edited_at',     "ALTER TABLE space_messages ADD COLUMN edited_at DATETIME NULL DEFAULT NULL"],
            ['space_messages',      'reply_to',      "ALTER TABLE space_messages ADD COLUMN reply_to BIGINT NULL DEFAULT NULL"],
        ];
        foreach ($alters as $a) {
            if (!spColumnExists($conn, $a[0], $a[1])) {
                $conn->query($a[2]);
            }
        }
    } catch (Throwable $e) {
        $schema_ok = false;
        error_log('spaces.php schema v2: ' . $e->getMessage());
    }
    if ($schema_ok) {
        $_SESSION['spaces_schema'] = 6;
    }
}

$conn->query("
    CREATE TABLE IF NOT EXISTS space_channel_permissions (
        channel_id INT NOT NULL,
        subject_type VARCHAR(6) NOT NULL,
        subject_id INT NOT NULL,
        allow_mask INT NOT NULL DEFAULT 0,
        deny_mask INT NOT NULL DEFAULT 0,
        PRIMARY KEY (channel_id, subject_type, subject_id),
        KEY subject_lookup (subject_type, subject_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// ============================================================
// API (JSON). Открытый текст автоматически шифруется перед сохранением в БД.
// ============================================================
const SPACE_MAX_OWNED   = 20;
const SPACE_MAX_MEMBERS = 50;
const SPACE_MAX_CALL    = 6;      // «каждый с каждым» — больше 6 участников нагружает каналы
const SPACE_CALL_TTL    = 12;     // секунд без опроса — считаем, что участник вышел
const SPACE_MAX_CHANNELS   = 50;
const SPACE_MAX_CATEGORIES = 20;
const SPACE_MAX_ROLES      = 15;
const SPACE_MAX_TOKENS     = 10;     // API-токенов на пользователя в одном пространстве

// Права (битовая маска). Владелец всегда имеет все права.
const SP_P_SEND     = 1;    // писать сообщения
const SP_P_VOICE    = 2;    // заходить в голосовые каналы
const SP_P_CHANNELS = 4;    // создавать, переименовывать и удалять каналы и категории
const SP_P_INVITE   = 8;    // приглашать (видеть код-приглашение)
const SP_P_ROLES    = 16;   // управлять ролями и назначать их
const SP_P_KICK     = 32;   // удалять участников
const SP_P_ALL      = 63;
const SP_P_DEFAULT  = 11;   // роль «Участник» по умолчанию: писать + голос + приглашать
const SP_C_VIEW     = 1;
const SP_C_SEND     = 2;
const SP_C_CONNECT  = 4;
const SP_C_SPEAK    = 8;
const SP_C_ALL      = 15;

function spJson(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function spCipherOk(string $s, int $max): bool {
    return strlen($s) <= $max && preg_match('/^v1\.[A-Za-z0-9_\-]{16}\.[A-Za-z0-9_\-]{8,}$/', $s) === 1;
}

function spAtRestKey(): string {
    if (!defined('ENCRYPTION_SALT') || ENCRYPTION_SALT === '') {
        throw new RuntimeException('Не настроен ключ серверного шифрования.');
    }
    return hash('sha256', 'playerchat-spaces-at-rest:' . ENCRYPTION_SALT, true);
}

function spSeal(string $plain): string {
    $iv = random_bytes(12);
    $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', spAtRestKey(), OPENSSL_RAW_DATA, $iv, $tag, 'playerchat-spaces-v1', 16);
    if ($cipher === false || strlen($tag) !== 16) {
        throw new RuntimeException('Не удалось зашифровать данные пространства.');
    }
    return 'srv1.' . rtrim(strtr(base64_encode($iv . $tag . $cipher), '+/', '-_'), '=');
}

function spOpen(string $stored): string {
    if (strpos($stored, 'srv1.') !== 0) return $stored;
    $encoded = strtr(substr($stored, 5), '-_', '+/');
    $encoded .= str_repeat('=', (4 - strlen($encoded) % 4) % 4);
    $blob = base64_decode($encoded, true);
    if ($blob === false || strlen($blob) < 29) {
        throw new RuntimeException('Зашифрованные данные пространства повреждены.');
    }
    $plain = openssl_decrypt(substr($blob, 28), 'aes-256-gcm', spAtRestKey(), OPENSSL_RAW_DATA, substr($blob, 0, 12), substr($blob, 12, 16), 'playerchat-spaces-v1');
    if ($plain === false) {
        throw new RuntimeException('Не удалось расшифровать данные пространства.');
    }
    return $plain;
}

function spTextOk(string $s, int $max): bool {
    return $s !== '' && strlen($s) <= $max && strpos($s, "\0") === false
        && preg_match('//u', $s) === 1;
}

function spStoredTextOk(string $s, int $max): bool {
    return spTextOk($s, $max) || spCipherOk($s, $max);
}

function spRole(mysqli $conn, int $space_id, int $uid): ?string {
    $stmt = $conn->prepare("SELECT role FROM space_members WHERE space_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $space_id, $uid);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ? (string)$row['role'] : null;
}

function spCallParticipants(mysqli $conn, int $space_id, ?int $channel_id = null): array {
    $ttl = SPACE_CALL_TTL;
    $sql = "
        SELECT p.user_id, u.username, u.avatar, m.server_nick_enc, m.voice_muted
        FROM space_call_presence p
        INNER JOIN users u ON u.id = p.user_id
        INNER JOIN space_members m ON m.space_id = p.space_id AND m.user_id = p.user_id
        WHERE p.space_id = ? AND p.last_seen >= (NOW() - INTERVAL $ttl SECOND)";
    if ($channel_id !== null) $sql .= " AND p.channel_id = ?";
    $sql .= " ORDER BY p.user_id";
    $stmt = $conn->prepare($sql);
    if ($channel_id !== null) $stmt->bind_param("ii", $space_id, $channel_id);
    else $stmt->bind_param("i", $space_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $out = [];
    while ($r = $res->fetch_assoc()) {
        $nick = spOpen((string)($r['server_nick_enc'] ?? ''));
        $out[] = [
            'user_id' => (int)$r['user_id'], 'username' => (string)$r['username'],
            'display_name' => $nick !== '' ? $nick : (string)$r['username'],
            'avatar' => (string)($r['avatar'] ?? ''), 'muted' => (bool)$r['voice_muted'],
        ];
    }
    $stmt->close();
    return $out;
}

// Кто сейчас в каких голосовых каналах: { "channel_id": [ {user_id, username, avatar} ] }
function spVoiceMap(mysqli $conn, int $space_id): array {
    $ttl = SPACE_CALL_TTL;
    $stmt = $conn->prepare("
        SELECT p.channel_id, p.user_id, u.username, u.avatar, m.server_nick_enc, m.voice_muted
        FROM space_call_presence p
        INNER JOIN users u ON u.id = p.user_id
        INNER JOIN space_members m ON m.space_id = p.space_id AND m.user_id = p.user_id
        WHERE p.space_id = ? AND p.last_seen >= (NOW() - INTERVAL $ttl SECOND)
        ORDER BY p.channel_id, p.user_id
    ");
    $stmt->bind_param("i", $space_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $out = [];
    while ($r = $res->fetch_assoc()) {
        $nick = spOpen((string)($r['server_nick_enc'] ?? ''));
        $out[(string)(int)$r['channel_id']][] = [
            'user_id' => (int)$r['user_id'], 'username' => (string)$r['username'],
            'display_name' => $nick !== '' ? $nick : (string)$r['username'],
            'avatar' => (string)($r['avatar'] ?? ''), 'muted' => (bool)$r['voice_muted'],
        ];
    }
    $stmt->close();
    return $out;
}

// Права участника: владелец — все; иначе права его роли; без роли — права роли «Участник».
function spMemberPerms(mysqli $conn, int $space_id, int $uid): int {
    $stmt = $conn->prepare("
        SELECT m.role, m.role_id, s.default_perms
        FROM space_members m INNER JOIN spaces s ON s.id = m.space_id
        WHERE m.space_id = ? AND m.user_id = ?
    ");
    $stmt->bind_param("ii", $space_id, $uid);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) return 0;
    if ($row['role'] === 'owner') return SP_P_ALL;
    $rid = (int)$row['role_id'];
    if ($rid > 0) {
        $stmt = $conn->prepare("SELECT perms FROM space_roles WHERE id = ? AND space_id = ?");
        $stmt->bind_param("ii", $rid, $space_id);
        $stmt->execute();
        $r = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($r) return ((int)$r['perms']) & SP_P_ALL;
    }
    return ((int)$row['default_perms']) & SP_P_ALL;
}

function spChannelAccess(mysqli $conn, int $space_id, int $channel_id, int $uid, string $type, int $space_perms, string $space_role): int {
    if ($space_role === 'owner') return SP_C_ALL;
    $access = SP_C_VIEW;
    if ($type === 'text' && ($space_perms & SP_P_SEND)) $access |= SP_C_SEND;
    if ($type === 'voice' && ($space_perms & SP_P_VOICE)) $access |= SP_C_CONNECT | SP_C_SPEAK;

    $member = spOne($conn, "SELECT role_id FROM space_members WHERE space_id = ? AND user_id = ?", "ii", $space_id, $uid);
    if (!$member) return 0;
    $role_id = (int)$member['role_id'];
    $overrides = [];
    $stmt = $conn->prepare("SELECT subject_type, subject_id, allow_mask, deny_mask FROM space_channel_permissions WHERE channel_id = ?");
    $stmt->bind_param("i", $channel_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $overrides[$row['subject_type'] . ':' . (int)$row['subject_id']] = [
            'allow' => (int)$row['allow_mask'] & SP_C_ALL,
            'deny' => (int)$row['deny_mask'] & SP_C_ALL,
        ];
    }
    $stmt->close();

    foreach (['role:0', 'role:' . $role_id, 'member:' . $uid] as $key) {
        if (!isset($overrides[$key])) continue;
        $access = ($access & ~$overrides[$key]['deny']) | $overrides[$key]['allow'];
    }
    $access &= SP_C_ALL;
    return ($access & SP_C_VIEW) ? $access : 0;
}

function spNeed(int $perms, int $bit): void {
    if (!($perms & $bit)) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Недостаточно прав для этого действия.'], 403);
}

function spOne(mysqli $conn, string $sql, string $types, ...$params): ?array {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function spExec(mysqli $conn, string $sql, string $types, ...$params): int {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $n = (int)$stmt->affected_rows;
    $stmt->close();
    return $n;
}

function spMigrateStorage(mysqli $conn): void {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    $conn->query("
        CREATE TABLE IF NOT EXISTS space_storage_migrations (
            migration_id VARCHAR(64) NOT NULL PRIMARY KEY,
            completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    if (spOne($conn, "SELECT migration_id FROM space_storage_migrations WHERE migration_id = ?", "s", "server-encryption-v1")) return;
    $lockResult = $conn->query("SELECT GET_LOCK('playerchat_spaces_storage_v1', 0) AS acquired");
    $lock = $lockResult ? $lockResult->fetch_assoc() : null;
    if (!$lock || (int)$lock['acquired'] !== 1) return;

    try {
        if (spOne($conn, "SELECT migration_id FROM space_storage_migrations WHERE migration_id = ?", "s", "server-encryption-v1")) return;
        $columns = [
            ['spaces', 'name_enc'],
            ['space_messages', 'body_enc'],
            ['space_categories', 'name_enc'],
            ['space_channels', 'name_enc'],
            ['space_roles', 'name_enc'],
            ['space_signals', 'payload_enc'],
        ];
        foreach ($columns as [$table, $column]) {
            $lastId = 0;
            do {
                $rows = $conn->query("SELECT id, $column AS value FROM $table WHERE id > $lastId AND $column NOT LIKE 'srv1.%' ORDER BY id LIMIT 250");
                if (!$rows) throw new RuntimeException('Не удалось прочитать данные для шифрования.');
                $batch = [];
                while ($row = $rows->fetch_assoc()) $batch[] = $row;
                $rows->free();
                foreach ($batch as $row) {
                    $id = (int)$row['id'];
                    $sealed = spSeal((string)$row['value']);
                    spExec($conn, "UPDATE $table SET $column = ? WHERE id = ? AND $column NOT LIKE 'srv1.%'", "si", $sealed, $id);
                    $lastId = max($lastId, $id);
                }
            } while (count($batch) === 250);
        }
        spExec($conn, "INSERT IGNORE INTO space_storage_migrations (migration_id) VALUES (?)", "s", "server-encryption-v1");
    } finally {
        $conn->query("SELECT RELEASE_LOCK('playerchat_spaces_storage_v1')");
    }
}

function spCount(mysqli $conn, string $table, int $space_id, string $extra = ''): int {
    $row = spOne($conn, "SELECT COUNT(*) AS c FROM $table WHERE space_id = ? $extra", "i", $space_id);
    return (int)($row['c'] ?? 0);
}

// Присутствие в «Пространствах»: статус (online / away / dnd / invisible) и время последней активности.
// Это отдельная от users.status настройка — она влияет только на то, что видят в «Пространствах».
function spTouchPresence(mysqli $conn, int $uid): void {
    spExec($conn, "INSERT INTO space_presence (user_id, status, seen) VALUES (?, 'online', NOW()) ON DUPLICATE KEY UPDATE seen = IF(seen IS NULL OR seen < (NOW() - INTERVAL 20 SECOND), NOW(), seen)", "i", $uid);
}

function spMyStatus(mysqli $conn, int $uid): string {
    $row = spOne($conn, "SELECT status FROM space_presence WHERE user_id = ?", "i", $uid);
    $s = (string)($row['status'] ?? 'online');
    return in_array($s, ['online', 'away', 'dnd', 'invisible'], true) ? $s : 'online';
}

// Канал существует в этом пространстве и нужного типа. id = 0 — «старый» общий чат/созвон,
// допустим только пока в пространстве нет ни одного канала этого типа.
function spResolveChannel(mysqli $conn, int $space_id, int $cid, string $type): bool {
    if ($cid > 0) {
        return spOne($conn, "SELECT id FROM space_channels WHERE id = ? AND space_id = ? AND type = ?", "iis", $cid, $space_id, $type) !== null;
    }
    return spCount($conn, 'space_channels', $space_id, "AND type = '" . ($type === 'voice' ? 'voice' : 'text') . "'") === 0;
}

// Нельзя трогать роли/участников с правами выше собственных (кроме владельца).
function spOutranks(int $actor_perms, string $actor_role, int $target_perms): bool {
    return $actor_role !== 'owner' && ($target_perms & ~$actor_perms) !== 0;
}

function spCallCanConnect(mysqli $conn, int $space_id, int $channel_id, int $uid): bool {
    $role = spRole($conn, $space_id, $uid);
    if ($role === null) return false;
    $perms = spMemberPerms($conn, $space_id, $uid);
    return (spChannelAccess($conn, $space_id, $channel_id, $uid, 'voice', $perms, $role) & SP_C_CONNECT) !== 0;
}

if (isset($_GET['api'])) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        spJson(['ok' => false, 'error' => 'method'], 405);
    }
    if (!$bot_auth) {
        $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if (!hash_equals($spaces_csrf, $token)) {
            spJson(['ok' => false, 'error' => 'csrf'], 403);
        }
        session_write_close(); // опросы не должны блокировать остальные вкладки
    }

    spMigrateStorage($conn);

    $content_type = (string)($_SERVER['CONTENT_TYPE'] ?? '');
    $in = stripos($content_type, 'multipart/form-data') === 0
        ? $_POST
        : json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($in)) $in = [];
    $action = (string)$_GET['api'];
    $space_id = (int)($in['space_id'] ?? 0);

    // --- API-токен бота: только info / messages / send и только в своём пространстве ---
    if ($bot_auth) {
        $bot_actions = ['info' => 'read', 'messages' => 'read', 'send' => 'write'];
        if (!isset($bot_actions[$action])) {
            spJson(['ok' => false, 'error' => 'bot_forbidden', 'message' => 'Это действие недоступно для API-токена.'], 403);
        }
        if ($bot_actions[$action] === 'write' && $bot_auth['scope'] !== 'write') {
            spJson(['ok' => false, 'error' => 'bot_forbidden', 'message' => 'Токен выдан только для чтения.'], 403);
        }
        if ($space_id !== 0 && $space_id !== $bot_auth['space_id']) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Токен выдан для другого пространства.'], 403);
        }
        $space_id = $bot_auth['space_id'];
    }

    // --- состояние оболочки: счётчики шапки и текущий сезон (опрос раз в ~30 с) ---
    if ($action === 'shell') {
        $notif = 0;
        $pending = 0;
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $notif = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
            $stmt->close();
            if ($is_admin) {
                $res = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
                if ($res) $pending = (int)($res->fetch_assoc()['c'] ?? 0);
            }
        } catch (Throwable $e) {
            error_log('spaces.php api=shell: ' . $e->getMessage());
        }
        $si = seasonInfo();
        spJson([
            'ok'               => true,
            'unread_messages'  => shell_unread_messages($conn, $user_id),
            'notifications'    => $notif,
            'pending_reports'  => $pending,
            'season'           => $si['season'],
            'theme'            => $si['theme'],
            'holiday'          => $si['holiday'],
        ]);
    }

    // --- действия без привязки к конкретному пространству ---
    if ($action === 'presence_set') {
        $st = (string)($in['status'] ?? '');
        if (!in_array($st, ['online', 'away', 'dnd', 'invisible'], true)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        spExec($conn, "INSERT INTO space_presence (user_id, status, seen) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE status = VALUES(status), seen = NOW()", "is", $user_id, $st);
        spJson(['ok' => true, 'status' => $st]);
    }

    // --- уведомления: новые сообщения во всех моих пространствах (опрос раз в несколько секунд) ---
    if ($action === 'notify_poll') {
        $after = max(0, (int)($in['after'] ?? 0));
        $mine = [];   // space_id => [role, perms]
        $stmt = $conn->prepare("SELECT space_id FROM space_members WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $mres = $stmt->get_result();
        while ($r = $mres->fetch_assoc()) {
            $sid = (int)$r['space_id'];
            $mine[$sid] = [spRole($conn, $sid, $user_id), spMemberPerms($conn, $sid, $user_id)];
        }
        $stmt->close();
        $access = [];
        $canView = static function (int $sid, int $cid) use (&$access, $mine, $conn, $user_id): bool {
            $k = $sid . ':' . $cid;
            if (!isset($access[$k])) {
                $access[$k] = isset($mine[$sid]) && (spChannelAccess($conn, $sid, $cid, $user_id, 'text', $mine[$sid][1], (string)$mine[$sid][0]) & SP_C_VIEW) !== 0;
            }
            return $access[$k];
        };
        if (!$mine) spJson(['ok' => true, 'cursor' => $after, 'items' => [], 'last' => new stdClass()]);
        $ids = implode(',', array_map('intval', array_keys($mine)));

        if ($after === 0) {
            // первый запуск: курсор и последнее сообщение каждого канала (для точек «непрочитано»)
            $cursor = 0;
            $last = [];
            $res = $conn->query("SELECT space_id, channel_id, MAX(id) AS last_id FROM space_messages WHERE space_id IN ($ids) GROUP BY space_id, channel_id");
            while ($res && ($r = $res->fetch_assoc())) {
                $sid = (int)$r['space_id']; $cid = (int)$r['channel_id'];
                $cursor = max($cursor, (int)$r['last_id']);
                if ($canView($sid, $cid)) $last[$sid . ':' . $cid] = (int)$r['last_id'];
            }
            spJson(['ok' => true, 'cursor' => $cursor, 'items' => [], 'last' => (object)$last]);
        }

        $stmt = $conn->prepare("
            SELECT m.id, m.space_id, m.channel_id, m.user_id, m.body_enc, UNIX_TIMESTAMP(m.created_at) AS ts, m.reply_to,
                   u.username, u.avatar, sm.server_nick_enc, r.user_id AS reply_uid
            FROM space_messages m
            INNER JOIN users u ON u.id = m.user_id
            LEFT JOIN space_members sm ON sm.space_id = m.space_id AND sm.user_id = m.user_id
            LEFT JOIN space_messages r ON r.id = m.reply_to
            WHERE m.space_id IN ($ids) AND m.id > ? ORDER BY m.id ASC LIMIT 100
        ");
        $stmt->bind_param("i", $after);
        $stmt->execute();
        $res = $stmt->get_result();
        $items = [];
        $cursor = $after;
        while ($r = $res->fetch_assoc()) {
            $cursor = max($cursor, (int)$r['id']);
            if ((int)$r['user_id'] === $user_id) continue;
            if (!$canView((int)$r['space_id'], (int)$r['channel_id'])) continue;
            $nick = spOpen((string)($r['server_nick_enc'] ?? ''));
            $items[] = [
                'id' => (int)$r['id'], 'space_id' => (int)$r['space_id'], 'channel_id' => (int)$r['channel_id'],
                'user_id' => (int)$r['user_id'], 'username' => (string)$r['username'], 'avatar' => (string)($r['avatar'] ?? ''),
                'display_name' => $nick !== '' ? $nick : (string)$r['username'],
                'body_enc' => mb_substr(spOpen((string)$r['body_enc']), 0, 600, 'UTF-8'), 'ts' => (int)$r['ts'],
                'reply_to_me' => $r['reply_uid'] !== null && (int)$r['reply_uid'] === $user_id,
            ];
        }
        $stmt->close();
        spJson(['ok' => true, 'cursor' => $cursor, 'items' => $items]);
    }

    if ($action === 'list') {
        spTouchPresence($conn, $user_id);
        $ttl = SPACE_CALL_TTL;
        $stmt = $conn->prepare("
            SELECT s.id, s.name_enc, s.avatar_path, m.role,
                   (SELECT COUNT(*) FROM space_members WHERE space_id = s.id) AS members,
                   (SELECT COUNT(*) FROM space_call_presence WHERE space_id = s.id AND last_seen >= (NOW() - INTERVAL $ttl SECOND)) AS in_call
            FROM space_members m
            INNER JOIN spaces s ON s.id = m.space_id
            WHERE m.user_id = ?
            ORDER BY s.id DESC
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $items = [];
        while ($r = $res->fetch_assoc()) {
            $items[] = [
                'id' => (int)$r['id'], 'name_enc' => spOpen((string)$r['name_enc']),
                'avatar_path' => (string)($r['avatar_path'] ?? ''), 'role' => (string)$r['role'],
                'members' => (int)$r['members'], 'in_call' => (int)$r['in_call'],
            ];
        }
        $stmt->close();
        spJson(['ok' => true, 'spaces' => $items]);
    }

    if ($action === 'create') {
        $name_enc = $in['name_enc'] ?? '';
        if (!is_string($name_enc) || !spStoredTextOk($name_enc, 2000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $name_enc = spSeal($name_enc);

        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM spaces WHERE owner_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $owned = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
        if ($owned >= SPACE_MAX_OWNED) spJson(['ok' => false, 'error' => 'limit', 'message' => 'Можно создать не больше ' . SPACE_MAX_OWNED . ' пространств.'], 400);

        $code = bin2hex(random_bytes(12));
        $stmt = $conn->prepare("INSERT INTO spaces (owner_id, name_enc, invite_code) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $user_id, $name_enc, $code);
        $stmt->execute();
        $new_id = (int)$conn->insert_id;
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO space_members (space_id, user_id, role) VALUES (?, ?, 'owner')");
        $stmt->bind_param("ii", $new_id, $user_id);
        $stmt->execute();
        $stmt->close();

        spJson(['ok' => true, 'id' => $new_id, 'invite_code' => $code]);
    }

    if ($action === 'join') {
        $code = (string)($in['code'] ?? '');
        if (!preg_match('/^[a-f0-9]{24}$/', $code)) spJson(['ok' => false, 'error' => 'bad_code', 'message' => 'Неверная ссылка-приглашение.'], 400);

        $stmt = $conn->prepare("SELECT id, name_enc, invite_code FROM spaces WHERE invite_code = ?");
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $sp = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$sp) spJson(['ok' => false, 'error' => 'not_found', 'message' => 'Пространство не найдено или приглашение недействительно.'], 404);

        $sid = (int)$sp['id'];
        $ban = spOne($conn, "SELECT banned_until, banned_until > NOW() AS is_active FROM space_bans WHERE space_id = ? AND user_id = ?", "ii", $sid, $user_id);
        if ($ban && (int)$ban['is_active'] === 1) {
            spJson(['ok' => false, 'error' => 'banned', 'message' => 'Вы временно заблокированы на этом сервере.'], 403);
        }
        if ($ban) spExec($conn, "DELETE FROM space_bans WHERE space_id = ? AND user_id = ?", "ii", $sid, $user_id);
        if (spRole($conn, $sid, $user_id) === null) {
            $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM space_members WHERE space_id = ?");
            $stmt->bind_param("i", $sid);
            $stmt->execute();
            $cnt = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
            $stmt->close();
            if ($cnt >= SPACE_MAX_MEMBERS) spJson(['ok' => false, 'error' => 'full', 'message' => 'В пространстве уже максимум участников.'], 400);

            $stmt = $conn->prepare("INSERT IGNORE INTO space_members (space_id, user_id, role) VALUES (?, ?, 'member')");
            $stmt->bind_param("ii", $sid, $user_id);
            $stmt->execute();
            $stmt->close();
        }
        spJson(['ok' => true, 'id' => $sid, 'name_enc' => spOpen((string)$sp['name_enc'])]);
    }

    // --- всё остальное — только для участников ---
    if ($space_id <= 0) spJson(['ok' => false, 'error' => 'bad_data'], 400);
    $role = spRole($conn, $space_id, $user_id);
    if ($role === null) spJson(['ok' => false, 'error' => 'forbidden'], 403);
    $perms = spMemberPerms($conn, $space_id, $user_id);

    if ($action === 'channel_permissions') {
        spNeed($perms, SP_P_CHANNELS);
        $channel_id = (int)($in['channel_id'] ?? 0);
        if ($channel_id <= 0 || !spOne($conn, "SELECT id FROM space_channels WHERE id = ? AND space_id = ?", "ii", $channel_id, $space_id)) {
            spJson(['ok' => false, 'error' => 'not_found'], 404);
        }
        $stmt = $conn->prepare("SELECT subject_type, subject_id, allow_mask, deny_mask FROM space_channel_permissions WHERE channel_id = ?");
        $stmt->bind_param("i", $channel_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $overrides = [];
        while ($row = $res->fetch_assoc()) {
            $overrides[] = [
                'subject_type' => (string)$row['subject_type'], 'subject_id' => (int)$row['subject_id'],
                'allow' => (int)$row['allow_mask'], 'deny' => (int)$row['deny_mask'],
            ];
        }
        $stmt->close();
        spJson(['ok' => true, 'overrides' => $overrides]);
    }

    if ($action === 'channel_permission_set') {
        spNeed($perms, SP_P_CHANNELS);
        $channel_id = (int)($in['channel_id'] ?? 0);
        $subject_type = (string)($in['subject_type'] ?? '');
        $subject_id = (int)($in['subject_id'] ?? -1);
        $allow = (int)($in['allow'] ?? 0);
        $deny = (int)($in['deny'] ?? 0);
        if ($channel_id <= 0 || !in_array($subject_type, ['role', 'member'], true)
            || ($allow & ~SP_C_ALL) !== 0 || ($deny & ~SP_C_ALL) !== 0 || ($allow & $deny) !== 0) {
            spJson(['ok' => false, 'error' => 'bad_data'], 400);
        }
        if (!spOne($conn, "SELECT id FROM space_channels WHERE id = ? AND space_id = ?", "ii", $channel_id, $space_id)) {
            spJson(['ok' => false, 'error' => 'not_found'], 404);
        }
        if ($subject_type === 'role') {
            if ($subject_id < 0 || ($subject_id > 0 && !spOne($conn, "SELECT id FROM space_roles WHERE id = ? AND space_id = ?", "ii", $subject_id, $space_id))) {
                spJson(['ok' => false, 'error' => 'bad_data'], 400);
            }
            $target_perms = $subject_id === 0
                ? (int)(spOne($conn, "SELECT default_perms FROM spaces WHERE id = ?", "i", $space_id)['default_perms'] ?? SP_P_DEFAULT)
                : (int)(spOne($conn, "SELECT perms FROM space_roles WHERE id = ? AND space_id = ?", "ii", $subject_id, $space_id)['perms'] ?? 0);
        } elseif ($subject_id <= 0 || !spOne($conn, "SELECT user_id FROM space_members WHERE space_id = ? AND user_id = ?", "ii", $space_id, $subject_id)) {
            spJson(['ok' => false, 'error' => 'bad_data'], 400);
        } else {
            $target_perms = spMemberPerms($conn, $space_id, $subject_id);
        }
        if ($role !== 'owner') {
            if (spOutranks($perms, $role, $target_perms)) {
                spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нельзя менять права роли выше вашей.'], 403);
            }
            $grantable = SP_C_VIEW;
            if ($perms & SP_P_SEND) $grantable |= SP_C_SEND;
            if ($perms & SP_P_VOICE) $grantable |= SP_C_CONNECT | SP_C_SPEAK;
            if (($allow & ~$grantable) !== 0) {
                spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нельзя выдать права, которых нет у вас.'], 403);
            }
        }
        if ($allow === 0 && $deny === 0) {
            spExec($conn, "DELETE FROM space_channel_permissions WHERE channel_id = ? AND subject_type = ? AND subject_id = ?", "isi", $channel_id, $subject_type, $subject_id);
        } else {
            spExec($conn, "INSERT INTO space_channel_permissions (channel_id, subject_type, subject_id, allow_mask, deny_mask) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE allow_mask = VALUES(allow_mask), deny_mask = VALUES(deny_mask)", "isiii", $channel_id, $subject_type, $subject_id, $allow, $deny);
        }
        spJson(['ok' => true]);
    }

    // ---------- API-токены для ботов (управление — только из интерфейса) ----------
    if ($action === 'token_list') {
        spEnsureTokenTable($conn);
        $stmt = $conn->prepare("SELECT id, name, scope, token_hint, UNIX_TIMESTAMP(created_at) AS created, UNIX_TIMESTAMP(last_used) AS used FROM space_api_tokens WHERE user_id = ? AND space_id = ? ORDER BY id DESC");
        $stmt->bind_param("ii", $user_id, $space_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $tokens = [];
        while ($r = $res->fetch_assoc()) {
            $tokens[] = [
                'id' => (int)$r['id'], 'name' => (string)$r['name'], 'scope' => (string)$r['scope'],
                'hint' => (string)$r['token_hint'], 'created' => (int)$r['created'], 'used' => $r['used'] === null ? 0 : (int)$r['used'],
            ];
        }
        $stmt->close();
        spJson(['ok' => true, 'tokens' => $tokens, 'max' => SPACE_MAX_TOKENS]);
    }

    if ($action === 'token_create') {
        spEnsureTokenTable($conn);
        $name = trim((string)($in['name'] ?? ''));
        $scope = (string)($in['scope'] ?? 'read');
        if (!in_array($scope, ['read', 'write'], true)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $len = mb_strlen($name, 'UTF-8');
        if ($len < 1 || $len > 40 || preg_match('/[\x00-\x1F\x7F]/', $name)) {
            spJson(['ok' => false, 'error' => 'bad_name', 'message' => 'Название бота — от 1 до 40 символов.'], 400);
        }
        if ($scope === 'write') spNeed($perms, SP_P_SEND);
        $row = spOne($conn, "SELECT COUNT(*) AS c FROM space_api_tokens WHERE user_id = ? AND space_id = ?", "ii", $user_id, $space_id);
        if ((int)($row['c'] ?? 0) >= SPACE_MAX_TOKENS) {
            spJson(['ok' => false, 'error' => 'limit', 'message' => 'Можно создать не больше ' . SPACE_MAX_TOKENS . ' токенов. Отзовите ненужные.'], 400);
        }
        $plain = 'spb_' . bin2hex(random_bytes(24));
        $hash  = hash('sha256', $plain);
        $hint  = substr($plain, 0, 8);
        spExec($conn, "INSERT INTO space_api_tokens (user_id, space_id, name, scope, token_hash, token_hint) VALUES (?, ?, ?, ?, ?, ?)", "iissss", $user_id, $space_id, $name, $scope, $hash, $hint);
        // сам токен показывается один раз — на сервере остаётся только его хэш
        spJson(['ok' => true, 'id' => (int)$conn->insert_id, 'token' => $plain]);
    }

    if ($action === 'token_revoke') {
        spEnsureTokenTable($conn);
        $tid = (int)($in['id'] ?? 0);
        $n = spExec($conn, "DELETE FROM space_api_tokens WHERE id = ? AND user_id = ? AND space_id = ?", "iii", $tid, $user_id, $space_id);
        spJson(['ok' => $n > 0]);
    }

    if ($action === 'name_update') {
        if ($role !== 'owner') spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Переименовать сервер может только владелец.'], 403);
        $name = trim((string)($in['name'] ?? ''));
        $length = mb_strlen($name, 'UTF-8');
        if ($length < 1 || $length > 40 || preg_match('/[\x00-\x1F\x7F]/u', $name) || preg_match('//u', $name) !== 1) {
            spJson(['ok' => false, 'error' => 'bad_name', 'message' => 'Название сервера должно содержать от 1 до 40 символов.'], 400);
        }
        $name_enc = spSeal($name);
        spExec($conn, "UPDATE spaces SET name_enc = ? WHERE id = ?", "si", $name_enc, $space_id);
        spJson(['ok' => true, 'name' => $name]);
    }

    if ($action === 'avatar_update') {
        if ($role !== 'owner') spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Менять изображение сервера может только владелец.'], 403);
        $current = spOne($conn, "SELECT avatar_path FROM spaces WHERE id = ?", "i", $space_id);
        if (!$current) spJson(['ok' => false, 'error' => 'not_found'], 404);

        $new_path = null;
        if (!empty($in['remove'])) {
            spExec($conn, "UPDATE spaces SET avatar_path = NULL WHERE id = ?", "i", $space_id);
        } else {
            if (!isset($_FILES['avatar']) || !is_array($_FILES['avatar'])) {
                spJson(['ok' => false, 'error' => 'missing_file', 'message' => 'Выберите изображение сервера.'], 400);
            }
            $file = $_FILES['avatar'];
            if ((int)$file['error'] !== UPLOAD_ERR_OK) {
                $message = (int)$file['error'] === UPLOAD_ERR_INI_SIZE || (int)$file['error'] === UPLOAD_ERR_FORM_SIZE
                    ? 'Изображение слишком большое.'
                    : 'Не удалось загрузить изображение.';
                spJson(['ok' => false, 'error' => 'upload_failed', 'message' => $message], 400);
            }
            if ((int)$file['size'] <= 0 || (int)$file['size'] > 4 * 1024 * 1024 || !is_uploaded_file($file['tmp_name'])) {
                spJson(['ok' => false, 'error' => 'bad_image', 'message' => 'Размер изображения должен быть не больше 4 МБ.'], 400);
            }
            $image = @getimagesize($file['tmp_name']);
            $mime = is_array($image) ? (string)($image['mime'] ?? '') : '';
            $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            if (!isset($extensions[$mime]) || (int)$image[0] > 4096 || (int)$image[1] > 4096) {
                spJson(['ok' => false, 'error' => 'bad_image', 'message' => 'Поддерживаются JPEG, PNG и WebP размером до 4096×4096 пикселей.'], 400);
            }

            $upload_dir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'spaces';
            if (!is_dir($upload_dir) && !mkdir($upload_dir, 0755, true) && !is_dir($upload_dir)) {
                error_log('spaces.php: cannot create server avatar directory');
                spJson(['ok' => false, 'error' => 'storage', 'message' => 'Не удалось сохранить изображение сервера.'], 500);
            }
            $file_name = 'space_' . $space_id . '_' . bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
            $destination = $upload_dir . DIRECTORY_SEPARATOR . $file_name;
            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                error_log('spaces.php: failed to move server avatar upload');
                spJson(['ok' => false, 'error' => 'storage', 'message' => 'Не удалось сохранить изображение сервера.'], 500);
            }
            $new_path = 'uploads/spaces/' . $file_name;
            try {
                spExec($conn, "UPDATE spaces SET avatar_path = ? WHERE id = ?", "si", $new_path, $space_id);
            } catch (Throwable $e) {
                @unlink($destination);
                error_log('spaces.php: failed to update server avatar: ' . $e->getMessage());
                spJson(['ok' => false, 'error' => 'storage', 'message' => 'Не удалось сохранить изображение сервера.'], 500);
            }
        }

        $old_path = (string)($current['avatar_path'] ?? '');
        if ($old_path !== '' && $old_path !== $new_path
            && preg_match('/^uploads\/spaces\/space_' . $space_id . '_[a-f0-9]{32}\.(?:jpg|png|webp)$/', $old_path)) {
            $old_file = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $old_path);
            if (is_file($old_file)) @unlink($old_file);
        }
        spJson(['ok' => true, 'avatar_path' => $new_path ?: '']);
    }

    if ($action === 'info') {
        $sp = spOne($conn, "SELECT name_enc, avatar_path, invite_code, owner_id, default_perms FROM spaces WHERE id = ?", "i", $space_id);
        if (!$sp) spJson(['ok' => false, 'error' => 'not_found'], 404);

        $stmt = $conn->prepare("
            SELECT u.id, u.username, u.avatar, m.server_nick_enc, m.voice_muted, m.role, m.role_id,
                   p.status AS pstatus, TIMESTAMPDIFF(SECOND, p.seen, NOW()) AS page
            FROM space_members m INNER JOIN users u ON u.id = m.user_id
            LEFT JOIN space_presence p ON p.user_id = u.id
            WHERE m.space_id = ? ORDER BY (m.role = 'owner') DESC, m.joined_at ASC
        ");
        $stmt->bind_param("i", $space_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $members = [];
        while ($r = $res->fetch_assoc()) {
            // «Невидимка» и давно не активные видны другим как «не в сети»; свой статус человек видит как есть
            $pst  = (string)($r['pstatus'] ?? '');
            $page = $r['page'] === null ? null : (int)$r['page'];
            if ((int)$r['id'] === $user_id) {
                $presence = in_array($pst, ['away', 'dnd', 'invisible'], true) ? $pst : 'online';
            } elseif ($page === null || $page > 60 || $pst === 'invisible') {
                $presence = 'offline';
            } else {
                $presence = in_array($pst, ['away', 'dnd'], true) ? $pst : 'online';
            }
            $members[] = [
                'id' => (int)$r['id'], 'username' => (string)$r['username'], 'avatar' => (string)($r['avatar'] ?? ''),
                'server_nick' => ($nick = spOpen((string)($r['server_nick_enc'] ?? ''))),
                'display_name' => $nick !== '' ? $nick : (string)$r['username'],
                'voice_muted' => (bool)$r['voice_muted'],
                'role' => (string)$r['role'], 'role_id' => (int)$r['role_id'], 'presence' => $presence,
            ];
        }
        $stmt->close();

        $categories = [];
        $stmt = $conn->prepare("SELECT id, name_enc, position FROM space_categories WHERE space_id = ? ORDER BY position, id");
        $stmt->bind_param("i", $space_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) $categories[] = ['id' => (int)$r['id'], 'name_enc' => spOpen((string)$r['name_enc']), 'position' => (int)$r['position']];
        $stmt->close();
        $category_count = spCount($conn, 'space_categories', $space_id);
        $channel_counts = [
            'text' => spCount($conn, 'space_channels', $space_id, "AND type = 'text'"),
            'voice' => spCount($conn, 'space_channels', $space_id, "AND type = 'voice'"),
        ];

        $channels = [];
        $visible_categories = [];
        $stmt = $conn->prepare("SELECT id, category_id, type, name_enc, topic_enc, position FROM space_channels WHERE space_id = ? ORDER BY position, id");
        $stmt->bind_param("i", $space_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) {
            $channel_access = spChannelAccess($conn, $space_id, (int)$r['id'], $user_id, (string)$r['type'], $perms, $role);
            if (!($channel_access & SP_C_VIEW)) continue;
            $channels[] = [
                'id' => (int)$r['id'], 'category_id' => (int)$r['category_id'], 'type' => (string)$r['type'],
                'name_enc' => spOpen((string)$r['name_enc']), 'topic' => spOpen((string)($r['topic_enc'] ?? '')),
                'position' => (int)$r['position'], 'access' => $channel_access,
            ];
            if ((int)$r['category_id'] > 0) $visible_categories[(int)$r['category_id']] = true;
        }
        $stmt->close();
        $categories = array_values(array_filter($categories, static function ($category) use ($visible_categories) {
            return isset($visible_categories[$category['id']]);
        }));

        $roles = [];
        $stmt = $conn->prepare("SELECT id, name_enc, color, perms FROM space_roles WHERE space_id = ? ORDER BY id");
        $stmt->bind_param("i", $space_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) $roles[] = ['id' => (int)$r['id'], 'name_enc' => spOpen((string)$r['name_enc']), 'color' => (string)$r['color'], 'perms' => (int)$r['perms']];
        $stmt->close();

        spJson([
            'ok' => true, 'name_enc' => spOpen((string)$sp['name_enc']), 'avatar_path' => (string)($sp['avatar_path'] ?? ''),
            // код-приглашение отдаём только тем, у кого есть право приглашать
            'invite_code' => (($perms & SP_P_INVITE) && !$bot_auth) ? (string)$sp['invite_code'] : '',
            'role' => $role, 'perms' => $perms, 'default_perms' => ((int)$sp['default_perms']) & SP_P_ALL,
            'members' => $members, 'categories' => $categories, 'category_count' => $category_count,
            'channels' => $channels, 'channel_counts' => $channel_counts, 'roles' => $roles,
        ]);
    }

    if ($action === 'messages') {
        $after = max(0, (int)($in['after'] ?? 0));
        if (!$bot_auth) spTouchPresence($conn, $user_id);
        $channel_id = (int)($in['channel_id'] ?? 0);
        if (!spResolveChannel($conn, $space_id, $channel_id, 'text')) spJson(['ok' => false, 'error' => 'bad_channel'], 404);
        if (!(spChannelAccess($conn, $space_id, $channel_id, $user_id, 'text', $perms, $role) & SP_C_VIEW)) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нет доступа к этому каналу.'], 403);
        }
        if ($after === 0) {
            $stmt = $conn->prepare("
                SELECT * FROM (
                    SELECT m.id, m.user_id, m.body_enc, UNIX_TIMESTAMP(m.created_at) AS ts, UNIX_TIMESTAMP(m.edited_at) AS edited_ts, m.reply_to,
                           u.username, u.avatar, sm.server_nick_enc,
                           r.user_id AS reply_uid, r.body_enc AS reply_body, ru.username AS reply_username
                    FROM space_messages m INNER JOIN users u ON u.id = m.user_id
                    INNER JOIN space_members sm ON sm.space_id = m.space_id AND sm.user_id = m.user_id
                    LEFT JOIN space_messages r ON r.id = m.reply_to AND r.space_id = m.space_id
                    LEFT JOIN users ru ON ru.id = r.user_id
                    WHERE m.space_id = ? AND m.channel_id = ? ORDER BY m.id DESC LIMIT 100
                ) t ORDER BY id ASC
            ");
            $stmt->bind_param("ii", $space_id, $channel_id);
        } else {
            $stmt = $conn->prepare("
                SELECT m.id, m.user_id, m.body_enc, UNIX_TIMESTAMP(m.created_at) AS ts, UNIX_TIMESTAMP(m.edited_at) AS edited_ts, m.reply_to,
                       u.username, u.avatar, sm.server_nick_enc,
                       r.user_id AS reply_uid, r.body_enc AS reply_body, ru.username AS reply_username
                FROM space_messages m INNER JOIN users u ON u.id = m.user_id
                INNER JOIN space_members sm ON sm.space_id = m.space_id AND sm.user_id = m.user_id
                LEFT JOIN space_messages r ON r.id = m.reply_to AND r.space_id = m.space_id
                LEFT JOIN users ru ON ru.id = r.user_id
                WHERE m.space_id = ? AND m.channel_id = ? AND m.id > ? ORDER BY m.id ASC LIMIT 200
            ");
            $stmt->bind_param("iii", $space_id, $channel_id, $after);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        $msgs = [];
        while ($r = $res->fetch_assoc()) {
            $msgs[] = [
                'id' => (int)$r['id'], 'user_id' => (int)$r['user_id'], 'username' => (string)$r['username'],
                'display_name' => (($nick = spOpen((string)($r['server_nick_enc'] ?? ''))) !== '') ? $nick : (string)$r['username'],
                'avatar' => (string)($r['avatar'] ?? ''), 'body_enc' => spOpen((string)$r['body_enc']), 'ts' => (int)$r['ts'],
                'edited_ts' => $r['edited_ts'] === null ? 0 : (int)$r['edited_ts'],
                'reply_to' => $r['reply_to'] === null ? 0 : (int)$r['reply_to'],
                'reply' => $r['reply_to'] === null ? null : ($r['reply_uid'] === null ? ['gone' => true] : [
                    'user_id' => (int)$r['reply_uid'], 'username' => (string)$r['reply_username'],
                    'body_enc' => mb_substr(spOpen((string)$r['reply_body']), 0, 400, 'UTF-8'),
                ]),
            ];
        }
        $stmt->close();
        // окно последних сообщений канала: по нему другие клиенты замечают удаления и правки
        $window = [];
        $edits = [];
        if ($after > 0) {
            $edit_since = max(0, (int)($in['edit_since'] ?? 0));
            $stmt = $conn->prepare("SELECT id, body_enc, UNIX_TIMESTAMP(edited_at) AS edited_ts FROM space_messages WHERE space_id = ? AND channel_id = ? ORDER BY id DESC LIMIT 100");
            $stmt->bind_param("ii", $space_id, $channel_id);
            $stmt->execute();
            $wres = $stmt->get_result();
            while ($w = $wres->fetch_assoc()) {
                $window[] = (int)$w['id'];
                if ($w['edited_ts'] !== null && (int)$w['edited_ts'] > $edit_since) {
                    $edits[] = ['id' => (int)$w['id'], 'body_enc' => spOpen((string)$w['body_enc']), 'edited_ts' => (int)$w['edited_ts']];
                }
            }
            $stmt->close();
        }
        $voice = spVoiceMap($conn, $space_id);
        foreach (array_keys($voice) as $voice_channel_id) {
            $channel_id_for_access = (int)$voice_channel_id;
            if ($channel_id_for_access > 0) {
                $voice_channel = spOne($conn, "SELECT type FROM space_channels WHERE id = ? AND space_id = ?", "ii", $channel_id_for_access, $space_id);
                if (!$voice_channel || $voice_channel['type'] !== 'voice' || !(spChannelAccess($conn, $space_id, $channel_id_for_access, $user_id, 'voice', $perms, $role) & SP_C_VIEW)) {
                    unset($voice[$voice_channel_id]);
                }
            }
        }
        spJson(['ok' => true, 'messages' => $msgs, 'voice' => $voice, 'perms' => $perms, 'window' => $window, 'edits' => $edits, 'now' => time()]);
    }

    if ($action === 'send') {
        $body_enc = $in['body'] ?? $in['body_enc'] ?? '';
        if (!is_string($body_enc) || !spStoredTextOk($body_enc, 24000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $channel_id = (int)($in['channel_id'] ?? 0);
        if (!spResolveChannel($conn, $space_id, $channel_id, 'text')) spJson(['ok' => false, 'error' => 'bad_channel', 'message' => 'Такого канала нет.'], 404);
        if (!(spChannelAccess($conn, $space_id, $channel_id, $user_id, 'text', $perms, $role) & SP_C_SEND)) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нет права отправлять сообщения в этом канале.'], 403);
        }
        $body_enc = spSeal($body_enc);

        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM space_messages WHERE user_id = ? AND created_at >= (NOW() - INTERVAL 10 SECOND)");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $recent = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
        if ($recent >= 10) spJson(['ok' => false, 'error' => 'rate', 'message' => 'Слишком часто. Подождите пару секунд.'], 429);

        $reply_to = (int)($in['reply_to'] ?? 0);
        if ($reply_to > 0 && !spOne($conn, "SELECT id FROM space_messages WHERE id = ? AND space_id = ? AND channel_id = ?", "iii", $reply_to, $space_id, $channel_id)) $reply_to = 0;
        $reply_db = $reply_to > 0 ? $reply_to : null;
        $stmt = $conn->prepare("INSERT INTO space_messages (space_id, channel_id, user_id, body_enc, reply_to) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiisi", $space_id, $channel_id, $user_id, $body_enc, $reply_db);
        $stmt->execute();
        $mid = (int)$conn->insert_id;
        $stmt->close();
        spJson(['ok' => true, 'id' => $mid]);
    }

    if ($action === 'message_edit') {
        $mid = (int)($in['message_id'] ?? 0);
        $body_enc = $in['body'] ?? '';
        if ($mid <= 0 || !is_string($body_enc) || trim($body_enc) === '' || !spStoredTextOk($body_enc, 24000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $msg = spOne($conn, "SELECT id, user_id, channel_id FROM space_messages WHERE id = ? AND space_id = ?", "ii", $mid, $space_id);
        if (!$msg) spJson(['ok' => false, 'error' => 'not_found', 'message' => 'Сообщение уже удалено.'], 404);
        if ((int)$msg['user_id'] !== $user_id) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Редактировать можно только свои сообщения.'], 403);
        $sealed = spSeal($body_enc);
        spExec($conn, "UPDATE space_messages SET body_enc = ?, edited_at = NOW() WHERE id = ? AND space_id = ?", "sii", $sealed, $mid, $space_id);
        spJson(['ok' => true]);
    }

    if ($action === 'message_delete') {
        $mid = (int)($in['message_id'] ?? 0);
        if ($mid <= 0) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $msg = spOne($conn, "SELECT id, user_id FROM space_messages WHERE id = ? AND space_id = ?", "ii", $mid, $space_id);
        if (!$msg) spJson(['ok' => true]);   // уже удалено — для клиента это тоже успех
        $author = (int)$msg['user_id'];
        if ($author !== $user_id) {
            // чужие сообщения: владелец или тот, у кого есть право удалять участников, и только если права автора не выше
            spNeed($perms, SP_P_KICK);
            $a_role = spRole($conn, $space_id, $author);
            if ($a_role !== null && ($a_role === 'owner' || spOutranks($perms, $role, spMemberPerms($conn, $space_id, $author)))) {
                spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У автора права выше ваших.'], 403);
            }
        }
        spExec($conn, "DELETE FROM space_messages WHERE id = ? AND space_id = ?", "ii", $mid, $space_id);
        spJson(['ok' => true]);
    }

    // ---------- каналы и категории ----------
    if ($action === 'category_create') {
        spNeed($perms, SP_P_CHANNELS);
        $name_enc = $in['name_enc'] ?? '';
        if (!is_string($name_enc) || !spStoredTextOk($name_enc, 2000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $name_enc = spSeal($name_enc);
        if (spCount($conn, 'space_categories', $space_id) >= SPACE_MAX_CATEGORIES) {
            spJson(['ok' => false, 'error' => 'limit', 'message' => 'Можно создать не больше ' . SPACE_MAX_CATEGORIES . ' категорий.'], 400);
        }
        $pos = (int)(spOne($conn, "SELECT COALESCE(MAX(position), 0) + 1 AS p FROM space_categories WHERE space_id = ?", "i", $space_id)['p'] ?? 1);
        spExec($conn, "INSERT INTO space_categories (space_id, name_enc, position) VALUES (?, ?, ?)", "isi", $space_id, $name_enc, $pos);
        spJson(['ok' => true, 'id' => (int)$conn->insert_id]);
    }

    if ($action === 'category_update') {
        spNeed($perms, SP_P_CHANNELS);
        $id = (int)($in['id'] ?? 0);
        $name_enc = $in['name_enc'] ?? '';
        if ($id <= 0 || !is_string($name_enc) || !spStoredTextOk($name_enc, 2000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $name_enc = spSeal($name_enc);
        spExec($conn, "UPDATE space_categories SET name_enc = ? WHERE id = ? AND space_id = ?", "sii", $name_enc, $id, $space_id);
        spJson(['ok' => true]);
    }

    if ($action === 'category_delete') {
        spNeed($perms, SP_P_CHANNELS);
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        // каналы из удаляемой категории остаются — просто без категории
        spExec($conn, "UPDATE space_channels SET category_id = 0 WHERE category_id = ? AND space_id = ?", "ii", $id, $space_id);
        spExec($conn, "DELETE FROM space_categories WHERE id = ? AND space_id = ?", "ii", $id, $space_id);
        spJson(['ok' => true]);
    }

    if ($action === 'channel_create') {
        spNeed($perms, SP_P_CHANNELS);
        $type = (($in['type'] ?? '') === 'voice') ? 'voice' : 'text';
        $name_enc = $in['name_enc'] ?? '';
        $cat = (int)($in['category_id'] ?? 0);
        if (!is_string($name_enc) || !spStoredTextOk($name_enc, 2000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $name_enc = spSeal($name_enc);
        if ($cat > 0 && !spOne($conn, "SELECT id FROM space_categories WHERE id = ? AND space_id = ?", "ii", $cat, $space_id)) {
            spJson(['ok' => false, 'error' => 'bad_data'], 400);
        }
        if (spCount($conn, 'space_channels', $space_id) >= SPACE_MAX_CHANNELS) {
            spJson(['ok' => false, 'error' => 'limit', 'message' => 'Можно создать не больше ' . SPACE_MAX_CHANNELS . ' каналов.'], 400);
        }
        $first_text = $type === 'text' && spCount($conn, 'space_channels', $space_id, "AND type = 'text'") === 0;
        $pos = (int)(spOne($conn, "SELECT COALESCE(MAX(position), 0) + 1 AS p FROM space_channels WHERE space_id = ?", "i", $space_id)['p'] ?? 1);
        spExec($conn, "INSERT INTO space_channels (space_id, category_id, type, name_enc, position) VALUES (?, ?, ?, ?, ?)", "iissi", $space_id, $cat, $type, $name_enc, $pos);
        $cid = (int)$conn->insert_id;
        if ($first_text) {
            // старые сообщения (до появления каналов) переезжают в первый текстовый канал
            spExec($conn, "UPDATE space_messages SET channel_id = ? WHERE space_id = ? AND channel_id = 0", "ii", $cid, $space_id);
        }
        spJson(['ok' => true, 'id' => $cid]);
    }

    if ($action === 'channel_update') {
        spNeed($perms, SP_P_CHANNELS);
        $id = (int)($in['id'] ?? 0);
        $name_enc = $in['name_enc'] ?? '';
        if ($id <= 0 || !is_string($name_enc) || !spStoredTextOk($name_enc, 2000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $channel = spOne($conn, "SELECT category_id, topic_enc FROM space_channels WHERE id = ? AND space_id = ?", "ii", $id, $space_id);
        if (!$channel) spJson(['ok' => false, 'error' => 'not_found'], 404);
        $category_id = (int)$channel['category_id'];
        if (array_key_exists('category_id', $in)) {
            $category_id = (int)$in['category_id'];
            if ($category_id < 0 || ($category_id > 0 && !spOne($conn, "SELECT id FROM space_categories WHERE id = ? AND space_id = ?", "ii", $category_id, $space_id))) {
                spJson(['ok' => false, 'error' => 'bad_data'], 400);
            }
        }
        $topic_enc = (string)($channel['topic_enc'] ?? '');
        if (array_key_exists('topic', $in)) {
            $topic = $in['topic'];
            if (!is_string($topic) || strlen($topic) > 8192 || strpos($topic, "\0") !== false || preg_match('//u', $topic) !== 1) {
                spJson(['ok' => false, 'error' => 'bad_data'], 400);
            }
            $topic_enc = spSeal($topic);
        }
        $name_enc = spSeal($name_enc);
        spExec($conn, "UPDATE space_channels SET name_enc = ?, topic_enc = ?, category_id = ? WHERE id = ? AND space_id = ?", "ssiii", $name_enc, $topic_enc, $category_id, $id, $space_id);
        spJson(['ok' => true]);
    }

    if ($action === 'channel_delete') {
        spNeed($perms, SP_P_CHANNELS);
        $id = (int)($in['id'] ?? 0);
        $ch = $id > 0 ? spOne($conn, "SELECT id, type FROM space_channels WHERE id = ? AND space_id = ?", "ii", $id, $space_id) : null;
        if (!$ch) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if ($ch['type'] === 'text') {
            spExec($conn, "DELETE FROM space_messages WHERE space_id = ? AND channel_id = ?", "ii", $space_id, $id);
        } else {
            spExec($conn, "DELETE FROM space_call_presence WHERE space_id = ? AND channel_id = ?", "ii", $space_id, $id);
        }
        spExec($conn, "DELETE FROM space_channel_permissions WHERE channel_id = ?", "i", $id);
        spExec($conn, "DELETE FROM space_channels WHERE id = ? AND space_id = ?", "ii", $id, $space_id);
        spJson(['ok' => true]);
    }

    // ---------- роли и права ----------
    if ($action === 'role_create') {
        spNeed($perms, SP_P_ROLES);
        $name_enc = $in['name_enc'] ?? '';
        $color = (string)($in['color'] ?? '#99aab5');
        if (!is_string($name_enc) || !spStoredTextOk($name_enc, 2000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $name_enc = spSeal($name_enc);
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) $color = '#99aab5';
        if (spCount($conn, 'space_roles', $space_id) >= SPACE_MAX_ROLES) {
            spJson(['ok' => false, 'error' => 'limit', 'message' => 'Можно создать не больше ' . SPACE_MAX_ROLES . ' ролей.'], 400);
        }
        $new = ((int)($in['perms'] ?? 0)) & SP_P_ALL;
        if ($role !== 'owner') $new &= $perms & ~SP_P_ROLES;   // нельзя выдать больше, чем есть у вас; право на роли — только владелец
        spExec($conn, "INSERT INTO space_roles (space_id, name_enc, color, perms) VALUES (?, ?, ?, ?)", "issi", $space_id, $name_enc, $color, $new);
        spJson(['ok' => true, 'id' => (int)$conn->insert_id]);
    }

    if ($action === 'role_update') {
        spNeed($perms, SP_P_ROLES);
        $id = (int)($in['id'] ?? 0);
        $new = ((int)($in['perms'] ?? 0)) & SP_P_ALL;
        if ($id === 0) {   // роль «Участник» (по умолчанию)
            $cur_p = (int)(spOne($conn, "SELECT default_perms FROM spaces WHERE id = ?", "i", $space_id)['default_perms'] ?? SP_P_DEFAULT);
            if (spOutranks($perms, $role, $cur_p)) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У этой роли права выше ваших.'], 403);
            if ($role !== 'owner') $new = ($new & $perms & ~SP_P_ROLES) | ($cur_p & ~$perms) | ($cur_p & SP_P_ROLES);
            spExec($conn, "UPDATE spaces SET default_perms = ? WHERE id = ?", "ii", $new, $space_id);
            spJson(['ok' => true]);
        }
        $r = spOne($conn, "SELECT id, perms FROM space_roles WHERE id = ? AND space_id = ?", "ii", $id, $space_id);
        if (!$r) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if (spOutranks($perms, $role, (int)$r['perms'])) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У этой роли права выше ваших.'], 403);
        if ($role !== 'owner') $new = ($new & $perms & ~SP_P_ROLES) | ((int)$r['perms'] & ~$perms) | ((int)$r['perms'] & SP_P_ROLES);
        $name_enc = $in['name_enc'] ?? null;
        $color = (string)($in['color'] ?? '');
        if ($name_enc !== null) {
            if (!is_string($name_enc) || !spStoredTextOk($name_enc, 2000)) spJson(['ok' => false, 'error' => 'bad_data'], 400);
            $name_enc = spSeal($name_enc);
            spExec($conn, "UPDATE space_roles SET name_enc = ? WHERE id = ? AND space_id = ?", "sii", $name_enc, $id, $space_id);
        }
        if (preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
            spExec($conn, "UPDATE space_roles SET color = ? WHERE id = ? AND space_id = ?", "sii", $color, $id, $space_id);
        }
        spExec($conn, "UPDATE space_roles SET perms = ? WHERE id = ? AND space_id = ?", "iii", $new, $id, $space_id);
        spJson(['ok' => true]);
    }

    if ($action === 'role_delete') {
        spNeed($perms, SP_P_ROLES);
        $id = (int)($in['id'] ?? 0);
        $r = $id > 0 ? spOne($conn, "SELECT id, perms FROM space_roles WHERE id = ? AND space_id = ?", "ii", $id, $space_id) : null;
        if (!$r) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if (spOutranks($perms, $role, (int)$r['perms'])) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У этой роли права выше ваших.'], 403);
        spExec($conn, "UPDATE space_members SET role_id = 0 WHERE space_id = ? AND role_id = ?", "ii", $space_id, $id);
        spExec($conn, "DELETE FROM space_channel_permissions WHERE subject_type = 'role' AND subject_id = ? AND channel_id IN (SELECT id FROM space_channels WHERE space_id = ?)", "ii", $id, $space_id);
        spExec($conn, "DELETE FROM space_roles WHERE id = ? AND space_id = ?", "ii", $id, $space_id);
        spJson(['ok' => true]);
    }

    if ($action === 'member_set_role') {
        spNeed($perms, SP_P_ROLES);
        $target = (int)($in['user_id'] ?? 0);
        $rid = (int)($in['role_id'] ?? 0);
        $t_role = spRole($conn, $space_id, $target);
        if ($target <= 0 || $t_role === null) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if ($t_role === 'owner' || $target === $user_id) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Эту роль изменить нельзя.'], 403);
        if (spOutranks($perms, $role, spMemberPerms($conn, $space_id, $target))) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У участника права выше ваших.'], 403);
        }
        if ($rid > 0) {
            $r = spOne($conn, "SELECT perms FROM space_roles WHERE id = ? AND space_id = ?", "ii", $rid, $space_id);
            if (!$r) spJson(['ok' => false, 'error' => 'not_found'], 404);
            if (spOutranks($perms, $role, (int)$r['perms'])) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нельзя назначить роль с правами выше ваших.'], 403);
        }
        spExec($conn, "UPDATE space_members SET role_id = ? WHERE space_id = ? AND user_id = ?", "iii", $rid, $space_id, $target);
        spJson(['ok' => true]);
    }

    if ($action === 'member_nick') {
        spNeed($perms, SP_P_KICK);
        $target = (int)($in['user_id'] ?? 0);
        $nick = trim((string)($in['nickname'] ?? ''));
        $target_role = $target > 0 ? spRole($conn, $space_id, $target) : null;
        if ($target_role === null) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if ($target_role === 'owner' || $target === $user_id) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нельзя изменить этот ник.'], 403);
        if (spOutranks($perms, $role, spMemberPerms($conn, $space_id, $target))) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У участника права выше ваших.'], 403);
        }
        $length = mb_strlen($nick, 'UTF-8');
        if ($length > 32 || preg_match('/[\x00-\x1F\x7F]/u', $nick) || preg_match('//u', $nick) !== 1) {
            spJson(['ok' => false, 'error' => 'bad_nickname', 'message' => 'Ник сервера должен быть не длиннее 32 символов.'], 400);
        }
        $stored = $nick === '' ? null : spSeal($nick);
        spExec($conn, "UPDATE space_members SET server_nick_enc = ? WHERE space_id = ? AND user_id = ?", "sii", $stored, $space_id, $target);
        spJson(['ok' => true]);
    }

    if ($action === 'member_voice_mute') {
        spNeed($perms, SP_P_KICK);
        $target = (int)($in['user_id'] ?? 0);
        $muted = !empty($in['muted']) ? 1 : 0;
        $target_role = $target > 0 ? spRole($conn, $space_id, $target) : null;
        if ($target_role === null) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if ($target_role === 'owner' || $target === $user_id) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нельзя заглушить этого участника.'], 403);
        if (spOutranks($perms, $role, spMemberPerms($conn, $space_id, $target))) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У участника права выше ваших.'], 403);
        }
        spExec($conn, "UPDATE space_members SET voice_muted = ? WHERE space_id = ? AND user_id = ?", "iii", $muted, $space_id, $target);
        spJson(['ok' => true, 'muted' => (bool)$muted]);
    }

    if ($action === 'member_ban') {
        spNeed($perms, SP_P_KICK);
        $target = (int)($in['user_id'] ?? 0);
        $target_role = $target > 0 ? spRole($conn, $space_id, $target) : null;
        if ($target_role === null) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if ($target_role === 'owner' || $target === $user_id) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нельзя заблокировать этого участника.'], 403);
        if (spOutranks($perms, $role, spMemberPerms($conn, $space_id, $target))) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У участника права выше ваших.'], 403);
        }
        $stmt = $conn->prepare("INSERT INTO space_bans (space_id, user_id, banned_until, created_by) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY), ?) ON DUPLICATE KEY UPDATE banned_until = VALUES(banned_until), created_by = VALUES(created_by), created_at = NOW()");
        $stmt->bind_param("iii", $space_id, $target, $user_id);
        $stmt->execute();
        $stmt->close();
        spExec($conn, "DELETE FROM space_members WHERE space_id = ? AND user_id = ?", "ii", $space_id, $target);
        spExec($conn, "DELETE FROM space_channel_permissions WHERE subject_type = 'member' AND subject_id = ? AND channel_id IN (SELECT id FROM space_channels WHERE space_id = ?)", "ii", $target, $space_id);
        spExec($conn, "DELETE FROM space_call_presence WHERE space_id = ? AND user_id = ?", "ii", $space_id, $target);
        spExec($conn, "DELETE FROM space_signals WHERE space_id = ? AND (to_user = ? OR from_user = ?)", "iii", $space_id, $target, $target);
        spJson(['ok' => true]);
    }

    if ($action === 'ban_list') {
        spNeed($perms, SP_P_KICK);
        $stmt = $conn->prepare("SELECT b.user_id, b.banned_until, u.username FROM space_bans b INNER JOIN users u ON u.id = b.user_id WHERE b.space_id = ? AND b.banned_until > NOW() ORDER BY b.banned_until");
        $stmt->bind_param("i", $space_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $bans = [];
        while ($row = $res->fetch_assoc()) {
            $bans[] = [
                'user_id' => (int)$row['user_id'], 'username' => (string)$row['username'],
                'banned_until' => (string)$row['banned_until'],
            ];
        }
        $stmt->close();
        spJson(['ok' => true, 'bans' => $bans]);
    }

    if ($action === 'member_unban') {
        spNeed($perms, SP_P_KICK);
        $target = (int)($in['user_id'] ?? 0);
        if ($target <= 0) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        spExec($conn, "DELETE FROM space_bans WHERE space_id = ? AND user_id = ?", "ii", $space_id, $target);
        spJson(['ok' => true]);
    }

    if ($action === 'member_kick') {
        spNeed($perms, SP_P_KICK);
        $target = (int)($in['user_id'] ?? 0);
        $t_role = spRole($conn, $space_id, $target);
        if ($target <= 0 || $t_role === null) spJson(['ok' => false, 'error' => 'not_found'], 404);
        if ($t_role === 'owner' || $target === $user_id) spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Этого участника удалить нельзя.'], 403);
        if (spOutranks($perms, $role, spMemberPerms($conn, $space_id, $target))) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'У участника права выше ваших.'], 403);
        }
        spExec($conn, "DELETE FROM space_members WHERE space_id = ? AND user_id = ?", "ii", $space_id, $target);
        spExec($conn, "DELETE FROM space_channel_permissions WHERE subject_type = 'member' AND subject_id = ? AND channel_id IN (SELECT id FROM space_channels WHERE space_id = ?)", "ii", $target, $space_id);
        spExec($conn, "DELETE FROM space_call_presence WHERE space_id = ? AND user_id = ?", "ii", $space_id, $target);
        spExec($conn, "DELETE FROM space_signals WHERE space_id = ? AND (to_user = ? OR from_user = ?)", "iii", $space_id, $target, $target);
        spJson(['ok' => true]);
    }

    if ($action === 'leave') {
        if ($role === 'owner') spJson(['ok' => false, 'error' => 'owner', 'message' => 'Владелец не может выйти — удалите пространство.'], 400);
        spExec($conn, "DELETE FROM space_channel_permissions WHERE subject_type = 'member' AND subject_id = ? AND channel_id IN (SELECT id FROM space_channels WHERE space_id = ?)", "ii", $user_id, $space_id);
        foreach (["DELETE FROM space_members WHERE space_id = ? AND user_id = ?",
                  "DELETE FROM space_call_presence WHERE space_id = ? AND user_id = ?"] as $sql) {
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $space_id, $user_id);
            $stmt->execute();
            $stmt->close();
        }
        spJson(['ok' => true]);
    }

    if ($action === 'delete') {
        if ($role !== 'owner') spJson(['ok' => false, 'error' => 'forbidden'], 403);
        spExec($conn, "DELETE FROM space_channel_permissions WHERE channel_id IN (SELECT id FROM space_channels WHERE space_id = ?)", "i", $space_id);
        foreach (["DELETE FROM space_signals WHERE space_id = ?", "DELETE FROM space_call_presence WHERE space_id = ?",
                  "DELETE FROM space_channels WHERE space_id = ?", "DELETE FROM space_categories WHERE space_id = ?", "DELETE FROM space_roles WHERE space_id = ?",
                  "DELETE FROM space_messages WHERE space_id = ?", "DELETE FROM space_members WHERE space_id = ?",
                  "DELETE FROM spaces WHERE id = ?"] as $sql) {
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $space_id);
            $stmt->execute();
            $stmt->close();
        }
        spJson(['ok' => true]);
    }

    // ---------- созвон ----------
    if ($action === 'call_join') {
        $channel_id = (int)($in['channel_id'] ?? 0);
        if (!spResolveChannel($conn, $space_id, $channel_id, 'voice')) spJson(['ok' => false, 'error' => 'bad_channel', 'message' => 'Такого голосового канала нет.'], 404);
        if (!(spChannelAccess($conn, $space_id, $channel_id, $user_id, 'voice', $perms, $role) & SP_C_CONNECT)) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нет права подключаться к этому голосовому каналу.'], 403);
        }
        $existing = spCallParticipants($conn, $space_id, $channel_id);
        $existing = array_values(array_filter($existing, function ($participant) use ($conn, $space_id, $channel_id) {
            return spCallCanConnect($conn, $space_id, $channel_id, $participant['user_id']);
        }));
        $already = false;
        foreach ($existing as $p) if ($p['user_id'] === $user_id) $already = true;
        $others = array_values(array_filter($existing, function ($p) use ($user_id) { return $p['user_id'] !== $user_id; }));
        if (!$already && count($others) + 1 > SPACE_MAX_CALL) {
            spJson(['ok' => false, 'error' => 'full', 'message' => 'В голосовом канале уже ' . SPACE_MAX_CALL . ' участников — это максимум.'], 400);
        }

        // чистим устаревшие сигналы для меня и отмечаемся в созвоне
        $stmt = $conn->prepare("DELETE FROM space_signals WHERE space_id = ? AND (to_user = ? OR from_user = ?)");
        $stmt->bind_param("iii", $space_id, $user_id, $user_id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO space_call_presence (space_id, user_id, channel_id, last_seen) VALUES (?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE last_seen = NOW(), channel_id = VALUES(channel_id)");
        $stmt->bind_param("iii", $space_id, $user_id, $channel_id);
        $stmt->execute();
        $stmt->close();
        $member_state = spOne($conn, "SELECT voice_muted FROM space_members WHERE space_id = ? AND user_id = ?", "ii", $space_id, $user_id);

        $res = $conn->query("SELECT COALESCE(MAX(id), 0) AS m FROM space_signals");
        $cursor = $res ? (int)$res->fetch_assoc()['m'] : 0;
        spJson(['ok' => true, 'participants' => $others, 'cursor' => $cursor, 'muted' => (bool)($member_state['voice_muted'] ?? false)]);
    }

    if ($action === 'call_poll') {
        $after = max(0, (int)($in['after'] ?? 0));
        $mine = spOne($conn, "SELECT p.channel_id, m.voice_muted FROM space_call_presence p INNER JOIN space_members m ON m.space_id = p.space_id AND m.user_id = p.user_id WHERE p.space_id = ? AND p.user_id = ?", "ii", $space_id, $user_id);
        if (!$mine) {
            spExec($conn, "DELETE FROM space_signals WHERE space_id = ? AND to_user = ?", "ii", $space_id, $user_id);
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Вы больше не подключены к голосовому каналу.'], 403);
        }
        $my_channel = (int)$mine['channel_id'];
        if (!spResolveChannel($conn, $space_id, $my_channel, 'voice')
            || !(spChannelAccess($conn, $space_id, $my_channel, $user_id, 'voice', $perms, $role) & SP_C_CONNECT)) {
            spExec($conn, "DELETE FROM space_call_presence WHERE space_id = ? AND user_id = ?", "ii", $space_id, $user_id);
            spExec($conn, "DELETE FROM space_signals WHERE space_id = ? AND (to_user = ? OR from_user = ?)", "iii", $space_id, $user_id, $user_id);
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нет права подключаться к этому голосовому каналу.'], 403);
        }
        $stmt = $conn->prepare("UPDATE space_call_presence SET last_seen = NOW() WHERE space_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $space_id, $user_id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("SELECT id, from_user, payload_enc FROM space_signals WHERE space_id = ? AND to_user = ? AND id > ? ORDER BY id ASC LIMIT 100");
        $stmt->bind_param("iii", $space_id, $user_id, $after);
        $stmt->execute();
        $res = $stmt->get_result();
        $signals = [];
        $max_id = $after;
        while ($r = $res->fetch_assoc()) {
            if (spCallCanConnect($conn, $space_id, $my_channel, (int)$r['from_user'])) {
                $signals[] = ['id' => (int)$r['id'], 'from' => (int)$r['from_user'], 'payload' => spOpen((string)$r['payload_enc'])];
            }
            $max_id = (int)$r['id'];
        }
        $stmt->close();

        if ($max_id > $after) {  // доставленное удаляем
            $stmt = $conn->prepare("DELETE FROM space_signals WHERE space_id = ? AND to_user = ? AND id <= ?");
            $stmt->bind_param("iii", $space_id, $user_id, $max_id);
            $stmt->execute();
            $stmt->close();
        }
        $conn->query("DELETE FROM space_signals WHERE created_at < (NOW() - INTERVAL 3 MINUTE)");

        // участники — только из того же голосового канала, где сижу я
        $participants = spCallParticipants($conn, $space_id, $my_channel);
        $participants = array_values(array_filter($participants, function ($participant) use ($conn, $space_id, $my_channel) {
            return spCallCanConnect($conn, $space_id, $my_channel, $participant['user_id']);
        }));
        spJson(['ok' => true, 'signals' => $signals, 'cursor' => $max_id, 'participants' => $participants, 'muted' => (bool)$mine['voice_muted']]);
    }

    if ($action === 'call_signal') {
        $to = (int)($in['to'] ?? 0);
        $payload = $in['payload'] ?? '';
        if ($to <= 0 || $to === $user_id || !is_string($payload) || !spTextOk($payload, 20000) || json_decode($payload, true) === null) spJson(['ok' => false, 'error' => 'bad_data'], 400);
        $mine = spOne($conn, "SELECT channel_id FROM space_call_presence WHERE space_id = ? AND user_id = ? AND last_seen >= (NOW() - INTERVAL " . SPACE_CALL_TTL . " SECOND)", "ii", $space_id, $user_id);
        $target = spOne($conn, "SELECT channel_id FROM space_call_presence WHERE space_id = ? AND user_id = ? AND last_seen >= (NOW() - INTERVAL " . SPACE_CALL_TTL . " SECOND)", "ii", $space_id, $to);
        if (!$mine || !$target || (int)$mine['channel_id'] !== (int)$target['channel_id']) spJson(['ok' => false, 'error' => 'forbidden'], 403);
        $channel_id = (int)$mine['channel_id'];
        if (!spCallCanConnect($conn, $space_id, $channel_id, $to)) {
            spJson(['ok' => false, 'error' => 'forbidden'], 403);
        }
        $channel_access = spChannelAccess($conn, $space_id, $channel_id, $user_id, 'voice', $perms, $role);
        if (!($channel_access & SP_C_CONNECT)) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нет права участвовать в этом голосовом канале.'], 403);
        }
        $signal_data = json_decode($payload, true);
        if (!($channel_access & SP_C_SPEAK) && isset($signal_data['sdp']['sdp'])
            && preg_match('/^m=audio\s+(?!0(?:\s|$))/m', (string)$signal_data['sdp']['sdp'])) {
            spJson(['ok' => false, 'error' => 'forbidden', 'message' => 'Нет права передавать звук в этом канале.'], 403);
        }

        $payload = spSeal($payload);
        $stmt = $conn->prepare("INSERT INTO space_signals (space_id, from_user, to_user, payload_enc) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiis", $space_id, $user_id, $to, $payload);
        $stmt->execute();
        $stmt->close();
        spJson(['ok' => true]);
    }

    if ($action === 'call_leave') {
        $stmt = $conn->prepare("DELETE FROM space_call_presence WHERE space_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $space_id, $user_id);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("DELETE FROM space_signals WHERE space_id = ? AND (to_user = ? OR from_user = ?)");
        $stmt->bind_param("iii", $space_id, $user_id, $user_id);
        $stmt->execute();
        $stmt->close();
        spJson(['ok' => true]);
    }

    spJson(['ok' => false, 'error' => 'unknown_action'], 400);
}

/*
|--------------------------------------------------------------------------
| ОБОЛОЧКА СТРАНИЦЫ (шапка, уведомления, тема) — как в index.php
|--------------------------------------------------------------------------
*/

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: spaces.php");
    exit;
}

$notifications = [];
$notif_count = 0;
$unread_count = 0;
$pending_reports_count = 0;
$current_user_data = [];

try {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

    $stmt = $conn->prepare("SELECT id, username, avatar, status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    if ($is_admin) {
        $result = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
        if ($result) {
            $pending_reports_count = (int)$result->fetch_assoc()['c'];
        }
    }
} catch (Throwable $e) {
    error_log('spaces.php shell: ' . $e->getMessage());
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function isOnline(?string $status): bool {
    return $status === 'online';
}


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Пространства — PLAYERCHAT</title>
    <link rel="icon" href="images/favicon.ico?v=<?= (int)@filemtime(__DIR__ . '/images/favicon.ico') ?>" sizes="32x32">
    <link rel="icon" href="images/logo.svg?v=<?= (int)@filemtime(__DIR__ . '/images/logo.svg') ?>" type="image/svg+xml">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png?v=<?= (int)@filemtime(__DIR__ . '/images/apple-touch-icon.png') ?>">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/spaces.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/spaces.css') ?>">
<?php echo seasonHead(); ?>
</head>
<body class="spaces-page"<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout spaces-layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main class="spaces-main">

            <div class="card sp-insecure" id="spInsecure" hidden>
                Соединение открыто без HTTPS: передача сообщений не защищена от перехвата, а голосовые и видеозвонки (микрофон и камера)
                могут быть недоступны. Используйте <strong>https://</strong> (или localhost для разработки).
            </div>

            <div class="spaces-app" id="spacesApp">

                <!-- ===== Список пространств ===== -->
                <section class="card sp-list">
                    <div class="sp-list-head">
                        <span class="sp-list-icon"><img src="images/nav-spaces.svg" alt=""></span>
                        <div>
                            <h1>Пространства</h1>
                            <p>Чат с автоматическим шифрованием</p>
                        </div>
                    </div>
                    <div class="sp-list-actions">
                        <button type="button" class="sp-btn primary" id="spCreateBtn">Создать</button>
                        <button type="button" class="sp-btn" id="spJoinBtn">Войти по ссылке</button>
                    </div>
                    <div class="sp-items" id="spItems"></div>

                    <?php
                    $me_name   = (string)($current_user_data['username'] ?? $username);
                    $me_avatar = (string)($current_user_data['avatar'] ?? '');
                    $me_has_av = $me_avatar !== '' && file_exists($me_avatar);
                    $me_letter = mb_strtoupper(mb_substr($me_name, 0, 1, 'UTF-8'), 'UTF-8');
                    ?>
                    <div class="sp-voice-bar" id="spVoiceBar" hidden>
                        <button type="button" class="sp-voice-main" id="spVoiceMain" title="Состояние связи" aria-haspopup="dialog" aria-expanded="false">
                            <div class="sp-net" id="spNet" data-level="0" aria-label="Качество связи"><i></i><i></i><i></i><i></i></div>
                            <div class="sp-voice-info">
                                <div class="sp-voice-title">Голосовая связь подключена</div>
                                <div class="sp-voice-sub" id="spVoiceSub"></div>
                            </div>
                        </button>
                        <button type="button" class="sp-me-btn" id="spShareBtn" title="Показ экрана" aria-label="Показ экрана" hidden>
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <rect x="3" y="4" width="18" height="12" rx="2"/>
                                <path d="M8 20h8M12 16v4"/>
                            </svg>
                        </button>
                        <button type="button" class="sp-me-btn" id="spVoiceLeave" title="Отключиться" aria-label="Отключиться от голосового канала">
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M10.68 13.31a16 16 0 0 0 3.41 2.6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7 2 2 0 0 1 1.72 2v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.42 19.42 0 0 1-3.33-2.67m-2.67-3.34a19.79 19.79 0 0 1-3.07-8.63A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91"/>
                                <line x1="23" y1="1" x2="1" y2="23"/>
                            </svg>
                        </button>
                    </div>
                    <div class="sp-me" id="spMe" data-status="online">
                        <div class="sp-me-avatar" id="spMeAvatar" role="button" tabindex="0" title="Сменить статус" aria-label="Сменить статус" aria-haspopup="menu">
                            <?php if ($me_has_av): ?>
                                <img src="<?= htmlspecialchars($me_avatar, ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($me_name, ENT_QUOTES, 'UTF-8') ?>">
                            <?php else: ?>
                                <?= htmlspecialchars($me_letter) ?>
                            <?php endif; ?>
                            <span class="sp-me-dot" id="spMeDot"></span>
                        </div>
                        <div class="sp-me-info">
                            <div class="sp-me-name"><?= htmlspecialchars($me_name, ENT_QUOTES, 'UTF-8') ?></div>
                            <div class="sp-me-sub" id="spNetText">В сети</div>
                        </div>
                        <button type="button" class="sp-me-btn" id="spMeMic" title="Выключить микрофон" aria-label="Выключить микрофон" aria-pressed="false">
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <rect x="9" y="3" width="6" height="11" rx="3"/>
                                <path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>
                                <line class="sp-mic-slash" x1="4" y1="4" x2="20" y2="20"/>
                            </svg>
                        </button>
                        <button type="button" class="sp-me-btn" id="spMeDeaf" title="Выключить звук" aria-label="Выключить звук" aria-pressed="false">
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M3 15v-3a9 9 0 0 1 18 0v3"/>
                                <rect x="3" y="14" width="4" height="7" rx="1.5"/>
                                <rect x="17" y="14" width="4" height="7" rx="1.5"/>
                                <line class="sp-mic-slash" x1="4" y1="4" x2="20" y2="20"/>
                            </svg>
                        </button>
                        <button type="button" class="sp-me-btn" id="spMeNotify" title="Настройки уведомлений" aria-label="Настройки уведомлений">
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6.5 2 6.5H4S6 14 6 9z"/><path d="M10 19a2 2 0 0 0 4 0"/></svg>
                        </button>
                        <button type="button" class="sp-me-btn" id="spMeSet" title="Настройки голоса и шумоподавление" aria-label="Настройки голоса и шумоподавление">
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <circle cx="12" cy="12" r="3"/>
                                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
                            </svg>
                        </button>
                    </div>
                </section>

                <!-- ===== Открытое пространство ===== -->
                <section class="card sp-view">
                    <div class="sp-empty" id="spEmpty">
                        <img src="images/nav-spaces.svg" alt="" class="sp-empty-ico">
                        <h2>Выберите пространство</h2>
                        <p>Создайте группу для общения и созвонов или войдите по ссылке-приглашению.</p>
                    </div>

                    <div class="sp-active" id="spActive" hidden>
                        <header class="sp-head">
                            <button type="button" class="sp-icon-btn sp-back" id="spBack" aria-label="Назад">‹</button>
                            <button type="button" class="sp-btn sp-ch-toggle" id="spChToggle" aria-label="Каналы">☰ Каналы</button>
                            <div class="sp-head-info">
                                <div class="sp-head-title" id="spTitle"></div>
                            </div>
                            <div class="sp-head-actions">
                                <button type="button" class="sp-btn" id="spMemberToggle" aria-controls="spMemberPanel" aria-expanded="false">Показать участников</button>
                                <button type="button" class="sp-btn" id="spRolesBtn" hidden>Роли</button>
                                <button type="button" class="sp-btn" id="spBotsBtn">Боты</button>
                                <button type="button" class="sp-btn primary" id="spInviteBtn">Пригласить</button>
                                <button type="button" class="sp-btn danger" id="spLeaveBtn" hidden>Выйти</button>
                                <button type="button" class="sp-btn danger" id="spDeleteBtn" hidden>Удалить</button>
                            </div>
                        </header>

                        <div class="sp-body">
                            <!-- ===== Каналы и категории ===== -->
                            <aside class="sp-channels" id="spChannels">
                                <div class="sp-ch-head">
                                    <span class="sp-ch-head-title">Каналы</span>
                                    <button type="button" class="sp-icon-btn" id="spChMenuBtn" title="Меню каналов" aria-label="Меню каналов">⋯</button>
                                </div>
                                <div class="sp-ch-list" id="spChList"></div>
                            </aside>

                            <div class="sp-main">
                                <div class="sp-lock" id="spLock" hidden></div>

                                <div class="sp-chan-bar" id="spChanBar"></div>

                                <div class="sp-call" id="spCall" hidden>
                                    <div class="sp-call-title" id="spCallTitle"></div>
                                    <div class="sp-grid" id="spGrid" data-count="1"></div>
                                    <div class="sp-stage-bar" id="spStageBar">
                                        <div class="sp-stage-group">
                                            <button type="button" class="sp-stage-btn" id="spStMic" title="Выключить микрофон" aria-label="Микрофон">
                                                <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/><line class="sp-mic-slash" x1="4" y1="4" x2="20" y2="20"/></svg>
                                            </button>
                                            <button type="button" class="sp-stage-btn" id="spStDeaf" title="Выключить звук" aria-label="Наушники">
                                                <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 15v-3a9 9 0 0 1 18 0v3"/><rect x="3" y="14" width="4" height="7" rx="1.5"/><rect x="17" y="14" width="4" height="7" rx="1.5"/><line class="sp-mic-slash" x1="4" y1="4" x2="20" y2="20"/></svg>
                                            </button>
                                            <button type="button" class="sp-stage-btn off" id="spStCam" title="Включить камеру" aria-label="Камера">
                                                <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 8.5V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1.5l5 3.2V5.3z"/><line class="sp-mic-slash" x1="4" y1="4" x2="20" y2="20"/></svg>
                                            </button>
                                        </div>
                                        <div class="sp-stage-group">
                                            <button type="button" class="sp-stage-btn" id="spStShare" title="Показ экрана" aria-label="Показ экрана">
                                                <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>
                                            </button>
                                        </div>
                                        <button type="button" class="sp-stage-hang" id="spStHang" title="Отключиться" aria-label="Отключиться от голосового канала">
                                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="transform: rotate(135deg)"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                                        </button>
                                    </div>
                                </div>

                                <div class="sp-messages" id="spMessages"></div>

                                <div class="sp-nosend" id="spNoSend" hidden>У вас нет права писать сообщения в этом пространстве.</div>

                                <form class="sp-composer" id="spComposer" autocomplete="off">
                                    <textarea id="spInput" rows="1" placeholder="Написать сообщение…" maxlength="4000"></textarea>
                                    <button type="submit" class="sp-btn primary" id="spSend">Отправить</button>
                                </form>
                            </div>

                            <aside class="sp-members-panel" id="spMemberPanel" aria-label="Участники" hidden>
                                <div class="sp-members-head" id="spMemberPanelHead">Участники</div>
                                <div class="sp-members-list" id="spMemberList"></div>
                            </aside>
                        </div>
                    </div>
                </section>
            </div>
        </main>


    </div>

    <script src="assets/js/script.js"></script>
    <script>
        window.SPACES_CFG = {
            userId: <?= (int)$user_id ?>,
            username: <?= json_encode($username, JSON_UNESCAPED_UNICODE) ?>,
            avatar: <?= json_encode(!empty($me_has_av) ? $me_avatar : '') ?>,
            csrf: <?= json_encode($spaces_csrf) ?>,
            status: <?= json_encode(spMyStatus($conn, $user_id)) ?>
        };
    </script>
    <script>
        // Живые значки шапки: раз в 30 с спрашиваем ?api=shell (пока вкладка видима)
        (function () {
            var cfg = window.SPACES_CFG || {};
            function setBadge(el, n) {
                if (!el) return;
                el.textContent = n > 99 ? '99+' : String(n);
                el.style.display = n > 0 ? '' : 'none';
            }
            function tick() {
                if (document.hidden) return;
                fetch('spaces.php?api=shell', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': cfg.csrf || '' },
                    body: '{}'
                }).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) {
                    if (!d || !d.ok) return;
                    setBadge(document.getElementById('notificationsBadge'), d.notifications);
                    document.dispatchEvent(new CustomEvent('shell:update', { detail: d }));
                }).catch(function () {});
            }
            setInterval(tick, 30000);
            document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(); });
        })();
    </script>
    <script src="assets/js/aesgcm-fallback.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/aesgcm-fallback.js') ?>"></script>
    <script src="assets/js/spaces.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/spaces.js') ?>"></script>
    
    <style>
        /* Приветствие в начале текстового канала «общий» (как в примере) */
        .sp-welcome { padding: 28px 6px 18px; }
        .sp-welcome-ico {
            width: 68px; height: 68px; border-radius: 50%; margin-bottom: 14px;
            display: flex; align-items: center; justify-content: center;
            background: rgba(127,127,127,.18); color: var(--text-primary, #f2f3f5); font-size: 40px; font-weight: 600; line-height: 1;
        }
        .sp-welcome-title { margin: 0 0 8px; font-size: 32px; line-height: 1.15; font-weight: 800; color: var(--text-primary, #f2f3f5); }
        .sp-welcome-sub { margin: 0 0 14px; font-size: 14px; color: var(--text-secondary, #949ba4); }
        .sp-welcome-btn {
            display: inline-flex; align-items: center; gap: 8px; padding: 8px 14px; border: 0; border-radius: 8px; cursor: pointer;
            background: rgba(127,127,127,.2); color: var(--text-primary, #f2f3f5); font: inherit; font-size: 14px; font-weight: 600;
        }
        .sp-welcome-btn:hover { background: rgba(127,127,127,.32); }
        .sp-welcome-btn svg { width: 16px; height: 16px; }
        @media (max-width: 600px) { .sp-welcome-title { font-size: 24px; } }
    </style>
    <script>
    /* Приветствие в начале каждого текстового канала */
    (function () {
        var msgs = document.getElementById('spMessages'), bar = document.getElementById('spChanBar'), active = document.getElementById('spActive');
        if (!msgs || !bar || !active) return;
        var busy = false;

        function channelName() {
            var n = bar.querySelector('.sp-chan-name');
            return n ? n.textContent.trim() : '';
        }
        function build(name) {
            var box = document.createElement('div');
            box.className = 'sp-welcome';
            box.setAttribute('data-sp-welcome', '1');
            box.setAttribute('data-name', name);

            var ico = document.createElement('div'); ico.className = 'sp-welcome-ico'; ico.textContent = '#';
            var h = document.createElement('h2'); h.className = 'sp-welcome-title'; h.textContent = 'Добро пожаловать на канал # ' + name + '!';
            var p = document.createElement('p'); p.className = 'sp-welcome-sub'; p.textContent = 'Это начало канала # ' + name + '.';
            box.appendChild(ico); box.appendChild(h); box.appendChild(p);

            if (active.dataset.canManageChannels === 'true') {
                var btn = document.createElement('button');
                btn.type = 'button'; btn.className = 'sp-welcome-btn';
                btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg><span>Настроить канал</span>';
                btn.addEventListener('click', function () {
                    document.dispatchEvent(new CustomEvent('spaces:configure-current-channel'));
                });
                box.appendChild(btn);
            }
            return box;
        }
        function sync() {
            if (busy) return;
            busy = true;
            try {
                var existing = msgs.querySelector('[data-sp-welcome]');
                var name = channelName();
                if (!name) { if (existing) existing.remove(); return; }
                if (existing && existing === msgs.firstElementChild && existing.getAttribute('data-name') === name
                    && !!existing.querySelector('.sp-welcome-btn') === (active.dataset.canManageChannels === 'true')) return;
                if (existing) existing.remove();
                msgs.insertBefore(build(name), msgs.firstChild);   // spaces.js очищает ленту при смене канала — блок возвращается сам
            } finally { busy = false; }
        }
        new MutationObserver(sync).observe(msgs, { childList: true });
        new MutationObserver(sync).observe(bar, { childList: true, subtree: true, characterData: true });
        new MutationObserver(sync).observe(active, { attributes: true, attributeFilter: ['data-can-manage-channels'] });
        sync();
    })();
    </script>
    <script>
    /* Левая панель меню лежала поверх списка пространств: приложение (.spaces-app) растянуто на весь экран
       (position: fixed; left: 0). Находим панель, которая реально перекрывает левый край, и сдвигаем приложение правее неё. */
    (function () {
        var app = document.getElementById('spacesApp');
        if (!app) return;
        var GAP = 12, SKIP = /^(HTML|BODY|MAIN|SCRIPT|STYLE)$/;

        function findOverlay() {
            var ar = app.getBoundingClientRect();
            var y = Math.min(window.innerHeight - 10, Math.max(0, ar.top) + 160);
            var stack = document.elementsFromPoint(40, y);
            for (var i = 0; i < stack.length; i++) {
                var el = stack[i];
                if (el === app || app.contains(el)) return null;           // дошли до приложения — над ним ничего нет
                if (SKIP.test(el.tagName) || el.classList.contains('layout')) continue;
                // поднимаемся до всей панели (но не выше контейнера страницы)
                while (el.parentElement && !SKIP.test(el.parentElement.tagName) && !el.parentElement.classList.contains('layout') &&
                       el.parentElement.getBoundingClientRect().width <= window.innerWidth * 0.4) {
                    el = el.parentElement;
                }
                return el;
            }
            return null;
        }

        var pending = false;
        function fix() {
            pending = false;
            app.style.left = '';
            if (window.innerWidth <= 860) return;
            var nav = findOverlay();
            if (!nav) return;
            var r = nav.getBoundingClientRect();
            if (r.width < 60 || r.width > window.innerWidth * 0.4 || r.left > 120) return;
            app.style.left = Math.round(r.right + GAP) + 'px';
        }
        function schedule() { if (!pending) { pending = true; requestAnimationFrame(fix); } }

        window.addEventListener('load', schedule);
        window.addEventListener('resize', schedule);
        document.addEventListener('DOMContentLoaded', schedule);
        new MutationObserver(schedule).observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class', 'hidden', 'data-nav-pos', 'data-theme'] });
        setTimeout(schedule, 300);
        setTimeout(schedule, 1200);
    })();
    </script>
</body>
</html>
<?php
$conn->close();

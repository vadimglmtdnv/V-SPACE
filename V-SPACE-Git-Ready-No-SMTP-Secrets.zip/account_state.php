<?php

if (!function_exists('ensureAccountStateColumns')) {
    function ensureAccountStateColumns(mysqli $conn): void
    {
        $columns = [
            'deleted_at' => "ALTER TABLE users ADD COLUMN deleted_at DATETIME NULL DEFAULT NULL",
            'is_blocked' => "ALTER TABLE users ADD COLUMN is_blocked TINYINT(1) NOT NULL DEFAULT 0",
            // Хранит последнее известное приложению значение is_admin.
            // Нужно, чтобы поймать момент, когда права админа меняют напрямую в БД
            // (без прохождения через код) — сравнивая is_admin с was_admin при входе.
            'was_admin' => "ALTER TABLE users ADD COLUMN was_admin TINYINT(1) NULL DEFAULT NULL",
        ];

        foreach ($columns as $column => $alterSql) {
            $check = $conn->query("SHOW COLUMNS FROM users LIKE '" . $conn->real_escape_string($column) . "'");
            $columnExisted = $check && $check->num_rows > 0;
            if ($check) {
                $check->close();
            }

            if (!$columnExisted) {
                try {
                    $conn->query($alterSql);
                } catch (mysqli_sql_exception $e) {
                    // 1060 = "Duplicate column name": параллельный запрос успел создать колонку раньше нас.
                    if ((int)$e->getCode() !== 1060) {
                        throw $e;
                    }
                    $columnExisted = true; // заполнением займётся тот, кто создал колонку
                }
            }

            // Колонку только что создали — заполняем её текущим is_admin,
            // чтобы у уже существующих пользователей не сработал "ложный" сброс пароля
            // при первом же входе после обновления.
            if ($column === 'was_admin' && !$columnExisted) {
                $conn->query("UPDATE users SET was_admin = is_admin WHERE was_admin IS NULL");
            }
        }
    }
}

function generateRandomToken(int $length = 16): string
{
    if ($length < 8) {
        throw new \InvalidArgumentException('Length must be at least 8');
    }

    $alphabet = getenv('ENCRYPTION_SALT');
    $max = strlen($alphabet) - 1;
    $result = '';

    for ($i = 0; $i < $length; $i++) {
        $result .= $alphabet[random_int(0, $max)];
    }

    return $result;
}

if (!function_exists('generateRandomPassword')) {
    function generateRandomPassword(int $length = 12): string
    {
        return generateRandomToken($length);
    }
}

if (!function_exists('sendNewPasswordEmail')) {
    /**
     * Отправляет пользователю письмо с новым паролем через SMTP из mail_config.php.
     * Требует PHPMailer (composer require phpmailer/phpmailer). Если библиотеки нет —
     * пробует запасной вариант через встроенную mail(), которая на многих хостингах
     * не работает без настройки SMTP на уровне сервера.
     * Возвращает true, если письмо удалось отправить (или хотя бы поставить в очередь).
     */
    function sendNewPasswordEmail(string $toEmail, string $username, string $newPassword): bool
    {
        if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        // Подхватываем composer-автозагрузчик, если его ещё никто не подключил.
        if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer', false)) {
            $autoload = __DIR__ . '/vendor/autoload.php';
            if (is_file($autoload)) {
                require_once $autoload;
            }
        }

        $configPath = __DIR__ . '/mail_config.php';
        $config = is_file($configPath) ? require $configPath : [];
        $providerName = $config['default_provider'] ?? null;
        $provider = ($providerName !== null) ? ($config['providers'][$providerName] ?? null) : null;

        $subject = 'PLAYERCHAT — ваш пароль изменён';
        $body =
            "Здравствуйте, {$username}!\n\n" .
            "Права администратора на вашем аккаунте были изменены, поэтому в целях безопасности " .
            "пароль был сброшен.\n\n" .
            "Ваш новый пароль: {$newPassword}\n\n" .
            "Рекомендуем войти и сменить его на свой в настройках профиля.\n\n" .
            "Если это были не вы — немедленно обратитесь в поддержку.";

        if (
            is_array($provider)
            && !empty($provider['host'])
            && class_exists('PHPMailer\\PHPMailer\\PHPMailer')
        ) {
            try {
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = $provider['host'];
                $mail->SMTPAuth = true;
                $mail->Username = $provider['username'] ?? '';
                $mail->Password = $provider['password'] ?? '';
                $mail->SMTPSecure = $provider['encryption'] ?? 'tls';
                $mail->Port = (int)($provider['port'] ?? 587);
                $mail->CharSet = 'UTF-8';
                // Без таймаута зависший SMTP подвесит страницу входа на минуту и больше.
                $mail->Timeout = 10;
                $mail->SMTPKeepAlive = false;

                $mail->setFrom($provider['username'], 'PLAYERCHAT');
                $mail->addAddress($toEmail, $username);
                $mail->isHTML(false);
                $mail->Subject = $subject;
                $mail->Body = $body;

                return (bool)$mail->send();
            } catch (\Throwable $e) {
                error_log('sendNewPasswordEmail (PHPMailer) error: ' . $e->getMessage());
                return false;
            }
        }

        // Запасной вариант без PHPMailer — может не сработать без настроенного SMTP-relay на сервере.
        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "Content-Transfer-Encoding: 8bit\r\n";
        if (is_array($provider) && !empty($provider['username']) && filter_var($provider['username'], FILTER_VALIDATE_EMAIL)) {
            $headers .= 'From: PLAYERCHAT <' . $provider['username'] . ">\r\n";
        }
        return @mail($toEmail, $encodedSubject, $body, $headers);
    }
}

if (!function_exists('syncAdminPasswordReset')) {
    /**
     * Проверяет, изменилась ли роль администратора со времени последней проверки
     * (сравнивая is_admin с сохранённым was_admin), и если да — сбрасывает пароль:
     * генерирует новый, хеширует, сохраняет, инвалидирует токены "запомнить меня"
     * на всех устройствах и отправляет новый пароль на email.
     *
     * Гарантии:
     *  - если was_admin ещё пуст (NULL) — просто запоминаем текущее значение, сброса нет;
     *  - при параллельных входах сброс делает ровно один запрос (атомарный захват по was_admin);
     *  - если письмо не удалось отправить, старый пароль и was_admin возвращаются назад,
     *    чтобы пользователь не остался без доступа; попытка повторится при следующем входе.
     *
     * Вызывать сразу после успешной проверки пароля при входе.
     * Возвращает true, если пароль был сброшен и письмо отправлено.
     */
    function syncAdminPasswordReset(mysqli $conn, array $user): bool
    {
        $userId = (int)$user['id'];
        $isAdminNow = (int)($user['is_admin'] ?? 0) === 1 ? 1 : 0;

        // Первый раз видим пользователя — просто запоминаем состояние.
        if (!array_key_exists('was_admin', $user) || $user['was_admin'] === null) {
            $stmt = $conn->prepare("UPDATE users SET was_admin = ? WHERE id = ? AND was_admin IS NULL");
            $stmt->bind_param("ii", $isAdminNow, $userId);
            $stmt->execute();
            $stmt->close();
            return false;
        }

        $wasAdminBefore = (int)$user['was_admin'] === 1 ? 1 : 0;
        if ($isAdminNow === $wasAdminBefore) {
            return false;
        }

        // Запоминаем старый хеш, чтобы вернуть его, если письмо не уйдёт.
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) {
            return false;
        }
        $oldHash = (string)$row['password'];

        $newPassword = generateRandomPassword(12);
        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);

        // Атомарный захват: условие was_admin = старое значение выполнится только у одного из
        // параллельных запросов, остальные увидят affected_rows = 0 и ничего не сделают.
        $stmt = $conn->prepare("
            UPDATE users
            SET password = ?, was_admin = ?, remember_token = NULL, token_expires = NULL
            WHERE id = ? AND was_admin = ?
        ");
        $stmt->bind_param("siii", $newHash, $isAdminNow, $userId, $wasAdminBefore);
        $stmt->execute();
        $claimed = $stmt->affected_rows === 1;
        $stmt->close();

        if (!$claimed) {
            return false;
        }

        $email = (string)($user['email'] ?? '');
        $username = (string)($user['username'] ?? '');

        if (sendNewPasswordEmail($email, $username, $newPassword)) {
            return true;
        }

        // Письмо не ушло — откатываем пароль и was_admin, иначе человек потеряет доступ к аккаунту.
        // remember_token остаётся сброшенным: это безопасно (потребуется обычный вход).
        error_log("syncAdminPasswordReset: email not sent for user {$userId}, password reset rolled back");
        $stmt = $conn->prepare("UPDATE users SET password = ?, was_admin = ? WHERE id = ? AND password = ?");
        $stmt->bind_param("siis", $oldHash, $wasAdminBefore, $userId, $newHash);
        $stmt->execute();
        $stmt->close();

        return false;
    }
}

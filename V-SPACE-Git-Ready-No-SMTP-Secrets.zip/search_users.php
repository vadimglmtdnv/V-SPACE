<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION["user_id"])) {
    echo json_encode([]);
    exit;
}

$user_id = (int)$_SESSION["user_id"];
$q = trim($_GET['q'] ?? '');

if ($q === '' || mb_strlen($q) < 2 || mb_strlen($q) > 50) {
    echo json_encode([]);
    exit;
}

$conn = @db_connect();

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([]);
    exit;
}

$conn->set_charset("utf8mb4");

$search_like = '%' . $q . '%';
$stmt = $conn->prepare("
    SELECT id, username, avatar, status
    FROM users 
    WHERE id != ? AND username LIKE ?
    ORDER BY username ASC
    LIMIT 10
");
$stmt->bind_param("is", $user_id, $search_like);
$stmt->execute();
$result = $stmt->get_result();

$users = [];
while ($row = $result->fetch_assoc()) {
    $avatar = $row['avatar'] ?? '';
    $avatar_exists = !empty($avatar) && file_exists($avatar);

    $users[] = [
        'id'       => (int)$row['id'],
        'username' => $row['username'],
        'avatar'   => $avatar_exists ? $avatar : '',
        'letter'   => mb_strtoupper(mb_substr($row['username'], 0, 1, 'UTF-8')),
        'online'   => $row['status'] === 'online'
    ];
}

$stmt->close();
$conn->close();

echo json_encode($users, JSON_UNESCAPED_UNICODE);
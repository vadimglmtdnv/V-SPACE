<?php

require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');

function respond(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (empty($_SESSION['user_id'])) {
    respond(['logged' => false]);
}

$userId = (int)$_SESSION['user_id'];

// Сессия дальше не меняется — освобождаем её, чтобы запрос не блокировал другие вкладки
session_write_close();

try {
    // Если на сервере есть config.php с $pdo — используем его,
    // иначе подключаемся к той же базе, что и остальные страницы (index.php, reports.php).
    $configFile = __DIR__ . '/config.php';
    if (is_file($configFile)) {
        require_once $configFile;
    }

    if (!isset($pdo) || !($pdo instanceof PDO)) {
        require_once __DIR__ . '/includes/env.php';
        $dbHost = (string)env('DB_HOST', DB_HOST);
        $dbName = (string)env('DB_NAME', DB_NAME);
        $dbUser = (string)env('DB_USER', DB_USER);
        $dbPass = (string)env('DB_PASS', DB_PASS);
        $pdo = new PDO(
            'mysql:host=' . $dbHost . ';dbname=' . $dbName . ';charset=utf8mb4',
            $dbUser,
            $dbPass,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
    }

    $stmt = $pdo->prepare('
        SELECT id, username, email, avatar
        FROM users
        WHERE id = ?
        LIMIT 1
    ');
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('user.php: ' . $e->getMessage());
    respond(['logged' => false, 'error' => 'server_error'], 500);
}

if (!$user) {
    // Пользователь удалён — завершаем сессию (её нужно снова открыть для записи)
    require_once __DIR__ . '/includes/helpers.php';
    start_secure_session();
    session_unset();
    session_destroy();

    respond(['logged' => false]);
}

respond([
    'logged'   => true,
    'id'       => (int)$user['id'],
    'username' => (string)$user['username'],
    'email'    => (string)$user['email'],
    'avatar'   => $user['avatar'] !== null ? (string)$user['avatar'] : null,
]);

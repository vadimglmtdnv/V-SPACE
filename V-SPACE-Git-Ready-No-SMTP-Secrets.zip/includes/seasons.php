<?php
// includes/seasons.php — 4 сезона по 3 месяца + праздники.
//
// Сезоны:  зима (дек–фев), весна (мар–май), лето (июн–авг), осень (сен–ноя).
// Праздники (имеют приоритет над сезоном, действуют в своём окне дат):
//   • Новый год        — 20 декабря – 10 января
//   • 8 Марта          — 8 – 9 марта
//   • День труда (1 мая) — 1 – 3 мая
//   • День знаний (1 сентября) — 28 августа – 3 сентября
//   • Хэллоуин         — 24 октября – 1 ноября
//
// Проверка без ожидания даты: любая страница с ?season_preview=halloween
// (winter, spring, summer, autumn, newyear, march8, mayday, knowledge, halloween).

function seasonDefinitions(): array
{
    return [
        'seasons' => [
            'winter' => ['title' => 'Зима',  'months' => [12, 1, 2]],
            'spring' => ['title' => 'Весна', 'months' => [3, 4, 5]],
            'summer' => ['title' => 'Лето',  'months' => [6, 7, 8]],
            'autumn' => ['title' => 'Осень', 'months' => [9, 10, 11]],
        ],
        // ключ => [название, поздравление, начало (мес, день), конец (мес, день), сезон]
        'holidays' => [
            'newyear'   => ['Новый год',      'С Новым годом! 🎄',            [12, 20], [1, 10], 'winter'],
            'march8'    => ['8 Марта',        'С 8 Марта! 🌷',                [3, 8],   [3, 9],  'spring'],
            'mayday'    => ['День труда',     'С 1 Мая — Днём труда! 🌿',     [5, 1],   [5, 3],  'spring'],
            'knowledge' => ['День знаний',    'С Днём знаний! 📚',            [8, 28],  [9, 3],  'autumn'],
            'halloween' => ['Хэллоуин',       'Счастливого Хэллоуина! 🎃',    [10, 24], [11, 1], 'autumn'],
        ],
    ];
}

/**
 * Текущий сезон и (если есть) праздник.
 * @return array{season:string, season_title:string, holiday:string, holiday_title:string, greeting:string, theme:string}
 */
function seasonInfo(?int $ts = null): array
{
    $defs = seasonDefinitions();
    $ts   = $ts ?? time();
    $m    = (int)date('n', $ts);
    $d    = (int)date('j', $ts);

    $season = 'summer';
    foreach ($defs['seasons'] as $key => $s) {
        if (in_array($m, $s['months'], true)) {
            $season = $key;
            break;
        }
    }

    $holiday = '';
    $md = $m * 100 + $d;
    foreach ($defs['holidays'] as $key => $h) {
        $start = $h[2][0] * 100 + $h[2][1];
        $end   = $h[3][0] * 100 + $h[3][1];
        $in = $start <= $end ? ($md >= $start && $md <= $end) : ($md >= $start || $md <= $end);
        if ($in) {
            $holiday = $key;
            break;
        }
    }

    // Предпросмотр (?season_preview=...): только из белого списка
    $preview = isset($_GET['season_preview']) && is_string($_GET['season_preview']) ? $_GET['season_preview'] : '';
    if ($preview !== '') {
        if (isset($defs['seasons'][$preview])) {
            $season = $preview;
            $holiday = '';
        } elseif (isset($defs['holidays'][$preview])) {
            $holiday = $preview;
            $season = $defs['holidays'][$preview][4];
        }
    }

    return [
        'season'        => $season,
        'season_title'  => $defs['seasons'][$season]['title'],
        'holiday'       => $holiday,
        'holiday_title' => $holiday !== '' ? $defs['holidays'][$holiday][0] : '',
        'greeting'      => $holiday !== '' ? $defs['holidays'][$holiday][1] : '',
        'theme'         => $holiday !== '' ? $holiday : $season,   // что рисуем: праздник важнее сезона
    ];
}

// Атрибуты для тега body: вызывать как seasonBodyAttrs() внутри <body ...>
function seasonBodyAttrs(): string
{
    $i = seasonInfo();
    $e = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    return ' data-season="' . $e($i['season']) . '"'
        . ' data-season-theme="' . $e($i['theme']) . '"'
        . ' data-holiday="' . $e($i['holiday']) . '"'
        . ' data-holiday-title="' . $e($i['holiday_title']) . '"'
        . ' data-holiday-greeting="' . $e($i['greeting']) . '"';
}

// Подключение стилей и скрипта: вставить в <head>
function seasonHead(): string
{
    $root = dirname(__DIR__);
    $cssV = (int)@filemtime($root . '/assets/css/seasons.css');
    $jsV  = (int)@filemtime($root . '/assets/js/seasons.js');
    return '<link rel="stylesheet" href="assets/css/seasons.css?v=' . $cssV . '">' . "\n"
        . '<script src="assets/js/seasons.js?v=' . $jsV . '" defer></script>' . "\n";
}

<?php
/**
 * userTag() — красивый «тег» пользователя вида #username.
 * Берёт ник (handle), если он задан, иначе делает ник из имени пользователя
 * (кириллица -> латиница: «вадим ги» -> #vadim_gi); номер аккаунта нужен только как последний запасной вариант.
 */
if (!function_exists('userTag')) {
    function userTag($handle = '', $username = '', $id = 0): string
    {
        $handle = trim((string)$handle);
        if ($handle === '') {
            static $map = [
            'а' => 'a',
            'б' => 'b',
            'в' => 'v',
            'г' => 'g',
            'д' => 'd',
            'е' => 'e',
            'ё' => 'e',
            'ж' => 'zh',
            'з' => 'z',
            'и' => 'i',
            'й' => 'y',
            'к' => 'k',
            'л' => 'l',
            'м' => 'm',
            'н' => 'n',
            'о' => 'o',
            'п' => 'p',
            'р' => 'r',
            'с' => 's',
            'т' => 't',
            'у' => 'u',
            'ф' => 'f',
            'х' => 'kh',
            'ц' => 'ts',
            'ч' => 'ch',
            'ш' => 'sh',
            'щ' => 'sch',
            'ъ' => '',
            'ы' => 'y',
            'ь' => '',
            'э' => 'e',
            'ю' => 'yu',
            'я' => 'ya',
            'і' => 'i',
            'ї' => 'yi',
            'є' => 'ye',
            'ґ' => 'g'
            ];
            $name = strtr(mb_strtolower(trim((string)$username), 'UTF-8'), $map);
            $handle = trim((string)preg_replace('/[^a-z0-9]+/', '_', $name), '_');
            if ($handle !== '' && !preg_match('/^[a-z]/', $handle)) {
                $handle = 'user_' . $handle;
            }
            $handle = trim(substr($handle, 0, 24), '_');
        }
        if ($handle === '') {
            $handle = 'id' . (int)$id;
        }
        return '#' . ltrim($handle, '#@');
    }
}

/**
 * Тег по номеру аккаунта: ник (users.handle) или настоящий users.username.
 * Имя из профиля (user_profiles.first_name / last_name) сюда НЕ попадает.
 */
if (!function_exists('userTagById')) {
    function userTagById($conn, int $uid): string
    {
        static $cache = [];
        if ($uid <= 0) return '';
        if (isset($cache[$uid])) return $cache[$uid];
        $row = null;
        if ($conn instanceof mysqli) {
            foreach (['SELECT username, handle FROM users WHERE id = ? LIMIT 1',
                      'SELECT username FROM users WHERE id = ? LIMIT 1'] as $sql) {   // второй — если колонки handle ещё нет
                try {
                    $stmt = $conn->prepare($sql);
                    if (!$stmt) continue;
                    $stmt->bind_param('i', $uid);
                    $stmt->execute();
                    $row = $stmt->get_result()->fetch_assoc();
                    $stmt->close();
                    break;
                } catch (Throwable $e) {
                    $row = null;
                }
            }
        }
        return $cache[$uid] = userTag($row['handle'] ?? '', $row['username'] ?? '', $uid);
    }
}

if (!function_exists('currentUserTag')) {
    function currentUserTag(): string
    {
        global $conn;
        return userTagById($conn ?? null, (int)($_SESSION['user_id'] ?? 0));
    }
}

/**
 * Статичный номер аккаунта для поддержки: #00002 (номер аккаунта с ведущими нулями).
 * Не меняется при смене ника или имени.
 */
if (!function_exists('userStaticId')) {
    function userStaticId(int $id, int $width = 5): string
    {
        return '#' . str_pad((string)max(0, $id), $width, '0', STR_PAD_LEFT);
    }
}

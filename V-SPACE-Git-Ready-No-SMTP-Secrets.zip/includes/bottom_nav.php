<?php
/**
 * Общая нижняя панель навигации (ручка + меню).
 * Подключается на всех страницах одной строкой:
 *     <?php include __DIR__ . '/includes/bottom_nav.php'; ?>
 *
 * Активный пункт определяется автоматически по имени текущего файла.
 * Бейдж непрочитанных берётся из $unread_count, если переменная задана на странице.
 */
$__bn_current = basename($_SERVER['PHP_SELF'] ?? '');
$__bn_active  = function (string $file) use ($__bn_current): string {
    return $__bn_current === $file ? ' active' : '';
};

// Язык интерфейса (ru/en) и словарь подписей — в includes/lang.php (общий с шапкой).
require_once __DIR__ . '/lang.php';
$__bn_e = function (string $key): string {
    return ui_e('nav_' . $key);
};

// Положение и закрепление панели — настройки из settings.php (cookie/сессия nav_pos и nav_pin).
// Читаем здесь, чтобы панель выглядела одинаково на всех страницах, где она подключена.
$__bn_pos = $_COOKIE['nav_pos'] ?? ($_SESSION['nav_pos'] ?? 'bottom');
$__bn_pos = in_array($__bn_pos, ['bottom', 'top', 'left'], true) ? $__bn_pos : 'bottom';
$__bn_pin = (($_COOKIE['nav_pin'] ?? ($_SESSION['nav_pin'] ?? '0')) === '1') ? '1' : '0';
$__bn_pin_user = $__bn_pin;   // закрепление, выбранное пользователем (на телефоне «слева» не действует)
if ($__bn_pos === 'left') { $__bn_pin = '1'; }   // слева панель всегда закреплена
$__bn_presence_csrf = $_SESSION['csrf_token'] ?? '';
if ($__bn_presence_csrf === '') {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $__bn_presence_csrf = $_SESSION['csrf_token'];
}
?>
<link rel="stylesheet" href="assets/css/nav-position.css">
<link rel="stylesheet" href="assets/css/nav-bubble.css">
<link rel="stylesheet" href="assets/css/nav-mobile.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/nav-mobile.css') ?>-<?= (int)@filesize(__DIR__ . '/../assets/css/nav-mobile.css') ?>">
<script>
/* Положение/закрепление панели берутся из настроек и действуют на всех страницах */
var __phone = window.matchMedia && window.matchMedia('(max-width: 640px)').matches;
document.body.setAttribute('data-nav-pos', __phone ? 'bottom' : '<?= $__bn_pos ?>');
document.body.setAttribute('data-nav-pin', __phone ? '<?= $__bn_pin_user ?>' : '<?= $__bn_pin ?>');
</script>
<script>
/* Настройки вида/цвета панели отдельно для телефона и ПК ставим до отрисовки, чтобы не мигала.
   Остальное (какие пункты показывать, порядок) применяет assets/js/nav-mobile.js. */
(function () {
    try {
        var phone = window.matchMedia('(max-width: 640px)');
        var key = phone.matches ? 'nav_mobile_v1' : 'nav_desktop_v1';
        var raw = localStorage.getItem(key);
        if (raw === null && !phone.matches) {
            raw = localStorage.getItem('nav_mobile_v1');
            if (raw !== null) localStorage.setItem(key, raw);
        }
        var c = JSON.parse(raw || 'null') || {}, r = document.documentElement;
        var st = ['dock', 'labels', 'compact'].indexOf(c.style) !== -1 ? c.style : (phone.matches ? 'dock' : 'labels');
        r.setAttribute('data-nm-style', st);
        if (c.accent === 'custom' && /^#[0-9a-f]{6}$/i.test(c.custom || '')) {
            // свой цвет из палитры: переменные из nav-mobile.css перекрываем на <html>
            var n = parseInt(c.custom.slice(1), 16), l = '#';
            [n >> 16 & 255, n >> 8 & 255, n & 255].forEach(function (v) { l += ('0' + Math.round(v + (255 - v) * 0.35).toString(16)).slice(-2); });
            r.setAttribute('data-nm-accent', 'custom');
            r.style.setProperty('--nm-accent', c.custom);
            r.style.setProperty('--nm-accent-2', l);
        } else if (['red', 'blue', 'violet', 'green', 'gold', 'site'].indexOf(c.accent) !== -1) r.setAttribute('data-nm-accent', c.accent);
        if (!phone.matches && c.autohide === true) r.setAttribute('data-nm-hide', '1');
        document.body.setAttribute('data-nav-pin', phone.matches ? '1' : '<?= $__bn_pin ?>');
    } catch (e) {}
})();
</script>
<div class="bottom-handle" id="handleBtn">
    <div class="handle-bar"></div>
</div>

<app-navigation class="bottom-nav navigation-transparent ng-star-inserted navigation-docked" id="site-navigator" data-managed-by-partial="true" style="--navigation-scroll-offset: 74px;">
    <a href="<?= !empty($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 'index.php' ?>" class="nav-item<?= $__bn_active('index.php') ?>">
        <span class="menu-icon"><img src="images/profile.svg" alt="<?= $__bn_e('profile') ?>"></span>
        <span class="nav-label"><?= $__bn_e('profile') ?></span>
    </a>
    <a href="news.php" class="nav-item<?= $__bn_active('news.php') ?>">
        <span class="menu-icon"><img src="images/news.svg" alt="<?= $__bn_e('news') ?>"></span>
        <span class="nav-label"><?= $__bn_e('news') ?></span>
    </a>
    <a href="messages.php" class="nav-item<?= $__bn_active('messages.php') ?>">
        <span class="menu-icon"><img src="images/nav-messages.svg" alt="<?= $__bn_e('messages') ?>"></span>
        <span class="nav-label"><?= $__bn_e('messages') ?></span>
        <?php if (isset($unread_count) && $unread_count > 0): ?>
            <span class="notification-badge"><?= $unread_count > 99 ? '99+' : (int)$unread_count ?></span>
        <?php endif; ?>
    </a>
    <a href="friends.php" class="nav-item<?= $__bn_active('friends.php') ?>">
        <span class="menu-icon"><img src="images/nav-friends.svg" alt="<?= $__bn_e('friends') ?>"></span>
        <span class="nav-label"><?= $__bn_e('friends') ?></span>
    </a>
    <a href="spaces.php" class="nav-item<?= $__bn_active('spaces.php') ?>">
        <span class="menu-icon"><img src="images/nav-spaces.svg" alt="<?= $__bn_e('spaces') ?>"></span>
        <span class="nav-label"><?= $__bn_e('spaces') ?></span>
    </a>
    <a href="photos.php" class="nav-item<?= $__bn_active('photos.php') ?>">
        <span class="menu-icon"><img src="images/nav-photo.svg" alt="<?= $__bn_e('photos') ?>"></span>
        <span class="nav-label"><?= $__bn_e('photos') ?></span>
    </a>
    <a href="music.php" class="nav-item<?= $__bn_active('music.php') ?>">
        <span class="menu-icon"><img src="images/nav-music.svg" alt="<?= $__bn_e('music') ?>"></span>
        <span class="nav-label"><?= $__bn_e('music') ?></span>
    </a>
    <a href="video.php" class="nav-item<?= $__bn_active('video.php') ?>">
        <span class="menu-icon"><img src="images/nav-video.svg" alt="<?= $__bn_e('video') ?>"></span>
        <span class="nav-label"><?= $__bn_e('video') ?></span>
    </a>
    <a href="favorite.php" class="nav-item<?= $__bn_active('favorite.php') ?>">
        <span class="menu-icon"><img src="images/nav-favorite.svg" alt="<?= $__bn_e('favorites') ?>"></span>
        <span class="nav-label"><?= $__bn_e('favorites') ?></span>
    </a>

    <div class="nav-divider"></div>

    <a href="support.php" class="nav-item<?= $__bn_active('support.php') ?>">
        <span class="menu-icon"><img src="images/nav-support.svg" alt="<?= $__bn_e('support') ?>"></span>
        <span class="nav-label"><?= $__bn_e('support') ?></span>
    </a>
    <a href="about.php" class="nav-item<?= $__bn_active('about.php') ?>">
        <span class="menu-icon"><img src="images/nav-about.svg" alt="<?= $__bn_e('about') ?>"></span>
        <span class="nav-label"><?= $__bn_e('about') ?></span>
    </a>
    <a href="developers.php" class="nav-item<?= $__bn_active('developers.php') ?>">
        <span class="menu-icon"><svg class="nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m8 7-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/></svg></span>
        <span class="nav-label"><?= $__bn_e('developers') ?></span>
    </a>
    <a href="menu.php" class="nav-item nav-menu-item<?= $__bn_active('menu.php') ?>" aria-label="<?= ui_e('nav_menu') ?>">
        <span class="menu-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true" focusable="false"><path d="M4 6h16M4 12h16M4 18h16"/></svg></span>
    </a>
    <div class="bottom-utility-controls" id="bottomUtilityControls" aria-label="Быстрые меню"></div>
</app-navigation>
<div class="top-corner-controls" id="topCornerControls" aria-label="<?= ui_e('notifications') ?>"<?= basename($_SERVER['SCRIPT_NAME'] ?? '') === 'news.php' ? ' data-bell-page="1"' : '' ?>></div>

<script>
/* Нижняя панель с ручкой — единое поведение для всех страниц.
   Телефон (до 640px): панель всегда на виду, ручки нет (см. assets/css/nav-mobile.css).
   Сенсорные экраны без мыши: «наведение» не используем — иначе касание по ручке сначала
   показывало панель (эмулированный mouseenter), а следующий click тут же прятал её. */
(function () {
    var handle = document.getElementById('handleBtn');
    var nav = document.getElementById('site-navigator');
    if (!handle || !nav) return;

    var touchOnly = window.matchMedia('(hover: none)').matches;
    var phone = window.matchMedia('(max-width: 640px)');
    function pinned() { return document.body.getAttribute('data-nav-pin') === '1'; }
    function syncPhonePin() {
        document.body.setAttribute('data-nav-pin', phone.matches ? '1' : '<?= $__bn_pin ?>');
    }

    function show() { nav.classList.remove('nav-hidden'); handle.classList.add('handle-hidden'); }
    function hide() { nav.classList.add('nav-hidden'); handle.classList.remove('handle-hidden'); }

    syncPhonePin();
    if (phone.matches) show(); else hide();

    handle.addEventListener('click', function (e) {
        e.stopPropagation();
        nav.classList.contains('nav-hidden') ? show() : hide();
    });

    if (!touchOnly) {
        handle.addEventListener('mouseenter', show);
        nav.addEventListener('mouseenter', show);
        nav.addEventListener('mouseleave', function () {
            if (!handle.matches(':hover')) hide();
        });
    } else {
        // Планшет / телефон в альбомной ориентации: тап мимо панели прячет её обратно
        document.addEventListener('click', function (e) {
            if (phone.matches || pinned()) return;
            if (nav.contains(e.target) || handle.contains(e.target)) return;
            if (!nav.classList.contains('nav-hidden')) hide();
        });
    }

    function onPhoneChange() {
        syncPhonePin();
        if (phone.matches) show();
        else if (!pinned()) hide();
    }
    if (phone.addEventListener) phone.addEventListener('change', onPhoneChange);
    else if (phone.addListener) phone.addListener(onPhoneChange);
})();
</script>
<script src="assets/js/nav-position.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/nav-position.js') ?>-<?= (int)@filesize(__DIR__ . '/../assets/js/nav-position.js') ?>" defer></script>
<script src="assets/js/nav-bubble.js" defer></script>
<script src="assets/js/call-shell-guard.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/call-shell-guard.js') ?>"></script>
<!-- входящие звонки на любой странице: в приложении сразу к звонку, в браузере — плашка «Принять / Отклонить» -->
<script src="assets/js/call-watch.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/call-watch.js') ?>" data-csrf="<?= htmlspecialchars($__bn_presence_csrf, ENT_QUOTES, 'UTF-8') ?>" defer></script>
<link rel="stylesheet" href="assets/css/nice-select.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/nice-select.css') ?>">
<script src="assets/js/nice-select.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/nice-select.js') ?>" defer></script>
<link rel="stylesheet" href="assets/css/notif-enhance.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/notif-enhance.css') ?>">
<script src="assets/js/notif-hover-read.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/notif-hover-read.js') ?>" defer></script>
<script src="assets/js/bell-redirect.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/bell-redirect.js') ?>"></script>
<script src="assets/js/nav-mobile.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/nav-mobile.js') ?>-<?= (int)@filesize(__DIR__ . '/../assets/js/nav-mobile.js') ?>" defer></script>
<script src="assets/js/header-bottom-controls.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/header-bottom-controls.js') ?>-<?= (int)@filesize(__DIR__ . '/../assets/js/header-bottom-controls.js') ?>" defer></script>
<script src="assets/js/user-presence.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/user-presence.js') ?>" data-presence-csrf="<?= htmlspecialchars($__bn_presence_csrf, ENT_QUOTES, 'UTF-8') ?>" defer></script>
<script src="assets/js/mobile-friends-position.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/mobile-friends-position.js') ?>" defer></script>

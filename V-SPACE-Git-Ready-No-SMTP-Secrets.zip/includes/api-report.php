<?php
require_once __DIR__ . '/helpers.php';
start_secure_session();
header('Content-Type: application/json');

// Файл может лежать в корне сайта или в api/
require_once (is_file(__DIR__ . '/includes/db.php') ? __DIR__ : dirname(__DIR__)) . '/includes/db.php';

if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => false, 'error' => 'Не авторизован']);
    exit;
}

$user_id = (int)$_SESSION["user_id"];

try {
    $conn = db_connect();
} catch (Throwable $e) {
    error_log('api-report.php DB connect error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Ошибка подключения к БД']);
    exit;
}
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Ошибка подключения к БД']);
    exit;
}

$conn->set_charset("utf8mb4");

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'error' => 'Нет данных']);
    exit;
}

$message_id = isset($data['messageId']) ? (int)$data['messageId'] : 0;
$reason = isset($data['reason']) ? trim((string)$data['reason']) : '';
$comment = isset($data['comment']) ? trim((string)$data['comment']) : '';

if ($message_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Неверный ID сообщения']);
    exit;
}

// Получаем ID автора сообщения
$stmt = $conn->prepare("SELECT sender_id FROM messages WHERE id = ?");
$stmt->bind_param("i", $message_id);
$stmt->execute();
$result = $stmt->get_result();
$msg = $result->fetch_assoc();
$stmt->close();

if (!$msg) {
    echo json_encode(['success' => false, 'error' => 'Сообщение не найдено']);
    exit;
}

$reported_user_id = $msg['sender_id'];

// Проверяем, не отправлял ли уже жалобу на это сообщение
$stmt = $conn->prepare("SELECT id FROM reports WHERE message_id = ? AND reporter_id = ?");
$stmt->bind_param("ii", $message_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$exists = $result->fetch_assoc();
$stmt->close();

if ($exists) {
    echo json_encode(['success' => false, 'error' => 'Вы уже пожаловались на это сообщение']);
    exit;
}

// Сохраняем жалобу
$stmt = $conn->prepare("INSERT INTO reports (message_id, reporter_id, reported_user_id, reason, comment, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
$stmt->bind_param("iiiss", $message_id, $user_id, $reported_user_id, $reason, $comment);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'report_id' => $conn->insert_id]);
} else {
    echo json_encode(['success' => false, 'error' => 'Ошибка сохранения жалобы: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>
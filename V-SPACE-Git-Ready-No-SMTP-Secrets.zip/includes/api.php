<?php
/**
 * Жалоба на сообщение.
 * POST JSON: { messageId: int, reason?: string, comment?: string }
 * Ответ всегда JSON: { success: bool, ... }
 */

require_once __DIR__ . '/helpers.php';
start_secure_session();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

// Файл может лежать в корне сайта или в api/
require_once (is_file(__DIR__ . '/includes/db.php') ? __DIR__ : dirname(__DIR__)) . '/includes/db.php';

function respond(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    respond(['success' => false, 'error' => 'Метод не поддерживается'], 405);
}

if (!isset($_SESSION['user_id'])) {
    respond(['success' => false, 'error' => 'Не авторизован']);
}

$user_id = (int)$_SESSION['user_id'];

// Сессия дальше не нужна — освобождаем её, чтобы запросы одного пользователя
// (поллинг чата и т.п.) не выстраивались в очередь на блокировке session-файла.
session_write_close();

$data = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($data)) {
    respond(['success' => false, 'error' => 'Нет данных']);
}

$message_id = isset($data['messageId']) ? (int)$data['messageId'] : 0;
$reason     = mb_substr(trim((string)($data['reason'] ?? '')), 0, 100, 'UTF-8');
$comment    = mb_substr(trim((string)($data['comment'] ?? '')), 0, 1000, 'UTF-8');

if ($message_id <= 0) {
    respond(['success' => false, 'error' => 'Неверный ID сообщения']);
}

// Ошибки mysqli -> исключения, чтобы не получить HTML-fatal вместо JSON.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$conn = null;

try {
    $conn = db_connect(true);

    // Автор сообщения
    $stmt = $conn->prepare('SELECT sender_id FROM messages WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $message_id);
    $stmt->execute();
    $msg = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$msg) {
        respond(['success' => false, 'error' => 'Сообщение не найдено']);
    }

    $reported_user_id = (int)$msg['sender_id'];

    if ($reported_user_id === $user_id) {
        respond(['success' => false, 'error' => 'Нельзя пожаловаться на своё сообщение']);
    }

    // Уже жаловался?
    $stmt = $conn->prepare('SELECT id FROM reports WHERE message_id = ? AND reporter_id = ? LIMIT 1');
    $stmt->bind_param('ii', $message_id, $user_id);
    $stmt->execute();
    $exists = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($exists) {
        respond(['success' => false, 'error' => 'Вы уже пожаловались на это сообщение']);
    }

    // Сохраняем жалобу
    $stmt = $conn->prepare(
        "INSERT INTO reports (message_id, reporter_id, reported_user_id, reason, comment, status, created_at)
         VALUES (?, ?, ?, ?, ?, 'pending', NOW())"
    );
    $stmt->bind_param('iiiss', $message_id, $user_id, $reported_user_id, $reason, $comment);

    try {
        $stmt->execute();
    } catch (mysqli_sql_exception $e) {
        // 1062 = дубликат (двойной клик / гонка двух запросов при наличии UNIQUE-индекса)
        if ((int)$e->getCode() === 1062) {
            respond(['success' => false, 'error' => 'Вы уже пожаловались на это сообщение']);
        }
        throw $e;
    }

    $reportId = (int)$conn->insert_id;
    $stmt->close();

    respond(['success' => true, 'report_id' => $reportId]);
} catch (Throwable $e) {
    // Детали — только в лог, клиенту не отдаём.
    error_log('api.php report error: ' . $e->getMessage());
    respond(['success' => false, 'error' => 'Внутренняя ошибка сервера. Попробуйте позже.'], 500);
} finally {
    if ($conn instanceof mysqli) {
        @$conn->close();
    }
}

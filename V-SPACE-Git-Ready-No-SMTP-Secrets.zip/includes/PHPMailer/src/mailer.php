<?php
/**
 * Отправка писем через PHPMailer. Настройки берутся из config/mail.php.
 *
 * Использование:
 *   require_once __DIR__ . '/includes/mailer.php';
 *   send_mail('user@example.com', 'Тема', '<b>Привет!</b>');
 */

use PHPMailer\PHPMailer\PHPMailer;

// PHPMailer: сначала Composer (vendor/), если его нет — вручную
// положенная папка includes/PHPMailer/src.
if (!class_exists(PHPMailer::class)) {
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';
    $manual   = __DIR__ . '/PHPMailer/src';

    if (is_file($autoload)) {
        require_once $autoload;
    } elseif (is_file($manual . '/PHPMailer.php')) {
        require_once $manual . '/Exception.php';
        require_once $manual . '/PHPMailer.php';
        require_once $manual . '/SMTP.php';
    } else {
        throw new RuntimeException('PHPMailer не найден: ни vendor/autoload.php, ни includes/PHPMailer/src.');
    }
}

function mail_config(): array
{
    static $config = null;
    if ($config === null) {
        $file = dirname(__DIR__) . '/config/mail.php';
        if (!is_file($file)) {
            throw new RuntimeException('Нет config/mail.php — скопируйте config/mail.example.php и заполните.');
        }
        $config = require $file;
    }
    return $config;
}

function send_mail(string $to, string $subject, string $htmlBody, string $altBody = '', string $toName = ''): bool
{
    try {
        $cfg = mail_config();

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = $cfg['host'];
        $mail->Port       = (int)$cfg['port'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $cfg['username'];
        $mail->Password   = $cfg['password'];
        $mail->SMTPSecure = ($cfg['encryption'] ?? 'tls') === 'ssl'
            ? PHPMailer::ENCRYPTION_SMTPS
            : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPDebug  = (int)($cfg['debug'] ?? 0);
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom($cfg['from_email'], $cfg['from_name'] ?? '');
        $mail->addAddress($to, $toName);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        $mail->AltBody = $altBody !== '' ? $altBody : strip_tags($htmlBody);

        $mail->send();
        return true;
    } catch (Throwable $e) {
        // Пишем в error.txt (если подключён логгер), пароль в лог не попадает
        if (function_exists('site_log_error')) {
            site_log_error('MAIL', $e->getMessage(), $e->getFile(), $e->getLine());
        } else {
            error_log('MAIL: ' . $e->getMessage());
        }
        return false;
    }
}

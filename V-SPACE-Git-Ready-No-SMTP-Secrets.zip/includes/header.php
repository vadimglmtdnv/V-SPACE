<?php
/**
 * Шапка сайта (логотип, уведомления, меню аватара).
 * Ожидает переменные: $username, $avatar, $avatarLetter, $avatar_ok,
 * $theme, $notifications, $notif_count
 */
$theme_names = ['dark' => 'Тёмная', 'light' => 'Светлая', 'system' => 'Системная'];
?>
<header class="header">
    <div class="header-left">
        <div class="logo">
            <div class="logo-icon">
                <img src="images/logo_type.svg" alt="SPACE Logo" width="40" height="40">
            </div>
        </div>
    </div>
    <div class="search-box"></div>
    <div class="header-right">

        <div class="notifications-wrapper">
            <button class="notifications-btn" id="notificationsBtn" aria-label="Уведомления">
                <?php include __DIR__ . '/notification_bell.php'; ?>
                <?php if ($notif_count > 0): ?>
                    <span class="notifications-badge" id="notificationsBadge"><?= $notif_count > 99 ? '99+' : $notif_count ?></span>
                <?php else: ?>
                    <span class="notifications-badge" id="notificationsBadge" style="display:none;">0</span>
                <?php endif; ?>
            </button>
            <div class="notifications-dropdown" id="notificationsDropdown">
                <div class="notifications-header">
                    <span class="notifications-title">Уведомления</span>
                    <div class="notifications-header-actions">
                        <?php if ($notif_count > 0): ?>
                            <button class="mark-all-read-btn" id="markAllReadBtn">Все прочитано</button>
                        <?php endif; ?>
                        <span class="notifications-count" id="notificationsCount"><?= $notif_count ?> новых</span>
                    </div>
                </div>
                <div class="notifications-list" id="notificationsList">
                    <?php if (empty($notifications)): ?>
                        <div class="notifications-empty">
                            <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
                            <div class="empty-text">Нет уведомлений</div>
                            <div class="empty-sub">Здесь будут появляться ваши уведомления</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($notifications as $notif):
                            $icon          = formatNotificationIcon((string)$notif['type']);
                            $sender_avatar = (string)($notif['sender_avatar'] ?? '');
                            $sender_name   = (string)($notif['sender_name'] ?? '');
                            $n_avatar_ok   = ($sender_avatar !== '' && file_exists($sender_avatar));
                            $notif_msg     = (string)$notif['message'];
                            if ($sender_name !== '' && mb_strpos($notif_msg, $sender_name) === 0) {
                                $notif_msg = ltrim(mb_substr($notif_msg, mb_strlen($sender_name)));
                            }
                        ?>
                            <a href="<?= e($notif['link'] ?: '#') ?>"
                               class="notification-item <?= $notif['is_read'] ? 'read' : 'unread' ?> type-<?= e((string)$notif['type']) ?>"
                               data-notification-id="<?= (int)$notif['id'] ?>">
                                <div class="notif-avatar-wrapper">
                                    <div class="notif-avatar">
                                        <?php if ($n_avatar_ok): ?>
                                            <img src="<?= e($sender_avatar) ?>" alt="">
                                        <?php elseif ($sender_name !== ''): ?>
                                            <span class="avatar-letter"><?= e(mb_strtoupper(mb_substr($sender_name, 0, 1, 'UTF-8'), 'UTF-8')) ?></span>
                                        <?php else: ?>
                                            <span class="avatar-letter">?</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="notif-content">
                                    <div class="notif-text">
                                        <?php if ($sender_name !== ''): ?>
                                            <strong class="notif-sender"><?= e($sender_name) ?></strong><span class="notif-message"><?= e($notif_msg) ?></span>
                                        <?php else: ?>
                                            <span class="notif-message"><?= e((string)$notif['message']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="notif-meta">
                                        <span class="notif-time"><?= formatTimeAgo((string)$notif['created_at']) ?></span>
                                    </div>
                                </div>
                                <?php if (!$notif['is_read']): ?>
                                    <span class="notif-dot"></span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div class="notifications-footer">
                    <a href="notifications.php" class="view-all-notifications">Показать всё</a>
                </div>
            </div>
        </div>

        <div class="avatar-dropdown">
            <button class="header-avatar is-online" id="avatarBtn" aria-label="Мой профиль">
                <?php if ($avatar_ok): ?>
                    <img src="<?= e($avatar) ?>" alt="<?= e($username) ?>">
                <?php else: ?>
                    <?= e($avatarLetter) ?>
                <?php endif; ?>
            </button>
            <div class="dropdown-menu" id="avatarDropdown">
                <div class="dropdown-header">
                    <div class="dropdown-avatar">
                        <?php if ($avatar_ok): ?>
                            <img src="<?= e($avatar) ?>" alt="">
                        <?php else: ?>
                            <?= e($avatarLetter) ?>
                        <?php endif; ?>
                    </div>
                    <div class="dropdown-user-info">
                        <div class="dropdown-username"><?php require_once __DIR__ . '/display_name.php'; ?><?= e(userDisplayName($conn ?? null, (int)($_SESSION['user_id'] ?? 0), (string)$username)) ?></div>
                    </div>
                </div>

                <div class="dropdown-divider"></div>

                <a href="settings.php" class="dropdown-item"><span class="dropdown-icon">⚙</span> Настройки</a>

                <div class="theme-trigger" id="themeTrigger">
                    <span class="dropdown-icon">🎨</span>
                    <span>Тема</span>
                    <span class="theme-current"><?= e($theme_names[$theme] ?? 'Тёмная') ?></span>
                    <span class="theme-arrow" id="themeArrow">▼</span>
                </div>

                <div class="theme-submenu" id="themeSubmenu">
                    <?php foreach ($theme_names as $key => $label): ?>
                        <a href="?theme=<?= $key ?>" class="theme-item <?= $theme === $key ? 'active' : '' ?>">
                            <span class="theme-option"><span class="theme-dot <?= $key ?>"></span><?= e($label) ?></span>
                            <?php if ($theme === $key): ?><span class="theme-check">✓</span><?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <div class="dropdown-divider"></div>

                <a href="logout.php" class="dropdown-item logout-item"><span class="dropdown-icon">↪</span> Выйти</a>
            </div>
        </div>
    </div>
</header>

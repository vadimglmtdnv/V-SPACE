<?php
/**
 * Загрузка секретов (пароль БД, соль шифрования, пароль почты) из файла .env.
 *
 * В PHP-коде секретов нет вообще. Значения берутся:
 *   1) из переменных окружения сервера (если хостинг их поддерживает);
 *   2) из файла .env. Файл ищется по порядку:
 *        - путь из переменной окружения APP_ENV_FILE;
 *        - папка ВЫШЕ папки сайта  (../.env)  — рекомендуется: файл не доступен по ссылке;
 *        - корень сайта (.env)     — тогда закройте его в настройках веб-сервера.
 *
 * Значения не кладутся в $_ENV / putenv(), поэтому не видны в phpinfo() и дочерних процессах.
 */

if (!function_exists('env')) {

    /** Путь к найденному .env или null. */
    function env_file_path(): ?string
    {
        $root = dirname(__DIR__);
        $candidates = [];

        $custom = getenv('APP_ENV_FILE');
        if (is_string($custom) && $custom !== '') {
            $candidates[] = $custom;
        }
        $candidates[] = dirname($root) . '/.env';
        $candidates[] = $root . '/.env';

        foreach ($candidates as $path) {
            if (is_file($path) && is_readable($path)) {
                return $path;
            }
        }
        return null;
    }

    /** Все значения из .env (читается один раз за запрос). */
    function env_values(): array
    {
        static $values = null;
        if ($values !== null) {
            return $values;
        }

        $values = [];
        $path = env_file_path();
        if ($path === null) {
            return $values;
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') {
                continue;
            }
            $eq = strpos($line, '=');
            if ($eq === false) {
                continue;
            }
            $key = trim(substr($line, 0, $eq));
            $val = trim(substr($line, $eq + 1));
            if ($key === '' || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $key)) {
                continue;
            }
            $len = strlen($val);
            if ($len >= 2 && ($val[0] === '"' || $val[0] === "'") && $val[$len - 1] === $val[0]) {
                $val = substr($val, 1, -1);
            }
            $values[$key] = $val;
        }
        return $values;
    }

    /** Есть ли значение (в окружении сервера или в .env). */
    function env_has(string $key): bool
    {
        $real = getenv($key);
        if ($real !== false && $real !== '') {
            return true;
        }
        return array_key_exists($key, env_values());
    }

    /** Значение настройки. Окружение сервера важнее .env. */
    function env(string $key, ?string $default = null): ?string
    {
        $real = getenv($key);
        if ($real !== false && $real !== '') {
            return $real;
        }
        $values = env_values();
        return array_key_exists($key, $values) ? $values[$key] : $default;
    }
}

// Константы для старого кода (messages.php и др. читают DB_* и ENCRYPTION_SALT как константы).
// Если константа уже объявлена — не трогаем.
defined('DB_HOST') || define('DB_HOST', (string)env('DB_HOST', '127.0.0.1'));
defined('DB_NAME') || define('DB_NAME', (string)env('DB_NAME', 'pg_player_chat'));
defined('DB_USER') || define('DB_USER', (string)env('DB_USER', ''));
defined('DB_PASS') || define('DB_PASS', (string)env('DB_PASS', ''));

if (!defined('ENCRYPTION_SALT') && env_has('ENCRYPTION_SALT')) {
    define('ENCRYPTION_SALT', (string)env('ENCRYPTION_SALT'));
}

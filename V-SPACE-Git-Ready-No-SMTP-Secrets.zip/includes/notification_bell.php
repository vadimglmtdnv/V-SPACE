<span class="bell-svg" aria-hidden="true">
    <svg width="24" height="24" viewBox="0 0 24 24">
        <defs>
            <linearGradient id="bellGrad" x1="5" y1="3" x2="19" y2="20" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#9aa4ff"/>
                <stop offset="1" stop-color="#5865f2"/>
            </linearGradient>
        </defs>
        <g class="bell-body">
            <path d="M12 2.4a1.3 1.3 0 0 1 1.3 1.3v.5a6.6 6.6 0 0 1 5.2 6.4v3.1c0 .9.4 1.7 1 2.4l.5.6c.5.7.1 1.7-.8 1.7H4.8c-.9 0-1.3-1-.8-1.7l.5-.6c.6-.7 1-1.5 1-2.4v-3.1a6.6 6.6 0 0 1 5.2-6.4v-.5A1.3 1.3 0 0 1 12 2.4z" fill="url(#bellGrad)"/>
            <path d="M8.2 10.2A3.9 3.9 0 0 1 11 7" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="1.3" stroke-linecap="round"/>
        </g>
        <path class="bell-clapper" d="M9.4 19.8h5.2a2.6 2.6 0 0 1-5.2 0z" fill="#5865f2"/>
    </svg>
</span>

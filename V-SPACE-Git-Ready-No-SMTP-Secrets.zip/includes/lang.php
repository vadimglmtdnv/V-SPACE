<?php
/**
 * includes/lang.php — язык интерфейса для общих частей сайта:
 * шапки (includes/site_header.php) и панели навигации (includes/bottom_nav.php).
 *
 * Язык выбирается в настройках (settings.php) и хранится в cookie "lang" (и в сессии).
 * Если там ничего нет, берётся переменная $lang страницы. Если язык не определён — русский.
 *
 * Подключение: require_once __DIR__ . '/lang.php';  (повторное подключение безопасно)
 *
 * Тексты самих страниц (посты, чат, формы и т.д.) этот файл не переводит —
 * только общие элементы интерфейса.
 */

if (!function_exists('ui_lang')) {
    /** Текущий язык интерфейса: 'ru' или 'en'. */
    function ui_lang(): string
    {
        $lang = $_COOKIE['lang'] ?? ($_SESSION['lang'] ?? ($GLOBALS['lang'] ?? 'ru'));
        return in_array($lang, ['ru', 'en'], true) ? $lang : 'ru';
    }
}

if (!function_exists('ui_t')) {
    /** Перевод строки интерфейса по ключу (для неизвестного ключа вернётся сам ключ). */
    function ui_t(string $key): string
    {
        static $dict = [
            'ru' => [
                // нижняя панель
                'nav_profile'    => 'Профиль',
                'nav_news'       => 'Новости',
                'nav_messages'   => 'Сообщения',
                'nav_friends'    => 'Друзья',
                'nav_spaces'     => 'Пространства',
                'nav_photos'     => 'Фото',
                'nav_music'      => 'Музыка',
                'nav_video'      => 'Видео',
                'nav_favorites'  => 'Избранное',
                'nav_support'    => 'Поддержка',
                'nav_about'      => 'О проекте',
                'nav_developers' => 'Разработчикам',
                'nav_menu'       => 'Меню',
                // шапка
                'moderation'     => 'Модерация',
                'notifications'  => 'Уведомления',
                'mark_all_read'  => 'Все прочитано',
                'no_notifs'      => 'Нет уведомлений',
                'no_notifs_sub'  => 'Здесь будут появляться ваши уведомления',
                'view_all_notifs'=> 'Показать всё',
                'my_profile'     => 'Мой профиль',
                'user_default'   => 'Пользователь',
                'settings'       => 'Настройки',
                'theme'          => 'Тема',
                'theme_dark'     => 'Тёмная',
                'theme_light'    => 'Светлая',
                'theme_system'   => 'Системная',
                'logout'         => 'Выйти',
            ],
            'en' => [
                'nav_profile'    => 'Profile',
                'nav_news'       => 'News',
                'nav_messages'   => 'Messages',
                'nav_friends'    => 'Friends',
                'nav_spaces'     => 'Spaces',
                'nav_photos'     => 'Photos',
                'nav_music'      => 'Music',
                'nav_video'      => 'Videos',
                'nav_favorites'  => 'Favorites',
                'nav_support'    => 'Support',
                'nav_about'      => 'About',
                'nav_developers' => 'Developers',
                'nav_menu'       => 'Menu',
                'moderation'     => 'Moderation',
                'notifications'  => 'Notifications',
                'mark_all_read'  => 'Mark all as read',
                'no_notifs'      => 'No notifications',
                'no_notifs_sub'  => 'Your notifications will appear here',
                'view_all_notifs'=> 'Show all',
                'my_profile'     => 'My profile',
                'user_default'   => 'User',
                'settings'       => 'Settings',
                'theme'          => 'Theme',
                'theme_dark'     => 'Dark',
                'theme_light'    => 'Light',
                'theme_system'   => 'System',
                'logout'         => 'Log out',
            ],
        ];
        $lang = ui_lang();
        return $dict[$lang][$key] ?? ($dict['ru'][$key] ?? $key);
    }
}

if (!function_exists('ui_e')) {
    /** ui_t() сразу с экранированием для вывода в HTML. */
    function ui_e(string $key): string
    {
        return htmlspecialchars(ui_t($key), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('ui_new_count')) {
    /** Подпись счётчика в окне уведомлений: «3 новых» / «3 new». */
    function ui_new_count(int $n): string
    {
        return ui_lang() === 'en' ? $n . ' new' : $n . ' новых';
    }
}

if (!function_exists('ui_time')) {
    /** Короткое «время назад» из timeAgo(): «10 ч» → «10h», «только что» → «just now». */
    function ui_time(string $s): string
    {
        if (ui_lang() !== 'en') {
            return $s;
        }
        $s = preg_replace('/только что/u', 'just now', $s);
        return preg_replace_callback('/(\d+)\s*(мин|м|ч|д)(?![\p{L}])/u', static function (array $m): string {
            $units = ['мин' => 'm', 'м' => 'm', 'ч' => 'h', 'д' => 'd'];
            return $m[1] . $units[$m[2]];
        }, $s);
    }
}

if (!function_exists('ui_notif_msg')) {
    /**
     * Текст уведомления. Тексты хранятся в базе по-русски, поэтому для английского
     * заменяем известные фразы; всё незнакомое остаётся как есть.
     * Новые фразы добавляются в массив ниже.
     */
    function ui_notif_msg(string $msg): string
    {
        if (ui_lang() !== 'en') {
            return $msg;
        }
        static $map = [
            'поставил(а) лайк на ваш пост'         => 'liked your post',
            'поставил(а) лайк на фото в переписке' => 'liked a photo in chat',
            'отреагировал(а) на ваш пост'          => 'reacted to your post',
            'репостнул(а) ваш пост'                => 'reposted your post',
            'прокомментировал(а) ваш пост:'        => 'commented on your post:',
            'опубликовал(а) новый пост:'           => 'published a new post:',
            'отправил(а) вам заявку в друзья'      => 'sent you a friend request',
            'принял(а) вашу заявку в друзья'       => 'accepted your friend request',
            'отклонил(а) вашу заявку в друзья'     => 'declined your friend request',
            'удалил(а) вас из друзей'              => 'removed you from friends',
            'отправил(а) вам сообщение'            => 'sent you a message',
        ];
        return strtr($msg, $map);
    }
}

/* ------------------------------------------------------------------------
 * Перевод содержимого страниц на английский «на лету».
 *
 * Тексты страниц написаны по-русски прямо в коде. Если выбран English, страница
 * пропускается через словарь includes/lang_en_pages.php: заменяются только строки,
 * которые совпадают со словарём целиком (текстовый узел, значение атрибута или
 * строка в скрипте), поэтому посты, чат и имена пользователей не затрагиваются.
 * Плюс несколько правил для строк с числами и датами (см. ui_translate_piece).
 *
 * Включается одной строкой в начале страницы, до любого вывода:
 *     require_once __DIR__ . '/includes/lang.php';
 *     ui_translate_start();
 * Для русского языка ничего не делает.
 * ---------------------------------------------------------------------- */

if (!function_exists('ui_translate_start')) {
    function ui_translate_start(): void
    {
        static $started = false;
        if ($started || ui_lang() !== 'en') {
            return;
        }
        $started = true;
        ob_start('ui_translate_html');
    }
}

if (!function_exists('ui_translate_piece')) {
    /** Перевод одного фрагмента текста (null — не знаем, оставить как есть). */
    function ui_translate_piece(string $s, array $map): ?string
    {
        if (isset($map[$s])) {
            return $map[$s];
        }

        // «5 подписчиков», «3 минуты назад»
        static $plural = [
            'подписчик' => ['follower', 'followers'], 'подписчика' => ['follower', 'followers'], 'подписчиков' => ['follower', 'followers'],
            'реакция' => ['reaction', 'reactions'], 'реакции' => ['reaction', 'reactions'], 'реакций' => ['reaction', 'reactions'],
            'трек' => ['track', 'tracks'], 'трека' => ['track', 'tracks'], 'треков' => ['track', 'tracks'],
            'альбом' => ['album', 'albums'], 'альбома' => ['album', 'albums'], 'альбомов' => ['album', 'albums'],
            'комментарий' => ['comment', 'comments'], 'комментария' => ['comment', 'comments'], 'комментариев' => ['comment', 'comments'],
            'друг' => ['friend', 'friends'], 'друга' => ['friend', 'friends'], 'друзей' => ['friend', 'friends'],
            'участник' => ['member', 'members'], 'участника' => ['member', 'members'], 'участников' => ['member', 'members'],
            'пост' => ['post', 'posts'], 'поста' => ['post', 'posts'], 'постов' => ['post', 'posts'],
            'просмотр' => ['view', 'views'], 'просмотра' => ['view', 'views'], 'просмотров' => ['view', 'views'],
            'канал' => ['channel', 'channels'], 'канала' => ['channel', 'channels'], 'каналов' => ['channel', 'channels'],
            'фото' => ['photo', 'photos'], 'видео' => ['video', 'videos'],
            'минуту' => ['minute', 'minutes'], 'минуты' => ['minute', 'minutes'], 'минут' => ['minute', 'minutes'],
            'час' => ['hour', 'hours'], 'часа' => ['hour', 'hours'], 'часов' => ['hour', 'hours'],
            'день' => ['day', 'days'], 'дня' => ['day', 'days'], 'дней' => ['day', 'days'],
        ];
        if (preg_match('/^(\d+)\s+(\p{L}+)(\s+назад)?$/u', $s, $m) && isset($plural[$m[2]])) {
            $word = ((int)$m[1] === 1) ? $plural[$m[2]][0] : $plural[$m[2]][1];
            return $m[1] . ' ' . $word . (!empty($m[3]) ? ' ago' : '');
        }

        // «Был(а) в сети …» (messages.php → lastSeenText)
        if (strpos($s, 'Был(а) в сети ') === 0) {
            $r = trim(substr($s, strlen('Был(а) в сети ')));
            static $fixed = ['недавно' => 'recently', 'только что' => 'just now', 'час назад' => 'an hour ago'];
            if (isset($fixed[$r])) {
                return 'Last seen ' . $fixed[$r];
            }
            if (preg_match('/^(\d+)\s+(?:минуту|минуты|минут)\s+назад$/u', $r, $m)) {
                return 'Last seen ' . $m[1] . ((int)$m[1] === 1 ? ' minute ago' : ' minutes ago');
            }
            if (preg_match('/^(\d+)\s+(?:часа|часов)\s+назад$/u', $r, $m)) {
                return 'Last seen ' . $m[1] . ' hours ago';
            }
            if (preg_match('/^сегодня в (\d{1,2}:\d{2})$/u', $r, $m)) {
                return 'Last seen today at ' . $m[1];
            }
            if (preg_match('/^вчера в (\d{1,2}:\d{2})$/u', $r, $m)) {
                return 'Last seen yesterday at ' . $m[1];
            }
            if (preg_match('/^(\d{1,2}\.\d{1,2}\.\d{4}) в (\d{1,2}:\d{2})$/u', $r, $m)) {
                return 'Last seen ' . $m[1] . ' at ' . $m[2];
            }
            return null;
        }

        // Даты с русскими месяцами: «5 января 2026», «5 января 2026 в 14:30»
        static $months = [
            'января' => 'Jan', 'февраля' => 'Feb', 'марта' => 'Mar', 'апреля' => 'Apr', 'мая' => 'May', 'июня' => 'Jun',
            'июля' => 'Jul', 'августа' => 'Aug', 'сентября' => 'Sep', 'октября' => 'Oct', 'ноября' => 'Nov', 'декабря' => 'Dec',
        ];
        if (preg_match('/^(\d{1,2})\s+(\p{L}+)(?:\s+(\d{4}))?(?:\s*г\.)?(?:,?\s*(?:в\s+)?(\d{1,2}:\d{2}))?$/u', $s, $m) && isset($months[$m[2]])) {
            return $months[$m[2]] . ' ' . $m[1]
                . (!empty($m[3]) ? ', ' . $m[3] : '')
                . (!empty($m[4]) ? ' at ' . $m[4] : '');
        }

        // «имя файла: причина» (загрузка фото)
        static $reasons = [
            'достигнут лимит фото' => 'photo limit reached', 'не удалось прочитать' => 'could not be read',
            'не удалось сохранить' => 'could not be saved', 'ошибка базы данных' => 'database error',
            'ошибка загрузки' => 'upload error', 'размер больше 15 МБ' => 'size exceeds 15 MB',
            'файл слишком большой' => 'file is too large', 'формат не поддерживается' => 'format not supported',
            'это не изображение' => 'not an image',
        ];
        if (preg_match('/^(.+): ([^:]+)$/su', $s, $m) && isset($reasons[$m[2]])) {
            return $m[1] . ': ' . $reasons[$m[2]];
        }

        // «Имя — Онлайн / Офлайн»
        if (preg_match('/^(.+) — (Онлайн|Офлайн)$/su', $s, $m)) {
            return $m[1] . ' — ' . ($m[2] === 'Онлайн' ? 'Online' : 'Offline');
        }

        // Страница V+ / баланса (donate.php): строки с суммами и датами
        if (preg_match('/^Не хватает (.+) VS$/u', $s, $m)) {
            return 'Short by ' . $m[1] . ' VS';
        }
        if (preg_match('/^Недостаточно VS-баллов\. Нужно: (.+) VS\.$/u', $s, $m)) {
            return 'Not enough VS points. You need ' . $m[1] . ' VS.';
        }
        if (preg_match('/^V\+ активирован до (\S+)\. Списано (.+) VS\.$/u', $s, $m)) {
            return 'V+ activated until ' . $m[1] . '. Charged ' . $m[2] . ' VS.';
        }
        if (preg_match('/^(Зачислено|Списано) (.+) VS\. Баланс: (.+) VS\.$/u', $s, $m)) {
            return ($m[1] === 'Зачислено' ? 'Credited ' : 'Charged ') . $m[2] . ' VS. Balance: ' . $m[3] . ' VS.';
        }
        if (preg_match('/^Оплата через «(.+)» пока недоступна: платёжная система ещё не подключена\.$/u', $s, $m)) {
            return 'Payment via ' . ($map[$m[1]] ?? $m[1]) . ' is not available yet: the payment system is not connected.';
        }

        return null;
    }
}

if (!function_exists('ui_translate_html')) {
    /** Обработчик буфера вывода: переводит готовый HTML (или JSON) страницы. */
    function ui_translate_html(string $html): string
    {
        if ($html === '' || strlen($html) > 4000000) {
            return $html;
        }
        // Бинарные ответы (картинки, аудио, видео, файлы) не трогаем.
        foreach (headers_list() as $h) {
            if (stripos($h, 'content-type:') === 0 && !preg_match('~text/|json|javascript|xml~i', $h)) {
                return $html;
            }
        }
        if (!mb_check_encoding($html, 'UTF-8') || !preg_match('/[\x{0400}-\x{04FF}]/u', $html)) {
            return $html;
        }

        static $map = null;
        if ($map === null) {
            $file = __DIR__ . '/lang_en_pages.php';
            $map = is_file($file) ? (array)(require $file) : [];
        }

        // 1) Текстовые узлы: >текст<
        $out = preg_replace_callback('/>([^<>]*[\x{0400}-\x{04FF}][^<>]*)</u', static function (array $m) use ($map): string {
            if (!preg_match('/^(\s*)(.*?)(\s*)$/su', $m[1], $p)) {
                return $m[0];
            }
            $key = preg_replace('/\s+/u', ' ', $p[2]);
            if ($key === null || $key === '') {
                return $m[0];
            }
            $tr = ui_translate_piece($key, $map);
            return $tr === null ? $m[0] : '>' . $p[1] . $tr . $p[3] . '<';
        }, $html);
        if ($out !== null) {
            $html = $out;
        }

        // 2) Строки целиком в кавычках: значения атрибутов (placeholder, title, alt …) и строки в скриптах
        $out = preg_replace_callback('/(["\'])([^"\'\\\\\n<>]*[\x{0400}-\x{04FF}][^"\'\\\\\n<>]*)\1/u', static function (array $m) use ($map): string {
            $tr = $map[$m[2]] ?? null;
            return $tr === null ? $m[0] : $m[1] . $tr . $m[1];
        }, $html);
        if ($out !== null) {
            $html = $out;
        }

        return str_replace('<html lang="ru">', '<html lang="en">', $html);
    }
}

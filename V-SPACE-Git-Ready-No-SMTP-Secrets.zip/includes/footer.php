<div class="site-footer">
    <div class="footer-content">
        <div class="footer-socials">
            <a href="https://discord.gg/N6kyTVDjNj" target="_blank" title="Discord">
                <img src="images/discord_invite.svg" alt="Discord">
            </a>
            <a href="https://t.me/VS_pace" target="_blank" title="Telegram">
                <img src="images/telegram_intivte.svg" alt="Telegram">
            </a>
        </div>
        <span class="footer-copy">
            SPACE &copy; <span class="year">2026</span>
        </span>
    </div>
</div>

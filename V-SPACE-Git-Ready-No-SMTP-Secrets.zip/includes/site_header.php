<?php
// includes/site_header.php — общая шапка сайта (точная копия шапки из index.php).
// Подключается на всех страницах строкой: include __DIR__ . '/includes/site_header.php';
// Нужные переменные страница задаёт заранее (если чего-то нет — используются безопасные значения):
//   $is_admin, $notifications, $notif_count, $pending_reports_count, $current_user_data, $theme
require_once __DIR__ . '/shell.php';
require_once __DIR__ . '/lang.php';   // язык интерфейса: ui_t(), ui_e(), ui_time() …
$is_admin              = !empty($is_admin);
$notifications         = isset($notifications) && is_array($notifications) ? $notifications : [];
$notif_count           = (int)($notif_count ?? 0);
$pending_reports_count = (int)($pending_reports_count ?? 0);
$current_user_data     = isset($current_user_data) && is_array($current_user_data) ? $current_user_data : [];
$theme                 = $theme ?? 'dark';
// Космос в шапке (планеты, астероиды, корабль) рисуется стилями из assets/css/index.css.
// Страница, где этот файл стилей не подключён, ставит $site_header_cosmic = false до подключения шапки.
$shell_cosmic          = $site_header_cosmic ?? true;
?>
<style>
.profile-status .presence-phone-icon { display: inline-block; width: 14px; height: 16px; vertical-align: -4px; }
.profile-status .status-dot { display: none !important; }
.profile-status .status-dot.is-device { display: inline-flex !important; width: 14px !important; height: 16px !important; margin-right: 6px !important; border-radius: 0 !important; background: transparent !important; align-items: center; justify-content: center; }
.notifications-btn .bell-svg { display: block; width: 26px; height: 26px; }
.notifications-btn .bell-svg svg { display: block; width: 100%; height: 100%; }
/* Шестерёнка «Настройки»: плавный оборот при наведении/фокусе */
.settings-item .settings-gear {
    transform-origin: 50% 50%;
    transform-box: fill-box;
}
.settings-item:hover .settings-gear,
.settings-item:focus-visible .settings-gear {
    animation: settings-gear-spin .9s cubic-bezier(.45, .05, .25, 1) 1;
}
@keyframes settings-gear-spin {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
}
@media (prefers-reduced-motion: reduce) {
    .settings-item:hover .settings-gear,
    .settings-item:focus-visible .settings-gear { animation: none; }
}

/* Выпадающие окна шапки (уведомления, меню профиля) — поверх панели навигации */
.header { z-index: 1300 !important; }
.notifications-dropdown,
.avatar-dropdown .dropdown-menu { z-index: 1300 !important; }

/* Телефон: шапка (вместе с колокольчиком) уезжает вверх при прокрутке вниз и возвращается при прокрутке вверх */
@media (max-width: 860px) {
    /* На странице может быть подключён не index.css (профиль, уведомления, друзья…), поэтому
       закрепление шапки задаём здесь — тогда оно работает везде, где есть эта шапка.
       overflow-x: clip вместо hidden у body: hidden на html и body сразу ломает sticky. */
    body { overflow-x: clip !important; }
    .header {
        position: sticky !important;
        top: 0 !important;
        background-color: var(--bg-secondary, var(--f-card, #2b2d31)) !important;
        transition: transform .25s ease, background .3s ease, border-color .3s ease, box-shadow .3s ease;
    }
    /* -100px сверху: сезонные украшения (гирлянда и т.п.) свисают ниже шапки и уезжают вместе с ней;
       !important у тени — сезонное правило в seasons.css иначе оставляет цветное свечение у верха экрана */
    .header.is-hidden {
        transform: translateY(calc(-100% - 100px));
        box-shadow: none !important;
        pointer-events: none;
    }
}
@media (prefers-reduced-motion: reduce) {
    .header { transition: none !important; }
}
</style>
<header class="header<?= $shell_cosmic ? ' header-cosmic' : '' ?>">
        <?php if ($shell_cosmic): ?>
        <!-- Космос в шапке: планеты, пояс астероидов и пролетающий корабль -->
        <span class="header-space" aria-hidden="true">
            <svg class="hs-defs" width="0" height="0" focusable="false">
                <defs>
                    <linearGradient id="hs-rock" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9097a8"/><stop offset="1" stop-color="#474c5a"/></linearGradient>
                    <radialGradient id="hs-sat" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffe6b8"/><stop offset=".55" stop-color="#e9a24f"/><stop offset="1" stop-color="#7a3f17"/></radialGradient>
                    <radialGradient id="hs-nep" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#bfe3ff"/><stop offset=".55" stop-color="#3f8cf0"/><stop offset="1" stop-color="#14307a"/></radialGradient>
                    <radialGradient id="hs-mars" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffb199"/><stop offset=".6" stop-color="#d8512f"/><stop offset="1" stop-color="#6b1d10"/></radialGradient>
                    <radialGradient id="hs-earth" cx="34%" cy="28%" r="75%"><stop offset="0" stop-color="#9fe8ff"/><stop offset=".58" stop-color="#2878d0"/><stop offset="1" stop-color="#102c75"/></radialGradient>
                    <linearGradient id="hs-hull" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#a9b1c4"/></linearGradient>
                    <linearGradient id="hs-glass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a6ecff"/><stop offset="1" stop-color="#2f7fe0"/></linearGradient>
                    <linearGradient id="hs-fire" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="#fff3a8"/><stop offset=".45" stop-color="#ffa63d"/><stop offset="1" stop-color="#ff4d1f" stop-opacity="0"/></linearGradient>

                    <symbol id="hs-rock-a" viewBox="0 0 24 24">
                        <polygon points="4,9 8,3 15,2 21,7 22,14 17,21 9,22 3,16" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                        <circle cx="9" cy="9" r="2.2" fill="#000" opacity=".28"/><circle cx="15.5" cy="14" r="2.8" fill="#000" opacity=".25"/><circle cx="8" cy="16.5" r="1.5" fill="#000" opacity=".28"/>
                    </symbol>
                    <symbol id="hs-rock-b" viewBox="0 0 24 24">
                        <polygon points="3,12 6,5 13,3 20,5 22,12 18,19 11,22 5,19" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                        <circle cx="12" cy="8" r="2.4" fill="#000" opacity=".26"/><circle cx="8" cy="15" r="2" fill="#000" opacity=".28"/><circle cx="16.5" cy="15.5" r="1.6" fill="#000" opacity=".25"/>
                    </symbol>
                    <symbol id="hs-rock-c" viewBox="0 0 24 24">
                        <polygon points="2,11 7,5 17,4 23,10 21,17 12,20 5,18" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                        <circle cx="10" cy="10" r="2.6" fill="#000" opacity=".26"/><circle cx="17" cy="13" r="1.8" fill="#000" opacity=".28"/>
                    </symbol>
                </defs>
            </svg>

            <!-- Планеты -->
            <svg class="hs-planet hs-planet-ringed" viewBox="0 0 80 50">
                <g transform="rotate(-16 40 25)">
                    <ellipse cx="40" cy="25" rx="36" ry="9" fill="none" stroke="#f4d28a" stroke-width="3" opacity=".55"/>
                    <circle cx="40" cy="25" r="15" fill="url(#hs-sat)"/>
                    <path d="M26 21 Q40 17.5 54 21 M25.6 29 Q40 33 54.4 29" fill="none" stroke="#fff" stroke-width="1.6" opacity=".28" stroke-linecap="round"/>
                    <path d="M4 25 A36 9 0 0 0 76 25" fill="none" stroke="#ffd98e" stroke-width="3" stroke-linecap="round"/>
                </g>
            </svg>
            <svg class="hs-planet hs-planet-blue" viewBox="0 0 40 40">
                <circle cx="20" cy="20" r="14" fill="url(#hs-nep)"/>
                <path d="M7.5 16 Q20 12 32.5 16 M6.5 23 Q20 27 33.5 23" fill="none" stroke="#fff" stroke-width="1.6" opacity=".3" stroke-linecap="round"/>
                <circle cx="35" cy="7" r="3" fill="#cfd6e6"/><circle cx="34" cy="6" r="1" fill="#fff" opacity=".7"/>
            </svg>
            <svg class="hs-planet hs-planet-red" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="url(#hs-mars)"/>
                <ellipse cx="9" cy="9" rx="2.2" ry="1.6" fill="#000" opacity=".22"/><ellipse cx="15" cy="14.5" rx="2.6" ry="1.8" fill="#000" opacity=".2"/>
            </svg>
            <svg class="hs-planet hs-planet-earth" viewBox="0 0 40 40">
                <circle cx="20" cy="20" r="16" fill="url(#hs-earth)"/>
                <path d="M10 10l5-3 3 2-1 4-3 1-1 4-4-1-2-3zm13-2 5 1 2 4-3 2-1 4-4-2-2-4 2-2zm-4 13 4-2 4 3-1 5-4 4-3-2-1-4zm-9 2 4 1 2 4-3 3-4-2-1-4z" fill="#55c77a"/>
                <path d="M8 15c4-3 8-4 12-4s8 1 12 4M6 21c5-2 9-3 14-3s9 1 14 3" fill="none" stroke="#c6f3ff" stroke-width=".8" opacity=".45"/>
            </svg>

            <!-- Пояс астероидов: плывут справа налево -->
            <span class="hs-asteroid" style="--y:9px;  --s:11px; --dur:46s; --delay:-9s;  --spin:360deg;  --sx:8%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
            <span class="hs-asteroid" style="--y:38px; --s:16px; --dur:62s; --delay:-31s; --spin:-300deg; --sx:20%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>
            <span class="hs-asteroid" style="--y:22px; --s:8px;  --dur:38s; --delay:-14s; --spin:420deg;  --sx:37%"><svg viewBox="0 0 24 24"><use href="#hs-rock-c"/></svg></span>
            <span class="hs-asteroid" style="--y:46px; --s:10px; --dur:54s; --delay:-44s; --spin:-360deg; --sx:50%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:5px;  --s:14px; --dur:70s; --delay:-21s; --spin:240deg;  --sx:64%"><svg viewBox="0 0 24 24"><use href="#hs-rock-c"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:30px; --s:9px;  --dur:42s; --delay:-3s;  --spin:-420deg; --sx:72%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:14px; --s:6px;  --dur:34s; --delay:-26s; --spin:300deg;  --sx:28%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:42px; --s:7px;  --dur:50s; --delay:-18s; --spin:-240deg; --sx:44%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>

            <!-- Космический корабль -->
            <span class="hs-ship">
                <svg viewBox="0 0 64 28">
                    <path class="hs-flame" d="M12 10.5 L0 14 L12 17.5Z" fill="url(#hs-fire)"/>
                    <path d="M15 10 L21 2 L28 10Z" fill="#5865f2" stroke="#2a31a0" stroke-width="1" stroke-linejoin="round"/>
                    <path d="M15 18 L21 26 L28 18Z" fill="#5865f2" stroke="#2a31a0" stroke-width="1" stroke-linejoin="round"/>
                    <rect x="10" y="10" width="5" height="8" rx="1.5" fill="#3a3f4b"/>
                    <path d="M14 8 H40 Q56 8 63 14 Q56 20 40 20 H14 Q11 14 14 8Z" fill="url(#hs-hull)" stroke="#59607a" stroke-width="1" stroke-linejoin="round"/>
                    <path d="M16 15 H36" stroke="#5865f2" stroke-width="2" stroke-linecap="round"/>
                    <ellipse cx="46" cy="13.4" rx="6.4" ry="3.6" fill="url(#hs-glass)" stroke="#2a4f9c" stroke-width=".8"/>
                    <ellipse cx="44.4" cy="12.2" rx="2.4" ry="1" fill="#fff" opacity=".7"/>
                    <circle cx="22" cy="12.4" r="1.2" fill="#2f7fe0"/><circle cx="27" cy="12.4" r="1.2" fill="#2f7fe0"/><circle cx="32" cy="12.4" r="1.2" fill="#2f7fe0"/>
                </svg>
            </span>
        </span>
        <span class="header-shooting-stars" aria-hidden="true">
            <span class="sky-cloud" aria-hidden="true"></span>
            <span class="sky-rain" aria-hidden="true"></span>
            <span class="sky-snow" aria-hidden="true"></span>
            <span class="sky-fog" aria-hidden="true"></span>
            <span class="sky-flash" aria-hidden="true"></span>
            <span class="header-shooting-star star-one"></span>
            <span class="header-shooting-star star-two"></span>
            <span class="header-shooting-star star-three"></span>
            <span class="header-comet"></span>
        </span>
        <?php endif; ?>
        <div class="header-left">
            <div class="logo">
                <div class="logo-icon">
                    <img src="images/logo_type.svg" alt="SPACE Logo" width="40" height="40">
                </div>
            </div>
        </div>
        <div class="search-box"></div>
        <div class="header-right">
            <?php if (!empty($is_admin) && empty($hide_moderation_button)): ?>
                <a href="reports.php" class="moderation-btn" title="<?= ui_e('moderation') ?>" aria-label="<?= ui_e('moderation') ?>">
                <img src="images/protection.svg" alt="<?= ui_e('moderation') ?>" class="moderation-icon">
                <?php if ($pending_reports_count > 0): ?>
                    <span class="moderation-badge"><?= $pending_reports_count > 99 ? '99+' : $pending_reports_count ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>

            <div class="notifications-wrapper">
                <button class="notifications-btn" id="notificationsBtn" aria-label="<?= ui_e('notifications') ?>">
                    <?php include __DIR__ . '/notification_bell.php'; ?>
                    <?php if ($notif_count > 0): ?>
                        <span class="notifications-badge" id="notificationsBadge"><?= $notif_count > 99 ? '99+' : $notif_count ?></span>
                    <?php else: ?>
                        <span class="notifications-badge" id="notificationsBadge" style="display:none;">0</span>
                    <?php endif; ?>
                </button>
                <div class="notifications-dropdown" id="notificationsDropdown">
                    <div class="notifications-header">
                        <span class="notifications-title"><?= ui_e('notifications') ?></span>
                        <div class="notifications-header-actions">
                            <?php if ($notif_count > 0): ?>
                                <button class="mark-all-read-btn" id="markAllReadBtn"><?= ui_e('mark_all_read') ?></button>
                            <?php endif; ?>
                            <span class="notifications-count" id="notificationsCount" data-zero-text="<?= htmlspecialchars(ui_new_count(0), ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(ui_new_count($notif_count), ENT_QUOTES, 'UTF-8') ?></span>
                        </div>
                    </div>
                    <div class="notifications-list" id="notificationsList">
                        <?php if (empty($notifications)): ?>
                            <div class="notifications-empty">
                                <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
                                <div class="empty-text"><?= ui_e('no_notifs') ?></div>
                                <div class="empty-sub"><?= ui_e('no_notifs_sub') ?></div>
                            </div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notif): 
                                $icon = shellNotificationIcon((string)$notif['type']);
                                $notif_type_class = $notif['type'];
                                $sender_avatar = $notif['sender_avatar'] ?? '';
                                $sender_name = trim((string)($notif['sender_name'] ?? ''));
                                // У части уведомлений (например «лайк на фото в переписке») sender_id пуст,
                                // а имя вшито в начало текста: «Vadim поставил(а) лайк…». Берём его оттуда,
                                // чтобы вместо «?» был кружок с буквой и жирное имя, как у остальных.
                                if ($sender_name === '' && preg_match('/^(\S{1,40})\s+\S*\(а\)/u', (string)($notif['message'] ?? ''), $nm)) {
                                    $sender_name = $nm[1];
                                }
                                
                                $avatar_exists = false;
                                if (!empty($sender_avatar)) {
                                    $paths_to_check = [
                                        $sender_avatar,
                                        'uploads/avatars/' . basename($sender_avatar),
                                        'assets/images/' . basename($sender_avatar)
                                    ];
                                    foreach ($paths_to_check as $path) {
                                        if (file_exists($path)) {
                                            $avatar_exists = true;
                                            $sender_avatar = $path;
                                            break;
                                        }
                                    }
                                }
                            ?>
                                <a href="<?= htmlspecialchars($notif['link'] ?: '#') ?>" class="notification-item <?= $notif['is_read'] ? 'read' : 'unread' ?> type-<?= htmlspecialchars($notif_type_class) ?>" data-notification-id="<?= $notif['id'] ?>">
                                    <div class="notif-avatar-wrapper">
                                        <div class="notif-avatar">
                                            <?php if ($avatar_exists): ?>
                                                <img src="<?= htmlspecialchars($sender_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?>">
                                            <?php elseif (!empty($sender_name)): ?>
                                                <span class="avatar-letter"><?= htmlspecialchars(mb_strtoupper(mb_substr($sender_name, 0, 1, 'UTF-8'), 'UTF-8')) ?></span>
                                            <?php else: ?>
                                                <span class="avatar-letter">?</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="notif-content">
                                        <div class="notif-text">
                                            <?php if (!empty($sender_name)): ?>
                                                <?php
                                                // Ник уже выведен жирным — не повторяем его в начале текста («Vadim Vadim поставил(а)…»)
                                                $notif_msg = (string)$notif['message'];
                                                foreach ([(string)$sender_name, (string)($notif['sender_username'] ?? '')] as $strip_name) {
                                                    if ($strip_name !== '' && mb_strpos($notif_msg, $strip_name) === 0) {
                                                        $notif_msg = ltrim(mb_substr($notif_msg, mb_strlen($strip_name)));
                                                        break;
                                                    }
                                                }
                                                ?>
                                                <strong class="notif-sender"><?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?></strong><span class="notif-message"><?= htmlspecialchars(ui_notif_msg($notif_msg), ENT_QUOTES, "UTF-8") ?></span>
                                            <?php else: ?>
                                                <span class="notif-message"><?= htmlspecialchars(ui_notif_msg((string)$notif['message']), ENT_QUOTES, "UTF-8") ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="notif-meta">
                                            <span class="notif-time"><?= htmlspecialchars(ui_time((string)shellTimeAgo($notif['created_at'])), ENT_QUOTES, 'UTF-8') ?></span>
                                        </div>
                                    </div>
                                    <?php if (!$notif['is_read']): ?>
                                        <span class="notif-dot"></span>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="notifications-footer">
                        <a href="notifications.php" class="view-all-notifications"><?= ui_e('view_all_notifs') ?></a>
                    </div>
                </div>
            </div>

            <div class="avatar-dropdown">
                <?php
                $current_avatar = $current_user_data['avatar'] ?? '';
                $current_username = $current_user_data['username'] ?? ui_t('user_default');
                require_once __DIR__ . '/display_name.php'; $current_username = userDisplayName($conn ?? null, (int)($_SESSION['user_id'] ?? 0), (string)$current_username);
                $current_letter = mb_strtoupper(mb_substr($current_username, 0, 1, 'UTF-8'), 'UTF-8');
                $current_status = 'online';
                ?>
                <button class="header-avatar <?= $current_status === 'online' ? 'is-online' : 'is-offline' ?>" id="avatarBtn" aria-label="<?= ui_e('my_profile') ?>">
                    <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                        <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                    <?php else: ?>
                        <?= htmlspecialchars($current_letter) ?>
                    <?php endif; ?>
                </button>
                <div class="dropdown-menu" id="avatarDropdown">
                    <div class="dropdown-header">
                        <div class="dropdown-avatar">
                            <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                                <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                            <?php else: ?>
                                <?= htmlspecialchars($current_letter) ?>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-user-info">
                            <div class="dropdown-username"><?= htmlspecialchars($current_username) ?></div>
                        </div>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a href="settings.php" class="dropdown-item settings-item">
                        <span class="dropdown-icon"><svg class="dropdown-svg settings-gear" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;width:18px;height:18px;fill:none;stroke:currentColor;vertical-align:middle;"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></span> <?= ui_e('settings') ?>
                    </a>
                    <div class="theme-trigger" id="themeTrigger">
                        <span class="dropdown-icon">🎨</span>
                        <span><?= ui_e('theme') ?></span>
                        <span class="theme-current">
                            <?php
                            $theme_name = ui_t('theme_dark');
                            if ($theme === 'light') $theme_name = ui_t('theme_light');
                            elseif ($theme === 'system') $theme_name = ui_t('theme_system');
                            echo htmlspecialchars($theme_name);
                            ?>
                        </span>
                        <span class="theme-arrow" id="themeArrow">▼</span>
                    </div>

                    <div class="theme-submenu" id="themeSubmenu">
                        <a href="?theme=dark" class="theme-item <?= $theme === 'dark' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot dark"></span>
                                <?= ui_e('theme_dark') ?>
                            </span>
                            <?php if ($theme === 'dark'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="?theme=light" class="theme-item <?= $theme === 'light' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot light"></span>
                                <?= ui_e('theme_light') ?>
                            </span>
                            <?php if ($theme === 'light'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="?theme=system" class="theme-item <?= $theme === 'system' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot system"></span>
                                <?= ui_e('theme_system') ?>
                            </span>
                            <?php if ($theme === 'system'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>
                    </div>

                    <a href="qr_login.php?scanner=1" class="dropdown-item" id="appQrLoginLink" style="display:none;">
                        <span class="dropdown-icon"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zm4 4h3v3h-3zm0-4h3m-7 7h3"/></svg></span>
                        Войти на компьютере по QR-коду
                    </a>

                    <div class="dropdown-divider"></div>

                    <a href="logout.php" class="dropdown-item logout-item">
                        <span class="dropdown-icon"><svg class="dropdown-svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;flex-shrink:0;width:18px;height:18px;fill:none;stroke:currentColor;vertical-align:middle;"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg></span> <?= ui_e('logout') ?>
                    </a>
                </div>
            </div>
        </div>
    </header>

<?php if ($shell_cosmic): ?>
<script src="assets/js/header-space.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/header-space.js') ?>" defer></script>
<?php endif; ?>

<?php /* Переключатель темы «ночь ↔ день» в меню профиля (общий для всех страниц с этой шапкой) */ ?>
<script>
    if (window.VSpaceApp && typeof window.VSpaceApp.scanQr === 'function') {
        var appQrLoginLink = document.getElementById('appQrLoginLink');
        if (appQrLoginLink) appQrLoginLink.style.display = 'flex';
    }
</script>
<script>
/* Телефон: прячем шапку с колокольчиком, когда страницу листают вниз (свайп снизу вверх), и показываем при листании вверх */
(function () {
    var header = document.querySelector('header.header');
    if (!header) return;
    var mq = window.matchMedia('(max-width: 860px)');
    var lastY = window.pageYOffset || 0;
    var ticking = false;
    var STEP = 6;                                   // игнорируем дрожание меньше 6px

    function panelOpen() {
        return !!document.querySelector('#notificationsDropdown.active, #avatarDropdown.active, .notifications-dropdown.active, .dropdown-menu.active');
    }
    function update() {
        ticking = false;
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        var max = document.documentElement.scrollHeight - window.innerHeight;
        if (!mq.matches || y <= header.offsetHeight || panelOpen()) {   // вверху страницы / открыта панель / не телефон
            header.classList.remove('is-hidden');
            lastY = y;
            return;
        }
        if (y < 0 || y > max) return;               // «резинка» iOS у краёв страницы
        var d = y - lastY;
        if (Math.abs(d) < STEP) return;
        header.classList.toggle('is-hidden', d > 0);
        lastY = y;
    }
    function onScroll() {
        if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
})();
</script>
<link rel="stylesheet" href="assets/css/theme-switch.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/theme-switch.css') ?>">
<script src="assets/js/header-dropdowns.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/header-dropdowns.js') ?>" defer></script>
<script src="assets/js/notifications.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/notifications.js') ?>" defer></script>
<script src="assets/js/theme-switch.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/theme-switch.js') ?>" defer></script>

<?php
/**
 * Работа с таблицей bug_reports.
 */

function bug_reports_ensure_table(mysqli $conn): void
{
    try {
        $conn->query("
            CREATE TABLE IF NOT EXISTS bug_reports (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                username VARCHAR(255) NOT NULL DEFAULT '',
                title VARCHAR(255) NOT NULL,
                description TEXT NOT NULL,
                page VARCHAR(255) NOT NULL DEFAULT '',
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                INDEX idx_bug_reports_user (user_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
    } catch (Throwable $e) {
        error_log('bug_reports ensure table error: ' . $e->getMessage());
    }
}

function bug_reports_insert(mysqli $conn, int $user_id, string $username, string $title, string $description, string $page): void
{
    $stmt = $conn->prepare("
        INSERT INTO bug_reports (user_id, username, title, description, page)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param('issss', $user_id, $username, $title, $description, $page);
    $stmt->execute();
    $stmt->close();
}

/**
 * Проверяет данные формы. Возвращает текст ошибки или пустую строку.
 */
function bug_reports_validate(string $title, string $description, string $page): string
{
    if ($title === '') {
        return 'Введите название ошибки.';
    }
    if ($description === '') {
        return 'Опишите проблему.';
    }
    if (mb_strlen($title, 'UTF-8') > 255) {
        return 'Название ошибки слишком длинное.';
    }
    if (mb_strlen($page, 'UTF-8') > 255) {
        return 'Поле «Где произошла ошибка?» слишком длинное.';
    }
    if (mb_strlen($description, 'UTF-8') > 10000) {
        return 'Описание ошибки слишком длинное.';
    }
    return '';
}

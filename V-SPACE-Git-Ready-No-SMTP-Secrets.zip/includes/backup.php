<?php
/**
 * Резервные копии V SPACE: создание, проверка, скачивание, откат.
 *
 * Бэкап — один архив. Формат выбирается автоматически:
 *   .zip      если на сервере включено расширение PHP zip
 *   .tar.gz   если zip нет, но есть zlib (чистый PHP, расширение zip не нужно)
 *   .tar      если нет ни zip, ни zlib (без сжатия)
 * Внутри архива:
 *   database.sql   дамп всех таблиц (если тип db/full)
 *   site/...       файлы сайта (если тип code/full)
 *   secrets/...    копия .env и storage/photo.key (ключи шифрования; нужны при переносе)
 *   manifest.json  описание и контрольная сумма дампа
 *
 * Работает на чистом PHP (mysqli), mysqldump и shell не нужны.
 * Использует только reports.php (уровень 4) и backup_cron.php (консоль).
 */

if (defined('VSB_LOADED')) {
    return;
}
define('VSB_LOADED', true);

const VSB_SQL_SEP = '/*!VS-END*/';
const VSB_KEEP_AUTO = 10;                    // сколько автобэкапов «перед откатом» хранить
const VSB_KEEP_CRON = 14;                    // сколько бэкапов по расписанию хранить
const VSB_KEEP_TABLES = ['admin_audit_log']; // эти таблицы откат не затрагивает (журнал действий)
const VSB_ID_REGEX = '/^vspace-(db|code|full)-\d{8}-\d{6}-[a-f0-9]{6}$/';

function vsb_root(): string
{
    return dirname(__DIR__);
}

function vsb_starts(string $s, string $prefix): bool
{
    return strncmp($s, $prefix, strlen($prefix)) === 0;
}

/** Папка бэкапов. По умолчанию storage/backups; можно вынести за сайт: BACKUP_DIR в .env. */
function vsb_dir(): string
{
    $custom = function_exists('env') ? trim((string)env('BACKUP_DIR', '')) : '';
    $dir = $custom !== '' ? rtrim($custom, '/\\') : vsb_root() . '/storage/backups';
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
        throw new RuntimeException('Не удалось создать папку бэкапов: ' . $dir);
    }
    if (!is_writable($dir)) {
        throw new RuntimeException('Папка бэкапов недоступна для записи: ' . $dir);
    }
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
    }
    if (!is_file($dir . '/index.html')) {
        @file_put_contents($dir . '/index.html', '');
    }
    return $dir;
}

/** ZipArchive::close() на уже закрытом объекте в PHP 8 бросает исключение — гасим его. */
function vsb_zip_close_quiet(ZipArchive $zip): void
{
    try {
        $zip->close();
    } catch (Throwable $e) {
        // уже закрыт
    }
}

// ------------------------------------------------------------
// Формат архива: ZIP (если на сервере есть расширение zip),
// иначе .tar.gz (нужен zlib) или обычный .tar — всё на чистом PHP.
// ------------------------------------------------------------

const VSB_EXTS = ['zip', 'tar.gz', 'tar'];

/** В каком формате создаются новые бэкапы на этом сервере. */
function vsb_format(): string
{
    if (class_exists('ZipArchive')) {
        return 'zip';
    }
    return function_exists('gzopen') ? 'tar.gz' : 'tar';
}

/** Формат по имени файла. */
function vsb_ext_of(string $path): string
{
    if (preg_match('/\.tar\.gz$/', $path)) {
        return 'tar.gz';
    }
    if (preg_match('/\.tar$/', $path)) {
        return 'tar';
    }
    return 'zip';
}

/** Запись ZIP-архива (расширение zip). */
class VsbZipWriter
{
    private ZipArchive $zip;
    private string $path;
    private int $added = 0;

    public function __construct(string $path)
    {
        $this->path = $path;
        $this->zip = new ZipArchive();
        if ($this->zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Не удалось создать архив бэкапа.');
        }
    }

    public function addFile(string $entry, string $abs, bool $store = false): void
    {
        $this->zip->addFile($abs, $entry);
        if ($store) {
            $this->zip->setCompressionName($entry, ZipArchive::CM_STORE);
        }
        // libzip держит открытые файлы до close(): периодически сбрасываем, чтобы не упереться в лимит
        if (++$this->added % 150 === 0) {
            if (!$this->zip->close() || $this->zip->open($this->path) !== true) {
                throw new RuntimeException('Ошибка записи архива бэкапа.');
            }
        }
    }

    public function addString(string $entry, string $data): void
    {
        $this->zip->addFromString($entry, $data);
    }

    public function close(): void
    {
        if (!$this->zip->close()) {
            throw new RuntimeException('Не удалось завершить запись архива (возможно, не хватает места на диске).');
        }
    }

    public function abort(): void
    {
        vsb_zip_close_quiet($this->zip);
    }
}

/** Запись TAR (с gzip или без) — без расширения zip, потоково. */
class VsbTarWriter
{
    private $fh;
    private bool $gz;

    public function __construct(string $path, bool $gz)
    {
        $this->gz = $gz;
        $this->fh = $gz ? @gzopen($path, 'wb6') : @fopen($path, 'wb');
        if (!$this->fh) {
            throw new RuntimeException('Не удалось создать архив бэкапа.');
        }
    }

    private function write(string $data): void
    {
        if ($data === '') {
            return;
        }
        $n = $this->gz ? @gzwrite($this->fh, $data) : @fwrite($this->fh, $data);
        if ($n === false || $n < strlen($data)) {
            throw new RuntimeException('Ошибка записи архива (возможно, не хватает места на диске).');
        }
    }

    private function header(string $name, int $size, int $mtime, int $mode): string
    {
        $prefix = '';
        if (strlen($name) > 100) {
            for ($i = min(155, strlen($name) - 1); $i > 0; $i--) {
                if ($name[$i] === '/' && strlen($name) - $i - 1 <= 100) {
                    $prefix = substr($name, 0, $i);
                    $name = substr($name, $i + 1);
                    break;
                }
            }
            if (strlen($name) > 100) {
                throw new RuntimeException('Слишком длинный путь файла для архива: ' . $name);
            }
        }
        if ($size >= 8589934592) {
            throw new RuntimeException('Файл больше 8 ГБ не поместится в tar: ' . $name);
        }
        $h = pack(
            'a100a8a8a8a12a12a8a1a100a6a2a32a32a8a8a155a12',
            $name,
            sprintf('%07o', $mode),
            sprintf('%07o', 0),
            sprintf('%07o', 0),
            sprintf('%011o', $size),
            sprintf('%011o', max(0, $mtime)),
            '        ',   // поле контрольной суммы считается как пробелы
            '0',
            '',
            'ustar',
            '00',
            '', '', '', '',
            $prefix,
            ''
        );
        $sum = 0;
        for ($i = 0; $i < 512; $i++) {
            $sum += ord($h[$i]);
        }
        return substr_replace($h, sprintf('%06o', $sum) . "\0 ", 148, 8);
    }

    private function pad(int $size): void
    {
        $r = $size % 512;
        if ($r !== 0) {
            $this->write(str_repeat("\0", 512 - $r));
        }
    }

    public function addFile(string $entry, string $abs, bool $store = false): void
    {
        $in = @fopen($abs, 'rb');
        if (!$in) {
            throw new RuntimeException('Не удалось прочитать файл: ' . $entry);
        }
        $st = fstat($in);
        $size = (int)($st['size'] ?? 0);
        $left = $size;
        try {
            $this->write($this->header($entry, $size, (int)($st['mtime'] ?? time()), ((int)($st['mode'] ?? 0644)) & 0777));
            while ($left > 0) {
                $chunk = fread($in, min(1048576, $left));
                if ($chunk === false || $chunk === '') {
                    break;
                }
                $this->write($chunk);
                $left -= strlen($chunk);
            }
        } finally {
            fclose($in);
        }
        if ($left > 0) {                       // файл уменьшился, пока его читали
            $this->write(str_repeat("\0", $left));
        }
        $this->pad($size);
    }

    public function addString(string $entry, string $data): void
    {
        $this->write($this->header($entry, strlen($data), time(), 0644));
        $this->write($data);
        $this->pad(strlen($data));
    }

    public function close(): void
    {
        $this->write(str_repeat("\0", 1024));
        $ok = $this->gz ? @gzclose($this->fh) : @fclose($this->fh);
        $this->fh = null;
        if (!$ok) {
            throw new RuntimeException('Не удалось завершить запись архива (возможно, не хватает места на диске).');
        }
    }

    public function abort(): void
    {
        if ($this->fh) {
            $this->gz ? @gzclose($this->fh) : @fclose($this->fh);
            $this->fh = null;
        }
    }
}

/** Последовательное чтение TAR / TAR.GZ. Бросает исключение, если архив повреждён или обрезан. */
class VsbTarReader
{
    private $fh;
    private bool $gz;
    private int $left = 0;   // непрочитанные байты данных текущей записи
    private int $pad = 0;    // выравнивание после неё

    public function __construct(string $path)
    {
        $this->gz = vsb_ext_of($path) === 'tar.gz';
        $this->fh = $this->gz ? @gzopen($path, 'rb') : @fopen($path, 'rb');
        if (!$this->fh) {
            throw new RuntimeException('Не удалось открыть архив бэкапа.');
        }
    }

    private function read(int $n): string
    {
        $out = '';
        while (strlen($out) < $n) {
            $want = $n - strlen($out);
            $chunk = $this->gz ? @gzread($this->fh, $want) : @fread($this->fh, $want);
            if ($chunk === false || $chunk === '') {
                break;
            }
            $out .= $chunk;
        }
        return $out;
    }

    private function skip(int $n): void
    {
        while ($n > 0) {
            $c = $this->read(min($n, 1048576));
            if ($c === '') {
                throw new RuntimeException('архив обрезан: неожиданный конец файла');
            }
            $n -= strlen($c);
        }
    }

    /** @return array{name:string,size:int}|null null — конец архива */
    public function next(): ?array
    {
        $this->skip($this->left + $this->pad);
        $this->left = 0;
        $this->pad = 0;
        while (true) {
            $h = $this->read(512);
            if (strlen($h) < 512) {
                throw new RuntimeException('архив обрезан: нет маркера конца');
            }
            if ($h === str_repeat("\0", 512)) {
                return null;
            }
            $stored = octdec(trim(substr($h, 148, 8), " \0"));
            $sum = 0;
            for ($i = 0; $i < 512; $i++) {
                $sum += ($i >= 148 && $i < 156) ? 32 : ord($h[$i]);
            }
            if ($stored !== $sum) {
                throw new RuntimeException('не сошлась контрольная сумма заголовка');
            }
            $name = rtrim(substr($h, 0, 100), "\0");
            $prefix = rtrim(substr($h, 345, 155), "\0");
            if ($prefix !== '') {
                $name = $prefix . '/' . $name;
            }
            $size = (int)octdec(trim(substr($h, 124, 12), " \0"));
            $pad = ($size % 512) ? 512 - ($size % 512) : 0;
            $type = $h[156];
            if ($type !== '0' && $type !== "\0") {      // каталоги и служебные записи пропускаем
                $this->skip($size + $pad);
                continue;
            }
            $this->left = $size;
            $this->pad = $pad;
            return ['name' => $name, 'size' => $size];
        }
    }

    /** Следующий кусок данных текущей записи; '' — данные закончились. */
    public function chunk(int $max = 1048576): string
    {
        if ($this->left <= 0) {
            return '';
        }
        $c = $this->read(min($max, $this->left));
        if ($c === '') {
            throw new RuntimeException('архив обрезан: неожиданный конец файла');
        }
        $this->left -= strlen($c);
        return $c;
    }

    public function copyTo($dst): void
    {
        while (($c = $this->chunk()) !== '') {
            if (fwrite($dst, $c) !== strlen($c)) {
                throw new RuntimeException('Ошибка записи файла (нет места или прав).');
            }
        }
    }

    public function contents(int $limit = 5242880): string
    {
        if ($this->left > $limit) {
            throw new RuntimeException('служебный файл слишком большой');
        }
        $out = '';
        while (($c = $this->chunk()) !== '') {
            $out .= $c;
        }
        return $out;
    }

    public function close(): void
    {
        if ($this->fh) {
            $this->gz ? @gzclose($this->fh) : @fclose($this->fh);
            $this->fh = null;
        }
    }
}

function vsb_fmt_size(int $bytes): string
{
    $units = ['Б', 'КБ', 'МБ', 'ГБ'];
    $i = 0;
    $v = (float)$bytes;
    while ($v >= 1024 && $i < count($units) - 1) {
        $v /= 1024;
        $i++;
    }
    return ($i === 0 ? (string)(int)$v : number_format($v, 1, ',', ' ')) . ' ' . $units[$i];
}

function vsb_type_name(string $type): string
{
    return ['db' => 'База данных', 'code' => 'Код сайта', 'full' => 'Полный (код + БД)'][$type] ?? $type;
}

// ------------------------------------------------------------
// Файлы сайта
// ------------------------------------------------------------

function vsb_file_excluded(string $rel, bool $withUserData): bool
{
    if ($rel === 'maintenance.lock') {
        return true;
    }
    // архивы в корне сайта (старые копии проекта) не кладём внутрь бэкапа
    if (strpos($rel, '/') === false && preg_match('/\.(zip|rar|7z|tar|gz|tgz)$/i', $rel)) {
        return true;
    }
    if (vsb_starts($rel, 'storage/backups/')) {
        return true;
    }
    if (!$withUserData) {
        if (vsb_starts($rel, 'uploads/')) {
            return true;
        }
        // storage — данные пользователей; ключ шифрования фото берём всегда
        if (vsb_starts($rel, 'storage/') && $rel !== 'storage/photo.key') {
            return true;
        }
    }
    return false;
}

/** @return array<string,string> относительный путь => абсолютный путь */
function vsb_collect(bool $withUserData): array
{
    $root = vsb_root();
    $backupReal = realpath(vsb_dir()) ?: '';
    $dirFilter = function (SplFileInfo $f, $key, $iter) use ($root, $backupReal, $withUserData): bool {
        if ($f->isLink()) {
            return false;
        }
        $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($root) + 1));
        if ($f->isDir()) {
            $real = $f->getRealPath();
            if ($backupReal !== '' && $real !== false
                && ($real === $backupReal || vsb_starts($real, $backupReal . DIRECTORY_SEPARATOR))) {
                return false;
            }
            if ($rel === '.git' || $rel === 'node_modules' || $rel === 'storage/backups') {
                return false;
            }
            if (!$withUserData && $rel === 'uploads') {
                return false;
            }
            return true;
        }
        return !vsb_file_excluded($rel, $withUserData);
    };
    $it = new RecursiveIteratorIterator(
        new RecursiveCallbackFilterIterator(
            new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
            $dirFilter
        ),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    $out = [];
    foreach ($it as $file) {
        if (!$file->isFile()) {
            continue;
        }
        $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
        $out[$rel] = $file->getPathname();
    }
    ksort($out);
    return $out;
}

// ------------------------------------------------------------
// Дамп базы данных
// ------------------------------------------------------------

function vsb_ident(string $name): string
{
    return '`' . str_replace('`', '``', $name) . '`';
}

function vsb_literal(mysqli $conn, $v, int $type): string
{
    if ($v === null) {
        return 'NULL';
    }
    $v = (string)$v;
    if (in_array($type, [0, 1, 2, 3, 4, 5, 8, 9, 13, 246], true)
        && preg_match('/^-?\d+(\.\d+)?([eE][+-]?\d+)?$/', $v)) {
        return $v;
    }
    // BIT, BLOB, BINARY, VARBINARY — в hex; текст, даты, JSON — строкой
    if (in_array($type, [16, 249, 250, 251, 252, 253, 254], true) && vsb_is_binary_value($v)) {
        return $v === '' ? "''" : '0x' . bin2hex($v);
    }
    return "'" . $conn->real_escape_string($v) . "'";
}

/** Значение с «небуквенными» байтами храним hex'ом — это безопаснее для BLOB/BINARY. */
function vsb_is_binary_value(string $v): bool
{
    return $v !== '' && !preg_match('//u', $v);
}

/**
 * Потоково пишет дамп в $path.
 * @return array{tables:int,rows:int,table_list:string[]}
 */
function vsb_dump_database(mysqli $conn, string $path): array
{
    $fh = fopen($path, 'wb');
    if (!$fh) {
        throw new RuntimeException('Не удалось создать временный файл дампа.');
    }
    $emit = function (string $sql) use ($fh): void {
        fwrite($fh, $sql . "\n" . VSB_SQL_SEP . "\n");
    };

    $oldTz = (string)$conn->query('SELECT @@SESSION.time_zone')->fetch_row()[0];
    $conn->query("SET SESSION time_zone = '+00:00'");
    $dbName = (string)$conn->query('SELECT DATABASE()')->fetch_row()[0];

    $tables = [];
    $res = $conn->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
    while ($row = $res->fetch_row()) {
        $tables[] = (string)$row[0];
    }
    $res->free();
    sort($tables);

    $totalRows = 0;
    try {
        $emit("-- V SPACE backup\n-- database: {$dbName}\n-- created: " . gmdate('Y-m-d H:i:s') . " UTC");
        $emit("SET NAMES utf8mb4");
        $emit("SET FOREIGN_KEY_CHECKS=0");
        $emit("SET UNIQUE_CHECKS=0");
        $emit("SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO'");
        $emit("SET time_zone='+00:00'");

        foreach ($tables as $table) {
            $q = vsb_ident($table);

            $cr = $conn->query("SHOW CREATE TABLE {$q}")->fetch_row();
            $emit("DROP TABLE IF EXISTS {$q}");
            $emit((string)$cr[1]);

            // колонки без вычисляемых (их нельзя вставлять)
            $cols = [];
            $cres = $conn->query("SHOW COLUMNS FROM {$q}");
            while ($c = $cres->fetch_assoc()) {
                if (!preg_match('/\b(VIRTUAL|STORED) GENERATED\b/i', (string)($c['Extra'] ?? ''))) {
                    $cols[] = (string)$c['Field'];
                }
            }
            $cres->free();
            if (!$cols) {
                continue;
            }
            $colList = implode(',', array_map('vsb_ident', $cols));

            $data = $conn->query("SELECT {$colList} FROM {$q}", MYSQLI_USE_RESULT);
            $types = [];
            foreach ($data->fetch_fields() as $f) {
                $types[] = (int)$f->type;
            }
            $batch = [];
            $size = 0;
            $flush = function () use (&$batch, &$size, $emit, $q, $colList): void {
                if ($batch) {
                    $emit("INSERT INTO {$q} ({$colList}) VALUES\n" . implode(",\n", $batch));
                    $batch = [];
                    $size = 0;
                }
            };
            while ($row = $data->fetch_row()) {
                $vals = [];
                foreach ($row as $i => $v) {
                    $vals[] = vsb_literal($conn, $v, $types[$i]);
                }
                $line = '(' . implode(',', $vals) . ')';
                $batch[] = $line;
                $size += strlen($line);
                $totalRows++;
                if ($size > 400000 || count($batch) >= 500) {
                    $flush();
                }
            }
            $data->free();
            $flush();
        }

        $emit("SET FOREIGN_KEY_CHECKS=1");
        $emit("SET UNIQUE_CHECKS=1");
    } finally {
        fclose($fh);
        try {
            $conn->query("SET SESSION time_zone = '" . $conn->real_escape_string($oldTz) . "'");
        } catch (Throwable $e) {
            error_log('backup: не удалось вернуть time_zone: ' . $e->getMessage());
        }
    }

    return ['tables' => count($tables), 'rows' => $totalRows, 'table_list' => $tables];
}

/** Выполняет дамп из файла. Таблицы из VSB_KEEP_TABLES пропускаются. */
function vsb_restore_database(mysqli $conn, string $sqlPath): array
{
    $fh = fopen($sqlPath, 'rb');
    if (!$fh) {
        throw new RuntimeException('Не удалось открыть дамп базы данных.');
    }
    $oldTz = (string)$conn->query('SELECT @@SESSION.time_zone')->fetch_row()[0];
    $oldMode = (string)$conn->query('SELECT @@SESSION.sql_mode')->fetch_row()[0];

    $done = 0;
    $skipped = 0;
    $buf = '';
    try {
        while (($line = fgets($fh)) !== false) {
            if (rtrim($line, "\r\n") !== VSB_SQL_SEP) {
                $buf .= $line;
                continue;
            }
            $sql = trim($buf);
            $buf = '';
            if ($sql === '' || vsb_starts($sql, '--')) {
                continue;
            }
            if (preg_match('/^(?:DROP TABLE IF EXISTS|CREATE TABLE|INSERT INTO)\s+`((?:[^`]|``)+)`/i', $sql, $m)
                && in_array(str_replace('``', '`', $m[1]), VSB_KEEP_TABLES, true)) {
                $skipped++;
                continue;
            }
            try {
                if ($conn->query($sql) === false) {
                    throw new RuntimeException($conn->error);
                }
            } catch (Throwable $e) {
                throw new RuntimeException(
                    'Ошибка при восстановлении БД: ' . $e->getMessage() . ' · запрос: ' . mb_substr($sql, 0, 120)
                );
            }
            $done++;
        }
    } finally {
        fclose($fh);
        try {
            $conn->query('SET FOREIGN_KEY_CHECKS=1');
            $conn->query('SET UNIQUE_CHECKS=1');
            $conn->query("SET SESSION sql_mode = '" . $conn->real_escape_string($oldMode) . "'");
            $conn->query("SET SESSION time_zone = '" . $conn->real_escape_string($oldTz) . "'");
        } catch (Throwable $e) {
            error_log('backup: не удалось вернуть параметры сессии: ' . $e->getMessage());
        }
    }
    return ['statements' => $done, 'skipped' => $skipped];
}

// ------------------------------------------------------------
// Создание / список / проверка / удаление
// ------------------------------------------------------------

/**
 * @param array{id?:int,name?:string} $actor
 * @return array<string,mixed> метаданные созданного бэкапа
 */
function vsb_create(mysqli $conn, string $type, bool $withUserData, string $label, array $actor = [], string $origin = 'manual', bool $prune = true): array
{
    if (!in_array($type, ['db', 'code', 'full'], true)) {
        throw new InvalidArgumentException('Неизвестный тип бэкапа.');
    }
    @set_time_limit(0);
    ignore_user_abort(true);

    $ext = vsb_format();
    $dir = vsb_dir();
    $id = 'vspace-' . $type . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3));
    $part = $dir . '/' . $id . '.' . $ext . '.part';
    $final = $dir . '/' . $id . '.' . $ext;
    $sqlTmp = $dir . '/' . $id . '.sql.part';

    $db = ['tables' => 0, 'rows' => 0, 'table_list' => []];
    $fileCount = 0;
    $sqlSha = null;
    $writer = null;

    try {
        $writer = $ext === 'zip' ? new VsbZipWriter($part) : new VsbTarWriter($part, $ext === 'tar.gz');

        if ($type !== 'code') {
            $db = vsb_dump_database($conn, $sqlTmp);
            $sqlSha = hash_file('sha256', $sqlTmp);
            $writer->addFile('database.sql', $sqlTmp);
        }

        if ($type !== 'db') {
            $stored = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'mp3', 'mp4', 'webm', 'ogg', 'zip', 'gz', 'bin', 'woff2'];
            foreach (vsb_collect($withUserData) as $rel => $abs) {
                $writer->addFile('site/' . $rel, $abs, in_array(strtolower(pathinfo($rel, PATHINFO_EXTENSION)), $stored, true));
                $fileCount++;
            }
        }

        // Секреты нужны, чтобы после переноса на новый сервер расшифровать сообщения и фото.
        $hasSecrets = false;
        if (function_exists('env_file_path')) {
            $envFile = env_file_path();
            if ($envFile !== null && is_file($envFile)) {
                $writer->addFile('secrets/env', $envFile);
                $hasSecrets = true;
            }
        }
        $photoKey = vsb_root() . '/storage/photo.key';
        if (is_file($photoKey)) {
            $writer->addFile('secrets/photo.key', $photoKey);
            $hasSecrets = true;
        }

        $dbName = (string)$conn->query('SELECT DATABASE()')->fetch_row()[0];
        $manifest = [
            'format'            => 1,
            'archive'           => $ext,
            'app'               => 'V SPACE',
            'id'                => $id,
            'type'              => $type,
            'label'             => $label,
            'origin'            => $origin,
            'created_at'        => date('c'),
            'created_by'        => (int)($actor['id'] ?? 0),
            'php'               => PHP_VERSION,
            'database'          => $dbName,
            'tables'            => $db['tables'],
            'rows'              => $db['rows'],
            'table_list'        => $db['table_list'],
            'files'             => $fileCount,
            'includes_userdata' => $type !== 'db' && $withUserData,
            'has_secrets'       => $hasSecrets,
            'sql_sha256'        => $sqlSha,
        ];
        $writer->addString('manifest.json', json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

        $writer->close();
        if (!rename($part, $final)) {
            throw new RuntimeException('Не удалось сохранить архив бэкапа.');
        }
    } catch (Throwable $e) {
        if ($writer !== null) {
            $writer->abort();
        }
        @unlink($part);
        @unlink($sqlTmp);
        throw $e;
    }
    @unlink($sqlTmp);
    @chmod($final, 0640);

    $meta = [
        'id'                => $id,
        'file'              => $id . '.' . $ext,
        'format'            => $ext,
        'type'              => $type,
        'label'             => $label,
        'origin'            => $origin,
        'created_at'        => $manifest['created_at'],
        'created_by'        => (int)($actor['id'] ?? 0),
        'created_by_name'   => (string)($actor['name'] ?? ($origin === 'cron' ? 'cron' : '')),
        'size'              => (int)filesize($final),
        'tables'            => $db['tables'],
        'rows'              => $db['rows'],
        'files'             => $fileCount,
        'includes_userdata' => $manifest['includes_userdata'],
        'zip_sha256'        => hash_file('sha256', $final),   // контрольная сумма всего архива (имя ключа историческое)
    ];
    @file_put_contents($dir . '/' . $id . '.json', json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    $check = vsb_verify($id);
    if (!$check['ok']) {
        vsb_delete($id);
        throw new RuntimeException('Созданный бэкап не прошёл проверку: ' . $check['error']);
    }

    if ($prune) {
        vsb_prune();
    }
    return $meta;
}

/** @return array<int,array<string,mixed>> новые сверху */
function vsb_list(): array
{
    $dir = vsb_dir();
    $paths = [];
    foreach (VSB_EXTS as $e) {
        foreach (glob($dir . '/vspace-*.' . $e) ?: [] as $p) {
            $paths[] = $p;
        }
    }
    $items = [];
    foreach ($paths as $archPath) {
        $id = preg_replace('/\.(zip|tar\.gz|tar)$/', '', basename($archPath));
        if (!preg_match(VSB_ID_REGEX, $id)) {
            continue;
        }
        $meta = [];
        $jsonPath = $dir . '/' . $id . '.json';
        if (is_file($jsonPath)) {
            $decoded = json_decode((string)file_get_contents($jsonPath), true);
            if (is_array($decoded)) {
                $meta = $decoded;
            }
        }
        $meta += [
            'id'              => $id,
            'file'            => basename($archPath),
            'format'          => vsb_ext_of($archPath),
            'type'            => explode('-', $id)[1],
            'label'           => '',
            'origin'          => 'manual',
            'created_at'      => date('c', (int)filemtime($archPath)),
            'created_by_name' => '',
            'includes_userdata' => false,
        ];
        $meta['size'] = (int)filesize($archPath);
        $items[] = $meta;
    }
    usort($items, function ($a, $b) {
        return strcmp((string)$b['created_at'], (string)$a['created_at']);
    });
    return $items;
}

function vsb_find(string $id): ?string
{
    if (!preg_match(VSB_ID_REGEX, $id)) {
        return null;
    }
    foreach (VSB_EXTS as $e) {
        $path = vsb_dir() . '/' . $id . '.' . $e;
        if (is_file($path)) {
            return $path;
        }
    }
    return null;
}

/** @return array{ok:bool,error:string,manifest:?array} */
function vsb_verify(string $id): array
{
    $path = vsb_find($id);
    if ($path === null) {
        return ['ok' => false, 'error' => 'Файл бэкапа не найден.', 'manifest' => null];
    }

    if (vsb_ext_of($path) === 'zip') {
        if (!class_exists('ZipArchive')) {
            return ['ok' => false, 'error' => 'Это ZIP-бэкап, а на сервере сейчас нет расширения PHP zip — включите его, чтобы открыть этот архив.', 'manifest' => null];
        }
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CHECKCONS) !== true) {
            return ['ok' => false, 'error' => 'Архив повреждён или не является ZIP.', 'manifest' => null];
        }
        $raw = $zip->getFromName('manifest.json');
        $manifest = $raw !== false ? json_decode($raw, true) : null;
        if (!is_array($manifest)) {
            $zip->close();
            return ['ok' => false, 'error' => 'В архиве нет manifest.json.', 'manifest' => null];
        }

        if (!empty($manifest['sql_sha256'])) {
            $stream = $zip->getStream('database.sql');
            if (!$stream) {
                $zip->close();
                return ['ok' => false, 'error' => 'В архиве нет database.sql.', 'manifest' => $manifest];
            }
            $ctx = hash_init('sha256');
            while (!feof($stream)) {
                $chunk = fread($stream, 1048576);
                if ($chunk === false) {
                    break;
                }
                hash_update($ctx, $chunk);
            }
            fclose($stream);
            if (!hash_equals((string)$manifest['sql_sha256'], hash_final($ctx))) {
                $zip->close();
                return ['ok' => false, 'error' => 'Контрольная сумма дампа БД не совпала — архив повреждён.', 'manifest' => $manifest];
            }
        }
        $zip->close();
    } else {
        // TAR / TAR.GZ: один проход — проверяем заголовки, забираем manifest и считаем хэш дампа
        $reader = null;
        $raw = null;
        $sqlHash = null;
        try {
            $reader = new VsbTarReader($path);
            while (($entry = $reader->next()) !== null) {
                if ($entry['name'] === 'manifest.json') {
                    $raw = $reader->contents();
                } elseif ($entry['name'] === 'database.sql') {
                    $ctx = hash_init('sha256');
                    while (($c = $reader->chunk()) !== '') {
                        hash_update($ctx, $c);
                    }
                    $sqlHash = hash_final($ctx);
                }
            }
            $reader->close();
        } catch (Throwable $e) {
            if ($reader !== null) {
                $reader->close();
            }
            return ['ok' => false, 'error' => 'Архив повреждён: ' . $e->getMessage() . '.', 'manifest' => null];
        }
        $manifest = $raw !== null ? json_decode($raw, true) : null;
        if (!is_array($manifest)) {
            return ['ok' => false, 'error' => 'В архиве нет manifest.json.', 'manifest' => null];
        }
        if (!empty($manifest['sql_sha256'])) {
            if ($sqlHash === null) {
                return ['ok' => false, 'error' => 'В архиве нет database.sql.', 'manifest' => $manifest];
            }
            if (!hash_equals((string)$manifest['sql_sha256'], $sqlHash)) {
                return ['ok' => false, 'error' => 'Контрольная сумма дампа БД не совпала — архив повреждён.', 'manifest' => $manifest];
            }
        }
    }

    $jsonPath = vsb_dir() . '/' . $id . '.json';
    if (is_file($jsonPath)) {
        $meta = json_decode((string)file_get_contents($jsonPath), true);
        if (is_array($meta) && !empty($meta['zip_sha256'])
            && !hash_equals((string)$meta['zip_sha256'], (string)hash_file('sha256', $path))) {
            return ['ok' => false, 'error' => 'Контрольная сумма архива не совпала — файл изменён или повреждён.', 'manifest' => $manifest];
        }
    }
    return ['ok' => true, 'error' => '', 'manifest' => $manifest];
}

function vsb_delete(string $id): bool
{
    $path = vsb_find($id);
    if ($path === null) {
        return false;
    }
    $ok = @unlink($path);
    @unlink(vsb_dir() . '/' . $id . '.json');
    return $ok;
}

/** Удаляет лишние автобэкапы (ручные не трогаем никогда). */
function vsb_prune(array $protect = []): void
{
    $count = ['auto' => 0, 'cron' => 0];
    $limit = ['auto' => VSB_KEEP_AUTO, 'cron' => VSB_KEEP_CRON];
    foreach (vsb_list() as $item) {   // уже от новых к старым
        $origin = (string)($item['origin'] ?? 'manual');
        if (!isset($count[$origin])) {
            continue;
        }
        if (++$count[$origin] > $limit[$origin] && !in_array((string)$item['id'], $protect, true)) {
            vsb_delete((string)$item['id']);
        }
    }
}

// ------------------------------------------------------------
// Откат
// ------------------------------------------------------------

function vsb_safe_rel(string $rel): bool
{
    if ($rel === '' || strpos($rel, "\0") !== false || strpos($rel, '\\') !== false
        || $rel[0] === '/' || preg_match('/^[A-Za-z]:/', $rel)) {
        return false;
    }
    foreach (explode('/', $rel) as $part) {
        if ($part === '..') {
            return false;
        }
    }
    return true;
}

/**
 * Записывает один файл сайта из архива (атомарно, через временный файл).
 * $copy(resource $dst) должна скопировать содержимое файла в $dst.
 *
 * @param array<string,mixed> $result
 */
function vsb_restore_site_file(string $rel, callable $copy, array &$result): void
{
    // секреты и служебное не перезаписываем: .env, замок техрежима, сами бэкапы
    if (!vsb_safe_rel($rel) || $rel === '.env' || $rel === 'maintenance.lock'
        || vsb_starts($rel, 'storage/backups/')) {
        $result['skipped_files']++;
        return;
    }
    $target = vsb_root() . '/' . $rel;
    $targetDir = dirname($target);
    if (!is_dir($targetDir) && !@mkdir($targetDir, 0755, true) && !is_dir($targetDir)) {
        throw new RuntimeException('Не удалось создать папку: ' . $rel);
    }
    $tmp = $target . '.vsb-tmp';
    $dst = @fopen($tmp, 'wb');
    if (!$dst) {
        throw new RuntimeException('Нет прав на запись: ' . $rel);
    }
    try {
        $copy($dst);
    } catch (Throwable $e) {
        fclose($dst);
        @unlink($tmp);
        throw $e;
    }
    fclose($dst);
    if (!rename($tmp, $target)) {
        @unlink($tmp);
        throw new RuntimeException('Не удалось заменить файл: ' . $rel);
    }
    $result['files']++;
}

/**
 * Откат из бэкапа. Перед откатом автоматически создаётся страховочный бэкап текущего состояния.
 *
 * @param array{id?:int,name?:string} $actor
 * @return array<string,mixed>
 */
function vsb_restore(mysqli $conn, string $id, bool $doDb, bool $doFiles, array $actor = []): array
{
    if (!$doDb && !$doFiles) {
        throw new InvalidArgumentException('Выберите, что восстанавливать: базу данных и/или файлы.');
    }
    $path = vsb_find($id);
    if ($path === null) {
        throw new RuntimeException('Бэкап не найден.');
    }
    $check = vsb_verify($id);
    if (!$check['ok']) {
        throw new RuntimeException('Бэкап не прошёл проверку: ' . $check['error']);
    }
    $manifest = $check['manifest'];
    $type = (string)($manifest['type'] ?? '');
    if ($doDb && $type === 'code') {
        throw new RuntimeException('В этом бэкапе нет базы данных.');
    }
    if ($doFiles && $type === 'db') {
        throw new RuntimeException('В этом бэкапе нет файлов сайта.');
    }

    @set_time_limit(0);
    ignore_user_abort(true);

    // 1. Страховка: бэкап того, что есть сейчас
    $safetyType = ($doDb && $doFiles) ? 'full' : ($doDb ? 'db' : 'code');
    $safety = vsb_create($conn, $safetyType, false, 'Автобэкап перед откатом на ' . $id, $actor, 'auto', false);

    // 2. На время отката закрываем сайт для посетителей (maintenance.php), снимем сами
    $lock = vsb_root() . '/maintenance.lock';
    $lockCreated = false;
    if (!is_file($lock) && @file_put_contents($lock, (string)(time() + 300)) !== false) {
        $lockCreated = true;
    }

    $result = ['safety_id' => $safety['id'], 'db' => null, 'files' => 0, 'skipped_files' => 0];
    $isZip = vsb_ext_of($path) === 'zip';
    $zip = null;
    $reader = null;
    $tmpSql = null;
    try {
        if ($isZip) {
            $zip = new ZipArchive();
            if ($zip->open($path) !== true) {
                throw new RuntimeException('Не удалось открыть архив бэкапа.');
            }

            if ($doDb) {
                $tmpSql = vsb_dir() . '/' . $id . '.restore.sql.tmp';
                $in = $zip->getStream('database.sql');
                if (!$in) {
                    throw new RuntimeException('В архиве нет database.sql.');
                }
                $out = fopen($tmpSql, 'wb');
                stream_copy_to_stream($in, $out);
                fclose($in);
                fclose($out);
                $result['db'] = vsb_restore_database($conn, $tmpSql);
            }

            if ($doFiles) {
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $name = (string)$zip->getNameIndex($i);
                    if (!vsb_starts($name, 'site/') || substr($name, -1) === '/') {
                        continue;
                    }
                    vsb_restore_site_file(substr($name, 5), function ($dst) use ($zip, $name) {
                        $src = $zip->getStream($name);
                        if (!$src) {
                            throw new RuntimeException('Не удалось прочитать из архива: ' . $name);
                        }
                        stream_copy_to_stream($src, $dst);
                        fclose($src);
                    }, $result);
                }
            }
        } else {
            // TAR / TAR.GZ: database.sql лежит в начале архива, дальше site/... — один проход
            $reader = new VsbTarReader($path);
            while (($entry = $reader->next()) !== null) {
                $name = $entry['name'];
                if ($name === 'database.sql') {
                    if ($doDb) {
                        $tmpSql = vsb_dir() . '/' . $id . '.restore.sql.tmp';
                        $out = fopen($tmpSql, 'wb');
                        if (!$out) {
                            throw new RuntimeException('Не удалось создать временный файл дампа.');
                        }
                        try {
                            $reader->copyTo($out);
                        } finally {
                            fclose($out);
                        }
                        $result['db'] = vsb_restore_database($conn, $tmpSql);
                    }
                    continue;
                }
                if ($doFiles && vsb_starts($name, 'site/')) {
                    vsb_restore_site_file(substr($name, 5), function ($dst) use ($reader) {
                        $reader->copyTo($dst);
                    }, $result);
                }
            }
            if ($doDb && $result['db'] === null) {
                throw new RuntimeException('В архиве нет database.sql.');
            }
        }
    } finally {
        if ($zip !== null) {
            vsb_zip_close_quiet($zip);
        }
        if ($reader !== null) {
            $reader->close();
        }
        if ($tmpSql !== null) {
            @unlink($tmpSql);
        }
        if ($lockCreated) {
            @unlink($lock);
        }
    }
    if (function_exists('opcache_reset')) {
        @opcache_reset();
    }
    vsb_prune([$id, (string)$safety['id']]);
    return $result;
}

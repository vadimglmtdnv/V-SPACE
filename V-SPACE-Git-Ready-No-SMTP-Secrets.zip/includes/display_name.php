<?php
/**
 * userDisplayName() — имя для показа: имя и фамилия из профиля (user_profiles),
 * а если они не заполнены — обычный username.
 * Если переданное соединение уже закрыто, функция открывает своё на один запрос.
 */
if (!function_exists('userDisplayName')) {
    function userDisplayName($conn, int $uid, string $fallback = ''): string
    {
        static $cache = [];
        if ($uid <= 0) return $fallback;
        if (!array_key_exists($uid, $cache)) {
            $name = null;
            $sql = "SELECT TRIM(CONCAT_WS(' ', first_name, last_name)) AS n FROM user_profiles WHERE user_id = ? LIMIT 1";
            $run = function ($c) use ($sql, $uid) {
                $stmt = $c->prepare($sql);
                if (!$stmt) return null;
                $stmt->bind_param('i', $uid);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                return trim((string)($row['n'] ?? ''));
            };
            if ($conn instanceof mysqli) {
                try { $name = $run($conn); } catch (Throwable $e) { $name = null; }
            }
            if ($name === null) {                       // соединения нет или оно закрыто
                try {
                    if (!function_exists('db_connect')) require_once __DIR__ . '/db.php';
                    $own = db_connect();
                    $name = $run($own);
                    $own->close();
                } catch (Throwable $e) {
                    $name = null;
                }
            }
            $cache[$uid] = (string)($name ?? '');
        }
        return $cache[$uid] !== '' ? $cache[$uid] : $fallback;
    }
}

<?php
/**
 * Завершение сеансов на всех устройствах.
 *
 * Как работает: у пользователя в БД есть счётчик users.session_version.
 * Каждая PHP-сессия запоминает значение счётчика, которое она видела.
 * Кнопка «Выйти со всех устройств» увеличивает счётчик — и при следующем
 * запросе любая другая сессия видит несовпадение и разлогинивается.
 * Заодно сбрасывается remember_token («запомнить меня»).
 *
 * Чтобы выход действовал на ВСЕХ страницах сайта, вызовите
 * enforceSessionVersion($conn, $user_id) там, где страницы проверяют вход.
 */

function ensureSessionVersionColumn(mysqli $conn): void {
    static $done = false;
    if ($done) {
        return;
    }
    $res = $conn->query("SHOW COLUMNS FROM users LIKE 'session_version'");
    if ($res && $res->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN session_version INT UNSIGNED NOT NULL DEFAULT 0");
    }
    $done = true;
}

function destroyCurrentSession(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

/** Делает недействительными все сеансы пользователя (включая «запомнить меня»). */
function revokeAllSessions(mysqli $conn, int $user_id): void {
    ensureSessionVersionColumn($conn);
    $stmt = $conn->prepare("
        UPDATE users
        SET session_version = session_version + 1,
            remember_token = NULL, token_expires = NULL
        WHERE id = ?
    ");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $stmt->close();
}

/** Если сеанс устарел (выполнен «выйти со всех устройств») — завершает его. */
function enforceSessionVersion(mysqli $conn, int $user_id): void {
    ensureSessionVersionColumn($conn);
    $stmt = $conn->prepare("SELECT session_version FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) {
        return;
    }
    $db_version = (int)$row['session_version'];

    // Сеанс, который ещё не видел счётчик, запоминает его при первом запросе.
    if (!isset($_SESSION['session_version'])) {
        $_SESSION['session_version'] = $db_version;
        return;
    }
    if ((int)$_SESSION['session_version'] !== $db_version) {
        destroyCurrentSession();
        header('Location: login.php');
        exit;
    }
}

<?php
// Разрешения для сайта: микрофон, камера, показ экрана и автозвук — разрешены, геоданные — запрещены
if (!headers_sent()) { header('Permissions-Policy: microphone=(self), camera=(self), display-capture=(self), autoplay=(self), fullscreen=(self), speaker-selection=(self), geolocation=()'); }


/**
 * Общие функции для страниц: сессия, тема, пользователь, уведомления.
 */

/** Срок жизни сессии в секундах; активная сессия продлевается при каждом запросе. */
function playerchat_session_lifetime(): int
{
    return 10 * 365 * 24 * 60 * 60;
}

/** Запускает сессию с безопасными настройками и продлевает срок действия cookie. */
function start_secure_session(): void
{
    $lifetime = playerchat_session_lifetime();
    $alreadyActive = session_status() === PHP_SESSION_ACTIVE;

    if (!$alreadyActive) {
        foreach ([
            'session.gc_maxlifetime' => (string)$lifetime,
            'session.cookie_lifetime' => (string)$lifetime,
            'session.cookie_httponly' => '1',
            'session.cookie_samesite' => 'Lax',
            'session.use_strict_mode' => '1',
            'session.use_only_cookies' => '1',
        ] as $setting => $value) {
            if (ini_set($setting, $value) === false) {
                throw new RuntimeException('Не удалось настроить параметр сессии: ' . $setting);
            }
        }
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            if (ini_set('session.cookie_secure', '1') === false) {
                throw new RuntimeException('Не удалось включить защищённую cookie сессии.');
            }
        }

        if (!session_start()) {
            throw new RuntimeException('Не удалось запустить сессию.');
        }
    }

    if (
        session_status() === PHP_SESSION_ACTIVE
        && isset($_COOKIE[session_name()])
        && !headers_sent()
    ) {
        $params = session_get_cookie_params();
        if (!setcookie(session_name(), session_id(), [
            'expires'  => time() + $lifetime,
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?: 'Lax',
        ])) {
            error_log('start_secure_session: не удалось продлить cookie сессии.');
        }
    }
}

/**
 * Возвращает текущую тему (dark | light | system).
 * Если передан ?theme=..., сохраняет её в cookie и перенаправляет на $redirect.
 */
function resolve_theme(string $redirect): string
{
    $allowed = ['dark', 'light', 'system'];

    if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed, true)) {
        setcookie('theme', $_GET['theme'], [
            'expires'  => time() + 365 * 24 * 60 * 60,
            'path'     => '/',
            'samesite' => 'Lax',
        ]);
        header('Location: ' . $redirect);
        exit;
    }

    $cookie = $_COOKIE['theme'] ?? '';
    return in_array($cookie, $allowed, true) ? $cookie : 'dark';
}

/** Данные пользователя по id или null. */
function fetch_user(mysqli $conn, int $user_id): ?array
{
    $stmt = $conn->prepare('SELECT id, username, avatar, status FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $user ?: null;
}

/**
 * Уведомления для колокольчика в шапке.
 *
 * @return array{0: array, 1: int} [список, количество непрочитанных]
 */
function fetch_notifications(mysqli $conn, int $user_id): array
{
    $list  = [];
    $count = 0;

    try {
        $stmt = $conn->prepare("
            SELECT n.id, n.type, n.message, n.link, n.is_read, n.created_at,
                   COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar AS sender_avatar
            FROM notifications n
            LEFT JOIN users u ON u.id = n.sender_id
            LEFT JOIN user_profiles sp ON sp.user_id = u.id
            WHERE n.user_id = ?
              AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
            ORDER BY n.created_at DESC
            LIMIT 30
        ");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $list[] = $row;
        }
        $stmt->close();

        $stmt = $conn->prepare("
            SELECT COUNT(*) AS c FROM notifications
            WHERE user_id = ? AND is_read = 0
              AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $count = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
    } catch (Throwable $e) {
        // таблицы уведомлений может ещё не быть — страница от этого не ломается
        return [[], 0];
    }

    return [$list, $count];
}

function formatTimeAgo(string $datetime): string
{
    $ts   = strtotime($datetime);
    $diff = time() - $ts;
    if ($diff < 60)     return 'только что';
    if ($diff < 3600)   return floor($diff / 60) . ' м';
    if ($diff < 86400)  return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $ts);
}

function formatNotificationIcon(string $type): string
{
    $icons = [
        'friend_request' => '👋', 'friend_accepted' => '✅', 'friend_removed' => '❌',
        'like' => '❤️', 'comment' => '💭', 'repost' => '🔁', 'message' => '💬',
        'news' => '📰', 'tag' => '🔖', 'mention' => '@', 'info' => 'ℹ️',
    ];
    return $icons[$type] ?? '🔔';
}

/** Короткий htmlspecialchars для шаблонов. */
function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

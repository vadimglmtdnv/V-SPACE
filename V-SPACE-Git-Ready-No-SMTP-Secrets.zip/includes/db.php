<?php
/**
 * Единое подключение к базе данных.
 * Логин и пароль берутся из .env (см. includes/env.php), в коде их нет.
 */

require_once __DIR__ . '/env.php';

/**
 * Возвращает подключение mysqli с кодировкой utf8mb4.
 *
 * @param bool|null $strict true  — ошибки mysqli выбрасываются как исключения;
 *                          false — исключения выключены;
 *                          null  — режим не меняется (как в старом коде страниц,
 *                                  где mysqli_report() не вызывался).
 *
 * @throws RuntimeException  если DB_USER не задан в .env или legacy-конфигурации
 * @throws mysqli_sql_exception при ошибке подключения в строгом режиме
 */
function db_connect(?bool $strict = null, ?string $database = null, bool $useConfiguredDatabase = true): mysqli
{
    if ($strict === true) {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    } elseif ($strict === false) {
        mysqli_report(MYSQLI_REPORT_OFF);
    }

    if (!env_has('DB_USER') && (!defined('DB_USER') || DB_USER === '')) {
        // Подробности только в лог, без секретов
        error_log('db_connect: DB_USER не задан (нет .env или legacy-конфигурации)');
        throw new RuntimeException('Не настроено подключение к базе данных.');
    }

    $host = (string)env('DB_HOST', DB_HOST);
    $user = (string)env('DB_USER', DB_USER);
    $password = (string)env('DB_PASS', DB_PASS);
    $defaultDatabase = (string)env('DB_NAME', DB_NAME);
    $selectedDatabase = $useConfiguredDatabase ? ($database ?? $defaultDatabase) : null;
    $conn = new mysqli($host, $user, $password, $selectedDatabase);

    // Если подключиться не удалось (не строгий режим) — вызывающий код сам проверит connect_error.
    if (!$conn->connect_errno) {
        $conn->set_charset('utf8mb4');
    }

    return $conn;
}

<?php
// includes/shell.php — общие функции «оболочки» страницы (шапка + нижняя панель).
// Подключается из includes/site_header.php и страниц. Функции объявлены под защитой
// function_exists, поэтому не конфликтуют с одноимёнными функциями на самих страницах.

if (!function_exists('shell_unread_messages')) {
    /**
     * Число собеседников с непрочитанными входящими — для значка «Сообщения» на нижней панели.
     * Сообщения одного собеседника не суммируются: 5 новых от одного человека = 1.
     * Считается так же, как в messages.php: только от других людей (не «Избранное»),
     * только живые (не удалённые) и не скрытые у этого пользователя.
     * Значок гаснет, когда пользователь открывает диалог (messages.php помечает
     * сообщения именно этого собеседника прочитанными).
     */
    function shell_unread_messages($conn, int $user_id): int
    {
        if ($user_id <= 0 || !$conn) {
            return 0;
        }
        $variants = [
            'SELECT COUNT(DISTINCT m.sender_id) AS c FROM messages m
              WHERE m.receiver_id = ? AND m.sender_id <> m.receiver_id AND m.is_read = 0
                AND m.deleted_at IS NULL
                AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id = m.id AND h.user_id = ?)',
            'SELECT COUNT(DISTINCT m.sender_id) AS c FROM messages m
              WHERE m.receiver_id = ? AND m.sender_id <> m.receiver_id AND m.is_read = 0
                AND m.deleted_at IS NULL',
            'SELECT COUNT(DISTINCT m.sender_id) AS c FROM messages m
              WHERE m.receiver_id = ? AND m.sender_id <> m.receiver_id AND m.is_read = 0',
        ];
        foreach ($variants as $sql) {
            try {
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    continue;
                }
                if (substr_count($sql, '?') === 2) {
                    $stmt->bind_param('ii', $user_id, $user_id);
                } else {
                    $stmt->bind_param('i', $user_id);
                }
                $stmt->execute();
                $count = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
                $stmt->close();
                return $count;
            } catch (Throwable $e) {
                // нет колонки deleted_at / таблицы message_hidden — пробуем упрощённый запрос
                continue;
            }
        }
        return 0;
    }
}

if (!function_exists('shell_prepare')) {
    /**
     * Все данные для общей шапки одним вызовом (для страниц, где их нет).
     * Использование:  extract(shell_prepare($conn, $user_id));
     */
    function shell_prepare($conn, int $user_id): array
    {
        $data = [
            'notifications'         => [],
            'notif_count'           => 0,
            'unread_count'          => shell_unread_messages($conn, $user_id),
            'pending_reports_count' => 0,
            'current_user_data'     => ['id' => $user_id, 'username' => 'Пользователь', 'avatar' => '', 'status' => 'online'],
            'is_admin'              => false,
        ];
        try {
            $stmt = $conn->prepare('SELECT id, username, avatar, status, is_admin FROM users WHERE id = ? LIMIT 1');
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row) {
                $data['current_user_data'] = $row;
                $data['is_admin'] = !empty($row['is_admin']);
            }

            $stmt = $conn->prepare("
                SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar AS sender_avatar
                FROM notifications n
                LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
                WHERE n.user_id = ?
                  AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
                ORDER BY n.created_at DESC
                LIMIT 30
            ");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($n = $res->fetch_assoc()) {
                $data['notifications'][] = $n;
            }
            $stmt->close();

            $stmt = $conn->prepare("
                SELECT COUNT(*) AS c FROM notifications
                WHERE user_id = ? AND is_read = 0
                  AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
            ");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $data['notif_count'] = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
            $stmt->close();

            if ($data['is_admin']) {
                $res = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
                if ($res) {
                    $data['pending_reports_count'] = (int)($res->fetch_assoc()['c'] ?? 0);
                }
            }
        } catch (Throwable $e) {
            error_log('shell_prepare: ' . $e->getMessage());
        }
        return $data;
    }
}

if (!function_exists('shellTimeAgo')) {
    function shellTimeAgo($datetime): string
    {
        $timestamp = strtotime((string)$datetime);
        $diff = time() - $timestamp;
        if ($diff < 60) return 'только что';
        if ($diff < 3600) return floor($diff / 60) . ' м';
        if ($diff < 86400) return floor($diff / 3600) . ' ч';
        if ($diff < 604800) return floor($diff / 86400) . ' д';
        return date('d.m.Y', $timestamp);
    }
}

if (!function_exists('shellNotificationIcon')) {
    function shellNotificationIcon(string $type): string
    {
        $icons = [
            'friend_request' => '👋', 'friend_accepted' => '✅', 'friend_removed' => '❌',
            'like' => '❤️', 'comment' => '💭', 'repost' => '🔁', 'message' => '💬',
            'news' => '📰', 'tag' => '🔖', 'mention' => '@', 'info' => 'ℹ️',
        ];
        return $icons[$type] ?? '🔔';
    }
}

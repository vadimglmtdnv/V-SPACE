<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

/*
|--------------------------------------------------------------------------
| PLAYERCHAT — Удаление новости
|--------------------------------------------------------------------------
| Только для администратора
|--------------------------------------------------------------------------
*/

// Проверка авторизации
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

// Проверка прав (только администратор с id=1)
if ($user_id !== 1) {
    header("Location: news.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST" || !isset($_POST["id"])) {
    header("Location: news.php");
    exit;
}

// Проверка CSRF-токена
if (!hash_equals((string)($_SESSION['csrf_news'] ?? ''), (string)($_POST['csrf_token'] ?? ''))) {
    http_response_code(403);
    exit('Недействительный токен формы. Вернитесь назад, обновите страницу и повторите.');
}

$news_id = (int)$_POST["id"];

// Подключение к базе данных
$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// Получаем путь к изображению для удаления
$stmt = $conn->prepare("SELECT image FROM news WHERE id = ?");
$stmt->bind_param("i", $news_id);
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_assoc();
$stmt->close();

// Удаляем новость
$stmt = $conn->prepare("DELETE FROM news WHERE id = ?");
$stmt->bind_param("i", $news_id);
$stmt->execute();
$stmt->close();

// Удаляем изображение, если оно есть
if (!empty($news['image']) && file_exists($news['image'])) {
    unlink($news['image']);
}

$conn->close();

header("Location: news.php");
exit;

?>
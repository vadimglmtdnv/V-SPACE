<?php
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
require_once __DIR__ . '/maintenance.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/lang.php';   // язык интерфейса (ru/en)
ui_translate_start();                            // для English переводит страницу по словарю includes/lang_en_pages.php
require_once __DIR__ . '/includes/shell.php';    // общие функции шапки (как в index.php)

try {
    $conn = db_connect();
    if ($conn->connect_error) {
        throw new Exception("Ошибка подключения: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Ошибка подключения к базе данных.");
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$current_user_id = (int)$_SESSION["user_id"];

// CSRF-токен. Ключ сессии 'avatar_csrf_token' — тот же, что проверяет avatars.php (avatarCsrfToken()),
// поэтому один и тот же токен подходит и для формы профиля, и для загрузки/удаления аватара.
if (empty($_SESSION['avatar_csrf_token']) || !is_string($_SESSION['avatar_csrf_token'])) {
    $_SESSION['avatar_csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['avatar_csrf_token'];

$view_user_id = isset($_GET['user']) ? (int)$_GET['user'] : 0;

if ($view_user_id <= 0) {
    $view_user_id = $current_user_id;
}

$can_edit = ($view_user_id === $current_user_id);
$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)
    ? $_GET['theme']
    : (isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true) ? $_COOKIE['theme'] : 'dark');
if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    setcookie('theme', $theme, time() + 365 * 24 * 60 * 60, '/');
}

$conn->query("
    CREATE TABLE IF NOT EXISTS user_profiles (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        first_name VARCHAR(50) DEFAULT NULL,
        last_name VARCHAR(50) DEFAULT NULL,
        birth_date DATE DEFAULT NULL,
        city VARCHAR(255) DEFAULT NULL,
        bio TEXT DEFAULT NULL,
        website_url VARCHAR(2048) DEFAULT NULL,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$profile_columns = $conn->query("SHOW COLUMNS FROM user_profiles LIKE 'website_url'");
if ($profile_columns && $profile_columns->num_rows === 0) {
    $conn->query("ALTER TABLE user_profiles ADD COLUMN website_url VARCHAR(2048) DEFAULT NULL AFTER bio");
}

foreach (['first_name' => 'VARCHAR(50) DEFAULT NULL', 'last_name' => 'VARCHAR(50) DEFAULT NULL', 'birth_date' => 'DATE DEFAULT NULL'] as $col_name => $col_def) {
    $col_chk = $conn->query("SHOW COLUMNS FROM user_profiles LIKE '" . $col_name . "'");
    if ($col_chk && $col_chk->num_rows === 0) {
        $conn->query("ALTER TABLE user_profiles ADD COLUMN " . $col_name . " " . $col_def);
    }
}

// Список городов для выпадающего поля (можно редактировать)
$city_options = [
    'Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань', 'Нижний Новгород',
    'Челябинск', 'Самара', 'Омск', 'Ростов-на-Дону', 'Уфа', 'Красноярск', 'Воронеж', 'Пермь',
    'Волгоград', 'Краснодар', 'Саратов', 'Тюмень', 'Тольятти', 'Ижевск', 'Барнаул', 'Ульяновск',
    'Иркутск', 'Хабаровск', 'Ярославль', 'Владивосток', 'Махачкала', 'Томск', 'Оренбург',
    'Кемерово', 'Новокузнецк', 'Рязань', 'Астрахань', 'Набережные Челны', 'Пенза', 'Липецк',
    'Киров', 'Чебоксары', 'Тула', 'Калининград', 'Курск', 'Севастополь', 'Сочи', 'Ставрополь',
    'Улан-Удэ', 'Тверь', 'Магнитогорск', 'Иваново', 'Брянск', 'Белгород', 'Сургут', 'Владимир',
    'Архангельск', 'Чита', 'Калуга', 'Смоленск', 'Волжский', 'Мурманск', 'Вологда', 'Якутск',
    'Минск', 'Гомель', 'Брест', 'Гродно', 'Витебск', 'Могилёв',
    'Киев', 'Харьков', 'Одесса', 'Днепр', 'Львов',
    'Астана', 'Алматы', 'Шымкент', 'Ташкент', 'Бишкек', 'Баку', 'Ереван', 'Тбилиси', 'Кишинёв',
    'Хельсинки', 'Таллин', 'Рига', 'Вильнюс', 'Варшава', 'Берлин', 'Прага', 'Тель-Авив',
];

// Английские названия городов (только для подписей в списке; в БД и в value остаются русские)
$city_en = [
    'Москва' => 'Moscow', 'Санкт-Петербург' => 'Saint Petersburg', 'Новосибирск' => 'Novosibirsk', 'Екатеринбург' => 'Yekaterinburg',
    'Казань' => 'Kazan', 'Нижний Новгород' => 'Nizhny Novgorod', 'Челябинск' => 'Chelyabinsk', 'Самара' => 'Samara', 'Омск' => 'Omsk',
    'Ростов-на-Дону' => 'Rostov-on-Don', 'Уфа' => 'Ufa', 'Красноярск' => 'Krasnoyarsk', 'Воронеж' => 'Voronezh', 'Пермь' => 'Perm',
    'Волгоград' => 'Volgograd', 'Краснодар' => 'Krasnodar', 'Саратов' => 'Saratov', 'Тюмень' => 'Tyumen', 'Тольятти' => 'Tolyatti',
    'Ижевск' => 'Izhevsk', 'Барнаул' => 'Barnaul', 'Ульяновск' => 'Ulyanovsk', 'Иркутск' => 'Irkutsk', 'Хабаровск' => 'Khabarovsk',
    'Ярославль' => 'Yaroslavl', 'Владивосток' => 'Vladivostok', 'Махачкала' => 'Makhachkala', 'Томск' => 'Tomsk', 'Оренбург' => 'Orenburg',
    'Кемерово' => 'Kemerovo', 'Новокузнецк' => 'Novokuznetsk', 'Рязань' => 'Ryazan', 'Астрахань' => 'Astrakhan',
    'Набережные Челны' => 'Naberezhnye Chelny', 'Пенза' => 'Penza', 'Липецк' => 'Lipetsk', 'Киров' => 'Kirov', 'Чебоксары' => 'Cheboksary',
    'Тула' => 'Tula', 'Калининград' => 'Kaliningrad', 'Курск' => 'Kursk', 'Севастополь' => 'Sevastopol', 'Сочи' => 'Sochi',
    'Ставрополь' => 'Stavropol', 'Улан-Удэ' => 'Ulan-Ude', 'Тверь' => 'Tver', 'Магнитогорск' => 'Magnitogorsk', 'Иваново' => 'Ivanovo',
    'Брянск' => 'Bryansk', 'Белгород' => 'Belgorod', 'Сургут' => 'Surgut', 'Владимир' => 'Vladimir', 'Архангельск' => 'Arkhangelsk',
    'Чита' => 'Chita', 'Калуга' => 'Kaluga', 'Смоленск' => 'Smolensk', 'Волжский' => 'Volzhsky', 'Мурманск' => 'Murmansk',
    'Вологда' => 'Vologda', 'Якутск' => 'Yakutsk', 'Минск' => 'Minsk', 'Гомель' => 'Gomel', 'Брест' => 'Brest', 'Гродно' => 'Grodno',
    'Витебск' => 'Vitebsk', 'Могилёв' => 'Mogilev', 'Киев' => 'Kyiv', 'Харьков' => 'Kharkiv', 'Одесса' => 'Odesa', 'Днепр' => 'Dnipro',
    'Львов' => 'Lviv', 'Астана' => 'Astana', 'Алматы' => 'Almaty', 'Шымкент' => 'Shymkent', 'Ташкент' => 'Tashkent', 'Бишкек' => 'Bishkek',
    'Баку' => 'Baku', 'Ереван' => 'Yerevan', 'Тбилиси' => 'Tbilisi', 'Кишинёв' => 'Chisinau', 'Хельсинки' => 'Helsinki',
    'Таллин' => 'Tallinn', 'Рига' => 'Riga', 'Вильнюс' => 'Vilnius', 'Варшава' => 'Warsaw', 'Берлин' => 'Berlin', 'Прага' => 'Prague',
    'Тель-Авив' => 'Tel Aviv',
];

$handle_col = $conn->query("SHOW COLUMNS FROM users LIKE 'handle'");
if ($handle_col && $handle_col->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN handle VARCHAR(32) DEFAULT NULL, ADD UNIQUE KEY handle (handle)");
}

// ---- Данные общей шапки (как в index.php): текущий пользователь, уведомления, модерация ----
$stmt = $conn->prepare("SELECT u.id, u.username, u.handle, u.avatar, u.status, u.is_admin, p.first_name, p.last_name FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE u.id = ? LIMIT 1");
$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$current_user = $stmt->get_result()->fetch_assoc() ?: [];
$stmt->close();

$notifications = [];
$notif_count = 0;
$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.username AS sender_username, u.avatar AS sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id
    LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC
    LIMIT 30
");
$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS count
    FROM notifications
    WHERE user_id = ? AND is_read = 0
      AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
");
$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
$stmt->close();

$header_is_admin = (int)($current_user['is_admin'] ?? 0) === 1;
$pending_reports_count = 0;
if ($header_is_admin) {
    $res = $conn->query("SELECT COUNT(*) AS count FROM reports WHERE status = 'pending'");
    if ($res) {
        $pending_reports_count = (int)($res->fetch_assoc()['count'] ?? 0);
    }
}

// ---- Переменные для includes/site_header.php — те же имена и смысл, что в index.php ----
$user_id            = $current_user_id;
$is_admin           = $header_is_admin;          // права того, кто СМОТРИТ страницу (космос в шапке, «Модерация»)
$notification_count = $notif_count;
$unread_count       = function_exists('shell_unread_messages') ? shell_unread_messages($conn, $current_user_id) : 0;
$profile_id         = $view_user_id;
// Имя в шапке — «Имя Фамилия», если заполнены, иначе логин (как username в index.php); @ник остаётся отдельно
$current_display_name = trim(trim((string)($current_user['first_name'] ?? '')) . ' ' . trim((string)($current_user['last_name'] ?? '')));
if ($current_display_name === '') { $current_display_name = (string)($current_user['username'] ?? 'Пользователь'); }
$current_user_data = [
    'id'         => $current_user_id,
    'username'   => $current_display_name,
    'login'      => (string)($current_user['username'] ?? ''),
    'handle'     => !empty($current_user['handle']) ? (string)$current_user['handle'] : (string)$current_user_id,
    'avatar'     => $current_user['avatar'] ?? '',
    'status'     => $current_user['status'] ?? 'online',
    'first_name' => $current_user['first_name'] ?? '',
    'last_name'  => $current_user['last_name'] ?? '',
    'is_admin'   => $header_is_admin ? 1 : 0,
];

$stmt = $conn->prepare("
    SELECT u.id, u.username, u.handle, u.email, u.avatar, u.created_at, u.last_seen, u.status, u.is_admin,
           p.first_name, p.last_name, p.birth_date, p.city, p.bio, p.website_url
    FROM users u
    LEFT JOIN user_profiles p ON p.user_id = u.id
    WHERE u.id = ?
    LIMIT 1
");
$stmt->bind_param("i", $view_user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    die("Пользователь не найден.");
}

$username = $user["username"] ?: "Пользователь";
// Отображаемое имя: «Имя Фамилия», если заполнены, иначе логин
$display_name = trim(trim((string)($user["first_name"] ?? '')) . ' ' . trim((string)($user["last_name"] ?? '')));
if ($display_name === '') { $display_name = $username; }
$default_handle = (string)(int)$user['id'];   // стандартный ID — просто номер аккаунта (например 1)
$user_handle = !empty($user['handle']) ? $user['handle'] : $default_handle; // ник-идентификатор (по умолчанию номер)

// Полная ссылка на профиль: https://сайт/playerchat/<ник или номер>
$is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$profile_link_prefix = ($is_https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
    . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') . '/';
$reserved_handles = ['admin','administrator','api','assets','images','includes','index','login','logout','register',
    'news','messages','friends','music','video','settings','support','edit','error','developers','profile','donate',
    'notifications','favorite','avatars','uploads','static','css','js','null','undefined','system','root',
    'moderator','help','playerchat','www'];
$email = $user["email"] ?? "";
$avatar = $user["avatar"] ?: "";
$avatarLetter = mb_strtoupper(mb_substr($display_name, 0, 1, 'UTF-8'), 'UTF-8');
$last_seen = $user["last_seen"] ?? null;
$header_status = $can_edit ? 'online' : ($user["status"] ?? 'offline');
$user_first_name = $user["first_name"] ?? '';
$user_last_name = $user["last_name"] ?? '';
$user_birth_date = $user["birth_date"] ?? '';
$user_city = $user["city"] ?? '';
$user_bio = $user["bio"] ?? '';
$user_website = $user["website_url"] ?? '';
$profile_is_admin = isset($user['is_admin']) && $user['is_admin'] == 1;   // админ ли владелец открытого профиля (плашка ADMIN)
$avatarExists = !empty($avatar) && is_file(__DIR__ . '/' . $avatar);
$created_at = $user["created_at"] ?? null;

// Обложка открытого профиля — та же, что на главной (если файла уже нет на диске — показываем стандартную)
$profile_cover = '';
$cover_val = '';
$cover_crop_raw = '';
foreach (['cover, cover_crop', 'cover'] as $cover_cols) {   // второй вариант — на случай, если колонки cover_crop ещё нет
    try {
        $cover_stmt = $conn->prepare("SELECT $cover_cols FROM users WHERE id = ? LIMIT 1");
        if (!$cover_stmt) { continue; }
        $cover_stmt->bind_param("i", $view_user_id);
        $cover_stmt->execute();
        $cover_row = $cover_stmt->get_result()->fetch_assoc() ?: [];
        $cover_stmt->close();
        $cover_val = trim((string)($cover_row['cover'] ?? ''));
        $cover_crop_raw = trim((string)($cover_row['cover_crop'] ?? ''));
        break;
    } catch (Throwable $e) {
        continue;
    }
}
if ($cover_val !== '' && strpos($cover_val, 'uploads/covers/') === 0 && strpos($cover_val, '..') === false && is_file(__DIR__ . '/' . $cover_val)) {
    $profile_cover = $cover_val;
}
// Рамка обложки: x, центр по y и ширина — доли картинки (0–1). Для старых обложек — на всю ширину по центру.
$cover_crop = [0, 5000, 10000];
if ($profile_cover !== '' && preg_match('/^(\d{1,5}) (\d{1,5}) (\d{1,5})$/', $cover_crop_raw, $cover_cm)) {
    $cover_cw = max(1000, min(10000, (int)$cover_cm[3]));
    $cover_cx = max(0, min(10000 - $cover_cw, (int)$cover_cm[1]));
    $cover_cy = max(0, min(10000, (int)$cover_cm[2]));
    $cover_crop = [$cover_cx, $cover_cy, $cover_cw];
}
$cover_fx  = number_format($cover_crop[0] / 10000, 4, '.', '');
$cover_fcy = number_format($cover_crop[1] / 10000, 4, '.', '');
$cover_fw  = number_format($cover_crop[2] / 10000, 4, '.', '');
$cover_ar = 2.0;   // пропорция картинки — нужна CSS для точного положения обложки
if ($profile_cover !== '') {
    $cover_dim = @getimagesize(__DIR__ . '/' . $profile_cover);
    if ($cover_dim && $cover_dim[0] > 0 && $cover_dim[1] > 0) {
        $cover_ar = $cover_dim[0] / $cover_dim[1];
    }
}
$cover_fa = number_format($cover_ar, 5, '.', '');

$profile_error = '';
$profile_success = '';
$upload_error = '';
$upload_success = '';

// Сообщения после редиректа (Post/Redirect/Get) — чтобы F5 не отправлял форму повторно.
if (!empty($_SESSION['flash_avatar']) && is_array($_SESSION['flash_avatar'])) {
    $flash = $_SESSION['flash_avatar'];
    unset($_SESSION['flash_avatar']);
    if (!empty($flash['ok'])) {
        $upload_success = (string)($flash['msg'] ?? '');
    } else {
        $upload_error = (string)($flash['msg'] ?? '');
    }
}
if (!empty($_SESSION['flash_profile'])) {
    $profile_success = (string)$_SESSION['flash_profile'];
    unset($_SESSION['flash_profile']);
}

// Загрузка и удаление аватара обрабатывает avatars.php (форма отправляет данные туда).
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_profile"])) {
    if (!$can_edit) {
        $profile_error = "Вы не можете редактировать этот профиль!";
    } elseif (!hash_equals($csrf_token, (string)($_POST['csrf_token'] ?? ''))) {
        $profile_error = "Ошибка безопасности (CSRF). Обновите страницу и попробуйте снова.";
    } else {
        $new_first_name = trim($_POST["first_name"] ?? "");
        $new_last_name = trim($_POST["last_name"] ?? "");
        $new_birth_date = trim($_POST["birth_date"] ?? "");
        $new_city = trim($_POST["city"] ?? "");
        $new_bio = trim($_POST["bio"] ?? "");
        $new_website = isset($_POST["website_url"]) ? trim($_POST["website_url"]) : $user_website;   // поля в форме нет — оставляем сохранённое значение
        $new_handle = mb_strtolower(trim($_POST["handle"] ?? $user_handle), 'UTF-8');
        if ($new_handle === '' || $new_handle === 'id' . $view_user_id) {
            $new_handle = $default_handle;   // пусто или старый вид id1 — возвращаем стандартный (номер)
        }

        if ($new_handle === $default_handle) {
            // стандартный ID (номер аккаунта) — всегда разрешён
        } elseif (!preg_match('/^[a-z][a-z0-9_]{2,31}$/', $new_handle)) {
            $profile_error = "ID: от 3 до 32 символов, только латинские буквы, цифры и «_», начинается с буквы.";
        } elseif (preg_match('/^id\d+$/', $new_handle)) {
            $profile_error = "ID вида id + число зарезервированы за номерами пользователей.";
        } elseif (in_array($new_handle, $reserved_handles, true)) {
            $profile_error = "Этот ID зарезервирован сайтом, выберите другой.";
        } elseif ($new_handle !== $user_handle) {
            $chk = $conn->prepare("SELECT id FROM users WHERE (handle = ? OR (? = CONCAT('id', id))) AND id <> ? LIMIT 1");
            $chk->bind_param("ssi", $new_handle, $new_handle, $view_user_id);
            $chk->execute();
            $chk->store_result();
            if ($chk->num_rows > 0) {
                $profile_error = "Такой ID уже занят.";
            }
            $chk->close();
        }

        if ($profile_error === '' && $new_city !== '' && $new_city !== $user_city && !in_array($new_city, $city_options, true)) {
            $profile_error = "Выберите город из списка.";
        } elseif ($profile_error !== '') {
            // ошибка ID уже установлена
        } elseif (mb_strlen($new_bio, 'UTF-8') > 500) {
            $profile_error = "Поле «О себе» не должно быть длиннее 500 символов.";
        } elseif ($new_website !== '' && (
            mb_strlen($new_website, 'UTF-8') > 2048 ||
            !filter_var($new_website, FILTER_VALIDATE_URL) ||
            !preg_match('/^https?:\/\//i', $new_website)
        )) {
            $profile_error = "Ссылка должна начинаться с http:// или https:// и быть корректной.";
        }

        foreach (['Имя' => $new_first_name, 'Фамилия' => $new_last_name] as $f_label => $f_value) {
            if ($profile_error !== '' || $f_value === '') continue;
            if (mb_strlen($f_value, 'UTF-8') > 50) {
                $profile_error = "Поле «" . $f_label . "» не должно быть длиннее 50 символов.";
            } elseif (!preg_match('/^[\p{L}][\p{L}\s\'\-]*$/u', $f_value)) {
                $profile_error = "Поле «" . $f_label . "»: только буквы, пробел, дефис и апостроф.";
            }
        }
        if ($profile_error === '' && $new_birth_date !== '') {
            $bd = DateTime::createFromFormat('!Y-m-d', $new_birth_date);
            $bd_ok = $bd && $bd->format('Y-m-d') === $new_birth_date;
            if (!$bd_ok) {
                $profile_error = "Укажите корректную дату рождения.";
            } elseif ($bd > new DateTime('today')) {
                $profile_error = "Дата рождения не может быть в будущем.";
            } elseif ($bd < new DateTime('1900-01-01')) {
                $profile_error = "Укажите корректную дату рождения.";
            }
        }

        if ($profile_error === '' && $new_handle !== $user_handle) {
            $store_handle = ($new_handle === $default_handle) ? null : $new_handle;
            try {
                $h_stmt = $conn->prepare("UPDATE users SET handle = ? WHERE id = ?");
                $h_stmt->bind_param("si", $store_handle, $view_user_id);
                $h_stmt->execute();
                $h_stmt->close();
            } catch (mysqli_sql_exception $e) {
                $profile_error = "Такой ID уже занят.";
            }
        }

        if ($profile_error === '') {
            $profile_stmt = $conn->prepare("
                INSERT INTO user_profiles (user_id, first_name, last_name, birth_date, city, bio, website_url, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE first_name = VALUES(first_name), last_name = VALUES(last_name),
                                        birth_date = VALUES(birth_date), city = VALUES(city), bio = VALUES(bio),
                                        website_url = VALUES(website_url), updated_at = NOW()
            ");
            $store_first = $new_first_name !== '' ? $new_first_name : null;
            $store_last  = $new_last_name !== '' ? $new_last_name : null;
            $store_birth = $new_birth_date !== '' ? $new_birth_date : null;
            $profile_stmt->bind_param("issssss", $view_user_id, $store_first, $store_last, $store_birth, $new_city, $new_bio, $new_website);
            $profile_stmt->execute();
            $profile_stmt->close();

            $_SESSION['flash_profile'] = "Профиль успешно обновлен!";
            $conn->close();
            header("Location: edit.php?user=" . (int)$view_user_id);
            exit;
        }

        // Ошибка валидации — показываем то, что ввёл пользователь, а не старые значения.
        $user_first_name = $new_first_name;
        $user_last_name = $new_last_name;
        $user_birth_date = $new_birth_date;
        $user_city = $new_city;
        $user_bio = $new_bio;
        $user_website = $new_website;
        $user_handle = $new_handle;
    }
}

// Соединение остаётся открытым: его использует includes/site_header.php. Закрываем в конце файла.

if (!function_exists('hasAvatar')) {
    function hasAvatar($avatar) {
        if (empty($avatar)) return false;
        if (is_file($avatar)) return true;
        return is_file(__DIR__ . DIRECTORY_SEPARATOR . ltrim($avatar, '/\\'));
    }
}

if (!function_exists('getAvatarUrl')) {
    function getAvatarUrl($avatar): string {
        $avatar = trim((string)$avatar);
        if ($avatar === '') return '';
        if (preg_match('/^(?:https?:)?\/\//i', $avatar)) return $avatar;
        return ltrim(str_replace('\\', '/', $avatar), '/');
    }
}

if (!function_exists('timeAgo')) {
    function timeAgo(string $datetime): string {
        $diff = time() - strtotime($datetime);
        if ($diff < 60) return 'только что';
        if ($diff < 3600) return floor($diff / 60) . ' м';
        if ($diff < 86400) return floor($diff / 3600) . ' ч';
        if ($diff < 604800) return floor($diff / 86400) . ' д';
        return date('d.m.Y', strtotime($datetime));
    }
}

if (!function_exists('getNotificationTypeName')) {
    function getNotificationTypeName(string $type): string {
        $names = [
            'friend_request' => 'Заявка в друзья', 'friend_accepted' => 'Заявка принята',
            'friend_removed' => 'Удаление из друзей', 'like' => 'Лайк', 'comment' => 'Комментарий',
            'repost' => 'Репост', 'message' => 'Сообщение', 'news' => 'Новость',
            'tag' => 'Отметка', 'mention' => 'Упоминание', 'info' => 'Информация'
        ];
        return $names[$type] ?? 'Уведомление';
    }
}

if (!function_exists('getNotificationIcon')) {
    function getNotificationIcon(string $type): string {
        $icons = [
            'friend_request' => '👋', 'friend_accepted' => '✅', 'friend_removed' => '❌',
            'like' => '❤️', 'comment' => '💭', 'repost' => '🔁', 'message' => '💬',
            'news' => '📰', 'tag' => '🔖', 'mention' => '@', 'info' => 'ℹ️'
        ];
        return $icons[$type] ?? '🔔';
    }
}

function getAvatarLetter(?string $username) {
    return mb_strtoupper(mb_substr($username ?: "?", 0, 1, 'UTF-8'), 'UTF-8');
}

function isOnline(?string $status): bool {
    return $status === 'online';
}

function formatLastSeen(?string $datetime) {
    if (empty($datetime)) return 'Неизвестно';
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    if ($diff < 60) return 'Только что';
    elseif ($diff < 3600) {
        $m = floor($diff / 60);
        return $m . ' ' . getMinutesWord($m) . ' назад';
    } elseif ($diff < 86400) {
        $h = floor($diff / 3600);
        return $h . ' ' . getHoursWord($h) . ' назад';
    } elseif ($diff < 604800) {
        $d = floor($diff / 86400);
        return $d . ' ' . getDaysWord($d) . ' назад';
    } else return date('d.m.Y H:i', $timestamp);
}

function getMinutesWord(int $n) {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'минут';
    $n = $n % 10;
    if ($n == 1) return 'минуту';
    if ($n >= 2 && $n <= 4) return 'минуты';
    return 'минут';
}

function getHoursWord(int $n) {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'часов';
    $n = $n % 10;
    if ($n == 1) return 'час';
    if ($n >= 2 && $n <= 4) return 'часа';
    return 'часов';
}

function getDaysWord(int $n) {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'дней';
    $n = $n % 10;
    if ($n == 1) return 'день';
    if ($n >= 2 && $n <= 4) return 'дня';
    return 'дней';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title><?= $can_edit ? 'Редактирование профиля' : 'Профиль пользователя' ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/edit.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/edit.css') ?>">
    <style>
        /* кнопки в шапке не слипаются (как в index.php) */
        .header-right { gap: 10px !important; }
        .header-right .avatar-dropdown { margin-left: 4px !important; }
    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <?php
    // Все сообщения страницы показываем как всплывающие уведомления
    $toasts = [];
    if (!empty($upload_error))    { $toasts[] = ['error',   $upload_error]; }
    if (!empty($upload_success))  { $toasts[] = ['success', $upload_success]; }
    if (!empty($profile_error))   { $toasts[] = ['error',   $profile_error]; }
    if (!empty($profile_success)) { $toasts[] = ['success', $profile_success]; }
    ?>
    <?php if ($toasts): ?>
        <div class="toast-stack" role="status" aria-live="polite">
            <?php foreach ($toasts as [$t_type, $t_text]): ?>
                <div class="notification <?= $t_type ?>" data-toast="<?= $t_type ?>">
                    <span class="toast-icon" aria-hidden="true">
                        <?php if ($t_type === 'success'): ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
                        <?php else: ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6.5v7"/><path d="M12 17.5h.01"/></svg>
                        <?php endif; ?>
                    </span>
                    <span class="toast-text"><?= htmlspecialchars($t_text, ENT_QUOTES, 'UTF-8') ?></span>
                    <button type="button" class="toast-close" aria-label="Закрыть">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main>
            <div class="edit-container">
                <div class="edit-card">

                    <div class="edit-topbar">
                        <a class="edit-back" href="<?= $can_edit ? 'index.php' : 'index.php?user=' . (int)$view_user_id ?>" aria-label="Назад">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>
                        </a>
                        <h1><?= $can_edit ? 'Редактирование профиля' : 'Профиль пользователя' ?></h1>
                        <span aria-hidden="true"></span>
                    </div>
                    <?php if (!$can_edit): ?>
                        <p class="subtitle">
                            Просмотр профиля <strong><?= htmlspecialchars($display_name) ?></strong>
                            <?php if ($profile_is_admin): ?>
                                <span class="admin-chip">ADMIN</span>
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>

                    <div class="avatar-section has-banner">
                        <div class="avatar-cover cover<?= $profile_cover !== '' ? ' has-cover' : '' ?>" aria-hidden="true">
                            <?php if ($profile_cover !== ''): ?>
                                <img class="cover-img" src="<?= htmlspecialchars($profile_cover, ENT_QUOTES, 'UTF-8') ?>" alt="" draggable="false"
                                     style="--fx:<?= $cover_fx ?>;--fcy:<?= $cover_fcy ?>;--fw:<?= $cover_fw ?>;--a:<?= $cover_fa ?>">
                            <?php else: ?>
                                <span class="cover-shooting-stars">
                                    <span class="cover-shooting-star star-one"></span>
                                    <span class="cover-shooting-star star-two"></span>
                                    <span class="cover-shooting-star star-three"></span>
                                    <span class="cover-comet"></span>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="avatar-wrap">
                        <div class="avatar-preview" id="avatarPreview"<?= $can_edit ? ' role="button" tabindex="0" title="Изменить фото"' : '' ?>>
                            <?php if ($avatarExists): ?>
                                <img src="<?= htmlspecialchars($avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($display_name, ENT_QUOTES, "UTF-8") ?>">
                            <?php else: ?>
                                <span class="avatar-text"><?= htmlspecialchars($avatarLetter) ?></span>
                                <img alt="" style="display:none;">
                            <?php endif; ?>
                            <?php if ($can_edit): ?>
                                <div class="avatar-hover" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l1.6-2.4h6.8L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13" r="3.4"/></svg></div>
                            <?php endif; ?>
                        </div>
                        </div>
                        <div class="avatar-meta">
                        <div class="avatar-name"><?= htmlspecialchars($display_name) ?></div>
                        <div class="avatar-handle">@<?= htmlspecialchars($user_handle, ENT_QUOTES, 'UTF-8') ?></div>
                        <div class="avatar-since"><span>Дата регистрации:</span> <?= $created_at ? date('d.m.Y', strtotime($created_at)) : 'Неизвестно' ?></div>
                        <?php if ($can_edit): ?>
                            <div class="avatar-hint">Нажмите на фото, чтобы выбрать и настроить новое</div>
                        <?php endif; ?>
                        <div class="avatar-actions">
                            <?php if ($can_edit): ?>
                                <form method="POST" action="avatars.php" enctype="multipart/form-data" id="avatarForm">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="return" value="edit.php?user=<?= (int)$view_user_id ?>">
                                    <input type="file" name="avatar" id="avatarUpload" accept="image/jpeg,image/png,image/gif,image/webp" class="avatar-upload-input">
                                </form>
                                    <form method="POST" action="avatars.php" id="avatarRemoveForm"<?= $avatarExists ? '' : ' hidden' ?>>
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
                                        <input type="hidden" name="return" value="edit.php?user=<?= (int)$view_user_id ?>">
                                        <button type="submit" name="remove_avatar" value="1" class="remove-avatar-btn">Удалить фото</button>
                                    </form>
                            <?php else: ?>
                                <span class="avatar-info">Владелец профиля</span>
                            <?php endif; ?>
                        </div>
                        </div>
                    </div>

                    <form method="POST" action="" class="edit-form" id="editForm">
                        <input type="hidden" name="update_profile" value="1">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">

                        <div class="set-title">Личные данные</div>
                        <div class="set-group">
                            <div class="form-group">
                                <label for="first_name">Имя</label>
                                <input type="text" name="first_name" id="first_name"
                                       value="<?= htmlspecialchars($user_first_name, ENT_QUOTES, "UTF-8") ?>"
                                       maxlength="50" autocomplete="given-name" placeholder="Например: Иван"
                                       <?= $can_edit ? '' : 'readonly' ?>>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Фамилия</label>
                                <input type="text" name="last_name" id="last_name"
                                       value="<?= htmlspecialchars($user_last_name, ENT_QUOTES, "UTF-8") ?>"
                                       maxlength="50" autocomplete="family-name" placeholder="Например: Иванов"
                                       <?= $can_edit ? '' : 'readonly' ?>>
                            </div>
                            <div class="form-group">
                                <label for="birth_date">Дата рождения</label>
                                <input type="date" name="birth_date" id="birth_date"
                                       value="<?= htmlspecialchars($user_birth_date, ENT_QUOTES, "UTF-8") ?>"
                                       min="1900-01-01" max="<?= date('Y-m-d') ?>"
                                       <?= $can_edit ? '' : 'readonly' ?>>
                            </div>
                            <div class="form-group">
                                <label for="city">Город</label>
                                <?php
                                $city_list = $city_options;
                                if ($user_city !== '' && !in_array($user_city, $city_list, true)) {
                                    array_unshift($city_list, $user_city);   // старое значение, которого нет в списке, не теряем
                                }
                                ?>
                                <select name="city" id="city" <?= $can_edit ? '' : 'disabled' ?>>
                                    <option value="">— Не выбран —</option>
                                    <?php foreach ($city_list as $c_name): ?>
                                        <option value="<?= htmlspecialchars($c_name, ENT_QUOTES, 'UTF-8') ?>"<?= $c_name === $user_city ? ' selected' : '' ?>><?= htmlspecialchars((ui_lang() === 'en' && isset($city_en[$c_name])) ? $city_en[$c_name] : $c_name, ENT_QUOTES, 'UTF-8') ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="set-title">Аккаунт</div>
                        <div class="set-group">
                            <div class="form-group">
                                <label for="handleInput">ID (ник)</label>
                                <div class="username-edit-wrapper">
                                    <div class="username-display">
                                        <span class="username-prefix id-icon" aria-hidden="true">@</span>
                                        <input type="text" name="handle" id="handleInput" class="username-input"
                                               value="<?= htmlspecialchars($user_handle, ENT_QUOTES, 'UTF-8') ?>"
                                               maxlength="32" autocomplete="off" spellcheck="false"
                                               placeholder="<?= htmlspecialchars($default_handle, ENT_QUOTES, 'UTF-8') ?>"
                                               <?= $can_edit ? '' : 'readonly' ?>>
                                    </div>
                                    <button type="button" class="edit-username-btn" id="copyHandleBtn">Копировать</button>
                                </div>
                            </div>
                            <?php if ($can_edit): ?>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" class="form-input" value="<?= htmlspecialchars($email, ENT_QUOTES, "UTF-8") ?>" readonly disabled>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php if ($can_edit): ?>
                            <div class="set-note">3–32 символа: латинские буквы, цифры и «_», начинается с буквы. Оставьте <b><?= htmlspecialchars($default_handle, ENT_QUOTES, 'UTF-8') ?></b>, чтобы вернуть стандартный. Email нельзя изменить — обратитесь в поддержку.</div>
                        <?php endif; ?>
                        <div class="set-note" id="handleLinkText" data-prefix="<?= htmlspecialchars($profile_link_prefix, ENT_QUOTES, 'UTF-8') ?>" data-default="<?= htmlspecialchars($default_handle, ENT_QUOTES, 'UTF-8') ?>">
                            Ваша ссылка: <b id="handleLinkValue"><?= htmlspecialchars($profile_link_prefix . $user_handle, ENT_QUOTES, 'UTF-8') ?></b>
                        </div>

                        <div class="set-title">О себе</div>
                        <div class="set-group">
                            <div class="form-group is-block">
                                <label for="bio" class="sr-only">О себе</label>
                                <textarea name="bio" id="bio" maxlength="500" placeholder="Расскажите о себе..."
                                          <?= $can_edit ? '' : 'readonly' ?>><?= htmlspecialchars($user_bio, ENT_QUOTES, "UTF-8") ?></textarea>
                                <?php if ($can_edit): ?>
                                    <div class="help-text">Максимум 500 символов.</div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-actions">
                            <?php if ($can_edit): ?>
                                <button type="submit" class="btn-save" id="saveBtn">
                                    <span class="btn-content">
                                        <img src="images/save.svg" class="save-icon" id="saveIcon" alt="Сохранить">
                                        <span id="saveBtnText">Сохранить</span>
                                    </span>
                                </button>
                                <a href="index.php" class="btn-cancel">Отмена</a>
                            <?php else: ?>
                                <a href="index.php?user=<?= $view_user_id ?>" class="btn-back">
                                    ← Назад к профилю
                                </a>
                            <?php endif; ?>
                        </div>

                    </form>

                    <?php if ($can_edit): ?>
                        <div class="save-bar<?= $profile_error !== '' ? ' is-visible' : '' ?>" id="saveBar" data-force="<?= $profile_error !== '' ? '1' : '0' ?>" role="region" aria-label="Несохранённые изменения">
                            <span class="save-bar-text">Есть несохранённые изменения</span>
                            <div class="save-bar-actions">
                                <button type="button" class="save-bar-reset" id="saveBarReset">Сбросить</button>
                                <button type="submit" class="save-bar-save" id="saveBarSave" form="editForm">Сохранить</button>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </main>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const themeTrigger = document.getElementById('themeTrigger');
            const themeSubmenu = document.getElementById('themeSubmenu');
            if (themeTrigger && themeSubmenu) {
                themeTrigger.addEventListener('click', function() {
                    themeSubmenu.classList.toggle('open');
                    themeTrigger.classList.toggle('open');
                    document.getElementById('themeArrow').classList.toggle('open');
                });
            }

        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var btn = document.getElementById('notificationsBtn');
            var dd = document.getElementById('notificationsDropdown');
            var markUrl = 'api/mark_notifications_read.php';
            var markBody = 'user_id=<?= (int)$current_user_id ?>&csrf_token=<?= rawurlencode($csrf_token) ?>';
            var post = function() {
                return fetch(markUrl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: markBody
                });
            };
            if (btn && dd) {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    dd.classList.toggle('active');
                    if (dd.classList.contains('active')) post().catch(function() {});
                });
                document.addEventListener('click', function(e) {
                    if (!dd.contains(e.target) && !btn.contains(e.target)) dd.classList.remove('active');
                });
            }
            var markAll = document.getElementById('markAllReadBtn');
            if (markAll) {
                markAll.addEventListener('click', function(e) {
                    e.stopPropagation();
                    post().then(function() {
                        document.querySelectorAll('.notification-item.unread').forEach(function(i) {
                            i.classList.remove('unread');
                            i.classList.add('read');
                        });
                        var badge = document.getElementById('notificationsBadge');
                        if (badge) badge.style.display = 'none';
                        var cnt = document.getElementById('notificationsCount');
                        if (cnt) cnt.textContent = '0 новых';
                        markAll.remove();
                    }).catch(function() {});
                });
            }
        });
    </script>
    <script>
    /* Уведомления и меню профиля: открыта максимум одна панель (как в index.php) */
    (function () {
        var notif = document.querySelector('.notifications-dropdown');
        var menu  = document.querySelector('.avatar-dropdown .dropdown-menu') || document.querySelector('.dropdown-menu');
        if (!notif || !menu) return;
        var CLS = ['active', 'show', 'open'];
        var root = document.documentElement;
        function isOpen(el) { return CLS.some(function (c) { return el.classList.contains(c); }); }
        function setOpen(el, on) {
            CLS.forEach(function (c) { if (c !== 'active') el.classList.remove(c); });
            if (el.classList.contains('active') !== on) el.classList.toggle('active', on);
        }
        function apply(n, m) {
            setOpen(notif, n);
            setOpen(menu, m);
            root.setAttribute('data-panel', n ? 'notif' : (m ? 'menu' : ''));
        }
        apply(isOpen(notif) && !isOpen(menu), isOpen(menu));
        document.addEventListener('click', function (e) {
            var inBell   = e.target.closest('#notificationsBtn, .notifications-btn');
            var inAvatar = e.target.closest('#avatarBtn, .header-avatar');
            var inside   = e.target.closest('.notifications-dropdown, .dropdown-menu');
            var wasN = isOpen(notif), wasM = isOpen(menu);
            var want = null;
            if (inBell)        want = [!wasN, false];
            else if (inAvatar) want = [false, !wasM];
            else if (!inside)  want = [false, false];
            if (!want) return;
            root.setAttribute('data-panel', want[0] ? 'notif' : (want[1] ? 'menu' : ''));
            setTimeout(function () { apply(want[0], want[1]); }, 0);
        }, true);
    })();
    </script>
    <?php if ($can_edit): ?>
    <!-- Окно настройки аватара: перетащить + масштаб в кружке -->
    <div class="crop-modal" id="cropModal" hidden>
        <div class="crop-backdrop" data-crop-close></div>
        <div class="crop-dialog" role="dialog" aria-modal="true" aria-labelledby="cropTitle">
            <div class="crop-head">
                <h2 id="cropTitle">Настройка фото</h2>
                <button type="button" class="crop-x" data-crop-close aria-label="Закрыть">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
                </button>
            </div>
            <div class="crop-stage" id="cropStage" tabindex="0" aria-label="Область фото. Перетаскивайте или используйте стрелки, + и −">
                <img id="cropImg" alt="" draggable="false">
                <div class="crop-mask" aria-hidden="true"></div>
            </div>
            <div class="crop-zoom">
                <button type="button" class="crop-step" id="cropZoomOut" aria-label="Уменьшить">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 12h12"/></svg>
                </button>
                <input type="range" id="cropZoom" min="0" max="1000" value="0" step="1" aria-label="Масштаб">
                <button type="button" class="crop-step" id="cropZoomIn" aria-label="Увеличить">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 12h12M12 6v12"/></svg>
                </button>
            </div>
            <p class="crop-note">Перетащите фото и меняйте масштаб ползунком — в аватар попадёт то, что внутри круга.</p>
            <div class="crop-actions">
                <button type="button" class="crop-btn crop-btn-ghost" data-crop-close>Отмена</button>
                <button type="button" class="crop-btn crop-btn-primary" id="cropSave">Сохранить</button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <script src="assets/js/edit.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/edit.js') ?>"></script>
</body>
</html>
<?php if (isset($conn) && $conn instanceof mysqli) { @$conn->close(); } ?>

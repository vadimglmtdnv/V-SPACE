<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

/*
|--------------------------------------------------------------------------
| Сброс пароля
|--------------------------------------------------------------------------
| Обновление пароля по токену
|--------------------------------------------------------------------------
*/

// Ошибки не показываем пользователю (пишутся только в лог сервера)
ini_set('display_errors', '0');

// Подключение к базе данных
$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

$error = "";
$success = "";
$token = isset($_GET['token']) ? trim($_GET['token']) : '';
$user_id = null;
$username = '';

// ============================================================
// 🔍 ОТЛАДКА: Проверяем, что токен получен
// ============================================================
if (!empty($token)) {
    // Проверяем, существует ли токен (даже если истек)
    $stmt = $conn->prepare("
        SELECT id, username, email, reset_token, reset_expires 
        FROM users 
        WHERE reset_token = ?
        LIMIT 1
    ");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    
    if ($user) {
        // Проверяем, не истек ли токен
        $now = new DateTime();
        $expires = new DateTime($user['reset_expires']);
        
        if ($expires > $now) {
            $user_id = $user['id'];
            $username = $user['username'];
        } else {
            $error = "❌ Срок действия ссылки истек. Запросите новую ссылку для сброса пароля.";
        }
    } else {
        $error = "❌ Недействительная ссылка для сброса пароля. Токен не найден в базе данных.";
    }
} else {
    $error = "❌ Отсутствует токен для сброса пароля.";
}

// Обработка POST-запроса
if ($_SERVER["REQUEST_METHOD"] === "POST" && $user_id) {
    $password = $_POST["password"] ?? "";
    $password_confirm = $_POST["password_confirm"] ?? "";

    if (strlen($password) < 6) {
        $error = "Пароль должен содержать минимум 6 символов.";
    } elseif ($password !== $password_confirm) {
        $error = "Пароли не совпадают.";
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("
            UPDATE users 
            SET password = ?, reset_token = NULL, reset_expires = NULL 
            WHERE id = ?
        ");
        $stmt->bind_param("si", $password_hash, $user_id);
        
        if ($stmt->execute()) {
            $success = "✅ Пароль успешно изменён! Теперь вы можете <a href='login.php'>войти</a> с новым паролем.";
        } else {
            $error = "❌ Ошибка обновления пароля: " . $conn->error;
        }
        $stmt->close();
    }
}

$conn->close();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>Сброс пароля</title>
    
    <style>
        * { box-sizing: border-box; }

        :root {
            --bg: #1b1c20;
            --card: #2b2d31;
            --card-border: rgba(255, 255, 255, 0.07);
            --field: #1e1f22;
            --text: #f2f3f5;
            --muted: #949ba4;
            --label: #b5bac1;
            --accent: #5865f2;
            --accent-2: #3a4bea;
            --green: #3ba55d;
            --green-soft: rgba(59, 165, 93, 0.14);
            --red: #f23f42;
            --red-soft: rgba(242, 63, 66, 0.14);
            --amber: #faa61a;
        }

        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            min-height: 100%;
            font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 16px;
        }

        .login-background {
            position: fixed;
            inset: 0;
            background:
                radial-gradient(circle at 15% 15%, rgba(88, 101, 242, 0.22), transparent 38%),
                radial-gradient(circle at 85% 85%, rgba(58, 75, 234, 0.16), transparent 40%),
                radial-gradient(circle at 80% 10%, rgba(143, 155, 255, 0.07), transparent 30%);
            pointer-events: none;
        }

        .login-card {
            position: relative;
            width: 100%;
            max-width: 460px;
            padding: 36px 34px 30px;
            background: linear-gradient(180deg, #2f3136 0%, var(--card) 100%);
            border: 1px solid var(--card-border);
            border-radius: 18px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.45), 0 2px 0 rgba(255, 255, 255, 0.03) inset;
            overflow: hidden;
        }

        .login-card::before {
            content: '';
            position: absolute;
            left: 0; right: 0; top: 0;
            height: 3px;
            background: linear-gradient(90deg, #3a4bea, #8f9bff, #3a4bea);
        }

        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 22px;
            text-decoration: none;
        }

        .login-title {
            text-align: center;
            font-size: 26px;
            font-weight: 700;
            letter-spacing: 0.2px;
            color: var(--text);
            margin-bottom: 8px;
        }

        .login-subtitle {
            text-align: center;
            font-size: 14px;
            line-height: 1.5;
            color: var(--muted);
            margin-bottom: 26px;
        }

        .login-subtitle strong { color: var(--label); font-weight: 600; }

        /* ---------- Сообщения ---------- */
        .login-error, .login-success {
            padding: 13px 16px;
            margin-bottom: 20px;
            border-radius: 10px;
            font-size: 14px;
            line-height: 1.55;
        }

        .login-error {
            background: var(--red-soft);
            border: 1px solid rgba(242, 63, 66, 0.4);
            color: #ff8a8c;
        }

        .login-success {
            background: var(--green-soft);
            border: 1px solid rgba(59, 165, 93, 0.45);
            color: #6fd58f;
        }

        .login-error a, .login-success a {
            color: #7cc4ff;
            text-decoration: none;
            font-weight: 600;
        }

        .login-error a:hover, .login-success a:hover { text-decoration: underline; }

        /* ---------- Поля ---------- */
        .form-group { margin-bottom: 20px; }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--label);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.7px;
        }

        .input-wrap {
            position: relative;
            width: 100%;
        }

        .input-wrap .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            width: 18px;
            height: 18px;
            transform: translateY(-50%);
            color: #6d6f78;
            pointer-events: none;
            transition: color 0.2s;
        }

        .form-input {
            width: 100%;
            height: 48px;
            padding: 0 46px 0 44px;
            border: 2px solid transparent;
            outline: none;
            border-radius: 10px;
            background: var(--field);
            color: var(--text);
            font-size: 15px;
            transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
        }

        .form-input::placeholder { color: #6d6f78; }

        .input-wrap:focus-within .input-icon { color: var(--accent); }

        .form-input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(88, 101, 242, 0.18);
        }

        /* Совпадает / не совпадает */
        .input-wrap.is-valid .form-input {
            border-color: var(--green);
            background: rgba(59, 165, 93, 0.07);
            box-shadow: 0 0 0 4px rgba(59, 165, 93, 0.16);
        }

        .input-wrap.is-valid .input-icon { color: var(--green); }

        .input-wrap.is-invalid .form-input {
            border-color: var(--red);
            background: rgba(242, 63, 66, 0.07);
            box-shadow: 0 0 0 4px rgba(242, 63, 66, 0.16);
        }

        .input-wrap.is-invalid .input-icon { color: var(--red); }

        .input-wrap.shake { animation: shake 0.35s ease; }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 34px;
            height: 34px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: none;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            opacity: 0.75;
            transition: opacity 0.2s, background 0.2s;
            z-index: 2;
        }

        .toggle-password:hover { opacity: 1; background: rgba(255, 255, 255, 0.06); }
        .toggle-password img { display: block; }

        .state-icon {
            position: absolute;
            right: 12px;
            top: 50%;
            width: 26px;
            height: 26px;
            transform: translateY(-50%) scale(0.6);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: 700;
            color: #fff;
            opacity: 0;
            transition: opacity 0.2s, transform 0.2s, background 0.2s;
            pointer-events: none;
        }

        .input-wrap.is-valid .state-icon   { opacity: 1; transform: translateY(-50%) scale(1); background: var(--green); }
        .input-wrap.is-invalid .state-icon { opacity: 1; transform: translateY(-50%) scale(1); background: var(--red); }

        /* ---------- Сложность ---------- */
        .password-strength {
            margin-top: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .strength-bar {
            flex: 1;
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 5px;
        }

        .strength-bar .seg {
            height: 5px;
            border-radius: 3px;
            background: #3f4147;
            transition: background 0.3s ease;
        }

        .strength-text {
            min-width: 92px;
            text-align: right;
            font-size: 13px;
            font-weight: 600;
            color: var(--muted);
            transition: color 0.3s ease;
        }

        /* ---------- Требования ---------- */
        .password-requirements {
            margin-top: 12px;
            padding: 12px;
            background: var(--field);
            border-radius: 10px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .password-requirements .req {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12.5px;
            color: var(--muted);
            transition: color 0.25s ease;
        }

        .password-requirements .req .icon {
            flex: 0 0 auto;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            font-weight: 700;
            color: #fff;
            background: #4a4d55;
            transition: background 0.25s ease;
        }

        .password-requirements .req.met { color: #6fd58f; }
        .password-requirements .req.met .icon { background: var(--green); }

        /* ---------- Совпадение ---------- */
        .match-message {
            margin-top: 9px;
            min-height: 22px;
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .match-message.success { color: #6fd58f; }
        .match-message.error   { color: #ff7a7c; }

        /* ---------- Кнопка ---------- */
        .login-button {
            width: 100%;
            height: 50px;
            margin-top: 6px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(135deg, #5865f2 0%, #3a4bea 100%);
            color: #fff;
            font-size: 15px;
            font-weight: 700;
            letter-spacing: 0.3px;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(58, 75, 234, 0.35);
            transition: transform 0.12s, box-shadow 0.2s, filter 0.2s;
        }

        .login-button:hover:not(:disabled) {
            filter: brightness(1.08);
            box-shadow: 0 10px 26px rgba(58, 75, 234, 0.5);
        }

        .login-button:active:not(:disabled) { transform: translateY(1px); }

        .login-button:disabled {
            opacity: 0.45;
            cursor: not-allowed;
            box-shadow: none;
        }

        .links { text-align: center; margin-top: 18px; }

        .links a {
            color: var(--muted);
            text-decoration: none;
            font-size: 13px;
            transition: color 0.15s;
        }

        .links a:hover { color: #dbdee1; text-decoration: underline; }

        .divider {
            border: none;
            height: 1px;
            background: rgba(255, 255, 255, 0.07);
            margin: 22px 0 6px;
        }

        @media (max-width: 520px) {
            .login-card { padding: 28px 20px 24px; border-radius: 14px; }
            .login-title { font-size: 23px; }
            .password-requirements { grid-template-columns: 1fr; }
        }

        @media (prefers-reduced-motion: reduce) {
            * { animation: none !important; transition: none !important; }
        }
    </style>
</head>
<body>
    
    <div class="login-background"></div>
    
    <div class="login-card">
        
        <a href="index.php" class="logo">
            <img src="images/logo_type.svg" alt="SPACE" height="56" style="width:auto;height:56px;display:block;">
        </a>
        
        <div class="login-title">Сброс пароля</div>
        
        <?php if ($error !== ""): ?>
            <div class="login-error">
                <?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?>
                <?php if (strpos($error, "истек") !== false || strpos($error, "Недействительная") !== false): ?>
                    <br><br>
                    <a href="forgot_password.php">Запросить новую ссылку для сброса пароля</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success !== ""): ?>
            <div class="login-success"><?= $success ?></div>
        <?php endif; ?>
        
        <?php if (empty($success) && !empty($token) && $user_id): ?>
            <div class="login-subtitle">Введите новый пароль для <strong><?= htmlspecialchars($username, ENT_QUOTES, "UTF-8") ?></strong></div>
            
            <form action="reset_password.php?token=<?= htmlspecialchars($token, ENT_QUOTES, "UTF-8") ?>" method="POST" id="resetForm">

                <!-- Новый пароль -->
                <div class="form-group">
                    <label class="form-label" for="password">Новый пароль</label>
                    <div class="input-wrap" id="wrapPassword">
                        <svg class="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
                        <input
                            type="password"
                            name="password"
                            id="password"
                            class="form-input"
                            placeholder="Минимум 6 символов"
                            required
                            minlength="6"
                            autofocus
                            autocomplete="new-password"
                        >
                        <button type="button" class="toggle-password" id="togglePassword" title="Показать пароль" aria-label="Показать пароль">
                            <img src="images/nosleep.svg" alt="" width="20" height="20">
                        </button>
                    </div>

                    <!-- Индикатор сложности -->
                    <div class="password-strength">
                        <div class="strength-bar" id="strengthBar">
                            <span class="seg"></span><span class="seg"></span><span class="seg"></span><span class="seg"></span><span class="seg"></span>
                        </div>
                        <span class="strength-text" id="strengthText">Введите пароль</span>
                    </div>

                    <!-- Требования к паролю -->
                    <div class="password-requirements" id="requirements">
                        <div class="req" id="reqLength"><span class="icon">✕</span> Минимум 6 символов</div>
                        <div class="req" id="reqLowercase"><span class="icon">✕</span> Строчные буквы (a-z)</div>
                        <div class="req" id="reqUppercase"><span class="icon">✕</span> Заглавные буквы (A-Z)</div>
                        <div class="req" id="reqNumber"><span class="icon">✕</span> Цифры (0-9)</div>
                        <div class="req" id="reqSpecial"><span class="icon">✕</span> Спецсимволы (!@#$%^&amp;*)</div>
                    </div>
                </div>

                <!-- Подтверждение: зелёный — совпадает, красный — не совпадает -->
                <div class="form-group">
                    <label class="form-label" for="passwordConfirm">Подтвердите пароль</label>
                    <div class="input-wrap" id="wrapConfirm">
                        <svg class="input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
                        <input
                            type="password"
                            name="password_confirm"
                            id="passwordConfirm"
                            class="form-input"
                            placeholder="Повторите пароль"
                            required
                            autocomplete="new-password"
                        >
                        <span class="state-icon" id="stateIcon" aria-hidden="true"></span>
                    </div>
                    <div class="match-message" id="matchText" aria-live="polite"></div>
                </div>

                <button type="submit" class="login-button" id="submitBtn">Изменить пароль</button>
            </form>
            
            <hr class="divider">
            
            <div class="links">
                <a href="login.php">← Вернуться на страницу входа</a>
            </div>
        <?php endif; ?>
        
        <?php if (empty($token) && empty($success) && empty($error)): ?>
            <div class="login-error">❌ Отсутствует токен для сброса пароля.</div>
            <div class="links">
                <a href="login.php">← Вернуться на страницу входа</a>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="links">
                <a href="login.php">← Вернуться на страницу входа</a>
            </div>
        <?php endif; ?>
        
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const password        = document.getElementById('password');
            const passwordConfirm = document.getElementById('passwordConfirm');
            if (!password || !passwordConfirm) return; // страница без формы (ошибка / успех)

            const strengthText = document.getElementById('strengthText');
            const segs         = document.querySelectorAll('#strengthBar .seg');
            const matchText    = document.getElementById('matchText');
            const submitBtn    = document.getElementById('submitBtn');
            const toggleBtn    = document.getElementById('togglePassword');
            const toggleImg    = toggleBtn.querySelector('img');
            const wrapPassword = document.getElementById('wrapPassword');
            const wrapConfirm  = document.getElementById('wrapConfirm');
            const stateIcon    = document.getElementById('stateIcon');

            const reqs = {
                length:    document.getElementById('reqLength'),
                lowercase: document.getElementById('reqLowercase'),
                uppercase: document.getElementById('reqUppercase'),
                number:    document.getElementById('reqNumber'),
                special:   document.getElementById('reqSpecial')
            };

            // Показать / скрыть пароль (в обоих полях сразу)
            toggleBtn.addEventListener('click', function () {
                const show = password.type === 'password';
                password.type = passwordConfirm.type = show ? 'text' : 'password';
                toggleImg.src = show ? 'images/sleep.svg' : 'images/nosleep.svg';
                toggleBtn.title = toggleBtn.ariaLabel = show ? 'Скрыть пароль' : 'Показать пароль';
            });

            function setReq(el, ok) {
                el.className = 'req' + (ok ? ' met' : '');
                el.querySelector('.icon').textContent = ok ? '✓' : '✕';
            }

            // Сложность пароля
            function checkStrength(pwd) {
                const r = {
                    length:    pwd.length >= 6,
                    lowercase: /[a-z]/.test(pwd),
                    uppercase: /[A-Z]/.test(pwd),
                    number:    /[0-9]/.test(pwd),
                    special:   /[^A-Za-z0-9\s]/.test(pwd)
                };
                Object.keys(r).forEach(k => setReq(reqs[k], r[k]));

                const score = Object.values(r).filter(Boolean).length;
                let level = 'Введите пароль', color = '#949ba4', filled = 0;
                if (pwd.length > 0) {
                    if (score <= 2)      { level = 'Слабый';   color = '#f23f42'; }
                    else if (score === 3){ level = 'Средний';  color = '#faa61a'; }
                    else if (score === 4){ level = 'Хороший';  color = '#3ba55d'; }
                    else                 { level = 'Сильный';  color = '#3ba55d'; }
                    filled = score;
                }
                segs.forEach((seg, i) => { seg.style.background = i < filled ? color : ''; });
                strengthText.textContent = level;
                strengthText.style.color = color;

                const strong = r.length && r.lowercase && r.uppercase && r.number && r.special;
                wrapPassword.classList.toggle('is-valid', strong);
                return strong;
            }

            // Совпадение: зелёный — совпадает, красный — не совпадает
            let lastState = '';
            function checkMatch() {
                const pwd = password.value, conf = passwordConfirm.value;
                let state = '';
                if (conf.length > 0) state = (pwd === conf && pwd.length > 0) ? 'ok' : 'bad';

                wrapConfirm.classList.toggle('is-valid',   state === 'ok');
                wrapConfirm.classList.toggle('is-invalid', state === 'bad');

                if (state === 'ok') {
                    stateIcon.textContent = '✓';
                    matchText.textContent = 'Пароли совпадают';
                    matchText.className = 'match-message success';
                } else if (state === 'bad') {
                    stateIcon.textContent = '✕';
                    matchText.textContent = 'Пароли не совпадают';
                    matchText.className = 'match-message error';
                    if (lastState !== 'bad') {
                        wrapConfirm.classList.remove('shake');
                        void wrapConfirm.offsetWidth;
                        wrapConfirm.classList.add('shake');
                    }
                } else {
                    stateIcon.textContent = '';
                    matchText.textContent = '';
                    matchText.className = 'match-message';
                }
                lastState = state;
                return state === 'ok';
            }

            function validateForm() {
                const strong = checkStrength(password.value);
                const match  = checkMatch();
                submitBtn.disabled = !(strong && match);
            }

            password.addEventListener('input', validateForm);
            passwordConfirm.addEventListener('input', validateForm);
            validateForm();
        });
    </script>
    
</body>
</html>
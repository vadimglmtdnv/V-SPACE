<?php
// profile.php больше не используется. Старые ссылки ведут на /playerchat/<номер аккаунта>.
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$id = (int)($_GET['user'] ?? ($_SESSION['user_id'] ?? 0));
$query = $_GET;
unset($query['user']);

// В адресе указан номер, но он не число или не больше нуля — это не профиль, показываем 404
if (isset($_GET['user']) && $id <= 0) {
    $error_code  = 404;
    $error_title = 'Профиль не найден';
    $error_text  = 'Такого пользователя нет — номер аккаунта в адресе указан неверно.';
    require __DIR__ . '/error.php';
    exit;
}

header('Location: ' . ($id > 0 ? $base . '/' . $id : $base . '/index.php') . ($query ? '?' . http_build_query($query) : ''));
exit;

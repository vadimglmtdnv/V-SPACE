<?php

require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function themeSyncRespond(int $status, array $payload): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    start_secure_session();

    $userId = (int)($_SESSION['user_id'] ?? 0);
    if ($userId <= 0) {
        themeSyncRespond(401, ['success' => false, 'error' => 'Не авторизован']);
    }

    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    $csrfToken = $_SESSION['csrf_token'];

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $theme = null;
    if ($method === 'POST') {
        $providedToken = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if ($providedToken === '' || !hash_equals($csrfToken, $providedToken)) {
            themeSyncRespond(403, ['success' => false, 'error' => 'Неверный CSRF-токен']);
        }

        $input = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input) || !isset($input['theme']) || !is_string($input['theme'])) {
            themeSyncRespond(400, ['success' => false, 'error' => 'Некорректные данные темы']);
        }
        $theme = $input['theme'];
        if (!in_array($theme, ['dark', 'light', 'system'], true)) {
            themeSyncRespond(400, ['success' => false, 'error' => 'Недопустимая тема']);
        }
    } elseif ($method !== 'GET') {
        header('Allow: GET, POST');
        themeSyncRespond(405, ['success' => false, 'error' => 'Метод не поддерживается']);
    }

    session_write_close();

    $conn = db_connect(true);
    $table = $conn->query("
        SELECT COUNT(*) AS table_exists
        FROM information_schema.tables
        WHERE table_schema = DATABASE()
          AND table_name = 'user_theme_preferences'
    ");
    if (!$table) {
        throw new RuntimeException('Не удалось проверить таблицу пользовательских тем.');
    }
    if ((int)($table->fetch_assoc()['table_exists'] ?? 0) === 0) {
        $conn->query("
            CREATE TABLE IF NOT EXISTS user_theme_preferences (
                user_id INT NOT NULL PRIMARY KEY,
                theme VARCHAR(10) NOT NULL,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                    ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    if ($method === 'POST') {
        $stmt = $conn->prepare("
            INSERT INTO user_theme_preferences (user_id, theme)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE theme = VALUES(theme)
        ");
        $stmt->bind_param('is', $userId, $theme);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = $conn->prepare('SELECT theme FROM user_theme_preferences WHERE user_id = ? LIMIT 1');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $theme = isset($row['theme']) && in_array($row['theme'], ['dark', 'light', 'system'], true)
            ? $row['theme']
            : null;
    }

    $conn->close();
    themeSyncRespond(200, [
        'success' => true,
        'theme' => $theme,
        'csrf_token' => $csrfToken,
    ]);
} catch (Throwable $error) {
    error_log('theme_sync.php: ' . $error->getMessage());
    themeSyncRespond(500, ['success' => false, 'error' => 'Не удалось синхронизировать тему']);
}

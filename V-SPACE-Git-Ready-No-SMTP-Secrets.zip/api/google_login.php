<?php
/**
 * Старт входа через Google (OAuth 2.0, Authorization Code).
 *
 * Ссылка с кнопки: api/google_login.php?from=login|register
 * Необязательно: &remember=1 («Запомнить меня»), &tz=Europe/Amsterdam (часовой пояс для нового аккаунта).
 */

require_once __DIR__ . '/google_helpers.php';

require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();

$from = google_from_page($_GET['from'] ?? '');

// Уже вошли — делать нечего
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . google_app_base() . '/index.php');
    exit;
}

$cfg = google_config();
if (!google_is_configured($cfg)) {
    error_log('Google OAuth: заполните client_id и client_secret в api/google_config.php');
    google_fail('not_configured', $from);
}

// Часовой пояс — только из списка допустимых
$timezone = (string)($_GET['tz'] ?? 'UTC');
if (!in_array($timezone, DateTimeZone::listIdentifiers(), true)) {
    $timezone = 'UTC';
}

$state       = bin2hex(random_bytes(16));   // защита от подделки запроса (CSRF)
$nonce       = bin2hex(random_bytes(16));   // защита от подмены токена
$redirectUri = google_redirect_uri($cfg);

$_SESSION['google_oauth'] = [
    'state'        => $state,
    'nonce'        => $nonce,
    'redirect_uri' => $redirectUri,
    'from'         => $from,
    'remember'     => ($_GET['remember'] ?? '') === '1',
    'timezone'     => $timezone,
    'time'         => time(),
];

$query = http_build_query([
    'client_id'     => $cfg['client_id'],
    'redirect_uri'  => $redirectUri,
    'response_type' => 'code',
    'scope'         => 'openid email profile',
    'state'         => $state,
    'nonce'         => $nonce,
    'prompt'        => 'select_account',   // всегда показывать выбор аккаунта
], '', '&', PHP_QUERY_RFC3986);

header('Location: https://accounts.google.com/o/oauth2/v2/auth?' . $query);
exit;

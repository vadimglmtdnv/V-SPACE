<?php
declare(strict_types=1);

// messages.php — страница чата (HTML). Общий код лежит в messages_core.php, JSON-API — в api/messages.php.
define('PLAYERCHAT_ENTRY', true);
require_once __DIR__ . '/messages_core.php';

// ============================================================
// Удаление сообщения у ВСЕХ участников диалога (api=delete), отмена удаления (api=restore)
// и удаление только у себя (api=hide).
// Обрабатывается здесь, до передачи управления api/messages.php: раньше удаление у всех зависело от
// отдельного обработчика, и при любой его ошибке пользователь видел «Не удалось удалить сообщение
// у всех участников». Запись из базы не стирается: ставится deleted_at (сервер после этого не отдаёт
// сообщение никому, см. visibleMessageSql), прежний текст сохраняется в deleted_message для отмены.
// ============================================================
if (isset($_GET['api']) && in_array($_GET['api'], ['delete', 'restore', 'hide'], true)) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        apiResponse(['success' => false, 'error' => 'method_not_allowed'], 405);
    }
    apiRequireCsrf();

    $del_msg_id = (int)($_POST['msg_id'] ?? 0);
    if ($del_msg_id <= 0) {
        apiResponse(['success' => false, 'error' => 'bad_message_id'], 400);
    }

    $stmt = $conn->prepare('SELECT id, sender_id, receiver_id, message, deleted_at, deleted_message,
                                   TIMESTAMPDIFF(SECOND, deleted_at, NOW()) AS deleted_age
                            FROM messages WHERE id = ?');
    if (!$stmt) {
        apiResponse(['success' => false, 'error' => 'db_error', 'message' => $conn->error], 500);
    }
    $stmt->bind_param('i', $del_msg_id);
    $stmt->execute();
    $del_row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$del_row) {
        apiResponse(['success' => false, 'error' => 'Сообщение не найдено.'], 404);
    }
    // «Удалить у меня»: сообщение скрывается только для этого пользователя (таблица message_hidden),
    // у собеседника остаётся. Скрыть можно любое сообщение своего диалога — и своё, и чужое.
    if ($_GET['api'] === 'hide') {
        if ((int)$del_row['sender_id'] !== $user_id && (int)$del_row['receiver_id'] !== $user_id) {
            apiResponse(['success' => false, 'error' => 'Сообщение не найдено.'], 404);
        }
        $stmt = $conn->prepare('INSERT IGNORE INTO message_hidden (user_id, message_id) VALUES (?, ?)');
        if (!$stmt) {
            apiResponse(['success' => false, 'error' => 'db_error', 'message' => $conn->error], 500);
        }
        $stmt->bind_param('ii', $user_id, $del_msg_id);
        $ok = $stmt->execute();
        $err = $stmt->error;
        $stmt->close();
        if (!$ok) {
            error_log('messages.php hide failed: ' . $err);
            apiResponse(['success' => false, 'error' => 'db_error', 'message' => $err], 500);
        }
        apiResponse(['success' => true]);
    }

    // У всех можно удалить только своё сообщение
    if ((int)$del_row['sender_id'] !== $user_id) {
        apiResponse(['success' => false, 'error' => 'У всех можно удалить только свои сообщения.'], 403);
    }

    if ($_GET['api'] === 'delete') {
        if (!empty($del_row['deleted_at'])) {
            apiResponse(['success' => true]);   // уже удалено — повторный запрос не ошибка
        }
        $stmt = $conn->prepare('UPDATE messages SET deleted_at = NOW(), deleted_message = message, deleted_by = ?
                                WHERE id = ? AND sender_id = ? AND deleted_at IS NULL');
        if (!$stmt) {
            apiResponse(['success' => false, 'error' => 'db_error', 'message' => $conn->error], 500);
        }
        $stmt->bind_param('iii', $user_id, $del_msg_id, $user_id);
        $ok = $stmt->execute();
        $err = $stmt->error;
        $stmt->close();
        if (!$ok) {
            error_log('messages.php delete failed: ' . $err);
            apiResponse(['success' => false, 'error' => 'db_error', 'message' => $err], 500);
        }
        apiResponse(['success' => true]);
    }

    // restore
    if (empty($del_row['deleted_at']) || $del_row['deleted_message'] === null) {
        apiResponse(['success' => false, 'error' => 'Нечего восстанавливать.'], 409);
    }
    // небольшой запас на задержку сети: клиент показывает кнопку DELETED_MESSAGE_TTL секунд
    if ((int)($del_row['deleted_age'] ?? 0) > DELETED_MESSAGE_TTL + 3) {
        apiResponse(['success' => false, 'error' => 'Время на восстановление истекло.'], 410);
    }
    $stmt = $conn->prepare('UPDATE messages SET deleted_at = NULL, deleted_message = NULL, deleted_by = NULL
                            WHERE id = ? AND sender_id = ? AND deleted_at IS NOT NULL');
    if (!$stmt) {
        apiResponse(['success' => false, 'error' => 'db_error', 'message' => $conn->error], 500);
    }
    $stmt->bind_param('ii', $del_msg_id, $user_id);
    $ok = $stmt->execute();
    $err = $stmt->error;
    $stmt->close();
    if (!$ok) {
        error_log('messages.php restore failed: ' . $err);
        apiResponse(['success' => false, 'error' => 'db_error', 'message' => $err], 500);
    }
    apiResponse(['success' => true]);
}

// Совместимость: старые обращения messages.php?api=<имя> (assets/js/*.js) обслуживает api/messages.php
if (isset($_GET['api']) && $_GET['api'] !== '') {
    require_once __DIR__ . '/api/messages.php';
    exit;
}

// ============================================================
// 10.5. Старый GET-эндпоинт ?mark_read=<id> УДАЛЁН — он менял данные по обычному GET
// без CSRF-токена (уязвимость: сторонняя страница могла дёрнуть его через <img src="...">).
// Тот же функционал теперь доступен только через защищённый POST api=mark_read
// (см. api/messages.php, требует csrf_token). JS (messages.js) уже переключён на него.
// ============================================================

// ============================================================
// Единый показ ошибок через error.php (страница с кодом, текстом и кнопками).
// back — относительная ссылка для кнопки «Вернуться в чат»; detail виден только при заходе с localhost.
// ============================================================
if (!function_exists('showErrorPage')) {
    function showErrorPage(int $code, string $text = '', string $back = '', string $title = '', string $detail = ''): void
    {
        $error_code = $code;
        if ($title !== '')  { $error_title  = $title; }
        if ($text !== '')   { $error_text   = $text; }
        if ($back !== '')   { $error_back_url = $back; }
        if ($detail !== '') { $error_detail = $detail; }
        require __DIR__ . '/error.php';
        exit;
    }
}

// ============================================================
// 10.6. HTTP 413: тело запроса больше post_max_size.
// В этом случае PHP целиком отбрасывает $_POST и $_FILES, поэтому дальше
// сработала бы ложная «CSRF token validation failed» (403). Ловим это заранее.
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $iniToBytes = static function (string $v): int {
        $v = trim($v);
        if ($v === '') return 0;
        $num = (float)$v;
        switch (strtolower(substr($v, -1))) {
            case 'g': $num *= 1024;
            // no break
            case 'm': $num *= 1024;
            // no break
            case 'k': $num *= 1024;
        }
        return (int)$num;
    };
    $content_length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    $post_max       = $iniToBytes((string)ini_get('post_max_size'));
    if ($post_max > 0 && $content_length > $post_max && empty($_POST) && empty($_FILES)) {
        http_response_code(413);
        $limit_mb = round($post_max / 1048576, 1);
        $is_ajax = (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest')
            || stripos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false;
        if ($is_ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success'  => false,
                'error'    => 'payload_too_large',
                'message'  => 'Файл слишком большой. Максимальный размер запроса: ' . $limit_mb . ' МБ',
                'limit'    => $post_max,
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        // Обычная форма: страница error.php (413) с кнопкой возврата в тот же диалог (берём его из Referer)
        $back = 'messages.php';
        $ref_query = (string)parse_url((string)($_SERVER['HTTP_REFERER'] ?? ''), PHP_URL_QUERY);
        parse_str($ref_query, $ref_params);
        $ref_dialog = (int)($ref_params['dialog'] ?? 0);
        if ($ref_dialog > 0) {
            $back .= '?dialog=' . $ref_dialog;
        }
        showErrorPage(413, 'Размер отправленных данных превышает допустимый (' . $limit_mb . ' МБ). Выберите файл поменьше.', $back);
    }
}

// ============================================================
// 11. ОТПРАВКА СООБЩЕНИЯ (форма)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'], $_POST['receiver_id'])) {

    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        showErrorPage(403, 'Сессия устарела или токен безопасности не прошёл проверку. Обновите страницу и попробуйте снова.', 'messages.php');
    }

    $receiver_id = (int)$_POST['receiver_id'];
    if ($receiver_id <= 0) {
        header('Location: messages.php');
        exit;
    }

    $stmt = $conn->prepare('SELECT id FROM users WHERE id = ?');
    $stmt->bind_param('i', $receiver_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        $stmt->close();
        header('Location: messages.php');
        exit;
    }
    $stmt->close();

    if ($receiver_id !== $user_id) {
        if (isDialogBlocked($conn, $receiver_id, $user_id)) {
            showErrorPage(403, 'Вы не можете написать этому пользователю: он вас заблокировал.', 'messages.php?dialog=' . $receiver_id, 'Сообщение не отправлено');
        }
        if (isDialogBlocked($conn, $user_id, $receiver_id)) {
            showErrorPage(403, 'Вы заблокировали этого пользователя. Разблокируйте его, чтобы написать.', 'messages.php?dialog=' . $receiver_id, 'Сообщение не отправлено');
        }
    }

    // Не больше 5 фото за раз
    $photo_files = collectPhotoFiles();
    if (count($photo_files) > 5) {
        showErrorPage(413, 'Можно отправить не больше 5 фото за раз.', 'messages.php?dialog=' . $receiver_id, 'Слишком много фото');
    }

    // Отдельный файл больше upload_max_filesize / MAX_FILE_SIZE — сообщаем, а не молча теряем вложение
    foreach ($_FILES as $uploaded_group) {
        foreach ((array)($uploaded_group['error'] ?? []) as $upload_err) {
            if (in_array((int)$upload_err, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
                showErrorPage(413, '', 'messages.php?dialog=' . $receiver_id);
            }
        }
    }

    if (captchaRequired()) {
        $given_captcha = trim((string)($_POST['captcha_code'] ?? ''));
        if (!captchaVerify($given_captcha)) {
            header('Location: messages.php?dialog=' . $receiver_id . '&error=' . ($given_captcha === '' ? 'captcha_required' : 'captcha_wrong'));
            exit;
        }
    }
    captchaRegisterSend();

    $_SESSION['last_message_time'] = $_SESSION['last_message_time'] ?? 0;
    // «Отпечаток» отправки: получатель + текст + признаки вложений. Нужен, чтобы отличить случайную двойную
    // отправку одного и того же сообщения (повторный submit/запрос) от настоящего спама.
    $send_fingerprint = md5(implode('|', [
        $receiver_id,
        trim((string)($_POST['message'] ?? '')),
        count($photo_files),
        (isset($_FILES['voice']) && $_FILES['voice']['error'] !== UPLOAD_ERR_NO_FILE) ? 'v' : '',
        (isset($_FILES['video']) && $_FILES['video']['error'] !== UPLOAD_ERR_NO_FILE) ? 'x' : '',
    ]));
    if (time() - (int)$_SESSION['last_message_time'] < 1) {
        if (($_SESSION['last_message_fingerprint'] ?? '') === $send_fingerprint) {
            // то же самое сообщение уже принято секунду назад — это двойной запрос, а не новое сообщение:
            // ничего не добавляем и не показываем пугающую ошибку, просто возвращаем в диалог
            header('Location: messages.php?dialog=' . $receiver_id);
            exit;
        }
        showErrorPage(429, 'Пожалуйста, подождите секунду между сообщениями.', 'messages.php?dialog=' . $receiver_id);
    }
    $_SESSION['last_message_time'] = time();
    $_SESSION['last_message_fingerprint'] = $send_fingerprint;

    $has_voice = isset($_FILES['voice']) && $_FILES['voice']['error'] !== UPLOAD_ERR_NO_FILE;
    $has_photo = $photo_files !== [];
    $has_video = isset($_FILES['video']) && $_FILES['video']['error'] !== UPLOAD_ERR_NO_FILE;

    $plain_text = trim((string)($_POST['message'] ?? ''));
    if (mb_strlen($plain_text, 'UTF-8') > 10000) {
        $plain_text = mb_substr($plain_text, 0, 10000, 'UTF-8');
    }
    if ($has_voice) {
        $plain_text = '';
    }

    $is_encrypted = 0;
    $stored_text  = $plain_text;
    if ($plain_text !== '' && $receiver_id !== $user_id) {
        $key = generateEncryptionKey($user_id, $receiver_id);
        $enc = encryptMessage($plain_text, $key);
        if ($enc !== '') {
            $stored_text  = $enc;
            $is_encrypted = 1;
        }
    }

    $message_type   = 'text';
    $file_path      = '';
    $voice_duration = null;
    $waveform_json  = getPostedWaveform();

    $extra_photo_paths = [];
    if ($has_photo) {
        foreach ($photo_files as $photo_file) {
            $uploaded = uploadFile($photo_file, 'photo', 20 * 1024 * 1024, 'uploads/photos/', ALLOWED_PHOTO_TYPES);
            if (!$uploaded) continue;
            if ($file_path === '') {
                $file_path = $uploaded;
                $message_type = 'photo';
            } else {
                $extra_photo_paths[] = $uploaded;
            }
        }
    }

    if ($has_video) {
        $uploaded = uploadFile($_FILES['video'], 'video', UPLOAD_MAX_SIZE, 'uploads/videos/', ALLOWED_VIDEO_TYPES);
        if ($uploaded) {
            $file_path = $uploaded;
            $message_type = 'video';
        }
    }

    if ($has_voice) {
        $uploaded = uploadFile($_FILES['voice'], 'voice', UPLOAD_VOICE_MAX_SIZE, 'uploads/voice/', ALLOWED_VOICE_TYPES);
        if ($uploaded) {
            $file_path = $uploaded;
            $message_type = 'voice';
            $voice_duration = isset($_POST['voice_duration']) ? (int)$_POST['voice_duration'] : null;
            if ($voice_duration !== null && $voice_duration <= 0) {
                $voice_duration = 1;
            }
            if ($waveform_json === null) {
                $waveform_json = json_encode(array_fill(0, 32, 25));
            }
        } else {
            error_log('Voice upload rejected: ' . json_encode($_FILES['voice'], JSON_UNESCAPED_SLASHES));
        }
    }

    if (!$has_voice && !$has_photo && !$has_video) {
        $legacy_voice = resolveLegacyVoice($conn, $plain_text);
        if ($legacy_voice) {
            $stored_text = '';
            $file_path = $legacy_voice['file_path'];
            $message_type = 'voice';
            $voice_duration = $legacy_voice['voice_duration'];
            $is_encrypted = 0;
        }
    }

    if ($stored_text === '' && $file_path === '') {
        header('Location: messages.php?dialog=' . $receiver_id);
        exit;
    }

    $reply_to_id = isset($_POST['reply_to_id']) ? (int)$_POST['reply_to_id'] : 0;
    if ($reply_to_id > 0) {
        $reply_stmt = $conn->prepare('
            SELECT id FROM messages
            WHERE id = ? AND ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
        ');
        if ($reply_stmt) {
            $reply_stmt->bind_param('iiiii', $reply_to_id, $user_id, $receiver_id, $receiver_id, $user_id);
            $reply_stmt->execute();
            $reply_valid = $reply_stmt->get_result()->num_rows > 0;
            $reply_stmt->close();
            if (!$reply_valid) $reply_to_id = 0;
        } else {
            $reply_to_id = 0;
        }
    }

    $conn->begin_transaction();
    try {
    if ($message_type === 'voice' && $file_path !== '') {
        $stored_text = '';
    }

    $insert_sql = 'INSERT INTO messages
             (sender_id, receiver_id, message, message_type, file_path, voice_duration, waveform, is_encrypted, is_read, is_favorite, reply_to_id, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, NOW())';
        $stmt = $conn->prepare($insert_sql);
        if (!$stmt) {
            throw new RuntimeException('Prepare failed: ' . $conn->error);
        }
        safeBind(
            $stmt,
            $insert_sql,
            [$user_id, $receiver_id, $stored_text, $message_type, $file_path, $voice_duration, $waveform_json, $is_encrypted, $reply_to_id],
            'iisssisii'
        );
        if (!$stmt->execute()) {
            throw new RuntimeException('Message insert failed: ' . $stmt->error);
        }
        $message_id = $stmt->insert_id;
        $stmt->close();

        // Несколько фото сразу: остальные уходят следом отдельными сообщениями
        if ($message_type === 'photo') {
            insertExtraPhotoMessages($conn, $user_id, $receiver_id, $extra_photo_paths);
        }

        if ($message_type === 'voice' && $file_path !== '') {
            try {
                saveVoiceRecord($conn, $user_id, $file_path, $voice_duration, $waveform_json);
            } catch (Throwable $e) {
                error_log('Voice history save failed after message insert #' . $message_id . ': ' . $e->getMessage());
            }
        }

        if ($receiver_id !== $user_id && !isDialogMuted($conn, $receiver_id, $user_id)) {
            $sender_username = profileDisplayName($conn, $user_id, (string)($_SESSION['username'] ?? 'Пользователь'));
            $notif_message = $sender_username . ' отправил(а) вам сообщение';
            $notif_link = 'messages.php?dialog=' . $user_id;

            notifyOnce($conn, $receiver_id, $user_id, 'message', $notif_message, $notif_link);
        }

        $conn->commit();
        header('Location: messages.php?dialog=' . $receiver_id);
        exit;
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Transaction failed: ' . $e->getMessage());
        showErrorPage(500, 'Не удалось отправить сообщение. Попробуйте позже.', 'messages.php?dialog=' . $receiver_id, '', $e->getMessage());
    }
}

// ============================================================
// 12. ИЗБРАННОЕ СООБЩЕНИЕ (старый эндпоинт)
// ============================================================
if (isset($_GET['toggle_favorite_msg'], $_GET['msg_id'])) {
    $msg_id = (int)$_GET['msg_id'];
    $dialog_param = isset($_GET['dialog']) ? (int)$_GET['dialog'] : 0;

    if (!legacyCsrfValid()) {
        // Токен неверный/отсутствует (например, чужая ссылка без &csrf=...) — молча не меняем ничего
        header('Location: messages.php' . ($dialog_param > 0 ? '?dialog=' . $dialog_param : ''));
        exit;
    }

    $stmt = $conn->prepare('SELECT sender_id, receiver_id FROM messages WHERE id = ?');
    $stmt->bind_param('i', $msg_id);
    $stmt->execute();
    $msg = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($msg && ((int)$msg['sender_id'] === $user_id || (int)$msg['receiver_id'] === $user_id)) {
        $stmt = $conn->prepare('UPDATE messages SET is_favorite = NOT is_favorite WHERE id = ?');
        $stmt->bind_param('i', $msg_id);
        $stmt->execute();
        $stmt->close();
    }

    header('Location: messages.php' . ($dialog_param > 0 ? '?dialog=' . $dialog_param : ''));
    exit;
}

// ============================================================
// 13. ДАННЫЕ ПОЛЬЗОВАТЕЛЯ
// ============================================================
$stmt = $conn->prepare("SELECT u.id, u.username, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS display_name, u.avatar, u.status, u.last_seen, u.is_admin FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
$stmt->close();

$username = $current_user_data['username'] ?? 'Пользователь';
$_SESSION['username'] = $username;   // в сессии остаётся логин
$display_name_me = (string)($current_user_data['display_name'] ?? $username);   // для показа: «Имя Фамилия» или логин
$is_admin = !empty($current_user_data['is_admin']);

$conn->query("
    CREATE TABLE IF NOT EXISTS favorite_dialogs (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        dialog_user_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_favorite (user_id, dialog_user_id),
        INDEX user_id (user_id),
        INDEX dialog_user_id (dialog_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// ============================================================
// 16. ИЗБРАННЫЙ ДИАЛОГ
// ============================================================
if (isset($_GET['toggle_favorite'], $_GET['fav_user_id'])) {
    $target_user = (int)$_GET['fav_user_id'];
    if ($target_user > 0 && $target_user !== $user_id && legacyCsrfValid()) {
        $stmt = $conn->prepare('SELECT id FROM favorite_dialogs WHERE user_id = ? AND dialog_user_id = ?');
        $stmt->bind_param('ii', $user_id, $target_user);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($exists) {
            $stmt = $conn->prepare('DELETE FROM favorite_dialogs WHERE user_id = ? AND dialog_user_id = ?');
        } else {
            $stmt = $conn->prepare('INSERT INTO favorite_dialogs (user_id, dialog_user_id) VALUES (?, ?)');
        }
        $stmt->bind_param('ii', $user_id, $target_user);
        $stmt->execute();
        $stmt->close();
    }
    $dialog_param = isset($_GET['dialog']) ? (int)$_GET['dialog'] : 0;
    header('Location: messages.php' . ($dialog_param > 0 ? '?dialog=' . $dialog_param : ''));
    exit;
}

// ============================================================
// 17. ДИАЛОГИ
// ============================================================
syncCallLogs($conn, $user_id);
$dialogs = apiGetDialogs($conn, $user_id);

// В списке диалогов (и в окне «Переслать») показываем «Имя Фамилия», если они заполнены
if (!empty($dialogs)) {
    try {
        $dlg_ids = array_values(array_unique(array_filter(array_map(static fn($d) => (int)($d['id'] ?? 0), $dialogs))));
        if ($dlg_ids) {
            $dn_map = [];
            $res_dn = $conn->query("SELECT user_id, TRIM(CONCAT_WS(' ', first_name, last_name)) AS n FROM user_profiles WHERE user_id IN (" . implode(',', $dlg_ids) . ")");
            if ($res_dn) {
                while ($r_dn = $res_dn->fetch_assoc()) {
                    if (trim((string)$r_dn['n']) !== '') {
                        $dn_map[(int)$r_dn['user_id']] = (string)$r_dn['n'];
                    }
                }
            }
            foreach ($dialogs as &$dlg_ref) {
                $did = (int)($dlg_ref['id'] ?? 0);
                if (isset($dn_map[$did])) {
                    $dlg_ref['username'] = $dn_map[$did];
                }
            }
            unset($dlg_ref);
        }
    } catch (Throwable $e) {
        error_log('messages.php: не удалось подставить имена в диалоги: ' . $e->getMessage());
    }
}

// ============================================================
// 17.1. ИЗБРАННОЕ
// ============================================================
$self_dialog = [
    'id'                => $user_id,
    'username'          => 'Избранное',
    'avatar'            => '',
    'status'            => 'online',
    'last_seen'         => date('Y-m-d H:i:s'),
    'is_admin'          => 0,
    'is_favorite'       => true,
    'last_message'      => '',
    'last_message_type' => 'text',
    'last_file_path'    => '',
    'last_message_time' => date('Y-m-d H:i:s'),
    'last_message_sender_id' => $user_id,
    'last_message_is_read' => 1,
    'unread'            => 0,
    'is_self'           => true,
    'is_favorites'      => true,
];

$vis_fav = visibleMessageSql('messages');
$stmt = $conn->prepare("
    SELECT message, message_type, file_path, created_at
    FROM messages
    WHERE is_favorite = 1
      AND (sender_id = ? OR receiver_id = ?)
      AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id = messages.id AND h.user_id = ?)
      AND {$vis_fav}
    ORDER BY id DESC LIMIT 1
");
if ($stmt) {
    $stmt->bind_param('iii', $user_id, $user_id, $user_id);
    $stmt->execute();
    $self_last = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($self_last) {
        $self_dialog['last_message']      = $self_last['message'] ?? '';
        $self_dialog['last_message_type'] = $self_last['message_type'] ?? 'text';
        $self_dialog['last_file_path']    = $self_last['file_path'] ?? '';
        $self_dialog['last_message_time'] = $self_last['created_at'] ?? date('Y-m-d H:i:s');
    }
}

array_unshift($dialogs, $self_dialog);

// ============================================================
// 18. ВЫБРАННЫЙ ДИАЛОГ
// ============================================================
$selected_dialog_id = isset($_GET['dialog']) ? (int)$_GET['dialog'] : 0;
$messages = [];
$selected_user = null;
$is_self_dialog = ($selected_dialog_id === $user_id);
$dialog_muted = false;
$dialog_blocked = false;
$blocked_by_peer = false;

if ($selected_dialog_id > 0) {
    if ($is_self_dialog) {
        $selected_user = [
            'id'        => $user_id,
            'username'  => $display_name_me,
            'avatar'    => $current_user_data['avatar'] ?? '',
            'status'    => 'online',
            'last_seen' => date('Y-m-d H:i:s'),
        ];
    } else {
        $stmt = $conn->prepare("SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, u.status, u.last_seen FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
        $stmt->bind_param('i', $selected_dialog_id);
        $stmt->execute();
        $selected_user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }

    if ($selected_user) {
        $enc_key = generateEncryptionKey($user_id, $selected_dialog_id);

        $vis_page = visibleMessageSql('m');
        $stmt = $conn->prepare("
            SELECT m.*, rm.message AS reply_message, rm.message_type AS reply_message_type,
                   rm.sender_id AS reply_sender_id, rm.is_encrypted AS reply_is_encrypted,
                   TIMESTAMPDIFF(SECOND, m.deleted_at, NOW()) AS deleted_age
            FROM messages m
            LEFT JOIN messages rm ON rm.id = m.reply_to_id
            WHERE ((m.sender_id = ? AND m.receiver_id = ?)
               OR (m.sender_id = ? AND m.receiver_id = ?))
              AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id = m.id AND h.user_id = ?)
              AND {$vis_page}
            ORDER BY m.id ASC
        ");
        $stmt->bind_param('iiiii', $user_id, $selected_dialog_id, $selected_dialog_id, $user_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            if ($is_self_dialog) {
                $row['is_read'] = 1;
            }
            if (!empty($row['is_encrypted']) && $row['message'] !== '' && !$is_self_dialog) {
                $dec = decryptMessage($row['message'], $enc_key);
                $row['message'] = ($dec !== '') ? $dec : '';
            }
            if (!empty($row['reply_is_encrypted']) && !empty($row['reply_message']) && !$is_self_dialog) {
                $reply_dec = decryptMessage((string)$row['reply_message'], $enc_key);
                $row['reply_message'] = ($reply_dec !== '') ? $reply_dec : '';
            }
            $legacy_voice = resolveLegacyVoice($conn, (string)$row['message']);
            if ($legacy_voice) {
                $row['message'] = '';
                $row['message_type'] = 'voice';
                $row['file_path'] = $legacy_voice['file_path'];
                $row['voice_duration'] = $legacy_voice['voice_duration'];
                $row['waveform'] = $legacy_voice['waveform'] ?? generateWaveform((int)$row['id'], 32);
            } else {
                $decoded_waveform = !empty($row['waveform'])
                    ? json_decode((string)$row['waveform'], true)
                    : null;
                $row['waveform'] = is_array($decoded_waveform) && count($decoded_waveform) >= 8
                    ? $decoded_waveform
                    : generateWaveform((int)$row['id'], 32);
            }
            $row['is_encrypted'] = 0;
            $messages[] = $row;
        }
        $stmt->close();

        if (!$is_self_dialog) {
            $stmt = $conn->prepare('UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0');
            $stmt->bind_param('ii', $selected_dialog_id, $user_id);
            $stmt->execute();
            $stmt->close();
        }
    }

    if ($selected_dialog_id > 0 && !$is_self_dialog) {
        $dialog_muted = isDialogMuted($conn, $user_id, $selected_dialog_id);
        $dialog_blocked = isDialogBlocked($conn, $user_id, $selected_dialog_id);
        $blocked_by_peer = isDialogBlocked($conn, $selected_dialog_id, $user_id);
    }
}

// ============================================================
// 19. ОБЩИЙ СЧЁТЧИК НЕПРОЧИТАННЫХ
// ============================================================
$unread_count = 0;
$stmt = $conn->prepare('
    SELECT COUNT(*) AS c
    FROM messages
    WHERE receiver_id = ?
      AND is_read = 0
      AND sender_id != receiver_id
      AND deleted_at IS NULL
      AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id = messages.id AND h.user_id = ?)
');
if ($stmt) {
    $stmt->bind_param('ii', $user_id, $user_id);
    $stmt->execute();
    $unread_count = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();
}

// ============================================================
// 20. УВЕДОМЛЕНИЯ
// ============================================================
$notifications = [];
$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) as sender_name, u.username as sender_username, u.avatar as sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id
    LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC
    LIMIT 30");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    if (empty($row['sender_avatar']) && !empty($row['sender_id'])) {
        $stmt2 = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
        $stmt2->bind_param("i", $row['sender_id']);
        $stmt2->execute();
        $res2 = $stmt2->get_result();
        if ($sender_row = $res2->fetch_assoc()) {
            $row['sender_avatar'] = $sender_row['avatar'];
        }
        $stmt2->close();
    }
    $notifications[] = $row;
}
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM notifications
    WHERE user_id = ?
      AND is_read = 0
      AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$notif_count = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();

// ============================================================
// 21. ОТЧЁТЫ
// ============================================================
$pending_reports_count = 0;
if ($is_admin) {
    $res = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
    if ($res) {
        $pending_reports_count = (int)$res->fetch_assoc()['c'];
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сообщения — PLAYERCHAT</title>
    <link rel="stylesheet" href="assets/css/messages.css?v=forward-service-style1">
    <link rel="stylesheet" href="assets/css/emoji.css?v=custom1">
    <link rel="stylesheet" href="assets/css/custom-emoji.css?v=1">
    <link rel="stylesheet" href="assets/css/calls.css?v=2">
    <script src="assets/js/header-dropdowns.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/header-dropdowns.js') ?>" defer></script>
    <style>
        /* отступ справа, чтобы карточки диалогов не касались разделителя (resizer) */
        .dialogs-sidebar .dialog-item { margin-right: 14px; }
    </style>
    <style>
        /* Расширенная карточка уведомления в шапке — как в index.php/settings.php:
           аватар отправителя, бейдж типа и ссылка "Показать все" внизу списка. */
        .notifications-title {
            font-weight: 600;
            font-size: 14px;
            color: #fff;
        }

        .notifications-header-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .notifications-count {
            color: #949ba4;
            font-size: 11px;
            white-space: nowrap;
        }

        .notifications-empty .empty-icon {
            font-size: 26px;
            margin-bottom: 6px;
        }

        .notifications-empty .empty-text {
            color: #dbdee1;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 3px;
        }

        .notifications-empty .empty-sub {
            color: #949ba4;
            font-size: 12px;
        }

        .notif-avatar-wrapper {
            position: relative;
            flex-shrink: 0;
        }

        .notif-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            overflow: hidden;
            background: #5865f2;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 700;
            font-size: 14px;
        }

        .notif-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .notif-avatar .avatar-letter {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
        }

        .notif-avatar-status {
            position: absolute;
            bottom: -3px;
            right: -3px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #2b2d31;
            border: 2px solid #2b2d31;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            line-height: 1;
        }

        .notif-sender {
            color: #fff;
            margin-right: 6px;
        }

        .notif-message {
            color: #dbdee1;
        }

        .notif-meta {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 4px;
        }

        .notif-type-badge {
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 6px;
            background: #35373c;
            color: #b5bac1;
            white-space: nowrap;
        }

        .notifications-footer {
            padding: 10px 14px;
            text-align: center;
            border-top: 1px solid #3f4147;
        }

        .view-all-notifications {
            color: #5865f2;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
        }

        .view-all-notifications:hover {
            text-decoration: underline;
        }
    </style>
    <style>
        /* Кнопка «Завершить все сеансы» под уведомлениями о входе */
        .login-alert-actions {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        .btn-end-sessions {
            border: none;
            border-radius: 8px;
            padding: 8px 14px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            background: #da373c;
            color: #fff;
            transition: background-color .15s ease, opacity .15s ease;
        }
        .btn-end-sessions:hover:not(:disabled) { background: #c62e33; }
        .btn-end-sessions:disabled { opacity: .6; cursor: default; }
        .end-sessions-status {
            font-size: 12px;
            color: var(--text-secondary, #949ba4);
        }
        .end-sessions-status.is-error { color: #da373c; }
    </style>
</head>
<body data-theme="<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>" data-theme-mode="<?= $theme === 'auto' ? 'auto' : 'manual' ?>" data-user-id="<?= $user_id ?>" data-dialog-id="<?= $selected_dialog_id ?>" data-delete-ttl="<?= (int)DELETED_MESSAGE_TTL ?>" data-csrf-token="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
<script>
(function () {
    if (document.body.dataset.theme !== 'auto') return;
    document.body.dataset.themeMode = 'auto';
    try {
        var zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        document.body.dataset.timezone = zone;
        document.body.dataset.comparisonTimezone = 'UTC';
    } catch (error) {}
})();
</script>
<script>
// Сервер хранит время в UTC. Метка сообщения (msg-time) уже переводится в
// локальное время браузера где-то в основном JS чата. Строку "Время: ..."
// внутри системных сообщений "Выполнен вход" / "Подозрительный вход" нужно
// перевести так же — заменяем помеченный span'ом .login-time-value на дату,
// посчитанную из того же UTC data-timestamp, что и у соседней метки msg-time.
(function () {
    function pad(n) { return String(n).padStart(2, '0'); }

    function localize(el) {
        var ts = parseInt(el.dataset.timestamp, 10);
        if (!ts) return;
        var d = new Date(ts * 1000);
        el.textContent = pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear()
            + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
        el.dataset.localized = '1';
    }

    function scan(root) {
        (root || document).querySelectorAll('.login-time-value[data-timestamp]:not([data-localized])').forEach(localize);
    }

    function init() {
        scan();

        var container = document.getElementById('chatMessages');
        if (container && window.MutationObserver) {
            new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    mutation.addedNodes.forEach(function (node) {
                        if (node.nodeType !== 1) return;
                        if (node.matches && node.matches('.login-time-value')) {
                            localize(node);
                        }
                        scan(node);
                    });
                });
            }).observe(container, { childList: true, subtree: true });
        }
    }

    // Скрипт стоит в начале <body>, а #chatMessages и сами .login-time-value
    // рендерятся значительно ниже по странице — на момент выполнения этого
    // <script> их ещё нет в DOM. Ждём полной загрузки разметки страницы.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
</script>
<script>
// Кнопка «Завершить все сеансы» в уведомлениях о входе (см. api=end_sessions в messages.php).
// Реально завершает сеансы на всех устройствах, кроме текущего: увеличивает users.session_version
// и стирает remember_token на сервере; на этом устройстве версия сессии сразу обновляется,
// так что сам пользователь из чата не вылетает.
(function () {
    function setStatus(el, text, isError) {
        if (!el) return;
        el.textContent = text;
        el.classList.toggle('is-error', !!isError);
    }

    function handleClick(btn) {
        if (btn.disabled) return;
        btn.disabled = true;

        var wrapper = btn.closest('.login-alert-actions');
        var statusEl = wrapper ? wrapper.querySelector('[data-end-sessions-status]') : null;
        var csrfToken = document.body.dataset.csrfToken || '';

        setStatus(statusEl, 'Завершаем сеансы…', false);

        fetch('api/messages.php?api=end_sessions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRF-Token': csrfToken,
            },
            credentials: 'same-origin',
            body: 'csrf_token=' + encodeURIComponent(csrfToken),
        })
            .then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); })
            .then(function (result) {
                if (result.ok && result.data && result.data.success) {
                    if (result.data.csrf_token) {
                        document.body.dataset.csrfToken = result.data.csrf_token;
                        document.querySelectorAll('input[name="csrf_token"]').forEach(function (input) {
                            input.value = result.data.csrf_token;
                        });
                    }
                    btn.textContent = 'Сеансы завершены';
                    setStatus(statusEl, 'Все остальные устройства разлогинены.', false);
                } else {
                    btn.disabled = false;
                    setStatus(statusEl, 'Не удалось завершить сеансы. Попробуйте ещё раз.', true);
                }
            })
            .catch(function () {
                btn.disabled = false;
                setStatus(statusEl, 'Ошибка сети. Попробуйте ещё раз.', true);
            });
    }

    function init() {
        document.addEventListener('click', function (event) {
            var btn = event.target.closest('[data-end-sessions]');
            if (btn) handleClick(btn);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
</script>

<?php if (isset($_GET['error']) && strpos((string)$_GET['error'], 'captcha') !== 0): ?>
    <div class="error-message" style="position:fixed;top:10px;left:50%;transform:translateX(-50%);z-index:9999;">
        <?php if ($_GET['error'] === 'rate_limit'): ?>
            ⚠️ Пожалуйста, подождите 1 секунду между сообщениями
        <?php elseif ($_GET['error'] === 'blocked_by_receiver'): ?>
            ⚠️ Вы не можете написать этому пользователю: он вас заблокировал
        <?php elseif ($_GET['error'] === 'receiver_blocked'): ?>
            ⚠️ Вы заблокировали этого пользователя. Разблокируйте его, чтобы написать
        <?php elseif ($_GET['error'] === 'server'): ?>
            ⚠️ Произошла ошибка сервера. Попробуйте позже.
        <?php endif; ?>
    </div>
<?php endif; ?>

<header class="header header-cosmic">
    <span class="header-shooting-stars" aria-hidden="true">
        <span class="sky-cloud" aria-hidden="true"></span>
        <span class="sky-rain" aria-hidden="true"></span>
        <span class="sky-snow" aria-hidden="true"></span>
        <span class="sky-fog" aria-hidden="true"></span>
        <span class="sky-flash" aria-hidden="true"></span>
        <span class="header-shooting-star star-one"></span>
        <span class="header-shooting-star star-two"></span>
        <span class="header-shooting-star star-three"></span>
        <span class="header-comet"></span>
    </span>
    <div class="header-left">
        <div class="logo">
            <div class="logo-icon">
                <img src="images/logo_type.svg" alt="SPACE Logo" width="40" height="40">
            </div>
        </div>
    </div>

    <div class="search-box"></div>

    <div class="header-right">
        <?php if ($is_admin): ?>
            <a href="reports.php" class="moderation-btn" aria-label="Модерация">
                <img src="images/protection.svg" alt="" class="moderation-icon">
                <?php if ($pending_reports_count > 0): ?>
                    <span class="moderation-badge"><?= $pending_reports_count > 99 ? '99+' : $pending_reports_count ?></span>
                <?php endif; ?>
            </a>
        <?php endif; ?>

        <div class="notifications-wrapper">
            <button class="notifications-btn" id="notificationsBtn" aria-label="Уведомления">
                <img src="images/Notification.svg" alt="">
                <?php if ($notif_count > 0): ?>
                    <span class="notifications-badge" id="notificationsBadge"><?= $notif_count > 99 ? '99+' : $notif_count ?></span>
                <?php else: ?>
                    <span class="notifications-badge" id="notificationsBadge" style="display:none;">0</span>
                <?php endif; ?>
            </button>

            <div class="notifications-dropdown" id="notificationsDropdown">
                <div class="notifications-header">
                    <span class="notifications-title">Уведомления</span>
                    <div class="notifications-header-actions">
                        <?php if ($notif_count > 0): ?>
                            <button class="mark-all-read-btn" id="markAllReadBtn">Все прочитано</button>
                        <?php endif; ?>
                        <span class="notifications-count" id="notificationsCount"><?= $notif_count ?> новых</span>
                    </div>
                </div>
                <div class="notifications-list" id="notificationsList">
                    <?php if (empty($notifications)): ?>
                        <div class="notifications-empty">
                            <div class="empty-icon">🔔</div>
                            <div class="empty-text">Нет уведомлений</div>
                            <div class="empty-sub">Здесь будут появляться ваши уведомления</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($notifications as $notif):
                            $icon = getNotificationIcon((string)$notif['type']);
                            $notif_type_class = $notif['type'];
                            $sender_avatar = $notif['sender_avatar'] ?? '';
                            $sender_name = $notif['sender_name'] ?? '';

                            $avatar_exists = false;
                            if (!empty($sender_avatar)) {
                                $paths_to_check = [
                                    $sender_avatar,
                                    'uploads/avatars/' . basename($sender_avatar),
                                    'assets/images/' . basename($sender_avatar)
                                ];
                                foreach ($paths_to_check as $path) {
                                    if (file_exists($path)) {
                                        $avatar_exists = true;
                                        $sender_avatar = $path;
                                        break;
                                    }
                                }
                            }
                        ?>
                            <a href="<?= htmlspecialchars($notif['link'] ?: '#') ?>"
                               class="notification-item <?= $notif['is_read'] ? 'read' : 'unread' ?> type-<?= htmlspecialchars($notif_type_class) ?>"
                               data-notification-id="<?= (int)$notif['id'] ?>">
                                <div class="notif-avatar-wrapper">
                                    <div class="notif-avatar">
                                        <?php if ($avatar_exists): ?>
                                            <img src="<?= htmlspecialchars($sender_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?>">
                                        <?php elseif (!empty($sender_name)): ?>
                                            <span class="avatar-letter"><?= htmlspecialchars(mb_strtoupper(mb_substr($sender_name, 0, 1, 'UTF-8'), 'UTF-8')) ?></span>
                                        <?php else: ?>
                                            <span class="avatar-letter">?</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="notif-avatar-status">
                                        <span class="notif-type-icon"><?php if ($notif['type'] === 'like'): ?><img class="like-heart like-heart-notif" src="images/heart.svg" alt=""><?php else: ?><?= htmlspecialchars($icon) ?><?php endif; ?></span>
                                    </div>
                                </div>
                                <div class="notif-content">
                                    <div class="notif-text">
                                        <?php if (!empty($sender_name)): ?>
                                            <?php
                                            // Ник уже выведен жирным — не повторяем его в начале текста
                                            $notif_msg = (string)$notif['message'];
                                            foreach ([(string)$sender_name, (string)($notif['sender_username'] ?? '')] as $strip_name) {
                                                if ($strip_name !== '' && mb_strpos($notif_msg, $strip_name) === 0) {
                                                    $notif_msg = ltrim(mb_substr($notif_msg, mb_strlen($strip_name)));
                                                    break;
                                                }
                                            }
                                            ?>
                                            <strong class="notif-sender"><?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?></strong><span class="notif-message"><?= htmlspecialchars($notif_msg, ENT_QUOTES, "UTF-8") ?></span>
                                        <?php else: ?>
                                            <span class="notif-message"><?= htmlspecialchars($notif['message'], ENT_QUOTES, "UTF-8") ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="notif-meta">
                                        <span class="notif-time"><?= timeAgo($notif['created_at']) ?></span>
                                    </div>
                                </div>
                                <?php if (!$notif['is_read']): ?>
                                    <span class="notif-dot"></span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                        <div class="notifications-footer">
                            <a href="notifications.php" class="view-all-notifications">Показать все уведомления →</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="avatar-dropdown">
            <?php
            $current_avatar   = $current_user_data['avatar'] ?? '';
            $current_username = $current_user_data['display_name'] ?? ($current_user_data['username'] ?? 'Пользователь');
            $current_letter   = getAvatarLetter($current_username);
            $current_status   = $current_user_data['status'] ?? 'offline';
            $current_last_seen = $current_user_data['last_seen'] ?? null;
            ?>
            <button class="header-avatar <?= isOnline($current_status, $current_last_seen) ? 'is-online' : 'is-offline' ?>" id="avatarBtn" aria-label="Мой профиль">
                <?php if (safeFileExists($current_avatar)): ?>
                    <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, 'UTF-8') ?>" alt="">
                <?php else: ?>
                    <?= htmlspecialchars($current_letter, ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
            </button>

            <div class="dropdown-menu" id="avatarDropdown">
                <div class="dropdown-header">
                    <div class="dropdown-avatar">
                        <?php if (safeFileExists($current_avatar)): ?>
                            <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, 'UTF-8') ?>" alt="">
                        <?php else: ?>
                            <?= htmlspecialchars($current_letter, ENT_QUOTES, 'UTF-8') ?>
                        <?php endif; ?>
                    </div>
                    <div class="dropdown-user-info">
                        <div class="dropdown-username"><?= htmlspecialchars($current_username, ENT_QUOTES, 'UTF-8') ?></div>
                    </div>
                </div>

                <div class="dropdown-divider"></div>

                <a href="settings.php" class="dropdown-item">
                    <span class="dropdown-icon">⚙</span> Настройки
                </a>

                <div class="theme-trigger" id="themeTrigger">
                    <span class="dropdown-icon">🎨</span>
                    <span>Тема</span>
                    <span class="theme-current">
                        <?php
                        $theme_name = ['dark' => 'Тёмная', 'light' => 'Светлая', 'system' => 'Системная'][$theme] ?? 'Тёмная';
                        echo htmlspecialchars($theme_name, ENT_QUOTES, 'UTF-8');
                        ?>
                    </span>
                    <span class="theme-arrow" id="themeArrow">▼</span>
                </div>

                <div class="theme-submenu" id="themeSubmenu">
                    <?php foreach (['dark' => 'Тёмная', 'light' => 'Светлая', 'system' => 'Системная'] as $key => $label): ?>
                        <a href="?theme=<?= $key ?>&dialog=<?= $selected_dialog_id ?>"
                           class="theme-item <?= $theme === $key ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot <?= $key ?>"></span>
                                <?= $label ?>
                            </span>
                            <?php if ($theme === $key): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <div class="dropdown-divider"></div>

                <a href="logout.php" class="dropdown-item logout-item">
                    <span class="dropdown-icon">↪</span> Выйти
                </a>
            </div>
        </div>
    </div>
</header>

<div class="layout">

    <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

    <main class="messages-layout" id="messagesLayout">

        <div class="dialogs-sidebar" id="dialogsSidebar">
            <div class="dialogs-header">
                <span>Сообщения</span>
                <button type="button" class="search-open-btn" onclick="openSearchModal()" aria-label="Поиск"><img src="images/nav-search.svg" alt="" class="ui-svg"></button>
            </div>

            <?php foreach ($dialogs as $dialog): ?>
                <?php $is_self = !empty($dialog['is_self']); ?>
                <div class="dialog-item <?= $selected_dialog_id === (int)$dialog['id'] ? 'active' : '' ?> <?= $is_self ? 'dialog-self' : '' ?>"
                     data-dialog-id="<?= (int)$dialog['id'] ?>">
                    <a href="messages.php?dialog=<?= (int)$dialog['id'] ?>" class="dialog-link">
                        <div class="dialog-avatar <?= $is_self ? 'is-notes' : '' ?>">
                            <?php if ($is_self): ?>
                                <img src="images/nav-favorite.svg" alt="" class="notes-icon notes-icon-star" loading="lazy">
                            <?php elseif (safeFileExists($dialog['avatar'] ?? '')): ?>
                                <img src="<?= htmlspecialchars($dialog['avatar'], ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy">
                            <?php else: ?>
                                <?= htmlspecialchars(getAvatarLetter($dialog['username']), ENT_QUOTES, 'UTF-8') ?>
                            <?php endif; ?>
                        </div>
                        <div class="dialog-info">
                            <div class="dialog-name">
                                <?= htmlspecialchars($dialog['username'], ENT_QUOTES, 'UTF-8') ?>
                            </div>
                            <div class="dialog-preview">
                                <span class="dialog-preview-text" data-dialog-preview>
                                    <?= htmlspecialchars(formatMessagePreview($dialog['last_message'] ?? '', $dialog['last_message_type'] ?? 'text', (int)($dialog['last_message_sender_id'] ?? 0) === $user_id, (string)($dialog['username'] ?? '')), ENT_QUOTES, 'UTF-8') ?>
                                </span>
                                <?php if (!$is_self && (int)($dialog['last_message_sender_id'] ?? 0) === $user_id): ?>
                                    <span class="dialog-message-status <?= !empty($dialog['last_message_is_read']) ? 'is-read' : 'is-unread' ?>"
                                          title="<?= !empty($dialog['last_message_is_read']) ? 'Прочитано' : 'Не прочитано' ?>">
                                        <?= readStatusDots(!empty($dialog['last_message_is_read'])) ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if (!$is_self && $dialog['unread'] > 0): ?>
                            <span class="dialog-unread"><?= $dialog['unread'] > 99 ? '99+' : $dialog['unread'] ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Разделитель: тянется мышью/пальцем и стрелками ←/→; кнопка по центру сворачивает и разворачивает список -->
        <div class="resizer" id="resizer" role="separator" aria-orientation="vertical" tabindex="0"
             aria-label="Изменить ширину списка диалогов">
            <button type="button" class="sidebar-resize-handle" id="sidebarResizeHandle" tabindex="-1"
                    aria-expanded="true"
                    aria-label="Свернуть или развернуть список диалогов"
                    title="Свернуть или развернуть список диалогов">‹</button>
        </div>

        <div class="chat-area">
            <?php if ($selected_user): ?>
                <div class="chat-header">
                    <div class="chat-header-avatar <?= $is_self_dialog ? 'is-notes' : '' ?> <?= (!$is_self_dialog && isOnline($selected_user['status'] ?? null, $selected_user['last_seen'] ?? null)) ? 'is-online' : '' ?>">
                        <?php if ($is_self_dialog): ?>
                            <img src="images/nav-favorite.svg" alt="" class="notes-icon notes-icon-star" loading="lazy">
                        <?php elseif (safeFileExists($selected_user['avatar'] ?? '')): ?>
                            <img src="<?= htmlspecialchars($selected_user['avatar'], ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy">
                        <?php else: ?>
                            <?= htmlspecialchars(getAvatarLetter($selected_user['username']), ENT_QUOTES, 'UTF-8') ?>
                        <?php endif; ?>
                        <?php if (!$is_self_dialog && isOnline($selected_user['status'] ?? null, $selected_user['last_seen'] ?? null)): ?>
                            <span class="chat-header-online-dot" aria-label="Онлайн"></span>
                        <?php endif; ?>
                    </div>

                    <div class="chat-header-info">
                        <div class="chat-header-name">
                            <?php if (!$is_self_dialog && (int)$selected_user['id'] > 0): ?>
                                <a class="chat-header-name-text chat-header-name-link"
                                   href="<?= (int)$selected_user['id'] ?>"
                                   title="Открыть страницу пользователя"><?= htmlspecialchars($selected_user['username'], ENT_QUOTES, 'UTF-8') ?></a>
                            <?php else: ?>
                                <span class="chat-header-name-text <?= $is_self_dialog ? 'is-favorites' : '' ?>">
                                    <?= $is_self_dialog
                                        ? 'Избранное'
                                        : htmlspecialchars($selected_user['username'], ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <?php
                            // Служебный аккаунт V SPACE: звонить нельзя, вместо «был(а) в сети» — «Администрация»
                            $is_vs_space_chat = !$is_self_dialog
                                && (int)$selected_user['id'] > 0
                                && (int)$selected_user['id'] === (int)ensureVsSpaceServiceAccount($conn);
                        ?>
                        <?php if ($is_vs_space_chat): ?>
                            <div class="chat-header-status is-admin">Администрация</div>
                        <?php elseif (!$is_self_dialog): ?>
                            <div class="chat-header-status <?= isOnline($selected_user['status'] ?? null, $selected_user['last_seen'] ?? null) ? 'online' : '' ?>">
                                <?= isOnline($selected_user['status'] ?? null, $selected_user['last_seen'] ?? null)
                                    ? 'Онлайн'
                                    : 'Был(а) в сети ' . htmlspecialchars(timeAgo($selected_user['last_seen'] ?? ''), ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if (!$is_self_dialog && !$is_vs_space_chat && (int)$selected_user['id'] > 0): ?>
                        <div class="chat-call-actions" id="chatCallActions"
                             data-peer-id="<?= (int)$selected_user['id'] ?>"
                             data-peer-name="<?= htmlspecialchars((string)$selected_user['username'], ENT_QUOTES, 'UTF-8') ?>"
                             data-peer-avatar="<?= safeFileExists($selected_user['avatar'] ?? '') ? htmlspecialchars((string)$selected_user['avatar'], ENT_QUOTES, 'UTF-8') : '' ?>">
                            <button type="button" class="chat-call-btn" data-call-media="audio" title="Позвонить" aria-label="Позвонить">
                                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                            </button>
                            <button type="button" class="chat-call-btn" data-call-media="video" title="Видеозвонок" aria-label="Видеозвонок">
                                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 4z"/></svg>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if (!$is_self_dialog): ?>
                        <?php /* старая кнопка-колокольчик оставлена скрытой, чтобы messages.js не терял свой элемент */ ?>
                        <button type="button" class="dialog-notify-btn <?= $dialog_muted ? 'muted' : '' ?>" id="dialogNotifyBtn" data-muted="<?= $dialog_muted ? '1' : '0' ?>" hidden aria-hidden="true" tabindex="-1"><?= $dialog_muted ? '🔕' : '🔔' ?></button>

                        <div class="dlg-more" id="dlgMore" data-dialog-id="<?= (int)$selected_dialog_id ?>">
                            <button type="button" class="dlg-more-btn" id="dlgMoreBtn" aria-haspopup="true" aria-expanded="false" aria-label="Ещё" title="Ещё">
                                <img src="images/change.svg" alt="" width="26" height="12">
                            </button>
                            <div class="dlg-menu-wrap">
                                <div class="dlg-menu" role="menu">
                                    <button type="button" class="dlg-item" id="dlgMute" role="menuitem"><?= $dialog_muted ? 'Включить уведомления' : 'Отключить уведомления' ?></button>
                                    <?php if (!$is_vs_space_chat): ?>
                                        <div class="dlg-sep"></div>
                                        <button type="button" class="dlg-item dlg-red" id="dlgClear" role="menuitem">Очистить историю</button>
                                        <button type="button" class="dlg-item dlg-red" id="dlgBlock" role="menuitem" data-blocked="<?= $dialog_blocked ? '1' : '0' ?>"><?= $dialog_blocked ? 'Разблокировать' : 'Заблокировать' ?></button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="message-selection-toolbar" id="messageSelectionToolbar" hidden>
                    <strong><span id="selectedMessageCount">0</span> выбрано</strong>
                    <button type="button" data-selection-action="copy">Копировать</button>
                    <button type="button" data-selection-action="forward">Переслать</button>
                    <button type="button" data-selection-action="unread">Непрочитано</button>
                    <button type="button" data-selection-action="delete">Удалить</button>
                    <button type="button" data-selection-action="clear" class="selection-cancel">Отмена</button>
                </div>

                <div class="chat-messages" id="chatMessages">
                    <?php if (empty($messages)): ?>
                        <div class="empty-chat">
                            <div class="empty-icon"><img src="images/nav-messages.svg" alt="" class="ui-svg-big"></div>
                            <div>Нет сообщений. Напишите первым!</div>
                        </div>
                    <?php else: ?>
                        <?php
                            $previous_message_date = '';
                            // Нужен, чтобы узнавать в цикле ниже сообщения-уведомления о входе
                            // от служебного аккаунта V SPACE и показывать под ними кнопку
                            // «Завершить все сеансы».
                            $vs_space_account_id = ensureVsSpaceServiceAccount($conn);
                        ?>
                        <?php foreach ($messages as $msg):
                            $is_mine = ((int)$msg['sender_id'] === $user_id);
                            $message_type = $msg['message_type'] ?? 'text';
                            $file_path = $msg['file_path'] ?? '';
                            $voice_duration = $msg['voice_duration'] ?? null;
                            $waveform = $msg['waveform'] ?? generateWaveform((int)$msg['id'], 32);
                            $msg_timestamp = strtotime((string)$msg['created_at']);
                            $msg_time = htmlspecialchars(formatMessageTime($msg['created_at']), ENT_QUOTES, 'UTF-8');
                            $message_date = date('Y-m-d', strtotime($msg['created_at']));
                            $is_deleted = !empty($msg['deleted_at']);
                            $msg_text = (string)($msg['message'] ?? '');
                            // Сообщения «недоступно» (текст не удалось расшифровать / файла нет) не показываем вообще —
                            // как будто они удалены. Условие повторяет ветку else ниже по шаблону.
                            $has_media = in_array($message_type, ['photo', 'video', 'voice'], true) && safeFileExists($file_path);
                            if (!$is_deleted && !$has_media && $msg_text === '') {
                                continue;
                            }
                            $reply_text = (string)($msg['reply_message'] ?? '');
                            if (($msg['reply_message_type'] ?? '') === 'call') {
                                $reply_text = (string)(callMessageText($reply_text, (int)($msg['reply_sender_id'] ?? 0) === $user_id, (string)($selected_user['username'] ?? '')) ?? $reply_text);
                            }
                        ?>
                            <?php if ($message_date !== $previous_message_date): ?>
                                <div class="chat-date-divider">
                                    <span><?= htmlspecialchars(formatChatDate($msg['created_at']), ENT_QUOTES, 'UTF-8') ?></span>
                                </div>
                                <?php $previous_message_date = $message_date; ?>
                            <?php endif; ?>
                            <div class="chat-message <?= $is_mine ? 'mine' : '' ?> <?= $is_deleted ? 'is-deleted' : '' ?>"
                                 data-message-id="<?= (int)$msg['id'] ?>"
                                 data-message-text="<?= htmlspecialchars($msg_text, ENT_QUOTES, 'UTF-8') ?>"
                                 data-message-type="<?= htmlspecialchars((string)$message_type, ENT_QUOTES, 'UTF-8') ?>"
                                 data-is-read="<?= !empty($msg['is_read']) ? '1' : '0' ?>"
                                 data-is-mine="<?= $is_mine ? '1' : '0' ?>"
                                 data-deleted-at="<?= $is_deleted ? htmlspecialchars((string)$msg['deleted_at'], ENT_QUOTES, 'UTF-8') : '' ?>"
                                 data-delete-remaining="<?= $is_deleted ? max(0, DELETED_MESSAGE_TTL - (int)($msg['deleted_age'] ?? 0)) : '' ?>"
                                 data-can-restore="<?= $is_deleted && isset($msg['deleted_message']) && $msg['deleted_message'] !== null ? '1' : '0' ?>">
                                <div class="msg-content">
                                    <?php if (!empty($msg['forwarded_from_id'])): ?>
                                        <div class="msg-forwarded-label">Пересланное сообщение</div>
                                    <?php endif; ?>
                                    <?php if ($reply_text !== '' || !empty($msg['reply_to_id'])): ?>
                                        <div class="msg-reply-preview">
                                            <span class="msg-reply-label">Ответ</span>
                                            <span><?= $reply_text !== '' ? formatChatMessage(mb_substr($reply_text, 0, 180, 'UTF-8')) : 'Сообщение недоступно' ?></span>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($is_deleted): ?>
                                        <div class="msg-bubble msg-deleted-text">
                                            <span class="msg-text">Сообщение удалено</span>
                                            <span class="msg-meta-inline">
                                                <span class="msg-time" data-timestamp="<?= $msg_timestamp !== false ? (int)$msg_timestamp : 0 ?>"><?= $msg_time ?></span>
                                            </span>
                                        </div>

                                    <?php elseif ($message_type === 'photo' && safeFileExists($file_path)): ?>
                                        <div class="msg-attachment">
                                            <img src="<?= htmlspecialchars($file_path, ENT_QUOTES, 'UTF-8') ?>"
                                                 class="msg-file msg-photo-viewable"
                                                 alt="Фото" loading="lazy">
                                        </div>
                                        <div class="msg-meta">
                                            <span class="msg-time" data-timestamp="<?= $msg_timestamp !== false ? (int)$msg_timestamp : 0 ?>"><?= $msg_time ?></span>
                                            <?php if ($is_mine): ?><span class="msg-status <?= !empty($msg['is_read']) ? 'is-read' : 'is-unread' ?>"><?= readStatusDots(!empty($msg['is_read'])) ?></span><?php endif; ?>
                                        </div>

                                    <?php elseif ($message_type === 'video' && safeFileExists($file_path)): ?>
                                        <video controls class="msg-video" preload="metadata">
                                            <source src="<?= htmlspecialchars($file_path, ENT_QUOTES, 'UTF-8') ?>" type="video/mp4">
                                            Ваш браузер не поддерживает видео.
                                        </video>
                                        <div class="msg-meta">
                                            <span class="msg-time" data-timestamp="<?= $msg_timestamp !== false ? (int)$msg_timestamp : 0 ?>"><?= $msg_time ?></span>
                                            <?php if ($is_mine): ?><span class="msg-status <?= !empty($msg['is_read']) ? 'is-read' : 'is-unread' ?>"><?= readStatusDots(!empty($msg['is_read'])) ?></span><?php endif; ?>
                                        </div>

                                    <?php elseif ($message_type === 'voice' && safeFileExists($file_path)): ?>
                                        <div class="voice-message" data-voice-id="<?= (int)$msg['id'] ?>" data-duration="<?= (int)($voice_duration ?? 0) ?>">
                                            <div class="voice-message-label">Голосовое сообщение</div>
                                            <div class="voice-player-row">
                                                <button type="button" class="voice-play"
                                                        data-src="<?= htmlspecialchars($file_path, ENT_QUOTES, 'UTF-8') ?>"
                                                        aria-label="Воспроизвести"></button>
                                                <div class="voice-content">
                                                    <div class="waveform">
                                                        <div class="wave-bars">
                                                            <?php foreach ($waveform as $h): ?>
                                                                <div class="wave-bar" style="height: <?= (int)$h ?>%"></div>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    </div>
                                                    <div class="voice-time">
                                                        <span class="current-time">0:00</span>
                                                        <span class="duration"><?= $voice_duration ? gmdate('i:s', (int)$voice_duration) : '0:00' ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <audio class="voice-audio" preload="metadata">
                                                <source src="<?= htmlspecialchars($file_path, ENT_QUOTES, 'UTF-8') ?>" type="audio/webm">
                                            </audio>
                                        </div>
                                        <div class="msg-meta">
                                            <span class="msg-time" data-timestamp="<?= $msg_timestamp !== false ? (int)$msg_timestamp : 0 ?>"><?= $msg_time ?></span>
                                            <?php if ($is_mine): ?><span class="msg-status <?= !empty($msg['is_read']) ? 'is-read' : 'is-unread' ?>"><?= readStatusDots(!empty($msg['is_read'])) ?></span><?php endif; ?>
                                        </div>
                                    <?php elseif ((string)($msg['message'] ?? '') !== ''): ?>
                                        <?php
                                            // Уведомления о входе шлёт только служебный аккаунт V SPACE и только
                                            // самому пользователю (получатель = текущий пользователь). Проверяем оба
                                            // условия, а не только текст, чтобы обычное сообщение с похожими словами
                                            // от другого человека кнопку не получило.
                                            $is_login_notice = (int)($msg['sender_id'] ?? 0) === (int)$vs_space_account_id
                                                && (int)($msg['receiver_id'] ?? 0) === $user_id
                                                && preg_match('/^(?:⚠️ Подозрительный вход|Выполнен вход) в аккаунт/u', (string)$msg['message']) === 1;
                                        ?>
                                        <div class="msg-bubble<?= $is_login_notice ? ' msg-bubble-login-alert' : '' ?><?= $message_type === 'call' ? ' msg-bubble-call' . ((strpos((string)$msg['message'], ':video:') !== false || mb_stripos((string)$msg['message'], 'Видео', 0, 'UTF-8') === 0) ? ' is-video' : '') : '' ?>">
                                            <?php
                                                // Сообщения "Выполнен вход" / "Подозрительный вход" содержат строку
                                                // "Время: ДД.ММ.ГГГГ ЧЧ:ММ", посчитанную на сервере в UTC. Помечаем эту
                                                // дату классом login-time-value с data-timestamp — JS ниже (localizeLoginTimes)
                                                // подставит вместо неё локальное время браузера, как и у метки msg-time.
                                                $call_text = $message_type === 'call'
                                                    ? callMessageText((string)$msg['message'], $is_mine, (string)($selected_user['username'] ?? ''))
                                                    : null;
                                                $call_card = $message_type === 'call'
                                                    ? callCardParts((string)$msg['message'], $is_mine, (string)($selected_user['username'] ?? ''))
                                                    : null;
                                                $msg_html = $call_text !== null
                                                    ? htmlspecialchars($call_text, ENT_QUOTES, 'UTF-8')
                                                    : formatChatMessage((string)$msg['message']);
                                                if ($msg_timestamp !== false) {
                                                    $msg_html = preg_replace(
                                                        '/(Время:\s*)(\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2})/u',
                                                        '$1<span class="login-time-value" data-timestamp="' . (int)$msg_timestamp . '">$2</span>',
                                                        $msg_html,
                                                        1
                                                    );
                                                }
                                            ?>
                                            <?php if ($call_card !== null): ?>
                                                <div class="call-card">
                                                    <span class="call-card-icon<?= $call_card['video'] ? ' is-video' : '' ?>" aria-hidden="true">
                                                        <?php if ($call_card['video']): ?>
                                                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="12" height="12" rx="2.5"/><path d="M15 10.5l5.2-3a.6.6 0 0 1 .8.5v8a.6.6 0 0 1-.8.5l-5.2-3z"/></svg>
                                                        <?php else: ?>
                                                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>
                                                        <?php endif; ?>
                                                    </span>
                                                    <span class="call-card-body">
                                                        <span class="call-card-title">
                                                            <span class="call-card-arrow<?= $call_card['bad'] ? ' is-bad' : '' ?>" aria-hidden="true"><?= $call_card['incoming'] ? '↙' : '↗' ?></span>
                                                            <?= htmlspecialchars($call_card['title'], ENT_QUOTES, 'UTF-8') ?>
                                                        </span>
                                                        <span class="call-card-sub<?= $call_card['bad'] ? ' is-bad' : '' ?>"><?= htmlspecialchars($call_card['sub'], ENT_QUOTES, 'UTF-8') ?></span>
                                                        <span class="call-card-route">
                                                            <span class="call-card-who is-caller"><?= htmlspecialchars($call_card['route'][0], ENT_QUOTES, 'UTF-8') ?></span>
                                                            <span class="call-card-route-arrow" aria-hidden="true">→</span>
                                                            <span class="call-card-who"><?= htmlspecialchars($call_card['route'][1], ENT_QUOTES, 'UTF-8') ?></span>
                                                        </span>
                                                    </span>
                                                </div>
                                            <?php else: ?>
                                                <span class="msg-text"><?= $msg_html ?></span>
                                            <?php endif; ?>
                                            <?php if ($is_login_notice): ?>
                                                <div class="login-alert-actions">
                                                    <button type="button" class="btn-end-sessions" data-end-sessions>
                                                        Завершить все сеансы
                                                    </button>
                                                    <span class="end-sessions-status" data-end-sessions-status></span>
                                                </div>
                                            <?php endif; ?>
                                            <span class="msg-meta-inline">
                                                <span class="msg-time" data-timestamp="<?= $msg_timestamp !== false ? (int)$msg_timestamp : 0 ?>"><?= $msg_time ?></span>
                                                <?php if (!empty($msg['edited_at'])): ?><span class="msg-edited-label" title="Сообщение изменено">изменено</span><?php endif; ?>
                                                <?php if ($is_mine): ?>
                                                    <span class="msg-status <?= !empty($msg['is_read']) ? 'is-read' : 'is-unread' ?>"
                                                          title="<?= !empty($msg['is_read']) ? 'Прочитано' : 'Не прочитано' ?>">
                                                        <?= readStatusDots(!empty($msg['is_read'])) ?>
                                                    </span>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    <?php else: ?>
                                        <div class="msg-bubble msg-deleted-text">
                                            <span class="msg-text"><?= $message_type === 'text' ? 'Сообщение недоступно' : 'Вложение недоступно' ?></span>
                                            <span class="msg-meta-inline">
                                                <span class="msg-time" data-timestamp="<?= $msg_timestamp !== false ? (int)$msg_timestamp : 0 ?>"><?= $msg_time ?></span>
                                            </span>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if ($blocked_by_peer || $dialog_blocked): ?>
                    <div class="chat-blocked-notice" role="status">
                        <?= $blocked_by_peer
                            ? 'Пользователь заблокировал вас. Вы не можете ему писать.'
                            : 'Вы заблокировали этого пользователя. Разблокируйте его в меню «⋯» в шапке, чтобы снова писать.' ?>
                    </div>
                <?php endif; ?>
                <form method="POST" action="messages.php" enctype="multipart/form-data" class="chat-input-container<?= ($blocked_by_peer || $dialog_blocked) ? ' is-blocked' : '' ?>" id="chatForm"<?= ($blocked_by_peer || $dialog_blocked) ? ' inert' : '' ?>
                      data-captcha="<?= captchaRequired() ? '1' : '0' ?>"
                      data-captcha-error="<?= isset($_GET['error']) && $_GET['error'] === 'captcha_wrong' ? 'wrong' : '' ?>"
                      data-captcha-open="<?= isset($_GET['error']) && strpos((string)$_GET['error'], 'captcha') === 0 ? '1' : '0' ?>">
                    <input type="hidden" name="receiver_id" value="<?= $selected_dialog_id ?>">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="voice_duration" id="voiceDuration" value="0">
                    <input type="hidden" name="waveform" id="voiceWaveform" value="">
                    <input type="hidden" name="reply_to_id" id="replyToId" value="0">
                    <input type="hidden" name="send_message" value="1">

                    <input type="hidden" name="captcha_code" id="captchaCode" value="">

                    <div class="reply-compose" id="replyCompose" hidden>
                        <span>Ответ на сообщение</span>
                        <strong id="replyComposeText"></strong>
                        <button type="button" id="cancelReplyBtn" aria-label="Отменить ответ">×</button>
                    </div>

                    <div class="chat-file-buttons">
                        <label class="chat-file-btn" title="Отправить фото" for="photoInput">
                            <span class="chat-file-icon"><img src="images/nav-photo.svg" alt="" class="ui-svg"></span>
                            <input type="file" name="photo[]" id="photoInput" accept="image/*" multiple hidden>
                        </label>

                        <label class="chat-file-btn" title="Отправить видео" for="videoInput">
                            <span class="chat-file-icon"><img src="images/nav-video.svg" alt="" class="ui-svg"></span>
                            <input type="file" name="video" id="videoInput" accept="video/*" hidden>
                        </label>

                        <input type="file" name="voice" id="voiceFileInput" accept="audio/*" hidden>
                    </div>

                    <div class="message-input-wrap">
                    <div class="voice-recording-indicator" id="voiceIndicator">
                        <span class="rec-dot"></span>
                        <span id="voiceRecordingStatus">Идёт запись...</span>
                        <div class="recording-waveform" id="recordingWaveform" aria-hidden="true">
                            <?php for ($i = 0; $i < 32; $i++): ?>
                                <span class="recording-wave-bar"></span>
                            <?php endfor; ?>
                        </div>
                        <span id="voiceTimer" class="voice-timer">0:00</span>
                        <audio id="voicePreviewAudio" preload="metadata"></audio>
                        <div class="voice-preview-actions" id="voicePreviewActions">
                            <button type="button" id="cancelVoiceBtn">Отмена</button>
                            <button type="button" id="continueVoiceBtn">Продолжить запись</button>
                            <button type="button" id="previewVoiceBtn">Прослушать</button>
                        </div>
                        <button type="button" class="voice-stop-btn" id="voiceStopBtn"
                                onclick="stopRecording()" aria-label="Остановить">⏹</button>
                    </div>
                    <input type="text"
                           name="message"
                           placeholder="Введите сообщение..."
                           autocomplete="off"
                           id="messageInput"
                           maxlength="10000">

                    <button type="button" class="emoji-button" id="emojiBtn" aria-label="Эмодзи">
                        <span class="chat-file-icon">😊</span>
                    </button>
                    </div>

                    <button type="submit" id="sendBtn" class="action-btn send-btn message-send-btn"
                            title="Отправить сообщение" style="display:none;">
                        <svg class="icon-send" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
                            <path d="M3.4 20.4l17.45-7.48a1 1 0 0 0 0-1.84L3.4 3.6a.993.993 0 0 0-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91z"/>
                        </svg>
                    </button>

                    <button type="button"
                            id="voiceBtn"
                            class="action-btn voice-btn"
                            title="Записать голосовое">
                        <svg class="icon-mic" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
                            <path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v5a3 3 0 0 0 3 3z"/>
                            <path d="M19 11a1 1 0 1 0-2 0 5 5 0 0 1-10 0 1 1 0 1 0-2 0 7 7 0 0 0 6 6.92V21a1 1 0 1 0 2 0v-3.08A7 7 0 0 0 19 11z"/>
                        </svg>
                    </button>

                </form>
            <?php else: ?>
                <div class="no-chat-selected">
                    <div class="icon"><img src="images/nav-messages.svg" alt="" class="ui-svg-big"></div>
                    <h3>Выберите диалог</h3>
                    <p>Нажмите на человека слева, чтобы начать диалог</p>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <div class="site-footer">
        <div class="footer-content">
            <div class="footer-socials">
                <a href="https://vk.com" target="_blank" rel="noopener noreferrer" title="ВКонтакте">
                    <img src="images/vk_invite.svg" alt="ВКонтакте">
                </a>
                <a href="https://discord.com" target="_blank" rel="noopener noreferrer" title="Discord">
                    <img src="images/discord_invite.svg" alt="Discord">
                </a>
                <a href="https://telegram.org" target="_blank" rel="noopener noreferrer" title="Telegram">
                    <img src="images/telegram_intivte.svg" alt="Telegram">
                </a>
            </div>
            <span class="footer-copy">
                SPACE &copy; <span class="year">2026</span>
            </span>
        </div>
    </div>
</div>

<div class="search-dialog-modal" id="searchModal">
    <div class="search-dialog-content">
        <input type="text" id="searchInput" placeholder="🔍 Поиск людей..." onkeyup="searchUsers()" autocomplete="off">
        <div class="search-results" id="searchResults">
            <div class="search-placeholder">Введите имя для поиска</div>
        </div>
        <button type="button" class="close-modal" onclick="closeSearchModal()">Закрыть</button>
    </div>
</div>

<div class="message-context-menu" id="messageContextMenu" hidden>
    <button type="button" data-context-action="select"><svg class="context-menu-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="m7.5 12.5 3 3 6-7"/></svg>Выбрать</button>
    <button type="button" data-context-action="reply"><svg class="context-menu-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 14 4 9l5-5"/><path d="M4 9h9a7 7 0 0 1 7 7v3"/></svg>Ответить</button>
    <button type="button" data-context-action="copy"><svg class="context-menu-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>Копировать</button>
    <button type="button" data-context-action="forward"><svg class="context-menu-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 5h5v5"/><path d="m19 5-8 8"/><path d="M18 13v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>Переслать</button>
    <button type="button" data-context-action="delete"><svg class="context-menu-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16"/><path d="M10 11v6m4-6v6"/><path d="m6 7 1 14h10l1-14"/><path d="M9 7V4h6v3"/></svg>Удалить</button>
    <button type="button" data-context-action="restore" hidden><svg class="context-menu-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11a9 9 0 1 1 2.6 6.4"/><path d="M3 4v7h7"/></svg>Восстановить</button>
</div>

<div class="forward-dialog-modal" id="forwardDialogModal" hidden>
    <div class="forward-dialog-content">
        <div class="forward-dialog-header">
            <h3>Переслать сообщение</h3>
            <button type="button" class="forward-dialog-close" id="closeForwardBtn" aria-label="Закрыть">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>
            </button>
        </div>
        <div class="forward-dialog-combo" id="forwardDialogCombo">
            <input type="text" id="forwardDialogSearch" autocomplete="off"
                   placeholder="Введите имя получателя или название чата">
            <svg class="forward-dialog-search-icon" viewBox="0 0 24 24" aria-hidden="true">
                <circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.2 4.2"/>
            </svg>
        </div>
        <div class="forward-dialog-list">
            <?php $forward_service_account_id = ensureVsSpaceServiceAccount($conn); ?>
            <?php foreach ($dialogs as $forward_dialog): ?>
                <?php if (!empty($forward_dialog['is_self'])) continue; ?>
                <?php
                    $forward_preview = formatMessagePreview(
                        (string)($forward_dialog['last_message'] ?? ''),
                        (string)($forward_dialog['last_message_type'] ?? 'text'),
                        (int)($forward_dialog['last_message_sender_id'] ?? 0) === $user_id,
                        (string)($forward_dialog['username'] ?? '')
                    );
                ?>
                <button type="button" class="forward-dialog-item<?= (int)$forward_dialog['id'] === (int)$forward_service_account_id ? ' is-service' : '' ?>"
                        data-forward-user="<?= (int)$forward_dialog['id'] ?>"
                        title="<?= htmlspecialchars($forward_dialog['username'], ENT_QUOTES, 'UTF-8') ?>">
                    <span class="forward-dialog-avatar" aria-hidden="true">
                        <?php if ((int)$forward_dialog['id'] === (int)$forward_service_account_id): ?>
                            <svg viewBox="0 0 24 24">
                                <path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/>
                                <path d="M10 21h4"/>
                                <path d="M12 1v2M3.5 4l1.4 1.4M20.5 4l-1.4 1.4"/>
                            </svg>
                        <?php elseif (safeFileExists($forward_dialog['avatar'] ?? '')): ?>
                            <img src="<?= htmlspecialchars($forward_dialog['avatar'], ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy">
                        <?php else: ?>
                            <?= htmlspecialchars(getAvatarLetter($forward_dialog['username']), ENT_QUOTES, 'UTF-8') ?>
                        <?php endif; ?>
                    </span>
                    <span class="forward-dialog-copy">
                        <span class="forward-dialog-title">
                            <span class="forward-dialog-name"><?= htmlspecialchars($forward_dialog['username'], ENT_QUOTES, 'UTF-8') ?></span>
                            <?php if ((int)$forward_dialog['id'] === (int)$forward_service_account_id): ?>
                                <span class="forward-dialog-service-label">Сервис</span>
                            <?php endif; ?>
                        </span>
                        <span class="forward-dialog-preview"><?= htmlspecialchars($forward_preview, ENT_QUOTES, 'UTF-8') ?></span>
                    </span>
                    <svg class="forward-dialog-chevron" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="m9 5 7 7-7 7"/>
                    </svg>
                </button>
            <?php endforeach; ?>
            <div class="forward-dialog-empty" hidden>Ничего не найдено</div>
        </div>
        <button type="button" class="close-modal" id="cancelForwardBtn">Отмена</button>
    </div>
</div>

<div class="photo-viewer-modal" id="photoViewerModal" hidden>
    <div class="photo-viewer-content">
        <div class="photo-viewer-stage">
            <img src="" alt="Фото" class="photo-viewer-image" id="photoViewerImage">
            <button type="button" class="photo-viewer-nav is-prev" id="photoViewerPrev" aria-label="Предыдущее фото" hidden>
                <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>
            </button>
            <button type="button" class="photo-viewer-nav is-next" id="photoViewerNext" aria-label="Следующее фото" hidden>
                <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>
            </button>
        </div>

        <aside class="photo-viewer-sidebar">
            <div class="photo-viewer-sidebar-header">
                <button type="button" class="photo-viewer-close" id="photoViewerClose" aria-label="Закрыть просмотр">×</button>
            </div>

            <!-- Отправитель фото, время отправки и «Переслать» -->
            <div class="photo-viewer-info" id="photoViewerInfo"
                 data-me-name="<?= htmlspecialchars((string)($current_username ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                 data-me-avatar="<?= htmlspecialchars(safeFileExists($current_avatar ?? '') ? (string)$current_avatar : '', ENT_QUOTES, 'UTF-8') ?>"
                 data-me-letter="<?= htmlspecialchars((string)($current_letter ?? '?'), ENT_QUOTES, 'UTF-8') ?>"
                 data-peer-online="<?= (isset($selected_user) && is_array($selected_user) && isOnline($selected_user['status'] ?? null, $selected_user['last_seen'] ?? null)) ? '1' : '0' ?>"
                 data-peer-status="<?= htmlspecialchars((isset($selected_user) && is_array($selected_user))
                     ? (isOnline($selected_user['status'] ?? null, $selected_user['last_seen'] ?? null)
                         ? 'Онлайн'
                         : 'Был(а) в сети ' . timeAgo($selected_user['last_seen'] ?? ''))
                     : '', ENT_QUOTES, 'UTF-8') ?>">
                <div class="photo-viewer-author-row">
                    <div class="photo-viewer-avatar-wrap">
                        <div class="photo-viewer-avatar" id="photoViewerAvatar"></div>
                        <span class="chat-header-online-dot photo-viewer-online-dot" id="photoViewerOnlineDot" hidden></span>
                    </div>
                    <div class="photo-viewer-meta">
                        <span class="photo-viewer-author" id="photoViewerAuthor"></span>
                        <span class="photo-viewer-time" id="photoViewerTime" hidden></span>
                        <span class="photo-viewer-status" id="photoViewerStatus"></span>
                    </div>
                </div>
                <div class="photo-viewer-actions">
                    <div class="photo-viewer-reactions">
                        <button type="button" class="post-viewer-action is-like" id="photoViewerLike" aria-label="Лайк">
                            <img src="images/heart.svg" alt="">
                            <span class="post-viewer-action-count" id="photoViewerLikeCount">0</span>
                        </button>
                        <button type="button" class="post-viewer-action is-repost" id="photoViewerShare" aria-label="Переслать" title="Переслать">
                            <img src="images/share.svg" alt="">
                            <span class="post-viewer-action-count" id="photoViewerShareCount">0</span>
                        </button>
                    </div>
                    <a href="#" target="_blank" rel="noopener noreferrer"
                       class="photo-viewer-open-original" id="photoViewerOpenOriginal">Открыть оригинал</a>
                </div>
            </div>

            <!-- Комментирование фото в переписке отключено -->
            <div class="photo-viewer-comments-locked" id="photoViewerCommentsLocked">
                <svg viewBox="0 0 24 24" width="64" height="64" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/>
                    <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>
                    <circle cx="12" cy="15" r="1.2" fill="currentColor" stroke="none"/>
                    <path d="M12 15.5v1.8"/>
                </svg>
                <p>Возможность комментирования этой фотографии ограничена.</p>
            </div>
            <div class="photo-viewer-comments" id="photoViewerComments" aria-live="polite" hidden></div>
            <div class="photo-viewer-comment-form" id="photoViewerCommentForm" hidden>
                <input type="text" id="photoViewerCommentInput" maxlength="1000" autocomplete="off"
                       placeholder="Написать комментарий..." disabled>
                <button type="button" class="photo-viewer-comment-send" id="photoViewerCommentSend" aria-label="Отправить" disabled><svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M2.5 20.5l19-8.5-19-8.5v6.6l13.6 1.9-13.6 1.9z"/></svg></button>
            </div>
        </aside>
    </div>
</div>

<script src="assets/js/custom-emoji.js"></script>
<script src="assets/js/emoji.js"></script>
<script src="assets/js/emoji-init.js"></script>
<script src="assets/js/mentions.js"></script>
<script src="assets/js/messages.js?v=forward-chat-list-style1"></script>
<script src="assets/js/calls.js?v=2"></script>
<script>
// «Печатает…» с ракетой в шапке чата
(function () {
    var body = document.body;
    var peerId = parseInt(body.dataset.dialogId || '0', 10);
    var myId = parseInt(body.dataset.userId || '0', 10);
    var input = document.getElementById('messageInput');
    var statusEl = document.querySelector('.chat-header-status:not(.is-admin)');
    if (!peerId || peerId === myId || !input || !statusEl) return;

    function token() {
        var i = document.querySelector('input[name="csrf_token"]');
        return (i && i.value) || body.dataset.csrfToken || '';
    }
    function post(stop) {
        var data = 'peer_id=' + peerId + (stop ? '&stop=1' : '');
        fetch('api/messages.php?api=typing', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': token() },
            body: data
        }).catch(function () {});
    }

    // отправляем «я печатаю» не чаще раза в 2,5 с
    var lastSent = 0;
    input.addEventListener('input', function () {
        if (input.value.trim() === '') { if (lastSent) { lastSent = 0; post(true); } return; }
        var now = Date.now();
        if (now - lastSent > 2500) { lastSent = now; post(false); }
    });
    var form = document.getElementById('chatForm');
    if (form) form.addEventListener('submit', function () { lastSent = 0; post(true); });

    // показываем «печатает…» вместо статуса
    var typingShown = false, saved = null;
    var PENCIL = '<svg class="typing-pencil" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>';
    function setTyping(on) {
        if (on === typingShown) return;
        typingShown = on;
        if (on) {
            saved = { html: statusEl.innerHTML, online: statusEl.classList.contains('online') };
            statusEl.classList.add('is-typing');
            statusEl.innerHTML = PENCIL + '<span class="typing-text">печатает<span class="typing-dots"><i>.</i><i>.</i><i>.</i></span></span>';
        } else {
            statusEl.classList.remove('is-typing');
            if (saved) statusEl.innerHTML = saved.html;
        }
    }
    function poll() {
        if (document.hidden) return;
        fetch('api/messages.php?api=typing_status&peer=' + peerId, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (d) { setTyping(!!(d && d.typing)); })
            .catch(function () {});
    }
    setInterval(poll, 2000);
})();
</script>
<script>
// Просмотр фото: закрытие (крестик, фон, Esc) и листание (стрелки на экране и ← →)
(function () {
    var modal = document.getElementById('photoViewerModal');
    if (!modal) return;
    var viewerImg = document.getElementById('photoViewerImage');
    var prevBtn = document.getElementById('photoViewerPrev');
    var nextBtn = document.getElementById('photoViewerNext');
    var closeBtn = document.getElementById('photoViewerClose');
    var current = null;

    // убираем надпись «Комментарии», если её добавляет другой скрипт
    function stripTitle() {
        var side = modal.querySelector('.photo-viewer-sidebar');
        if (!side) return;
        var nodes = side.querySelectorAll('.photo-viewer-sidebar-header *, h1, h2, h3, h4, span');
        for (var n = 0; n < nodes.length; n++) {
            var el = nodes[n];
            if (el.children.length === 0 && el.textContent.trim() === 'Комментарии' && !el.closest('.photo-viewer-close')) {
                el.remove();
            }
        }
    }
    stripTitle();

    // Статус автора фото как в шапке чата: точка у аватарки и подпись «Онлайн» / «Был(а) в сети …»
    var infoBox = document.getElementById('photoViewerInfo');
    var authorEl = document.getElementById('photoViewerAuthor');
    var statusEl = document.getElementById('photoViewerStatus');
    var dotEl = document.getElementById('photoViewerOnlineDot');
    function updatePresence() {
        if (!infoBox || !statusEl || !dotEl) return;
        var author = authorEl ? authorEl.textContent.trim() : '';
        var isMe = author !== '' && author === (infoBox.getAttribute('data-me-name') || '').trim();
        var online = isMe || infoBox.getAttribute('data-peer-online') === '1';
        var text = isMe ? 'Онлайн' : (infoBox.getAttribute('data-peer-status') || '');
        statusEl.textContent = text;
        statusEl.classList.toggle('online', online);
        dotEl.hidden = !online;
        var wrapEl = dotEl.parentNode;
        if (wrapEl) wrapEl.classList.toggle('is-online', online);
    }
    if (authorEl) new MutationObserver(updatePresence).observe(authorEl, { childList: true, characterData: true, subtree: true });
    new MutationObserver(updatePresence).observe(modal, { attributes: true, attributeFilter: ['hidden'] });
    updatePresence();
    new MutationObserver(stripTitle).observe(modal, { childList: true, subtree: true });

    function closeViewer() {
        if (modal.hidden) return;
        modal.hidden = true;
        document.body.style.overflow = '';
    }
    function photos() {
        return Array.prototype.slice.call(document.querySelectorAll('img.msg-photo-viewable'));
    }
    function currentIndex(list) {
        var idx = current ? list.indexOf(current) : -1;
        if (idx === -1 && viewerImg) {
            for (var k = 0; k < list.length; k++) {
                if (list[k].src === viewerImg.src) { idx = k; break; }
            }
        }
        return idx;
    }
    function updateArrows() {
        if (modal.hidden) return;
        var list = photos();
        var idx = currentIndex(list);
        if (prevBtn) prevBtn.hidden = !(idx > 0);
        if (nextBtn) nextBtn.hidden = !(idx !== -1 && idx < list.length - 1);
    }
    function go(step) {
        if (modal.hidden) return;
        var list = photos();
        var idx = currentIndex(list);
        var target = list[idx + step];
        if (idx === -1 || !target) return;
        target.click(); // открывает соседнее фото штатным обработчиком (автор, время, лайки обновятся)
        setTimeout(updateArrows, 0);
    }

    // запоминаем, по какому именно фото кликнули
    document.addEventListener('click', function (e) {
        var img = e.target && e.target.closest ? e.target.closest('img.msg-photo-viewable') : null;
        if (img) { current = img; setTimeout(updateArrows, 0); }
    }, true);

    if (closeBtn) closeBtn.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); closeViewer(); });
    if (prevBtn) prevBtn.addEventListener('click', function (e) { e.stopPropagation(); go(-1); });
    if (nextBtn) nextBtn.addEventListener('click', function (e) { e.stopPropagation(); go(1); });
    modal.addEventListener('click', function (e) { if (e.target === modal) closeViewer(); });
    var stage = modal.querySelector('.photo-viewer-stage');
    if (stage) stage.addEventListener('click', function (e) { if (e.target === stage) closeViewer(); });

    document.addEventListener('keydown', function (e) {
        if (modal.hidden) return;
        if (e.key === 'Escape') closeViewer();
        else if (e.key === 'ArrowLeft') { e.preventDefault(); go(-1); }
        else if (e.key === 'ArrowRight') { e.preventDefault(); go(1); }
    });

    // обновляем стрелки при открытии окна и смене картинки
    new MutationObserver(updateArrows).observe(modal, { attributes: true, attributeFilter: ['hidden'] });
    if (viewerImg) new MutationObserver(updateArrows).observe(viewerImg, { attributes: true, attributeFilter: ['src'] });
})();
</script>

    <script src="assets/js/error-reporter.js"></script>
</body>
</html>
<?php
if ($conn instanceof mysqli) {
    $conn->close();
}
<?php

require_once dirname(__DIR__) . '/includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();
header('Content-Type: application/json');

if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => false, 'error' => 'Не авторизован']);
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$conn = db_connect();
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Ошибка подключения к БД']);
    exit;
}

$conn->set_charset("utf8mb4");

$stmt = $conn->prepare("
    SELECT n.*, u.username as sender_name, u.avatar as sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC 
    LIMIT 30
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

// Подсчет непрочитанных
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$count_result = $stmt->get_result();
$count = $count_result->fetch_assoc()['count'] ?? 0;
$stmt->close();

$conn->close();

echo json_encode([
    'success' => true,
    'notifications' => $notifications,
    'count' => $count
]);
?>
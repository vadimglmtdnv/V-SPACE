<?php

require_once dirname(__DIR__) . '/includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();
header('Content-Type: application/json');

// Включаем вывод ошибок только для разработки
error_reporting(E_ALL);
ini_set('display_errors', 0);

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

try {
    // Проверяем авторизацию
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Не авторизован');
    }
    
    $user_id = (int)$_SESSION['user_id'];
    
    // Получаем данные из JSON
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    // Проверяем данные
    if (!$data || !isset($data['post_id']) || !isset($data['comment'])) {
        throw new Exception('Неверные данные');
    }
    
    $post_id = (int)$data['post_id'];
    $comment = sanitizeInput($data['comment']);
    
    // Валидация
    if ($post_id <= 0) {
        throw new Exception('Неверный ID поста');
    }
    
    if (empty($comment)) {
        throw new Exception('Комментарий не может быть пустым');
    }
    
    if (strlen($comment) > 10000) {
        throw new Exception('Комментарий слишком длинный (макс. 10000 символов)');
    }
    
    // Подключаемся к БД
    $conn = db_connect();
    if ($conn->connect_error) {
        throw new Exception('Ошибка подключения к БД');
    }
    $conn->set_charset("utf8mb4");
    
    // Проверка на спам
    $check = $conn->prepare("SELECT COUNT(*) FROM post_comments 
                              WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 10 SECOND)");
    $check->bind_param("i", $user_id);
    $check->execute();
    $check->bind_result($spamCount);
    $check->fetch();
    $check->close();
    
    if ($spamCount > 0) {
        throw new Exception('Пожалуйста, подождите 10 секунд перед новым комментарием');
    }
    
    // Вставляем комментарий
    $stmt = $conn->prepare("INSERT INTO post_comments (post_id, user_id, comment, created_at) 
                            VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iis", $post_id, $user_id, $comment);
    
    if (!$stmt->execute()) {
        error_log("Ошибка комментария: " . $stmt->error);
        throw new Exception('Ошибка при добавлении комментария');
    }
    
    $comment_id = $conn->insert_id;
    $stmt->close();
    $conn->close();
    
    // Успешный ответ
    echo json_encode([
        'success' => true,
        'message' => 'Комментарий добавлен',
        'comment_id' => $comment_id
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
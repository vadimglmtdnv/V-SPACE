<?php
/**
 * Общие функции для api/google_login.php и api/google_callback.php.
 * Напрямую не вызывается.
 */

/** Настройки из google_config.php (+ переменные окружения). */
function google_config(): array
{
    $file = __DIR__ . '/google_config.php';
    $cfg  = is_file($file) ? require $file : [];
    if (!is_array($cfg)) {
        $cfg = [];
    }

    $cfg += [
        'client_id'       => '',
        'client_secret'   => '',
        'redirect_uri'    => '',   // пусто = определится автоматически (с учётом папки проекта)
        'allowed_domains' => ['gmail.com', 'googlemail.com'],
    ];

    foreach (['client_id' => 'GOOGLE_CLIENT_ID', 'client_secret' => 'GOOGLE_CLIENT_SECRET'] as $key => $env) {
        $value = getenv($env);
        if ($value !== false && $value !== '') {
            $cfg[$key] = $value;
        }
    }

    $cfg['client_id']     = trim((string)$cfg['client_id']);
    $cfg['client_secret'] = trim((string)$cfg['client_secret']);
    $cfg['redirect_uri']  = trim((string)$cfg['redirect_uri']);

    return $cfg;
}

/** Ключи заполнены (а не оставлены заглушками «ВСТАВЬ_...»)? */
function google_is_configured(array $cfg): bool
{
    foreach (['client_id', 'client_secret'] as $key) {
        if ($cfg[$key] === '' || strpos($cfg[$key], 'ВСТАВЬ') !== false) {
            return false;
        }
    }
    return true;
}

/** URL-путь к корню сайта: '' если сайт в корне домена, '/chat' если в подпапке. */
function google_app_base(): string
{
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    // SCRIPT_NAME = /<корень>/api/google_xxx.php -> поднимаемся на две папки вверх
    return rtrim(dirname(dirname($script)), '/');
}

/** Адрес, на который Google вернёт пользователя. */
function google_redirect_uri(array $cfg): string
{
    if ($cfg['redirect_uri'] !== '') {
        return $cfg['redirect_uri'];
    }

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host  = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');

    return ($https ? 'https://' : 'http://') . $host . google_app_base() . '/api/google_callback.php';
}

/** С какой страницы пришёл пользователь: только login или register. */
function google_from_page($value): string
{
    return $value === 'register' ? 'register' : 'login';
}

/** Возвращает пользователя на страницу входа/регистрации с кодом ошибки. */
function google_fail(string $code, string $from, string $detail = ''): void
{
    $page = $from === 'register' ? 'register.php' : 'login.php';
    $url  = google_app_base() . '/' . $page . '?google_error=' . rawurlencode($code);

    // Подробности причины — только при локальной разработке
    $host = strtolower((string)preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($detail !== '' && in_array($host, ['localhost', '127.0.0.1'], true)) {
        $url .= '&google_detail=' . rawurlencode(substr($detail, 0, 300));
    }

    header('Location: ' . $url);
    exit;
}

/** POST application/x-www-form-urlencoded. Возвращает ['status' => int, 'body' => string]. */
function google_http_post(string $url, array $fields): array
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($fields),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_HTTPHEADER     => ['Accept: application/json'],
        ]);
        $body   = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($body === false) {
            error_log('Google OAuth: cURL — ' . curl_error($ch));
        }
        curl_close($ch);

        return ['status' => $status, 'body' => is_string($body) ? $body : ''];
    }

    // Запасной вариант без cURL
    $context = stream_context_create(['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json\r\n",
        'content'       => http_build_query($fields),
        'timeout'       => 15,
        'ignore_errors' => true,
    ]]);
    $body   = @file_get_contents($url, false, $context);
    $status = 0;
    if (isset($http_response_header[0]) && preg_match('~\s(\d{3})\s~', $http_response_header[0], $m)) {
        $status = (int)$m[1];
    }

    return ['status' => $status, 'body' => is_string($body) ? $body : ''];
}

/**
 * Содержимое (payload) JWT id_token.
 * Подпись не проверяем: токен получен напрямую от Google по HTTPS
 * в ответ на обмен кода (так разрешает документация Google).
 * aud / iss / exp / nonce проверяются в google_callback.php.
 */
function google_jwt_payload(string $jwt): ?array
{
    $parts = explode('.', $jwt);
    if (count($parts) !== 3) {
        return null;
    }

    $b64 = strtr($parts[1], '-_', '+/');
    $b64 .= str_repeat('=', (4 - strlen($b64) % 4) % 4);

    $json = base64_decode($b64, true);
    $data = $json === false ? null : json_decode($json, true);

    return is_array($data) ? $data : null;
}

<?php
/**
 * Возврат из Google: проверяем ответ, находим или создаём пользователя и открываем сессию.
 * Этот адрес нужно добавить в «Authorized redirect URIs» в Google Cloud Console.
 */

require_once __DIR__ . '/google_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();

// ---------------------------------------------------------------------------
// Вспомогательные функции для работы с БД
// ---------------------------------------------------------------------------

/** Добавляет колонку, если её ещё нет (как это делает login.php). */
function google_ensure_column($conn, string $table, string $column, string $definition): void
{
    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    if ($res && $res->num_rows === 0) {
        $conn->query("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    }
}

/** Имя пользователя из локальной части email: john.doe@gmail.com -> johndoe */
function google_username_base(string $email): string
{
    $local = (string)strstr($email, '@', true);
    $name  = substr((string)preg_replace('/[^a-zA-Z0-9_]+/', '', $local), 0, 40);

    return strlen($name) >= 3 ? $name : 'user' . random_int(1000, 99999);
}

/** Создаёт аккаунт для нового пользователя Google. Возвращает строку пользователя. */
function google_create_user($conn, string $email, string $timezone): array
{
    $base = google_username_base($email);
    // Пароль случайный: войти по паролю можно будет после «Забыли пароль?»
    $hash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);

    for ($i = 0; $i < 8; $i++) {
        $username = $i === 0 ? $base : substr($base, 0, 40) . random_int(100, 99999);

        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $taken = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        if ($taken) {
            continue;
        }

        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, status, last_seen, verified, timezone)
            VALUES (?, ?, ?, 'online', NOW(), 1, ?)
        ");
        $stmt->bind_param('ssss', $username, $email, $hash, $timezone);

        try {
            $ok    = $stmt->execute();
            $errno = $ok ? 0 : (int)$stmt->errno;
        } catch (mysqli_sql_exception $e) {
            $ok    = false;
            $errno = (int)$e->getCode();
        }
        $newId = (int)$conn->insert_id;
        $stmt->close();

        if ($ok) {
            return [
                'id'              => $newId,
                'username'        => $username,
                'session_version' => 0,
                'deactivated_at'  => null,
                'deleted_at'      => null,
                'is_blocked'      => 0,
                'verified'        => 1,
            ];
        }
        if ($errno !== 1062) {      // 1062 = имя уже занято (гонка) -> пробуем другое
            throw new RuntimeException('Не удалось создать пользователя: ' . $conn->error);
        }
    }

    throw new RuntimeException('Не удалось подобрать свободное имя пользователя');
}

/** Запись IP в историю входов (как в login.php). Ошибки не должны ломать вход. */
function google_log_ip($conn, int $userId): void
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    if ($ip === '') {
        return;
    }
    $userAgent = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);

    try {
        $stmt = $conn->prepare("
            SELECT id FROM user_ip_history
            WHERE user_id = ? AND ip_address = ? AND action = 'login'
              AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)
            LIMIT 1
        ");
        $stmt->bind_param('is', $userId, $ip);
        $stmt->execute();
        $recent = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if (!$recent) {
            $stmt = $conn->prepare("INSERT INTO user_ip_history (user_id, ip_address, user_agent, action) VALUES (?, ?, ?, 'login')");
            $stmt->bind_param('iss', $userId, $ip, $userAgent);
            $stmt->execute();
            $stmt->close();
        }

        $stmt = $conn->prepare("UPDATE users SET ip_address = ? WHERE id = ?");
        $stmt->bind_param('si', $ip, $userId);
        $stmt->execute();
        $stmt->close();
    } catch (Throwable $e) {
        error_log('Google OAuth: не удалось записать IP — ' . $e->getMessage());
    }
}

/** «Запомнить меня»: токен в БД и долговременная кука (как в login.php). */
function google_remember_me($conn, int $userId): void
{
    try {
        $lifetime = playerchat_session_lifetime();
        $token    = bin2hex(random_bytes(32));
        $expires  = date('Y-m-d H:i:s', time() + $lifetime);

        $stmt = $conn->prepare("UPDATE users SET remember_token = ?, token_expires = ? WHERE id = ?");
        $stmt->bind_param('ssi', $token, $expires, $userId);
        $stmt->execute();
        $stmt->close();

        $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        setcookie('remember_token', $token, [
            'expires'  => time() + $lifetime,
            'path'     => '/',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } catch (Throwable $e) {
        error_log('Google OAuth: не удалось включить «Запомнить меня» — ' . $e->getMessage());
    }
}

// ---------------------------------------------------------------------------
// 1. Проверяем, что это именно наш запрос
// ---------------------------------------------------------------------------

$oauth = $_SESSION['google_oauth'] ?? null;
unset($_SESSION['google_oauth']);                       // одноразовые данные

$from = is_array($oauth) ? google_from_page($oauth['from'] ?? '') : 'login';

if (!is_array($oauth) || (time() - (int)($oauth['time'] ?? 0)) > 600) {
    google_fail('session_expired', $from);
}

if (isset($_GET['error'])) {                            // например, пользователь нажал «Отмена»
    google_fail($_GET['error'] === 'access_denied' ? 'cancelled' : 'google_error', $from);
}

$state = $_GET['state'] ?? '';
$code  = $_GET['code'] ?? '';

if (!is_string($state) || !hash_equals((string)$oauth['state'], $state)) {
    google_fail('state', $from);
}
if (!is_string($code) || $code === '') {
    google_fail('google_error', $from);
}

// ---------------------------------------------------------------------------
// 2. Меняем code на токены (запрос сервер -> Google)
// ---------------------------------------------------------------------------

$cfg = google_config();
if (!google_is_configured($cfg)) {
    google_fail('not_configured', $from);
}

$response = google_http_post('https://oauth2.googleapis.com/token', [
    'code'          => $code,
    'client_id'     => $cfg['client_id'],
    'client_secret' => $cfg['client_secret'],
    'redirect_uri'  => (string)$oauth['redirect_uri'],
    'grant_type'    => 'authorization_code',
]);

$tokens = json_decode($response['body'], true);
if ($response['status'] !== 200 || !is_array($tokens) || empty($tokens['id_token'])) {
    error_log('Google OAuth: обмен кода не удался, HTTP ' . $response['status'] . ' ' . substr($response['body'], 0, 300));
    google_fail('google_error', $from);
}

// ---------------------------------------------------------------------------
// 3. Проверяем id_token
// ---------------------------------------------------------------------------

$claims = google_jwt_payload((string)$tokens['id_token']);

$claimsOk = is_array($claims)
    && in_array($claims['iss'] ?? '', ['accounts.google.com', 'https://accounts.google.com'], true)
    && ($claims['aud'] ?? '') === $cfg['client_id']
    && (int)($claims['exp'] ?? 0) > time()
    && isset($claims['nonce']) && hash_equals((string)$oauth['nonce'], (string)$claims['nonce']);

if (!$claimsOk) {
    error_log('Google OAuth: id_token не прошёл проверку (iss/aud/exp/nonce)');
    google_fail('google_error', $from);
}

$email = strtolower(trim((string)($claims['email'] ?? '')));
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || !filter_var($claims['email_verified'] ?? false, FILTER_VALIDATE_BOOLEAN)) {
    google_fail('email_unverified', $from);
}

$allowedDomains = array_map('strtolower', (array)$cfg['allowed_domains']);
if ($allowedDomains && !in_array(substr(strrchr($email, '@'), 1), $allowedDomains, true)) {
    google_fail('domain', $from);
}

// ---------------------------------------------------------------------------
// 4. Находим или создаём пользователя и открываем сессию
// ---------------------------------------------------------------------------

$base      = google_app_base();
$errorCode = null;
$errorDetail = '';
$redirect  = $base . '/index.php';

try {
    $conn = db_connect();
    if ($conn->connect_error) {
        throw new RuntimeException('Ошибка подключения: ' . $conn->connect_error);
    }
    $conn->set_charset('utf8mb4');

    // Нужные колонки (те же, что создаёт login.php)
    $accountState = __DIR__ . '/../account_state.php';
    if (is_file($accountState)) {
        require_once $accountState;
        if (function_exists('ensureAccountStateColumns')) {
            ensureAccountStateColumns($conn);
        }
    }
    google_ensure_column($conn, 'users', 'session_version', 'INT NOT NULL DEFAULT 0');
    google_ensure_column($conn, 'users', 'deactivated_at', 'DATETIME NULL DEFAULT NULL');

    $stmt = $conn->prepare("
        SELECT id, username, verified, deleted_at, is_blocked, session_version, deactivated_at
        FROM users
        WHERE LOWER(email) = LOWER(?)
        LIMIT 1
    ");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($user && (int)($user['is_blocked'] ?? 0) === 1) {
        $errorCode = 'blocked';
    } else {
        if (!$user) {
            $user = google_create_user($conn, $email, (string)($oauth['timezone'] ?? 'UTC'));
        } elseif (empty($user['verified'])) {
            // Аккаунт с этим email зарегистрирован, но почта не подтверждена. Google только что
            // подтвердил владельца, поэтому подтверждаем аккаунт, а старый пароль сбрасываем:
            // иначе тот, кто зарегистрировал чужой email заранее, сохранил бы доступ.
            $randomHash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
            $stmt = $conn->prepare("
                UPDATE users
                SET verified = 1, password = ?, session_version = session_version + 1
                WHERE id = ?
            ");
            $stmt->bind_param('si', $randomHash, $user['id']);
            $stmt->execute();
            $stmt->close();
            $user['session_version'] = (int)$user['session_version'] + 1;

            // Необязательная очистка токенов: если каких-то колонок нет — вход не ломаем
            $uid = (int)$user['id'];
            foreach ([
                "UPDATE users SET verification_token = NULL, token_expiry = NULL WHERE id = $uid",
                "UPDATE users SET remember_token = NULL, token_expires = NULL WHERE id = $uid",
            ] as $sql) {
                try {
                    $conn->query($sql);
                } catch (Throwable $e) {
                    error_log('Google OAuth: пропущена очистка токенов — ' . $e->getMessage());
                }
            }
        }

        $userId = (int)$user['id'];

        session_regenerate_id(true);
        $_SESSION['user_id']  = $userId;
        $_SESSION['username'] = $user['username'];
        unset($_SESSION['saved_login']);

        if (!empty($user['deleted_at'])) {
            // Удалённый аккаунт: как и при входе по паролю, index.php предложит его восстановить
            $_SESSION['deleted_account_pending'] = true;
        } else {
            $_SESSION['session_version'] = (int)($user['session_version'] ?? 0);
            $_SESSION['fresh_login']     = true;

            google_log_ip($conn, $userId);

            // Временно отключённый аккаунт включается обратно при входе
            $wasDeactivated = !empty($user['deactivated_at']);
            if ($wasDeactivated) {
                $stmt = $conn->prepare("UPDATE users SET deactivated_at = NULL WHERE id = ?");
                $stmt->bind_param('i', $userId);
                $stmt->execute();
                $stmt->close();
                $redirect .= '?reactivated=1';
            }

            if (!empty($oauth['remember'])) {
                google_remember_me($conn, $userId);
            }

            $stmt = $conn->prepare("UPDATE users SET last_seen = NOW(), status = 'online' WHERE id = ?");
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $stmt->close();
        }
    }

    $conn->close();
} catch (Throwable $e) {
    error_log('Google OAuth: ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')');
    $errorCode   = 'server';
    $errorDetail = $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')';
}

if ($errorCode !== null) {
    google_fail($errorCode, $from, $errorDetail);
}

header('Location: ' . $redirect);
exit;

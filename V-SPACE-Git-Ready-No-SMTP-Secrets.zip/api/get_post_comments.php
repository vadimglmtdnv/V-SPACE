<?php

require_once dirname(__DIR__) . '/includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;

if (!$post_id) {
    echo json_encode([]);
    exit;
}

$conn = db_connect();
if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}
$conn->set_charset("utf8mb4");

// «Имя Фамилия», если заполнены, иначе логин
$stmt = $conn->prepare("
    SELECT c.id, c.comment, c.created_at, u.id as user_id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar
    FROM post_comments c
    INNER JOIN users u ON u.id = c.user_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE c.post_id = ?
    ORDER BY c.created_at ASC
    LIMIT 30
");
if (!$stmt) {   // таблицы профилей ещё нет — показываем логины, как раньше
    $stmt = $conn->prepare("
        SELECT c.id, c.comment, c.created_at, u.id as user_id, u.username, u.avatar
        FROM post_comments c
        INNER JOIN users u ON u.id = c.user_id
        WHERE c.post_id = ?
        ORDER BY c.created_at ASC
        LIMIT 30
    ");
}
$stmt->bind_param("i", $post_id);
$stmt->execute();
$result = $stmt->get_result();

$comments = [];
while ($row = $result->fetch_assoc()) {
    $letter = mb_strtoupper(mb_substr($row['username'] ?: "?", 0, 1, 'UTF-8'), 'UTF-8');
    
    $comments[] = [
        'id' => $row['id'],
        'user_id' => $row['user_id'],
        'username' => htmlspecialchars($row['username']),
        'avatar' => getAvatarUrl($row['avatar'] ?? ''),
        'letter' => $letter,
        'comment' => formatCommentText((string)$row['comment']),
        'time' => timeAgo($row['created_at']),
        'can_delete' => ($row['user_id'] == $user_id || $user_id == 1)
    ];
}

$stmt->close();
$conn->close();

echo json_encode([
    'success' => true,
    'comments' => $comments
], JSON_UNESCAPED_UNICODE);

function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . 'м';
    if ($diff < 86400) return floor($diff / 3600) . 'ч';
    if ($diff < 604800) return floor($diff / 86400) . 'д';
    return date('d.m.Y', $timestamp);
}

function formatCommentText($comment) {
    $formatted = htmlspecialchars($comment, ENT_QUOTES, 'UTF-8');
    $formatted = preg_replace_callback(
        '/[\x{1F1E6}-\x{1F1FF}][\x{1F1E6}-\x{1F1FF}]/u',
        function ($matches) {
            $codepoints = [];
            foreach (preg_split('//u', $matches[0], -1, PREG_SPLIT_NO_EMPTY) as $symbol) {
                $codepoints[] = strtolower(dechex(mb_ord($symbol, 'UTF-8')));
            }
            $src = 'https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/svg/'
                . implode('-', $codepoints) . '.svg';
            return '<img class="comment-flag" src="' . $src . '" alt="' . $matches[0] . '">';
        },
        $formatted
    );
    return nl2br($formatted, false);
}

function getAvatarUrl($avatar) {
    $avatar = trim((string)$avatar);
    if ($avatar === '') {
        return '';
    }

    $relativePath = ltrim(str_replace('\\', '/', $avatar), '/');
    $absolutePath = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
    return is_file($absolutePath) ? $relativePath : '';
}
?>
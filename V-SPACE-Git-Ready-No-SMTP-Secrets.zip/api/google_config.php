<?php
/**
 * Настройки входа через Google.
 *
 * Как получить ключи — см. README.md (раздел «Настройка Google»).
 * Вместо этого файла можно задать переменные окружения GOOGLE_CLIENT_ID и GOOGLE_CLIENT_SECRET.
 */
return [
    'client_id'     => '1078879444766-bjgn979ss54pq4499vangfvld16a9kp5.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri' => 'http://localhost/playerchat/api/google_callback.php',

    // Какие домены почты можно использовать для входа.
    // [] (пустой массив) = подойдёт любой аккаунт Google, включая Google Workspace.
    'allowed_domains' => ['gmail.com', 'googlemail.com'],
];

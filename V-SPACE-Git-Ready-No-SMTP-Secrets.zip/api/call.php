<?php
declare(strict_types=1);
/*
 * API звонков и видеозвонков (WebRTC-сигналинг).
 *
 * Сам звук и видео идут напрямую между браузерами (peer-to-peer). Этот файл
 * только передаёт «служебные» сообщения (offer / answer / ice / hangup ...)
 * между двумя собеседниками через таблицу call_signals.
 *
 *   GET  api/call.php?action=config           — ICE-серверы и id текущего пользователя
 *   GET  api/call.php?action=poll&since=<id>[&wait=1] — новые сигналы для меня
 *        (wait=1 — «длинный опрос»: сервер держит запрос до ~20 с и отвечает сразу, как придёт сигнал)
 *   POST api/call.php?action=send             — отправить сигнал (to, call_id, type, media, payload)
 *
 * Все ответы — JSON. POST требует заголовок X-CSRF-Token (тот же токен, что в messages.php).
 */

date_default_timezone_set('UTC');

require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');

function callRespond(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* Авторизация. Сессию сразу закрываем: опрос идёт каждые 1–3 секунды,
   и открытая сессия блокировала бы остальные запросы пользователя. */

$user_id    = (int)($_SESSION['user_id'] ?? 0);
$csrf_token = (string)($_SESSION['csrf_token'] ?? '');
session_write_close();

if ($user_id <= 0) {
    callRespond(['success' => false, 'error' => 'unauthorized'], 401);
}

/* Legacy config.local.php is optional; database credentials are resolved from .env first. */

$configPath = dirname(__DIR__) . '/config.local.php';
if (is_file($configPath)) {
    @require_once $configPath;
}
require_once dirname(__DIR__) . '/includes/db.php';
if (!env_has('DB_USER') && (!defined('DB_USER') || DB_USER === '')) {
    callRespond(['success' => false, 'error' => 'config_invalid'], 500);
}

$conn = @db_connect();
if ($conn->connect_error) {
    callRespond(['success' => false, 'error' => 'db_connection_failed'], 500);
}
$conn->set_charset('utf8mb4');
$conn->query("SET time_zone = '+00:00'");

$conn->query("
    CREATE TABLE IF NOT EXISTS call_signals (
        id INT(11) NOT NULL AUTO_INCREMENT,
        call_id VARCHAR(32) NOT NULL,
        from_user INT(11) NOT NULL,
        to_user INT(11) NOT NULL,
        type VARCHAR(16) NOT NULL,
        media VARCHAR(8) NOT NULL DEFAULT 'audio',
        payload MEDIUMTEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX to_user_id (to_user, id),
        INDEX created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

const CALL_SIGNAL_TTL      = 45;     // сколько секунд сигнал считается «свежим»
const CALL_PAYLOAD_MAX     = 20000;  // максимальный размер payload (символов)
const CALL_RATE_LIMIT      = 150;    // максимум сигналов от одного пользователя за 10 секунд
const CALL_ALLOWED_TYPES   = ['offer', 'answer', 'ice', 'hangup', 'decline', 'busy', 'ringing'];

$action = (string)($_GET['action'] ?? '');

/* ---------- config ---------- */

if ($action === 'config' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    // Свои STUN/TURN-серверы можно задать в config.local.php:
    //   define('CALL_ICE_SERVERS', [
    //       ['urls' => 'stun:stun.l.google.com:19302'],
    //       ['urls' => 'turn:turn.example.com:3478', 'username' => '...', 'credential' => '...'],
    //   ]);
    $ice = (defined('CALL_ICE_SERVERS') && is_array(CALL_ICE_SERVERS))
        ? CALL_ICE_SERVERS
        : [['urls' => 'stun:stun.l.google.com:19302'], ['urls' => 'stun:stun1.l.google.com:19302']];

    callRespond(['success' => true, 'user_id' => $user_id, 'ice_servers' => $ice]);
}

/* ---------- poll ---------- */

if ($action === 'poll' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $since = max(0, (int)($_GET['since'] ?? 0));
    $ttl   = CALL_SIGNAL_TTL;

    // Длинный опрос: звонок доходит мгновенно, а не «до 3 секунд».
    // Отключить или изменить время удержания можно в config.local.php:
    //   define('CALL_LONGPOLL_SECONDS', 0);   // 0 — обычный короткий опрос
    $hold = defined('CALL_LONGPOLL_SECONDS') ? max(0, min(25, (int)CALL_LONGPOLL_SECONDS)) : 20;
    $wait = !empty($_GET['wait']) && $hold > 0;
    if ($wait) {
        @set_time_limit($hold + 15);
    }

    $stmt = $conn->prepare("
        SELECT s.id, s.call_id, s.from_user, s.type, s.media, s.payload,
               TIMESTAMPDIFF(SECOND, s.created_at, NOW()) AS age,
               u.username AS from_name, u.avatar AS from_avatar
        FROM call_signals s
        LEFT JOIN users u ON u.id = s.from_user
        WHERE s.to_user = ? AND s.id > ?
          AND s.created_at >= (NOW() - INTERVAL {$ttl} SECOND)
        ORDER BY s.id ASC
        LIMIT 100
    ");
    if (!$stmt) {
        callRespond(['success' => false, 'error' => 'server'], 500);
    }
    $stmt->bind_param('ii', $user_id, $since);

    $root     = dirname(__DIR__);
    $deadline = microtime(true) + ($wait ? $hold : 0);
    $signals  = [];
    $last_id  = $since;

    do {
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $avatar = (string)($row['from_avatar'] ?? '');
            if ($avatar !== '' && (strpos($avatar, '..') !== false || !is_file($root . '/' . ltrim($avatar, '/')))) {
                $avatar = '';
            }
            $signals[] = [
                'id'          => (int)$row['id'],
                'call_id'     => (string)$row['call_id'],
                'from'        => (int)$row['from_user'],
                'from_name'   => (string)($row['from_name'] ?? 'Пользователь'),
                'from_avatar' => $avatar,
                'type'        => (string)$row['type'],
                'media'       => (string)$row['media'],
                'payload'     => $row['payload'],
                'age'         => (int)$row['age'],
            ];
            $last_id = max($last_id, (int)$row['id']);
        }
        if ($signals || !$wait) {
            break;
        }
        usleep(300000);
    } while (microtime(true) < $deadline);
    $stmt->close();

    callRespond(['success' => true, 'signals' => $signals, 'last_id' => $last_id, 'long_poll' => $wait]);
}

/* ---------- send ---------- */

if ($action === 'send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($token === '' || $csrf_token === '' || !hash_equals($csrf_token, $token)) {
        callRespond(['success' => false, 'error' => 'csrf_failed'], 403);
    }

    $to      = (int)($_POST['to'] ?? 0);
    $call_id = (string)($_POST['call_id'] ?? '');
    $type    = (string)($_POST['type'] ?? '');
    $media   = ((string)($_POST['media'] ?? 'audio') === 'video') ? 'video' : 'audio';
    $payload = (string)($_POST['payload'] ?? '');

    if ($to <= 0 || $to === $user_id) {
        callRespond(['success' => false, 'error' => 'invalid_user'], 400);
    }
    if (!preg_match('/^[a-f0-9]{16,32}$/', $call_id)) {
        callRespond(['success' => false, 'error' => 'invalid_call'], 400);
    }
    if (!in_array($type, CALL_ALLOWED_TYPES, true)) {
        callRespond(['success' => false, 'error' => 'invalid_type'], 400);
    }
    if (strlen($payload) > CALL_PAYLOAD_MAX) {
        callRespond(['success' => false, 'error' => 'payload_too_large'], 413);
    }

    $stmt = $conn->prepare('SELECT id FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $to);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    if (!$exists) {
        callRespond(['success' => false, 'error' => 'user_not_found'], 404);
    }

    // Простейшая защита от флуда
    $stmt = $conn->prepare('SELECT COUNT(*) AS c FROM call_signals WHERE from_user = ? AND created_at >= (NOW() - INTERVAL 10 SECOND)');
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $recent = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();
    if ($recent >= CALL_RATE_LIMIT) {
        callRespond(['success' => false, 'error' => 'rate_limit'], 429);
    }

    $stmt = $conn->prepare('INSERT INTO call_signals (call_id, from_user, to_user, type, media, payload) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('siisss', $call_id, $user_id, $to, $type, $media, $payload);
    $ok = $stmt->execute();
    $new_id = (int)$stmt->insert_id;
    $stmt->close();

    // Время от времени чистим старые сигналы
    if ($ok && random_int(1, 20) === 1) {
        $conn->query('DELETE FROM call_signals WHERE created_at < (NOW() - INTERVAL 10 MINUTE)');
    }

    callRespond(['success' => (bool)$ok, 'id' => $new_id], $ok ? 200 : 500);
}

callRespond(['success' => false, 'error' => 'unknown_action'], 400);

<?php

require_once dirname(__DIR__) . '/includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();
header('Content-Type: application/json');

if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => false, 'error' => 'Не авторизован']);
    exit;
}

$user_id = (int)$_SESSION["user_id"];
$status = isset($_POST['status']) ? $_POST['status'] : 'offline';

// Если пришел JSON
$input = json_decode(file_get_contents('php://input'), true);
if ($input && isset($input['status'])) {
    $status = $input['status'];
}

$conn = db_connect();
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Ошибка подключения к БД']);
    exit;
}

$conn->set_charset("utf8mb4");

$stmt = $conn->prepare("UPDATE users SET status = ?, last_seen = NOW() WHERE id = ?");
$stmt->bind_param("si", $status, $user_id);
$stmt->execute();

$success = $stmt->affected_rows > 0;
$stmt->close();
$conn->close();

echo json_encode(['success' => $success]);
?>
<?php

require_once dirname(__DIR__) . '/includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();
header('Content-Type: application/json');

if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => false, 'error' => 'Не авторизован']);
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$conn = db_connect();
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Ошибка подключения к БД']);
    exit;
}

$conn->set_charset("utf8mb4");

// Проверяем, является ли пользователь админом
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user || !$user['is_admin']) {
    echo json_encode(['success' => false, 'error' => 'Доступ запрещен']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'error' => 'Нет данных']);
    exit;
}

$target_user_id = isset($data['user_id']) ? (int)$data['user_id'] : 0;
$title = isset($data['title']) ? $conn->real_escape_string($data['title']) : '';
$message = isset($data['message']) ? $conn->real_escape_string($data['message']) : '';
$type = isset($data['type']) ? $conn->real_escape_string($data['type']) : 'info';

if ($target_user_id <= 0 || empty($title) || empty($message)) {
    echo json_encode(['success' => false, 'error' => 'Не все поля заполнены']);
    exit;
}

// Проверяем, существует ли пользователь
$stmt = $conn->prepare("SELECT id FROM users WHERE id = ?");
$stmt->bind_param("i", $target_user_id);
$stmt->execute();
$result = $stmt->get_result();
$user_exists = $result->fetch_assoc();
$stmt->close();

if (!$user_exists) {
    echo json_encode(['success' => false, 'error' => 'Пользователь не найден']);
    exit;
}

// Сохраняем уведомление
$stmt = $conn->prepare("INSERT INTO system_notifications (user_id, title, message, type, created_at) VALUES (?, ?, ?, ?, NOW())");
$stmt->bind_param("isss", $target_user_id, $title, $message, $type);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'notification_id' => $conn->insert_id]);
} else {
    echo json_encode(['success' => false, 'error' => 'Ошибка сохранения уведомления: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>
<?php

require_once dirname(__DIR__) . '/includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();
header('Content-Type: application/json');

if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => false, 'error' => 'Не авторизован']);
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$conn = db_connect();
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Ошибка подключения к БД']);
    exit;
}

$conn->set_charset("utf8mb4");

// Проверяем, передан ли конкретный ID или нужно отметить все
$notification_id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

if ($notification_id > 0) {
    // Отметить конкретное уведомление как прочитанное
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $notification_id, $user_id);
    $stmt->execute();
    
    $success = $stmt->affected_rows > 0;
    $stmt->close();
} else {
    // Отметить все уведомления как прочитанные
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    
    $success = $stmt->affected_rows > 0;
    $stmt->close();
}

$conn->close();

echo json_encode(['success' => $success]);
?>
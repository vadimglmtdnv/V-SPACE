<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

start_secure_session();
$userId = (int)($_SESSION['user_id'] ?? 0);
if ($userId <= 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$sessionId = session_id();
$sessionToken = (string)($_SESSION['csrf_token'] ?? '');
$input = null;

if ($method === 'POST') {
    $providedToken = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($sessionToken === '' || !hash_equals($sessionToken, $providedToken)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit;
    }

    $input = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($input) || (isset($input['ids']) && !is_array($input['ids']))) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid request body']);
        exit;
    }
} elseif ($method !== 'GET') {
    http_response_code(405);
    header('Allow: GET, POST');
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

session_write_close();

try {
    $conn = db_connect(true);
    $conn->query(
        "CREATE TABLE IF NOT EXISTS user_device_presence (
            user_id INT NOT NULL,
            session_hash CHAR(64) NOT NULL,
            device VARCHAR(24) NOT NULL,
            last_seen DATETIME NOT NULL,
            PRIMARY KEY (user_id, session_hash),
            KEY idx_user_presence_seen (user_id, last_seen)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    if ($method === 'POST') {
        if ($sessionId === '') {
            throw new RuntimeException('Session identifier is unavailable');
        }

        $agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (preg_match('/iPhone|iPad|iPod/i', $agent) || (stripos($agent, 'Macintosh') !== false && stripos($agent, 'Mobile') !== false)) {
            $device = 'iPhone';
        } elseif (preg_match('/Android|HarmonyOS|MNA-LX9/i', $agent)) {
            $device = 'Android';
        } else {
            $device = 'Компьютер';
        }

        $sessionHash = hash('sha256', $sessionId);
        $stmt = $conn->prepare(
            "INSERT INTO user_device_presence (user_id, session_hash, device, last_seen)
             VALUES (?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE device = VALUES(device), last_seen = NOW()"
        );
        if (!$stmt) {
            throw new RuntimeException('Could not prepare presence update');
        }
        $stmt->bind_param('iss', $userId, $sessionHash, $device);
        if (!$stmt->execute()) {
            throw new RuntimeException('Could not update user presence');
        }
        $stmt->close();

        $update = $conn->prepare("UPDATE users SET status = 'online', last_seen = NOW() WHERE id = ?");
        if (!$update) {
            throw new RuntimeException('Could not prepare user activity update');
        }
        $update->bind_param('i', $userId);
        if (!$update->execute()) {
            throw new RuntimeException('Could not update user activity');
        }
        $update->close();
    } elseif ($method !== 'GET') {
        http_response_code(405);
        header('Allow: GET, POST');
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        exit;
    }

    $ids = [];
    $rawIds = $method === 'POST' ? ($input['ids'] ?? []) : ($_GET['ids'] ?? '');
    if (is_array($rawIds)) {
        $ids = $rawIds;
    } elseif (is_string($rawIds) && $rawIds !== '') {
        $ids = explode(',', $rawIds);
    }
    foreach ($ids as $rawId) {
        if (!is_int($rawId) && !(is_string($rawId) && ctype_digit($rawId))) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid user ID']);
            exit;
        }
    }
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn($id) => $id > 0)));
    $ids = array_slice($ids, 0, 100);

    $presence = [];
    if ($ids) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $conn->prepare(
            "SELECT id, last_seen,
                    CASE
                        WHEN TIMESTAMPDIFF(SECOND, last_seen, NOW()) >= 120
                        THEN TIMESTAMPDIFF(SECOND, last_seen, NOW())
                        ELSE NULL
                    END AS last_seen_age_seconds
             FROM users WHERE id IN ($placeholders)"
        );
        if (!$stmt) {
            throw new RuntimeException('Could not prepare presence lookup');
        }
        $types = str_repeat('i', count($ids));
        $bindValues = $ids;
        $bindArguments = [$types];
        foreach ($bindValues as &$bindValue) {
            $bindArguments[] = &$bindValue;
        }
        if (!call_user_func_array([$stmt, 'bind_param'], $bindArguments)) {
            throw new RuntimeException('Could not bind presence lookup parameters');
        }
        unset($bindValue);
        if (!$stmt->execute()) {
            throw new RuntimeException('Could not load user activity');
        }
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $presence[(int)$row['id']] = [
                'online' => false,
                'last_seen' => $row['last_seen'],
                'last_seen_age_seconds' => $row['last_seen_age_seconds'],
                'devices' => [],
            ];
        }
        $stmt->close();

        if ($presence) {
            $activeIds = array_keys($presence);
            $activePlaceholders = implode(',', array_fill(0, count($activeIds), '?'));
            $active = $conn->prepare(
                "SELECT user_id, device, last_seen,
                        TIMESTAMPDIFF(SECOND, last_seen, NOW()) AS last_seen_age_seconds
                 FROM user_device_presence
                 WHERE user_id IN ($activePlaceholders)
                   AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                 ORDER BY last_seen DESC"
            );
            if (!$active) {
                throw new RuntimeException('Could not prepare active device lookup');
            }
            $activeTypes = str_repeat('i', count($activeIds));
            $bindValues = $activeIds;
            $bindArguments = [$activeTypes];
            foreach ($bindValues as &$bindValue) {
                $bindArguments[] = &$bindValue;
            }
            if (!call_user_func_array([$active, 'bind_param'], $bindArguments)) {
                throw new RuntimeException('Could not bind active device parameters');
            }
            unset($bindValue);
            if (!$active->execute()) {
                throw new RuntimeException('Could not load active devices');
            }
            $activeResult = $active->get_result();
            while ($row = $activeResult->fetch_assoc()) {
                $id = (int)$row['user_id'];
                if (!isset($presence[$id])) {
                    continue;
                }
                $presence[$id]['online'] = true;
                $presence[$id]['last_seen'] = $row['last_seen'];
                $presence[$id]['last_seen_age_seconds'] = (int)$row['last_seen_age_seconds'];
                if (!in_array($row['device'], $presence[$id]['devices'], true)) {
                    $presence[$id]['devices'][] = $row['device'];
                }
            }
            $active->close();

            $offlineIds = array_values(array_filter(
                array_keys($presence),
                static fn($id) => !$presence[$id]['online']
            ));
            if ($offlineIds) {
                $offlinePlaceholders = implode(',', array_fill(0, count($offlineIds), '?'));
                $latest = $conn->prepare(
                    "SELECT p.user_id, p.device, p.last_seen,
                            TIMESTAMPDIFF(SECOND, p.last_seen, NOW()) AS last_seen_age_seconds
                     FROM user_device_presence p
                     INNER JOIN (
                         SELECT user_id, MAX(last_seen) AS latest_seen
                         FROM user_device_presence
                         WHERE user_id IN ($offlinePlaceholders)
                         GROUP BY user_id
                     ) recent ON recent.user_id = p.user_id AND recent.latest_seen = p.last_seen"
                );
                if (!$latest) {
                    throw new RuntimeException('Could not prepare last known device lookup');
                }
                $latestTypes = str_repeat('i', count($offlineIds));
                $bindValues = $offlineIds;
                $bindArguments = [$latestTypes];
                foreach ($bindValues as &$bindValue) {
                    $bindArguments[] = &$bindValue;
                }
                if (!call_user_func_array([$latest, 'bind_param'], $bindArguments)) {
                    throw new RuntimeException('Could not bind last known device parameters');
                }
                unset($bindValue);
                if (!$latest->execute()) {
                    throw new RuntimeException('Could not load last known devices');
                }
                $latestResult = $latest->get_result();
                while ($row = $latestResult->fetch_assoc()) {
                    $id = (int)$row['user_id'];
                    $presence[$id]['last_seen'] = $row['last_seen'];
                    $presence[$id]['last_seen_age_seconds'] = (int)$row['last_seen_age_seconds'];
                    if (!in_array($row['device'], $presence[$id]['devices'], true)) {
                        $presence[$id]['devices'][] = $row['device'];
                    }
                }
                $latest->close();
            }
        }
    }

    echo json_encode([
        'success' => true,
        'presence' => $presence,
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $error) {
    error_log('Presence API error: ' . $error->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Could not load user presence']);
}

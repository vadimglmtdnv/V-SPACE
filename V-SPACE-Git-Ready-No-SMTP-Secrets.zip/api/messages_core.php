<?php
declare(strict_types=1);

// messages_core.php — общий код чата: сессия, конфиг, БД, авторизация, шифрование, загрузка файлов, функции.
// Подключается из messages.php (страница) и api.php (JSON-API). Напрямую не открывается.
if (!defined('PLAYERCHAT_ENTRY')) {
    $error_code = 404;
    require __DIR__ . '/error.php';
    exit;
}

// ============================================================
// 0. БЕЗОПАСНАЯ СЕССИЯ
// ============================================================
// Единый часовой пояс для PHP и MySQL (см. ниже "SET time_zone"): без этого strtotime() по
// умолчанию мог бы толковать одну и ту же строку времени иначе, чем её сохранила база, и тогда
// unix-время, которое мы отдаём в data-timestamp, было бы сдвинуто на разницу поясов сервера.
// Само время на экране при этом всегда локальное — его в браузере считает formatMessageTimes()
// в messages.js через встроенные часы компьютера пользователя.
date_default_timezone_set('UTC');

require_once __DIR__ . '/../includes/helpers.php';
start_secure_session();
if (is_file(__DIR__ . '/includes/error_logger.php')) { require_once __DIR__ . '/includes/error_logger.php'; }
require_once __DIR__ . '/maintenance.php';

// ============================================================
// 1. ЗАГОЛОВКИ БЕЗОПАСНОСТИ
// ============================================================
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' https://cdn.jsdelivr.net data: blob:; media-src 'self' blob:; connect-src 'self'; font-src 'self' data:;");
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');

// ============================================================
// 2. КОНФИГУРАЦИЯ
// ============================================================
$legacy_config_paths = [__DIR__ . '/config.local.php'];
if (basename(__DIR__) === 'api') {
    $legacy_config_paths[] = dirname(__DIR__) . '/config.local.php';
}
$legacy_config_found = false;
foreach ($legacy_config_paths as $legacy_config_path) {
    if (is_file($legacy_config_path)) {
        require_once $legacy_config_path;
        $legacy_config_found = true;
        break;
    }
}

$env_bootstrap = __DIR__ . '/includes/env.php';
if (!is_file($env_bootstrap)) {
    $env_bootstrap = dirname(__DIR__) . '/includes/env.php';
}
require_once $env_bootstrap;

$db_host = (string)env('DB_HOST', DB_HOST);
$db_user = (string)env('DB_USER', DB_USER);
$db_pass = (string)env('DB_PASS', DB_PASS);
$db_name = (string)env('DB_NAME', DB_NAME);

if ((!$legacy_config_found && (!env_has('DB_USER') || !env_has('ENCRYPTION_SALT'))) || $db_user === '' || !defined('ENCRYPTION_SALT') || ENCRYPTION_SALT === '') {
    if (isset($_GET['api'])) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'server_config']);
        exit;
    }
    $error_code = 500;
    $error_title = 'Application configuration is missing';
    $error_text = 'Check .env or the legacy config.local.php settings.';
    $error_detail = 'Set DB_* and ENCRYPTION_SALT in .env or provide config.local.php.';
    require __DIR__ . '/error.php';
    exit;
}

define('DELETED_MESSAGE_TTL', 10);

// Сколько лет хранятся удалённые сообщения (вместе с вложениями). Потом запись и файл удаляются окончательно.
define('DELETED_MESSAGE_RETENTION_YEARS', 3);

// Лимиты вложений: фото — 20 МБ, видео — 100 МБ, голосовые — 50 МБ.
// Реальный потолок задаёт сервер (upload_max_filesize и post_max_size в php.ini или .htaccess):
// ini_set() на лету их не меняет. Поэтому лимиты ниже автоматически урезаются до того,
// что сервер действительно пропустит, — и не обещают больше, чем получится загрузить.
function iniSizeToBytes(string $v): int {
    $v = trim($v);
    if ($v === '') return 0;
    $n = (int)$v;
    switch (strtolower(substr($v, -1))) {
        case 'g': $n *= 1024;
        case 'm': $n *= 1024;
        case 'k': $n *= 1024;
    }
    return $n;
}
function serverUploadCap(): int {
    $caps = [iniSizeToBytes((string)ini_get('upload_max_filesize'))];
    $post = iniSizeToBytes((string)ini_get('post_max_size'));
    if ($post > 0) $caps[] = $post - 512 * 1024;   // запас на текст и служебные поля формы
    $cap = min($caps);
    return $cap > 0 ? $cap : PHP_INT_MAX;
}
define('UPLOAD_MAX_SIZE',       min(100 * 1024 * 1024, serverUploadCap()));   // видео
define('UPLOAD_PHOTO_MAX_SIZE', min( 20 * 1024 * 1024, serverUploadCap()));   // фото
define('UPLOAD_VOICE_MAX_SIZE', min( 50 * 1024 * 1024, serverUploadCap()));   // голосовые

define('ALLOWED_PHOTO_TYPES', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
define('ALLOWED_VIDEO_TYPES', ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime']);
define('ALLOWED_VOICE_TYPES', [
    'audio/webm',
    'video/webm',
    'audio/mpeg',
    'audio/ogg',
    'audio/wav',
    'audio/x-wav',
    'audio/mp4',
    'audio/x-m4a',
]);

// ENCRYPTION_SALT is loaded from .env, with config.local.php retained as a legacy fallback.

// Имя и фамилия лежат в user_profiles; если колонок ещё нет — создаём их (так же, как в edit.php)
if (!function_exists('ensureProfileNameColumns')) {
    function ensureProfileNameColumns(mysqli $conn): void {
        $conn->query("
            CREATE TABLE IF NOT EXISTS user_profiles (
                id INT(11) NOT NULL AUTO_INCREMENT,
                user_id INT(11) NOT NULL,
                first_name VARCHAR(50) DEFAULT NULL,
                last_name VARCHAR(50) DEFAULT NULL,
                birth_date DATE DEFAULT NULL,
                city VARCHAR(255) DEFAULT NULL,
                bio TEXT DEFAULT NULL,
                website_url VARCHAR(2048) DEFAULT NULL,
                updated_at TIMESTAMP NULL DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY user_id (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $chk = $conn->query("SHOW COLUMNS FROM user_profiles LIKE 'first_name'");
        if ($chk && $chk->num_rows === 0) {
            foreach (['first_name' => 'VARCHAR(50)', 'last_name' => 'VARCHAR(50)', 'birth_date' => 'DATE'] as $col => $def) {
                $c2 = $conn->query("SHOW COLUMNS FROM user_profiles LIKE '" . $col . "'");
                if ($c2 && $c2->num_rows === 0) {
                    $conn->query("ALTER TABLE user_profiles ADD COLUMN " . $col . " " . $def . " DEFAULT NULL");
                }
            }
        }
    }
}

// Имя и фамилия пользователя из профиля; если не заполнены — подставляется $fallback (логин)
if (!function_exists('profileDisplayName')) {
    function profileDisplayName(mysqli $conn, int $id, string $fallback = 'Пользователь'): string {
        try {
            $st = $conn->prepare("SELECT TRIM(CONCAT_WS(' ', first_name, last_name)) AS n FROM user_profiles WHERE user_id = ? LIMIT 1");
            $st->bind_param('i', $id);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            $st->close();
            $n = trim((string)($row['n'] ?? ''));
            return $n !== '' ? $n : $fallback;
        } catch (Throwable $e) {
            return $fallback;
        }
    }
}

// ============================================================
// 3. ПОДКЛЮЧЕНИЕ К БД
// ============================================================
$db_error = '';
$conn = null;

try {
    $conn = mysqli_init();
    if ($conn === false) {
        throw new Exception('mysqli_init() failed');
    }
    $conn->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, 1);
    $conn->real_connect($db_host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        throw new Exception('Ошибка подключения: ' . $conn->connect_error);
    }

    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+00:00'");   // NOW()/CURRENT_TIMESTAMP тоже в UTC, независимо от настроек сервера БД
    ensureProfileNameColumns($conn);

    $tables = ['messages', 'users', 'notifications', 'reports'];
    foreach ($tables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");
        if (!$result || $result->num_rows === 0) {
            throw new Exception("Таблица '$table' не существует");
        }
    }

    $columns = [
        'messages' => [
            'message_type'   => "ALTER TABLE messages ADD COLUMN message_type VARCHAR(50) NOT NULL DEFAULT 'text' AFTER message",
            'file_path'      => "ALTER TABLE messages ADD COLUMN file_path VARCHAR(255) NULL DEFAULT NULL AFTER message_type",
            'photo_radius'   => "ALTER TABLE messages ADD COLUMN photo_radius INT(11) NULL DEFAULT NULL AFTER file_path",
            'is_encrypted'   => "ALTER TABLE messages ADD COLUMN is_encrypted TINYINT(1) NOT NULL DEFAULT 0 AFTER file_path",
            'voice_duration' => "ALTER TABLE messages ADD COLUMN voice_duration INT(11) NULL DEFAULT NULL AFTER file_path",
            'waveform'       => "ALTER TABLE messages ADD COLUMN waveform JSON NULL AFTER voice_duration",
            'is_favorite'    => "ALTER TABLE messages ADD COLUMN is_favorite TINYINT(1) NOT NULL DEFAULT 0 AFTER is_read",
            'reply_to_id'    => "ALTER TABLE messages ADD COLUMN reply_to_id INT(11) NULL DEFAULT NULL AFTER is_favorite",
            'edited_at'      => "ALTER TABLE messages ADD COLUMN edited_at DATETIME NULL DEFAULT NULL AFTER reply_to_id",
            'deleted_at'     => "ALTER TABLE messages ADD COLUMN deleted_at DATETIME NULL DEFAULT NULL AFTER edited_at",
            'deleted_message' => "ALTER TABLE messages ADD COLUMN deleted_message TEXT NULL DEFAULT NULL AFTER deleted_at",
            'deleted_by'      => "ALTER TABLE messages ADD COLUMN deleted_by INT(11) NULL DEFAULT NULL AFTER deleted_message",
            'forwarded_from_id' => "ALTER TABLE messages ADD COLUMN forwarded_from_id INT(11) NULL DEFAULT NULL AFTER deleted_at",
        ],
        'voice_messages' => [
            'waveform' => "ALTER TABLE voice_messages ADD COLUMN waveform JSON NULL AFTER duration",
        ],
    ];

    foreach ($columns as $table => $cols) {
        foreach ($cols as $col => $sql) {
            $check = $conn->query("SHOW COLUMNS FROM `$table` LIKE '" . $conn->real_escape_string($col) . "'");
            if ($check && $check->num_rows === 0) {
                if (!$conn->query($sql)) {
                    error_log("ALTER TABLE failed for $table.$col: " . $conn->error);
                }
            }
        }
    }

    // Удалённые сообщения из базы НЕ стираются: они остаются со временем удаления (deleted_at),
    // автором удаления (deleted_by) и прежним текстом (deleted_message) — для возможности восстановить
    // по горячим следам и для истории. Но сервер их больше никогда не отдаёт в выдаче (visibleMessageSql):
    // заглушку «Сообщение удалено» с таймером на отмену показывает только клиент сразу после удаления,
    // это состояние не переживает F5/Ctrl+F5 — после перезагрузки сообщение уже полностью пропадает.

    $conn->query("
        CREATE TABLE IF NOT EXISTS voice_messages (
            id INT(11) NOT NULL AUTO_INCREMENT,
            user_id INT(11) NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            duration INT(11) NOT NULL DEFAULT 0,
            waveform JSON NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $conn->query("
        CREATE TABLE IF NOT EXISTS muted_dialogs (
            user_id INT(11) NOT NULL,
            dialog_user_id INT(11) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, dialog_user_id),
            INDEX dialog_user_id (dialog_user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Чёрный список: blocker_id заблокировал blocked_id (написать ему больше нельзя)
    $conn->query("
        CREATE TABLE IF NOT EXISTS dialog_blocks (
            blocker_id INT(11) NOT NULL,
            blocked_id INT(11) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (blocker_id, blocked_id),
            INDEX blocked_id (blocked_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // «Удалить у меня»: сообщение остаётся в базе и у собеседника, но скрыто для этого пользователя
    $conn->query("
        CREATE TABLE IF NOT EXISTS message_hidden (
            user_id INT(11) NOT NULL,
            message_id INT(11) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, message_id),
            INDEX message_id (message_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Комментарии к фото в переписке (окно просмотра фото): видят только двое участников диалога
    $conn->query("
        CREATE TABLE IF NOT EXISTS message_photo_comments (
            id INT(11) NOT NULL AUTO_INCREMENT,
            message_id INT(11) NOT NULL,
            user_id INT(11) NOT NULL,
            content TEXT NOT NULL,
            is_encrypted TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX message_id (message_id),
            INDEX user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Лайки фото в переписке: один лайк на пользователя
    $conn->query("
        CREATE TABLE IF NOT EXISTS message_photo_likes (
            id INT(11) NOT NULL AUTO_INCREMENT,
            message_id INT(11) NOT NULL,
            user_id INT(11) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_photo_like (message_id, user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Индикатор «печатает…»: кто (user_id) последний раз печатал кому (peer_id)
    $conn->query("
        CREATE TABLE IF NOT EXISTS chat_typing (
            user_id INT(11) NOT NULL,
            peer_id INT(11) NOT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, peer_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // История входов: используется для уведомлений о входе и обнаружения подозрительных входов
    // (вход с IP-адреса, которого раньше не было у этого пользователя).
    $conn->query("
        CREATE TABLE IF NOT EXISTS login_history (
            id INT(11) NOT NULL AUTO_INCREMENT,
            user_id INT(11) NOT NULL,
            ip_address VARCHAR(45) NULL DEFAULT NULL,
            user_agent VARCHAR(255) NULL DEFAULT NULL,
            is_suspicious TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX user_id (user_id),
            INDEX created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Версия сессии пользователя: увеличивается кнопкой «Завершить все сеансы» в уведомлении
    // о входе. При несовпадении версии в PHP-сессии с версией в БД (см. раздел 7 ниже)
    // сессия на этом устройстве принудительно закрывается — так реализовано реальное
    // завершение сеансов на других устройствах, а не просто текст в интерфейсе.
    $col = $conn->query("SHOW COLUMNS FROM users LIKE 'session_version'");
    if ($col && $col->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN session_version INT NOT NULL DEFAULT 0");
    }

    // Индекс ускоряет выбор удалённых сообщений и суточную чистку по сроку хранения
    $idx = $conn->query("SHOW INDEX FROM messages WHERE Key_name = 'idx_messages_deleted_at'");
    if ($idx && $idx->num_rows === 0) {
        $conn->query("ALTER TABLE messages ADD INDEX idx_messages_deleted_at (deleted_at)");
    }

    // Сбой чистки не должен ломать загрузку страницы
    try {
        purgeExpiredDeletedMessages($conn);
    } catch (Throwable $purge_error) {
        error_log('Purge of expired deleted messages failed: ' . $purge_error->getMessage());
    }
} catch (Throwable $e) {
    $db_error = $e->getMessage();
    error_log('MySQL Error: ' . $db_error);
}

// ============================================================
// 4. ОШИБКА ПОДКЛЮЧЕНИЯ
// ============================================================
if (!$conn || $conn->connect_error) {
    if (isset($_GET['api'])) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'db_connection_failed', 'message' => $db_error]);
        exit;
    }
    // Единая страница ошибок (error.php) вместо отдельной вёрстки
    $error_code   = 503;
    $error_title  = 'Нет связи с базой данных';
    $error_text   = 'Не удалось подключиться к серверу MySQL, чат сейчас недоступен. Попробуйте чуть позже.';
    $error_detail = $db_error;   // показывается только при заходе с localhost
    require __DIR__ . '/error.php';
    exit;
}

// ============================================================
// ХЕЛПЕР: условие «сообщение показывается в переписке».
// Не удалённые видны всегда. Удалённые у всех — сервер их НЕ показывает вообще, сразу же:
// ни в переписке, ни в списке диалогов, ни в превью, ни после F5/Ctrl+F5. Остаются только в базе.
// ============================================================
function visibleMessageSql(string $alias): string {
    // Удалённые сообщения больше никогда не отдаются сервером — ни при первой загрузке страницы,
    // ни при F5/Ctrl+F5, ни при AJAX-переходе между диалогами. Заглушку «Сообщение удалено» и
    // возможность восстановить (DELETED_MESSAGE_TTL секунд) показывает только клиент, который сам
    // только что удалил сообщение — это состояние JS хранит у себя и НЕ переживает перезагрузку страницы.
    return "{$alias}.deleted_at IS NULL";
}

// ============================================================
// ХРАНЕНИЕ УДАЛЁННЫХ СООБЩЕНИЙ: DELETED_MESSAGE_RETENTION_YEARS лет.
// Раз в сутки окончательно стирает сообщения, удалённые у всех больше срока назад,
// и их вложения, если на файл больше никто не ссылается (пересланные копии используют тот же файл).
// ============================================================
function purgeExpiredDeletedMessages(mysqli $conn): void {
    $conn->query("
        CREATE TABLE IF NOT EXISTS app_meta (
            meta_key VARCHAR(64) NOT NULL,
            meta_value VARCHAR(255) NOT NULL,
            PRIMARY KEY (meta_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Не чаще одного раза в сутки
    $res = $conn->query("SELECT meta_value FROM app_meta WHERE meta_key = 'deleted_purge_at'");
    $row = $res ? $res->fetch_assoc() : null;
    if ($row && (time() - (int)$row['meta_value']) < 86400) return;
    $conn->query("INSERT INTO app_meta (meta_key, meta_value) VALUES ('deleted_purge_at', '" . time() . "')
                  ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value)");

    $years = max(1, (int)DELETED_MESSAGE_RETENTION_YEARS);
    $expired = "deleted_at IS NOT NULL AND deleted_at < DATE_SUB(NOW(), INTERVAL {$years} YEAR)";

    // Вложения истёкших сообщений запоминаем до удаления строк
    $files = [];
    $res = $conn->query("SELECT DISTINCT file_path FROM messages WHERE {$expired} AND file_path IS NOT NULL AND file_path <> ''");
    while ($res && ($file_row = $res->fetch_assoc())) {
        $files[] = (string)$file_row['file_path'];
    }

    $conn->query("DELETE FROM messages WHERE {$expired}");
    $conn->query("DELETE mh FROM message_hidden mh LEFT JOIN messages m ON m.id = mh.message_id WHERE m.id IS NULL");

    $uploads = realpath(__DIR__ . '/uploads');
    if ($uploads === false || !$files) return;
    $still_used = $conn->prepare('SELECT 1 FROM messages WHERE file_path = ? LIMIT 1');
    $drop_voice = $conn->prepare('DELETE FROM voice_messages WHERE file_path = ?');
    foreach ($files as $path) {
        // Удаляем только файлы внутри папки uploads
        $full = realpath(__DIR__ . '/' . ltrim($path, '/\\'));
        if ($full === false || strpos($full, $uploads . DIRECTORY_SEPARATOR) !== 0 || !is_file($full)) continue;
        if ($still_used) {
            $still_used->bind_param('s', $path);
            $still_used->execute();
            if ($still_used->get_result()->num_rows > 0) continue;   // файл нужен другому сообщению
        }
        if ($drop_voice) {
            $drop_voice->bind_param('s', $path);
            $drop_voice->execute();
        }
        @unlink($full);
    }
    if ($still_used) $still_used->close();
    if ($drop_voice) $drop_voice->close();
}

// ============================================================
// ХЕЛПЕР: безопасный bind_param
// ============================================================
function safeBind(mysqli_stmt $stmt, string $sql, array $params, string $types): void {
    $placeholders = substr_count($sql, '?');
    if ($placeholders !== count($params)) {
        error_log("Placeholder mismatch: SQL has $placeholders, params has " . count($params));
        throw new RuntimeException("SQL placeholder mismatch: expected $placeholders, got " . count($params));
    }
    if (strlen($types) !== count($params)) {
        throw new RuntimeException("Type string length mismatch");
    }
    $stmt->bind_param($types, ...$params);
}

// ============================================================
// СЕРВИСНЫЙ АККАУНТ V SPACE
// Тот же самый системный аккаунт, что использует консоль администратора
// (reports.php) для отправки сообщений от имени команды V SPACE. Здесь он
// переиспользуется для автоматических уведомлений о входе в аккаунт.
// ============================================================
function ensureVsSpaceServiceAccount(mysqli $conn): ?int {
    $service_username = 'V SPACE';
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param('s', $service_username);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($existing) {
        return (int)$existing['id'];
    }

    $legacy_username = 'VS SPACE';
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param('s', $legacy_username);
    $stmt->execute();
    $legacy = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($legacy) {
        $legacy_id = (int)$legacy['id'];
        $stmt = $conn->prepare("UPDATE users SET username = ? WHERE id = ? AND username = ?");
        $stmt->bind_param('sis', $service_username, $legacy_id, $legacy_username);
        $renamed = $stmt->execute();
        $stmt->close();
        if ($renamed) {
            return $legacy_id;
        }
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param('s', $service_username);
        $stmt->execute();
        $canonical = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $canonical ? (int)$canonical['id'] : $legacy_id;
    }

    // Считываем реальную структуру таблицы users, чтобы создать системный аккаунт,
    // не полагаясь на предположения о её точной схеме.
    $columns = [];
    $colsResult = $conn->query("
        SELECT column_name, is_nullable, column_default, extra
        FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = 'users'
    ");
    if (!$colsResult) {
        return null;
    }
    while ($col = $colsResult->fetch_assoc()) {
        $columns[$col['column_name']] = $col;
    }

    $values = [];
    if (isset($columns['username'])) $values['username'] = $service_username;
    if (isset($columns['email'])) $values['email'] = 'v-space@system.local';
    if (isset($columns['password'])) $values['password'] = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
    if (isset($columns['is_admin'])) $values['is_admin'] = 0;
    if (isset($columns['status'])) $values['status'] = 'offline';
    if (isset($columns['avatar'])) $values['avatar'] = '';

    foreach ($columns as $name => $col) {
        if (array_key_exists($name, $values)) continue;
        if (stripos((string)$col['extra'], 'auto_increment') !== false) continue;
        if ($col['is_nullable'] === 'YES') continue;
        if ($col['column_default'] !== null) continue;
        $values[$name] = '';
    }

    if (empty($values)) {
        return null;
    }

    $columnNames = array_keys($values);
    $columnList = implode(', ', array_map(function ($c) { return "`$c`"; }, $columnNames));
    $placeholders = implode(', ', array_fill(0, count($columnNames), '?'));
    $types = str_repeat('s', count($columnNames));

    $insertStmt = $conn->prepare("INSERT INTO users ($columnList) VALUES ($placeholders)");
    if (!$insertStmt) {
        return null;
    }
    $bindArgs = [$types];
    foreach ($columnNames as $name) {
        $bindArgs[] = &$values[$name];
    }
    call_user_func_array([$insertStmt, 'bind_param'], $bindArgs);
    $ok = $insertStmt->execute();
    $newId = (int)$insertStmt->insert_id;
    $insertStmt->close();

    return $ok ? $newId : null;
}

// ============================================================
// РЕАЛЬНЫЙ IP-АДРЕС КЛИЕНТА
// ::1 и 127.0.0.1 — это "localhost" (сервер видит сам себя). Так бывает, когда
// сайт открыт локально или стоит за прокси (nginx, Cloudflare), который сам
// подключается к PHP с loopback-адреса.
//
// Заголовкам X-Forwarded-For / X-Real-IP доверяем ТОЛЬКО если запрос пришёл с
// локального/приватного адреса или из списка $trusted_proxies — иначе их
// может подделать любой клиент.
// ============================================================
function normalizeIpAddress(?string $ip): string {
    $ip = trim((string)$ip);
    if ($ip === '') {
        return '';
    }
    if (preg_match('/^\[([0-9a-f:.]+)\](?::\d+)?$/i', $ip, $m)) {
        $ip = $m[1];
    } elseif (preg_match('/^(\d{1,3}(?:\.\d{1,3}){3}):\d+$/', $ip, $m)) {
        $ip = $m[1];
    }
    $bin = @inet_pton($ip);
    if ($bin === false) {
        return '';
    }
    if (strlen($bin) === 16 && substr($bin, 0, 12) === "\0\0\0\0\0\0\0\0\0\0\xff\xff") {
        $bin = substr($bin, 12);
    }
    $ip = inet_ntop($bin);
    return $ip === '::1' ? '127.0.0.1' : (string)$ip;
}

function isPublicIpAddress(string $ip): bool {
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}

function getClientIpAddress(): string {
    $trusted_proxies = [
        // '203.0.113.10',
    ];

    $remote = normalizeIpAddress($_SERVER['REMOTE_ADDR'] ?? '');

    if ($remote !== '' && isPublicIpAddress($remote) && !in_array($remote, $trusted_proxies, true)) {
        return $remote;
    }

    // REMOTE_ADDR не публичный (обычно 127.0.0.1 или адрес докер-сети) — значит,
    // запрос пришёл не напрямую от браузера, а через обратный прокси (nginx и т.п.),
    // и настоящий IP посетителя нужно искать в заголовках, которые прокси
    // проставляет сам. Если прокси их не шлёт, взять реальный IP неоткуда —
    // это настраивается на стороне nginx/веб-сервера, а не в этом PHP-файле
    // (см. комментарий ниже про diagnostics-лог).
    $headers = [
        'HTTP_CF_CONNECTING_IP',   // Cloudflare
        'HTTP_TRUE_CLIENT_IP',     // Cloudflare Enterprise / Akamai
        'HTTP_X_REAL_IP',          // nginx: proxy_set_header X-Real-IP $remote_addr;
        'HTTP_X_FORWARDED_FOR',    // nginx: proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',          // RFC 7239: "for=1.2.3.4;proto=https;by=..."
        'HTTP_CLIENT_IP',
    ];
    $fallback = '';
    foreach ($headers as $header) {
        if (empty($_SERVER[$header])) {
            continue;
        }
        $raw = (string)$_SERVER[$header];

        // RFC 7239 "Forwarded" отличается по формату от остальных — вытаскиваем
        // из него значение for=... отдельно, в нём тоже может быть цепочка через запятую.
        if ($header === 'HTTP_FORWARDED') {
            preg_match_all('/for=("?\[?[^;,\s"]+]?"?)/i', $raw, $matches);
            $raw = implode(',', $matches[1] ?? []);
        }

        // X-Forwarded-For может содержать цепочку "клиент, прокси1, прокси2" — берём первый валидный адрес.
        foreach (explode(',', $raw) as $candidate) {
            $candidate = trim($candidate, " \t\"[]");
            $candidate = normalizeIpAddress($candidate);
            if ($candidate === '') {
                continue;
            }
            if (isPublicIpAddress($candidate)) {
                return $candidate;
            }
            if ($fallback === '') {
                $fallback = $candidate;
            }
        }
    }

    if ($fallback !== '') {
        return $fallback;
    }

    // Ни REMOTE_ADDR, ни один из известных заголовков не дали публичный IP —
    // почти всегда это значит, что обратный прокси перед PHP не настроен
    // передавать реальный адрес клиента (нет X-Real-IP / X-Forwarded-For).
    // Логируем сырые заголовки один раз за вход, чтобы можно было посмотреть
    // в error_log веб-сервера, что реально приходит, и понять, какой
    // заголовок настроить на прокси (или добавить его имя в список выше).
    $seen_headers = [];
    foreach ($_SERVER as $key => $value) {
        if (strpos($key, 'HTTP_') === 0 || $key === 'REMOTE_ADDR') {
            $seen_headers[$key] = $value;
        }
    }
    error_log('[getClientIpAddress] Не удалось определить публичный IP, REMOTE_ADDR=' . $remote
        . '. Проверьте, что обратный прокси передаёт X-Real-IP / X-Forwarded-For. '
        . 'Полученные заголовки: ' . json_encode($seen_headers, JSON_UNESCAPED_UNICODE));

    return $remote;
}

// ============================================================
// УВЕДОМЛЕНИЕ О ВХОДЕ / ПОДОЗРИТЕЛЬНОМ ВХОДЕ
// Срабатывает один раз за сессию (при первой загрузке messages.php после входа).
// Считает вход подозрительным, если у пользователя уже ЕСТЬ история входов,
// но текущий IP-адрес среди неё за последние 180 дней не встречался.
// Самый первый вход в истории пользователя подозрительным не считается —
// на нём база данных о его обычных IP только начинает накапливаться.
// ============================================================
// ============================================================
// ГОРОД ПО IP-АДРЕСУ
// Публичный IP — спрашиваем город прямо по нему. Локальный/приватный
// (127.0.0.1 и т.п., типично при локальной разработке) — реальный IP
// посетителя серверу не виден, поэтому спрашиваем город у "себя" (по IP,
// с которого сервер сам выходит в интернет) — на локальной машине это
// обычно и есть реальный внешний адрес того, кто её открыл.
// Запрос делаем один раз за вход (recordLoginAndNotify срабатывает раз за
// сессию), поэтому лимиты бесплатного API (ip-api.com, 45 запросов/мин) не
// проблема. Если сервис недоступен — просто не показываем город.
// ============================================================
function getCityFromIp(string $ip): ?string {
    // Публичный IP — узнаём город прямо по нему.
    // Локальный/приватный (127.0.0.1, 192.168.x.x — типично для локальной
    // разработки) — реальный IP посетителя серверу не виден, поэтому вместо
    // этого спрашиваем город у "себя": ip-api.com/json/ без адреса вернёт
    // геолокацию по IP, с которого сервер сам выходит в интернет.
    if ($ip !== '' && isPublicIpAddress($ip)) {
        $url = 'http://ip-api.com/json/' . rawurlencode($ip) . '?fields=status,city,regionName,country&lang=ru';
    } else {
        $url = 'http://ip-api.com/json/?fields=status,city,regionName,country&lang=ru';
    }

    $response = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 3,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
    }
    if ($response === false && ini_get('allow_url_fopen')) {
        $context = stream_context_create(['http' => ['timeout' => 3, 'ignore_errors' => true]]);
        $response = @file_get_contents($url, false, $context);
    }
    if ($response === false || $response === '') {
        return null;
    }

    $data = json_decode($response, true);
    if (!is_array($data) || ($data['status'] ?? '') !== 'success') {
        return null;
    }

    $parts = array_filter([$data['city'] ?? '', $data['country'] ?? '']);
    return $parts ? implode(', ', $parts) : null;
}

function recordLoginAndNotify(mysqli $conn, int $user_id): void {
    if (!empty($_SESSION['login_event_handled'])) {
        return;
    }
    $_SESSION['login_event_handled'] = true;

    // Сообщение "Выполнен вход в аккаунт" должно приходить только после
    // настоящего входа по логину/паролю (флаг ставит login.php). Тихий
    // автовход по токену «Запомнить меня» этот флаг не ставит. При этом
    // запись в login_history ниже выполняется в любом случае — это история
    // IP-адресов для определения подозрительного входа, она нужна независимо
    // от того, шлём мы сообщение в чат или нет.
    $is_fresh_login = !empty($_SESSION['fresh_login']);
    unset($_SESSION['fresh_login']);

    $ip = getClientIpAddress();
    $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);

    $countStmt = $conn->prepare("SELECT COUNT(*) AS c FROM login_history WHERE user_id = ?");
    $countStmt->bind_param('i', $user_id);
    $countStmt->execute();
    $has_history = (int)($countStmt->get_result()->fetch_assoc()['c'] ?? 0) > 0;
    $countStmt->close();

    $is_suspicious = false;
    if ($has_history && $ip !== '') {
        $knownStmt = $conn->prepare("
            SELECT COUNT(*) AS c FROM login_history
            WHERE user_id = ? AND ip_address = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 180 DAY)
        ");
        $knownStmt->bind_param('is', $user_id, $ip);
        $knownStmt->execute();
        $known = (int)($knownStmt->get_result()->fetch_assoc()['c'] ?? 0) > 0;
        $knownStmt->close();
        $is_suspicious = !$known;
    }

    $insertStmt = $conn->prepare("
        INSERT INTO login_history (user_id, ip_address, user_agent, is_suspicious, created_at)
        VALUES (?, ?, ?, ?, NOW())
    ");
    $suspiciousFlag = $is_suspicious ? 1 : 0;
    $insertStmt->bind_param('issi', $user_id, $ip, $ua, $suspiciousFlag);
    $insertStmt->execute();
    $insertStmt->close();

    // Дальше — только отправка самого сообщения в чат. Если это не настоящий
    // вход по паролю (а тихий автовход по токену), на этом останавливаемся:
    // IP уже записан в историю выше, а лишнее сообщение в чат слать не нужно.
    if (!$is_fresh_login) {
        return;
    }

    $vs_space_id = ensureVsSpaceServiceAccount($conn);
    if (!$vs_space_id || $vs_space_id === $user_id) {
        return;
    }

    $when = date('d.m.Y H:i');
    $ip_display = $ip !== '' ? $ip : 'неизвестен';
    $city = getCityFromIp($ip);
    $city_line = $city !== null ? "Город: {$city}\n" : '';
    if ($is_suspicious) {
        $text = "⚠️ Подозрительный вход в аккаунт с нового устройства или IP-адреса.\n"
              . "Время: {$when}\nIP-адрес: {$ip_display}\n{$city_line}\n"
              . "Если это были не вы — срочно смените пароль и завершите все активные сеансы.";
    } else {
        $text = "Выполнен вход в аккаунт.\nВремя: {$when}\nIP-адрес: {$ip_display}\n{$city_line}\n"
              . "Если это были не вы — смените пароль.";
    }

    $msgStmt = $conn->prepare("
        INSERT INTO messages (sender_id, receiver_id, message, message_type, is_encrypted, is_read, created_at)
        VALUES (?, ?, ?, 'text', 0, 0, NOW())
    ");
    if ($msgStmt) {
        $msgStmt->bind_param('iis', $vs_space_id, $user_id, $text);
        $msgStmt->execute();
        $msgStmt->close();
    }

    $notif_text = $is_suspicious
        ? 'V SPACE: подозрительный вход в аккаунт'
        : 'V SPACE: выполнен вход в аккаунт';
    $notif_link = 'messages.php?dialog=' . $vs_space_id;
    $notifStmt = $conn->prepare("
        INSERT INTO notifications (user_id, sender_id, type, message, link, is_read, created_at)
        VALUES (?, ?, 'message', ?, ?, 0, NOW())
    ");
    if ($notifStmt) {
        $notifStmt->bind_param('iiss', $user_id, $vs_space_id, $notif_text, $notif_link);
        $notifStmt->execute();
        $notifStmt->close();
    }
}

// ============================================================
// 5. CSRF-ТОКЕН
// ============================================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================================
// 6. ТЕМА
// ============================================================
$theme = $_COOKIE['theme'] ?? 'dark';
if (!in_array($theme, ['dark', 'light', 'system'], true)) {
    $theme = 'dark';
}

if (isset($_GET['theme'])) {
    $allowed = ['dark', 'light', 'system'];
    $theme = in_array($_GET['theme'], $allowed, true) ? $_GET['theme'] : 'dark';
    setcookie('theme', $theme, [
        'expires'  => time() + 365 * 24 * 60 * 60,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    $dialog_param = isset($_GET['dialog']) ? (int)$_GET['dialog'] : 0;
    header('Location: messages.php' . ($dialog_param > 0 ? '?dialog=' . $dialog_param : ''));
    exit;
}

// ============================================================
// 7. АВТОРИЗАЦИЯ
// ============================================================
if (!isset($_SESSION['user_id'])) {
    if (isset($_GET['api'])) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'unauthorized']);
        exit;
    }
    header('Location: login.php');
    exit;
}
$user_id = (int)$_SESSION['user_id'];

// ============================================================
// 7.1. ПРОВЕРКА «ЗАВЕРШЕНИЯ ВСЕХ СЕАНСОВ»
// ============================================================
// Кнопка «Завершить все сеансы» в уведомлении о входе увеличивает users.session_version
// и обновляет версию только в сессии того устройства, с которого её нажали. Все остальные
// открытые сессии этого пользователя хранят старую версию — при следующей же их загрузке
// страницы это несовпадение обнаруживается здесь, и сессия принудительно закрывается.
$stmt_sv = $conn->prepare('SELECT session_version FROM users WHERE id = ?');
$stmt_sv->bind_param('i', $user_id);
$stmt_sv->execute();
$db_session_version = $stmt_sv->get_result()->fetch_assoc();
$stmt_sv->close();

if ($db_session_version === null) {
    // Пользователь удалён из БД, но сессия ещё жива — закрываем её.
    $_SESSION = [];
    session_destroy();
    header('Location: login.php?account_missing=1');
    exit;
}

if ((int)($_SESSION['session_version'] ?? 0) !== (int)$db_session_version['session_version']) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    setcookie('user_id', '', time() - 3600, '/');

    if (isset($_GET['api'])) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'session_ended']);
        exit;
    }
    header('Location: login.php?session_ended=1');
    exit;
}

// Уведомление о входе / подозрительном входе — срабатывает один раз за сессию.
recordLoginAndNotify($conn, $user_id);

// ============================================================
// 8. НАСТРОЙКИ ЗАГРУЗКИ
// ============================================================
// upload_max_filesize и post_max_size через ini_set() не меняются (только php.ini / .htaccess) —
// см. лимиты вложений в начале файла. Время выполнения для долгой загрузки видео поднять можно:
ini_set('max_execution_time', '300');

// ============================================================
// 9. ФУНКЦИИ ШИФРОВАНИЯ
// ============================================================
function encryptMessage(string $text, string $key): string {
    if ($text === '') return '';
    $iv_len = openssl_cipher_iv_length('aes-256-cbc');
    $iv = openssl_random_pseudo_bytes($iv_len);
    $encrypted = openssl_encrypt($text, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    if ($encrypted === false) return '';
    return base64_encode($iv . $encrypted);
}

function decryptMessage(string $encrypted, string $key): string {
    if ($encrypted === '') return '';
    $data = base64_decode($encrypted, true);
    if ($data === false) return '';
    $iv_len = openssl_cipher_iv_length('aes-256-cbc');
    if (strlen($data) < $iv_len) return '';
    $iv = substr($data, 0, $iv_len);
    $cipher = substr($data, $iv_len);
    $decrypted = openssl_decrypt($cipher, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted === false ? '' : $decrypted;
}

function generateEncryptionKey(int $user_id, int $receiver_id): string {
    $min = min($user_id, $receiver_id);
    $max = max($user_id, $receiver_id);
    $seed = $min . ':' . $max . ':' . ENCRYPTION_SALT;
    return hash('sha256', $seed, true);
}

// ============================================================
// Комментарии к фото в переписке
// ============================================================

// Фото-сообщение, к которому у пользователя есть доступ (он отправитель или получатель)
function getPhotoCommentMessage(mysqli $conn, int $msg_id, int $user_id): ?array {
    if ($msg_id <= 0) return null;
    $stmt = $conn->prepare('SELECT id, sender_id, receiver_id, message_type, deleted_at FROM messages WHERE id = ? AND (sender_id = ? OR receiver_id = ?)');
    if (!$stmt) return null;
    $stmt->bind_param('iii', $msg_id, $user_id, $user_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row || !empty($row['deleted_at']) || ($row['message_type'] ?? '') !== 'photo') return null;
    return $row;
}

// Лайки и пересылки фото из переписки: сколько лайков, лайкнул ли я, сколько раз фото пересылали
function chatPhotoStats(mysqli $conn, int $msg_id, int $user_id): array {
    $likes = 0; $liked = false; $forwards = 0;
    $stmt = $conn->prepare('SELECT COUNT(*) AS c, SUM(user_id = ?) AS mine FROM message_photo_likes WHERE message_id = ?');
    if ($stmt) {
        $stmt->bind_param('ii', $user_id, $msg_id);
        $stmt->execute();
        $r = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $likes = (int)($r['c'] ?? 0);
        $liked = (int)($r['mine'] ?? 0) > 0;
    }
    $stmt = $conn->prepare('SELECT COUNT(*) AS c FROM messages WHERE forwarded_from_id = ? AND deleted_at IS NULL');
    if ($stmt) {
        $stmt->bind_param('i', $msg_id);
        $stmt->execute();
        $forwards = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
    }
    return ['likes' => $likes, 'liked' => $liked, 'forwards' => $forwards];
}

function formatPhotoComment(array $row, array $msg, int $viewer_id): array {
    $text = (string)$row['content'];
    if (!empty($row['is_encrypted'])) {
        $text = decryptMessage($text, generateEncryptionKey((int)$msg['sender_id'], (int)$msg['receiver_id']));
    }
    $avatar = (string)($row['avatar'] ?? '');
    $author_id = (int)$row['user_id'];
    return [
        'id'         => (int)$row['id'],
        'user_id'    => $author_id,
        'username'   => (string)($row['username'] ?? 'Пользователь'),
        'avatar'     => safeFileExists($avatar) ? $avatar : '',
        'content'    => $text,
        'ts'         => (int)$row['ts'],
        'is_mine'    => $author_id === $viewer_id,
        // удалить комментарий может его автор и автор самого фото
        'can_delete' => $author_id === $viewer_id || (int)$msg['sender_id'] === $viewer_id,
    ];
}

// ============================================================
// 10. ЗАГРУЗКА ФАЙЛА
// ============================================================
// Сколько фото можно отправить за один раз (каждое уходит отдельным сообщением)
const MAX_PHOTOS_PER_MESSAGE = 10;

// Список загруженных фото: понимает и одиночное поле photo, и множественное photo[]
function collectPhotoFiles(): array {
    if (!isset($_FILES['photo']) || !is_array($_FILES['photo'])) return [];
    $f = $_FILES['photo'];
    $files = [];
    if (is_array($f['name'])) {
        foreach (array_keys($f['name']) as $i) {
            $files[] = [
                'name'     => $f['name'][$i],
                'type'     => $f['type'][$i],
                'tmp_name' => $f['tmp_name'][$i],
                'error'    => $f['error'][$i],
                'size'     => $f['size'][$i],
            ];
        }
    } else {
        $files[] = $f;
    }
    $files = array_values(array_filter($files, function ($x) {
        return ($x['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    }));
    return array_slice($files, 0, MAX_PHOTOS_PER_MESSAGE);
}

// Остальные фото из пачки (первое уходит основным сообщением): по одному сообщению на каждое.
function insertExtraPhotoMessages(mysqli $conn, int $sender_id, int $receiver_id, array $paths): array {
    $out = [];
    if (!$paths) return $out;
    $stmt = $conn->prepare("INSERT INTO messages
        (sender_id, receiver_id, message, message_type, file_path, voice_duration, waveform, is_encrypted, is_read, is_favorite, reply_to_id, created_at)
        VALUES (?, ?, '', 'photo', ?, NULL, NULL, 0, 0, 0, 0, NOW())");
    if (!$stmt) throw new RuntimeException('Prepare failed: ' . $conn->error);
    foreach ($paths as $path) {
        $stmt->bind_param('iis', $sender_id, $receiver_id, $path);
        if (!$stmt->execute()) throw new RuntimeException('Photo insert failed: ' . $stmt->error);
        $out[] = [
            'id'           => (int)$stmt->insert_id,
            'sender_id'    => $sender_id,
            'receiver_id'  => $receiver_id,
            'message'      => '',
            'message_type' => 'photo',
            'file_path'    => $path,
            'created_at'   => date('Y-m-d H:i:s'),
        ];
    }
    $stmt->close();
    return $out;
}

function uploadFile(array $file, string $type, int $maxSize, string $uploadDir, array $allowedTypes): ?string {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        error_log('Upload failed: ' . (string)($file['error'] ?? 'missing error'));
        return null;
    }
    if ($file['size'] > $maxSize) {
        error_log("File too large: {$file['size']} bytes, max: $maxSize");
        return null;
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo === false) {
        error_log('Failed to open finfo');
        return null;
    }
    $mimeType = finfo_file($finfo, $file['tmp_name']);

    $mimeBase = strtok($mimeType, ';');

    if (!in_array($mimeBase, $allowedTypes, true) && !in_array($mimeType, $allowedTypes, true)) {
        error_log("Invalid file type: $mimeType");
        return null;
    }

    if (str_starts_with($mimeBase, 'image/')) {
        $img_info = getimagesize($file['tmp_name']);
        if ($img_info === false || $img_info[0] > 8000 || $img_info[1] > 8000) {
            error_log('Invalid or too large image');
            return null;
        }
    }

    $extensionByMime = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'audio/mpeg' => 'mp3',
        'audio/ogg' => 'ogg',
        'video/mp4' => 'mp4',
        'video/webm' => 'webm',
        'video/ogg' => 'ogv',
        'video/quicktime' => 'mov',
        'audio/webm' => 'webm',
        'audio/wav' => 'wav',
        'audio/x-wav' => 'wav',
        'audio/mp4' => 'm4a',
        'audio/x-m4a' => 'm4a',
    ];
    $safe_ext = $extensionByMime[$mimeBase] ?? null;
    if ($safe_ext === null) {
        error_log("Unsupported upload MIME type: $mimeBase");
        return null;
    }

    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
        error_log("Failed to create directory: $uploadDir");
        return null;
    }

    $new_name = $type . '_' . time() . '_' . bin2hex(random_bytes(8)) . '.' . $safe_ext;
    $target = $uploadDir . $new_name;

    $counter = 1;
    while (file_exists($target)) {
        $new_name = $type . '_' . time() . '_' . bin2hex(random_bytes(16)) . '_' . $counter . '.' . $safe_ext;
        $target = $uploadDir . $new_name;
        $counter++;
    }

    if (move_uploaded_file($file['tmp_name'], $target)) {
        chmod($target, 0644);
        return $target;
    }

    error_log('Failed to move uploaded file');
    return null;
}

// ============================================================
// КАПЧА ОТ ФЛУДА (текст из английских букв и цифр, рисуется как SVG)
// Включается только когда пользователь шлёт сообщения слишком часто:
// больше CAPTCHA_MAX_MESSAGES за CAPTCHA_WINDOW секунд. Пока флаг
// captcha_required стоит в сессии, сообщение без верного кода не уходит.
// ============================================================
const CAPTCHA_LENGTH       = 5;     // длина кода
const CAPTCHA_TTL          = 600;   // сколько секунд код действителен
const CAPTCHA_WINDOW       = 60;    // окно подсчёта сообщений, сек
const CAPTCHA_MAX_MESSAGES = 8;     // сколько сообщений можно за окно без капчи
const CAPTCHA_ALPHABET     = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // без I и O, чтобы не путать с 1 и 0

function captchaRequired(): bool {
    return !empty($_SESSION['captcha_required']);
}

function captchaGenerateCode(): string {
    $len = strlen(CAPTCHA_ALPHABET);
    do {
        $code = '';
        for ($i = 0; $i < CAPTCHA_LENGTH; $i++) {
            $code .= CAPTCHA_ALPHABET[random_int(0, $len - 1)];
        }
        // обязательно и буква, и цифра
    } while (!preg_match('/[A-Z]/', $code) || !preg_match('/[2-9]/', $code));
    return $code;
}

// Считает отправку; если за окно набралось больше лимита — включает капчу.
function captchaRegisterSend(): void {
    $now = time();
    $times = array_filter((array)($_SESSION['send_times'] ?? []), function ($t) use ($now) {
        return ($now - (int)$t) < CAPTCHA_WINDOW;
    });
    $times[] = $now;
    $_SESSION['send_times'] = array_values($times);
    if (count($times) > CAPTCHA_MAX_MESSAGES) {
        $_SESSION['captcha_required'] = true;
    }
}

// Код одноразовый: после любой попытки проверки он сбрасывается.
function captchaVerify(string $input): bool {
    $c = $_SESSION['captcha'] ?? null;
    unset($_SESSION['captcha']);
    if (!is_array($c) || (time() - (int)($c['time'] ?? 0)) > CAPTCHA_TTL) {
        return false;
    }
    $input = strtoupper(preg_replace('/\s+/', '', $input));
    if ($input === '' || !hash_equals((string)$c['code'], $input)) {
        return false;
    }
    unset($_SESSION['captcha_required'], $_SESSION['send_times']);
    return true;
}

// Рисует код как SVG из пикселей (текста в SVG нет — боту нужно распознавать картинку)
function captchaRenderSvg(string $code): string {
    static $font = [
        'A' => '.###.|#...#|#...#|#####|#...#|#...#|#...#',
        'B' => '####.|#...#|#...#|####.|#...#|#...#|####.',
        'C' => '.####|#....|#....|#....|#....|#....|.####',
        'D' => '####.|#...#|#...#|#...#|#...#|#...#|####.',
        'E' => '#####|#....|#....|####.|#....|#....|#####',
        'F' => '#####|#....|#....|####.|#....|#....|#....',
        'G' => '.####|#....|#....|#..##|#...#|#...#|.####',
        'H' => '#...#|#...#|#...#|#####|#...#|#...#|#...#',
        'J' => '..###|....#|....#|....#|....#|#...#|.###.',
        'K' => '#...#|#..#.|#.#..|##...|#.#..|#..#.|#...#',
        'L' => '#....|#....|#....|#....|#....|#....|#####',
        'M' => '#...#|##.##|#.#.#|#.#.#|#...#|#...#|#...#',
        'N' => '#...#|##..#|#.#.#|#..##|#...#|#...#|#...#',
        'P' => '####.|#...#|#...#|####.|#....|#....|#....',
        'Q' => '.###.|#...#|#...#|#...#|#.#.#|#..#.|.##.#',
        'R' => '####.|#...#|#...#|####.|#.#..|#..#.|#...#',
        'S' => '.####|#....|#....|.###.|....#|....#|####.',
        'T' => '#####|..#..|..#..|..#..|..#..|..#..|..#..',
        'U' => '#...#|#...#|#...#|#...#|#...#|#...#|.###.',
        'V' => '#...#|#...#|#...#|#...#|#...#|.#.#.|..#..',
        'W' => '#...#|#...#|#...#|#.#.#|#.#.#|##.##|#...#',
        'X' => '#...#|#...#|.#.#.|..#..|.#.#.|#...#|#...#',
        'Y' => '#...#|#...#|.#.#.|..#..|..#..|..#..|..#..',
        'Z' => '#####|....#|...#.|..#..|.#...|#....|#####',
        '2' => '.###.|#...#|....#|...#.|..#..|.#...|#####',
        '3' => '####.|....#|....#|.###.|....#|....#|####.',
        '4' => '...#.|..##.|.#.#.|#..#.|#####|...#.|...#.',
        '5' => '#####|#....|####.|....#|....#|#...#|.###.',
        '6' => '.###.|#....|#....|####.|#...#|#...#|.###.',
        '7' => '#####|....#|...#.|..#..|.#...|.#...|.#...',
        '8' => '.###.|#...#|#...#|.###.|#...#|#...#|.###.',
        '9' => '.###.|#...#|#...#|.####|....#|....#|.###.',
    ];
    $colors = ['#1d2b64', '#5b2a86', '#0b6e4f', '#9c1c3a', '#1f5fbf', '#7a4a00'];
    $w = 230; $h = 76; $px = 5.4;
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $w . '" height="' . $h . '" viewBox="0 0 ' . $w . ' ' . $h . '">';
    $svg .= '<rect width="100%" height="100%" rx="10" fill="#eef0fb"/>';

    // шум под символами
    for ($i = 0; $i < 6; $i++) {
        $svg .= sprintf('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-opacity="0.35" stroke-width="%.1f"/>',
            random_int(0, $w), random_int(0, $h), random_int(0, $w), random_int(0, $h),
            $colors[array_rand($colors)], random_int(10, 25) / 10);
    }

    $n = strlen($code);
    $slot = ($w - 20) / $n;
    for ($i = 0; $i < $n; $i++) {
        $rows = explode('|', $font[$code[$i]]);
        $x = 10 + $i * $slot + random_int(0, 4);
        $y = 14 + random_int(0, 8);
        $rot = random_int(-14, 14);
        $skew = random_int(-10, 10);
        $color = $colors[array_rand($colors)];
        $svg .= sprintf('<g transform="translate(%.1f %.1f) rotate(%d %.1f %.1f) skewX(%d)" fill="%s">',
            $x, $y, $rot, 2.5 * $px, 3.5 * $px, $skew, $color);
        foreach ($rows as $ry => $row) {
            for ($rx = 0; $rx < 5; $rx++) {
                if ($row[$rx] === '#') {
                    $svg .= sprintf('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="1"/>',
                        $rx * $px, $ry * $px, $px + 0.3, $px + 0.3);
                }
            }
        }
        $svg .= '</g>';
    }

    // линии и точки поверх символов
    for ($i = 0; $i < 4; $i++) {
        $svg .= sprintf('<path d="M%d %d Q%d %d %d %d" fill="none" stroke="%s" stroke-opacity="0.55" stroke-width="%.1f"/>',
            random_int(0, 20), random_int(5, $h - 5), random_int(60, 170), random_int(0, $h),
            random_int($w - 20, $w), random_int(5, $h - 5),
            $colors[array_rand($colors)], random_int(10, 20) / 10);
    }
    for ($i = 0; $i < 35; $i++) {
        $svg .= sprintf('<circle cx="%d" cy="%d" r="%.1f" fill="%s" fill-opacity="0.45"/>',
            random_int(0, $w), random_int(0, $h), random_int(5, 14) / 10, $colors[array_rand($colors)]);
    }
    return $svg . '</svg>';
}

// ============================================================
// ХЕЛПЕРЫ ДЛЯ API
// ============================================================
function apiResponse(array $data, int $code = 200): void {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function apiRequireCsrf(): void {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
    if (!is_string($token) || $token === '' || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        apiResponse(['success' => false, 'error' => 'csrf_failed'], 403);
    }
}

// Для старых эндпоинтов на GET-ссылках (?toggle_favorite=1&...), которые меняют данные и раньше
// не проверяли CSRF-токен вообще. Токен передаётся как &csrf=... в самой ссылке. Если он отсутствует
// или не совпадает — просто ничего не меняем и уходим туда же, откуда пришли (без ошибки на весь экран,
// чтобы не пугать пользователя, который просто открыл старую/чужую ссылку).
function legacyCsrfValid(): bool {
    $token = $_GET['csrf'] ?? '';
    return is_string($token) && $token !== '' && hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function apiUserExists(mysqli $conn, int $id): bool {
    $stmt = $conn->prepare('SELECT id FROM users WHERE id = ?');
    if (!$stmt) return false;
    $stmt->bind_param('i', $id);
    if (!$stmt->execute()) {
        $stmt->close();
        return false;
    }
    $ok = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $ok;
}

function isDialogBlocked(mysqli $conn, int $blocker_id, int $blocked_id): bool {
    $stmt = $conn->prepare('SELECT 1 FROM dialog_blocks WHERE blocker_id = ? AND blocked_id = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('ii', $blocker_id, $blocked_id);
    $stmt->execute();
    $blocked = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $blocked;
}

// Для API: если между пользователями есть блокировка (в любую сторону) — отказ 403
function apiRequireNotBlocked(mysqli $conn, int $sender_id, int $receiver_id): void {
    if ($receiver_id === $sender_id) return;
    if (isDialogBlocked($conn, $receiver_id, $sender_id)) {
        apiResponse(['success' => false, 'error' => 'blocked_by_receiver'], 403);
    }
    if (isDialogBlocked($conn, $sender_id, $receiver_id)) {
        apiResponse(['success' => false, 'error' => 'receiver_blocked'], 403);
    }
}

function isDialogMuted(mysqli $conn, int $user_id, int $dialog_id): bool {
    $stmt = $conn->prepare('SELECT 1 FROM muted_dialogs WHERE user_id = ? AND dialog_user_id = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('ii', $user_id, $dialog_id);
    $stmt->execute();
    $muted = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $muted;
}

function apiGetDialogs(mysqli $conn, int $user_id): array {
    $dialogs = [];
    $vis_m2 = visibleMessageSql('m2');
    $vis_mm = visibleMessageSql('mm');
    $sql = "
        SELECT
            u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, u.status, u.last_seen, u.is_admin,
            COALESCE(fd.cnt, 0) AS is_favorite,
            COALESCE(m.message, '')          AS last_message,
            COALESCE(m.message_type, 'text') AS last_message_type,
            COALESCE(m.file_path, '')        AS last_file_path,
            COALESCE(m.created_at, NOW())    AS last_message_time,
            COALESCE(m.is_encrypted, 0)      AS last_is_encrypted,
            COALESCE(m.sender_id, 0)         AS last_message_sender_id,
            COALESCE(m.is_read, 0)           AS last_message_is_read,
            m.deleted_at                     AS last_deleted_at,
            COALESCE((
                SELECT COUNT(*) FROM messages un_read
                WHERE un_read.receiver_id = ?
                  AND un_read.sender_id   = u.id
                  AND un_read.is_read     = 0
                  AND un_read.deleted_at IS NULL
                  AND NOT EXISTS (SELECT 1 FROM message_hidden h0 WHERE h0.message_id = un_read.id AND h0.user_id = ?)
            ), 0) AS unread
        FROM users u
        LEFT JOIN user_profiles up ON up.user_id = u.id
        LEFT JOIN (
            SELECT dialog_user_id, 1 AS cnt FROM favorite_dialogs WHERE user_id = ?
        ) fd ON fd.dialog_user_id = u.id
        LEFT JOIN messages m ON m.id = (
            SELECT m2.id FROM messages m2
            WHERE ((m2.sender_id = ? AND m2.receiver_id = u.id)
               OR (m2.sender_id = u.id AND m2.receiver_id = ?))
              AND NOT EXISTS (SELECT 1 FROM message_hidden h2 WHERE h2.message_id = m2.id AND h2.user_id = ?)
              AND {$vis_m2}
            ORDER BY m2.id DESC
            LIMIT 1
        )
        WHERE u.id != ?
          AND EXISTS (
              SELECT 1 FROM messages mm
              WHERE ((mm.sender_id = ? AND mm.receiver_id = u.id)
                 OR (mm.sender_id = u.id AND mm.receiver_id = ?))
                AND NOT EXISTS (SELECT 1 FROM message_hidden h3 WHERE h3.message_id = mm.id AND h3.user_id = ?)
                AND {$vis_mm}
          )
        ORDER BY last_message_time DESC
    ";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return $dialogs;
    // Все плейсхолдеры в запросе — это id текущего пользователя
    $params = array_fill(0, substr_count($sql, '?'), $user_id);
    safeBind($stmt, $sql, $params, str_repeat('i', count($params)));
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $row['is_favorite'] = (bool)$row['is_favorite'];
        $row['unread']      = (int)$row['unread'];

        if (!empty($row['last_is_encrypted']) && $row['last_message'] !== '') {
            $key = generateEncryptionKey($user_id, (int)$row['id']);
            $dec = decryptMessage($row['last_message'], $key);
            $row['last_message'] = ($dec !== '') ? $dec : '';
        }
        if (!empty($row['last_deleted_at'])) {
            $row['last_message']      = 'Сообщение удалено';
            $row['last_message_type'] = 'text';
        }

        $dialogs[] = $row;
    }
    $stmt->close();
    return $dialogs;
}

function apiGetMessages(mysqli $conn, int $user_id, int $dialog_id, int $limit, int $before): array {
    $limit = max(1, min(200, $limit));
    $messages = [];
    $vis = visibleMessageSql('m');

    if ($before > 0) {
        $sql = "
            SELECT m.*, rm.message AS reply_message, rm.message_type AS reply_message_type,
                   rm.sender_id AS reply_sender_id, rm.is_encrypted AS reply_is_encrypted
            FROM messages m
            LEFT JOIN messages rm ON rm.id = m.reply_to_id
            WHERE ((m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?))
              AND m.id < ?
              AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id = m.id AND h.user_id = ?)
              AND {$vis}
            ORDER BY m.id DESC
            LIMIT ?
        ";
        $stmt = $conn->prepare($sql);
        if (!$stmt) return $messages;
        $stmt->bind_param('iiiiiii', $user_id, $dialog_id, $dialog_id, $user_id, $before, $user_id, $limit);
    } else {
        $sql = "
            SELECT m.*, rm.message AS reply_message, rm.message_type AS reply_message_type,
                   rm.sender_id AS reply_sender_id, rm.is_encrypted AS reply_is_encrypted
            FROM messages m
            LEFT JOIN messages rm ON rm.id = m.reply_to_id
            WHERE ((m.sender_id = ? AND m.receiver_id = ?)
               OR (m.sender_id = ? AND m.receiver_id = ?))
              AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id = m.id AND h.user_id = ?)
              AND {$vis}
            ORDER BY m.id DESC
            LIMIT ?
        ";
        $stmt = $conn->prepare($sql);
        if (!$stmt) return $messages;
        $stmt->bind_param('iiiiii', $user_id, $dialog_id, $dialog_id, $user_id, $user_id, $limit);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $key = generateEncryptionKey($user_id, $dialog_id);

    while ($row = $result->fetch_assoc()) {
        if (!empty($row['is_encrypted']) && $row['message'] !== '') {
            $dec = decryptMessage($row['message'], $key);
            $row['message'] = ($dec !== '') ? $dec : '';
        }
        if (!empty($row['reply_is_encrypted']) && !empty($row['reply_message'])) {
            $reply_dec = decryptMessage((string)$row['reply_message'], $key);
            $row['reply_message'] = ($reply_dec !== '') ? $reply_dec : '';
        }
        $legacy_voice = resolveLegacyVoice($conn, (string)$row['message']);
        if ($legacy_voice) {
            $row['message'] = '';
            $row['message_type'] = 'voice';
            $row['file_path'] = $legacy_voice['file_path'];
            $row['voice_duration'] = $legacy_voice['voice_duration'];
            $row['waveform'] = $legacy_voice['waveform'] ?? generateWaveform((int)$row['id'], 32);
        } else {
            $decoded_waveform = !empty($row['waveform'])
                ? json_decode((string)$row['waveform'], true)
                : null;
            $row['waveform'] = is_array($decoded_waveform) && count($decoded_waveform) >= 8
                ? $decoded_waveform
                : generateWaveform((int)$row['id'], 32);
        }
        $row['is_mine']  = ((int)$row['sender_id'] === $user_id);
        $row['is_encrypted'] = 0;
        $messages[] = $row;
    }
    $stmt->close();

    return array_reverse($messages);
}

// ============================================================
// 14. ФУНКЦИИ
// ============================================================
function timeAgo(?string $datetime): string {
    if (empty($datetime)) return 'неизвестно';
    $ts = strtotime($datetime);
    if ($ts === false) return 'неизвестно';
    $diff = time() - $ts;
    if ($diff < 0) return 'только что';
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . 'м';
    if ($diff < 86400) return floor($diff / 3600) . 'ч';
    if ($diff < 604800) return floor($diff / 86400) . 'д';
    return date('d.m.Y', $ts);
}

function formatMessageTime(?string $datetime): string {
    if (empty($datetime)) return '';
    $ts = strtotime($datetime);
    return $ts === false ? '' : date('H:i', $ts);
}

function formatChatDate(?string $datetime): string {
    if (empty($datetime)) return '';
    $ts = strtotime($datetime);
    if ($ts === false) return '';

    $months = [
        1 => 'январь',
        2 => 'февраль',
        3 => 'март',
        4 => 'апрель',
        5 => 'май',
        6 => 'июнь',
        7 => 'июль',
        8 => 'август',
        9 => 'сентябрь',
        10 => 'октябрь',
        11 => 'ноябрь',
        12 => 'декабрь',
    ];

    return $months[(int)date('n', $ts)] . ' ' . (int)date('j', $ts);
}

function formatNotification(string $type, string $message): array {
    $icons = [
        'message' => '💬', 'news' => '📰', 'friend_request' => '👋',
        'friend_accepted' => '✅', 'friend_removed' => '❌', 'like' => '❤️',
        'comment' => '💭', 'report' => '⚠️', 'warning' => '⚡',
        'system' => '🔔', 'friend' => '👤', 'invite' => '📨',
        'group' => '👥', 'mention' => '@',
    ];
    return ['icon' => $icons[$type] ?? '🔔', 'text' => $message];
}

// Та же шапка уведомлений, что и в index.php / settings.php: иконка и
// человекочитаемое название по типу уведомления.
function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getAvatarLetter(?string $username): string {
    if (empty($username)) return '?';
    return mb_strtoupper(mb_substr($username, 0, 1, 'UTF-8'), 'UTF-8');
}

function isOnline(?string $status, ?string $last_seen = null): bool {
    if ($status !== 'online') {
        return false;
    }
    if ($last_seen === null || $last_seen === '') {
        return false;
    }

    $last_seen_timestamp = strtotime($last_seen);
    return $last_seen_timestamp !== false
        && (time() - $last_seen_timestamp) >= 0
        && (time() - $last_seen_timestamp) <= 120;
}

function ruPlural(int $n, string $one, string $few, string $many): string {
    $n = abs($n) % 100;
    $n1 = $n % 10;
    if ($n > 10 && $n < 20) return $many;
    if ($n1 > 1 && $n1 < 5) return $few;
    if ($n1 === 1) return $one;
    return $many;
}

// «1 минуту», «1 минуту 15 секунд», «2 часа 3 минуты» (винительный падеж: «звонок длился …»)
function callDurationWords(int $sec): string {
    $sec = max(0, $sec);
    $h = intdiv($sec, 3600);
    $m = intdiv($sec % 3600, 60);
    $x = $sec % 60;
    $parts = [];
    if ($h > 0) $parts[] = $h . ' ' . ruPlural($h, 'час', 'часа', 'часов');
    if ($m > 0) $parts[] = $m . ' ' . ruPlural($m, 'минуту', 'минуты', 'минут');
    if ($x > 0 || !$parts) $parts[] = $x . ' ' . ruPlural($x, 'секунду', 'секунды', 'секунд');
    return implode(' ', $parts);
}

// Запись о звонке в переписке. $is_caller — текущий пользователь сам звонил,
// $peer — имя собеседника. Для старых записей (обычный текст) возвращает null.
function callMessageText(string $raw, bool $is_caller, string $peer): ?string {
    if (!preg_match('/^\[CALL:(answered|missed|declined|busy):(audio|video):(\d+)\]$/', trim($raw), $m)) {
        return null;
    }
    $status = $m[1];
    $video  = $m[2] === 'video';
    $secs   = (int)$m[3];
    $noun   = $video ? 'видеозвонок' : 'звонок';
    $Noun   = $video ? 'Видеозвонок' : 'Звонок';
    $peer   = $peer !== '' ? $peer : 'собеседника';

    if ($status === 'answered') {
        return $Noun . ' с ' . $peer . ' завершён, длился ' . callDurationWords($secs);
    }
    if ($status === 'declined') {
        return $is_caller ? $peer . ' отклонил(а) ' . $noun : 'Вы отклонили ' . $noun . ' от ' . $peer;
    }
    if ($status === 'busy') {
        return $is_caller ? $peer . ' занят(а)' : 'Вы пропустили ' . $noun . ' от ' . $peer;
    }
    // missed
    return $is_caller ? $peer . ' не ответил(а) на ' . $noun : 'Вы пропустили ' . $noun . ' от ' . $peer;
}

// Запасной путь записи звонков в переписку. Основной — api/call.php (в момент hangup/decline/busy),
// но если он по какой-то причине не записал звонок, здесь он дописывается по сигналам из call_signals
// при открытии страницы и при каждом автообновлении чата. Оба пути используют таблицу call_logs,
// поэтому на один звонок всегда создаётся ровно одна запись и у обоих собеседников она одинаковая.
function syncCallLogs(mysqli $conn, int $user_id): void {
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS call_logs (
            call_id VARCHAR(32) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (call_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        if ($conn->query("SHOW TABLES LIKE 'call_signals'")->num_rows === 0) return;

        $stmt = $conn->prepare("
            SELECT s.call_id, s.type
            FROM call_signals s
            LEFT JOIN call_logs l ON l.call_id = s.call_id
            WHERE (s.from_user = ? OR s.to_user = ?)
              AND s.type IN ('hangup', 'decline', 'busy')
              AND s.created_at >= (NOW() - INTERVAL 30 MINUTE)
              AND l.call_id IS NULL
            ORDER BY s.id ASC
            LIMIT 40
        ");
        if (!$stmt) return;
        $stmt->bind_param('ii', $user_id, $user_id);
        $stmt->execute();
        $res = $stmt->get_result();
        $ended = [];                         // call_id => тип первого завершающего сигнала
        while ($row = $res->fetch_assoc()) {
            if (!isset($ended[$row['call_id']])) $ended[$row['call_id']] = (string)$row['type'];
        }
        $stmt->close();

        foreach ($ended as $call_id => $end_type) {
            $stmt = $conn->prepare("
                SELECT type, from_user, to_user, media, UNIX_TIMESTAMP(created_at) AS ts
                FROM call_signals
                WHERE call_id = ? AND type IN ('offer', 'answer', 'hangup', 'decline', 'busy')
                ORDER BY id ASC
            ");
            if (!$stmt) continue;
            $stmt->bind_param('s', $call_id);
            $stmt->execute();
            $sig = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            $offer = null; $answer_ts = null; $end_ts = null;
            foreach ($sig as $r) {
                if ($r['type'] === 'offer' && $offer === null) {
                    $offer = $r;
                } elseif ($r['type'] === 'answer' && $offer !== null && $answer_ts === null
                          && (int)$r['from_user'] === (int)$offer['to_user']) {
                    $answer_ts = (int)$r['ts'];
                } elseif (in_array($r['type'], ['hangup', 'decline', 'busy'], true) && $end_ts === null) {
                    $end_ts = (int)$r['ts'];
                }
            }
            if ($offer === null) continue;   // начала звонка уже нет в сигналах — не гадаем

            // Один звонок — одна запись (кто первый вставил строку в call_logs, тот и пишет)
            $stmt = $conn->prepare('INSERT IGNORE INTO call_logs (call_id) VALUES (?)');
            if (!$stmt) continue;
            $stmt->bind_param('s', $call_id);
            $stmt->execute();
            $took = $stmt->affected_rows === 1;
            $stmt->close();
            if (!$took) continue;

            $media = $offer['media'] === 'video' ? 'video' : 'audio';
            if ($end_type === 'decline')      { $status = 'declined'; $secs = 0; }
            elseif ($end_type === 'busy')     { $status = 'busy';     $secs = 0; }
            elseif ($answer_ts !== null)      { $status = 'answered'; $secs = max(0, ($end_ts ?? $answer_ts) - $answer_ts); }
            else                              { $status = 'missed';   $secs = 0; }

            $text    = '[CALL:' . $status . ':' . $media . ':' . $secs . ']';
            $is_read = ($status === 'missed') ? 0 : 1;
            $caller  = (int)$offer['from_user'];
            $callee  = (int)$offer['to_user'];
            $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message, message_type, is_encrypted, is_read, created_at)
                                    VALUES (?, ?, ?, 'call', 0, ?, NOW())");
            if (!$stmt) { error_log('syncCallLogs: ' . $conn->error); continue; }
            $stmt->bind_param('iisi', $caller, $callee, $text, $is_read);
            $stmt->execute();
            $stmt->close();
        }
    } catch (Throwable $e) {
        error_log('syncCallLogs error: ' . $e->getMessage());
    }
}

// Короткая длительность для карточки звонка: «45 с», «1 мин 15 с», «2 ч 3 мин»
function callDurationShort(int $sec): string {
    $sec = max(0, $sec);
    $h = intdiv($sec, 3600);
    $m = intdiv($sec % 3600, 60);
    $x = $sec % 60;
    $parts = [];
    if ($h > 0) $parts[] = $h . ' ч';
    if ($m > 0) $parts[] = $m . ' мин';
    if (($x > 0 && $h === 0) || !$parts) $parts[] = $x . ' с';
    return implode(' ', $parts);
}

// Карточка звонка в стиле мессенджера: заголовок («Исходящий звонок»), подпись («Отменён»,
// «Пропущен», «1 мин 15 с») и признак «неудачного» звонка (подпись красным).
// Для старых записей (обычный текст) возвращает null.
function callCardParts(string $raw, bool $is_caller, string $peer = ''): ?array {
    if (!preg_match('/^\[CALL:(answered|missed|declined|busy):(audio|video):(\d+)\]$/', trim($raw), $m)) {
        return null;
    }
    $status = $m[1];
    $video  = $m[2] === 'video';
    $secs   = (int)$m[3];
    $peer   = $peer !== '' ? $peer : 'Собеседник';

    $kind  = $video ? 'видеозвонок' : 'звонок';
    $title = ($is_caller ? 'Исходящий ' : 'Входящий ') . $kind;

    // Кто звонил -> кому звонили
    $from = $is_caller ? 'Вы' : $peer;
    $to   = $is_caller ? $peer : 'Вы';
    $route = [$from, $to];

    if ($status === 'answered') {
        // Поговорили
        $sub = 'Поговорили · ' . callDurationShort($secs);
        $bad = false;
    } elseif ($status === 'declined') {
        $sub = $is_caller ? $peer . ' отклонил(а) звонок' : 'Вы отклонили звонок';
        $bad = !$is_caller;
    } elseif ($status === 'busy') {
        if ($is_caller) {
            $sub = $peer . ' занят(а)';
            $bad = false;
        } else {
            $title = 'Пропущенный ' . $kind;
            $sub   = 'Вы были заняты';
            $bad   = true;
        }
    } else { // missed
        if ($is_caller) {
            // Я звонил, собеседник не ответил
            $sub = $peer . ' не ответил(а)';
            $bad = true;
        } else {
            // Мне звонили, я пропустил
            $title = 'Пропущенный ' . $kind;
            $sub   = 'Вы не ответили';
            $bad   = true;
        }
    }

    return ['title' => $title, 'sub' => $sub, 'bad' => $bad, 'incoming' => !$is_caller, 'video' => $video, 'route' => $route];
}

function formatMessagePreview(string $message, string $type, bool $is_mine = false, string $peer = ''): string {
    if ($type === 'call') {
        $call_text = callMessageText($message, $is_mine, $peer);
        return $call_text !== null ? $call_text : mb_substr(str_replace(["\r", "\n"], ' ', $message), 0, 60, 'UTF-8');
    }
    if ($type === 'photo') return '🖼️ Фото';
    if ($type === 'video') return '🎬 Видео';
    if ($type === 'voice') return 'Голосовое сообщение';
    if ($message === '') return '';
    $message = str_replace(["\r", "\n"], ' ', $message);
    return mb_substr($message, 0, 30, 'UTF-8');
}

// Ключ и расшифровка текста постов — те же, что в index.php (getPostsEncryptionKey / decryptPostContent)
function chatPostsKey(): string {
    static $key = null;
    if ($key !== null) return $key;
    if (defined('ENCRYPTION_SALT') && ENCRYPTION_SALT !== '') {
        return $key = hash('sha256', 'posts:' . ENCRYPTION_SALT, true);
    }
    $secret_file = __DIR__ . '/posts_encryption.key';
    $secret = is_file($secret_file) ? trim((string)file_get_contents($secret_file)) : '';
    if ($secret === '') $secret = 'posts-fallback-secret';
    return $key = hash('sha256', 'posts:' . $secret, true);
}

function chatDecryptPost(string $encrypted): string {
    if ($encrypted === '') return '';
    $data = base64_decode($encrypted, true);
    if ($data === false) return '';
    $iv_len = openssl_cipher_iv_length('aes-256-cbc');
    if (strlen($data) < $iv_len) return '';
    $out = openssl_decrypt(substr($data, $iv_len), 'aes-256-cbc', chatPostsKey(), OPENSSL_RAW_DATA, substr($data, 0, $iv_len));
    return $out === false ? '' : $out;
}

// Полные данные поста для окна просмотра в чате: текст, лайки, репосты, комментарии
function chatPostPayload(mysqli $conn, int $post_id, int $user_id): ?array {
    $stmt = $conn->prepare("
        SELECT p.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS author_name, u.avatar AS author_avatar,
               (SELECT COUNT(*) FROM post_likes   WHERE post_id = p.id) AS likes_count,
               (SELECT COUNT(*) FROM post_reposts WHERE post_id = p.id) AS reposts_count,
               (SELECT COUNT(*) FROM post_likes   WHERE post_id = p.id AND user_id = ?) AS user_liked,
               (SELECT COUNT(*) FROM post_reposts WHERE post_id = p.id AND user_id = ?) AS user_reposted
        FROM posts p JOIN users u ON u.id = p.user_id
        LEFT JOIN user_profiles up ON up.user_id = u.id
        WHERE p.id = ? LIMIT 1
    ");
    if (!$stmt) return null;
    $stmt->bind_param('iii', $user_id, $user_id, $post_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) return null;

    $text = (string)($row['content'] ?? '');
    if (!empty($row['is_encrypted']) && $text !== '') $text = chatDecryptPost($text);

    $image  = (string)($row['image'] ?? '');
    $avatar = (string)($row['author_avatar'] ?? '');
    $author = (int)$row['user_id'];

    return [
        'id'            => $post_id,
        'author_id'     => $author,
        'author_name'   => (string)$row['author_name'],
        'author_avatar' => (safeFileExists($avatar) && strpos($avatar, '..') === false) ? $avatar : '',
        'text'          => $text,
        'image'         => (safeFileExists($image) && strpos($image, '..') === false) ? $image : '',
        'created_at'    => (string)($row['created_at'] ?? ''),
        'likes'         => (int)$row['likes_count'],
        'reposts'       => (int)$row['reposts_count'],
        'liked'         => (int)$row['user_liked'] > 0,
        'reposted'      => (int)$row['user_reposted'] > 0,
        'page_url'      => 'index.php?user=' . $author . '#post-' . $post_id,
    ];
}

function chatPostComments(mysqli $conn, int $post_id, int $user_id): array {
    $stmt = $conn->prepare("
        SELECT c.id, c.user_id, c.comment, c.created_at, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar
        FROM post_comments c JOIN users u ON u.id = c.user_id
        LEFT JOIN user_profiles up ON up.user_id = u.id
        WHERE c.post_id = ? ORDER BY c.created_at ASC, c.id ASC LIMIT 300
    ");
    if (!$stmt) return [];
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $out = [];
    while ($r = $res->fetch_assoc()) $out[] = chatPostCommentRow($r, $user_id);
    $stmt->close();
    return $out;
}

function chatPostCommentRow(array $r, int $user_id): array {
    $avatar = (string)($r['avatar'] ?? '');
    return [
        'id'         => (int)$r['id'],
        'user_id'    => (int)$r['user_id'],
        'username'   => (string)$r['username'],
        'avatar'     => (safeFileExists($avatar) && strpos($avatar, '..') === false) ? $avatar : '',
        'text'       => (string)$r['comment'],
        'ts'         => (int)strtotime((string)$r['created_at']),
        'can_delete' => ((int)$r['user_id'] === $user_id || $user_id === 1),
    ];
}

// Уведомление автору поста (та же таблица, что использует share_post)
/**
 * Одно уведомление вместо стопки: перед вставкой удаляем прежнее (прочитанное или нет)
 * уведомление того же типа от того же отправителя с той же ссылкой и тем же текстом.
 * В итоге у получателя всегда одно (самое свежее) уведомление, а не десятки одинаковых.
 */
function notifyOnce(mysqli $conn, int $receiver_id, int $sender_id, string $type, string $message, string $link): bool {
    $del = $conn->prepare("DELETE FROM notifications
        WHERE user_id = ? AND sender_id = ? AND type = ? AND link = ? AND message = ?");
    if ($del) {
        $del->bind_param('iisss', $receiver_id, $sender_id, $type, $link, $message);
        $del->execute();
        $del->close();
    }
    $ins = $conn->prepare("INSERT INTO notifications (user_id, sender_id, type, message, link, is_read, created_at)
        VALUES (?, ?, ?, ?, ?, 0, NOW())");
    if (!$ins) return false;
    $ins->bind_param('iisss', $receiver_id, $sender_id, $type, $message, $link);
    $ok = $ins->execute();
    $ins->close();
    return (bool)$ok;
}

function chatNotifyPostAuthor(mysqli $conn, int $post_id, int $user_id, string $type, string $text): void {
    $stmt = $conn->prepare('SELECT user_id FROM posts WHERE id = ?');
    if (!$stmt) return;
    $stmt->bind_param('i', $post_id);
    $stmt->execute();
    $owner = (int)($stmt->get_result()->fetch_assoc()['user_id'] ?? 0);
    $stmt->close();
    if ($owner <= 0 || $owner === $user_id) return;
    $name = profileDisplayName($conn, $user_id, (string)($_SESSION['username'] ?? 'Пользователь'));
    $msg  = $name . ' ' . $text;
    $link = 'index.php?user=' . $user_id;
    notifyOnce($conn, $owner, $user_id, $type, $msg, $link);
}

// Путь к фото поста (для карточки поста в сообщении); пустая строка, если фото нет
function getSharedPostImage(int $post_id): string {
    global $conn;
    static $cache = [];
    if (array_key_exists($post_id, $cache)) {
        return $cache[$post_id];
    }
    $cache[$post_id] = '';
    if ($post_id > 0 && $conn instanceof mysqli) {
        $stmt = $conn->prepare('SELECT image FROM posts WHERE id = ? LIMIT 1');
        if ($stmt) {
            $stmt->bind_param('i', $post_id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            $image = (string)($row['image'] ?? '');
            if ($image !== '' && file_exists($image)) {
                $cache[$post_id] = $image;
            }
        }
    }
    return $cache[$post_id];
}

function formatChatMessage(string $message): string {
    $formatted = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

    // Ссылки http(s):// -> кликабельные. Сначала прячем их под метки, чтобы флаги и @упоминания
    // ниже не трогали содержимое ссылок, в конце метки заменяются готовой разметкой.
    $link_tokens = [];
    $own_host = strtolower((string)strtok((string)($_SERVER['HTTP_HOST'] ?? ''), ':'));
    $formatted = preg_replace_callback(
        '~https?://[^\s<]+~iu',
        static function (array $matches) use (&$link_tokens, $own_host): string {
            $url = $matches[0];
            $trail = '';
            if (preg_match('~[.,:!?)\]]+$~u', $url, $t)) {
                $trail = $t[0];
                $url = substr($url, 0, -strlen($trail));
            }

            $plain = html_entity_decode($url, ENT_QUOTES, 'UTF-8');
            $host  = strtolower((string)parse_url($plain, PHP_URL_HOST));
            $same_site = $own_host !== '' && $host === $own_host;

            // Ссылка на пост из «Поделиться» показывается карточкой (с фото поста, если оно есть),
            // остальные ссылки — как есть
            $is_post_link = $same_site && preg_match('~index\.php\?user=\d+#post-(\d+)$~', $plain, $post_match);
            $target = $same_site ? '' : ' target="_blank" rel="noopener noreferrer"';
            $token = "\x01L" . count($link_tokens) . "\x02";

            if ($is_post_link) {
                $photo_html = '';
                $photo = getSharedPostImage((int)$post_match[1]);
                if ($photo !== '') {
                    $photo_html = '<img class="message-post-photo" src="'
                        . htmlspecialchars($photo, ENT_QUOTES, 'UTF-8') . '" alt="Фото поста" loading="lazy">';
                }
                $link_tokens[$token] = '<a class="message-link message-link-post' . ($photo_html !== '' ? ' has-photo' : '')
                    . '" href="' . $url . '" data-post-id="' . (int)$post_match[1] . '">' . $photo_html . '<span class="message-link-post-label">Открыть пост →</span></a>';
            } else {
                $link_tokens[$token] = '<a class="message-link" href="' . $url . '"' . $target . '>' . $url . '</a>';
            }
            return $token . $trail;
        },
        $formatted
    );

    $formatted = preg_replace_callback(
        '/[\x{1F1E6}-\x{1F1FF}][\x{1F1E6}-\x{1F1FF}]/u',
        static function (array $matches): string {
            $flag = $matches[0];
            $codepoints = [];
            foreach (preg_split('//u', $flag, -1, PREG_SPLIT_NO_EMPTY) as $symbol) {
                $codepoints[] = strtolower(dechex(mb_ord($symbol, 'UTF-8')));
            }

            $src = 'https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/svg/'
                . implode('-', $codepoints)
                . '.svg';

            return '<img class="chat-flag" src="' . $src . '" alt="' . $flag . '">';
        },
        $formatted
    );

    $formatted = preg_replace_callback(
        '/@([\p{L}\p{N}_.-]+)(\s*\([^()\r\n]*\))?/u',
        static function (array $matches): string {
            global $conn;
            static $user_ids = [];

            $username = html_entity_decode($matches[1], ENT_QUOTES, 'UTF-8');
            $cache_key = mb_strtolower($username, 'UTF-8');
            if (!array_key_exists($cache_key, $user_ids)) {
                $user_ids[$cache_key] = null;
                if ($conn instanceof mysqli) {
                    $stmt = $conn->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
                    if ($stmt) {
                        $stmt->bind_param('s', $username);
                        $stmt->execute();
                        $user = $stmt->get_result()->fetch_assoc();
                        $stmt->close();
                        if ($user) {
                            $user_ids[$cache_key] = (int)$user['id'];
                        }
                    }
                }
            }

            if (!$user_ids[$cache_key]) {
                return $matches[0];
            }

            $href = 'index.php?user=' . $user_ids[$cache_key];
            return '<a class="message-mention" href="' . $href . '">' . $matches[0] . '</a>';
        },
        $formatted
    );

    if ($link_tokens) {
        $formatted = strtr($formatted, $link_tokens);
    }

    return nl2br($formatted, false);
}

function generateWaveform(int $messageId, int $bars = 32): array {
    $seed = $messageId * 2654435761;
    $heights = [];
    for ($i = 0; $i < $bars; $i++) {
        $seed = ($seed * 1103515245 + 12345) & 0x7fffffff;
        $heights[] = 20 + (($seed >> 8) % 80);
    }
    return $heights;
}

function getPostedWaveform(): ?string {
    $raw = trim((string)($_POST['waveform'] ?? ''));
    if ($raw === '') {
        return null;
    }

    $values = json_decode($raw, true);
    if (!is_array($values) || count($values) < 8) {
        return null;
    }

    $normalized = [];
    foreach ($values as $value) {
        if (!is_numeric($value)) {
            continue;
        }
        $normalized[] = max(5, min(100, (int)round((float)$value)));
    }

    if (count($normalized) < 8) {
        return null;
    }

    $encoded = json_encode($normalized);
    return $encoded === false ? null : $encoded;
}

function saveVoiceRecord(mysqli $conn, int $user_id, string $file_path, ?int $duration, ?string $waveform): int {
    $sql = 'INSERT INTO voice_messages (user_id, file_path, duration, waveform) VALUES (?, ?, ?, ?)';
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new RuntimeException('Voice record prepare failed: ' . $conn->error);
    }

    $duration = max(0, (int)$duration);
    safeBind($stmt, $sql, [$user_id, $file_path, $duration, $waveform], 'isis');
    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Voice record save failed: ' . $error);
    }

    $voice_id = (int)$stmt->insert_id;
    $stmt->close();
    return $voice_id;
}

function resolveLegacyVoice(mysqli $conn, string $message): ?array {
    if (!preg_match('/^\[VOICE:(\d+)\]$/', trim($message), $matches)) {
        return null;
    }

    static $table_available = null;
    if ($table_available === null) {
        $check = $conn->query("SHOW TABLES LIKE 'voice_messages'");
        $table_available = $check instanceof mysqli_result && $check->num_rows > 0;
    }
    if (!$table_available) {
        return null;
    }

    $stmt = $conn->prepare('SELECT file_path, duration, waveform FROM voice_messages WHERE id = ?');
    if (!$stmt) {
        return null;
    }

    $voice_id = (int)$matches[1];
    $stmt->bind_param('i', $voice_id);
    $stmt->execute();
    $voice = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$voice || empty($voice['file_path'])) {
        return null;
    }

    $waveform = null;
    if (!empty($voice['waveform'])) {
        $decoded = json_decode((string)$voice['waveform'], true);
        if (is_array($decoded) && count($decoded) >= 8) {
            $waveform = array_map(
                static fn($height): int => max(5, min(100, (int)round((float)$height * 100))),
                $decoded
            );
        }
    }

    return [
        'file_path' => (string)$voice['file_path'],
        'voice_duration' => max(0, (int)($voice['duration'] ?? 0)),
        'waveform' => $waveform,
    ];
}

// Индикатор прочтения: один кружок = не прочитано, два кружка = прочитано.
// Кружки рисуются через CSS (<i>), а не символом «●», поэтому расстояние между ними задаётся gap и они не слипаются.
function readStatusDots(bool $is_read): string {
    return $is_read ? '<i></i><i></i>' : '<i></i>';
}

function safeFileExists(?string $path): bool {
    return !empty($path) && is_file($path);
}

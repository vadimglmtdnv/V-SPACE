<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
require_once __DIR__ . '/maintenance.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$conn = db_connect();
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$user_id = (int)$_SESSION["user_id"];

// ID (ник) пользователя: общий столбец с edit.php
$check_handle = $conn->query("SHOW COLUMNS FROM users LIKE 'handle'");
if ($check_handle && $check_handle->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN handle VARCHAR(32) DEFAULT NULL, ADD UNIQUE KEY handle (handle)");
}

// ===== Фильтры и страницы =====
const NOTIF_FRIEND_TYPES   = ['friend_request', 'friend_accepted', 'friend_removed'];
const NOTIF_ACTIVITY_TYPES = ['like', 'comment', 'repost', 'mention', 'tag'];

$filter = $_GET['filter'] ?? ($_POST['filter'] ?? 'all');
if (!in_array($filter, ['all', 'unread', 'friends', 'activity'], true)) {
    $filter = 'all';
}
$page = max(1, (int)($_GET['page'] ?? ($_POST['page'] ?? 1)));
$per_page = 20;

function notificationsUrl(string $filter, int $page = 1): string {
    $q = [];
    if ($filter !== 'all') $q['filter'] = $filter;
    if ($page > 1) $q['page'] = $page;
    return 'notifications.php' . ($q ? '?' . http_build_query($q) : '');
}

function safeNotificationLink($link): string {
    $link = trim((string)$link);
    if ($link !== '' && preg_match('~^(?![a-z][a-z0-9+.\-]*:|//)[\w./?=&%#\-]+$~iu', $link)) {
        return $link;
    }
    return '';
}

// ===== Открытие уведомления: пометить прочитанным и перейти по ссылке =====
if (isset($_GET['open'])) {
    $open_id = (int)$_GET['open'];
    $stmt = $conn->prepare("SELECT link FROM notifications WHERE id = ? AND user_id = ? LIMIT 1");
    $stmt->bind_param("ii", $open_id, $user_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row) {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $open_id, $user_id);
        $stmt->execute();
        $stmt->close();
        $target = safeNotificationLink($row['link']);
        header("Location: " . ($target !== '' ? $target : notificationsUrl($filter, $page)));
    } else {
        header("Location: notifications.php");
    }
    exit;
}

// ===== POST-действия =====
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['mark_read'])) {
        $id = (int)$_POST['notification_id'];
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $id, $user_id);
        $stmt->execute();
        $stmt->close();
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['notification_id'];
        $stmt = $conn->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $id, $user_id);
        $stmt->execute();
        $stmt->close();
        $_SESSION['success_message'] = 'Уведомление удалено';
    } elseif (isset($_POST['mark_all_read'])) {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0 AND type <> 'message'");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
        $_SESSION['success_message'] = 'Все уведомления отмечены прочитанными';
    } elseif (isset($_POST['clear_all'])) {
        $stmt = $conn->prepare("DELETE FROM notifications WHERE user_id = ? AND type <> 'message'");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
        $_SESSION['success_message'] = 'Уведомления очищены';
    }

    header("Location: " . notificationsUrl($filter, $page));
    exit;
}

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)
    ? $_GET['theme']
    : (isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true) ? $_COOKIE['theme'] : 'dark');
if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    setcookie('theme', $theme, time() + 365 * 24 * 60 * 60, '/');
}

// ===== Текущий пользователь и данные шапки =====
$stmt = $conn->prepare("SELECT id, username, handle, avatar, status, is_admin FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$current_user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$notifications = [];
$notif_count = 0;
$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar AS sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC
    LIMIT 30
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS count
    FROM notifications
    WHERE user_id = ? AND is_read = 0
      AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
$stmt->close();

$pending_reports_count = 0;
$is_admin = (int)($current_user['is_admin'] ?? 0) === 1;
if ($is_admin) {
    $result = $conn->query("SELECT COUNT(*) AS count FROM reports WHERE status = 'pending'");
    if ($result) {
        $pending_reports_count = (int)($result->fetch_assoc()['count'] ?? 0);
    }
}

// ===== Счётчики вкладок =====
$friend_list = "'" . implode("','", NOTIF_FRIEND_TYPES) . "'";
$activity_list = "'" . implode("','", NOTIF_ACTIVITY_TYPES) . "'";
$stmt = $conn->prepare("
    SELECT
        COUNT(*) AS total,
        SUM(is_read = 0) AS unread,
        SUM(type IN ($friend_list)) AS friends,
        SUM(type IN ($activity_list)) AS activity
    FROM notifications
    WHERE user_id = ? AND type <> 'message'
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$counts = $stmt->get_result()->fetch_assoc() ?: [];
$stmt->close();
$count_all      = (int)($counts['total'] ?? 0);
$count_unread   = (int)($counts['unread'] ?? 0);
$count_friends  = (int)($counts['friends'] ?? 0);
$count_activity = (int)($counts['activity'] ?? 0);
$unread_count   = $count_unread;

// ===== Список уведомлений для страницы =====
$where = "n.user_id = ? AND n.type <> 'message'";
if ($filter === 'unread')   $where .= " AND n.is_read = 0";
if ($filter === 'friends')  $where .= " AND n.type IN ($friend_list)";
if ($filter === 'activity') $where .= " AND n.type IN ($activity_list)";

$offset = ($page - 1) * $per_page;
$limit = $per_page + 1;
$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar AS sender_avatar_current
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE $where
    ORDER BY n.created_at DESC, n.id DESC
    LIMIT $limit OFFSET $offset
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$page_items = [];
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $page_items[] = $row;
}
$stmt->close();
$has_next = count($page_items) > $per_page;
if ($has_next) array_pop($page_items);

// Группировка по дням
$groups = ['Сегодня' => [], 'Вчера' => [], 'Ранее' => []];
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));
foreach ($page_items as $item) {
    $d = date('Y-m-d', strtotime($item['created_at']));
    $groups[$d === $today ? 'Сегодня' : ($d === $yesterday ? 'Вчера' : 'Ранее')][] = $item;
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

if (!function_exists('getNotificationTypeName')) {
function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}
}

if (!function_exists('getNotificationIcon')) {
function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}
}

function displayHandle(array $u): string {
    return !empty($u['handle']) ? $u['handle'] : 'id' . (int)($u['id'] ?? 0);
}

function getAvatarLetter($username) {
    return htmlspecialchars(
        mb_substr($username ?: "?", 0, 1, "UTF-8"),
        ENT_QUOTES,
        "UTF-8"
    );
}

function hasAvatar($avatar) {
    if (empty($avatar)) {
        return false;
    }

    if (is_file($avatar)) {
        return true;
    }

    return is_file(__DIR__ . DIRECTORY_SEPARATOR . ltrim($avatar, '/\\'));
}

function getAvatarUrl($avatar): string {
    $avatar = trim((string)$avatar);
    if ($avatar === '') {
        return '';
    }

    if (preg_match('/^(?:https?:)?\/\//i', $avatar)) {
        return $avatar;
    }

    return ltrim(str_replace('\\', '/', $avatar), '/');
}

$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message'], $_SESSION['error_message']);

$conn->close();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="<?= $theme === 'light' ? '#f0f2f5' : '#313338' ?>">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>Уведомления</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/friends.css">
    <link rel="stylesheet" href="assets/css/notifications.css">
    <link rel="stylesheet" href="assets/css/notifications-page.css">
    <script src="assets/js/header-dropdowns.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/header-dropdowns.js') ?>" defer></script>
    <style>
        .header-left { display: flex; align-items: center; gap: 20px; }
    </style>
    <link rel="stylesheet" href="assets/css/theme-switch.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/theme-switch.css') ?>">
    <script src="assets/js/theme-switch.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/theme-switch.js') ?>" defer></script>
</head>
<body data-theme="<?= $theme ?>">

    <!-- ===== ВЕРХНЯЯ ПАНЕЛЬ (как в index.php) ===== -->
    <header class="header header-cosmic">
        <span class="header-shooting-stars" aria-hidden="true">
            <span class="sky-cloud" aria-hidden="true"></span>
            <span class="sky-rain" aria-hidden="true"></span>
            <span class="sky-snow" aria-hidden="true"></span>
            <span class="sky-fog" aria-hidden="true"></span>
            <span class="sky-flash" aria-hidden="true"></span>
            <span class="header-shooting-star star-one"></span>
            <span class="header-shooting-star star-two"></span>
            <span class="header-shooting-star star-three"></span>
            <span class="header-comet"></span>
        </span>
        <div class="header-left">
            <div class="logo">
                <div class="logo-icon">
                    <img src="images/logo_type.svg" alt="SPACE Logo" width="40" height="40">
                </div>
            </div>
        </div>
        <div class="search-box"></div>
        <div class="header-right">

            <?php if ($is_admin): ?>
                <a href="reports.php" class="moderation-btn" title="Модерация">
                <img src="images/protection.svg" alt="Модерация" class="moderation-icon">
                <?php if ($pending_reports_count > 0): ?>
                    <span class="moderation-badge"><?= $pending_reports_count > 99 ? '99+' : $pending_reports_count ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>

            <div class="notifications-wrapper">
                <button class="notifications-btn" id="notificationsBtn" title="Уведомления">
                    <?php include __DIR__ . '/includes/notification_bell.php'; ?>
                    <?php if ($notif_count > 0): ?>
                        <span class="notifications-badge" id="notificationsBadge"><?= $notif_count > 99 ? '99+' : $notif_count ?></span>
                    <?php else: ?>
                        <span class="notifications-badge" id="notificationsBadge" style="display:none;">0</span>
                    <?php endif; ?>
                </button>
                <div class="notifications-dropdown" id="notificationsDropdown">
                    <div class="notifications-header">
                        <span class="notifications-title">Уведомления</span>
                        <div class="notifications-header-actions">
                            <?php if ($notif_count > 0): ?>
                                <button class="mark-all-read-btn" id="markAllReadBtn">Все прочитано</button>
                            <?php endif; ?>
                            <span class="notifications-count" id="notificationsCount"><?= $notif_count ?> новых</span>
                        </div>
                    </div>
                    <div class="notifications-list" id="notificationsList">
                        <?php if (empty($notifications)): ?>
                            <div class="notifications-empty">
                                <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
                                <div class="empty-text">Нет уведомлений</div>
                                <div class="empty-sub">Здесь будут появляться ваши уведомления</div>
                            </div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notif): 
                                $icon = getNotificationIcon((string)$notif['type']);
                                $notif_type_class = $notif['type'];
                                $sender_avatar = $notif['sender_avatar'] ?? '';
                                $sender_name = $notif['sender_name'] ?? '';
                                
                                $avatar_exists = !empty($sender_avatar) && hasAvatar($sender_avatar);
                                if ($avatar_exists) { $sender_avatar = getAvatarUrl($sender_avatar); }
                            ?>
                                <a href="<?= htmlspecialchars($notif['link'] ?: '#') ?>" class="notification-item <?= $notif['is_read'] ? 'read' : 'unread' ?> type-<?= htmlspecialchars($notif_type_class) ?>" data-notification-id="<?= (int)$notif['id'] ?>">
                                    <div class="notif-avatar-wrapper">
                                        <div class="notif-avatar">
                                            <?php if ($avatar_exists): ?>
                                                <img src="<?= htmlspecialchars($sender_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?>">
                                            <?php elseif (!empty($sender_name)): ?>
                                                <span class="avatar-letter"><?= htmlspecialchars(mb_strtoupper(mb_substr($sender_name, 0, 1, 'UTF-8'), 'UTF-8')) ?></span>
                                            <?php else: ?>
                                                <span class="avatar-letter">?</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="notif-content">
                                        <div class="notif-text">
                                            <?php if (!empty($sender_name)): ?>
                                                <strong class="notif-sender"><?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?></strong>
                                                <span class="notif-message"> <?= htmlspecialchars($notif['message'], ENT_QUOTES, "UTF-8") ?></span>
                                            <?php else: ?>
                                                <span class="notif-message"><?= htmlspecialchars($notif['message'], ENT_QUOTES, "UTF-8") ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="notif-meta">
                                            <span class="notif-time"><?= timeAgo($notif['created_at']) ?></span>
                                            <span class="notif-type-badge <?= htmlspecialchars($notif_type_class) ?>"><?= htmlspecialchars(getNotificationTypeName((string)$notif['type'])) ?></span>
                                        </div>
                                    </div>
                                    <?php if (!$notif['is_read']): ?>
                                        <span class="notif-dot"></span>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="notifications-footer">
                        <a href="notifications.php" class="view-all-notifications">Показать всё</a>
                    </div>
                </div>
            </div>

            <div class="avatar-dropdown">
                <?php
                $current_avatar = $current_user['avatar'] ?? '';
                $current_username = $current_user['username'] ?? 'Пользователь';
                require_once __DIR__ . '/includes/display_name.php'; $current_username = userDisplayName($conn ?? null, (int)($_SESSION['user_id'] ?? 0), (string)$current_username);
                $current_letter = mb_strtoupper(mb_substr($current_username, 0, 1, 'UTF-8'), 'UTF-8');
                $current_status = $current_user['status'] ?? 'offline';
                $current_handle = displayHandle($current_user);
                ?>
                <button class="header-avatar <?= $current_status === 'online' ? 'is-online' : 'is-offline' ?>" id="avatarBtn" title="Мой профиль" aria-label="Мой профиль">
                    <?php if (hasAvatar($current_avatar)): ?>
                        <img src="<?= htmlspecialchars(getAvatarUrl($current_avatar), ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                    <?php else: ?>
                        <?= htmlspecialchars($current_letter) ?>
                    <?php endif; ?>
                </button>
                <div class="dropdown-menu" id="avatarDropdown">
                    <div class="dropdown-header">
                        <div class="dropdown-avatar">
                            <?php if (hasAvatar($current_avatar)): ?>
                                <img src="<?= htmlspecialchars(getAvatarUrl($current_avatar), ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                            <?php else: ?>
                                <?= htmlspecialchars($current_letter) ?>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-user-info">
                            <div class="dropdown-username"><?= htmlspecialchars($current_username) ?></div>
                            <div class="dropdown-handle"><?= htmlspecialchars($current_handle) ?></div>
                        </div>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a href="index.php" class="dropdown-item">
                        <span class="dropdown-icon">◐</span> Мой профиль
                    </a>
                    <a href="edit.php" class="dropdown-item">
                        <span class="dropdown-icon">✎</span> Редактировать
                    </a>
                    <a href="settings.php" class="dropdown-item">
                        <span class="dropdown-icon">⚙</span> Настройки
                    </a>
                    <div class="theme-trigger" id="themeTrigger">
                        <span class="dropdown-icon">🎨</span>
                        <span>Тема</span>
                        <span class="theme-current">
                            <?php
                            $theme_name = 'Тёмная';
                            if ($theme === 'light') $theme_name = 'Светлая';
                            elseif ($theme === 'system') $theme_name = 'Системная';
                            echo htmlspecialchars($theme_name);
                            ?>
                        </span>
                        <span class="theme-arrow" id="themeArrow">▼</span>
                    </div>

                    <div class="theme-submenu" id="themeSubmenu">
                        <a href="notifications.php?theme=dark" class="theme-item <?= $theme === 'dark' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot dark"></span>
                                Тёмная
                            </span>
                            <?php if ($theme === 'dark'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="notifications.php?theme=light" class="theme-item <?= $theme === 'light' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot light"></span>
                                Светлая
                            </span>
                            <?php if ($theme === 'light'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="notifications.php?theme=system" class="theme-item <?= $theme === 'system' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot system"></span>
                                Системная
                            </span>
                            <?php if ($theme === 'system'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a href="logout.php" class="dropdown-item logout-item">
                        <span class="dropdown-icon">↪</span> Выйти
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="friends-page-shell">
    <main class="main">

        <?php if ($success_message): ?>
            <div class="notification success"><?= htmlspecialchars($success_message) ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="notification error"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <div class="page-head">
            <div>
                <h1 class="page-title">Уведомления</h1>
                <p class="page-subtitle">
                    <?= $count_unread > 0 ? 'Непрочитанных: ' . $count_unread : 'Все уведомления прочитаны' ?>
                </p>
            </div>
            <?php if ($count_all > 0): ?>
                <div class="page-head-actions">
                    <?php if ($count_unread > 0): ?>
                        <form method="POST">
                            <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                            <button type="submit" name="mark_all_read" class="friend-button">Прочитать все</button>
                        </form>
                    <?php endif; ?>
                    <form method="POST" data-confirm="Удалить все уведомления?">
                        <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                        <button type="submit" name="clear_all" class="friend-button red">Очистить все</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>

        <!-- Вкладки -->
        <div class="friends-tabs">
            <a href="<?= notificationsUrl('all') ?>" class="friends-tab <?= $filter === 'all' ? 'active' : '' ?>">
                Все
                <?php if ($count_all > 0): ?><span class="<?= 'all' === 'unread' ? 'badge' : 'tab-count' ?>"><?= $count_all ?></span><?php endif; ?>
            </a>
            <a href="<?= notificationsUrl('unread') ?>" class="friends-tab <?= $filter === 'unread' ? 'active' : '' ?>">
                Непрочитанные
                <?php if ($count_unread > 0): ?><span class="<?= 'unread' === 'unread' ? 'badge' : 'tab-count' ?>"><?= $count_unread ?></span><?php endif; ?>
            </a>
            <a href="<?= notificationsUrl('friends') ?>" class="friends-tab <?= $filter === 'friends' ? 'active' : '' ?>">
                Друзья
                <?php if ($count_friends > 0): ?><span class="<?= 'friends' === 'unread' ? 'badge' : 'tab-count' ?>"><?= $count_friends ?></span><?php endif; ?>
            </a>
            <a href="<?= notificationsUrl('activity') ?>" class="friends-tab <?= $filter === 'activity' ? 'active' : '' ?>">
                Активность
                <?php if ($count_activity > 0): ?><span class="<?= 'activity' === 'unread' ? 'badge' : 'tab-count' ?>"><?= $count_activity ?></span><?php endif; ?>
            </a>
        </div>

        <?php if (empty($page_items)): ?>
            <div class="empty">
                <div class="empty-title">
                    <?php if ($filter === 'unread'): ?>Нет непрочитанных уведомлений
                    <?php else: ?>Здесь пока пусто<?php endif; ?>
                </div>
                <div class="empty-text">Новые события появятся здесь: заявки в друзья, лайки, комментарии и упоминания.</div>
            </div>
        <?php else: ?>
            <?php foreach ($groups as $group_title => $items): ?>
                <?php if (empty($items)) continue; ?>
                <section class="section">
                    <div class="section-title"><?= htmlspecialchars($group_title) ?> — <?= count($items) ?></div>

                    <?php foreach ($items as $n): ?>
                        <?php
                        $n_unread = (int)$n['is_read'] === 0;
                        $n_name = $n['sender_name'] ?? '';
                        $n_avatar = $n['sender_avatar_current'] ?? ($n['sender_avatar'] ?? '');
                        $n_has_avatar = !empty($n_avatar) && hasAvatar($n_avatar);
                        $n_icon = getNotificationIcon((string)$n['type']);
                        ?>
                        <div class="n-card <?= $n_unread ? 'unread' : 'read' ?> type-<?= htmlspecialchars((string)$n['type'], ENT_QUOTES, 'UTF-8') ?>">
                            <a href="notifications.php?open=<?= (int)$n['id'] ?>" class="n-main">
                                <div class="n-avatar">
                                    <?php if ($n_has_avatar): ?>
                                        <img src="<?= htmlspecialchars(getAvatarUrl($n_avatar), ENT_QUOTES, 'UTF-8') ?>" alt="">
                                    <?php elseif ($n_name !== ''): ?>
                                        <?= htmlspecialchars(getAvatarLetter($n_name)) ?>
                                    <?php else: ?>
                                        ?
                                    <?php endif; ?>
                                </div>
                                <div class="n-body">
                                    <div class="n-text">
                                        <?php if ($n_name !== ''): ?>
                                            <strong><?= htmlspecialchars($n_name, ENT_QUOTES, 'UTF-8') ?></strong>
                                        <?php endif; ?>
                                        <?= htmlspecialchars($n['message'], ENT_QUOTES, 'UTF-8') ?>
                                    </div>
                                    <div class="n-meta">
                                        <span><?= timeAgo($n['created_at']) ?></span>
                                        <span class="n-chip"><?= htmlspecialchars(getNotificationTypeName((string)$n['type'])) ?></span>
                                    </div>
                                </div>
                                <?php if ($n_unread): ?><span class="n-dot" title="Не прочитано"></span><?php endif; ?>
                            </a>

                            <div class="n-actions">
                                <?php if ($n_unread): ?>
                                    <form method="POST">
                                        <input type="hidden" name="notification_id" value="<?= (int)$n['id'] ?>">
                                        <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                                        <input type="hidden" name="page" value="<?= (int)$page ?>">
                                        <button type="submit" name="mark_read" class="friend-button">Прочитано</button>
                                    </form>
                                <?php endif; ?>
                                <form method="POST">
                                    <input type="hidden" name="notification_id" value="<?= (int)$n['id'] ?>">
                                    <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                                    <input type="hidden" name="page" value="<?= (int)$page ?>">
                                    <button type="submit" name="delete" class="friend-button n-delete">Удалить</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </section>
            <?php endforeach; ?>

            <?php if ($page > 1 || $has_next): ?>
                <nav class="pager">
                    <?php if ($page > 1): ?>
                        <a href="<?= notificationsUrl($filter, $page - 1) ?>" class="friend-button">← Назад</a>
                    <?php endif; ?>
                    <span class="pager-page">Страница <?= (int)$page ?></span>
                    <?php if ($has_next): ?>
                        <a href="<?= notificationsUrl($filter, $page + 1) ?>" class="friend-button">Далее →</a>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        <?php endif; ?>

    </main>

    <footer class="site-footer">
        <div class="footer-content">
            <span class="footer-copy">SPACE &copy; <span class="year">2026</span></span>
        </div>
    </footer>

    <!-- ===== НИЖНЯЯ НАВИГАЦИЯ ===== -->
    </div>

    <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

    <script src="assets/js/notifications-page.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var avatarBtn = document.getElementById('avatarBtn');
            var avatarDropdown = document.getElementById('avatarDropdown');
            if (avatarBtn && avatarDropdown) {
                avatarBtn.addEventListener('click', function(event) {
                    event.stopPropagation();
                    avatarDropdown.classList.toggle('active');
                });
                document.addEventListener('click', function(event) {
                    if (!avatarDropdown.contains(event.target) && !avatarBtn.contains(event.target)) {
                        avatarDropdown.classList.remove('active');
                    }
                });
            }

            var themeTrigger = document.getElementById('themeTrigger');
            var themeSubmenu = document.getElementById('themeSubmenu');
            if (themeTrigger && themeSubmenu) {
                themeTrigger.addEventListener('click', function() {
                    themeSubmenu.classList.toggle('open');
                    themeTrigger.classList.toggle('open');
                    document.getElementById('themeArrow').classList.toggle('open');
                });
            }

            var notificationsBtn = document.getElementById('notificationsBtn');
            var notificationsDropdown = document.getElementById('notificationsDropdown');
            if (notificationsBtn && notificationsDropdown) {
                notificationsBtn.addEventListener('click', function(event) {
                    event.stopPropagation();

                    // Телефон: сразу открываем страницу уведомлений, без выпадающего окна
                    if (window.matchMedia('(max-width: 768px)').matches) {
                        if (!/notifications\.php$/.test(window.location.pathname)) {
                            window.location.href = 'notifications.php';
                        }
                        return;
                    }

                    // ПК: выпадающее окно
                    notificationsDropdown.classList.toggle('active');
                    if (notificationsDropdown.classList.contains('active')) {
                        fetch('api/mark_notifications_read.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                            body: 'user_id=<?= $user_id ?>'
                        }).catch(function(error) {
                            console.error('Не удалось отметить уведомления прочитанными:', error);
                        });
                    }
                });
                document.addEventListener('click', function(event) {
                    if (!notificationsDropdown.contains(event.target) && !notificationsBtn.contains(event.target)) {
                        notificationsDropdown.classList.remove('active');
                    }
                });
            }

            var markAllReadBtn = document.getElementById('markAllReadBtn');
            if (markAllReadBtn) {
                markAllReadBtn.addEventListener('click', function(event) {
                    event.stopPropagation();
                    fetch('api/mark_notifications_read.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'user_id=<?= $user_id ?>'
                    }).then(function() {
                        document.querySelectorAll('.notification-item.unread').forEach(function(item) {
                            item.classList.remove('unread');
                            item.classList.add('read');
                        });
                        var badge = document.getElementById('notificationsBadge');
                        if (badge) badge.style.display = 'none';
                        var count = document.getElementById('notificationsCount');
                        if (count) count.textContent = '0 новых';
                        markAllReadBtn.remove();
                    }).catch(function(error) {
                        console.error('Не удалось отметить уведомления прочитанными:', error);
                    });
                });
            }

        });
    </script>
</body>
</html>

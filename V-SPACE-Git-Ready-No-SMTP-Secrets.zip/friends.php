<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
require_once __DIR__ . '/maintenance.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$conn = db_connect();
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$user_id = (int)$_SESSION["user_id"];

$service_account_ids = [];
$canonical_service_account = $conn->query("SELECT id FROM users WHERE username = 'V SPACE' LIMIT 1");
if ($canonical_service_account && $canonical_service_account->num_rows === 0) {
    $rename_legacy_service = $conn->prepare("UPDATE users SET username = 'V SPACE' WHERE username = 'VS SPACE'");
    if (!$rename_legacy_service->execute()) {
        error_log('Failed to rename legacy VS SPACE service account: ' . $rename_legacy_service->error);
    }
    $rename_legacy_service->close();
}
$service_account_result = $conn->query("SELECT id FROM users WHERE username IN ('V SPACE', 'VS SPACE')");
if ($service_account_result) {
    while ($service_account_row = $service_account_result->fetch_assoc()) {
        $service_account_ids[] = (int)$service_account_row['id'];
    }
}

// Функция для добавления уведомления с аватаркой
function addNotificationWithAvatar($conn, $user_id, $type, $message, $link = null, $sender_id = null) {
    $sender_avatar = null;
    if ($sender_id) {
        $stmt = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
        $stmt->bind_param("i", $sender_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $sender_avatar = $row['avatar'];
        }
        $stmt->close();
    }
    
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, sender_id, sender_avatar, type, message, link, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("iissss", $user_id, $sender_id, $sender_avatar, $type, $message, $link);
    return $stmt->execute();
}

// ID (ник) пользователя: общий столбец с edit.php
$check_handle = $conn->query("SHOW COLUMNS FROM users LIKE 'handle'");
if ($check_handle && $check_handle->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN handle VARCHAR(32) DEFAULT NULL, ADD UNIQUE KEY handle (handle)");
}

// Имя/фамилия лежат в user_profiles, статус верификации (2FA) — в users.totp_enabled.
// Если чего-то ещё нет (страницу открыли раньше edit.php/settings.php) — создаём так же, как они.
$conn->query("
    CREATE TABLE IF NOT EXISTS user_profiles (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        first_name VARCHAR(50) DEFAULT NULL,
        last_name VARCHAR(50) DEFAULT NULL,
        birth_date DATE DEFAULT NULL,
        city VARCHAR(255) DEFAULT NULL,
        bio TEXT DEFAULT NULL,
        website_url VARCHAR(2048) DEFAULT NULL,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
foreach (['first_name' => 'VARCHAR(50)', 'last_name' => 'VARCHAR(50)'] as $col => $def) {
    $chk_col = $conn->query("SHOW COLUMNS FROM user_profiles LIKE '" . $col . "'");
    if ($chk_col && $chk_col->num_rows === 0) {
        $conn->query("ALTER TABLE user_profiles ADD COLUMN " . $col . " " . $def . " DEFAULT NULL");
    }
}
$chk_totp = $conn->query("SHOW COLUMNS FROM users LIKE 'totp_enabled'");
if ($chk_totp && $chk_totp->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN totp_enabled TINYINT(1) NOT NULL DEFAULT 0");
}

// Проверяем наличие колонок
$check_avatar_column = $conn->query("SHOW COLUMNS FROM notifications LIKE 'sender_avatar'");
if ($check_avatar_column->num_rows == 0) {
    $conn->query("ALTER TABLE notifications ADD COLUMN sender_avatar VARCHAR(255) NULL DEFAULT NULL AFTER sender_id");
}

$check_column = $conn->query("SHOW COLUMNS FROM notifications LIKE 'sender_id'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE notifications ADD COLUMN sender_id INT(11) NULL DEFAULT NULL AFTER user_id");
    $conn->query("ALTER TABLE notifications ADD INDEX sender_id (sender_id)");
}

// Обработка POST-запросов
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Отправка заявки в друзья
    if (isset($_POST["add_friend"])) {
        $receiver_id = (int)$_POST["receiver_id"];

        if (in_array($user_id, $service_account_ids, true) || in_array($receiver_id, $service_account_ids, true)) {
            $_SESSION['error_message'] = 'Нельзя отправлять заявки служебному аккаунту.';
            header("Location: friends.php?action=add");
            exit;
        }

        if ($receiver_id <= 0 || $receiver_id === $user_id) {
            $_SESSION['error_message'] = 'Нельзя добавить самого себя в друзья.';
        } else {
            $stmt = $conn->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
            $stmt->bind_param("i", $receiver_id);
            $stmt->execute();
            $receiver_exists = (bool)$stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$receiver_exists) {
                $_SESSION['error_message'] = 'Пользователь не найден.';
                header("Location: friends.php?action=add");
                exit;
            }

            $stmt = $conn->prepare("
                SELECT id, sender_id, receiver_id, status
                FROM friend_requests
                WHERE (sender_id = ? AND receiver_id = ?)
                   OR (sender_id = ? AND receiver_id = ?)
                LIMIT 1
            ");
            $stmt->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $existing = $result->fetch_assoc();
            $stmt->close();

            if (!$existing) {
                $stmt = $conn->prepare("
                    INSERT INTO friend_requests (sender_id, receiver_id, status)
                    VALUES (?, ?, 'pending')
                ");
                $stmt->bind_param("ii", $user_id, $receiver_id);
                $created = $stmt->execute();
                $stmt->close();

                if ($created) {
                    addNotificationWithAvatar(
                        $conn,
                        $receiver_id,
                        'friend_request',
                        'отправил(а) вам заявку в друзья',
                        'friends.php?filter=pending',
                        $user_id
                    );
                    $_SESSION['success_message'] = 'Заявка отправлена!';
                } else {
                    $_SESSION['error_message'] = 'Не удалось отправить заявку. Попробуйте ещё раз.';
                }
            } elseif ($existing['status'] === 'accepted') {
                $_SESSION['error_message'] = 'Вы уже друзья с этим пользователем.';
            } elseif (
                $existing['status'] === 'pending'
                && (int)$existing['sender_id'] === $receiver_id
                && (int)$existing['receiver_id'] === $user_id
            ) {
                $stmt = $conn->prepare("
                    UPDATE friend_requests
                    SET status = 'accepted'
                    WHERE id = ? AND status = 'pending'
                ");
                $stmt->bind_param("i", $existing['id']);
                $accepted = $stmt->execute() && $stmt->affected_rows === 1;
                $stmt->close();

                if ($accepted) {
                    addNotificationWithAvatar(
                        $conn,
                        $receiver_id,
                        'friend_accepted',
                        'принял(а) вашу заявку в друзья!',
                        'index.php?user=' . $user_id,
                        $user_id
                    );
                    $_SESSION['success_message'] = 'Заявка принята. Теперь вы друзья!';
                } else {
                    $_SESSION['error_message'] = 'Заявка уже была обработана.';
                }
            } else {
                $_SESSION['error_message'] = 'Заявка уже отправлена. Дождитесь ответа.';
            }
        }
        
        header("Location: friends.php?action=add");
        exit;
    }

    // Принятие заявки
    if (isset($_POST["accept_request"])) {
        $request_id = (int)$_POST["request_id"];

        $stmt = $conn->prepare("
            SELECT sender_id, receiver_id
            FROM friend_requests
            WHERE id = ? AND receiver_id = ? AND status = 'pending'
        ");
        $stmt->bind_param("ii", $request_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $request = $result->fetch_assoc();
        $stmt->close();

        if ($request) {
            $stmt = $conn->prepare("
                UPDATE friend_requests
                SET status = 'accepted'
                WHERE id = ? AND receiver_id = ? AND status = 'pending'
            ");
            $stmt->bind_param("ii", $request_id, $user_id);
            $stmt->execute();
            $stmt->close();

            $stmt_user = $conn->prepare("SELECT username FROM users WHERE id = ?");
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result = $stmt_user->get_result();
            $acceptor = $result->fetch_assoc();
            $stmt_user->close();

            // Уведомление (БЕЗ ИМЕНИ в сообщении)
            addNotificationWithAvatar(
                $conn,
                $request['sender_id'],
                'friend_accepted',
                'принял(а) вашу заявку в друзья!',
                'index.php?user=' . $user_id,
                $user_id
            );

            $_SESSION['success_message'] = 'Заявка принята!';
        }
        
        header("Location: friends.php");
        exit;
    }

    // Отклонение заявки
    if (isset($_POST["reject_request"])) {
        $request_id = (int)$_POST["request_id"];

        $stmt = $conn->prepare("
            SELECT sender_id
            FROM friend_requests
            WHERE id = ? AND receiver_id = ? AND status = 'pending'
        ");
        $stmt->bind_param("ii", $request_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $request = $result->fetch_assoc();
        $stmt->close();

        if ($request) {
            $stmt = $conn->prepare("
                DELETE FROM friend_requests
                WHERE id = ? AND receiver_id = ? AND status = 'pending'
            ");
            $stmt->bind_param("ii", $request_id, $user_id);
            $stmt->execute();
            $stmt->close();

            // Уведомление (БЕЗ ИМЕНИ в сообщении)
            addNotificationWithAvatar(
                $conn,
                $request['sender_id'],
                'friend_removed',
                'отклонил(а) вашу заявку в друзья',
                'index.php?user=' . $user_id,
                $user_id
            );

            $_SESSION['success_message'] = 'Заявка отклонена';
        }
        
        header("Location: friends.php");
        exit;
    }
}

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)
    ? $_GET['theme']
    : (isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true) ? $_COOKIE['theme'] : 'dark');
if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    setcookie('theme', $theme, time() + 365 * 24 * 60 * 60, '/');
}

// Получение текущего пользователя
$stmt = $conn->prepare("SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.handle, u.avatar, u.status, u.is_admin, u.totp_enabled FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$current_user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Данные для общей шапки: уведомления и счётчик модерации.
$notifications = [];
$notif_count = 0;
$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar AS sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC
    LIMIT 30
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS count
    FROM notifications
    WHERE user_id = ? AND is_read = 0
      AND type NOT IN ('message', 'friend_accepted', 'friend_removed')
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
$stmt->close();

$pending_reports_count = 0;
$is_admin = (int)($current_user['is_admin'] ?? 0) === 1;
if ($is_admin) {
    $result = $conn->query("SELECT COUNT(*) AS count FROM reports WHERE status = 'pending'");
    if ($result) {
        $pending_reports_count = (int)($result->fetch_assoc()['count'] ?? 0);
    }
}

// Данные для общей шапки и значка «Сообщения» (как в index.php)
$current_user_data = $current_user ?: [];
$unread_count = shell_unread_messages($conn, $user_id);

// Поиск пользователей
$search = isset($_GET["search"]) ? trim($_GET["search"]) : "";
$search_users = [];

if ($search !== "") {
    $search_norm = ltrim(mb_strtolower($search, 'UTF-8'), '@');
    $like = "%" . $search . "%";
    $stmt = $conn->prepare("
        SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.handle, u.avatar, u.status, u.totp_enabled
        FROM users u
        LEFT JOIN user_profiles up ON up.user_id = u.id
        WHERE u.id != ?
          AND (u.username LIKE ? OR CONCAT_WS(' ', up.first_name, up.last_name) LIKE ? OR u.handle LIKE ? OR CONCAT('id', u.id) = ?)
        ORDER BY username ASC
        LIMIT 30
    ");
    $like_handle = "%" . $search_norm . "%";
    $stmt->bind_param("issss", $user_id, $like, $like, $like_handle, $search_norm);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $search_users[] = $row;
    }
    $stmt->close();
}

// Входящие заявки
$incoming_requests = [];
$stmt = $conn->prepare("
    SELECT
        fr.id AS request_id,
        u.id,
        COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username,
        u.handle,
        u.avatar,
        u.status,
        u.totp_enabled
    FROM friend_requests fr
    INNER JOIN users u ON u.id = fr.sender_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE fr.receiver_id = ? AND fr.status = 'pending'
    ORDER BY fr.created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $incoming_requests[] = $row;
}
$stmt->close();

// Список друзей
$friends = [];
$stmt = $conn->prepare("
    SELECT
        u.id,
        COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username,
        u.handle,
        u.avatar,
        u.status,
        u.totp_enabled
    FROM friend_requests fr
    INNER JOIN users u ON (
        CASE
            WHEN fr.sender_id = ? THEN u.id = fr.receiver_id
            ELSE u.id = fr.sender_id
        END
    )
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE (fr.sender_id = ? OR fr.receiver_id = ?)
      AND fr.status = 'accepted'
    ORDER BY u.username ASC
");
$stmt->bind_param("iii", $user_id, $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $friends[] = $row;
}
$stmt->close();

$friends_count = count($friends);
$online_count = count(array_filter($friends, function ($f) { return $f['status'] === 'online'; }));

// Фильтры
$filter = isset($_GET['filter']) ? $_GET['filter'] : '';

if ($filter === 'online') {
    $friends = array_filter($friends, function($friend) {
        return $friend['status'] === 'online';
    });
}

$show_pending = ($filter === 'pending');

// Вспомогательные функции
if (!function_exists('timeAgo')) {
function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}
}

if (!function_exists('getNotificationTypeName')) {
function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}
}

if (!function_exists('getNotificationIcon')) {
function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}
}

// Значок верификации: у пользователя подключена 2FA
function verifiedBadge(array $u): string {
    if (empty($u['totp_enabled'])) {
        return '';
    }
    return ' <img src="images/verified.svg" alt="Страница верифицирована" title="Страница верифицирована" style="width:16px;height:17px;vertical-align:-3px;margin-left:2px;">';
}

function displayHandle(array $u): string {
    return !empty($u['handle']) ? $u['handle'] : 'id' . (int)($u['id'] ?? 0);
}

function getAvatarLetter($username) {
    return htmlspecialchars(
        mb_substr($username ?: "?", 0, 1, "UTF-8"),
        ENT_QUOTES,
        "UTF-8"
    );
}

function getFriendState($conn, $user_id, $other_id) {
    $stmt = $conn->prepare("
        SELECT sender_id, receiver_id, status
        FROM friend_requests
        WHERE (sender_id = ? AND receiver_id = ?)
           OR (sender_id = ? AND receiver_id = ?)
        LIMIT 1
    ");
    $stmt->bind_param("iiii", $user_id, $other_id, $other_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    if (!$row) return "none";
    if ($row["status"] === "accepted") return "friends";
    if ($row["status"] === "pending" && (int)$row["sender_id"] === $user_id) return "waiting";
    if ($row["status"] === "pending" && (int)$row["receiver_id"] === $user_id) return "incoming";
    
    return "none";
}

function hasAvatar($avatar) {
    if (empty($avatar)) {
        return false;
    }

    if (is_file($avatar)) {
        return true;
    }

    return is_file(__DIR__ . DIRECTORY_SEPARATOR . ltrim($avatar, '/\\'));
}

function getAvatarUrl($avatar): string {
    $avatar = trim((string)$avatar);
    if ($avatar === '') {
        return '';
    }

    if (preg_match('/^(?:https?:)?\/\//i', $avatar)) {
        return $avatar;
    }

    return ltrim(str_replace('\\', '/', $avatar), '/');
}

$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message'], $_SESSION['error_message']);

$active_tab = 'online';
if ($filter === 'pending') $active_tab = 'pending';
elseif ($filter === '') $active_tab = 'all';
if ((isset($_GET['action']) && $_GET['action'] === 'add') || $search !== '') $active_tab = 'add';

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="<?= $theme === 'light' ? '#f0f2f5' : '#313338' ?>">
    <title>Друзья</title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/friends.css">
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
    <style>
        .header-left { display: flex; align-items: center; gap: 20px; }

        /* Телефон: в списке друзей кнопка «Написать» остаётся в одной строке с аватаром и именем, справа */
        @media (max-width: 720px) {
            .user-card.friend-row {
                display: flex !important;
                flex-direction: row !important;
                flex-wrap: nowrap !important;
                align-items: center !important;
                gap: 12px !important;
            }
            .friend-row .user-avatar { flex: none !important; }
            .friend-row .user-info { flex: 1 1 0 !important; min-width: 0 !important; }
            .friend-row .user-info .username {
                display: block;
                max-width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .friend-row .friend-actions-inline {
                flex: none !important;
                width: auto !important;
                margin: 0 !important;
                padding: 0 !important;
                border: 0 !important;
                display: flex !important;
                align-items: center !important;
            }
            .friend-row .friend-actions-inline .friend-button {
                width: auto !important;
                min-height: 38px;
                padding: 8px 16px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                white-space: nowrap;
                font-size: 14px;
                font-weight: 700;
                border-radius: 10px;
                border: 1px solid var(--border-color, rgba(255, 255, 255, .18));
                background: var(--bg-hover, rgba(255, 255, 255, .08));
                color: var(--text-primary, #fff);
                text-decoration: none;
            }
        }
    </style>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= $theme ?>">

    <!-- ===== ВЕРХНЯЯ ПАНЕЛЬ (как в index.php) ===== -->
    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <!-- ===== ОСНОВНОЙ КОНТЕНТ ===== -->
    <div class="friends-page-shell">
    <main class="main">

        <?php if (!empty($success_message)): ?>
            <div class="notification success"><?= htmlspecialchars($success_message) ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="notification error"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <h1 class="page-title">Друзья</h1>
        <p class="page-subtitle">Управляйте списком друзей и заявками</p>

        <!-- Вкладки -->
        <div class="friends-tabs">
            <a href="friends.php" class="friends-tab <?= $active_tab === 'all' ? 'active' : '' ?>"> Все
                <span class="tab-count"><?= (int)$friends_count ?></span>
            </a>
            <a href="friends.php?filter=online" class="friends-tab <?= $active_tab === 'online' ? 'active' : '' ?>"> В сети
                <span class="tab-count"><?= (int)$online_count ?></span>
            </a>
            <a href="friends.php?filter=pending" class="friends-tab <?= $active_tab === 'pending' ? 'active' : '' ?>"> Ожидание
                <?php if (!empty($incoming_requests)): ?>
                    <span class="badge"><?= count($incoming_requests) > 99 ? '99+' : count($incoming_requests) ?></span>
                <?php endif; ?>
            </a>
            <a href="friends.php?action=add" class="friends-tab add-friend <?= $active_tab === 'add' ? 'active' : '' ?>"> Добавить в друзья
            </a>
        </div>

        <!-- Поиск: только на вкладке «Добавить в друзья» -->
        <?php if ($active_tab === 'add'): ?>
            <form method="GET" class="friend-search">
                <input type="hidden" name="action" value="add">
                <input
                    type="text"
                    name="search"
                    value="<?= htmlspecialchars($search) ?>"
                    placeholder="Введите запрос"
                    autocomplete="off"
                >
                <button type="submit">Найти</button>
                <?php if (!empty($search)): ?>
                    <a href="friends.php?action=add" class="friend-button gray">Очистить</a>
                <?php endif; ?>
            </form>
        <?php endif; ?>

        <!-- Входящие заявки (краткий вид) -->
        <?php if (!empty($incoming_requests) && !$show_pending): ?>
            <section class="section">
                <div class="section-title">Заявки в друзья — <?= count($incoming_requests) ?></div>
                <?php foreach ($incoming_requests as $request): ?>
                    <div class="user-card">
                        <div class="user-avatar">
                            <?php if (hasAvatar($request["avatar"])): ?>
                                <img src="<?= htmlspecialchars(getAvatarUrl($request["avatar"]), ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($request["username"], ENT_QUOTES, 'UTF-8') ?>">
                            <?php else: ?>
                                <?= getAvatarLetter($request["username"]) ?>
                            <?php endif; ?>
                            <span class="online-dot offline" data-presence-dot="<?= (int)$request['id'] ?>"></span>
                        </div>
                        <div class="user-info">
                            <a href="<?= (int)$request['id'] ?>" class="username">
                                <?= htmlspecialchars($request["username"]) ?><?= verifiedBadge($request) ?>
                            </a>
                            <div class="user-status">отправил заявку в друзья</div>
                            <div class="user-status offline" data-user-presence="<?= (int)$request['id'] ?>">Не в сети</div>
                        </div>
                        <div class="friend-actions">
                            <form method="POST">
                                <input type="hidden" name="request_id" value="<?= (int)$request["request_id"] ?>">
                                <button class="friend-button green" type="submit" name="accept_request">Принять</button>
                            </form>
                            <form method="POST">
                                <input type="hidden" name="request_id" value="<?= (int)$request["request_id"] ?>">
                                <button class="friend-button red" type="submit" name="reject_request">Отклонить</button>
                            </form>
                            <a href="messages.php?dialog=<?= (int)$request['id'] ?>" class="friend-button">Написать</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <!-- Вкладка "Ожидание" (все заявки) -->
        <?php if ($show_pending): ?>
            <section class="section">
                <div class="section-title">Входящие заявки — <?= count($incoming_requests) ?></div>
                <?php if (empty($incoming_requests)): ?>
                    <div class="empty">
                        <div class="empty-title">Нет входящих заявок</div>
                        <div class="empty-text">Пока никто не отправил вам заявку в друзья.</div>
                    </div>
                <?php else: ?>
                    <?php foreach ($incoming_requests as $request): ?>
                        <div class="user-card">
                            <div class="user-avatar">
                                <?php if (hasAvatar($request["avatar"])): ?>
                                    <img src="<?= htmlspecialchars(getAvatarUrl($request["avatar"]), ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($request["username"], ENT_QUOTES, 'UTF-8') ?>">
                                <?php else: ?>
                                    <?= getAvatarLetter($request["username"]) ?>
                                <?php endif; ?>
                                <span class="online-dot offline" data-presence-dot="<?= (int)$request['id'] ?>"></span>
                            </div>
                            <div class="user-info">
                                <a href="<?= (int)$request['id'] ?>" class="username">
                                    <?= htmlspecialchars($request["username"]) ?><?= verifiedBadge($request) ?>
                                </a>
                                <div class="user-status">отправил заявку в друзья</div>
                                <div class="user-status offline" data-user-presence="<?= (int)$request['id'] ?>">Не в сети</div>
                            </div>
                            <div class="friend-actions">
                                <form method="POST">
                                    <input type="hidden" name="request_id" value="<?= (int)$request["request_id"] ?>">
                                    <button class="friend-button green" type="submit" name="accept_request">Принять</button>
                                </form>
                                <form method="POST">
                                    <input type="hidden" name="request_id" value="<?= (int)$request["request_id"] ?>">
                                    <button class="friend-button red" type="submit" name="reject_request">Отклонить</button>
                                </form>
                                <a href="messages.php?dialog=<?= (int)$request['id'] ?>" class="friend-button">Написать</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <!-- Результаты поиска -->
        <?php if ($search !== ""): ?>
            <section class="section">
                <div class="section-title">Результаты поиска</div>
                <?php if (empty($search_users)): ?>
                    <div class="empty">
                        <div class="empty-title">Пользователь не найден</div>
                        <div class="empty-text">Попробуйте изменить запрос.</div>
                    </div>
                <?php else: ?>
                    <?php foreach ($search_users as $person): ?>
                        <?php
                        $state = getFriendState($conn, $user_id, (int)$person["id"]);
                        ?>
                        <div class="user-card">
                            <div class="user-avatar">
                                <?php if (hasAvatar($person["avatar"])): ?>
                                    <img src="<?= htmlspecialchars(getAvatarUrl($person["avatar"]), ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($person["username"], ENT_QUOTES, 'UTF-8') ?>">
                                <?php else: ?>
                                    <?= getAvatarLetter($person["username"]) ?>
                                <?php endif; ?>
                                <span class="online-dot offline" data-presence-dot="<?= (int)$person['id'] ?>"></span>
                            </div>
                            <div class="user-info">
                                <a href="<?= (int)$person['id'] ?>" class="username">
                                    <?= htmlspecialchars($person["username"]) ?><?= verifiedBadge($person) ?>
                                </a>
                                <div class="user-status offline" data-user-presence="<?= (int)$person['id'] ?>">
                                    Не в сети
                                </div>
                            </div>
                            <div class="friend-actions">
                                <?php if (!in_array((int)$person["id"], $service_account_ids, true) && $state === "none"): ?>
                                    <form method="POST">
                                        <input type="hidden" name="receiver_id" value="<?= (int)$person["id"] ?>">
                                        <button type="submit" name="add_friend" class="friend-button">Добавить</button>
                                    </form>
                                <?php elseif (!in_array((int)$person["id"], $service_account_ids, true) && $state === "waiting"): ?>
                                    <button type="button" class="friend-button gray" disabled>Заявка отправлена</button>
                                <?php elseif (!in_array((int)$person["id"], $service_account_ids, true) && $state === "incoming"): ?>
                                    <button type="button" class="friend-button gray" disabled>Входящая</button>
                                <?php elseif (!in_array((int)$person["id"], $service_account_ids, true) && $state === "friends"): ?>
                                    <button type="button" class="friend-button green" disabled>Друзья</button>
                                <?php endif; ?>
                                <a href="messages.php?dialog=<?= (int)$person['id'] ?>" class="friend-button">Написать</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <!-- Список друзей -->
        <?php if (!$show_pending): ?>
            <section class="section">
                <div class="section-title">Мои друзья — <?= count($friends) ?></div>
                <?php if (empty($friends)): ?>
                    <div class="empty">
                        <div class="empty-title">У вас пока нет друзей</div>
                        <div class="empty-text">Найдите пользователя выше и отправьте ему заявку.</div>
                    </div>
                <?php else: ?>
                    <?php foreach ($friends as $friend): ?>
                        <div class="user-card friend-row">
                            <div class="user-avatar">
                                <?php if (hasAvatar($friend["avatar"])): ?>
                                    <img src="<?= htmlspecialchars(getAvatarUrl($friend["avatar"]), ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($friend["username"], ENT_QUOTES, 'UTF-8') ?>">
                                <?php else: ?>
                                    <?= getAvatarLetter($friend["username"]) ?>
                                <?php endif; ?>
                                <span class="online-dot offline" data-presence-dot="<?= (int)$friend['id'] ?>"></span>
                            </div>
                            <div class="user-info">
                                <a href="<?= (int)$friend['id'] ?>" class="username">
                                    <?= htmlspecialchars($friend["username"]) ?><?= verifiedBadge($friend) ?>
                                </a>
                                <div class="user-status offline" data-user-presence="<?= (int)$friend['id'] ?>">
                                    Не в сети
                                </div>
                            </div>
                            <div class="friend-actions friend-actions-inline">
                                <a href="messages.php?dialog=<?= (int)$friend["id"] ?>" class="friend-button">Написать</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
        <?php endif; ?>

    </main>

    <footer class="site-footer">
        <div class="footer-content">
            <span class="footer-copy">&copy; <span class="year">2026</span></span>
        </div>
    </footer>

    <!-- ===== НИЖНЯЯ НАВИГАЦИЯ ===== -->
    </div>

    <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

    <script src="assets/js/friends.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var avatarBtn = document.getElementById('avatarBtn');
            var avatarDropdown = document.getElementById('avatarDropdown');
            if (avatarBtn && avatarDropdown) {
                avatarBtn.addEventListener('click', function(event) {
                    event.stopPropagation();
                    avatarDropdown.classList.toggle('active');
                });
                document.addEventListener('click', function(event) {
                    if (!avatarDropdown.contains(event.target) && !avatarBtn.contains(event.target)) {
                        avatarDropdown.classList.remove('active');
                    }
                });
            }

            var themeTrigger = document.getElementById('themeTrigger');
            var themeSubmenu = document.getElementById('themeSubmenu');
            if (themeTrigger && themeSubmenu) {
                themeTrigger.addEventListener('click', function() {
                    themeSubmenu.classList.toggle('open');
                    themeTrigger.classList.toggle('open');
                    document.getElementById('themeArrow').classList.toggle('open');
                });
            }

            var notificationsBtn = document.getElementById('notificationsBtn');
            var notificationsDropdown = document.getElementById('notificationsDropdown');
            if (notificationsBtn && notificationsDropdown) {
                notificationsBtn.addEventListener('click', function(event) {
                    event.stopPropagation();
                    notificationsDropdown.classList.toggle('active');
                    if (notificationsDropdown.classList.contains('active')) {
                        fetch('api/mark_notifications_read.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                            body: 'user_id=<?= $user_id ?>'
                        }).catch(function(error) {
                            console.error('Не удалось отметить уведомления прочитанными:', error);
                        });
                    }
                });
                document.addEventListener('click', function(event) {
                    if (!notificationsDropdown.contains(event.target) && !notificationsBtn.contains(event.target)) {
                        notificationsDropdown.classList.remove('active');
                    }
                });
            }

            var markAllReadBtn = document.getElementById('markAllReadBtn');
            if (markAllReadBtn) {
                markAllReadBtn.addEventListener('click', function(event) {
                    event.stopPropagation();
                    fetch('api/mark_notifications_read.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'user_id=<?= $user_id ?>'
                    }).then(function() {
                        document.querySelectorAll('.notification-item.unread').forEach(function(item) {
                            item.classList.remove('unread');
                            item.classList.add('read');
                        });
                        var badge = document.getElementById('notificationsBadge');
                        if (badge) badge.style.display = 'none';
                        var count = document.getElementById('notificationsCount');
                        if (count) count.textContent = '0 новых';
                        markAllReadBtn.remove();
                    }).catch(function(error) {
                        console.error('Не удалось отметить уведомления прочитанными:', error);
                    });
                });
            }

        });
    </script>
</body>
</html>
<?php
// ============================================================
// ПАТЧ ДЛЯ messages.php: запись о звонке в переписку (message_type = 'call')
// Три вставки. Номера строк — по вашему файлу (4060 строк).
// ============================================================


// ------------------------------------------------------------
// ВСТАВКА 1. Раздел 3 (подключение к БД): после CREATE TABLE message_hidden (~строка 184).
// Таблица нужна только для защиты от дублей: один call_id = одна запись в переписке.
// ------------------------------------------------------------
    $conn->query("
        CREATE TABLE IF NOT EXISTS call_records (
            call_id VARCHAR(64) NOT NULL,
            message_id INT(11) NULL DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (call_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");


// ------------------------------------------------------------
// ВСТАВКА 2. API-роутер: перед `if ($api === 'mark_read' ...` (~строка 1661).
//
// POST messages.php?api=call_log
//   csrf_token  — как у остальных POST
//   call_id     — уникальный id звонка (A-Za-z0-9_-, 8..64 символа), один и тот же у обеих сторон
//   caller_id   — id того, кто звонил (это либо вы, либо собеседник)
//   peer_id     — id второго участника
//   status      — answered | missed | declined | busy
//   kind        — audio | video
//   duration    — секунды разговора (учитывается только для answered)
//
// Строка пишется от имени звонившего (sender_id = caller_id): ровно это ждёт рендер,
// где is_caller = «сообщение моё». Повторный вызов с тем же call_id ничего не создаёт.
// ------------------------------------------------------------
    if ($api === 'call_log' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        apiRequireCsrf();

        $call_id   = (string)($_POST['call_id'] ?? '');
        $caller_id = (int)($_POST['caller_id'] ?? 0);
        $peer_id   = (int)($_POST['peer_id'] ?? 0);
        $status    = (string)($_POST['status'] ?? '');
        $kind      = (string)($_POST['kind'] ?? 'audio');
        $duration  = (int)($_POST['duration'] ?? 0);

        if (!preg_match('/^[A-Za-z0-9_-]{8,64}$/', $call_id)
            || !in_array($status, ['answered', 'missed', 'declined', 'busy'], true)
            || !in_array($kind, ['audio', 'video'], true)) {
            apiResponse(['success' => false, 'error' => 'invalid_call'], 400);
        }

        // Писать может только участник звонка; звонившим считается caller_id
        $other_id = $caller_id === $user_id ? $peer_id : ($peer_id === $user_id ? $caller_id : 0);
        if ($other_id <= 0 || $other_id === $user_id || !in_array($user_id, [$caller_id, $peer_id], true)
            || !apiUserExists($conn, $other_id)) {
            apiResponse(['success' => false, 'error' => 'invalid_participants'], 400);
        }
        $receiver_id = $caller_id === $user_id ? $peer_id : $user_id;

        $duration  = $status === 'answered' ? max(0, min(86400, $duration)) : 0;
        $call_text = '[CALL:' . $status . ':' . $kind . ':' . $duration . ']';
        // Не шифруем: текст служебный, а рендер (callMessageText) разбирает его регуляркой
        // и сам подставляет имена. is_encrypted = 0 → apiGetMessages отдаёт строку как есть.
        // Отвеченный звонок сразу считаем прочитанным, чтобы не плодить «1 непрочитанное».
        $is_read = $status === 'answered' ? 1 : 0;

        $conn->begin_transaction();
        try {
            $guard = $conn->prepare('INSERT IGNORE INTO call_records (call_id) VALUES (?)');
            if (!$guard) throw new RuntimeException('Prepare failed: ' . $conn->error);
            $guard->bind_param('s', $call_id);
            $guard->execute();
            $is_new = $guard->affected_rows === 1;
            $guard->close();

            if (!$is_new) {            // вторая сторона (или повторный запрос) — дубль не создаём
                $conn->commit();
                apiResponse(['success' => true, 'duplicate' => true]);
            }

            $insert_sql = "INSERT INTO messages
                (sender_id, receiver_id, message, message_type, is_encrypted, is_read, is_favorite, created_at)
                VALUES (?, ?, ?, 'call', 0, ?, 0, NOW())";
            $stmt = $conn->prepare($insert_sql);
            if (!$stmt) throw new RuntimeException('Prepare failed: ' . $conn->error);
            safeBind($stmt, $insert_sql, [$caller_id, $receiver_id, $call_text, $is_read], 'iisi');
            $stmt->execute();
            $new_id = (int)$stmt->insert_id;
            $stmt->close();

            $upd = $conn->prepare('UPDATE call_records SET message_id = ? WHERE call_id = ?');
            if ($upd) {
                $upd->bind_param('is', $new_id, $call_id);
                $upd->execute();
                $upd->close();
            }

            // Пропущенный звонок — обычное уведомление получателю (если диалог не заглушён)
            if ($status !== 'answered' && !isDialogMuted($conn, $receiver_id, $caller_id)) {
                $notif_sql = "INSERT INTO notifications (user_id, type, message, link, is_read) VALUES (?, 'message', ?, ?, 0)";
                $notif_stmt = $conn->prepare($notif_sql);
                if ($notif_stmt) {
                    $caller_name = $caller_id === $user_id ? (string)($_SESSION['username'] ?? 'Пользователь') : 'Собеседник';
                    $notice = 'Пропущенный ' . ($kind === 'video' ? 'видеозвонок' : 'звонок') . ' от ' . $caller_name;
                    $link   = 'messages.php?dialog=' . $caller_id;
                    safeBind($notif_stmt, $notif_sql, [$receiver_id, $notice, $link], 'iss');
                    $notif_stmt->execute();
                    $notif_stmt->close();
                }
            }

            $conn->commit();
            apiResponse(['success' => true, 'id' => $new_id]);
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('call_log failed: ' . $e->getMessage());
            apiResponse(['success' => false, 'error' => 'server'], 500);
        }
    }


// ------------------------------------------------------------
// ВСТАВКА 3 (рекомендуется). apiGetDialogs(): в цикле while, после блока
// `if (!empty($row['last_deleted_at'])) { ... }` (~строка 1207).
// Без неё JSON-список диалогов (?api=dialogs) отдаёт в превью сырую строку [CALL:...].
// Серверный рендер страницы уже использует formatMessagePreview, а JSON — нет.
// ------------------------------------------------------------
        if (($row['last_message_type'] ?? '') === 'call') {
            $row['last_message'] = formatMessagePreview(
                (string)$row['last_message'],
                'call',
                (int)$row['last_message_sender_id'] === $user_id,
                (string)$row['username']
            );
        }

<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
header('Content-Type: application/json');

if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => true, 'count' => 0]);
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$conn = db_connect();
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Ошибка БД', 'count' => 0]);
    exit;
}

$conn->set_charset("utf8mb4");

// Проверяем, является ли пользователь админом
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user || !$user['is_admin']) {
    echo json_encode(['success' => true, 'count' => 0]);
    $conn->close();
    exit;
}

// Проверяем, существует ли таблица reports
$tableCheck = $conn->query("SHOW TABLES LIKE 'reports'");
if ($tableCheck->num_rows === 0) {
    echo json_encode(['success' => true, 'count' => 0]);
    $conn->close();
    exit;
}

// Считаем количество непросмотренных жалоб
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM reports WHERE status = 'pending'");
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

$conn->close();

echo json_encode([
    'success' => true,
    'count' => (int)($row['count'] ?? 0)
]);
?>
<?php

require_once __DIR__ . '/includes/db.php';
$conn = db_connect(null, null, false);

if ($conn->connect_error) {
    die("Ошибка подключения к MySQL: " . $conn->connect_error);
}

$setupDatabase = (string)env('DB_SETUP_NAME', 'playerchat');
if (!preg_match('/^[A-Za-z0-9_]+$/', $setupDatabase)) {
    die("Некорректное имя базы данных в DB_SETUP_NAME.");
}

/* Создание базы */
$conn->query("
    CREATE DATABASE IF NOT EXISTS `$setupDatabase`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci
");


/* Выбор базы */
$conn->select_db($setupDatabase);


/* Кодировка */
$conn->set_charset("utf8mb4");


/* Таблица сообщений */
$conn->query("
    CREATE TABLE IF NOT EXISTS messages (
        id INT NOT NULL AUTO_INCREMENT,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        message TEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_unicode_ci
");

?>
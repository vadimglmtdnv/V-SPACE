<?php
/**
 * error.php — универсальная страница ошибок (400, 401, 403, 404, 405, 408, 410, 413, 429, 500, 502, 503, 504)
 *
 * Подключение через .htaccess:  ErrorDocument 404 /error.php  (см. файл htaccess-errors.txt)
 * Проверка вручную:             error.php?code=404, error.php?code=500 ...
 * Подключение из PHP-кода:      $error_code = 404;            // обязательно
 *                               $error_title = '...';         // необязательно: свой заголовок
 *                               $error_text  = '...';         // необязательно: свой текст
 *                               $error_detail = $e->getMessage(); // необязательно: деталь, видна только при заходе с localhost
 *                               $error_season = 'summer';     // необязательно: принудительный сезон (spring | summer | autumn | winter)
 *                               require __DIR__ . '/error.php'; exit;
 * Сезон выбирается сам по месяцу (зима: дек–фев, весна: мар–май, лето: июн–авг, осень: сен–ноя);
 * проверить вручную: error.php?code=404&season=winter
 */

// ----- Определяем код ошибки -----
$errors = [
    400 => ['icon' => 'warn',  'tone' => 'warn', 'title' => 'Неверный запрос',
            'text' => 'Сервер не смог понять запрос. Проверьте адрес или повторите действие.'],
    401 => ['icon' => 'lock',  'tone' => 'gold', 'title' => 'Нужна авторизация',
            'text' => 'Эта часть станции доступна только экипажу. Войдите в аккаунт и попробуйте снова.'],
    403 => ['icon' => 'lock',  'tone' => 'gold', 'title' => 'Доступ запрещён',
            'text' => 'У вас нет допуска в этот отсек. Если считаете, что это ошибка — напишите администратору.'],
    404 => ['icon' => 'planet', 'tone' => 'blue', 'title' => 'Страница потерялась в космосе',
            'text' => 'Мы облетели всю галактику, но такой страницы не нашли. Возможно, она удалена или адрес введён с ошибкой.'],
    405 => ['icon' => 'warn',  'tone' => 'warn', 'title' => 'Метод не разрешён',
            'text' => 'Этот адрес не принимает такой тип запроса.'],
    408 => ['icon' => 'clock', 'tone' => 'warn', 'title' => 'Время ожидания истекло',
            'text' => 'Связь с сервером прервалась. Попробуйте ещё раз через пару секунд.'],
    410 => ['icon' => 'planet', 'tone' => 'blue', 'title' => 'Страница удалена',
            'text' => 'Эта страница была удалена навсегда и больше не вернётся.'],
    413 => ['icon' => 'warn',  'tone' => 'warn', 'title' => 'Файл слишком большой',
            'text' => 'Размер отправленных данных превышает допустимый. Выберите файл поменьше.'],
    429 => ['icon' => 'clock', 'tone' => 'warn', 'title' => 'Слишком много запросов',
            'text' => 'Вы двигаетесь слишком быстро. Подождите немного и повторите попытку.'],
    500 => ['icon' => 'bolt',  'tone' => 'bad',  'title' => 'Внутренняя ошибка сервера',
            'text' => 'На станции что-то пошло не так. Мы уже знаем о проблеме и разбираемся.'],
    502 => ['icon' => 'bolt',  'tone' => 'bad',  'title' => 'Плохой шлюз',
            'text' => 'Сервер получил некорректный ответ от соседней системы. Попробуйте позже.'],
    503 => ['icon' => 'tools', 'tone' => 'bad',  'title' => 'Сервис временно недоступен',
            'text' => 'На сайте идут технические работы или сервер перегружен. Скоро всё заработает.'],
    504 => ['icon' => 'clock', 'tone' => 'bad',  'title' => 'Шлюз не отвечает',
            'text' => 'Сервер слишком долго не отвечал. Попробуйте обновить страницу чуть позже.'],
];

$code = 404;
if (isset($error_code) && is_numeric($error_code)) {            // подключено из index.php / login.php / profile.php / news.php
    $code = (int)$error_code;
} elseif (isset($_GET['code']) && ctype_digit((string)$_GET['code'])) {
    $code = (int)$_GET['code'];
} elseif (!empty($_SERVER['REDIRECT_STATUS']) && (int)$_SERVER['REDIRECT_STATUS'] >= 400) {
    $code = (int)$_SERVER['REDIRECT_STATUS'];
}
if (!isset($errors[$code])) {
    $code = 404;
}
$err = $errors[$code];
if (!empty($error_title)) { $err['title'] = (string)$error_title; }
if (!empty($error_text))  { $err['text']  = (string)$error_text; }

// Папка сайта: нужна, чтобы ссылки и логотип работали и на /playerchat/<номер>, и при подключении из любого файла
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$base = preg_replace('#/api$#', '', $base);   // если ошибка вылетела из api/messages.php

// Техническая деталь ошибки (например, текст ошибки MySQL) — только при заходе с этого же компьютера
$detail = '';
if (!empty($error_detail) && in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) {
    $detail = (string)$error_detail;
}

http_response_code($code);
// Сезон оформления страницы ошибки: spring | summer | autumn | winter (меняется каждые 3 месяца)
// Приоритет: $error_season из PHP-кода → ?season=... (для проверки) → по текущему месяцу
$seasons = ['spring', 'summer', 'autumn', 'winter'];
if (isset($error_season) && in_array($error_season, $seasons, true)) {
    $season = $error_season;
} elseif (isset($_GET['season']) && in_array($_GET['season'], $seasons, true)) {
    $season = $_GET['season'];
} else {
    $month  = (int)date('n');
    $season = ($month === 12 || $month <= 2) ? 'winter'
            : (($month <= 5) ? 'spring'
            : (($month <= 8) ? 'summer' : 'autumn'));
}

if ($code === 503) {
    header('Retry-After: 120');
}
header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; style-src 'self' 'unsafe-inline';");

// ----- Тема оформления (та же cookie, что и на index.php) -----
$allowed_themes = ['dark', 'light', 'system'];
$theme = (isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true))
    ? $_COOKIE['theme']
    : 'dark';

// ----- Что запрашивали (только для 404/410, экранируется) -----
$path = '';
if (in_array($code, [404, 410], true)) {
    $path = (string)(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?? '');
    if (in_array(basename($path), ['error.php', 'index.php', 'profile.php', 'news.php'], true)) {
        $path = '';
    }
    if (mb_strlen($path) > 80) {
        $path = mb_substr($path, 0, 77) . '…';
    }
}

$canRetry = $code >= 500 || in_array($code, [408, 429], true);
// Необязательная кнопка «Вернуться в чат»: $error_back_url задаётся из PHP-кода (messages.php) и только относительный путь
$backUrl = '';
if (!empty($error_back_url) && preg_match('#^[A-Za-z0-9_./?=&-]+$#', (string)$error_back_url)) {
    $backUrl = (string)$error_back_url;
}
$digits   = str_split((string)$code);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= $code ?> — <?= htmlspecialchars($err['title']) ?></title>
    <style>
        /* цвета темы зарегистрированы как <color>, поэтому при смене темы они плавно перетекают */
        @property --bg      { syntax: '<color>';  inherits: true; initial-value: #313338; }
        @property --bg-deep { syntax: '<color>';  inherits: true; initial-value: #1e1f22; }
        @property --panel   { syntax: '<color>';  inherits: true; initial-value: #2b2d31; }
        @property --line    { syntax: '<color>';  inherits: true; initial-value: #3f4147; }
        @property --text    { syntax: '<color>';  inherits: true; initial-value: #f2f3f5; }
        @property --muted   { syntax: '<color>';  inherits: true; initial-value: #949ba4; }
        @property --gold    { syntax: '<color>';  inherits: true; initial-value: #f0b232; }
        @property --warn    { syntax: '<color>';  inherits: true; initial-value: #f0b232; }
        @property --glow-a  { syntax: '<number>'; inherits: true; initial-value: .35; }

        :root {
            --bg: #313338; --bg-deep: #1e1f22; --panel: #2b2d31; --line: #3f4147;
            --text: #f2f3f5; --muted: #949ba4; --accent: #5865f2; --accent-h: #4752c4;
            --star: 255, 255, 255; --glow-a: .35;
            --blue: #5865f2; --gold: #f0b232; --warn: #f0b232; --bad: #f23f42;
        }
        body[data-theme="light"] {
            --bg: #f2f3f5; --bg-deep: #e3e5e8; --panel: #ffffff; --line: #d4d7dc;
            --text: #060607; --muted: #5c5e66; --star: 88, 101, 242; --glow-a: .18;
            --gold: #b7791f; --warn: #b7791f;
        }
        @media (prefers-color-scheme: light) {
            body[data-theme="system"] {
                --bg: #f2f3f5; --bg-deep: #e3e5e8; --panel: #ffffff; --line: #d4d7dc;
                --text: #060607; --muted: #5c5e66; --star: 88, 101, 242; --glow-a: .18;
                --gold: #b7791f; --warn: #b7791f;
            }
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            transition: --bg .5s ease, --bg-deep .5s ease, --panel .5s ease, --line .5s ease, --text .5s ease,
                        --muted .5s ease, --gold .5s ease, --warn .5s ease, --glow-a .5s ease;
            margin: 0;
            background:
                radial-gradient(1200px 600px at 50% -10%, rgba(88, 101, 242, var(--glow-a)), transparent 60%),
                radial-gradient(800px 500px at 90% 110%, rgba(240, 178, 50, calc(var(--glow-a) * .35)), transparent 60%),
                var(--bg);
            color: var(--text);
            font-family: 'Segoe UI', system-ui, -apple-system, Arial, sans-serif;
            line-height: 1.5;
            overflow-x: hidden;
        }

        /* тон ошибки задаёт главный цвет страницы */
        .tone-blue { --c: var(--blue); }
        .tone-gold { --c: var(--gold); }
        .tone-warn { --c: var(--warn); }
        .tone-bad  { --c: var(--bad); }

        #stars { position: fixed; inset: 0; width: 100%; height: 100%; z-index: 0; pointer-events: none; }

        .wrap {
            position: relative; z-index: 1;
            min-height: 100%;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            padding: 112px 18px 28px;   /* место под большой логотип сверху */
        }

        .brand {
            position: absolute; top: 22px; left: 50%; transform: translateX(-50%);
            display: flex; align-items: center; gap: 10px;
            color: var(--text); text-decoration: none; opacity: 1; transition: .2s;
        }
        .brand:hover { transform: translateX(-50%) translateY(-2px); }
        .brand img {
            height: 76px; width: auto; max-width: 80vw; display: block; object-fit: contain;   /* логотип-надпись широкий, поэтому ширина авто */
            filter: drop-shadow(0 4px 14px rgba(88, 101, 242, .45));
        }

        .card {
            position: relative;
            width: 100%; max-width: 620px;
            background: color-mix(in srgb, var(--panel) 86%, transparent);
            -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px);
            border: 1px solid var(--line);
            border-radius: 22px;
            padding: 34px 32px 28px;
            text-align: center;
            box-shadow: 0 18px 60px rgba(0, 0, 0, .35), 0 0 0 1px rgba(255, 255, 255, .02) inset;
            animation: rise .6s cubic-bezier(.2, .8, .2, 1) both;
        }
        .card::before {                       /* цветная полоса сверху */
            content: ""; position: absolute; left: 28px; right: 28px; top: -1px; height: 3px;
            border-radius: 0 0 6px 6px;
            background: linear-gradient(90deg, transparent, var(--c), transparent);
            filter: drop-shadow(0 0 8px var(--c));
        }

        /* ----- иллюстрация ----- */
        .art { height: 150px; display: flex; align-items: center; justify-content: center; margin-bottom: 4px; }
        .art svg { overflow: visible; }
        .float  { animation: float 5s ease-in-out infinite; transform-origin: center; }
        .orbit  { animation: spin 14s linear infinite; transform-origin: 90px 75px; }
        .twinkle{ animation: twinkle 2.4s ease-in-out infinite; }
        .shake  { animation: shake 3.2s ease-in-out infinite; transform-origin: 90px 75px; }

        /* ----- цифры кода ----- */
        .code {
            display: flex; justify-content: center; gap: 6px;
            font-size: clamp(76px, 18vw, 124px); font-weight: 900; line-height: 1;
            letter-spacing: -.02em; margin: 2px 0 6px;
            user-select: none;
        }
        .code .d {
            display: inline-block; position: relative;
            background: linear-gradient(180deg, var(--text) 0%, var(--c) 120%);
            -webkit-background-clip: text; background-clip: text; color: transparent;
            --glow: color-mix(in srgb, var(--c) 45%, transparent);
            filter: drop-shadow(0 6px calc(4px + 20px * var(--lamp, 1)) var(--glow)) brightness(calc(.7 + .35 * var(--lamp, 1)));
            opacity: calc(.04 + .96 * var(--lamp, 1));          /* яркость лампы выставляет JS (плавное моргание + звук) */
            animation: bob 3.6s ease-in-out infinite;
        }
        .code .d:nth-child(2) { animation-delay: -1.2s; }
        .code .d:nth-child(3) { animation-delay: -2.4s; }
        .code .d::before, .code .d::after {   /* лёгкий глитч */
            content: attr(data-d); position: absolute; inset: 0; background: none; color: var(--c);
            -webkit-background-clip: initial; background-clip: initial;
            opacity: 0; mix-blend-mode: screen;
        }
        .code .d::before { opacity: .7; transform: translate(-3px, 0); clip-path: inset(0 0 50% 0); }
        .code .d::after  { opacity: .7; transform: translate(3px, 0);  clip-path: inset(50% 0 0 0); }

        h1 { margin: 0 0 8px; font-size: clamp(20px, 4.6vw, 26px); font-weight: 800; }
        .lead { margin: 0 auto 18px; max-width: 460px; color: var(--muted); font-size: 15px; }

        .path {
            display: inline-block; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
            margin: 0 0 20px; padding: 7px 14px; border-radius: 10px;
            background: var(--bg-deep); border: 1px solid var(--line);
            font: 12.5px/1.4 ui-monospace, 'Cascadia Code', Consolas, monospace; color: var(--muted);
        }
        .path b { color: var(--c); font-weight: 600; margin-right: 6px; }
        .detail {
            max-width: 100%; margin: 0 0 20px; padding: 8px 14px; border-radius: 10px; text-align: left;
            background: var(--bg-deep); border: 1px dashed var(--line); word-break: break-all;
            font: 12px/1.45 ui-monospace, 'Cascadia Code', Consolas, monospace; color: var(--muted);
        }
        .detail b { color: var(--c); font-weight: 600; margin-right: 6px; }

        .actions { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
        .btn {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 11px 24px; border-radius: 10px; border: 1px solid transparent;
            font: 600 14px 'Segoe UI', system-ui, Arial, sans-serif; text-decoration: none; cursor: pointer;
            transition: transform .15s, background .15s, box-shadow .15s, border-color .15s;
        }
        .btn svg { width: 16px; height: 16px; flex: none; }
        .btn-primary { background: var(--accent); color: #fff; box-shadow: 0 6px 18px rgba(88, 101, 242, .35); }
        .btn-primary:hover { background: var(--accent-h); transform: translateY(-2px); box-shadow: 0 10px 24px rgba(88, 101, 242, .45); }
        .btn-ghost { background: transparent; color: var(--text); border-color: var(--line); }
        .btn-ghost:hover { background: var(--bg-deep); border-color: var(--muted); transform: translateY(-2px); }
        .btn:focus-visible { outline: 2px solid var(--accent); outline-offset: 3px; }

        .meta {
            margin-top: 22px; padding-top: 16px; border-top: 1px dashed var(--line);
            display: flex; flex-wrap: wrap; gap: 8px 18px; justify-content: center;
            font-size: 12px; color: var(--muted);
        }
        .meta code { font-family: ui-monospace, Consolas, monospace; color: var(--text); }
        .dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: var(--c);
               margin-right: 6px; box-shadow: 0 0 8px var(--c); animation: pulse 1.8s ease-in-out infinite; }


        /* ----- анимации ----- */
        .theme-sw {
            position: fixed; top: 16px; left: 16px; z-index: 5;
            display: flex; gap: 2px; padding: 3px; border-radius: 999px;
            background: color-mix(in srgb, var(--panel) 80%, transparent);
            border: 1px solid var(--line);
        }
        .theme-sw button {
            width: 32px; height: 32px; padding: 0; border: 0; border-radius: 50%; cursor: pointer;
            display: grid; place-items: center; background: transparent; color: var(--muted); transition: .15s;
        }
        .theme-sw button svg { width: 17px; height: 17px; }
        .theme-sw button:hover { color: var(--text); background: color-mix(in srgb, var(--text) 10%, transparent); }
        .theme-sw button.active { background: var(--accent); color: #fff; }
        .theme-sw button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
        .sound-ctl { position: fixed; top: 16px; right: 16px; z-index: 5; }
        .vol-pop {
            position: absolute; top: 46px; left: 50%; transform: translate(-50%, -6px);
            display: flex; flex-direction: column; align-items: center; gap: 8px;
            padding: 12px 8px 10px; border-radius: 20px;
            background: color-mix(in srgb, var(--panel) 92%, transparent);
            -webkit-backdrop-filter: blur(10px); backdrop-filter: blur(10px);
            border: 1px solid var(--line); box-shadow: 0 8px 24px rgba(0, 0, 0, .3);
            opacity: 0; pointer-events: none; transition: opacity .15s, transform .15s;
        }
        .vol-pop::before { content: ""; position: absolute; top: -10px; left: 0; right: 0; height: 10px; }   /* мостик, чтобы панель не пропадала при наведении */
        .sound-ctl:hover .vol-pop, .sound-ctl:focus-within .vol-pop { opacity: 1; pointer-events: auto; transform: translate(-50%, 0); }
        .vol {
            writing-mode: vertical-lr; direction: rtl;      /* вертикальный ползунок: минимум внизу, максимум вверху */
            width: 22px; height: 100px; margin: 0; cursor: pointer; accent-color: var(--accent);
        }
        .vol-val { font: 600 11px/1 ui-monospace, Consolas, monospace; color: var(--muted); min-width: 30px; text-align: center; }
        #stars { transition: opacity .6s ease; }
        body[data-theme="light"] #stars { opacity: 0; }             /* в светлой теме звёзды плавно гаснут */
        @media (prefers-color-scheme: light) { body[data-theme="system"] #stars { opacity: 0; } }
        .sound-btn {
            position: relative;
            width: 40px; height: 40px; border-radius: 50%; padding: 0; cursor: pointer;
            display: grid; place-items: center;
            background: rgba(255,255,255,.06); color: var(--muted);
            border: 1px solid rgba(255,255,255,.12); transition: .15s;
        }
        .sound-btn:hover { color: var(--text); background: rgba(255,255,255,.12); }
        .sound-btn svg { width: 20px; height: 20px; }
        .sound-btn .on { display: none; }
        .sound-btn.is-on .on { display: block; }
        .sound-btn.is-on .off { display: none; }
        .sound-btn.is-on { color: var(--c); }

        @keyframes rise    { from { opacity: 0; transform: translateY(18px) scale(.98); } to { opacity: 1; transform: none; } }
        @keyframes float   { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        @keyframes spin    { to { transform: rotate(360deg); } }
        @keyframes twinkle { 0%, 100% { opacity: .25; } 50% { opacity: 1; } }
        @keyframes bob     { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
        @keyframes pulse   { 0%, 100% { opacity: 1; } 50% { opacity: .35; } }

        @keyframes shake   { 0%, 86%, 100% { transform: rotate(0); } 89% { transform: rotate(-4deg); } 92% { transform: rotate(4deg); } 95% { transform: rotate(-2deg); } }

        @media (max-width: 520px) {
            .card { padding: 28px 18px 22px; border-radius: 18px; }
            .btn { width: 100%; justify-content: center; }
            .brand { top: 14px; }
            .wrap { padding-top: 84px; }
            .brand img { height: 54px; }
        }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { animation: none !important; transition: none !important; }
        }
    </style>
</head>
<body data-theme="<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>">
    <canvas id="stars" aria-hidden="true"></canvas>

    <div class="theme-sw" id="themeSw" role="group" aria-label="Тема оформления">
        <button type="button" data-theme="dark" class="<?= $theme === 'dark' ? 'active' : '' ?>" title="Тёмная" aria-label="Тёмная тема">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
        </button>
        <button type="button" data-theme="light" class="<?= $theme === 'light' ? 'active' : '' ?>" title="Светлая" aria-label="Светлая тема">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
        </button>
        <button type="button" data-theme="system" class="<?= $theme === 'system' ? 'active' : '' ?>" title="Системная" aria-label="Системная тема">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>
        </button>
    </div>

    <div class="sound-ctl" id="soundCtl">
        <button type="button" class="sound-btn" id="soundBtn" aria-label="Звук" title="Звук">
            <svg class="off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M23 9l-6 6M17 9l6 6"/></svg>
            <svg class="on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/></svg>
        </button>
        <div class="vol-pop">
            <input type="range" class="vol" id="volSlider" min="0" max="100" step="1" value="60" aria-label="Громкость" title="Громкость">
            <span class="vol-val" id="volVal">60%</span>
        </div>
    </div>

    <div class="wrap tone-<?= $err['tone'] ?>">
        <a class="brand" href="<?= htmlspecialchars($base, ENT_QUOTES, 'UTF-8') ?>/index.php" aria-label="На главную">
            <img src="<?= htmlspecialchars($base, ENT_QUOTES, 'UTF-8') ?>/images/logo_type.svg" alt="" onerror="this.style.display='none'">
        </a>

        <main class="card" role="main">
            <div class="art" aria-hidden="true">
                <?php if ($err['icon'] === 'planet'): ?>
                <svg width="180" height="150" viewBox="0 0 180 150" class="float">
                    <defs>
                        <radialGradient id="pg" cx="35%" cy="30%" r="80%">
                            <stop offset="0" stop-color="#9aa4ff"/><stop offset=".55" stop-color="#5865f2"/><stop offset="1" stop-color="#252a7a"/>
                        </radialGradient>
                        <clipPath id="front"><rect x="0" y="75" width="180" height="80"/></clipPath>
                    </defs>
                    <ellipse cx="90" cy="75" rx="78" ry="20" fill="none" stroke="#f0b232" stroke-opacity=".5" stroke-width="5" transform="rotate(-18 90 75)"/>
                    <circle cx="90" cy="75" r="44" fill="url(#pg)"/>
                    <circle cx="74" cy="62" r="7" fill="#000" fill-opacity=".14"/>
                    <circle cx="108" cy="88" r="10" fill="#000" fill-opacity=".14"/>
                    <circle cx="100" cy="56" r="4" fill="#000" fill-opacity=".12"/>
                    <g clip-path="url(#front)">
                        <ellipse cx="90" cy="75" rx="78" ry="20" fill="none" stroke="#f0b232" stroke-width="5" transform="rotate(-18 90 75)"/>
                    </g>
                    <g class="orbit"><circle cx="90" cy="14" r="5" fill="#f2f3f5"/><circle cx="90" cy="14" r="9" fill="#f2f3f5" fill-opacity=".15"/></g>
                    <circle class="twinkle" cx="18" cy="26" r="2" fill="#fff"/>
                    <circle class="twinkle" style="animation-delay:-1s" cx="160" cy="40" r="2.4" fill="#fff"/>
                    <circle class="twinkle" style="animation-delay:-.5s" cx="150" cy="122" r="1.8" fill="#fff"/>
                </svg>

                <?php elseif ($err['icon'] === 'lock'): ?>
                <svg width="180" height="150" viewBox="0 0 180 150" class="float">
                    <circle cx="90" cy="75" r="58" fill="none" stroke="var(--c)" stroke-opacity=".25" stroke-width="2" stroke-dasharray="4 8"/>
                    <g class="orbit"><circle cx="90" cy="17" r="5" fill="var(--c)"/></g>
                    <path d="M66 70V56a24 24 0 0 1 48 0v14" fill="none" stroke="var(--c)" stroke-width="9" stroke-linecap="round"/>
                    <rect x="52" y="68" width="76" height="56" rx="14" fill="var(--c)"/>
                    <circle cx="90" cy="92" r="8" fill="#1e1f22"/>
                    <rect x="87" y="95" width="6" height="15" rx="3" fill="#1e1f22"/>
                </svg>

                <?php elseif ($err['icon'] === 'clock'): ?>
                <svg width="180" height="150" viewBox="0 0 180 150" class="float">
                    <circle cx="90" cy="75" r="56" fill="none" stroke="var(--c)" stroke-opacity=".3" stroke-width="4"/>
                    <circle cx="90" cy="75" r="56" fill="none" stroke="var(--c)" stroke-width="4" stroke-linecap="round" stroke-dasharray="120 352" transform="rotate(-90 90 75)"/>
                    <circle cx="90" cy="75" r="44" fill="var(--c)" fill-opacity=".12"/>
                    <g class="orbit"><path d="M90 75V42" stroke="var(--c)" stroke-width="6" stroke-linecap="round"/></g>
                    <path d="M90 75l20 12" stroke="var(--text)" stroke-width="6" stroke-linecap="round"/>
                    <circle cx="90" cy="75" r="6" fill="var(--text)"/>
                </svg>

                <?php elseif ($err['icon'] === 'tools'): ?>
                <svg width="180" height="150" viewBox="0 0 180 150" class="float">
                    <g class="orbit" style="animation-duration:9s"><g transform="translate(90 75)">
                        <circle r="34" fill="var(--c)"/>
                        <?php for ($i = 0; $i < 8; $i++): ?>
                        <rect x="-8" y="-52" width="16" height="22" rx="4" fill="var(--c)" transform="rotate(<?= $i * 45 ?>)"/>
                        <?php endfor; ?>
                        <circle r="15" fill="var(--panel)"/>
                    </g></g>
                    <circle class="twinkle" cx="24" cy="30" r="2" fill="#fff"/>
                    <circle class="twinkle" style="animation-delay:-1.2s" cx="158" cy="116" r="2.2" fill="#fff"/>
                </svg>

                <?php elseif ($err['icon'] === 'bolt'): ?>
                <svg width="180" height="150" viewBox="0 0 180 150" class="float">
                    <g class="shake">
                        <circle cx="90" cy="75" r="56" fill="var(--c)" fill-opacity=".12" stroke="var(--c)" stroke-opacity=".5" stroke-width="2"/>
                        <path d="M98 22L56 84h28l-8 44 46-66H92z" fill="var(--c)" stroke="var(--c)" stroke-width="4" stroke-linejoin="round"/>
                    </g>
                    <circle class="twinkle" cx="22" cy="34" r="2" fill="#fff"/>
                    <circle class="twinkle" style="animation-delay:-.8s" cx="160" cy="26" r="2.4" fill="#fff"/>
                </svg>

                <?php else: ?>
                <svg width="180" height="150" viewBox="0 0 180 150" class="float">
                    <path d="M90 18L162 128H18z" fill="var(--c)" fill-opacity=".15" stroke="var(--c)" stroke-width="7" stroke-linejoin="round"/>
                    <rect x="85" y="56" width="10" height="38" rx="5" fill="var(--c)"/>
                    <circle cx="90" cy="107" r="6" fill="var(--c)"/>
                </svg>
                <?php endif; ?>
            </div>

            <div class="code" aria-label="Ошибка <?= $code ?>">
                <?php foreach ($digits as $d): ?><span class="d" data-d="<?= $d ?>"><?= $d ?></span><?php endforeach; ?>
            </div>

            <h1><?= htmlspecialchars($err['title']) ?></h1>
            <p class="lead"><?= htmlspecialchars($err['text']) ?></p>

            <?php if ($path !== ''): ?>
                <div class="path" title="<?= htmlspecialchars($path, ENT_QUOTES, 'UTF-8') ?>"><b>GET</b><?= htmlspecialchars($path, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>

            <?php if ($detail !== ''): ?>
                <div class="detail"><b>DEBUG</b><?= htmlspecialchars($detail, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>

            <div class="actions">
                <a class="btn btn-primary" href="<?= htmlspecialchars($base, ENT_QUOTES, 'UTF-8') ?>/index.php">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/></svg>
                    На главную
                </a>
                <?php if ($backUrl !== ''): ?>
                <a class="btn btn-ghost" href="<?= htmlspecialchars($base . '/' . $backUrl, ENT_QUOTES, 'UTF-8') ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                    <?= strpos($backUrl, 'messages.php') === 0 ? 'Вернуться в чат' : 'Назад' ?>
                </a>
                <?php endif; ?>
                <?php if ($canRetry): ?>
                <button type="button" class="btn btn-ghost" id="retryBtn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/></svg>
                    Попробовать снова
                </button>
                <?php endif; ?>
            </div>

            <div class="meta">
                <span><span class="dot"></span>Код ошибки: <code><?= $code ?></code></span>
            </div>
        </main>
    </div>

    <script>
    (function () {
        /* ----- кнопки ----- */
        var retry = document.getElementById('retryBtn');
        if (retry) retry.addEventListener('click', function () { location.replace(location.href); });

        /* ----- смена темы (та же cookie «theme», что и в index.php) ----- */
        function themeIsLight() {
            var th = document.body.getAttribute('data-theme');
            return th === 'light' || (th === 'system' && !!window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches);
        }
        function onThemeChange() {                    // звёзды и сезонные эффекты подстраиваются под тему без перезагрузки
            if (window.__starsTheme) window.__starsTheme(themeIsLight());
            if (window.__seasonTheme) window.__seasonTheme();
        }
        var themeSw = document.getElementById('themeSw');
        if (themeSw) themeSw.addEventListener('click', function (e) {
            var b = e.target.closest('button[data-theme]');
            if (!b || b.classList.contains('active')) return;
            var t = b.getAttribute('data-theme');
            [].slice.call(themeSw.querySelectorAll('button')).forEach(function (x) { x.classList.toggle('active', x === b); });
            document.cookie = 'theme=' + t + '; path=/; max-age=31536000; samesite=lax';
            document.body.setAttribute('data-theme', t);   // цвета плавно перетекают благодаря transition на body
            onThemeChange();
        });
        if (window.matchMedia) {                      // при «Системной» теме следим за сменой темы в самой системе
            var mqTheme = matchMedia('(prefers-color-scheme: light)');
            var mqHandler = function () { if (document.body.getAttribute('data-theme') === 'system') onThemeChange(); };
            if (mqTheme.addEventListener) mqTheme.addEventListener('change', mqHandler);
            else if (mqTheme.addListener) mqTheme.addListener(mqHandler);
        }

        /* ----- лампа: плавное моргание цифр + звук (Web Audio, без файлов) ----- */
        var rm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
        var soundBtn = document.getElementById('soundBtn');
        var digitEls = [].slice.call(document.querySelectorAll('.code .d'));
        if (rm) {
            if (soundBtn) soundBtn.style.display = 'none';
        } else if (digitEls.length) {
            var AC = window.AudioContext || window.webkitAudioContext;
            var ac = null, master = null, send = null, noiseBuf = null;
            var soundPref = true;
            try { soundPref = localStorage.getItem('errSound') !== '0'; } catch (e) {}
            var vol = .6;                                   // громкость 0..1 (ползунок), запоминается в браузере
            try { var sv = parseFloat(localStorage.getItem('errVol')); if (sv >= 0 && sv <= 1) vol = sv; } catch (e) {}

            function rnd(a, b) { return a + Math.random() * (b - a); }
            function audioReady() { return ac && ac.state === 'running'; }
            function syncBtn() { if (soundBtn) soundBtn.classList.toggle('is-on', !!(soundPref && audioReady())); }

            function audioInit() {
                if (!AC) return;
                if (!ac) {
                    ac = new AC();
                    master = ac.createGain(); master.gain.value = vol; master.connect(ac.destination);

                    // короткий шум для звуков моргания
                    var len = Math.floor(ac.sampleRate * .2);
                    noiseBuf = ac.createBuffer(1, len, ac.sampleRate);
                    var ch = noiseBuf.getChannelData(0);
                    for (var i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;

                    // небольшая комната (почти сухо): лёгкая живость без металлического эха
                    var irLen = Math.floor(ac.sampleRate * .28);
                    var ir = ac.createBuffer(2, irLen, ac.sampleRate);
                    for (var c = 0; c < 2; c++) {
                        var d = ir.getChannelData(c);
                        for (var j = 0; j < irLen; j++) d[j] = (Math.random() * 2 - 1) * Math.exp(-(j / ac.sampleRate) * 16);
                    }
                    var conv = ac.createConvolver(); conv.buffer = ir;
                    var wet = ac.createGain(); wet.gain.value = .35;
                    send = ac.createGain(); send.gain.value = .22;
                    send.connect(conv); conv.connect(wet); wet.connect(master);
                }
                if (ac.state !== 'running') ac.resume().then(syncBtn, function () {});
                syncBtn();
            }

            // выход сигнала: сухой + чуть в комнату
            function route(node) { node.connect(master); if (send) node.connect(send); }

            // короткий всплеск шума через фильтр с экспоненциальным затуханием
            function burst(t0, dur, type, freq, q, level, att) {
                var a = att || .001;
                var src = ac.createBufferSource(); src.buffer = noiseBuf;
                var f = ac.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
                var g = ac.createGain();
                g.gain.setValueAtTime(.0001, t0);
                g.gain.exponentialRampToValueAtTime(Math.max(.0002, level), t0 + a);
                g.gain.exponentialRampToValueAtTime(.0001, t0 + dur);
                src.connect(f); f.connect(g); route(g);
                src.start(t0, rnd(0, .1), dur + .01);
            }
            function thump(t0, f0, f1, dur, level) {
                var o = ac.createOscillator(); o.type = 'sine';
                o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
                var g = ac.createGain();
                g.gain.setValueAtTime(.0001, t0);
                g.gain.exponentialRampToValueAtTime(Math.max(.0002, level), t0 + .004);
                g.gain.exponentialRampToValueAtTime(.0001, t0 + dur);
                o.connect(g); route(g); o.start(t0); o.stop(t0 + dur + .02);
            }

            // Неон, без жужжания: 'on' — трубка «схватывает» (яркий электрический «зип»),
            // 'cut' — тишина, без щелчков, 'pop' — едва слышное потрескивание разряда.
            function tick(strength, kind) {
                if (!soundPref || !audioReady()) return;
                var t = ac.currentTime, k = strength;
                if (kind === 'on') {
                    burst(t, .05, 'bandpass', rnd(4200, 6800), 1.4, .07 * k, .004);          // «зип» поджига
                    burst(t + .006, .04, 'bandpass', rnd(2000, 3400), 1.1, .05 * k, .006);
                } else if (kind === 'pop') {
                    burst(t, .02, 'bandpass', rnd(3000, 5000), 1.2, .03 * k, .006);
                }
            }

            ['pointerdown', 'keydown', 'touchstart'].forEach(function (ev) {
                addEventListener(ev, audioInit, { once: true, passive: true });
            });
            try { audioInit(); } catch (e) {}   // если браузер уже разрешил звук для сайта — заработает сразу

            if (soundBtn) soundBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                if (!audioReady()) { soundPref = true; audioInit(); }
                else { soundPref = !soundPref; }
                try { localStorage.setItem('errSound', soundPref ? '1' : '0'); } catch (err) {}
                syncBtn();
                if (soundPref) setTimeout(function () { tick(.8, 'on'); }, 60);
            });

            // вертикальный ползунок громкости
            var volEl = document.getElementById('volSlider'), volVal = document.getElementById('volVal');
            if (volEl) {
                volEl.value = Math.round(vol * 100);
                if (volVal) volVal.textContent = volEl.value + '%';
                volEl.addEventListener('input', function () {
                    vol = volEl.value / 100;
                    if (volVal) volVal.textContent = volEl.value + '%';
                    try { localStorage.setItem('errVol', String(vol)); } catch (err) {}
                    if (vol > 0 && !soundPref) { soundPref = true; try { localStorage.setItem('errSound', '1'); } catch (err) {} }
                    if (vol > 0) audioInit();
                    if (master && ac) master.gain.setTargetAtTime(vol, ac.currentTime, .02);
                    syncBtn();
                });
                volEl.addEventListener('change', function () { tick(.8, 'on'); });   // пробный звук после настройки
            }

            // Реалистичная лампа: нить накала имеет тепловую инерцию (гаснет быстро, разгорается дольше),
            // в «спокойном» состоянии чуть дрожит от сети, а неисправность приходит нерегулярными очередями
            // коротких обрывов контакта — как у перегорающей лампы. У каждой цифры свой характер.
            function skew(a, b) { return a + (b - a) * Math.pow(Math.random(), 2); }   // чаще короткие, редко длинные

            var lamps = digitEls.map(function (el, i) {
                var dying = i === digitEls.length - 1;
                return {
                    el: el, v: 1, t: 1, q: [], next: 0, flut: 0, fl2: 0,
                    tauDown: rnd(22, 34), tauUp: rnd(48, 75),
                    burst: performance.now() + rnd(1200, 4500) + i * 900, dying: dying
                };
            });

            function makeBurst(l) {
                var q = [], n = l.dying ? Math.round(rnd(4, 9)) : Math.round(rnd(2, 5));
                for (var i = 0; i < n; i++) {
                    var deep = Math.random() < (l.dying ? .6 : .4);
                    q.push({ l: deep ? rnd(.02, .14) : rnd(.3, .62), d: skew(22, deep ? 150 : 110) });  // обрыв контакта
                    q.push({ l: rnd(.78, 1),                          d: skew(28, 240) });             // нить успела разгореться
                }
                if (l.dying && Math.random() < .3) q.push({ l: rnd(.02, .08), d: rnd(320, 750) });     // долгое «затухание»
                q.push({ l: 1, d: 0 });
                return q;
            }

            var lastT = performance.now();
            (function lampLoop(now) {
                var dt = Math.min(64, now - lastT); lastT = now;
                var sum = 0;
                for (var i = 0; i < lamps.length; i++) {
                    var l = lamps[i];
                    if (l.q.length) {
                        if (now >= l.next) {
                            var st = l.q.shift(), delta = st.l - l.t;
                            if (delta < -.05)     tick(Math.min(1, .35 + Math.abs(delta)), 'cut');   // разрыв контакта — резкий щелчок
                            else if (delta > .05) tick(Math.min(1, .3 + delta * .7), 'on');      // замыкание — искра
                            l.t = st.l; l.next = now + st.d;
                            if (!l.q.length) l.burst = now + (l.dying ? rnd(2500, 6000) : rnd(6000, 14000));
                        }
                    } else if (now >= l.burst) {
                        l.q = makeBurst(l); l.next = now;
                    }
                    // тепловая инерция нити (не зависит от частоты кадров)
                    var tau = l.t < l.v ? l.tauDown : l.tauUp;
                    l.v += (l.t - l.v) * (1 - Math.exp(-dt / tau));
                    // лёгкое дрожание яркости от сети (шум, сглаженный в два шага)
                    l.fl2 += ((Math.random() - .5) - l.fl2) * .35;
                    l.flut += (l.fl2 - l.flut) * .35;
                    var amp = l.q.length ? .11 : .035;
                    var out = Math.max(0, Math.min(1, l.v + l.flut * amp * 2));
                    l.el.style.setProperty('--lamp', out.toFixed(3));
                    sum += out;
                    // потрескивание контакта во время серии
                    if (l.q.length && Math.random() < .018) tick(rnd(.3, .7), 'pop');
                }
                requestAnimationFrame(lampLoop);
            })(performance.now());
        }

        /* ----- сезонный эффект (на всех страницах ошибок): частицы падают и оседают на цифрах (весна, лето, осень, зима) ----- */
        if (true) (function () {
            var SEASON = '<?= $season ?>';              // spring | summer | autumn | winter
            if (['spring', 'summer', 'autumn', 'winter'].indexOf(SEASON) < 0) return;
            var P = SEASON === 'spring' ? 46 : 16;          // запас вокруг цифры: куда ляжет «шапка» снега или лист; весной — ещё и место для выросших цветов
            var dpr2 = Math.min(window.devicePixelRatio || 1, 2);
            function r2(a, b) { return a + Math.random() * (b - a); }
            var GROUND = SEASON === 'autumn' || SEASON === 'winter' || SEASON === 'spring';   // эти сезоны складываются в кучу под цифрами; частицы не вылетают за её края
            var SNOW_DIGITS = ['5', '3'];                  // зимой снег ложится ещё и на эти цифры (список можно менять)
            var LIGHT = themeIsLight();   // светлая тема
            window.__seasonTheme = function () { LIGHT = themeIsLight(); };   // смена темы на лету: новые частицы и кромка снега берут цвета под неё
            function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

            var SNOW = ['255,255,255', '255,255,255', '226,238,255'];
            var AUT  = ['222,92,28', '236,132,24', '200,52,36', '226,170,40', '150,82,34'];
            var SPR  = ['255,183,200', '255,208,218', '255,232,238', '248,160,188'];
            var SUM_L = ['176,150,70', '150,170,80', '190,160,90'], SUM_D = ['255,250,235', '255,246,214', '250,255,240'];   // пух одуванчика: светлая / тёмная тема
            var CFG = {
                winter: { count: 95, maxPerDigit: 0,    pre: 0,   preReduce: 0 },
                autumn: { count: 38, maxPerDigit: 0,    pre: 0,   preReduce: 0 },
                spring: { count: 34, maxPerDigit: 16,   pre: 3,   preReduce: 9 },
                summer: { count: 30, maxPerDigit: 12,   pre: 3,   preReduce: 8 }
            }[SEASON];

            var digs = [], parts = [], pcv, pctx, pw, ph, started = false;
            var gcv, gctx, GH = [], G = [], GCOL = 4, MAXH = 26, GW = 0, GCH = 0, GBASE = 0;   // осень: куча листьев под цифрами (карта высот по столбцам)

            // для каждой цифры: маска её контура (по реальным метрикам шрифта) и холст осевших частиц внутри самой цифры,
            // поэтому снег/листья двигаются вместе с цифрой и мигают вместе с лампой
            function buildDigits() {
                digs.forEach(function (d) { if (d.cv.parentNode) d.cv.parentNode.removeChild(d.cv); if (d.fcv && d.fcv.parentNode) d.fcv.parentNode.removeChild(d.fcv); });
                digs = [];
                [].slice.call(document.querySelectorAll('.code .d')).forEach(function (el) {
                    var cs = getComputedStyle(el), fs = parseFloat(cs.fontSize), ch = el.textContent;
                    var w = el.offsetWidth, h = el.offsetHeight;
                    var Wc = Math.ceil(w + 2 * P), Hc = Math.ceil(h + 2 * P);
                    var m = document.createElement('canvas'); m.width = Wc; m.height = Hc;
                    var mc = m.getContext('2d');
                    mc.font = cs.fontWeight + ' ' + fs + 'px ' + cs.fontFamily;
                    mc.textBaseline = 'alphabetic';
                    var met = mc.measureText(ch);
                    var A = met.fontBoundingBoxAscent || fs * .92, D = met.fontBoundingBoxDescent || fs * .24;
                    var base = (h - (A + D)) / 2 + A;
                    mc.fillStyle = '#000'; mc.strokeStyle = '#000'; mc.lineWidth = 2; mc.lineJoin = 'round';
                    mc.fillText(ch, P, P + base); mc.strokeText(ch, P, P + base);
                    var px = mc.getImageData(0, 0, Wc, Hc).data, solid = new Uint8Array(Wc * Hc);
                    for (var i = 0; i < solid.length; i++) solid[i] = px[i * 4 + 3] > 110 ? 1 : 0;

                    var cv = document.createElement('canvas'); cv.width = Wc * dpr2; cv.height = Hc * dpr2;
                    cv.style.cssText = 'position:absolute;left:' + (-P) + 'px;top:' + (-P) + 'px;width:' + Wc + 'px;height:' + Hc + 'px;pointer-events:none;';
                    el.appendChild(cv);
                    var c = cv.getContext('2d'); c.scale(dpr2, dpr2);
                    var fcv = null, fc = null;
                    if (SEASON === 'spring') {                      // отдельный холст для цветов: они перерисовываются каждый кадр, а упавшие лепестки остаются на своём
                        fcv = document.createElement('canvas'); fcv.width = Wc * dpr2; fcv.height = Hc * dpr2;
                        fcv.style.cssText = cv.style.cssText;
                        el.appendChild(fcv);
                        fc = fcv.getContext('2d'); fc.scale(dpr2, dpr2);
                    }
                    digs.push({ el: el, cv: cv, c: c, fcv: fcv, fc: fc, Wc: Wc, Hc: Hc, solid: solid, n: 0, ch: ch });
                    if ((SEASON === 'winter' && SNOW_DIGITS.indexOf(ch) >= 0) || SEASON === 'spring') prepSnow(digs[digs.length - 1]);
                });
            }

            // ---------- рисование ----------
            function leafPath(c, s) {                          // лист: острый кончик сверху, черешок снизу
                c.beginPath(); c.moveTo(0, -s);
                c.quadraticCurveTo(s * .75, -s * .15, 0, s * .8);
                c.quadraticCurveTo(-s * .75, -s * .15, 0, -s);
            }
            function petalPath(c, s) {                         // лепесток вишни: капля с небольшой выемкой сверху
                c.beginPath(); c.moveTo(0, s);
                c.bezierCurveTo(s * .95, s * .35, s * .8, -s * .95, s * .12, -s * .75);
                c.lineTo(0, -s * .55);
                c.lineTo(-s * .12, -s * .75);
                c.bezierCurveTo(-s * .8, -s * .95, -s * .95, s * .35, 0, s);
            }
            function fluffPath(c, p, alpha) {                  // «парашютик» одуванчика: семечко снизу и веер тонких волосков
                var s = p.size, by = s * .5;
                c.lineCap = 'round';
                c.strokeStyle = 'rgba(' + p.col + ',' + (.7 * alpha).toFixed(3) + ')'; c.lineWidth = .5;
                c.fillStyle = 'rgba(' + p.col + ',' + alpha.toFixed(3) + ')';
                c.beginPath();
                for (var k = 0; k < 9; k++) {
                    var a = -1.5708 + (k - 4) * .21, ex = Math.cos(a) * s * .8, ey = by + Math.sin(a) * s * .95;
                    c.moveTo(0, by); c.lineTo(ex, ey);
                }
                c.stroke();
                for (var j = 0; j < 9; j++) {
                    var b = -1.5708 + (j - 4) * .21;
                    c.beginPath(); c.arc(Math.cos(b) * s * .8, by + Math.sin(b) * s * .95, 1, 0, 6.283); c.fill();
                }
                c.strokeStyle = 'rgba(' + (LIGHT ? '110,90,50' : '150,122,76') + ',' + alpha.toFixed(3) + ')'; c.lineWidth = 1.3;   // семечко
                c.beginPath(); c.moveTo(0, by); c.lineTo(0, s * 1.0); c.stroke();
            }
            function drawShape(c, p, x, y, rot, flip, alpha) {
                if (SEASON === 'winter') {
                    c.fillStyle = 'rgba(' + p.col + ',' + alpha.toFixed(3) + ')';
                    c.beginPath(); c.arc(x, y, p.r, 0, 6.283); c.fill();
                    return;
                }
                c.save(); c.translate(x, y); c.rotate(rot); c.scale(flip, 1);
                if (SEASON === 'autumn') {
                    leafPath(c, p.size);
                    c.fillStyle = 'rgba(' + p.col + ',' + alpha.toFixed(3) + ')'; c.fill();
                    c.strokeStyle = 'rgba(60,24,6,' + (.45 * alpha).toFixed(3) + ')'; c.lineWidth = .7;
                    c.beginPath(); c.moveTo(0, -p.size * .85); c.lineTo(0, p.size * 1.15); c.stroke();   // жилка и черешок
                } else if (SEASON === 'summer') {
                    fluffPath(c, p, alpha);
                } else {
                    petalPath(c, p.size);
                    c.fillStyle = 'rgba(' + p.col + ',' + alpha.toFixed(3) + ')'; c.fill();
                    c.strokeStyle = 'rgba(214,100,140,' + (.35 * alpha).toFixed(3) + ')'; c.lineWidth = .6;
                    c.beginPath(); c.moveTo(0, p.size * .8); c.lineTo(0, -p.size * .2); c.stroke();      // прожилка
                }
                c.restore();
            }

            function markSolid(d, cx, cy, hx, hy) {
                for (var yy = Math.floor(cy - hy); yy <= Math.ceil(cy + hy); yy++) {
                    if (yy < 0 || yy >= d.Hc) continue;
                    for (var xx = Math.floor(cx - hx); xx <= Math.ceil(cx + hx); xx++) {
                        if (xx >= 0 && xx < d.Wc) d.solid[yy * d.Wc + xx] = 1;
                    }
                }
            }

            // частица села в точке (lx, ly) цифры и остаётся на ней
            function land(d, p, lx, ly) {
                if (d.n >= CFG.maxPerDigit) return;
                d.n++;
                if (SEASON === 'winter') {                     // снежная «шапка»: мягкие комки, следующие хлопья ложатся сверху
                    d.c.fillStyle = 'rgba(214,228,248,.16)';
                    d.c.beginPath(); d.c.ellipse(lx, ly + .4, r2(2.6, 4.4), r2(.7, 1.1), 0, 0, 6.283); d.c.fill();
                    d.c.fillStyle = 'rgba(255,255,255,.96)';
                    d.c.beginPath(); d.c.ellipse(lx, ly - .4, r2(3.4, 4.6), r2(1.1, 1.6), 0, 0, 6.283); d.c.fill();   // не уже опоры, иначе в шапке остаются дыры
                    markSolid(d, lx, ly - .3, 3.4, 1.2);          // широкая опора: снег ложится ровной шапкой, а не столбиками
                } else {                                       // лист/лепесток лежит плашмя на верхней поверхности
                    var rot = (Math.random() < .5 ? 1 : -1) * 1.5708 + r2(-.55, .55);
                    var s = p.size * .95;
                    var cy = ly - s * .32;
                    d.c.fillStyle = 'rgba(0,0,0,.22)';        // лёгкая тень под ним
                    d.c.beginPath(); d.c.ellipse(lx, ly + .3, s * .95, s * .22, 0, 0, 6.283); d.c.fill();
                    drawShape(d.c, p, lx, cy, rot, 1, 1);
                    markSolid(d, lx, cy, s * .9, s * .3);
                }
            }

            // мгновенная посадка: частица падает по вертикали в случайном столбце до первой опоры
            function dropInstant(d) {
                var x = Math.floor(r2(P, d.Wc - P)), p = newProps();
                for (var y = 0; y < d.Hc; y++) {
                    if (d.solid[y * d.Wc + x]) { land(d, p, x + r2(-.4, .4), y - r2(.3, 1)); return; }
                }
            }

            // осень: куча листьев в полосе под цифрами. Холст кучи лежит внутри .code, поэтому двигается вместе со страницей
            function lowRow(d) {
                for (var y = d.Hc - 1; y >= 0; y--) for (var x = 0; x < d.Wc; x++) if (d.solid[y * d.Wc + x]) return y;
                return d.Hc - 1;
            }
            function capAt(i) {                                // куча выше посередине и сходит на нет к краям
                var u = Math.min(1, Math.max(0, (i * GCOL) / GW));
                return MAXH * (.3 + .7 * Math.sin(3.1416 * u));
            }
            // ---------- зима: реалистичный снег на цифре ----------
            // Не «стопка» из комков: у каждой цифры есть карта высоты снега по столбцам. Падающие хлопья добавляют снег,
            // а предел высоты зависит от формы цифры: на ровной верхушке снега много, на крутых склонах мало, к краям он сходит на нет.
            function prepSnow(d) {
                var W = d.Wc, H = d.Hc, x, y;
                d.top = new Int16Array(W); d.h = new Float32Array(W); d.maxH = new Float32Array(W);
                for (x = 0; x < W; x++) {
                    d.top[x] = -1;
                    for (y = 0; y < H; y++) if (d.solid[y * W + x]) { d.top[x] = y; break; }
                }
                var cap = Math.max(6, Math.round(H * .062)), start = -1;
                for (x = 0; x <= W; x++) {
                    var on = x < W && d.top[x] >= 0;
                    if (on && start < 0) start = x;
                    if (!on && start >= 0) {                        // отдельный участок верхней кромки: считаем форму и расстояние до его краёв
                        for (var i = start; i < x; i++) {
                            var a = Math.max(start, i - 4), b = Math.min(x - 1, i + 4);
                            var slope = b > a ? Math.abs(d.top[b] - d.top[a]) / (b - a) : 0;
                            var edge = Math.min(i - start + 1, x - i) / 11;
                            var f = Math.pow(Math.max(0, 1 - slope / 1.1), 1.3) * Math.pow(Math.min(1, edge), .7);
                            d.maxH[i] = cap * f * r2(.82, 1.12);
                        }
                        start = -1;
                    }
                }
                d.cap = cap; d.dirty = false; d.last = 0;
            }
            function snowLand(d, x) {
                var amt = r2(.5, 1.1), c = Math.floor(x);
                for (var i = c - 4; i <= c + 4; i++) {
                    if (i < 0 || i >= d.Wc || d.top[i] < 0) continue;
                    d.h[i] = Math.min(d.maxH[i], d.h[i] + amt * Math.exp(-((i - x) * (i - x)) / 8));
                }
                d.dirty = true;
            }
            function seedSnow(d, k) {
                for (var x = 0; x < d.Wc; x++) d.h[x] = d.maxH[x] * k * r2(.85, 1);
                d.dirty = true;
            }
            function drawSnow(d) {
                var W = d.Wc, c = d.c, hs = new Float32Array(W), x, i;
                c.clearRect(0, 0, W, d.Hc);
                for (x = 0; x < W; x++) {                           // сглаживание, чтобы кромка была мягкой
                    var sum = 0, wsum = 0;
                    for (i = -3; i <= 3; i++) { var j = x + i; if (j >= 0 && j < W) { var w = 4 - Math.abs(i); sum += d.h[j] * w; wsum += w; } }
                    hs[x] = sum / wsum;
                }
                var start = -1;
                for (x = 0; x <= W; x++) {
                    var on = x < W && d.top[x] >= 0 && hs[x] > .25;
                    if (on && start < 0) start = x;
                    if (!on && start >= 0) {
                        var end = x - 1, minY = 1e9, maxY = 0;
                        c.beginPath(); c.moveTo(start, d.top[start] + 2);
                        for (i = start; i <= end; i++) { var yy = d.top[i] - hs[i]; c.lineTo(i + .5, yy); if (yy < minY) minY = yy; if (d.top[i] + 2 > maxY) maxY = d.top[i] + 2; }
                        c.lineTo(end + 1, d.top[end] + 2); c.closePath();
                        var g = c.createLinearGradient(0, minY, 0, maxY);
                        g.addColorStop(0, 'rgba(255,255,255,.98)'); g.addColorStop(1, 'rgba(218,230,250,.96)');
                        c.fillStyle = g; c.fill();
                        c.beginPath();                              // тонкая кромка сверху
                        for (i = start; i <= end; i++) { var y2 = d.top[i] - hs[i]; if (i === start) c.moveTo(i + .5, y2); else c.lineTo(i + .5, y2); }
                        c.strokeStyle = LIGHT ? 'rgba(120,150,200,.6)' : 'rgba(255,255,255,.9)'; c.lineWidth = LIGHT ? .9 : 1.1; c.lineJoin = 'round'; c.stroke();
                        start = -1;
                    }
                }
            }
            // ---------- весна: на верхней кромке цифр вырастают цветы ----------
            // Росток тянется вверх, раскрываются листья, потом почка превращается в цветок. Цветы качаются на ветру.
            var FLOWERS = [
                { p: '255,183,200', c: '255,205,70',  n: 5, w: .36 },      // вишнёвый
                { p: '255,255,255', c: '255,198,50',  n: 9, w: .2  },      // ромашка
                { lilac: true },                                           // сирень: кисть из множества мелких цветков, раскрывающихся по очереди
                { lilac: true },
                { p: '255,150,120', c: '255,232,110', n: 6, w: .32 }       // коралловый
            ];
            var MAXF = 4;                                                  // цветов на одной цифре
            function ease(u) { u = u < 0 ? 0 : u > 1 ? 1 : u; return 1 - Math.pow(1 - u, 3); }
            function back(u) { u = u < 0 ? 0 : u > 1 ? 1 : u; return 1 + 2.70158 * Math.pow(u - 1, 3) + 1.70158 * Math.pow(u - 1, 2); }
            function plant(d, now, age) {                                  // age 0..1 — насколько цветок уже вырос к моменту посадки
                var cands = [], x, i;
                for (x = 8; x < d.Wc - 8; x++) if (d.top[x] >= 0 && d.maxH[x] >= d.cap * .4) cands.push(x);   // только ровные участки кромки, не у самого края
                if (!cands.length) return;
                var ok = false;
                for (i = 0; i < 14 && !ok; i++) { x = pick(cands); ok = d.fl.every(function (f) { return Math.abs(f.x - x) > 15; }); }
                if (!ok) return;
                var dur = r2(5500, 8500);
                var t = pick(FLOWERS);
                var f = { x: x, y: d.top[x] + 1.5, t0: now - (age || 0) * dur, dur: dur, H: t.lilac ? r2(12, 18) : r2(18, 30), R: r2(6, 9),
                          t: t, ph: r2(0, 6.283), bend: r2(-4, 4), rot: r2(0, 6.283) };
                if (t.lilac) {                                               // кисть сирени: конус из мелких цветков, снизу вверх
                    var PH = r2(17, 23), PW = r2(5.5, 7.5), cols = pick([['196,160,238', '184,146,230', '210,178,244'], ['226,206,250', '214,190,246', '240,226,255']]);
                    f.PH = PH; f.fl = [];
                    for (var q = 0; q < 30; q++) {
                        var tt = Math.pow(Math.random(), .85), wd = PW * Math.pow(1 - tt, .8);
                        f.fl.push({ x: r2(-1, 1) * wd, y: -tt * PH, o: .5 + .36 * tt + r2(0, .04), rot: r2(0, 6.283), col: pick(cols), r: r2(2.1, 2.9) });
                    }
                    f.fl.sort(function (a, b) { return b.y - a.y; });
                }
                d.fl.push(f);
            }
            function drawFlower(c, f, now) {
                var u = (now - f.t0) / f.dur;
                if (u <= 0) return;
                if (u > 1) u = 1;
                var sg = ease(u / .6), L = f.H * sg, bx = f.bend * sg;
                c.save(); c.translate(f.x, f.y); c.rotate(Math.sin(now / 1000 * 1.1 + f.ph) * .045 * sg);
                c.lineCap = 'round'; c.strokeStyle = 'rgb(88,168,86)'; c.lineWidth = 1.8;
                c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(bx * .2, -L * .5, bx, -L); c.stroke();                   // стебель
                var ls = ease((u - .22) / .35);
                if (ls > 0) {                                                                                               // два листика
                    c.fillStyle = 'rgba(104,184,92,.96)';
                    for (var sd = -1; sd <= 1; sd += 2) {
                        c.beginPath(); c.ellipse(bx * .1 + sd * 4.6 * ls, -L * .42 - 2 * ls, 4.8 * ls, 1.9 * ls, sd * -.5, 0, 6.283); c.fill();
                    }
                }
                c.translate(bx, -L);
                if (f.t.lilac) {                                                                                            // сирень: кисть растёт, цветки раскрываются по очереди снизу вверх
                    var pb = ease((u - .38) / .17);
                    if (pb > 0) {
                        c.strokeStyle = 'rgb(88,150,84)'; c.lineWidth = 1.2;
                        c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -f.PH * pb); c.stroke();                                  // ось кисти
                        for (var j = 0; j < f.fl.length; j++) {
                            var fo = f.fl[j], k = (u - fo.o) / .12, px = fo.x * pb, py = fo.y * pb;
                            if (k <= 0) {                                                                                       // закрытая почка
                                c.fillStyle = 'rgb(122,80,166)'; c.beginPath(); c.arc(px, py, 1.1 * pb, 0, 6.283); c.fill();
                            } else {
                                var rr = fo.r * back(k);
                                c.fillStyle = 'rgba(' + fo.col + ',.98)';
                                for (var m = 0; m < 4; m++) {
                                    c.save(); c.translate(px, py); c.rotate(fo.rot + m * 1.5708);
                                    c.beginPath(); c.ellipse(0, -rr * .55, rr * .42, rr * .58, 0, 0, 6.283); c.fill();
                                    c.restore();
                                }
                                c.fillStyle = 'rgb(150,104,190)'; c.beginPath(); c.arc(px, py, rr * .24, 0, 6.283); c.fill();
                            }
                        }
                    }
                } else if (u < .55) {                                                                                       // почка
                    c.fillStyle = 'rgb(122,196,100)'; c.beginPath(); c.arc(0, 0, 2.3 * sg, 0, 6.283); c.fill();
                } else {                                                                                                    // цветок раскрывается
                    var R = f.R * back((u - .55) / .45), n = f.t.n;
                    c.fillStyle = 'rgba(' + f.t.p + ',.97)'; c.strokeStyle = 'rgba(150,90,120,.32)'; c.lineWidth = .6;
                    for (var i = 0; i < n; i++) {
                        c.save(); c.rotate(f.rot + i * 6.2832 / n);
                        c.beginPath(); c.ellipse(0, -R * .62, R * f.t.w, R * .6, 0, 0, 6.283); c.fill(); c.stroke();
                        c.restore();
                    }
                    c.fillStyle = 'rgb(' + f.t.c + ')'; c.beginPath(); c.arc(0, 0, R * .28, 0, 6.283); c.fill();
                }
                c.restore();
            }
            function growFlowers(d, now) {
                if (!d.fl) return;
                if (d.fl.length < MAXF && now >= d.nextPlant) { plant(d, now, 0); d.nextPlant = now + r2(4000, 8000); }   // через время вырастает ещё один
                d.fc.clearRect(0, 0, d.Wc, d.Hc);
                for (var i = 0; i < d.fl.length; i++) drawFlower(d.fc, d.fl[i], now);
            }
            function holds(d) { return !GROUND || (SEASON === 'winter' && SNOW_DIGITS.indexOf(d.ch) >= 0); }   // ложатся ли частицы на эту цифру
            function buildGround() {
                if (gcv && gcv.parentNode) gcv.parentNode.removeChild(gcv);
                gcv = null;
                var code = document.querySelector('.code');
                if (!GROUND || !code || !digs.length) return;
                var cr = code.getBoundingClientRect(), first = digs[0].cv.getBoundingClientRect(), last = digs[digs.length - 1].cv.getBoundingClientRect();
                var low = 0; digs.forEach(function (d) { low = Math.max(low, lowRow(d)); });
                var ty = 0, mm = (getComputedStyle(digs[0].el).transform || '').match(/matrix\(([^)]+)\)/);
                if (mm) ty = parseFloat(mm[1].split(',')[5]) || 0;                       // цифры покачиваются — берём их «нулевое» положение
                var glyphBottom = first.top + low + 1 - ty - cr.top;                      // низ цифр относительно .code
                var codeH = cr.height, M = 26;
                MAXH = Math.max(14, Math.min(34, Math.round(codeH - glyphBottom) + 8));  // куча лежит в пустой полосе под цифрами
                var gl = (first.left + P) - M, gr = (last.right - P) + M;
                GW = Math.round(gr - gl); GCH = MAXH + 18; GBASE = GCH - 4;
                code.style.position = 'relative';
                gcv = document.createElement('canvas');
                gcv.width = GW * dpr2; gcv.height = GCH * dpr2;
                gcv.style.cssText = 'position:absolute;left:' + Math.round(gl - cr.left) + 'px;top:' + Math.round(codeH + 2 - GBASE) + 'px;' +
                                    'width:' + GW + 'px;height:' + GCH + 'px;pointer-events:none;z-index:2;';
                code.appendChild(gcv);
                gctx = gcv.getContext('2d'); gctx.setTransform(dpr2, 0, 0, dpr2, 0, 0);
                GH = []; G = []; for (var g = 0; g <= Math.ceil(GW / GCOL); g++) GH.push(0);
            }
            // лист/снежинка упали в кучу (x — в координатах холста кучи); следующие ложатся выше
            function groundLand(p, x) {
                var winter = SEASON === 'winter', w = winter ? 3 : p.size;
                var i0 = Math.max(0, Math.floor((x - w) / GCOL)), i1 = Math.min(GH.length - 1, Math.floor((x + w) / GCOL));
                var top = 0, i;
                for (i = i0; i <= i1; i++) if (GH[i] > top) top = GH[i];
                var base = GBASE - top;
                if (winter) {                                  // сугроб: мягкие комки, следующие хлопья ложатся сверху
                    gctx.fillStyle = 'rgba(236,243,255,.95)';
                    gctx.fillRect(x - r2(2.5, 4), base, r2(5, 8), top + 1);      // тело сугроба под комком
                    gctx.fillStyle = 'rgba(214,228,248,.4)';
                    gctx.beginPath(); gctx.ellipse(x, base + .4, r2(3, 5.5), r2(.8, 1.3), 0, 0, 6.283); gctx.fill();
                    gctx.fillStyle = 'rgba(255,255,255,.97)';
                    gctx.beginPath(); gctx.ellipse(x, base - .4, r2(1.8, 3.4), r2(1, 1.7), 0, 0, 6.283); gctx.fill();
                    for (i = i0; i <= i1; i++) GH[i] = Math.min(capAt(i), Math.max(GH[i], top) + .8);
                    return;
                }
                // листья и лепестки не копятся стопкой: лежат в один слой на земле вразброс, а когда место кончается, самый старый исчезает
                G.push({ p: p, x: x, dy: r2(0, 2.5), rot: (Math.random() < .5 ? 1 : -1) * 1.5708 + r2(-.6, .6), flip: r2(.45, 1) });
                if (G.length > Math.max(10, Math.floor(GW / 15))) G.shift();
                redrawGround();
            }
            function redrawGround() {
                gctx.clearRect(0, 0, GW, GCH);
                for (var i = 0; i < G.length; i++) {
                    var g = G[i], s = g.p.size * .95;
                    gctx.fillStyle = 'rgba(0,0,0,.2)';
                    gctx.beginPath(); gctx.ellipse(g.x, GBASE + .3, s * .8, s * .16, 0, 0, 6.283); gctx.fill();
                    drawShape(gctx, g.p, g.x, GBASE - s * .3 - g.dy, g.rot, g.flip, 1);
                }
            }
            function groundH(x) { return SEASON === 'winter' ? (GH[Math.floor(x / GCOL)] || 0) : 0; }   // у снега куча растёт, у листьев земля плоская

            function newProps() {
                if (SEASON === 'winter') return { col: pick(SNOW), r: r2(.9, 2.6), a: r2(.6, 1), vy: r2(18, 42), amp: r2(8, 20) };
                if (SEASON === 'autumn') return { col: pick(AUT), size: r2(6, 10), vy: r2(26, 52), amp: r2(22, 48) };
                if (SEASON === 'summer') return { col: pick(LIGHT ? SUM_L : SUM_D), size: r2(5, 8), vy: r2(10, 22), amp: r2(14, 30) };
                return { col: pick(SPR), size: r2(4.5, 7.5), vy: r2(15, 34), amp: r2(16, 36) };
            }

            function newPart(initial) {
                var x, y;
                if (GROUND && gcv) {      // осень, зима и весна: всё падает над цифрами и ложится в кучу под ними
                    var gr0 = gcv.getBoundingClientRect(), dTop = digs[0].cv.getBoundingClientRect().top;
                    var u = (Math.random() + Math.random()) / 2; x = gr0.left + GW * u;
                    y = initial ? r2(dTop - 160, dTop + 60) : dTop - r2(20, 90);
                } else if (!GROUND && digs.length && Math.random() < .7) {      // большинство падает над цифрами
                    var rc = digs[Math.floor(Math.random() * digs.length)].cv.getBoundingClientRect();
                    x = r2(rc.left + P, rc.right - P);
                    y = initial ? r2(rc.top - 190, rc.top) : rc.top - r2(20, 80);
                } else {
                    x = r2(0, pw); y = initial ? r2(0, ph) : -12;
                }
                var p = newProps();
                p.x = x; p.u = u; p.sway = SEASON === 'winter' ? r2(8, 24) : SEASON === 'spring' ? r2(10, 28) : r2(14, 36); p.y = y; p.ph = r2(0, 6.283); p.sp = r2(.35, .9);
                p.rot = r2(0, 6.283); p.vr = r2(-1.5, 1.5); p.fl = r2(0, 6.283);
                return p;
            }

            function sizePart() {
                pw = innerWidth; ph = innerHeight;
                pcv.width = pw * dpr2; pcv.height = ph * dpr2;
                pctx = pcv.getContext('2d'); pctx.setTransform(dpr2, 0, 0, dpr2, 0, 0);
            }

            function setup() {
                sizePart(); buildDigits(); buildGround();
                for (var k = 0; k < digs.length; k++) {
                    if (!holds(digs[k])) continue;
                    if (SEASON === 'winter') { seedSnow(digs[k], rm ? 1 : .6); drawSnow(digs[k]); digs[k].dirty = false; }
                    else for (var n = 0; n < (rm ? CFG.preReduce : CFG.pre); n++) dropInstant(digs[k]);
                }
                if (SEASON === 'spring') {
                    var now0 = performance.now();
                    digs.forEach(function (d) {
                        d.fl = [];
                        if (rm) { for (var z = 0; z < 3; z++) plant(d, now0, 1); d.nextPlant = 1e15; growFlowers(d, now0); return; }
                        plant(d, now0, .9); plant(d, now0, .35);          // один цветок уже цветёт, второй на подходе
                        d.nextPlant = now0 + r2(1500, 4000);
                    });
                }
                parts = [];
                if (gcv) for (var q = 0, nq = SEASON === 'winter' ? (rm ? 900 : 450) : (rm ? 60 : 14); q < nq; q++) groundLand(newProps(), r2(8, GW - 8));   // под цифрами уже что-то лежит
                if (!rm) for (var i = 0; i < CFG.count; i++) parts.push(newPart(true));
            }

            var lastP = performance.now();
            function frame(now) {
                var dt = Math.min(.05, (now - lastP) / 1000); lastP = now;
                var t = now / 1000;
                pctx.clearRect(0, 0, pw, ph);
                var rects = digs.map(function (d) { return d.cv.getBoundingClientRect(); });
                var gR = gcv ? gcv.getBoundingClientRect() : null;
                for (var i = 0; i < parts.length; i++) {
                    var p = parts[i];
                    var vy = SEASON === 'winter' ? p.vy : p.vy * (.72 + .28 * Math.sin(t * 1.7 + p.ph));   // листья «планируют»
                    p.y += vy * dt;
                    if (GROUND && gR && p.u !== undefined) {                // качается вокруг своей линии падения и не вылетает за края кучи
                        p.x = Math.max(gR.left + 6, Math.min(gR.left + GW - 6, gR.left + p.u * GW + Math.sin(t * p.sp + p.ph) * p.sway));
                    } else p.x += Math.sin(t * p.sp + p.ph) * p.amp * dt;
                    if (SEASON === 'summer') p.rot = Math.sin(t * p.sp * 1.3 + p.ph) * .5;   // парашютик качается, семечком вниз
                    else p.rot += p.vr * dt;
                    var probeY = p.y + (p.size ? p.size * .3 : 0);
                    var landed = false;
                    for (var k = 0; k < digs.length; k++) {
                        var rc = rects[k], d = digs[k];
                        if (!holds(d)) continue;                    // осенью на цифрах ничего не лежит, зимой — только на SNOW_DIGITS
                        if (SEASON === 'winter') {                  // хлопья ложатся на верхнюю кромку цифры поверх уже лежащего снега
                            var xi = Math.floor(p.x - rc.left);
                            if (xi >= 0 && xi < d.Wc && d.top[xi] >= 0 && p.y - rc.top >= d.top[xi] - d.h[xi]) { snowLand(d, p.x - rc.left); landed = true; break; }
                            continue;
                        }
                        if (p.x >= rc.left && p.x < rc.right && probeY >= rc.top && probeY < rc.bottom) {
                            var lx = Math.floor(p.x - rc.left), ly = Math.floor(probeY - rc.top);
                            if (d.solid[ly * d.Wc + lx]) {
                                var yy = ly; while (yy > 0 && d.solid[yy * d.Wc + lx]) yy--;
                                land(d, p, p.x - rc.left, yy + r2(.2, .8));
                                landed = true; break;
                            }
                        }
                    }
                    if (!landed && gR) {
                        var xc = p.x - gR.left;
                        if (xc >= 0 && xc < GW && p.y + (p.size ? p.size * .3 : 1) >= gR.top + GBASE - groundH(xc)) { groundLand(p, xc); landed = true; }
                    }
                    if (landed || p.y > ph + 20 || p.x < -20 || p.x > pw + 20) { parts[i] = newPart(false); continue; }
                    var flip = SEASON === 'summer' ? 1 : Math.max(.22, Math.abs(Math.cos(t * 2.1 + p.fl)));   // кувыркается в воздухе
                    var alpha = SEASON === 'winter' ? p.a * (.75 + .25 * Math.sin(t * 1.6 + p.fl)) : 1;
                    drawShape(pctx, p, p.x, p.y, p.rot, flip, alpha);
                }
                if (SEASON === 'spring') for (var fm = 0; fm < digs.length; fm++) growFlowers(digs[fm], now);
                if (SEASON === 'winter') for (var m = 0; m < digs.length; m++) {
                    var dd = digs[m];
                    if (dd.dirty && now - dd.last > 110) { drawSnow(dd); dd.dirty = false; dd.last = now; }
                }
                requestAnimationFrame(frame);
            }

            function start() {
                if (started) return; started = true;
                pcv = document.createElement('canvas');
                pcv.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:4;';
                document.body.appendChild(pcv);
                setup();
                if (!rm) requestAnimationFrame(frame);
                var rt;
                addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(setup, 250); });   // размеры цифр зависят от экрана
            }
            if (document.fonts && document.fonts.ready) document.fonts.ready.then(start); else start();
        })();

        /* ----- звёздное небо ----- */
        var cv = document.getElementById('stars');
        if (!cv || !cv.getContext) return;
        var ctx = cv.getContext('2d'), stars = [], shoot = null, W, H, dpr = Math.min(window.devicePixelRatio || 1, 2);
        var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
        var rgb = getComputedStyle(document.body).getPropertyValue('--star').trim() || '255,255,255';
        var dark = rgb.replace(/\s/g, '') === '255,255,255';
        if (!dark) { cv.style.display = 'none'; return; }     // светлая тема: звёзд нет
        // на тёмном фоне у звёзд лёгкие оттенки (холодные и тёплые), на светлом — один цвет темы
        var tints = dark ? ['255,255,255', '255,255,255', '200,220,255', '255,238,208'] : [rgb];

        function rnd(a, b) { return a + Math.random() * (b - a); }

        function resize() {
            W = innerWidth; H = innerHeight;
            cv.width = W * dpr; cv.height = H * dpr;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            var count = Math.min(190, Math.floor(W * H / 8000));
            stars = [];
            for (var i = 0; i < count; i++) {
                var big = Math.random() < .09;                       // немного крупных ярких звёзд с мягким ореолом
                stars.push({
                    x: Math.random() * W, y: Math.random() * H,
                    r: big ? rnd(1.3, 2) : rnd(.35, 1.2),
                    p1: rnd(0, 6.283), p2: rnd(0, 6.283),            // фазы двух «волн» мерцания
                    sp: big ? rnd(.5, .9) : rnd(.6, 1.7),            // скорость мерцания, рад/с (медленно и плавно)
                    base: big ? rnd(.55, .75) : rnd(.25, .5),        // минимальная яркость
                    depth: rnd(.4, 1),                               // «глубина»: дальние дрейфуют медленнее
                    tint: tints[Math.floor(Math.random() * tints.length)],
                    big: big
                });
            }
        }

        var last = performance.now();
        function frame(now) {
            now = now || performance.now();
            var dt = Math.min(.05, (now - last) / 1000); last = now;
            var t = now / 1000;
            ctx.clearRect(0, 0, W, H);

            for (var i = 0; i < stars.length; i++) {
                var s = stars[i];
                // очень медленный дрейф по диагонали (не «дождь»), пропорционален глубине
                s.x -= 2.2 * s.depth * dt; s.y += 1.4 * s.depth * dt;
                if (s.y > H + 3) { s.y = -3; s.x = Math.random() * W; }
                if (s.x < -3) { s.x = W + 3; s.y = Math.random() * H; }

                // естественное мерцание: две синусоиды разной частоты дают мягкую, неповторяющуюся «дышащую» яркость
                var w = .62 * Math.sin(t * s.sp + s.p1) + .38 * Math.sin(t * s.sp * 2.37 + s.p2);
                var k = Math.pow((w + 1) / 2, 1.4);                  // 0..1, нижние значения «растянуты» — звезда подолгу мягко светится
                var a = s.base + (1 - s.base) * k;
                var r = s.r * (.88 + .24 * k);                       // размер чуть пульсирует вместе с яркостью

                if (s.big) {                                         // мягкий ореол
                    var gr = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, r * 6);
                    gr.addColorStop(0, 'rgba(' + s.tint + ',' + (a * .35).toFixed(3) + ')');
                    gr.addColorStop(1, 'rgba(' + s.tint + ',0)');
                    ctx.fillStyle = gr;
                    ctx.beginPath(); ctx.arc(s.x, s.y, r * 6, 0, 6.283); ctx.fill();
                }
                ctx.fillStyle = 'rgba(' + s.tint + ',' + a.toFixed(3) + ')';
                ctx.beginPath(); ctx.arc(s.x, s.y, r, 0, 6.283); ctx.fill();
            }

            // редкая падающая звезда (по времени, не по кадрам)
            if (!shoot && Math.random() < .09 * dt) {
                shoot = { x: rnd(W * .3, W), y: rnd(0, H * .4), life: 0, dur: rnd(.7, 1.1), len: rnd(90, 150) };
            }
            if (shoot) {
                shoot.life += dt;
                var u = shoot.life / shoot.dur;
                if (u >= 1) { shoot = null; }
                else {
                    var hx = shoot.x - 520 * shoot.life, hy = shoot.y + 260 * shoot.life;   // голова
                    var fadeA = Math.sin(Math.PI * u);                                     // плавно появляется и гаснет
                    var tx = hx + shoot.len, ty = hy - shoot.len * .5;                     // хвост
                    var g = ctx.createLinearGradient(hx, hy, tx, ty);
                    g.addColorStop(0, 'rgba(' + rgb + ',' + (.9 * fadeA).toFixed(3) + ')');
                    g.addColorStop(1, 'rgba(' + rgb + ',0)');
                    ctx.strokeStyle = g; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
                    ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(tx, ty); ctx.stroke();
                }
            }

            if (!reduce) requestAnimationFrame(frame);
        }

        resize(); frame();
        addEventListener('resize', function () { resize(); if (reduce) frame(); });
    })();
    </script>
</body>
</html>

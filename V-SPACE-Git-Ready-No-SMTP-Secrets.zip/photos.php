<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
// Если в настройках выбран English — содержимое страницы переводится «на лету» (includes/lang.php)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();

/*
|--------------------------------------------------------------------------
| PLAYERCHAT — Фото
|--------------------------------------------------------------------------
*/

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$user_id = (int)$_SESSION["user_id"];

$stmt = $conn->prepare("SELECT id, username, email, avatar, status, last_seen, is_admin FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    $_SESSION = [];
    session_destroy();
    header("Location: login.php?account_missing=1");
    exit;
}

$username = $user["username"];
$is_admin = isset($user["is_admin"]) && $user["is_admin"] == 1;

/*
|--------------------------------------------------------------------------
| Хранилище фото с шифрованием (AES-256-GCM)
|--------------------------------------------------------------------------
| • Сами фото лежат на диске в storage/photos/*.bin только в зашифрованном
|   виде. Формат файла: [12 байт IV][16 байт тег][шифртекст].
| • В базе (таблица photos) — только метаданные; название фото тоже шифруется.
| • Ключ шифрования (API-ключ, 64 hex-символа) берётся из переменной окружения
|   PHOTO_ENCRYPTION_KEY, а если её нет — из файла storage/photo.key
|   (создаётся автоматически при первом запуске). Ключ нигде не хранится в БД.
| • Фото отдаются через photos.php?api=img&id=...: владельцу всегда, остальным —
|   только если фото лежит в ОТКРЫТОМ альбоме. Закрытые альбомы видит только владелец.
|--------------------------------------------------------------------------
*/

const PHOTO_MAX_BYTES = 15 * 1024 * 1024;     // 15 МБ на файл
const PHOTO_MAX_PER_REQUEST = 20;             // файлов за одну загрузку
const PHOTO_MAX_TOTAL = 2000;                 // фото на пользователя
const PHOTO_MIMES = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
];

$photo_storage = __DIR__ . '/storage';
$photo_dir     = $photo_storage . '/photos';

function photoJson(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function photoPrepareStorage(): void {
    global $photo_storage, $photo_dir;
    foreach ([$photo_storage, $photo_dir] as $d) {
        if (!is_dir($d) && !@mkdir($d, 0755, true) && !is_dir($d)) {
            throw new RuntimeException('Не удалось создать папку ' . basename($d));
        }
    }
    // Закрываем прямой доступ к папке по HTTP
    $ht = $photo_storage . '/.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    }
    $idx = $photo_storage . '/index.html';
    if (!is_file($idx)) {
        @file_put_contents($idx, '');
    }
}

function photoKey(): string {
    global $photo_storage;
    $env = getenv('PHOTO_ENCRYPTION_KEY');
    if (is_string($env) && strlen($env) === 64 && ctype_xdigit($env)) {
        return hex2bin($env);
    }
    $file = $photo_storage . '/photo.key';
    if (!is_file($file)) {
        $fh = @fopen($file, 'x');                     // 'x' — не затираем чужой ключ при гонке
        if ($fh) {
            fwrite($fh, bin2hex(random_bytes(32)));
            fclose($fh);
            @chmod($file, 0600);
        }
    }
    $hex = trim((string)@file_get_contents($file));
    if (strlen($hex) !== 64 || !ctype_xdigit($hex)) {
        throw new RuntimeException('Ключ шифрования повреждён или не создан');
    }
    return hex2bin($hex);
}

function photoEncrypt(string $plain, string $aad): string {
    $iv  = random_bytes(12);
    $tag = '';
    $ct  = openssl_encrypt($plain, 'aes-256-gcm', photoKey(), OPENSSL_RAW_DATA, $iv, $tag, $aad, 16);
    if ($ct === false || strlen($tag) !== 16) {
        throw new RuntimeException('Ошибка шифрования');
    }
    return $iv . $tag . $ct;
}

function photoDecrypt(string $blob, string $aad): ?string {
    if (strlen($blob) < 29) return null;
    $iv  = substr($blob, 0, 12);
    $tag = substr($blob, 12, 16);
    $ct  = substr($blob, 28);
    $out = openssl_decrypt($ct, 'aes-256-gcm', photoKey(), OPENSSL_RAW_DATA, $iv, $tag, $aad);
    return $out === false ? null : $out;
}

function photoTitleDec(string $enc, int $uid): string {
    $raw = base64_decode($enc, true);
    $t = $raw === false ? null : photoDecrypt($raw, 't' . $uid);
    return $t ?? 'Фото';
}

function albumTitle(array $row): string {
    $raw = base64_decode((string)$row['title_enc'], true);
    $t = $raw === false ? null : photoDecrypt($raw, 'a' . (int)$row['user_id']);
    return $t ?? 'Альбом';
}

function albumOwned(mysqli $c, int $aid, int $uid): ?array {
    if ($aid <= 0) return null;
    $stmt = $c->prepare("SELECT * FROM photo_albums WHERE id = ? AND user_id = ? LIMIT 1");
    $stmt->bind_param('ii', $aid, $uid);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function albumOut(array $r): array {
    return [
        'id'     => (int)$r['id'],
        'title'  => albumTitle($r),
        'public' => (int)$r['is_public'] === 1,
        'count'  => (int)($r['cnt'] ?? 0),
        'cover'  => isset($r['cover']) ? (int)$r['cover'] : null,
        'user'   => (int)$r['user_id'],
        'owner'  => $r['username'] ?? null,
    ];
}

function photoOut(array $r, int $owner): array {
    return [
        'id' => (int)$r['id'],
        'title' => photoTitleDec((string)$r['title_enc'], $owner),
        'w' => (int)$r['width'], 'h' => (int)$r['height'],
        'size' => (int)$r['size'], 'created' => $r['created_at'],
        'album' => isset($r['album_id']) ? (int)$r['album_id'] : null,
    ];
}

if (empty($_SESSION['photos_csrf'])) {
    $_SESSION['photos_csrf'] = bin2hex(random_bytes(32));
}
$photos_csrf = $_SESSION['photos_csrf'];

try {
    photoPrepareStorage();
    $conn->query("
        CREATE TABLE IF NOT EXISTS photos (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title_enc TEXT NOT NULL,
            mime VARCHAR(50) NOT NULL,
            size INT UNSIGNED NOT NULL DEFAULT 0,
            width INT UNSIGNED NOT NULL DEFAULT 0,
            height INT UNSIGNED NOT NULL DEFAULT 0,
            file_name CHAR(40) NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_photos_user (user_id, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $conn->query("
        CREATE TABLE IF NOT EXISTS photo_albums (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title_enc TEXT NOT NULL,
            is_public TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_albums_user (user_id, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $col = $conn->query("SHOW COLUMNS FROM photos LIKE 'album_id'");
    if ($col && $col->num_rows === 0) {
        $conn->query("ALTER TABLE photos ADD COLUMN album_id INT UNSIGNED NULL DEFAULT NULL, ADD INDEX idx_photos_album (album_id)");
    }
} catch (Throwable $e) {
    error_log('photos.php init: ' . $e->getMessage());
    if (isset($_GET['api'])) photoJson(['ok' => false, 'error' => 'Хранилище недоступно'], 500);
}

const PHOTO_ALBUM_SQL = "
    SELECT a.*, u.username,
           (SELECT COUNT(*) FROM photos p WHERE p.album_id = a.id) AS cnt,
           (SELECT p.id FROM photos p WHERE p.album_id = a.id ORDER BY p.id DESC LIMIT 1) AS cover
    FROM photo_albums a
    JOIN users u ON u.id = a.user_id
";

if (isset($_GET['api'])) {
    $api = (string)$_GET['api'];
    session_write_close();   // не блокируем другие запросы пользователя

    $csrf_ok = function () use ($photos_csrf): bool {
        $t = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
        return is_string($t) && hash_equals($photos_csrf, $t);
    };
    $is_post = $_SERVER['REQUEST_METHOD'] === 'POST';
    if ($is_post && !$csrf_ok()) {
        photoJson(['ok' => false, 'error' => 'Сессия устарела, обновите страницу'], 403);
    }

    try {
        // ---- мои фото и мои альбомы ----
        if ($api === 'list' && !$is_post) {
            $stmt = $conn->prepare("SELECT id, title_enc, width, height, size, created_at, album_id FROM photos WHERE user_id = ? ORDER BY id DESC LIMIT " . PHOTO_MAX_TOTAL);
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $res = $stmt->get_result();
            $items = [];
            while ($r = $res->fetch_assoc()) $items[] = photoOut($r, $user_id);
            $stmt->close();

            $stmt = $conn->prepare(PHOTO_ALBUM_SQL . " WHERE a.user_id = ? ORDER BY a.id DESC");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $res = $stmt->get_result();
            $albums = [];
            while ($r = $res->fetch_assoc()) $albums[] = albumOut($r);
            $stmt->close();

            photoJson(['ok' => true, 'items' => $items, 'albums' => $albums]);
        }

        // ---- альбомы пользователя (чужие — только открытые) ----
        if ($api === 'user_albums' && !$is_post) {
            $uid = (int)($_GET['uid'] ?? 0);
            $mine = $uid === $user_id ? 1 : 0;
            $stmt = $conn->prepare("SELECT username FROM users WHERE id = ? LIMIT 1");
            $stmt->bind_param('i', $uid);
            $stmt->execute();
            $u = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$u) photoJson(['ok' => false, 'error' => 'Пользователь не найден'], 404);

            $stmt = $conn->prepare(PHOTO_ALBUM_SQL . " WHERE a.user_id = ? AND (a.is_public = 1 OR ? = 1) ORDER BY a.id DESC");
            $stmt->bind_param('ii', $uid, $mine);
            $stmt->execute();
            $res = $stmt->get_result();
            $albums = [];
            while ($r = $res->fetch_assoc()) $albums[] = albumOut($r);
            $stmt->close();
            photoJson(['ok' => true, 'albums' => $albums, 'owner' => $u['username'], 'mine' => (bool)$mine]);
        }

        // ---- один альбом: владельцу всегда, остальным — если открытый ----
        if ($api === 'album_get' && !$is_post) {
            $aid = (int)($_GET['id'] ?? 0);
            $stmt = $conn->prepare(PHOTO_ALBUM_SQL . " WHERE a.id = ? LIMIT 1");
            $stmt->bind_param('i', $aid);
            $stmt->execute();
            $a = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            $mine = $a && (int)$a['user_id'] === $user_id;
            if (!$a || (!$mine && (int)$a['is_public'] !== 1)) {
                photoJson(['ok' => false, 'error' => 'Альбом не найден или закрыт владельцем'], 404);
            }
            $stmt = $conn->prepare("SELECT id, title_enc, width, height, size, created_at, album_id FROM photos WHERE album_id = ? AND user_id = ? ORDER BY id DESC");
            $owner_id = (int)$a['user_id'];
            $stmt->bind_param('ii', $aid, $owner_id);
            $stmt->execute();
            $res = $stmt->get_result();
            $items = [];
            while ($r = $res->fetch_assoc()) $items[] = photoOut($r, $owner_id);
            $stmt->close();
            photoJson(['ok' => true, 'album' => albumOut($a), 'items' => $items, 'mine' => $mine]);
        }

        // ---- выдача расшифрованной картинки ----
        if ($api === 'img' && !$is_post) {
            $id = (int)($_GET['id'] ?? 0);
            $stmt = $conn->prepare("
                SELECT p.mime, p.file_name, p.user_id, a.is_public
                FROM photos p LEFT JOIN photo_albums a ON a.id = p.album_id
                WHERE p.id = ? LIMIT 1
            ");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$row || !isset(PHOTO_MIMES[$row['mime']]) || !preg_match('/^[a-f0-9]{40}$/', $row['file_name'])) {
                http_response_code(404); exit;
            }
            $owner_id = (int)$row['user_id'];
            $mine = $owner_id === $user_id;
            if (!$mine && (int)($row['is_public'] ?? 0) !== 1) {   // закрытое — только владельцу
                http_response_code(404); exit;
            }
            $blob = @file_get_contents($photo_dir . '/' . $row['file_name'] . '.bin');
            $plain = $blob === false ? null : photoDecrypt($blob, 'p' . $owner_id);
            if ($plain === null) { http_response_code(404); exit; }
            header('Content-Type: ' . $row['mime']);
            header('Content-Length: ' . strlen($plain));
            header('X-Content-Type-Options: nosniff');
            header("Content-Security-Policy: default-src 'none'; sandbox");
            header($mine ? 'Cache-Control: private, max-age=86400' : 'Cache-Control: private, no-store');
            echo $plain;
            exit;
        }

        // ---- загрузка (можно сразу в альбом) ----
        if ($api === 'upload' && $is_post) {
            if (empty($_FILES['photos'])) {
                photoJson(['ok' => false, 'error' => 'Файлы не получены. Проверьте upload_max_filesize и post_max_size в php.ini'], 400);
            }
            $album_id = (int)($_POST['album_id'] ?? 0);
            if ($album_id > 0 && !albumOwned($conn, $album_id, $user_id)) $album_id = 0;
            $album_sql = $album_id > 0 ? $album_id : null;

            $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM photos WHERE user_id = ?");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $have = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
            $stmt->close();

            $f = $_FILES['photos'];
            $names = is_array($f['name']) ? $f['name'] : [$f['name']];
            $count = min(count($names), PHOTO_MAX_PER_REQUEST);
            $added = [];
            $errors = [];
            $finfo = new finfo(FILEINFO_MIME_TYPE);

            for ($i = 0; $i < $count; $i++) {
                $orig = (string)$names[$i];
                $err  = is_array($f['error']) ? $f['error'][$i] : $f['error'];
                $tmp  = is_array($f['tmp_name']) ? $f['tmp_name'][$i] : $f['tmp_name'];

                if ($have + count($added) >= PHOTO_MAX_TOTAL) { $errors[] = "$orig: достигнут лимит фото"; break; }
                if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) { $errors[] = "$orig: файл слишком большой"; continue; }
                if ($err !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)) { $errors[] = "$orig: ошибка загрузки"; continue; }

                $size = (int)filesize($tmp);
                if ($size <= 0 || $size > PHOTO_MAX_BYTES) { $errors[] = "$orig: размер больше 15 МБ"; continue; }

                $mime = $finfo->file($tmp);
                if (!isset(PHOTO_MIMES[$mime])) { $errors[] = "$orig: формат не поддерживается"; continue; }

                $info = @getimagesize($tmp);
                if (!$info || $info[0] < 1 || $info[1] < 1) { $errors[] = "$orig: это не изображение"; continue; }

                $plain = file_get_contents($tmp);
                if ($plain === false) { $errors[] = "$orig: не удалось прочитать"; continue; }

                $title = trim(preg_replace('/\.[A-Za-z0-9]{1,5}$/', '', basename($orig)));
                $title = mb_substr($title !== '' ? $title : 'Фото', 0, 120, 'UTF-8');

                $file_name = bin2hex(random_bytes(20));
                $path = $photo_dir . '/' . $file_name . '.bin';
                $enc  = photoEncrypt($plain, 'p' . $user_id);
                if (@file_put_contents($path, $enc, LOCK_EX) === false) { $errors[] = "$orig: не удалось сохранить"; continue; }
                @chmod($path, 0600);
                $title_enc = base64_encode(photoEncrypt($title, 't' . $user_id));

                $w = (int)$info[0]; $h = (int)$info[1];
                $stmt = $conn->prepare("INSERT INTO photos (user_id, title_enc, mime, size, width, height, file_name, album_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param('issiiisi', $user_id, $title_enc, $mime, $size, $w, $h, $file_name, $album_sql);
                if (!$stmt->execute()) {
                    $stmt->close();
                    @unlink($path);
                    $errors[] = "$orig: ошибка базы данных";
                    continue;
                }
                $new_id = (int)$stmt->insert_id;
                $stmt->close();
                $added[] = ['id' => $new_id, 'title' => $title, 'w' => $w, 'h' => $h, 'size' => $size,
                            'created' => date('Y-m-d H:i:s'), 'album' => $album_sql];
            }
            photoJson(['ok' => true, 'items' => $added, 'errors' => $errors]);
        }

        // ---- удаление фото ----
        if ($api === 'delete' && $is_post) {
            $id = (int)($_POST['id'] ?? 0);
            $stmt = $conn->prepare("SELECT file_name FROM photos WHERE id = ? AND user_id = ? LIMIT 1");
            $stmt->bind_param('ii', $id, $user_id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$row) photoJson(['ok' => false, 'error' => 'Фото не найдено'], 404);
            $stmt = $conn->prepare("DELETE FROM photos WHERE id = ? AND user_id = ?");
            $stmt->bind_param('ii', $id, $user_id);
            $stmt->execute();
            $stmt->close();
            if (preg_match('/^[a-f0-9]{40}$/', $row['file_name'])) {
                @unlink($photo_dir . '/' . $row['file_name'] . '.bin');
            }
            photoJson(['ok' => true]);
        }

        // ---- создать альбом ----
        if ($api === 'album_create' && $is_post) {
            $title = trim((string)($_POST['title'] ?? ''));
            $title = mb_substr($title, 0, 80, 'UTF-8');
            if ($title === '') photoJson(['ok' => false, 'error' => 'Введите название альбома'], 400);
            $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM photo_albums WHERE user_id = ?");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $have = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
            $stmt->close();
            if ($have >= 200) photoJson(['ok' => false, 'error' => 'Достигнут лимит альбомов'], 400);

            $public = !empty($_POST['public']) ? 1 : 0;
            $title_enc = base64_encode(photoEncrypt($title, 'a' . $user_id));
            $stmt = $conn->prepare("INSERT INTO photo_albums (user_id, title_enc, is_public) VALUES (?, ?, ?)");
            $stmt->bind_param('isi', $user_id, $title_enc, $public);
            $stmt->execute();
            $new_id = (int)$stmt->insert_id;
            $stmt->close();
            photoJson(['ok' => true, 'album' => [
                'id' => $new_id, 'title' => $title, 'public' => $public === 1,
                'count' => 0, 'cover' => null, 'user' => $user_id, 'owner' => $username,
            ]]);
        }

        // ---- изменить альбом: название и/или доступ ----
        if ($api === 'album_update' && $is_post) {
            $aid = (int)($_POST['id'] ?? 0);
            $a = albumOwned($conn, $aid, $user_id);
            if (!$a) photoJson(['ok' => false, 'error' => 'Альбом не найден'], 404);

            $title_enc = $a['title_enc'];
            if (isset($_POST['title'])) {
                $title = mb_substr(trim((string)$_POST['title']), 0, 80, 'UTF-8');
                if ($title === '') photoJson(['ok' => false, 'error' => 'Введите название альбома'], 400);
                $title_enc = base64_encode(photoEncrypt($title, 'a' . $user_id));
            }
            $public = isset($_POST['public']) ? (!empty($_POST['public']) ? 1 : 0) : (int)$a['is_public'];
            $stmt = $conn->prepare("UPDATE photo_albums SET title_enc = ?, is_public = ? WHERE id = ? AND user_id = ?");
            $stmt->bind_param('siii', $title_enc, $public, $aid, $user_id);
            $stmt->execute();
            $stmt->close();
            $a['title_enc'] = $title_enc;
            $a['is_public'] = $public;
            photoJson(['ok' => true, 'album' => albumOut($a)]);
        }

        // ---- удалить альбом (фото остаются в «Все фото») ----
        if ($api === 'album_delete' && $is_post) {
            $aid = (int)($_POST['id'] ?? 0);
            if (!albumOwned($conn, $aid, $user_id)) photoJson(['ok' => false, 'error' => 'Альбом не найден'], 404);
            $stmt = $conn->prepare("UPDATE photos SET album_id = NULL WHERE album_id = ? AND user_id = ?");
            $stmt->bind_param('ii', $aid, $user_id);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("DELETE FROM photo_albums WHERE id = ? AND user_id = ?");
            $stmt->bind_param('ii', $aid, $user_id);
            $stmt->execute();
            $stmt->close();
            photoJson(['ok' => true]);
        }

        // ---- переместить фото в альбом (album = 0 — убрать из альбома) ----
        if ($api === 'photo_move' && $is_post) {
            $ids = array_values(array_unique(array_filter(array_map('intval', explode(',', (string)($_POST['ids'] ?? ''))))));
            $ids = array_slice($ids, 0, 200);
            $album = (int)($_POST['album'] ?? 0);
            if ($album > 0 && !albumOwned($conn, $album, $user_id)) photoJson(['ok' => false, 'error' => 'Альбом не найден'], 404);
            $album_sql = $album > 0 ? $album : null;
            $moved = [];
            $stmt = $conn->prepare("UPDATE photos SET album_id = ? WHERE id = ? AND user_id = ?");
            foreach ($ids as $pid) {
                $stmt->bind_param('iii', $album_sql, $pid, $user_id);
                $stmt->execute();
                if ($stmt->affected_rows >= 0) $moved[] = $pid;
            }
            $stmt->close();
            photoJson(['ok' => true, 'moved' => $moved, 'album' => $album_sql]);
        }

        photoJson(['ok' => false, 'error' => 'Неизвестный запрос'], 400);
    } catch (Throwable $e) {
        error_log('photos.php api: ' . $e->getMessage());
        photoJson(['ok' => false, 'error' => 'Внутренняя ошибка сервера'], 500);
    }
}

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: photos.php");
    exit;
}

$notifications = [];
$notif_count = 0;
$unread_count = 0;
$pending_reports_count = 0;
$current_user_data = [];

try {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM messages WHERE receiver_id = ? AND sender_id <> ? AND is_read = 0");
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $unread_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT id, username, avatar, status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    if ($is_admin) {
        $result = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
        if ($result) {
            $pending_reports_count = (int)$result->fetch_assoc()['c'];
        }
    }
} catch (Throwable $e) {
    error_log('photos.php shell: ' . $e->getMessage());
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function isOnline(?string $status): bool {
    return $status === 'online';
}


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Фото</title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/media.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/media.css') ?>">
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main>
            <div class="md-page md-wrap" data-md-kind="photo">

                <section class="md-hero">
                    <div class="md-hero-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5.2-5.2a1.5 1.5 0 0 0-2.1 0L5 19"/></svg></div>
                    <div class="md-hero-text">
                        <h1 id="mdTitle">Фото</h1>
                        <p id="mdSub">Ваши снимки в одном месте. Перетащите файлы в окно или выберите их на компьютере.</p>
                    </div>
                    <label class="md-btn md-owner-only" id="mdHeroUpload" for="mdInput"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M5 20h14"/></svg>Выбрать фото</label>
                </section>

                <input type="file" id="mdInput" accept="image/*" multiple hidden>

                <div class="md-tabs md-owner-only" id="mdTabs">
                    <button type="button" data-tab="all" class="active">Все фото</button>
                    <button type="button" data-tab="albums">Альбомы</button>
                </div>

                <div class="md-ahead" id="mdAhead" hidden>
                    <button type="button" class="md-btn ghost" id="mdBack">← Альбомы</button>
                    <div class="md-ahead-info">
                        <h2 id="mdATitle"></h2>
                        <div class="md-ahead-meta">
                            <span class="md-badge" id="mdABadge"></span>
                            <span id="mdAMeta"></span>
                        </div>
                    </div>
                    <div class="md-ahead-actions md-owner-only">
                        <button type="button" class="md-btn ghost" id="mdAToggle"></button>
                        <button type="button" class="md-btn ghost" id="mdACopy">Ссылка</button>
                        <button type="button" class="md-btn ghost" id="mdAAdd">Добавить фото</button>
                        <button type="button" class="md-btn ghost" id="mdARename">Изменить</button>
                        <button type="button" class="md-btn ghost danger" id="mdADel">Удалить</button>
                    </div>
                </div>

                <div class="md-albums" id="mdAlbums" hidden></div>

                <div class="md-toolbar" id="mdToolbar" hidden>
                    <div class="md-count" id="mdCount">0</div>
                    <div class="md-seg" role="group" aria-label="Размер"><button type="button" data-size="s">Мелко</button><button type="button" data-size="m" class="active">Средне</button><button type="button" data-size="l">Крупно</button></div>
                </div>

                <div class="md-drop" id="mdDrop">
                    <div class="md-drop-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5.2-5.2a1.5 1.5 0 0 0-2.1 0L5 19"/></svg></div>
                    <strong>Перетащите фото сюда</strong>
                    <small>JPG, PNG, GIF, WebP — сколько угодно файлов</small>
                    <label class="md-btn" for="mdInput"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M5 20h14"/></svg>Выбрать фото</label>
                </div>

                <div class="md-grid" id="mdGrid" data-size="m" hidden></div>

                <p class="md-note" id="mdNote">🔒 Фото хранятся на сервере в зашифрованном виде (AES-256-GCM). Закрытые альбомы видите только вы, открытые — все пользователи сайта.</p>
            </div>
        </main>
    </div>

    <div class="md-modal" id="mdModal"><div class="md-modal-card" id="mdModalCard"></div></div>

    <div class="md-viewer" id="mdViewer" aria-hidden="true">
        <button type="button" class="md-vbtn close" aria-label="Закрыть">✕</button>
        <button type="button" class="md-vbtn prev" aria-label="Назад">‹</button>
        <div class="md-viewer-stage" id="mdStage"></div>
        <button type="button" class="md-vbtn next" aria-label="Вперёд">›</button>
        <div class="md-vcap" id="mdVcap"></div>
    </div>

    <script src="assets/js/script.js"></script>
    <script>
        window.PHOTOS_CFG = {
            api: 'photos.php',
            csrf: <?= json_encode($photos_csrf) ?>,
            me: <?= (int)$user_id ?>,
            openAlbum: <?= (int)($_GET['album'] ?? 0) ?>,
            openUser: <?= (int)($_GET['user'] ?? 0) ?>
        };
    </script>
    <script src="assets/js/photos.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/photos.js') ?>"></script>

</body>
</html>
<?php
$conn->close();

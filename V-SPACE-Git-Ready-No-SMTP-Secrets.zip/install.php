<?php

require_once __DIR__ . '/includes/db.php';
// Installation must never be reachable through the public web root.
http_response_code(404);
exit('Not found');

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

echo "🔄 Выполняем обновление базы данных...<br><br>";

// 1. Добавляем поле is_hidden
$sql1 = "ALTER TABLE messages ADD COLUMN is_hidden TINYINT(1) DEFAULT 0";
if ($conn->query($sql1) === TRUE) {
    echo "✅ Поле 'is_hidden' добавлено<br>";
} else {
    if (strpos($conn->error, "Duplicate column name") !== false) {
        echo "ℹ️ Поле 'is_hidden' уже существует<br>";
    } else {
        echo "❌ Ошибка: " . $conn->error . "<br>";
    }
}

// 2. Добавляем поле moderator_id
$sql2 = "ALTER TABLE messages ADD COLUMN moderator_id INT DEFAULT NULL";
if ($conn->query($sql2) === TRUE) {
    echo "✅ Поле 'moderator_id' добавлено<br>";
} else {
    if (strpos($conn->error, "Duplicate column name") !== false) {
        echo "ℹ️ Поле 'moderator_id' уже существует<br>";
    } else {
        echo "❌ Ошибка: " . $conn->error . "<br>";
    }
}

// 3. Добавляем поле is_admin в таблицу users (если ещё нет)
$sql3 = "ALTER TABLE users ADD COLUMN is_admin TINYINT(1) DEFAULT 0";
if ($conn->query($sql3) === TRUE) {
    echo "✅ Поле 'is_admin' добавлено в users<br>";
} else {
    if (strpos($conn->error, "Duplicate column name") !== false) {
        echo "ℹ️ Поле 'is_admin' уже существует<br>";
    } else {
        echo "❌ Ошибка: " . $conn->error . "<br>";
    }
}

// 4. Создаём таблицу reports (если ещё нет)
$sql4 = "CREATE TABLE IF NOT EXISTS reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message_id INT NOT NULL,
    reporter_id INT NOT NULL,
    reported_user_id INT NOT NULL,
    reason VARCHAR(50) NOT NULL,
    comment TEXT,
    status ENUM('pending', 'reviewed', 'resolved', 'rejected') DEFAULT 'pending',
    moderator_comment TEXT,
    moderator_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (status),
    INDEX (message_id),
    INDEX (reporter_id),
    INDEX (reported_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($sql4) === TRUE) {
    echo "✅ Таблица 'reports' создана<br>";
} else {
    echo "❌ Ошибка: " . $conn->error . "<br>";
}

// 5. Делаем первого пользователя админом (по желанию)
$sql5 = "UPDATE users SET is_admin = 1 WHERE id = 1";
if ($conn->query($sql5) === TRUE) {
    echo "✅ Пользователь с ID=1 назначен администратором<br>";
} else {
    echo "❌ Ошибка: " . $conn->error . "<br>";
}

echo "<br>🎉 Обновление завершено!<br>";
echo "⚠️ <strong>Удалите этот файл (install.php) после использования!</strong>";

$conn->close();
?>
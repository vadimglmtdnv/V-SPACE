<?php
// Public-safe mail configuration.
// SMTP credentials must be supplied through local environment variables or an ignored .env file.
// Never commit real email addresses used for authentication, app passwords, or API keys.

require_once __DIR__ . '/includes/env.php';

return [
    'default_provider' => 'default',
    'providers' => [
        'default' => [
            'host'       => (string)env('MAIL_HOST', ''),
            'port'       => (int)env('MAIL_PORT', '587'),
            'username'   => (string)env('MAIL_USER', ''),
            'password'   => (string)env('MAIL_PASS', ''),
            'encryption' => (string)env('MAIL_ENCRYPTION', 'tls'),
        ],
        'mailru' => [
            'host'       => 'smtp.mail.ru',
            'port'       => 465,
            'username'   => (string)env('MAIL_MAILRU_USER', ''),
            'password'   => (string)env('MAIL_MAILRU_PASS', ''),
            'encryption' => 'ssl',
        ],
        'gmail' => [
            'host'       => 'smtp.gmail.com',
            'port'       => 465,
            'username'   => (string)env('MAIL_GMAIL_USER', ''),
            'password'   => (string)env('MAIL_GMAIL_PASS', ''),
            'encryption' => 'ssl',
        ],
        'yandex' => [
            'host'       => 'smtp.yandex.ru',
            'port'       => 465,
            'username'   => (string)env('MAIL_YANDEX_USER', ''),
            'password'   => (string)env('MAIL_YANDEX_PASS', ''),
            'encryption' => 'ssl',
        ],
    ],
];

<?php

require_once __DIR__ . '/includes/db.php';
// fix_reports.php — миграция таблицы reports. Выполнить один раз, затем удалить
// (внизу страницы есть кнопка «Удалить этот файл»).

require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
if (is_file(__DIR__ . '/includes/error_logger.php')) {
    require_once __DIR__ . '/includes/error_logger.php';
}

$conn = db_connect();
if ($conn->connect_error) {
    die("Ошибка подключения к БД.");
}
$conn->set_charset("utf8mb4");

function h($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* ---------- Доступ только для администратора ---------- */

$user_id = (int)($_SESSION['user_id'] ?? 0);
if ($user_id <= 0) {
    header('Location: login.php');
    exit;
}
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$is_admin = !empty($stmt->get_result()->fetch_assoc()['is_admin']);
$stmt->close();

if (!$is_admin) {
    http_response_code(403);
    die("Доступ запрещён: скрипт доступен только администратору.");
}

/* ---------- Удаление файла после выполнения ---------- */

if (empty($_SESSION['fix_reports_token'])) {
    $_SESSION['fix_reports_token'] = bin2hex(random_bytes(16));
}
$deleted = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && ($_POST['action'] ?? '') === 'delete_self'
    && hash_equals($_SESSION['fix_reports_token'], (string)($_POST['token'] ?? ''))) {
    $conn->close();
    if (@unlink(__FILE__)) {
        header('Location: reports.php');
        exit;
    }
    $deleted = false;
    $delete_failed = true;
}

/* ---------- Вспомогательные функции ---------- */

function column_exists(mysqli $conn, string $table, string $column): bool
{
    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE '" . $conn->real_escape_string($column) . "'");
    return $res && $res->num_rows > 0;
}

/** Добавляет колонку, если её ещё нет. Возвращает [класс, сообщение]. */
function add_column(mysqli $conn, string $table, string $column, string $definition): array
{
    try {
        if (column_exists($conn, $table, $column)) {
            return ['info', "ℹ️ Поле '$column' уже существует"];
        }
        $conn->query("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
        return ['success', "✅ Поле '$column' успешно добавлено"];
    } catch (Throwable $e) {
        // В PHP 8.1+ mysqli сам бросает исключения — ловим их тут
        return ['error', "❌ Ошибка: " . h($e->getMessage())];
    }
}

?><!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Исправление таблицы reports</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #313338; color: #dbdee1; padding: 40px; max-width: 800px; margin: 0 auto; }
        .container { background: #1e1f22; padding: 30px; border-radius: 12px; border: 1px solid #2b2d31; }
        h1 { color: #ffffff; margin-top: 0; }
        .success { color: #23a55a; }
        .error { color: #da373c; }
        .info { color: #f0b232; }
        .warning { color: #da373c; font-weight: bold; margin-top: 20px; padding: 10px; background: rgba(218, 55, 60, 0.1); border-radius: 8px; border-left: 4px solid #da373c; }
        .log { margin: 8px 0; padding: 6px 12px; background: #2b2d31; border-radius: 6px; font-family: monospace; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #2b2d31; text-align: left; }
        th, td { padding: 6px 12px; border: 1px solid #2b2d31; }
        .btn { display: inline-block; padding: 10px 24px; background: #5865f2; color: #fff; text-decoration: none; border: none; border-radius: 8px; font-weight: 500; font-size: 14px; cursor: pointer; }
        .btn.danger { background: #da373c; }
        .actions { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; margin-top: 16px; }
    </style>
</head>
<body>
<div class="container">
    <h1>🛠️ Исправление таблицы reports</h1>
    <hr style="border-color:#2b2d31;">
    <p><strong>Подключение к БД:</strong> ✅ Успешно</p>

<?php
$tableCheck = $conn->query("SHOW TABLES LIKE 'reports'");
if (!$tableCheck || $tableCheck->num_rows === 0) {
    echo "<div class='log error'>❌ Таблица 'reports' не найдена. Сначала создайте её.</div></div></body></html>";
    exit;
}

$columns = [
    'moderator_id'      => 'INT DEFAULT NULL',
    'moderator_comment' => 'TEXT DEFAULT NULL',
    'updated_at'        => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
];

$step = 1;
foreach ($columns as $name => $definition) {
    echo "<h3>$step. Добавление поля " . h($name) . "</h3>";
    [$cls, $msg] = add_column($conn, 'reports', $name, $definition);
    echo "<div class='log $cls'>$msg</div>";
    $step++;
}

echo "<h3>$step. Структура таблицы reports</h3>";
$step++;
$newFields = array_keys($columns);
if ($result = $conn->query("DESCRIBE reports")) {
    echo "<table><tr><th>Поле</th><th>Тип</th><th>Null</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $bg = in_array($row['Field'], $newFields, true) ? 'rgba(35,165,90,0.15)' : 'transparent';
        echo "<tr style='background:$bg'>"
            . "<td>" . h($row['Field']) . "</td>"
            . "<td>" . h($row['Type']) . "</td>"
            . "<td>" . h($row['Null']) . "</td>"
            . "<td>" . h($row['Default'] ?? 'NULL') . "</td></tr>";
    }
    echo "</table>";
    $result->close();
}

echo "<h3>$step. Статистика</h3>";
if ($result = $conn->query("SELECT COUNT(*) AS total FROM reports")) {
    echo "<div class='log info'>📊 Всего жалоб в базе: " . (int)$result->fetch_assoc()['total'] . "</div>";
    $result->close();
}

$status_labels = [
    'pending'  => '⏳ В ожидании',
    'reviewed' => '👀 Просмотрена',
    'resolved' => '✅ Решена',
    'rejected' => '❌ Отклонена',
];
if (($result = $conn->query("SELECT status, COUNT(*) AS cnt FROM reports GROUP BY status")) && $result->num_rows > 0) {
    echo "<div class='log info'>📊 Жалобы по статусам:</div>";
    while ($row = $result->fetch_assoc()) {
        $label = $status_labels[$row['status']] ?? $row['status'];
        echo "<div class='log' style='margin-left:20px;'>• " . h($label) . ": " . (int)$row['cnt'] . "</div>";
    }
    $result->close();
}
$conn->close();
?>

    <hr style="border-color:#2b2d31; margin:20px 0;">
    <div class="warning">⚠️ <strong>ВАЖНО!</strong> Удалите этот файл (fix_reports.php) после использования!</div>
<?php if (!empty($delete_failed)): ?>
    <div class="log error">❌ Не удалось удалить файл автоматически — удалите его вручную.</div>
<?php endif; ?>

    <div class="actions">
        <a href="reports.php" class="btn">Перейти в панель модерации →</a>
        <form method="POST" onsubmit="return confirm('Удалить fix_reports.php?');" style="margin:0;">
            <input type="hidden" name="action" value="delete_self">
            <input type="hidden" name="token" value="<?= h($_SESSION['fix_reports_token']) ?>">
            <button type="submit" class="btn danger">🗑️ Удалить этот файл</button>
        </form>
    </div>
</div>
</body>
</html>

<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

define('MAX_AUDIO_SIZE', 25 * 1024 * 1024);
define('UPLOAD_DIR', 'uploads/audio/');

// ============================================================
// ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ
// ============================================================
function formatSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 1) . ' ГБ';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 1) . ' МБ';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 1) . ' КБ';
    }
    return $bytes . ' Б';
}

// ============================================================
// ФУНКЦИЯ ДЛЯ ГЕНЕРАЦИИ WAVEFORM ИЗ АУДИО (УЛУЧШЕННАЯ)
// ============================================================
function generateWaveformFromAudio($audioPath, $points = 50) {
    // Проверяем, что файл существует
    if (!file_exists($audioPath)) {
        return null;
    }

    // Проверяем наличие FFmpeg
    $ffmpegPath = 'ffmpeg';
    
    // Пробуем получить данные через ffmpeg
    $cmd = $ffmpegPath . ' -i ' . escapeshellarg($audioPath) . ' -af "volumedetect" -f null NUL 2>&1';
    exec($cmd, $output, $returnCode);
    
    if ($returnCode !== 0) {
        // Если ffmpeg не доступен, пробуем другой способ
        return generateWaveformFromAudioFile($audioPath, $points);
    }
    
    // Парсим вывод ffmpeg для получения RMS значений
    $waveform = [];
    $rmsValues = [];
    
    foreach ($output as $line) {
        if (preg_match('/mean_volume:\s*([-\d.]+)/', $line, $matches)) {
            $rmsValues[] = (float)$matches[1];
        }
    }
    
    if (count($rmsValues) > 0) {
        // Нормализуем значения
        $minVal = min($rmsValues);
        $maxVal = max($rmsValues);
        $range = $maxVal - $minVal;
        
        if ($range > 0) {
            foreach ($rmsValues as $val) {
                // Нормализуем в диапазон 0-1
                $normalized = ($val - $minVal) / $range;
                $normalized = max(0.05, min(0.95, $normalized));
                $waveform[] = round($normalized, 4);
            }
        }
        
        // Если точек слишком много, берем только нужное количество
        if (count($waveform) > $points) {
            $step = count($waveform) / $points;
            $compressed = [];
            for ($i = 0; $i < $points; $i++) {
                $index = min(floor($i * $step), count($waveform) - 1);
                $compressed[] = $waveform[$index];
            }
            $waveform = $compressed;
        }
    }
    
    // Если не удалось получить данные, генерируем из файла
    if (count($waveform) < $points / 2) {
        return generateWaveformFromAudioFile($audioPath, $points);
    }
    
    return $waveform;
}

// ============================================================
// ФУНКЦИЯ ДЛЯ ГЕНЕРАЦИИ WAVEFORM ИЗ АУДИОФАЙЛА (BLOB)
// ============================================================
function generateWaveformFromAudioFile($audioPath, $points = 50) {
    // Пытаемся прочитать файл и создать простую волну
    if (!file_exists($audioPath)) {
        return generateRandomWaveform($points);
    }
    
    $fileSize = filesize($audioPath);
    if ($fileSize < 1024) {
        return generateRandomWaveform($points);
    }
    
    // Читаем файл частями для создания волны
    $handle = fopen($audioPath, 'rb');
    if (!$handle) {
        return generateRandomWaveform($points);
    }
    
    $chunkSize = min(4096, floor($fileSize / $points));
    if ($chunkSize < 64) {
        $chunkSize = 64;
    }
    
    $waveform = [];
    $totalChunks = 0;
    
    while (!feof($handle) && count($waveform) < $points) {
        $chunk = fread($handle, $chunkSize);
        if ($chunk === false || strlen($chunk) === 0) break;
        
        // Анализируем chunk (простой анализ амплитуды)
        $bytes = unpack('C*', $chunk);
        if ($bytes === false) continue;
        
        $sum = 0;
        $count = count($bytes);
        if ($count === 0) continue;
        
        foreach ($bytes as $byte) {
            $sum += abs($byte - 128);
        }
        
        $avg = $sum / $count;
        $normalized = $avg / 128;
        $normalized = max(0.05, min(0.95, $normalized));
        $waveform[] = round($normalized, 4);
        $totalChunks++;
    }
    
    fclose($handle);
    
    // Если получилось слишком мало точек, генерируем случайную волну
    if (count($waveform) < $points / 2) {
        return generateRandomWaveform($points);
    }
    
    // Если точек слишком много, сжимаем
    if (count($waveform) > $points) {
        $step = count($waveform) / $points;
        $compressed = [];
        for ($i = 0; $i < $points; $i++) {
            $index = min(floor($i * $step), count($waveform) - 1);
            $compressed[] = $waveform[$index];
        }
        $waveform = $compressed;
    }
    
    return $waveform;
}

// ============================================================
// ФУНКЦИЯ ДЛЯ ГЕНЕРАЦИИ РЕАЛИСТИЧНОЙ СЛУЧАЙНОЙ ВОЛНЫ
// ============================================================
function generateRandomWaveform($points = 50) {
    $waveform = [];
    // Создаем плавную волну с помощью синусоиды + случайность
    for ($i = 0; $i < $points; $i++) {
        // Используем синусоиду для плавности
        $base = 0.4 + sin($i / 4) * 0.3;
        // Добавляем случайность для реалистичности
        $noise = (mt_rand() / mt_getrandmax()) * 0.3;
        $value = $base + $noise;
        $value = max(0.1, min(0.9, $value));
        $waveform[] = round($value, 4);
    }
    return $waveform;
}

// ============================================================
// ФУНКЦИЯ ДЛЯ ПОЛУЧЕНИЯ ДЛИТЕЛЬНОСТИ АУДИО (УЛУЧШЕННАЯ)
// ============================================================
function getAudioDuration($audioPath) {
    if (!file_exists($audioPath)) {
        return 0;
    }
    
    // Пробуем через ffmpeg
    if (function_exists('exec')) {
        $ffmpegPath = 'ffmpeg';
        $cmd = $ffmpegPath . ' -i ' . escapeshellarg($audioPath) . ' 2>&1';
        exec($cmd, $output, $returnCode);
        
        // Ищем длительность в выводе
        foreach ($output as $line) {
            if (preg_match('/Duration:\s*(\d{2}):(\d{2}):(\d{2}\.\d+)/', $line, $matches)) {
                $hours = (int)$matches[1];
                $minutes = (int)$matches[2];
                $seconds = (float)$matches[3];
                return (int)($hours * 3600 + $minutes * 60 + $seconds);
            }
        }
    }
    
    // Пробуем через getID3, если установлен
    if (function_exists('getid3')) {
        try {
            $getID3 = new getID3();
            $fileInfo = $getID3->analyze($audioPath);
            if (isset($fileInfo['playtime_seconds'])) {
                return (int)$fileInfo['playtime_seconds'];
            }
        } catch (Exception $e) {}
    }
    
    // Если не удалось определить, возвращаем 0
    return 0;
}

// ============================================================
// ФУНКЦИЯ ДЛЯ ПРОВЕРКИ И СОЗДАНИЯ КОЛОНКИ WAVEFORM
// ============================================================
function ensureWaveformColumn($conn) {
    try {
        $check = $conn->query("SHOW COLUMNS FROM voice_messages LIKE 'waveform'");
        if ($check && $check->num_rows === 0) {
            $conn->query("ALTER TABLE voice_messages ADD COLUMN waveform JSON NULL AFTER duration");
            return true;
        }
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// ============================================================
// АУТЕНТИФИКАЦИЯ
// ============================================================
if (!isset($_SESSION["user_id"])) {
    http_response_code(401);
    echo json_encode(['error' => 'Не авторизован']);
    exit;
}

$user_id = (int)$_SESSION["user_id"];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Метод не разрешён']);
    exit;
}

$conn = db_connect();

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Ошибка подключения к БД']);
    exit;
}

$conn->set_charset("utf8mb4");

// Проверяем и создаем колонку waveform
ensureWaveformColumn($conn);

// ============================================================
// ПРОВЕРЯЕМ AUDIO_DATA
// ============================================================
if (!isset($_POST['audio_data']) || empty($_POST['audio_data'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Нет аудиоданных']);
    exit;
}

$audio_data = $_POST['audio_data'];

// Декодируем base64
$audio_data = preg_replace('/^data:audio\/[^;]+;base64,/', '', $audio_data);
$audio_data = str_replace(' ', '+', $audio_data);
$audio_binary = base64_decode($audio_data);

if ($audio_binary === false) {
    http_response_code(400);
    echo json_encode(['error' => 'Ошибка декодирования аудио']);
    exit;
}

$file_size = strlen($audio_binary);

if ($file_size > MAX_AUDIO_SIZE) {
    http_response_code(400);
    echo json_encode(['error' => 'Аудио слишком большое. Максимум: ' . formatSize(MAX_AUDIO_SIZE)]);
    exit;
}

// ============================================================
// СОХРАНЯЕМ ФАЙЛ
// ============================================================
$filename = 'recording_' . time() . '_' . uniqid() . '.webm';
$filepath = UPLOAD_DIR . $filename;

if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0777, true);
}

if (!file_put_contents($filepath, $audio_binary)) {
    http_response_code(500);
    echo json_encode(['error' => 'Ошибка сохранения файла']);
    exit;
}

// ============================================================
// ПОЛУЧАЕМ ДЛИТЕЛЬНОСТЬ
// ============================================================
$duration = isset($_POST['duration']) ? (int)$_POST['duration'] : 0;

// Если длительность не передана, пытаемся определить
if ($duration <= 0) {
    $duration = getAudioDuration($filepath);
}

// ============================================================
// ОБРАБОТКА WAVEFORM (ВИЗУАЛИЗАЦИЯ ВОЛНЫ)
// ============================================================
$waveform = null;

// Сначала пробуем получить waveform из POST
if (isset($_POST['waveform']) && trim($_POST['waveform']) !== '') {
    $waveform_data = json_decode($_POST['waveform'], true);

    if (json_last_error() === JSON_ERROR_NONE && is_array($waveform_data) && count($waveform_data) > 0) {
        $clean_waveform = [];

        foreach ($waveform_data as $value) {
            $value = (float)$value;
            $value = max(0.05, min(0.95, $value));
            $clean_waveform[] = round($value, 4);
        }

        if (count($clean_waveform) >= 20) {
            $waveform = json_encode($clean_waveform);
        }
    }
}

// Если waveform не получен из POST, генерируем из файла
if ($waveform === null) {
    $generatedWaveform = generateWaveformFromAudio($filepath, 50);
    if ($generatedWaveform !== null && count($generatedWaveform) >= 20) {
        $waveform = json_encode($generatedWaveform);
    }
}

// Если все еще нет waveform, создаем случайную реалистичную волну
if ($waveform === null) {
    $randomWaveform = generateRandomWaveform(50);
    $waveform = json_encode($randomWaveform);
}

// ============================================================
// СОХРАНЯЕМ В БАЗУ ДАННЫХ
// ============================================================
$stmt = $conn->prepare("
    INSERT INTO voice_messages
    (
        user_id,
        file_path,
        duration,
        waveform,
        created_at
    )
    VALUES (?, ?, ?, ?, NOW())
");

if (!$stmt) {
    if (file_exists($filepath)) {
        unlink($filepath);
    }
    http_response_code(500);
    echo json_encode(['error' => 'Ошибка подготовки запроса: ' . $conn->error]);
    exit;
}

$stmt->bind_param("isis", $user_id, $filepath, $duration, $waveform);

if ($stmt->execute()) {
    $voice_id = $stmt->insert_id;
    $decodedWaveform = json_decode($waveform, true);
    
    echo json_encode([
        'success' => true,
        'voice_id' => $voice_id,
        'file_path' => $filepath,
        'duration' => $duration,
        'waveform' => $waveform,
        'waveform_decoded' => $decodedWaveform,
        'waveform_count' => count($decodedWaveform),
        'message' => 'Голосовое сообщение сохранено'
    ]);
} else {
    if (file_exists($filepath)) {
        unlink($filepath);
    }
    http_response_code(500);
    echo json_encode(['error' => 'Ошибка сохранения в БД: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>
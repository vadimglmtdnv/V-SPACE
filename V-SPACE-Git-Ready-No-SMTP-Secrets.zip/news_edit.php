<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

/*
|--------------------------------------------------------------------------
| PLAYERCHAT — Редактирование новости
|--------------------------------------------------------------------------
| Только для администратора
|--------------------------------------------------------------------------
*/

// Проверка авторизации
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

// Проверка прав (только администратор с id=1)
if ($user_id !== 1) {
    header("Location: news.php");
    exit;
}

// CSRF-токен (тот же, что использует лента news.php)
if (empty($_SESSION['csrf_news'])) {
    $_SESSION['csrf_news'] = bin2hex(random_bytes(32));
}
$csrf_token = (string)$_SESSION['csrf_news'];

$news_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($news_id <= 0) {
    header("Location: news.php");
    exit;
}

// Подключение к базе данных
$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// Получаем данные новости
$stmt = $conn->prepare("SELECT id, title, content, image FROM news WHERE id = ?");
$stmt->bind_param("i", $news_id);
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_assoc();
$stmt->close();

if (!$news) {
    header("Location: news.php");
    exit;
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && !hash_equals($csrf_token, (string)($_POST['csrf_token'] ?? ''))) {
    $error = "Недействительный токен формы. Обновите страницу и попробуйте снова.";
} elseif ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"] ?? "");
    $content = trim($_POST["content"] ?? "");
    $image_path = $news['image'];
    $delete_image = isset($_POST["delete_image"]) ? true : false;
    
    if ($title === "" || $content === "") {
        $error = "Заполните все поля.";
    } else {
        // Удаление изображения
        if ($delete_image && !empty($image_path) && file_exists($image_path)) {
            unlink($image_path);
            $image_path = "";
        }
        
        // Обработка загрузки нового изображения
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
            $file = $_FILES["image"];
            $allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_file($finfo, $file["tmp_name"]) : false;
            if ($finfo) {
                finfo_close($finfo);
            }
            $extensions = ["image/jpeg" => "jpg", "image/png" => "png", "image/webp" => "webp", "image/gif" => "gif"];
            $new_name = "news_" . time() . "_" . bin2hex(random_bytes(6)) . "." . ($extensions[$mime] ?? "bin");
            $upload_dir = "uploads/news/";
            
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            if (!isset($extensions[$mime]) || !in_array($mime, $allowed, true)) {
                $error = "Неподдерживаемый формат изображения.";
            } elseif ($file["size"] > 5 * 1024 * 1024) {
                $error = "Изображение слишком большое (макс. 5 МБ).";
            } else {
                // Удаляем старое изображение
                if (!empty($image_path) && file_exists($image_path)) {
                    unlink($image_path);
                }
                $target = $upload_dir . $new_name;
                if (move_uploaded_file($file["tmp_name"], $target)) {
                    $image_path = $target;
                }
            }
        }
        
        if (empty($error)) {
            $stmt = $conn->prepare("
                UPDATE news 
                SET title = ?, content = ?, image = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("sssi", $title, $content, $image_path, $news_id);
            $stmt->execute();
            $stmt->close();
            
            $success = "✅ Новость успешно обновлена!";
        }
    }
}

$conn->close();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактирование новости — PLAYERCHAT</title>
    <link rel="stylesheet" href="style.css">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            background: #313338;
            color: #dbdee1;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .form-container {
            background: #1e1f22;
            border: 1px solid #2b2d31;
            border-radius: 12px;
            padding: 32px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        
        .form-container h1 {
            color: #f2f3f5;
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .form-container .subtitle {
            color: #949ba4;
            font-size: 14px;
            margin-bottom: 24px;
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        .form-group label {
            display: block;
            color: #b5bac1;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            background: #1e1f22;
            border: 1px solid #2b2d31;
            border-radius: 8px;
            outline: none;
            color: #dbdee1;
            font-size: 14px;
            transition: 0.15s;
            font-family: inherit;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #5865f2;
            box-shadow: 0 0 0 3px rgba(88, 101, 242, 0.15);
        }
        
        .form-group textarea {
            height: 150px;
            resize: vertical;
        }
        
        .form-group input[type="file"] {
            padding: 8px 14px;
            cursor: pointer;
        }
        
        .form-group .current-image {
            padding: 10px 14px;
            background: #2b2d31;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .form-group .current-image img {
            max-height: 60px;
            border-radius: 4px;
        }
        
        .form-group .current-image .no-image {
            color: #5c5e64;
        }
        
        .form-group .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 0;
        }
        
        .form-group .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .error {
            background: rgba(242, 63, 66, 0.12);
            border: 1px solid rgba(242, 63, 66, 0.35);
            color: #f23f42;
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 16px;
            font-size: 14px;
        }
        
        .success {
            background: rgba(35, 165, 89, 0.12);
            border: 1px solid rgba(35, 165, 89, 0.35);
            color: #23a559;
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 16px;
            font-size: 14px;
        }
        
        .buttons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        .btn-submit {
            padding: 10px 24px;
            background: #5865f2;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: 0.15s;
        }
        
        .btn-submit:hover {
            background: #4752c4;
        }
        
        .btn-cancel {
            padding: 10px 24px;
            background: #2b2d31;
            color: #dbdee1;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: 0.15s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
        }
        
        .btn-cancel:hover {
            background: #3f4147;
        }
    </style>
</head>
<body>

    <div class="form-container">
        <h1>✏️ Редактировать новость</h1>
        <div class="subtitle">Измените информацию о новости</div>
        
        <?php if (!empty($error)): ?>
            <div class="error"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="success"><?= htmlspecialchars($success, ENT_QUOTES, "UTF-8") ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
            <div class="form-group">
                <label>Заголовок</label>
                <input type="text" name="title" placeholder="Введите заголовок новости" value="<?= htmlspecialchars($_POST["title"] ?? $news['title'], ENT_QUOTES, "UTF-8") ?>" required>
            </div>
            
            <div class="form-group">
                <label>Содержание</label>
                <textarea name="content" placeholder="Введите текст новости..." required><?= htmlspecialchars($_POST["content"] ?? $news['content'], ENT_QUOTES, "UTF-8") ?></textarea>
            </div>
            
            <div class="form-group">
                <label>Текущее изображение</label>
                <div class="current-image">
                    <?php if (!empty($news['image']) && file_exists($news['image'])): ?>
                        <img src="<?= htmlspecialchars($news['image'], ENT_QUOTES, "UTF-8") ?>" alt="">
                        <span style="color:#dbdee1;font-size:13px;"><?= basename($news['image']) ?></span>
                    <?php else: ?>
                        <span class="no-image">📷 Изображение не загружено</span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-group">
                <label>Новое изображение (необязательно)</label>
                <input type="file" name="image" accept="image/*">
                <div class="checkbox-group">
                    <input type="checkbox" name="delete_image" id="delete_image">
                    <label for="delete_image" style="font-size:13px;color:#da373c;cursor:pointer;">🗑️ Удалить текущее изображение</label>
                </div>
            </div>
            
            <div class="buttons">
                <button type="submit" class="btn-submit">💾 Сохранить</button>
                <a href="news.php" class="btn-cancel">← Отмена</a>
            </div>
        </form>
    </div>

</body>
</html>
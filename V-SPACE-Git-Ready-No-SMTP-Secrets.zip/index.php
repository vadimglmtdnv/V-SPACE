<?php

require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
// Если в настройках выбран English — содержимое страницы переводится «на лету» (includes/lang.php)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();
require_once __DIR__ . '/account_state.php';
require_once __DIR__ . '/maintenance.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; img-src 'self' https://cdn.jsdelivr.net data: blob:; style-src 'self' 'unsafe-inline';");
header('Content-Type: text/html; charset=utf-8');

// Имя и фамилия лежат в user_profiles; если колонок ещё нет — создаём их (так же, как в edit.php)
if (!function_exists('ensureProfileNameColumns')) {
    function ensureProfileNameColumns(mysqli $conn): void {
        $conn->query("
            CREATE TABLE IF NOT EXISTS user_profiles (
                id INT(11) NOT NULL AUTO_INCREMENT,
                user_id INT(11) NOT NULL,
                first_name VARCHAR(50) DEFAULT NULL,
                last_name VARCHAR(50) DEFAULT NULL,
                birth_date DATE DEFAULT NULL,
                city VARCHAR(255) DEFAULT NULL,
                bio TEXT DEFAULT NULL,
                website_url VARCHAR(2048) DEFAULT NULL,
                updated_at TIMESTAMP NULL DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY user_id (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $chk = $conn->query("SHOW COLUMNS FROM user_profiles LIKE 'first_name'");
        if ($chk && $chk->num_rows === 0) {
            foreach (['first_name' => 'VARCHAR(50)', 'last_name' => 'VARCHAR(50)', 'birth_date' => 'DATE'] as $col => $def) {
                $c2 = $conn->query("SHOW COLUMNS FROM user_profiles LIKE '" . $col . "'");
                if ($c2 && $c2->num_rows === 0) {
                    $conn->query("ALTER TABLE user_profiles ADD COLUMN " . $col . " " . $def . " DEFAULT NULL");
                }
            }
        }
    }
}

$db_error = '';
$conn = null;

try {
    $conn = db_connect();

    if ($conn->connect_error) {
        throw new Exception("Ошибка подключения: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");
    ensureAccountStateColumns($conn);
    ensureProfileNameColumns($conn);
    require_once __DIR__ . '/account_state.php';

} catch (Exception $e) {
    $db_error = $e->getMessage();
    error_log("MySQL Error: " . $db_error);
}

if (!$conn || $conn->connect_error) {
    // БД недоступна — показываем общую страницу ошибки error.php с кодом 503
    // (текст ошибки MySQL виден там только при заходе с localhost)
    $error_code   = 503;
    $error_text   = 'Не удалось подключиться к базе данных. Попробуйте обновить страницу чуть позже.';
    $error_detail = $db_error;
    require __DIR__ . '/error.php';
    exit;
}

// Определение темы оформления
$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (($_COOKIE['theme'] ?? '') === 'auto') {
    $theme = 'dark';
}

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: index.php");
    exit;
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function formatCommentText(string $comment): string {
    $formatted = htmlspecialchars($comment, ENT_QUOTES, 'UTF-8');
    $formatted = preg_replace_callback(
        '/[\x{1F1E6}-\x{1F1FF}][\x{1F1E6}-\x{1F1FF}]/u',
        static function (array $matches): string {
            $codepoints = [];
            foreach (preg_split('//u', $matches[0], -1, PREG_SPLIT_NO_EMPTY) as $symbol) {
                $codepoints[] = strtolower(dechex(mb_ord($symbol, 'UTF-8')));
            }
            $src = 'https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/svg/'
                . implode('-', $codepoints) . '.svg';
            return '<img class="comment-flag" src="' . $src . '" alt="' . $matches[0] . '">';
        },
        $formatted
    );
    return nl2br($formatted, false);
}

// Создание таблицы уведомлений
$conn->query("
    CREATE TABLE IF NOT EXISTS notifications (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        sender_id INT(11) NULL DEFAULT NULL,
        sender_avatar VARCHAR(255) NULL DEFAULT NULL,
        type VARCHAR(50) NOT NULL,
        message TEXT NOT NULL,
        link VARCHAR(255) NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX user_id (user_id),
        INDEX sender_id (sender_id),
        INDEX is_read (is_read),
        INDEX created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function addNotification(
    mysqli $conn,
    int $user_id,
    string $type,
    string $message,
    ?string $link = null,
    ?int $sender_id = null
): bool {
    $sender_avatar = null;
    if ($sender_id) {
        $stmt = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
        $stmt->bind_param("i", $sender_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $sender_avatar = $row['avatar'];
        }
        $stmt->close();
    }
    
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, sender_id, sender_avatar, type, message, link, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("iissss", $user_id, $sender_id, $sender_avatar, $type, $message, $link);
    return $stmt->execute();
}

// Получение списка уведомлений
$notifications = [];
$notif_count = 0;

if (isset($_SESSION["user_id"])) {
    $user_id = (int)$_SESSION["user_id"];
    
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) as sender_name, u.username as sender_username, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id
        LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC 
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        if (empty($row['sender_avatar']) && !empty($row['sender_id'])) {
            $stmt2 = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
            $stmt2->bind_param("i", $row['sender_id']);
            $stmt2->execute();
            $res2 = $stmt2->get_result();
            if ($user_avatar = $res2->fetch_assoc()) {
                $row['sender_avatar'] = $user_avatar['avatar'];
            }
            $stmt2->close();
        }
        $notifications[] = $row;
    }
    $stmt->close();
    
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notif_count = $result->fetch_assoc()['count'] ?? 0;
    $stmt->close();
}

$notification_count = $notif_count;

$unread_count = 0;
if (isset($_SESSION["user_id"])) {
    $user_id = (int)$_SESSION["user_id"];
    $unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

// Иконки поля комментария (смайлик и «отправить»), общие для всех форм комментариев
$svg_comment_smile = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9.2"/><path d="M8.3 14.2c.9 1.3 2.1 2 3.7 2s2.8-.7 3.7-2"/><circle cx="9" cy="9.7" r=".6" fill="currentColor"/><circle cx="15" cy="9.7" r=".6" fill="currentColor"/></svg>';
$reaction_emojis = ['laugh' => '😆', 'wow' => '😲', 'love' => '😍', 'sad' => '😢', 'angry' => '😡'];
$svg_comment_send  = '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M3.4 20.4 20.85 12.92a1 1 0 0 0 0-1.84L3.4 3.6a1 1 0 0 0-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91z"/></svg>';

// CSRF-токен общий с messages.php (одна сессия) — нужен окну «Поделиться»
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// Адрес профиля: /playerchat/<ник или номер аккаунта>.
// Ник пользователь задаёт в edit.php; пока ника нет — адрес просто номер (/playerchat/1).
// ============================================
$handle_col = $conn->query("SHOW COLUMNS FROM users LIKE 'handle'");
if ($handle_col && $handle_col->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN handle VARCHAR(32) DEFAULT NULL, ADD UNIQUE KEY handle (handle)");
}

// Обложка профиля: путь к загруженной картинке (NULL — стандартная космическая обложка)
$cover_col = $conn->query("SHOW COLUMNS FROM users LIKE 'cover'");
if ($cover_col && $cover_col->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN cover VARCHAR(255) DEFAULT NULL");
}
// Рамка обложки: «x центр_y ширина» — доли картинки в десятитысячных (0–10000).
// По умолчанию: на всю ширину, по центру.
$cover_crop_col = $conn->query("SHOW COLUMNS FROM users LIKE 'cover_crop'");
if ($cover_crop_col && $cover_crop_col->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN cover_crop VARCHAR(32) DEFAULT NULL");
}

$view_user_id   = 0;
$slug_not_found = false;
$requested_slug = (isset($_GET['user']) && is_string($_GET['user'])) ? trim($_GET['user']) : '';
if ($requested_slug !== '') {
    if (ctype_digit($requested_slug)) {
        $view_user_id = (int)$requested_slug;
    } elseif (preg_match('/^id(\d+)$/i', $requested_slug, $slug_m)) {
        $view_user_id = (int)$slug_m[1];                       // старый вид id123
    } elseif (preg_match('/^[A-Za-z][A-Za-z0-9_]{2,31}$/', $requested_slug)) {
        $slug_lower = strtolower($requested_slug);
        $slug_stmt = $conn->prepare("SELECT id FROM users WHERE handle = ? LIMIT 1");
        $slug_stmt->bind_param("s", $slug_lower);
        $slug_stmt->execute();
        $slug_row = $slug_stmt->get_result()->fetch_assoc();
        $slug_stmt->close();
        if ($slug_row) {
            $view_user_id = (int)$slug_row['id'];
        } else {
            $slug_not_found = true;
        }
    } else {
        $slug_not_found = true;
    }
}

// Как адрес профиля пишется на самом деле: ник, а если его нет — номер аккаунта
$profile_slug_of = static function (int $uid) use ($conn): string {
    $s = $conn->prepare("SELECT handle FROM users WHERE id = ? LIMIT 1");
    $s->bind_param("i", $uid);
    $s->execute();
    $r = $s->get_result()->fetch_assoc();
    $s->close();
    return !empty($r['handle']) ? (string)$r['handle'] : (string)$uid;
};
$profile_base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');

// Любой другой вид адреса (index.php?user=2, /playerchat/id2, /playerchat/Vadim) ведёт на единственный правильный.
// Редирект временный (302): ник можно сменить, и браузер не должен запоминать старый.
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $view_user_id > 0 && $view_user_id <= 90000000) {
    $canonical_slug = $profile_slug_of($view_user_id);
    if ($requested_slug !== $canonical_slug) {
        $pq = $_GET;
        unset($pq['user']);
        header('Location: ' . $profile_base . '/' . rawurlencode($canonical_slug) . ($pq ? '?' . http_build_query($pq) : ''));
        exit;
    }
}

// Голый index.php (без параметров) — свой профиль: /playerchat/vadim или /playerchat/1
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !$_GET && empty($_SERVER['HTTP_X_REQUESTED_WITH']) && $user_id > 0 && $user_id <= 90000000) {
    header('Location: ' . $profile_base . '/' . rawurlencode($profile_slug_of($user_id)));
    exit;
}

if ($view_user_id > 0 && $view_user_id != $user_id) {
    $is_other_profile = true;
    $profile_id = $view_user_id;
} else {
    $is_other_profile = false;
    $profile_id = $user_id;
}

$service_account_ids = [];
$canonical_service_account = $conn->query("SELECT id FROM users WHERE username = 'V SPACE' LIMIT 1");
if ($canonical_service_account && $canonical_service_account->num_rows === 0) {
    $rename_legacy_service = $conn->prepare("UPDATE users SET username = 'V SPACE' WHERE username = 'VS SPACE'");
    if (!$rename_legacy_service->execute()) {
        error_log('Failed to rename legacy VS SPACE service account: ' . $rename_legacy_service->error);
    }
    $rename_legacy_service->close();
}
$service_account_result = $conn->query("SELECT id FROM users WHERE username IN ('V SPACE', 'VS SPACE')");
if ($service_account_result) {
    while ($service_account_row = $service_account_result->fetch_assoc()) {
        $service_account_ids[] = (int)$service_account_row['id'];
    }
}

// ============================================
// Показ ошибок через error.php (код, текст, кнопка возврата)
// ============================================
if (!function_exists('showErrorPage')) {
    function showErrorPage(int $code, string $text = '', string $back = '', string $title = '', string $detail = ''): void
    {
        $error_code = $code;
        if ($title !== '')  { $error_title  = $title; }
        if ($text !== '')   { $error_text   = $text; }
        if ($back !== '')   { $error_back_url = $back; }
        if ($detail !== '') { $error_detail = $detail; }
        require __DIR__ . '/error.php';
        exit;
    }
}

// Номера аккаунтов: от 1 до 90 000 000; неизвестный ник — тоже 404
if ($slug_not_found || $view_user_id > 90000000) {
    showErrorPage(404, 'Такого пользователя нет — номер аккаунта в адресе указан неверно.', 'index.php', 'Профиль не найден');
}

// HTTP 413: тело запроса больше post_max_size — PHP тогда сбрасывает $_POST и $_FILES,
// форма «молча» не срабатывает. Ловим это и показываем страницу ошибки.
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $iniToBytes = static function (string $v): int {
        $v = trim($v);
        if ($v === '') return 0;
        $num = (float)$v;
        switch (strtolower(substr($v, -1))) {
            case 'g': $num *= 1024;
            // no break
            case 'm': $num *= 1024;
            // no break
            case 'k': $num *= 1024;
        }
        return (int)$num;
    };
    $content_length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    $post_max       = $iniToBytes((string)ini_get('post_max_size'));
    if ($post_max > 0 && $content_length > $post_max && empty($_POST) && empty($_FILES)) {
        showErrorPage(413, 'Размер отправленных данных превышает допустимый (' . round($post_max / 1048576, 1) . ' МБ). Выберите файл поменьше.', 'index.php');
    }
}

// ============================================
// ОБРАБОТКА ЗАЯВОК В ДРУЗЬЯ
// ============================================

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["accept_friend"]) && isset($_POST["request_id"])) {
    $request_id = (int)$_POST["request_id"];
    $stmt = $conn->prepare("SELECT sender_id, receiver_id FROM friend_requests WHERE id = ? AND receiver_id = ? AND status = 'pending'");
    $stmt->bind_param("ii", $request_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $request_data = $result->fetch_assoc();
    $stmt->close();
    
    if ($request_data) {
        $stmt = $conn->prepare("UPDATE friend_requests SET status = 'accepted' WHERE id = ?");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $stmt->close();
        
        addNotification($conn, (int)$request_data['sender_id'], 'friend_accepted', 
            'принял(а) вашу заявку в друзья!',
            'index.php?user=' . $user_id,
            $user_id
        );
    }
    
    header("Location: friends.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["decline_friend"]) && isset($_POST["request_id"])) {
    $request_id = (int)$_POST["request_id"];
    $stmt = $conn->prepare("SELECT sender_id, receiver_id FROM friend_requests WHERE id = ? AND receiver_id = ? AND status = 'pending'");
    $stmt->bind_param("ii", $request_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $request_data = $result->fetch_assoc();
    $stmt->close();
    
    if ($request_data) {
        $stmt = $conn->prepare("DELETE FROM friend_requests WHERE id = ?");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $stmt->close();
        
        addNotification($conn, (int)$request_data['sender_id'], 'friend_removed', 
            'отклонил(а) вашу заявку в друзья',
            'index.php?user=' . $user_id,
            $user_id
        );
    }
    
    header("Location: friends.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["remove_friend"]) && isset($_POST["friend_id"])) {
    $friend_id = (int)$_POST["friend_id"];

    $stmt = $conn->prepare("
        DELETE FROM friend_requests 
        WHERE status = 'accepted'
          AND ((sender_id = ? AND receiver_id = ? AND sender_id = ?)
            OR (sender_id = ? AND receiver_id = ? AND receiver_id = ?))
    ");
    $stmt->bind_param("iiiiii", $user_id, $friend_id, $user_id, $friend_id, $user_id, $user_id);
    $stmt->execute();
    $stmt->close();

    addNotification($conn, $friend_id, 'friend_removed', 
        'удалил(а) вас из друзей',
        'index.php?user=' . $user_id,
        $user_id
    );

    header("Location: index.php?user=" . $friend_id);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_friend"]) && isset($_POST["receiver_id"])) {
    $receiver_id = (int)$_POST["receiver_id"];
    if (in_array($user_id, $service_account_ids, true) || in_array($receiver_id, $service_account_ids, true)) {
        header("Location: index.php?user=" . $receiver_id);
        exit;
    }
    
    $stmt = $conn->prepare("
        SELECT id FROM friend_requests 
        WHERE (sender_id = ? AND receiver_id = ?) 
           OR (sender_id = ? AND receiver_id = ?)
    ");
    $stmt->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result->fetch_assoc();
    $stmt->close();
    
    if (!$exists) {
        $stmt = $conn->prepare("
            INSERT INTO friend_requests (sender_id, receiver_id, status, created_at) 
            VALUES (?, ?, 'pending', NOW())
        ");
        $stmt->bind_param("ii", $user_id, $receiver_id);
        $stmt->execute();
        $stmt->close();
        
        addNotification($conn, $receiver_id, 'friend_request', 
            'отправил(а) вам заявку в друзья',
            'friends.php',
            $user_id
        );
    }
    
    header("Location: index.php?user=" . $receiver_id);
    exit;
}

// ============================================
// РЕАКЦИИ НА ПОСТЫ (как «лайк», но с выбором: сердце, смех, удивление, восторг, грусть, злость)
// ============================================

$reaction_col = $conn->query("SHOW COLUMNS FROM post_likes LIKE 'reaction'");
if ($reaction_col && $reaction_col->num_rows === 0) {
    $conn->query("ALTER TABLE post_likes ADD COLUMN reaction VARCHAR(16) NOT NULL DEFAULT 'like' AFTER user_id");
}

// Сколько реакций у поста и кто последним отреагировал (окно реакций при наведении на лайк)
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["post_reactions"])) {
    $react_post_id = (int)$_GET["post_reactions"];
    $out = ['total' => 0, 'users' => []];

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM post_likes WHERE post_id = ?");
    $stmt->bind_param("i", $react_post_id);
    $stmt->execute();
    $out['total'] = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("
        SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, l.reaction
        FROM post_likes l
        INNER JOIN users u ON u.id = l.user_id
        LEFT JOIN user_profiles up ON up.user_id = u.id
        WHERE l.post_id = ?
        ORDER BY l.id DESC
        LIMIT 3
    ");
    $stmt->bind_param("i", $react_post_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) {
        $avatar = (string)($r['avatar'] ?? '');
        $out['users'][] = [
            'id'       => (int)$r['id'],
            'username' => (string)$r['username'],
            'avatar'   => ($avatar !== '' && file_exists($avatar)) ? $avatar : '',
            'reaction' => (string)$r['reaction'],
        ];
    }
    $stmt->close();

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================
// ОБРАБОТКА ЛАЙКОВ
// ============================================

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["toggle_like"]) && isset($_POST["post_id"])) {
    $post_id = (int)$_POST["post_id"];

    // reaction: пусто — обычный клик по кнопке (лайк / снять), иначе выбранная реакция
    $allowed_reactions = ['like', 'laugh', 'wow', 'love', 'sad', 'angry'];
    $reaction = (string)($_POST["reaction"] ?? "");
    if (!in_array($reaction, $allowed_reactions, true)) {
        $reaction = "";
    }
    
    $stmt = $conn->prepare("SELECT id, reaction FROM post_likes WHERE post_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $post_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result->fetch_assoc();
    $stmt->close();
    
    if ($exists && $reaction !== "" && $reaction !== $exists["reaction"]) {
        // выбрали другую реакцию — меняем её, число реакций не меняется
        $stmt = $conn->prepare("UPDATE post_likes SET reaction = ? WHERE id = ?");
        $exists_id = (int)$exists["id"];
        $stmt->bind_param("si", $reaction, $exists_id);
        $stmt->execute();
        $stmt->close();
    } elseif ($exists) {
        $stmt = $conn->prepare("DELETE FROM post_likes WHERE post_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $post_id, $user_id);
        $stmt->execute();
        $stmt->close();
    } else {
        $new_reaction = $reaction !== "" ? $reaction : "like";
        $stmt = $conn->prepare("INSERT INTO post_likes (post_id, user_id, reaction, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $post_id, $user_id, $new_reaction);
        $stmt->execute();
        $stmt->close();
        
        $stmt_post = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
        $stmt_post->bind_param("i", $post_id);
        $stmt_post->execute();
        $result_post = $stmt_post->get_result();
        $post_data = $result_post->fetch_assoc();
        $stmt_post->close();
        
        if ($post_data && $post_data['user_id'] != $user_id) {
            $stmt_user = $conn->prepare("SELECT COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            $user_data = $result_user->fetch_assoc();
            $stmt_user->close();
            
            addNotification($conn, (int)$post_data['user_id'], 'like', 
                $user_data['username'] . ($new_reaction === 'like' ? ' поставил(а) лайк на ваш пост' : ' отреагировал(а) на ваш пост'), 
                'index.php?user=' . $user_id,
                $user_id
            );
        }
    }
    
    header("Location: index.php" . ($view_user_id > 0 ? "?user=" . $view_user_id : ""));
    exit;
}

// ============================================
// ОБРАБОТКА РЕПОСТОВ
// ============================================

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["toggle_repost"]) && isset($_POST["post_id"])) {
    $post_id = (int)$_POST["post_id"];
    
    $stmt = $conn->prepare("SELECT id FROM post_reposts WHERE post_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $post_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result->fetch_assoc();
    $stmt->close();
    
    if ($exists) {
        $stmt = $conn->prepare("DELETE FROM post_reposts WHERE post_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $post_id, $user_id);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = $conn->prepare("INSERT INTO post_reposts (post_id, user_id, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("ii", $post_id, $user_id);
        $stmt->execute();
        $stmt->close();
        
        $stmt_post = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
        $stmt_post->bind_param("i", $post_id);
        $stmt_post->execute();
        $result_post = $stmt_post->get_result();
        $post_data = $result_post->fetch_assoc();
        $stmt_post->close();
        
        if ($post_data && $post_data['user_id'] != $user_id) {
            $stmt_user = $conn->prepare("SELECT COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            $user_data = $result_user->fetch_assoc();
            $stmt_user->close();
            
            addNotification($conn, (int)$post_data['user_id'], 'repost', 
                $user_data['username'] . ' репостнул(а) ваш пост', 
                'index.php?user=' . $user_id,
                $user_id
            );
        }
    }
    
    header("Location: index.php" . ($view_user_id > 0 ? "?user=" . $view_user_id : ""));
    exit;
}

// ============================================
// ОБРАБОТКА КОММЕНТАРИЕВ
// ============================================

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_comment"]) && isset($_POST["post_id"])) {
    $post_id = (int)$_POST["post_id"];
    $comment = trim($_POST["comment"] ?? "");
    
    if ($comment !== "") {
        $stmt = $conn->prepare("INSERT INTO post_comments (post_id, user_id, comment, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $post_id, $user_id, $comment);
        $stmt->execute();
        $stmt->close();
        
        $stmt_post = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
        $stmt_post->bind_param("i", $post_id);
        $stmt_post->execute();
        $result_post = $stmt_post->get_result();
        $post_data = $result_post->fetch_assoc();
        $stmt_post->close();
        
        if ($post_data && $post_data['user_id'] != $user_id) {
            $stmt_user = $conn->prepare("SELECT COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
            $stmt_user->bind_param("i", $user_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            $user_data = $result_user->fetch_assoc();
            $stmt_user->close();
            
            $comment_preview = mb_substr($comment, 0, 50, 'UTF-8');
            addNotification($conn, (int)$post_data['user_id'], 'comment', 
                $user_data['username'] . ' прокомментировал(а) ваш пост: "' . $comment_preview . '"', 
                'index.php?user=' . $user_id,
                $user_id
            );
        }
    }
    
    $redirect_url = "index.php";
    if ($view_user_id > 0) {
        $redirect_url .= "?user=" . $view_user_id;
    }
    header("Location: " . $redirect_url);
    exit;
}

// Права текущего пользователя (а не владельца профиля) — для удаления постов и комментариев
$viewer_is_admin = false;
if ($user_id > 0) {
    $stmt_va = $conn->prepare("SELECT is_admin FROM users WHERE id = ? LIMIT 1");
    $stmt_va->bind_param("i", $user_id);
    $stmt_va->execute();
    $viewer_is_admin = (int)($stmt_va->get_result()->fetch_assoc()['is_admin'] ?? 0) === 1;
    $stmt_va->close();
}

// Удаление — только POST + CSRF-токен
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["delete_comment"]) && is_numeric($_POST["delete_comment"])
    && isset($_POST['csrf']) && hash_equals($_SESSION['csrf_token'], (string)$_POST['csrf'])) {
    $comment_id = (int)$_POST["delete_comment"];
    
    $stmt = $conn->prepare("SELECT user_id FROM post_comments WHERE id = ?");
    $stmt->bind_param("i", $comment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $comment = $result->fetch_assoc();
    $stmt->close();
    
    if ($comment && ($comment['user_id'] == $user_id || $viewer_is_admin)) {
        $stmt = $conn->prepare("DELETE FROM post_comments WHERE id = ?");
        $stmt->bind_param("i", $comment_id);
        $stmt->execute();
        $stmt->close();
    }
    
    $redirect_url = "index.php";
    if ($view_user_id > 0) {
        $redirect_url .= "?user=" . $view_user_id;
    }
    header("Location: " . $redirect_url);
    exit;
}

// ============================================
// СМЕНА ОБЛОЖКИ ПРОФИЛЯ
// Только свой профиль (меняется обложка пользователя из сессии), только POST + CSRF.
// change_cover — загрузить новую, remove_cover — вернуть стандартную.
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['change_cover']) || isset($_POST['remove_cover']))) {
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf_token'], (string)$_POST['csrf'])) {
        showErrorPage(403, 'Не удалось подтвердить запрос. Обновите страницу и попробуйте ещё раз.', 'index.php');
    }

    $cover_dir = 'uploads/covers/';

    // Рамка обложки из редактора: всё приводится к целым числам в допустимых границах
    $cover_clamp = static function ($v, int $lo, int $hi): int {
        return max($lo, min($hi, (int)$v));
    };
    $crop_w = $cover_clamp($_POST['cover_crop_w'] ?? 10000, 1000, 10000);
    $crop_x = $cover_clamp($_POST['cover_crop_x'] ?? 0, 0, 10000 - $crop_w);
    $crop_y = $cover_clamp($_POST['cover_crop_y'] ?? 5000, 0, 10000);
    $cover_crop_val = $crop_x . ' ' . $crop_y . ' ' . $crop_w;

    $stmt = $conn->prepare("SELECT cover FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $old_cover = (string)($stmt->get_result()->fetch_assoc()['cover'] ?? '');
    $stmt->close();

    // Старый файл удаляем только если он лежит в папке обложек
    $delete_old_cover = static function (string $path) use ($cover_dir): void {
        if ($path !== '' && strpos($path, $cover_dir) === 0 && strpos($path, '..') === false && is_file($path)) {
            @unlink($path);
        }
    };

    if (isset($_POST['remove_cover'])) {
        $stmt = $conn->prepare("UPDATE users SET cover = NULL, cover_crop = NULL WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
        $delete_old_cover($old_cover);
        header("Location: index.php");
        exit;
    }

    $cover_no_file = !isset($_FILES['cover_image']) || (int)$_FILES['cover_image']['error'] === UPLOAD_ERR_NO_FILE;
    if ($cover_no_file) {
        // Новый файл не выбирали: меняется только рамка уже загруженной обложки
        if ($old_cover !== '') {
            $stmt = $conn->prepare("UPDATE users SET cover_crop = ? WHERE id = ?");
            $stmt->bind_param("si", $cover_crop_val, $user_id);
            $stmt->execute();
            $stmt->close();
            header("Location: index.php");
            exit;
        }
        showErrorPage(400, 'Файл не выбран.', 'index.php', 'Обложка не загружена');
    }
    $file = $_FILES['cover_image'];

    if (in_array((int)$file['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true) || $file['size'] > 5 * 1024 * 1024) {
        showErrorPage(413, 'Картинка слишком большая. Максимальный размер обложки: 5 МБ.', 'index.php');
    }
    if ((int)$file['error'] !== UPLOAD_ERR_OK) {
        showErrorPage(400, 'Не удалось загрузить файл. Попробуйте ещё раз.', 'index.php', 'Обложка не загружена');
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = $finfo ? finfo_file($finfo, $file['tmp_name']) : false;
    if ($finfo) {
        finfo_close($finfo);
    }
    $cover_extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    // Должна быть настоящая картинка: и тип, и getimagesize() это подтверждают
    if (!isset($cover_extensions[$mime]) || @getimagesize($file['tmp_name']) === false) {
        showErrorPage(400, 'Неподдерживаемый формат картинки. Разрешены JPG, PNG, WEBP и GIF.', 'index.php', 'Неверный формат файла');
    }

    if (!is_dir($cover_dir)) {
        mkdir($cover_dir, 0755, true);
    }
    $new_cover = $cover_dir . 'cover_' . $user_id . '_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $cover_extensions[$mime];

    if (!move_uploaded_file($file['tmp_name'], $new_cover)) {
        showErrorPage(500, 'Не удалось сохранить обложку на сервере.', 'index.php', 'Обложка не загружена');
    }

    $stmt = $conn->prepare("UPDATE users SET cover = ?, cover_crop = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_cover, $cover_crop_val, $user_id);
    $stmt->execute();
    $stmt->close();
    $delete_old_cover($old_cover);

    header("Location: index.php");
    exit;
}

// Получение данных пользователя
$conn->query("
    CREATE TABLE IF NOT EXISTS user_profiles (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        city VARCHAR(255) DEFAULT NULL,
        bio TEXT DEFAULT NULL,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$stmt = $conn->prepare("
    SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.email, u.avatar, u.created_at, u.last_seen,
           TIMESTAMPDIFF(SECOND, u.last_seen, NOW()) AS last_seen_age_seconds,
           u.status, u.is_admin, u.deleted_at, u.is_blocked
    FROM users u
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE u.id = ?
    LIMIT 1
");
$stmt->bind_param("i", $profile_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    if ($profile_id === $user_id) {
        $_SESSION = [];
        session_destroy();
        header("Location: login.php?account_missing=1");
        exit;
    }

    showErrorPage(404, 'Такого пользователя нет — номер аккаунта в адресе указан неверно.', 'index.php', 'Профиль не найден');
}

$username = $user["username"] ?: "Пользователь";
$avatar = $user["avatar"] ?: "";
$avatarLetter = mb_strtoupper(mb_substr($username, 0, 1, 'UTF-8'), 'UTF-8');
$user_status = $user["status"] ?? 'offline';
$last_seen = $user["last_seen"] ?? null;
$user_email = $user["email"] ?? '';
$is_deleted_account = !empty($user['deleted_at']);
$is_blocked_account = (int)($user['is_blocked'] ?? 0) === 1;

$profile_stmt = $conn->prepare("SELECT bio FROM user_profiles WHERE user_id = ? LIMIT 1");
$profile_stmt->bind_param("i", $profile_id);
$profile_stmt->execute();
$profile_result = $profile_stmt->get_result();
$profile_data = $profile_result->fetch_assoc();
$profile_stmt->close();
$user_bio = trim((string)($profile_data['bio'] ?? ''));

// Обложка открытого профиля (если файла уже нет на диске — показываем стандартную)
$profile_cover = '';
$cover_stmt = $conn->prepare("SELECT cover, cover_crop FROM users WHERE id = ? LIMIT 1");
$cover_stmt->bind_param("i", $profile_id);
$cover_stmt->execute();
$cover_row = $cover_stmt->get_result()->fetch_assoc() ?: [];
$cover_val = trim((string)($cover_row['cover'] ?? ''));
$cover_crop_raw = trim((string)($cover_row['cover_crop'] ?? ''));
$cover_stmt->close();
if ($cover_val !== '' && strpos($cover_val, 'uploads/covers/') === 0 && strpos($cover_val, '..') === false && is_file($cover_val)) {
    $profile_cover = $cover_val;
}

// Рамка обложки: x, центр по y и ширина — доли картинки (0–1). Для старых обложек — на всю ширину по центру.
$cover_crop = [0, 5000, 10000];
if ($profile_cover !== '' && preg_match('/^(\d{1,5}) (\d{1,5}) (\d{1,5})$/', $cover_crop_raw, $cover_cm)) {
    $cover_cw = max(1000, min(10000, (int)$cover_cm[3]));
    $cover_cx = max(0, min(10000 - $cover_cw, (int)$cover_cm[1]));
    $cover_cy = max(0, min(10000, (int)$cover_cm[2]));
    $cover_crop = [$cover_cx, $cover_cy, $cover_cw];
}
$cover_fx  = number_format($cover_crop[0] / 10000, 4, '.', '');
$cover_fcy = number_format($cover_crop[1] / 10000, 4, '.', '');
$cover_fw  = number_format($cover_crop[2] / 10000, 4, '.', '');
// Пропорция картинки (ширина / высота) — нужна CSS для точного, чёткого позиционирования обложки
$cover_ar = 2.0;
if ($profile_cover !== '') {
    $cover_dim = @getimagesize($profile_cover);
    if ($cover_dim && $cover_dim[0] > 0 && $cover_dim[1] > 0) {
        $cover_ar = $cover_dim[0] / $cover_dim[1];
    }
}
$cover_fa = number_format($cover_ar, 5, '.', '');

$is_owner = isset($user['is_admin']) && $user['is_admin'] == 1;
$profile_is_admin = isset($user['is_admin']) && $user['is_admin'] == 1;   // админ ли владелец открытого профиля

// Верификация: галочка выдаётся, если у владельца профиля подключена 2FA (users.totp_enabled).
// Права админа ($is_owner / $profile_is_admin) от этого не меняются — меняется только значок рядом с именем.
$profile_verified = false;
try {
    $chk_totp = $conn->query("SHOW COLUMNS FROM users LIKE 'totp_enabled'");
    if ($chk_totp && $chk_totp->num_rows > 0) {
        $stmt_ver = $conn->prepare("SELECT totp_enabled FROM users WHERE id = ? LIMIT 1");
        $stmt_ver->bind_param("i", $profile_id);
        $stmt_ver->execute();
        $profile_verified = (int)($stmt_ver->get_result()->fetch_assoc()['totp_enabled'] ?? 0) === 1;
        $stmt_ver->close();
    }
} catch (Throwable $e) {
    $profile_verified = false;
}

// Шапка зависит от того, кто СМОТРИТ страницу, а не от владельца профиля:
// $is_admin — права текущего пользователя (космос в шапке, кнопка «Модерация»), чтобы шапка не менялась на чужом профиле
$is_admin = $profile_is_admin;
if ($profile_id !== $user_id) {
    $stmt_viewer = $conn->prepare("SELECT is_admin FROM users WHERE id = ? LIMIT 1");
    $stmt_viewer->bind_param("i", $user_id);
    $stmt_viewer->execute();
    $is_admin = (int)($stmt_viewer->get_result()->fetch_assoc()['is_admin'] ?? 0) === 1;
    $stmt_viewer->close();
}

// ---- Мини-окно «Подробнее»: @ник и дата рождения видят все; город — только разработчики 4 уровня ----
// Уровень разработчика — таблица admins (user_id, level). Нет строки = обычный пользователь.
$viewer_dev_level = 0;
$info_handle = (string)$profile_id;
$info_city   = '';
$info_birth  = '';
$info_city_visible = false;
try {
    $stmt_dev = $conn->prepare("SELECT level FROM admins WHERE user_id = ? LIMIT 1");
    $stmt_dev->bind_param("i", $user_id);
    $stmt_dev->execute();
    $viewer_dev_level = (int)($stmt_dev->get_result()->fetch_assoc()['level'] ?? 0);
    $stmt_dev->close();
    $info_city_visible = $viewer_dev_level >= 4;

    $stmt_info = $conn->prepare("SELECT u.handle, p.city, p.birth_date FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE u.id = ? LIMIT 1");
    $stmt_info->bind_param("i", $profile_id);
    $stmt_info->execute();
    $info_row = $stmt_info->get_result()->fetch_assoc() ?: [];
    $stmt_info->close();
    if (!empty($info_row['handle'])) { $info_handle = (string)$info_row['handle']; }
    $bd_raw = (string)($info_row['birth_date'] ?? '');
    $bd_obj = $bd_raw !== '' ? DateTime::createFromFormat('Y-m-d', $bd_raw) : false;
    $info_birth = $bd_obj ? $bd_obj->format('d.m.Y') : '';
    // Город читаем и выводим только тем, у кого есть право — остальным его нет даже в HTML
    if ($info_city_visible) { $info_city = trim((string)($info_row['city'] ?? '')); }
} catch (Throwable $e) {
    // не критично: окно покажет только то, что удалось получить
}

$is_premium = false;
$premium_expires = null;
$stmt = $conn->prepare("SELECT is_premium, premium_expires FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$premium_data = $result->fetch_assoc();
$stmt->close();

if ($premium_data && $premium_data['is_premium'] == 1) {
    if ($premium_data['premium_expires'] === null || strtotime($premium_data['premium_expires']) > time()) {
        $is_premium = true;
        $premium_expires = $premium_data['premium_expires'];
    }
}

// V+ оформляется на странице donate.php за VS-баллы, автоактивация, без заявок.

$is_friend = false;
$friend_status = 'none';

if ($is_other_profile) {
    $stmt = $conn->prepare("
        SELECT status
        FROM friend_requests
        WHERE (sender_id = ? AND receiver_id = ?)
           OR (sender_id = ? AND receiver_id = ?)
        LIMIT 1
    ");
    $stmt->bind_param("iiii", $user_id, $view_user_id, $view_user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $friend = $result->fetch_assoc();
    $stmt->close();

    if ($friend) {
        if ($friend['status'] === 'accepted') {
            $is_friend = true;
            $friend_status = 'friends';
        } elseif ($friend['status'] === 'pending') {
            $friend_status = 'pending';
        }
    }
}

// Чёрный список (таблица dialog_blocks, как в messages.php): блокировка в любую сторону —
// писать и звонить нельзя, поэтому кнопку «Написать» скрываем
$chat_blocked = false;
if ($is_other_profile) {
    try {
        $stmt = $conn->prepare("SELECT 1 FROM dialog_blocks
            WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?) LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('iiii', $user_id, $view_user_id, $view_user_id, $user_id);
            $stmt->execute();
            $chat_blocked = (bool)$stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
    } catch (Throwable $e) {
        $chat_blocked = false;
    }
}

// Владелец страницы заблокировал ТЕКУЩЕГО пользователя — ленту не показываем
$blocked_by_owner = false;
if ($is_other_profile) {
    try {
        $stmt = $conn->prepare("SELECT 1 FROM dialog_blocks WHERE blocker_id = ? AND blocked_id = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('ii', $view_user_id, $user_id);
            $stmt->execute();
            $blocked_by_owner = (bool)$stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
    } catch (Throwable $e) {
        $blocked_by_owner = false;
    }
}

// ============================================================
// ШИФРОВАНИЕ ПОСТОВ
// Посты — публичный контент (видны всем друзьям/гостям), поэтому у них
// нет отдельного ключа на пару собеседников, как в messages.php: используется
// один общий ключ, полученный из ENCRYPTION_SALT (если рядом лежит
// config.local.php от messages.php — секрет переиспользуется) либо из
// собственного файла-секрета posts_encryption.key, который создаётся
// автоматически при первом запуске и не должен попадать в git.
// ============================================================
function getPostsEncryptionKey(): string {
    static $key = null;
    if ($key !== null) return $key;

    // Общая соль берётся из .env (ENCRYPTION_SALT), в коде ключей нет.
    // Ключ считается так же, как раньше, поэтому уже сохранённые посты расшифровываются.
    if (defined('ENCRYPTION_SALT') && ENCRYPTION_SALT !== '') {
        $key = hash('sha256', 'posts:' . ENCRYPTION_SALT, true);
        return $key;
    }

    // Старый файл-секрет: только читаем, чтобы расшифровать ранее созданные посты.
    // Новый файл с ключом больше не создаётся.
    foreach ([dirname(__DIR__) . '/posts_encryption.key', __DIR__ . '/posts_encryption.key'] as $candidate) {
        if (is_file($candidate)) {
            $secret = trim((string)file_get_contents($candidate));
            if ($secret !== '') {
                $key = hash('sha256', 'posts:' . $secret, true);
                return $key;
            }
        }
    }

    throw new RuntimeException('Ключ шифрования постов не настроен: задайте ENCRYPTION_SALT в .env');
}

function encryptPostContent(string $text): string {
    if ($text === '') return '';
    $iv_len = openssl_cipher_iv_length('aes-256-cbc');
    $iv = openssl_random_pseudo_bytes($iv_len);
    try {
        $enc_key = getPostsEncryptionKey();
    } catch (Throwable $e) {
        error_log('posts encrypt: ' . $e->getMessage());
        return '';
    }
    $encrypted = openssl_encrypt($text, 'aes-256-cbc', $enc_key, OPENSSL_RAW_DATA, $iv);
    if ($encrypted === false) return '';
    return base64_encode($iv . $encrypted);
}

function decryptPostContent(string $encrypted): string {
    if ($encrypted === '') return '';
    $data = base64_decode($encrypted, true);
    if ($data === false) return '';
    $iv_len = openssl_cipher_iv_length('aes-256-cbc');
    if (strlen($data) < $iv_len) return '';
    $iv = substr($data, 0, $iv_len);
    $cipher = substr($data, $iv_len);
    try {
        $dec_key = getPostsEncryptionKey();
    } catch (Throwable $e) {
        error_log('posts decrypt: ' . $e->getMessage());
        return '';
    }
    $decrypted = openssl_decrypt($cipher, 'aes-256-cbc', $dec_key, OPENSSL_RAW_DATA, $iv);
    return $decrypted === false ? '' : $decrypted;
}

// Создание таблиц
$conn->query("
    CREATE TABLE IF NOT EXISTS posts (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        content TEXT NOT NULL,
        image VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        PRIMARY KEY (id),
        INDEX user_id (user_id),
        INDEX created_at (created_at)
    ) ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_unicode_ci
");

// posts создавалась раньше без is_encrypted — довешиваем колонку на уже существующих базах.
$posts_col_check = $conn->query("SHOW COLUMNS FROM posts LIKE 'is_encrypted'");
if ($posts_col_check && $posts_col_check->num_rows === 0) {
    $conn->query("ALTER TABLE posts ADD COLUMN is_encrypted TINYINT(1) NOT NULL DEFAULT 0 AFTER content");
}

$conn->query("
    CREATE TABLE IF NOT EXISTS post_likes (
        id INT(11) NOT NULL AUTO_INCREMENT,
        post_id INT(11) NOT NULL,
        user_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_like (post_id, user_id),
        INDEX post_id (post_id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_unicode_ci
");

$conn->query("
    CREATE TABLE IF NOT EXISTS post_comments (
        id INT(11) NOT NULL AUTO_INCREMENT,
        post_id INT(11) NOT NULL,
        user_id INT(11) NOT NULL,
        comment TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX post_id (post_id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_unicode_ci
");

$conn->query("
    CREATE TABLE IF NOT EXISTS post_reposts (
        id INT(11) NOT NULL AUTO_INCREMENT,
        post_id INT(11) NOT NULL,
        user_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_repost (post_id, user_id),
        INDEX post_id (post_id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
    COLLATE=utf8mb4_unicode_ci
");

if (!$is_other_profile && $_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_post"])) {
    $content = trim($_POST["content"] ?? "");
    $image_path = "";

    if ($content !== "") {
        // Файл больше upload_max_filesize / MAX_FILE_SIZE — раньше пост публиковался без картинки молча
        if (isset($_FILES["post_image"]) && in_array((int)$_FILES["post_image"]["error"], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
            showErrorPage(413, 'Картинка слишком большая. Максимальный размер для поста: 5 МБ.', 'index.php');
        }
        if (isset($_FILES["post_image"]) && $_FILES["post_image"]["error"] === UPLOAD_ERR_OK) {
            $file = $_FILES["post_image"];
            $allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_file($finfo, $file["tmp_name"]) : false;
            if ($finfo) {
                finfo_close($finfo);
            }
            $extensions = ["image/jpeg" => "jpg", "image/png" => "png", "image/webp" => "webp", "image/gif" => "gif"];
            $new_name = "post_" . time() . "_" . $user_id . "_" . bin2hex(random_bytes(6)) . "." . ($extensions[$mime] ?? "bin");
            $upload_dir = "uploads/posts/";

            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            if (!isset($extensions[$mime]) || !in_array($mime, $allowed, true)) {
                showErrorPage(400, 'Неподдерживаемый формат картинки. Разрешены JPG, PNG, WEBP и GIF.', 'index.php', 'Неверный формат файла');
            }
            if ($file["size"] > 5 * 1024 * 1024) {
                showErrorPage(413, 'Картинка слишком большая. Максимальный размер для поста: 5 МБ.', 'index.php');
            }
            if (isset($extensions[$mime]) && in_array($mime, $allowed, true) && $file["size"] <= 5 * 1024 * 1024) {
                $target = $upload_dir . $new_name;
                if (move_uploaded_file($file["tmp_name"], $target)) {
                    $image_path = $target;
                }
            }
        }

        $stored_content = encryptPostContent($content);
        $is_encrypted = 1;
        if ($stored_content === '') {
            // Шифрование не удалось (например, openssl недоступен) — не теряем пост, храним как есть.
            $stored_content = $content;
            $is_encrypted = 0;
        }

        $stmt = $conn->prepare("
            INSERT INTO posts (user_id, content, image, is_encrypted)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("issi", $user_id, $stored_content, $image_path, $is_encrypted);
        $stmt->execute();
        $stmt->close();

        $stmt_friends = $conn->prepare("
            SELECT u.id as friend_id
            FROM friend_requests fr
            INNER JOIN users u ON (
                CASE
                    WHEN fr.sender_id = ? THEN u.id = fr.receiver_id
                    ELSE u.id = fr.sender_id
                END
            )
            WHERE (fr.sender_id = ? OR fr.receiver_id = ?)
              AND fr.status = 'accepted'
              AND u.id != ?
        ");
        $stmt_friends->bind_param("iiii", $user_id, $user_id, $user_id, $user_id);
        $stmt_friends->execute();
        $friends_result = $stmt_friends->get_result();
        
        while ($friend = $friends_result->fetch_assoc()) {
            addNotification($conn, (int)$friend['friend_id'], 'news', 
                $username . ' опубликовал(а) новый пост: ' . mb_substr($content, 0, 50, 'UTF-8'), 
                'index.php?user=' . $user_id,
                $user_id
            );
        }
        $stmt_friends->close();

        header("Location: index.php");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["delete"]) && is_numeric($_POST["delete"])
    && isset($_POST['csrf']) && hash_equals($_SESSION['csrf_token'], (string)$_POST['csrf'])) {
    $post_id = (int)$_POST["delete"];

    $stmt = $conn->prepare("SELECT user_id, image FROM posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $post = $result->fetch_assoc();
    $stmt->close();

    if ($post && ($post['user_id'] == $user_id || $viewer_is_admin)) {
        if (!empty($post['image']) && file_exists($post['image'])) {
            unlink($post['image']);
        }

        $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
        $stmt->bind_param("i", $post_id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: index.php");
    exit;
}

// ==================== КОЛИЧЕСТВО ДРУЗЕЙ ====================
$friends_count = 0;
$stmt = $conn->prepare("
    SELECT COUNT(*) as count
    FROM friend_requests
    WHERE (sender_id = ? OR receiver_id = ?)
      AND status = 'accepted'
");
$stmt->bind_param("ii", $profile_id, $profile_id);
$stmt->execute();
$result = $stmt->get_result();
$friends_count = $result->fetch_assoc()['count'] ?? 0;
$stmt->close();

// ==================== СПИСОК ДРУЗЕЙ ДЛЯ ПРАВОЙ ПАНЕЛИ ====================
$friends_list = [];
$stmt = $conn->prepare("
    SELECT DISTINCT 
        u.id, 
        COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, 
        u.avatar, 
        u.status,
        u.last_seen
    FROM friend_requests fr
    INNER JOIN users u ON (
        CASE 
            WHEN fr.sender_id = ? THEN u.id = fr.receiver_id
            ELSE u.id = fr.sender_id
        END
    )
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE (fr.sender_id = ? OR fr.receiver_id = ?)
      AND fr.status = 'accepted'
      AND u.id != ?
    ORDER BY u.username ASC
    LIMIT 9
");
$stmt->bind_param("iiii", $profile_id, $profile_id, $profile_id, $profile_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $friends_list[] = $row;
}
$stmt->close();

$followers_count = 0;
$stmt = $conn->prepare("
    SELECT COUNT(*) as count
    FROM friend_requests
    WHERE receiver_id = ?
      AND status = 'accepted'
");
$stmt->bind_param("i", $profile_id);
$stmt->execute();
$result = $stmt->get_result();
$followers_count = $result->fetch_assoc()['count'] ?? 0;
$stmt->close();

$messages_count = 0;
$stmt = $conn->prepare("
    SELECT COUNT(*) as count
    FROM messages
    WHERE sender_id = ? OR receiver_id = ?
");
$stmt->bind_param("ii", $profile_id, $profile_id);
$stmt->execute();
$result = $stmt->get_result();
$messages_count = $result->fetch_assoc()['count'] ?? 0;
$stmt->close();

// ==================== ПОСТЫ ====================
$posts = [];
if (!$blocked_by_owner) {
$stmt = $conn->prepare("
    SELECT 
        p.id,
        p.content,
        p.is_encrypted,
        p.image,
        p.created_at,
        u.id as user_id,
        COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username,
        u.avatar,
        u.status,
        u.last_seen,
        (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as likes_count,
        (SELECT COUNT(*) FROM post_comments WHERE post_id = p.id) as comments_count,
        (SELECT COUNT(*) FROM post_reposts WHERE post_id = p.id) as reposts_count,
        (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id AND user_id = ?) as user_liked,
        (SELECT COUNT(*) FROM post_reposts WHERE post_id = p.id AND user_id = ?) as user_reposted
    FROM posts p
    INNER JOIN users u ON u.id = p.user_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE p.user_id = ?
    ORDER BY p.created_at DESC
    LIMIT 50
");
$stmt->bind_param("iii", $user_id, $user_id, $profile_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    if (!empty($row['is_encrypted']) && $row['content'] !== '') {
        $decrypted = decryptPostContent((string)$row['content']);
        $row['content'] = ($decrypted !== '') ? $decrypted : '';
    }
    $posts[] = $row;
}
$stmt->close();
}

// Какую реакцию поставил текущий пользователь на показанные посты
$my_reactions = [];
if (!empty($posts)) {
    $ids_sql = implode(',', array_map('intval', array_column($posts, 'id')));
    $res_my = $conn->query("SELECT post_id, reaction FROM post_likes WHERE user_id = " . (int)$user_id . " AND post_id IN ($ids_sql)");
    if ($res_my) {
        while ($r = $res_my->fetch_assoc()) {
            $my_reactions[(int)$r['post_id']] = (string)$r['reaction'];
        }
    }
}

$followers_list = [];
$stmt = $conn->prepare("
    SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, u.status
    FROM friend_requests fr
    INNER JOIN users u ON u.id = fr.sender_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE fr.receiver_id = ?
      AND fr.status = 'accepted'
    ORDER BY u.username ASC
    LIMIT 10
");
$stmt->bind_param("i", $profile_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $followers_list[] = $row;
}
$stmt->close();

$current_user_data = [];
$stmt = $conn->prepare("SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, u.status FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$current_user_data = $result->fetch_assoc();
$stmt->close();

$pending_reports_count = 0;
if ($is_admin) {
    $result = $conn->query("SELECT COUNT(*) as c FROM reports WHERE status = 'pending'");
    $pending_reports_count = (int)$result->fetch_assoc()['c'];
}

function getAvatarLetter(?string $username): string {
    return mb_strtoupper(mb_substr($username ?: "?", 0, 1, 'UTF-8'), 'UTF-8');
}

function isOnline(?string $status, ?string $last_seen = null): bool {
    if ($status !== 'online' || empty($last_seen)) {
        return false;
    }
    $timestamp = strtotime($last_seen);
    return $timestamp !== false && time() - $timestamp >= 0 && time() - $timestamp <= 120;
}

function formatLastSeen(?string $datetime, ?int $ageSeconds = null): string {
    if (empty($datetime)) {
        return 'Неизвестно';
    }

    $timestamp = strtotime($datetime);
    if ($ageSeconds === null && $timestamp === false) {
        return 'Неизвестно';
    }
    $diff = $ageSeconds ?? (time() - $timestamp);

    if ($diff < 0) {
        return 'Неизвестно';
    }
    if ($diff < 60) {
        return 'Только что';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' ' . getMinutesWord($minutes) . ' назад';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' ' . getHoursWord($hours) . ' назад';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' ' . getDaysWord($days) . ' назад';
    } else {
        return date('d.m.Y H:i', $timestamp);
    }
}

function getMinutesWord(int $n): string {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'минут';
    $n = $n % 10;
    if ($n == 1) return 'минуту';
    if ($n >= 2 && $n <= 4) return 'минуты';
    return 'минут';
}

function getHoursWord(int $n): string {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'часов';
    $n = $n % 10;
    if ($n == 1) return 'час';
    if ($n >= 2 && $n <= 4) return 'часа';
    return 'часов';
}

function getDaysWord(int $n): string {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'дней';
    $n = $n % 10;
    if ($n == 1) return 'день';
    if ($n >= 2 && $n <= 4) return 'дня';
    return 'дней';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <link rel="stylesheet" href="assets/css/index.css?v=share-dialog-v2">
    <style>
        /* ===== Иконка «Пост» (SVG вместо эмодзи) ===== */
        .title-ic {
            flex: 0 0 auto;
            width: 34px; height: 34px;
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 10px;
            background: rgba(88, 101, 242, .16);
            color: #7b87ff;
        }
        .empty-posts .icon svg { width: 56px; height: 56px; color: #7b87ff; opacity: .55; }
        [data-theme="light"] .title-ic { background: rgba(88, 101, 242, .12); color: #5865f2; }

        /* ===== Красивая форма «Что у вас нового?» ===== */
        .post-form textarea {
            display: block; width: 100%; box-sizing: border-box;
            min-height: 104px; resize: vertical;
            padding: 14px 16px;
            font: inherit; font-size: 15px; line-height: 1.55; color: inherit;
            background: rgba(128, 132, 150, .07);
            border: 1px solid rgba(128, 132, 150, .28);
            border-radius: 14px;
            transition: border-color .2s ease, box-shadow .2s ease, background .2s ease;
        }
        .post-form textarea::placeholder { color: inherit; opacity: .5; }
        .post-form textarea:hover { border-color: rgba(128, 132, 150, .45); }
        .post-form textarea:focus {
            outline: none;
            border-color: #5865f2;
            background: rgba(88, 101, 242, .06);
            box-shadow: 0 0 0 3px rgba(88, 101, 242, .25);
        }

        .post-form .post-actions {
            display: flex; align-items: center; justify-content: space-between;
            flex-wrap: wrap; gap: 12px; margin-top: 12px;
        }

        .post-form .post-emoji-btn {
            display: inline-grid; place-items: center;
            width: 40px; height: 40px; padding: 0; cursor: pointer;
            background: rgba(128, 132, 150, .12);
            border: 1px solid rgba(128, 132, 150, .28);
            border-radius: 10px;
            transition: background .2s ease, border-color .2s ease, transform .15s ease;
        }
        .post-form .post-emoji-btn:hover {
            background: rgba(88, 101, 242, .16);
            border-color: rgba(88, 101, 242, .55);
            transform: translateY(-1px);
        }

        .post-form .btn-post {
            padding: 10px 24px; font-size: 14px; font-weight: 600; color: #fff; cursor: pointer;
            background: linear-gradient(135deg, #6c78ff 0%, #5865f2 55%, #4752c4 100%);
            border: none; border-radius: 10px;
            box-shadow: 0 4px 14px rgba(88, 101, 242, .38);
            transition: transform .15s ease, box-shadow .2s ease, filter .2s ease;
        }
        .post-form .btn-post:hover {
            transform: translateY(-1px); filter: brightness(1.07);
            box-shadow: 0 7px 20px rgba(88, 101, 242, .5);
        }
        .post-form .btn-post:active { transform: translateY(0); box-shadow: 0 3px 10px rgba(88, 101, 242, .35); }
        .post-form .btn-post:focus-visible,
        .post-form .attach-trigger:focus-visible,
        .post-form .post-emoji-btn:focus-visible { outline: 2px solid #8b95ff; outline-offset: 2px; }

        /* Кнопка «+» с раскрывающимся меню: фото / видео / музыка / файл.
           Оформление такое же, как у кнопки эмодзи рядом и у «Опубликовать»:
           скруглённый квадрат 40×40, серая база, акцент #5865f2 при наведении. */
        .attach-menu { position: relative; display: inline-flex; align-items: center; }
        .attach-trigger {
            display: grid; place-items: center; width: 40px; height: 40px; padding: 0;
            color: var(--text-secondary, #949ba4); cursor: pointer;
            background: rgba(128, 132, 150, .12);
            border: 1px solid rgba(128, 132, 150, .28);
            border-radius: 10px;
            transition: background .2s ease, border-color .2s ease, color .2s ease, box-shadow .2s ease, transform .15s ease;
        }
        .attach-trigger svg { transition: transform .3s cubic-bezier(.34, 1.56, .64, 1); }
        .attach-menu:hover .attach-trigger,
        .attach-menu:focus-within .attach-trigger,
        .attach-menu.is-open .attach-trigger {
            color: #fff; background: #5865f2; border-color: #5865f2;
            box-shadow: 0 4px 14px rgba(88, 101, 242, .38);
        }
        .attach-menu:hover .attach-trigger svg,
        .attach-menu:focus-within .attach-trigger svg,
        .attach-menu.is-open .attach-trigger svg { transform: rotate(135deg); }

        .attach-options {
            position: absolute; left: 100%; top: 50%; z-index: 20;
            display: flex; align-items: center; gap: 8px;
            padding-left: 10px;            /* «мостик», чтобы наведение не пропадало между кнопками */
            transform: translateY(-50%);
            visibility: hidden; pointer-events: none;
        }
        .attach-menu:hover .attach-options,
        .attach-menu:focus-within .attach-options,
        .attach-menu.is-open .attach-options { visibility: visible; pointer-events: auto; }

        .attach-item {
            position: relative; display: grid; place-items: center;
            width: 40px; height: 40px; padding: 0; margin: 0; cursor: pointer;
            color: var(--text-secondary, #949ba4);
            background: rgba(128, 132, 150, .12);
            border: 1px solid rgba(128, 132, 150, .28); border-radius: 10px;
            opacity: 0; transform: translateX(-12px) scale(.6);
            transition: opacity .2s ease, transform .3s cubic-bezier(.34, 1.56, .64, 1), background .2s ease, border-color .2s ease, color .2s ease;
            transition-delay: calc(var(--i) * 45ms);
        }
        .attach-menu:hover .attach-item,
        .attach-menu:focus-within .attach-item,
        .attach-menu.is-open .attach-item { opacity: 1; transform: none; }
        .attach-menu .attach-item:not(.is-soon):hover {
            color: #8b95ff; background: rgba(88, 101, 242, .16); border-color: rgba(88, 101, 242, .55);
            transform: translateY(-1px); transition-delay: 0s;
        }
        .attach-item input[type="file"] { display: none; }
        .attach-item::after {
            content: attr(data-label);
            position: absolute; bottom: calc(100% + 8px); left: 50%;
            transform: translateX(-50%) translateY(4px);
            padding: 4px 9px; white-space: nowrap; font-size: 12px; font-weight: 500; color: #fff;
            background: rgba(20, 21, 24, .92); border-radius: 7px;
            opacity: 0; pointer-events: none; transition: opacity .15s ease, transform .15s ease;
        }
        .attach-item:hover::after { opacity: 1; transform: translateX(-50%); }
        .attach-item.is-soon { cursor: not-allowed; }
        .attach-menu:hover .attach-item.is-soon,
        .attach-menu:focus-within .attach-item.is-soon,
        .attach-menu.is-open .attach-item.is-soon { opacity: .5; }

        /* Карточки (форма, посты) — мягче и аккуратнее */
        .card { border-radius: 16px; transition: box-shadow .25s ease, border-color .25s ease; }
        .card:hover { box-shadow: 0 6px 22px rgba(0, 0, 0, .16); }

        .profile-identity .profile-status-inline { display: flex; align-items: center; margin: 0 0 3px; padding: 0; border: 0; font-size: 13px; line-height: 1.4; white-space: nowrap; }
        .profile-status-inline.online { color: var(--status-online, #43b581); }
        .profile-status-inline.offline { color: var(--text-muted, #95a5a6); }
        .profile-status.profile-status-inline::before { content: none; display: none; animation: none; }
        .profile-status[data-presence-pending] { visibility: hidden; }
        .avatar[data-presence-pending] { border-color: transparent !important; box-shadow: none !important; }

        @media (max-width: 520px) {
            .post-form .post-actions { flex-direction: column; align-items: stretch; }
            .post-form .btn-post { width: 100%; }
            .attach-item { width: 38px; height: 38px; }
        }
    </style>
    <style>
        /* кнопки в шапке не слипаются */
        .header-right { gap: 10px !important; }
        .header-right .avatar-dropdown { margin-left: 4px !important; }
    </style>
    <style>
        .header-left { display: flex; align-items: center; gap: 20px; }

        /* ===== V+ modal ===== */
        .donate-modal { position: fixed; inset: 0; z-index: 3000; display: none; align-items: center; justify-content: center; padding: 16px; background: rgba(0,0,0,.6); }
        .donate-modal.active { display: flex; }
        .donate-modal, .donate-modal * { box-sizing: border-box; }
        .donate-panel {
            --d-panel: #2b2d31; --d-panel2: #1e1f22; --d-line: #3f4147; --d-text: #f2f3f5; --d-muted: #949ba4;
            --d-accent: #5865f2; --d-accent-h: #4752c4; --d-gold: #f0b232; --d-ok: #23a55a; --d-bad: #f23f42;
            width: 100%; max-width: 560px; max-height: 92vh; overflow-y: auto;
            background: var(--d-panel); color: var(--d-text); border: 1px solid var(--d-line);
            border-radius: 16px; padding: 22px; font-family: 'Segoe UI', system-ui, Arial, sans-serif; line-height: 1.5;
        }
        body[data-theme="light"] .donate-panel {
            --d-panel: #fff; --d-panel2: #e3e5e8; --d-line: #d4d7dc; --d-text: #060607; --d-muted: #5c5e66; --d-gold: #b7791f;
        }
        @media (prefers-color-scheme: light) {
            body[data-theme="system"] .donate-panel {
                --d-panel: #fff; --d-panel2: #e3e5e8; --d-line: #d4d7dc; --d-text: #060607; --d-muted: #5c5e66; --d-gold: #b7791f;
            }
        }
        .donate-panel.is-active { border-color: var(--d-gold); }
        .donate-head { display: flex; align-items: center; gap: 14px; margin-bottom: 4px; }
        .donate-badge { width: 48px; height: 48px; border-radius: 12px; background: var(--d-panel2); border: 1px solid var(--d-line); display: grid; place-items: center; flex-shrink: 0; }
        .donate-badge img { width: 28px; height: 28px; }
        .donate-head h3 { margin: 0; font-size: 20px; }
        .donate-head p { margin: 0; color: var(--d-muted); font-size: 14px; }
        .donate-close { margin-left: auto; align-self: flex-start; background: none; border: none; color: var(--d-muted); font-size: 20px; cursor: pointer; padding: 4px 8px; border-radius: 6px; }
        .donate-close:hover { color: var(--d-text); background: var(--d-panel2); }
        .donate-flash { margin: 14px 0 0; padding: 10px 14px; border-radius: 10px; font-size: 14px; border: 1px solid; }
        .donate-flash.success { background: rgba(35,165,90,.12); border-color: rgba(35,165,90,.5); color: var(--d-ok); }
        .donate-flash.error { background: rgba(242,63,66,.12); border-color: rgba(242,63,66,.5); color: var(--d-bad); }
        .donate-panel h4 { margin: 20px 0 8px; font-size: 15px; }
        .donate-perks { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
        .donate-perks li { position: relative; padding-left: 24px; font-size: 14px; }
        .donate-perks li::before { content: ''; position: absolute; left: 4px; top: 5px; width: 6px; height: 11px; border: solid var(--d-gold); border-width: 0 2px 2px 0; transform: rotate(45deg); }
        .donate-plan { display: flex; align-items: center; gap: 12px; padding: 12px 14px; margin-bottom: 8px; background: var(--d-panel2); border: 1px solid var(--d-line); border-radius: 12px; position: relative; }
        .donate-plan.best { border-color: var(--d-accent); }
        .donate-plan-info { flex: 1; min-width: 0; }
        .donate-plan-name { font-weight: 600; font-size: 15px; }
        .donate-plan-note { color: var(--d-muted); font-size: 13px; }
        .donate-plan-price { font-weight: 700; font-size: 18px; white-space: nowrap; }
        .donate-tag { display: inline-block; margin-left: 6px; padding: 1px 8px; border-radius: 999px; background: var(--d-accent); color: #fff; font-size: 11px; font-weight: 600; vertical-align: middle; }
        .donate-btn { display: inline-block; cursor: pointer; padding: 8px 16px; border: none; border-radius: 8px; background: var(--d-accent); color: #fff; font: inherit; font-weight: 600; font-size: 14px; text-decoration: none; transition: background .15s; }
        .donate-btn:hover { background: var(--d-accent-h); }
        .donate-btn[disabled] { opacity: .5; cursor: not-allowed; }
        .donate-btn.danger { background: transparent; color: var(--d-bad); border: 1px solid var(--d-bad); }
        .donate-btn.danger:hover { background: rgba(242,63,66,.12); }
        .donate-box { background: var(--d-panel2); border: 1px solid var(--d-line); border-radius: 12px; padding: 12px 14px; }
        .donate-box p { margin: 0; }
        .donate-muted { color: var(--d-muted); font-size: 13px; }
        .donate-actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
        .donate-actions form { margin: 0; }
        .donate-table-wrap { overflow-x: auto; }
        .donate-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .donate-table th, .donate-table td { text-align: left; padding: 8px 6px; border-bottom: 1px solid var(--d-line); }
        .donate-table th { color: var(--d-muted); font-weight: 500; }
        .donate-table tr:last-child td { border-bottom: none; }
        .donate-table a { color: var(--d-accent); text-decoration: none; }
        .donate-st-paid { color: var(--d-ok); }
        .donate-st-cancelled { color: var(--d-muted); }
        @media (max-width: 480px) { .donate-plan { flex-wrap: wrap; } .donate-panel { padding: 16px; } }

        /* ===== Кнопка «Удалить из друзей»: переливающийся градиент + белый луч ===== */
        .button.button-friend-remove {
            position: relative; overflow: hidden; isolation: isolate;
            display: inline-flex; align-items: center; gap: 7px;
            height: 23px; padding: 0 10px; border: 0; border-radius: 8px; box-sizing: border-box; cursor: pointer;
            color: #fff; text-align: left;
            background: linear-gradient(100deg, #3bb2d6, #8a2be2, #ff7a1a, #8a2be2, #3bb2d6);
            background-size: 300% 100%;
            animation: bfr-flow 6s linear infinite;
            box-shadow: none;
            transition: transform .15s ease;
        }
        .button.button-friend-remove::after {
            content: ""; position: absolute; top: -20%; bottom: -20%; left: 0; width: 20px;
            background: linear-gradient(90deg, rgba(255,255,255,0), rgba(255,255,255,.75), rgba(255,255,255,0));
            transform: translateX(-120px) skewX(-20deg);
            animation: bfr-beam 3s ease-in-out infinite;
            pointer-events: none; z-index: 1;
        }
        .button.button-friend-remove::before {
            content: ""; position: absolute; inset: 0; z-index: 0;
            background: linear-gradient(100deg, #e5383b, #ff2d55);
            opacity: 0; transition: opacity .25s ease; pointer-events: none;
        }
        .button.button-friend-remove:hover::before { opacity: 1; }
        .button.button-friend-remove:hover { transform: translateY(-1px); }
        .button.button-friend-remove:active { transform: translateY(0); }
        .button-friend-remove .bfr-icon { width: 13px; height: 13px; flex: none; position: relative; z-index: 2; }
        .button-friend-remove .bfr-text { display: flex; flex-direction: column; line-height: 1.05; position: relative; z-index: 2; }
        .button-friend-remove .bfr-title { font-size: 9.5px; font-weight: 800; text-transform: uppercase; letter-spacing: .5px; }
        .button-friend-remove .bfr-sub { font-size: 6.5px; font-weight: 600; color: rgba(255,255,255,.75); margin-top: 0; }
        @keyframes bfr-flow { from { background-position: 0% 0; } to { background-position: 300% 0; } }
        @keyframes bfr-beam {
            0%   { transform: translateX(-120px) skewX(-20deg); }
            55%, 100% { transform: translateX(320px) skewX(-20deg); }
        }
        @media (prefers-reduced-motion: reduce) {
            .button.button-friend-remove, .button.button-friend-remove::after { animation: none; }
        }
    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
    <style>
        /* ===== Кнопка «Подробнее» и мини-окно с данными профиля ===== */
        .profile-details-btn {
            display: inline-flex; align-items: center; gap: 6px;
            height: 26px; padding: 0 10px 0 8px;
            background: transparent; color: var(--text-secondary);
            border: 1px solid var(--border-color); border-radius: 999px;
            font: inherit; font-size: 12px; font-weight: 600; line-height: 1; cursor: pointer;
            transition: color .15s ease, border-color .15s ease, background-color .15s ease;
        }
        .profile-details-btn svg { width: 16px; height: 16px; flex: none; }
        .profile-details-btn:hover,
        .profile-details-btn[aria-expanded="true"] { color: var(--text-primary); border-color: var(--accent-color); background: rgba(88, 101, 242, .12); }
        .profile-details-btn:focus-visible { outline: 2px solid var(--accent-color); outline-offset: 2px; }

        .profile-name .button-group .profile-details-btn {
            height: auto; padding: 4px 12px 4px 10px; border-radius: 6px;
            background: var(--bg-hover, #35373c); color: var(--text-primary);
            border: 1px solid var(--border-color); font-size: 0.8rem; font-weight: 500; gap: 6px;
        }
        .profile-name .button-group .profile-details-btn:hover,
        .profile-name .button-group .profile-details-btn[aria-expanded="true"] { border-color: var(--accent-color); background: rgba(88, 101, 242, .16); }

        /* Статус устройства отображается отдельным SVG-телефоном на аватаре. */
        .avatar-wrapper .status-dot { display: none; }
        .profile-avatar-device {
            position: absolute;
            right: 0;
            bottom: 0;
            z-index: 6;
            display: flex;
            width: 19px;
            height: 23px;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
            background: transparent;
        }
        .profile-avatar-device[hidden] { display: none; }
        .profile-avatar-device .presence-phone-icon { width: 17px; height: 21px; }
        .avatar.is-online {
            border: 5px solid var(--status-online, #43b581) !important;
            box-shadow: none !important;
        }
        @media (max-width: 520px) {
            .profile-avatar-device { right: 0; bottom: 0; width: 17px; height: 21px; }
            .avatar.is-online { border-width: 4px !important; }
        }

        /* Окно по центру экрана с затемнённым фоном */
        .pd-overlay {
            position: fixed; inset: 0; z-index: 2500;
            display: flex; align-items: center; justify-content: center; padding: 16px;
            background: rgba(0, 0, 0, .6);
            -webkit-backdrop-filter: blur(3px); backdrop-filter: blur(3px);
            opacity: 0; visibility: hidden;
            transition: opacity .18s ease, visibility 0s linear .18s;
        }
        .pd-overlay.is-open { opacity: 1; visibility: visible; transition-delay: 0s; }
        .profile-details-pop {
            position: relative; width: 380px; max-width: 100%;
            padding: 22px 20px 14px; box-sizing: border-box;
            background: var(--bg-dropdown, var(--bg-card)); color: var(--text-primary);
            border: 1px solid var(--border-color); border-radius: 16px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, .5);
            transform: translateY(12px) scale(.97);
            transition: transform .18s ease;
        }
        .pd-overlay.is-open .profile-details-pop { transform: none; }
        .pd-title { margin: 0 36px 10px 12px; font-size: 17px; font-weight: 700; }
        .pd-close {
            position: absolute; top: 12px; right: 12px; width: 32px; height: 32px;
            display: grid; place-items: center; padding: 0;
            background: transparent; color: var(--text-secondary);
            border: 0; border-radius: 50%; cursor: pointer;
            transition: background-color .15s ease, color .15s ease;
        }
        .pd-close svg { width: 18px; height: 18px; }
        .pd-close:hover { background: var(--bg-hover); color: var(--text-primary); }
        .pd-close:focus-visible { outline: 2px solid var(--accent-color); outline-offset: 1px; }
        .pd-handle-row { background: var(--bg-hover); margin-bottom: 6px; }

        .pd-handle-row {
            display: flex; align-items: center; gap: 10px; padding: 10px 10px 10px 12px;
            border-radius: 9px;
        }
        .pd-handle-row > svg { width: 20px; height: 20px; flex: none; color: var(--accent-color); }
        .pd-handle { flex: 1; min-width: 0; font-size: 15px; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .pd-copy {
            flex: none; display: grid; place-items: center; width: 30px; height: 30px; padding: 0;
            background: transparent; color: var(--text-secondary); border: 0; border-radius: 8px; cursor: pointer;
            transition: background-color .15s ease, color .15s ease;
        }
        .pd-copy svg { width: 16px; height: 16px; }
        .pd-copy .pd-ok { display: none; }
        .pd-copy:hover { background: var(--bg-hover, rgba(128,132,142,.16)); color: var(--text-primary); }
        .pd-copy.is-done { color: var(--status-online, #23a559); }
        .pd-copy.is-done .pd-ic-copy { display: none; }
        .pd-copy.is-done .pd-ok { display: block; }
        .pd-copy:focus-visible { outline: 2px solid var(--accent-color); outline-offset: 1px; }

        .pd-list { margin: 0; padding: 4px 0 2px; border-top: 1px solid var(--border-color); }
        .pd-row { display: grid; grid-template-columns: 20px 1fr; column-gap: 12px; padding: 9px 12px; }
        .pd-row > svg { width: 20px; height: 20px; margin-top: 1px; color: var(--text-secondary); }
        .pd-label { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 8px; margin: 0; font-size: 12px; color: var(--text-secondary); }
        .pd-value { margin: 2px 0 0; font-size: 14px; font-weight: 600; overflow-wrap: anywhere; }
        .pd-value.is-empty { color: var(--text-secondary); font-weight: 500; }
        .pd-tag {
            display: inline-flex; align-items: center; gap: 4px; padding: 1px 7px 1px 5px; border-radius: 6px;
            background: rgba(88, 101, 242, .16); color: var(--accent-color); font-size: 11px; font-weight: 600;
        }
        .pd-tag svg { width: 11px; height: 11px; }
        [data-theme="light"] .profile-details-pop { box-shadow: 0 12px 32px rgba(20, 24, 40, .16); }
        @media (prefers-reduced-motion: reduce) { .profile-details-pop { transition: none; } }

        /* ===== Ширина страницы — как у панели навигации (90% окна, до 1200px), края карточек по краям панели ===== */
        @media (min-width: 861px) {
            body[data-nav-pos="top"] .layout,
            body[data-nav-pos="bottom"] .layout { width: min(90%, 1200px); max-width: 1200px; padding-left: 0; padding-right: 0; }
        }
        @media (min-width: 601px) and (max-width: 860px) {
            body[data-nav-pos="top"] .layout,
            body[data-nav-pos="bottom"] .layout { width: calc(100% - 24px); max-width: 1200px; padding-left: 0; padding-right: 0; }
        }
    </style>

    <style>
        /* ===== Телефон: шапка профиля — кнопки больше не вылезают за карточку («Подробнее» обрезалось) ===== */
        @media (max-width: 520px) {
            .profile { padding: 0 16px 20px; }
            .profile-name { flex-direction: column; align-items: stretch; gap: 12px; }
            .profile-name .profile-username { flex-shrink: 1; min-width: 0; overflow-wrap: anywhere; }
            .profile-name .button-group {
                width: 100%; margin-left: 0 !important; flex-shrink: 1;
                flex-wrap: wrap;
            }
            .profile-name .button-group .button,
            .profile-name .button-group .profile-details-btn {
                flex: 1 1 auto; justify-content: center; text-align: center;
                min-height: 36px; padding: 8px 12px; font-size: .85rem;
            }
        }
    </style>

    <style>
        /* ===== Мини-окно сообщений ===== */
        .mc-win {
            position: fixed; right: 20px; bottom: 20px; z-index: 2000;
            width: 380px; height: 560px; max-width: calc(100vw - 24px); max-height: calc(100vh - 24px);
            display: flex; flex-direction: column; overflow: hidden;
            background: var(--d-panel2, #1e1f22); color: var(--d-text, #f2f3f5);
            border: 1px solid var(--d-line, #3f4147); border-radius: 16px;
            box-shadow: 0 18px 50px rgba(0,0,0,.45);
            transition: width .22s ease, height .22s ease;
        }
        .mc-win[hidden] { display: none; }
        .mc-win.is-expanded { width: 980px; height: 720px; max-width: calc(100vw - 40px); max-height: calc(100vh - 40px); }
        .mc-bar {
            display: flex; align-items: center; gap: 4px; flex: 0 0 auto;
            padding: 8px 8px 8px 12px; background: var(--d-panel, #2b2d31);
            border-bottom: 1px solid var(--d-line, #3f4147);
        }
        .mc-title { flex: 1; min-width: 0; font-weight: 700; font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .mc-btn {
            display: inline-flex; align-items: center; justify-content: center;
            width: 32px; height: 32px; padding: 0; border: 0; border-radius: 8px;
            background: transparent; color: var(--d-muted, #949ba4); cursor: pointer; text-decoration: none;
        }
        .mc-btn:hover { background: rgba(127,127,127,.2); color: var(--d-text, #f2f3f5); }
        .mc-btn[hidden] { display: none; }
        .mc-btn svg { width: 18px; height: 18px; }
        .mc-btn.mc-close:hover { background: rgba(242,63,66,.2); color: var(--d-bad, #f23f42); }
        .mc-frame { flex: 1 1 auto; width: 100%; border: 0; background: transparent; }
        @media (max-width: 699px) { .mc-win { display: none !important; } }
    </style>

    <style>
        /* ===== Всплывающее уведомление о сообщении (слева сбоку) ===== */
        .mc-toasts { position: fixed; top: 76px; left: 20px; z-index: 2100; display: flex; flex-direction: column; gap: 10px; width: 340px; max-width: calc(100vw - 24px); pointer-events: none; }
        .mc-toast {
            position: relative; overflow: hidden; pointer-events: auto; cursor: pointer;
            display: flex; align-items: center; gap: 12px; padding: 12px 14px 15px;
            background: var(--d-panel, #2b2d31); color: var(--d-text, #f2f3f5);
            border: 1px solid var(--d-line, #3f4147); border-radius: 14px;
            box-shadow: 0 12px 34px rgba(0,0,0,.4);
            opacity: 0; transform: translateX(-24px);
            transition: opacity .35s ease, transform .35s ease;
        }
        .mc-toast.is-in { opacity: 1; transform: translateX(0); }
        .mc-toast.is-out { opacity: 0; transform: translateX(-24px); }
        .mc-toast-ava { flex: 0 0 auto; width: 42px; height: 42px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; background: var(--d-accent, #5865f2); color: #fff; font-weight: 700; }
        .mc-toast-ava img { width: 100%; height: 100%; object-fit: cover; }
        .mc-toast-body { min-width: 0; flex: 1; }
        .mc-toast-name { font-weight: 700; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .mc-toast-text { margin-top: 2px; font-size: 13px; color: var(--d-muted, #949ba4); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .mc-toast-x { flex: 0 0 auto; width: 24px; height: 24px; border: 0; padding: 0; border-radius: 6px; background: transparent; color: var(--d-muted, #949ba4); cursor: pointer; font-size: 18px; line-height: 1; }
        .mc-toast-x:hover { background: rgba(127,127,127,.2); color: var(--d-text, #f2f3f5); }
        .mc-toast-bar { position: absolute; left: 0; bottom: 0; height: 3px; width: 100%; background: var(--d-accent, #5865f2); transform-origin: left center; animation: mcToastBar var(--mc-dur, 6s) linear forwards; }
        .mc-toast:hover .mc-toast-bar { animation-play-state: paused; }
        @keyframes mcToastBar { from { transform: scaleX(1); } to { transform: scaleX(0); } }
        @media (max-width: 699px) { .mc-toasts { top: 64px; left: 12px; } }
    </style>

    <style>
    </style>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main>

            <?php if ($is_deleted_account): ?>
                <section style="margin:0 auto 18px;max-width:900px;padding:18px 22px;border:1px solid rgba(240,160,48,.55);border-radius:16px;background:linear-gradient(135deg,rgba(100,55,10,.8),rgba(35,25,15,.9));color:#fff0d0;box-shadow:0 8px 30px rgba(0,0,0,.2);">
                    <strong style="display:block;font-size:18px;margin-bottom:6px;">Аккаунт удалён</strong>
                    <span style="display:block;margin-bottom:14px;color:#f7d9a0;">Вы вошли в удалённый аккаунт. Восстановите его, чтобы снова пользоваться всеми возможностями сайта.</span>
                    <a href="settings.php?action=restore" data-confirm="Восстановить аккаунт?" style="display:inline-block;padding:10px 16px;border-radius:10px;background:#f0a030;color:#241707;text-decoration:none;font-weight:700;">Восстановить аккаунт</a>
                </section>
            <?php endif; ?>
            <?php if (isset($_GET['account_restored'])): ?>
                <section style="margin:0 auto 18px;max-width:900px;padding:14px 18px;border:1px solid rgba(87,242,135,.5);border-radius:14px;background:rgba(35,100,58,.7);color:#d8ffe3;">✅ Аккаунт успешно восстановлен.</section>
            <?php endif; ?>

            <section class="card" data-mobile-friends-anchor>
                <div class="cover<?= $profile_cover !== '' ? ' has-cover' : '' ?>" id="profileCover">
                    <?php if ($profile_cover !== ''): ?>
                        <img class="cover-img" src="<?= htmlspecialchars($profile_cover, ENT_QUOTES, 'UTF-8') ?>" alt="" draggable="false"
                             style="--fx:<?= $cover_fx ?>;--fcy:<?= $cover_fcy ?>;--fw:<?= $cover_fw ?>;--a:<?= $cover_fa ?>">
                    <?php endif; ?>
                    <span class="cover-shooting-stars" aria-hidden="true">
                        <span class="cover-shooting-star star-one"></span>
                        <span class="cover-shooting-star star-two"></span>
                        <span class="cover-shooting-star star-three"></span>
                        <span class="cover-comet"></span>
                    </span>

                    <?php if (!$is_other_profile): ?>
                        <!-- Смена обложки: кнопка с SVG открывает окно #coverModal (разметка и JS внизу страницы) -->
                        <div class="cover-actions">
                            <button type="button" class="cover-btn cover-edit-btn" id="coverEditBtn" aria-label="Изменить обложку" aria-haspopup="dialog" aria-controls="coverModal">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                    <path d="M12.5 19.5H6a3 3 0 0 1-3-3v-9a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v4.5"/>
                                    <circle cx="8.4" cy="9.1" r="1.5"/>
                                    <path d="M3 16l4.3-4a1.6 1.6 0 0 1 2.2 0l3.2 3"/>
                                    <path d="M19.4 14.1l2.3 2.3-5.5 5.5-3.1.8.8-3.1z"/>
                                </svg>
                                <span class="cover-btn-text">Изменить обложку</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="profile">
                    <div class="avatar-wrapper">
                        <div class="avatar"
                             data-presence-avatar="<?= (int)$user['id'] ?>"
                             data-presence-pending>
                            <?php if (!empty($avatar) && file_exists($avatar)): ?>
                                <img src="<?= htmlspecialchars($avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($username, ENT_QUOTES, "UTF-8") ?>">
                            <?php else: ?>
                                <span class="avatar-text"><?= htmlspecialchars($avatarLetter) ?></span>
                            <?php endif; ?>
                        </div>
                        <span class="profile-avatar-device" data-presence-avatar-device="<?= (int)$user['id'] ?>" hidden></span>
                    </div>

                    <div class="profile-row">
                        <div class="profile-info">
                            <div class="profile-name">
                                <div class="profile-identity">
                                    <?php
                                        $profile_online = false;
                                        $profile_presence_label = $profile_online ? 'В сети' : 'Не в сети';
                                    ?>
                                    <div class="profile-status profile-status-inline <?= $profile_online ? 'online' : 'offline' ?>"
                                         data-user-presence="<?= (int)$user['id'] ?>"
                                         data-presence-pending><?= htmlspecialchars($profile_presence_label, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <span class="profile-username"><?= htmlspecialchars($username) ?></span>
                                        <?php if ($is_deleted_account): ?>
                                            <span class="profile-account-state" style="color:#f0a030;font-size:12px;">Аккаунт удалён</span>
                                            <img src="images/owner.svg" alt="Аккаунт удалён" title="Аккаунт удалён" style="width:20px; height:20px; display:inline-block;">
                                        <?php elseif ($is_blocked_account): ?>
                                            <span class="profile-account-state" style="color:#f23f42;font-size:12px;">Аккаунт заблокирован</span>
                                            <img src="images/owner.svg" alt="Аккаунт заблокирован" title="Аккаунт заблокирован" style="width:20px; height:20px; display:inline-block;">
                                        <?php elseif ($profile_verified): ?>
                                            <img src="images/verified.svg" alt="Страница верифицирована" title="Страница верифицирована" style="width:20px; height:21px; display:inline-block;">
                                        <?php elseif ($is_owner): ?>
                                            <img src="images/owner.svg" alt="" title="" style="width:20px; height:20px; display:inline-block;">
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($user_bio !== ''): ?>
                                        <div class="profile-bio"><?= nl2br(htmlspecialchars($user_bio, ENT_QUOTES, 'UTF-8'), false) ?></div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="button-group" style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                                    <?php if (!$is_other_profile): ?>
                                        <a href="edit.php" class="button button-edit">Редактировать</a>
                                        
                                        <?php if ($is_premium): ?>
                                            <a href="donate.php" class="button button-donate">
                                                <img src="images/donate.svg" alt="V+">
                                                V+ активен
                                            </a>
                                        <?php else: ?>
                                            <a href="donate.php" class="button button-donate">
                                                <img src="images/donate.svg" alt="V+">
                                                Купить V+
                                            </a>
                                        <?php endif; ?>
                                        
                                    <?php else: ?>
                                        <?php if (!in_array($profile_id, $service_account_ids, true) && $is_friend): ?>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="friend_id" value="<?= $profile_id ?>">
                                                <input type="hidden" name="remove_friend" value="1">
                                                <button type="submit" class="button button-friend-remove" data-confirm="Вы уверены, что хотите удалить этого пользователя из друзей?">
                                                    <svg class="bfr-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 3c-3 0-8 1.5-8 4.5V21h16v-1.5c0-3-5-4.5-8-4.5z" fill="currentColor"/><path d="M2 7h6v2H2z" fill="currentColor"/></svg>
                                                    <span class="bfr-text">
                                                        <span class="bfr-title">Удалить из друзей</span>
                                                        <span class="bfr-sub">Вы друзья</span>
                                                    </span>
                                                </button>
                                            </form>
                                        <?php elseif (!in_array($profile_id, $service_account_ids, true) && $friend_status === 'pending'): ?>
                                            <span class="button button-pending">Заявка отправлена</span>
                                        <?php elseif (!in_array($profile_id, $service_account_ids, true)): ?>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="receiver_id" value="<?= $profile_id ?>">
                                                <input type="hidden" name="add_friend" value="1">
                                                <button type="submit" class="button button-friend">Добавить в друзья</button>
                                            </form>
                                        <?php endif; ?>
                                        <?php /* написать можно любому, кроме тех, с кем есть блокировка */ ?>
                                        <?php if (!$chat_blocked): ?>
                                            <a href="messages.php?dialog=<?= $profile_id ?>" class="button button-friend button-message" data-no-mini>Написать</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <button type="button" class="button profile-details-btn" id="profileDetailsBtn"
                                        aria-haspopup="dialog" aria-expanded="false" aria-controls="profileDetailsPop">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <rect x="2.5" y="4.5" width="19" height="15" rx="3"/>
                                        <circle cx="8.6" cy="10.4" r="2.2"/>
                                        <path d="M4.9 16.2c.5-1.7 1.9-2.6 3.7-2.6s3.2.9 3.7 2.6"/>
                                        <path d="M14.6 9.4h4.2M14.6 12.4h4.2M14.6 15.2h2.6"/>
                                        </svg>
                                        Подробнее
                                        </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <?php if (!$is_other_profile): ?>
                <section class="card">
                    <div class="post-form">
                        <form method="POST" enctype="multipart/form-data">
                            <textarea name="content" id="postContentInput" placeholder="Что у вас нового?"></textarea>

                            <div class="post-actions">
                                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                                    <button type="button" class="emoji-button post-emoji-btn"
                                            id="postEmojiBtn" data-target="postContentInput" aria-label="Эмодзи">
                                        <span class="chat-file-icon">😊</span>
                                    </button>

                                    <!-- Круглая кнопка «+»: при наведении раскрывается: фото, видео, музыка, файл -->
                                    <div class="attach-menu" id="attachMenu">
                                        <button type="button" class="attach-trigger" id="attachTrigger"
                                                aria-label="Прикрепить" aria-haspopup="true" aria-expanded="false">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                                        </button>
                                        <div class="attach-options" role="menu">
                                            <label class="attach-item" style="--i:0;" data-label="Фото" role="menuitem">
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5-8 9"/></svg>
                                                <input type="file" name="post_image" accept="image/*" id="postImage">
                                            </label>
                                            <button type="button" class="attach-item is-soon" style="--i:1;" data-label="Видео · скоро" role="menuitem" disabled aria-disabled="true">
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="6" width="13" height="12" rx="3"/><path d="M16 10.5l5-3v9l-5-3z"/></svg>
                                            </button>
                                            <button type="button" class="attach-item is-soon" style="--i:2;" data-label="Музыка · скоро" role="menuitem" disabled aria-disabled="true">
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></svg>
                                            </button>
                                            <button type="button" class="attach-item is-soon" style="--i:3;" data-label="Файл · скоро" role="menuitem" disabled aria-disabled="true">
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="image-preview-container" id="imagePreviewContainer">
                                    <img id="imagePreview" src="#" alt="Предпросмотр">
                                    <button type="button" class="remove-image" id="removeImageBtn">x</button>
                                </div>

                                <button type="submit" name="add_post" class="btn-post">
                                    Опубликовать
                                </button>
                            </div>
                        </form>
                        <script>
                        (function () {
                            var menu = document.getElementById('attachMenu');
                            var trigger = document.getElementById('attachTrigger');
                            var photo = document.getElementById('postImage');
                            if (!menu || !trigger) return;
                            function setOpen(on) {
                                menu.classList.toggle('is-open', on);
                                trigger.setAttribute('aria-expanded', on ? 'true' : 'false');
                            }
                            trigger.addEventListener('click', function (e) { e.stopPropagation(); setOpen(!menu.classList.contains('is-open')); });
                            document.addEventListener('click', function (e) { if (!menu.contains(e.target)) setOpen(false); });
                            document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });
                            if (photo) photo.addEventListener('change', function () { setOpen(false); });
                        })();
                        </script>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($blocked_by_owner): ?>
            <section class="card">
                <div class="feed-restricted">
                    <div class="icon">🚫</div>
                    <h3><?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?> ограничил вам доступ к своей странице</h3>
                </div>
            </section>
            <?php else: ?>
            <section class="card">
                <div class="feed-header">
                    <span class="title-ic"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="15" height="16" rx="2.5"/><path d="M18 9h1.5a1.5 1.5 0 0 1 1.5 1.5V18a2 2 0 0 1-2 2"/><path d="M7 8.5h7M7 12h7M7 15.5h4"/></svg></span>
                    <h2><?= $is_other_profile ? 'Записи ' . htmlspecialchars($username) : 'Лента новостей' ?></h2>
                </div>

                <?php if (empty($posts)): ?>
                    <div class="empty-posts">
                        <div class="icon"><svg viewBox="0 0 24 24" width="56" height="56" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="15" height="16" rx="2.5"/><path d="M18 9h1.5a1.5 1.5 0 0 1 1.5 1.5V18a2 2 0 0 1-2 2"/><path d="M7 8.5h7M7 12h7M7 15.5h4"/></svg></div>
                        <h3><?= $is_other_profile ? 'У пользователя пока нет постов' : 'Пока нет постов' ?></h3>
                        <p><?= $is_other_profile ? '' : 'Опубликуйте первый пост!' ?></p>
                    </div>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                        <div class="post-item <?= !empty($post['is_encrypted']) ? 'is-encrypted' : '' ?>"
                             id="post-<?= (int)$post['id'] ?>"
                             data-post-id="<?= $post['id'] ?>">
                            <div class="post-header">
                                <div class="post-avatar">
                                    <?php if (!empty($post['avatar']) && file_exists($post['avatar'])): ?>
                                        <img src="<?= htmlspecialchars($post['avatar'], ENT_QUOTES, "UTF-8") ?>" alt="">
                                    <?php else: ?>
                                        <?= htmlspecialchars(getAvatarLetter($post['username'])) ?>
                                    <?php endif; ?>
                                    <span class="status-dot-small offline"
                                          data-presence-dot="<?= (int)$post['user_id'] ?>"></span>
                                </div>
                                <a href="<?= htmlspecialchars($profile_base, ENT_QUOTES) ?>/<?= (int)$post['user_id'] ?>" class="post-author">
                                    <?= htmlspecialchars($post['username'], ENT_QUOTES, "UTF-8") ?>
                                </a>
                                <span class="post-time"><?= timeAgo($post['created_at']) ?></span>
                                <?php if ($post['user_id'] == $user_id || $viewer_is_admin): ?>
                                    <a href="#" data-post-url="index.php" data-post-fields="<?= htmlspecialchars(json_encode(['delete' => (int)$post['id'], 'csrf' => $_SESSION['csrf_token']]), ENT_QUOTES) ?>" class="post-delete" data-confirm="Удалить этот пост?">x</a>
                                <?php endif; ?>
                            </div>
                            <div class="post-content">
                                <?= nl2br(htmlspecialchars($post['content'], ENT_QUOTES, "UTF-8")) ?>
                            </div>
                            <?php if (!empty($post['image']) && file_exists($post['image'])): ?>
                                <div class="post-image" onclick="openPhotoModal(<?= $post['id'] ?>, '<?= htmlspecialchars($post['image'], ENT_QUOTES, "UTF-8") ?>')">
                                    <img src="<?= htmlspecialchars($post['image'], ENT_QUOTES, "UTF-8") ?>" alt="Изображение" loading="lazy">
                                    <div class="image-overlay">
                                        <span>Нажмите для просмотра</span>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="post-actions-bar">
                                <form method="POST" class="ajax-like-form" style="display:inline;" data-post-id="<?= $post['id'] ?>">
                                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                                    <input type="hidden" name="toggle_like" value="1">
                                    <?php $my_reaction = $my_reactions[(int)$post['id']] ?? ''; ?>
                                    <button type="submit" class="post-action-btn <?= $post['user_liked'] ? 'liked' : '' ?>" aria-label="Лайк"
                                            data-reaction="<?= htmlspecialchars($my_reaction, ENT_QUOTES, 'UTF-8') ?>">
                                        <span class="action-icon"><?php if (isset($reaction_emojis[$my_reaction])): ?><span class="reaction-emoji"><?= $reaction_emojis[$my_reaction] ?></span><?php else: ?><img class="like-heart" src="images/heart.svg" alt=""><?php endif; ?></span>
                                        <span class="action-count"><?= $post['likes_count'] ?></span>
                                    </button>
                                </form>

                                <button class="post-action-btn toggle-comments" data-post-id="<?= $post['id'] ?>" data-tooltip="Оставить комментарий">
                                    <span class="action-icon comment-action-icon" role="button" tabindex="0" aria-label="Открыть комментарии"><img class="chat-icon" src="images/chat.svg" alt=""></span>
                                    <span class="action-count"><?= $post['comments_count'] ?></span>
                                </button>

                                <form method="POST" class="ajax-repost-form" style="display:inline;" data-post-id="<?= $post['id'] ?>">
                                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                                    <input type="hidden" name="toggle_repost" value="1">
                                    <button type="submit" class="post-action-btn <?= $post['user_reposted'] ? 'reposted' : '' ?>" aria-label="Поделиться" data-tooltip="Поделиться">
                                        <span class="action-icon"><img class="share-icon" src="images/share.svg" alt=""></span>
                                        <span class="action-count"><?= $post['reposts_count'] ?></span>
                                    </button>
                                </form>
                            </div>

                            <div class="comments-section" id="comments-<?= $post['id'] ?>" style="display:none;">
                                <?php
                                $stmt_comm = $conn->prepare("
                                    SELECT c.id, c.comment, c.created_at, u.id as user_id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar
                                    FROM post_comments c
                                    INNER JOIN users u ON u.id = c.user_id
                                    LEFT JOIN user_profiles up ON up.user_id = u.id
                                    WHERE c.post_id = ?
                                    ORDER BY c.created_at ASC
                                    LIMIT 20
                                ");
                                $stmt_comm->bind_param("i", $post['id']);
                                $stmt_comm->execute();
                                $comments_result = $stmt_comm->get_result();
                                while ($comment = $comments_result->fetch_assoc()):
                                ?>
                                    <div class="comment-item">
                                        <div class="comment-avatar">
                                            <?php
                                            $comment_avatar = trim((string)($comment['avatar'] ?? ''));
                                            $comment_avatar_path = $comment_avatar !== ''
                                                ? __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($comment_avatar, '/'))
                                                : '';
                                            ?>
                                            <?php if ($comment_avatar !== '' && is_file($comment_avatar_path)): ?>
                                                <img src="<?= htmlspecialchars(str_replace('\\', '/', $comment_avatar), ENT_QUOTES, "UTF-8") ?>" alt="">
                                            <?php else: ?>
                                                <?= htmlspecialchars(getAvatarLetter($comment['username'])) ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="comment-body">
                                            <a href="<?= htmlspecialchars($profile_base, ENT_QUOTES) ?>/<?= (int)$comment['user_id'] ?>" class="comment-author">
                                                <?= htmlspecialchars($comment['username'], ENT_QUOTES, "UTF-8") ?>
                                            </a>
                                            <span class="comment-time"><?= timeAgo($comment['created_at']) ?></span>
                                            <div class="comment-text"><?= formatCommentText((string)$comment['comment']) ?></div>
                                        </div>
                                        <?php if ($comment['user_id'] == $user_id || $viewer_is_admin): ?>
                                            <a href="#" data-post-url="index.php<?= $view_user_id > 0 ? '?user=' . $view_user_id : '' ?>" data-post-fields="<?= htmlspecialchars(json_encode(['delete_comment' => (int)$comment['id'], 'csrf' => $_SESSION['csrf_token']]), ENT_QUOTES) ?>" class="comment-delete" data-confirm="Удалить комментарий?">✕</a>
                                        <?php endif; ?>
                                    </div>
                                <?php endwhile; ?>
                                <?php $stmt_comm->close(); ?>
                                <form method="POST" class="comment-form ajax-comment-form" data-post-id="<?= $post['id'] ?>">
                                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                                    <input type="hidden" name="add_comment" value="1">
                                    <div class="comment-field">
                                        <input type="text" name="comment" id="commentInput-<?= $post['id'] ?>"
                                               placeholder="Написать комментарий..." autocomplete="off" required>
                                        <button type="button" class="emoji-button comment-emoji-btn"
                                                data-target="commentInput-<?= $post['id'] ?>" aria-label="Эмодзи"><?= $svg_comment_smile ?></button>
                                    </div>
                                    <button type="submit" class="comment-send" aria-label="Отправить"><?= $svg_comment_send ?></button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
            <?php endif; ?>

        </main>

        <aside class="right-sidebar">

            <div class="right-card">
                <a href="friends.php" style="text-decoration:none;color:inherit;display:block;">
                    <div class="right-title">
                        Друзья
                        <span style="font-size:13px;font-weight:400;color:var(--text-secondary);margin-left:auto;"><?= $friends_count ?></span>
                    </div>
                </a>

                <?php if (!empty($friends_list)): ?>
                    <div class="friends-avatar-grid">
                        <?php foreach ($friends_list as $friend): ?>
                            <a href="<?= $friend['id'] ?>" class="friend-avatar-card">

                                <div class="friend-avatar-big"
                                     data-presence-avatar="<?= (int)$friend['id'] ?>"
                                     data-presence-pending>
                                    <?php if (!empty($friend['avatar']) && file_exists($friend['avatar'])): ?>
                                        <img src="<?= htmlspecialchars($friend['avatar'], ENT_QUOTES, 'UTF-8') ?>"
                                             alt="<?= htmlspecialchars($friend['username'], ENT_QUOTES, 'UTF-8') ?>">
                                    <?php else: ?>
                                        <span class="avatar-letter"><?= htmlspecialchars(getAvatarLetter($friend['username'])) ?></span>
                                    <?php endif; ?>

                                    <span class="friend-status-dot offline"
                                              data-presence-dot="<?= (int)$friend['id'] ?>"
                                              data-presence-pending></span>
                                </div>

                                <span class="friend-avatar-name">
                                    <?= htmlspecialchars($friend['username'], ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </a>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($friends_count > 9): ?>
                        <a href="friends.php" class="view-all-link">Показать всех →</a>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="friends-empty">
                        <span class="empty-icon">👥</span>
                        <span class="empty-text">Нет друзей</span>
                        <a href="friends.php" style="color:#5865f2;text-decoration:none;font-size:13px;">Найти друзей</a>
                    </div>
                <?php endif; ?>
            </div>

        </aside>

        <div class="site-footer">
            <div class="footer-content">

                <span class="footer-copy">
                    SPACE &copy; <span class="year">2026</span>
                </span>

            </div>
        </div>
    </div>


    <!-- Реакции: появляются при наведении на лайк (на телефоне — долгое нажатие) -->
    <div class="reaction-popup" id="reactionPopup" hidden>
        <div class="reaction-popup-row">
            <button type="button" class="reaction-opt" data-reaction="like" title="Нравится"><img class="like-heart" src="images/heart.svg" alt=""></button>
            <button type="button" class="reaction-opt" data-reaction="laugh" title="Ха-ха">😆</button>
            <button type="button" class="reaction-opt" data-reaction="wow" title="Ух ты">😲</button>
            <button type="button" class="reaction-opt" data-reaction="love" title="Восторг">😍</button>
            <button type="button" class="reaction-opt" data-reaction="sad" title="Грустно">😢</button>
            <button type="button" class="reaction-opt" data-reaction="angry" title="Возмутительно">😡</button>
        </div>
        <div class="reaction-popup-footer" id="reactionPopupFooter" hidden></div>
    </div>

    <!-- Поделиться: только «В личном сообщении» -->
    <div class="share-dialog-overlay" id="shareDialog" hidden>
        <div class="share-dialog" role="dialog" aria-modal="true" aria-labelledby="shareDialogTitle">
            <div class="share-dialog-tabs">
                <span class="share-dialog-tab" id="shareDialogTitle">Поделиться</span>
            </div>
            <div class="share-dialog-body">
                <div class="share-option">
                    <span class="share-radio" aria-hidden="true"></span>
                    <span>В личном сообщении</span>
                </div>

                <div class="share-combo" id="shareCombo">
                    <input type="text" id="shareSearch" autocomplete="off"
                           placeholder="Введите имя получателя или название чата">
                    <span class="share-combo-arrow" aria-hidden="true">⌄</span>
                    <div class="share-list" id="shareList" hidden></div>
                </div>
            </div>
            <div class="share-dialog-footer">
                <button type="button" class="share-btn share-btn-cancel" id="shareCancel">Отмена</button>
                <button type="button" class="share-btn share-btn-send" id="shareSend" disabled>Отправить</button>
            </div>
        </div>
    </div>

    <div class="photo-modal" id="photoModal" onclick="if(event.target === this) closePhotoModal()">
        <div class="photo-modal-content" onclick="event.stopPropagation()">
            <div class="photo-modal-image">
                <img id="modalImage" src="" alt="Просмотр фото">
            </div>
            <div class="photo-modal-sidebar">
                <div class="sidebar-header">
                    <span>Комментарии</span>
                    <button class="close-btn" onclick="closePhotoModal()">✕</button>
                </div>

                <!-- Автор поста, время публикации, лайк и «поделиться» — над комментариями -->
                <div class="modal-post-info" id="modalPostInfo" hidden>
                    <div class="modal-post-author-row">
                        <div class="modal-post-avatar" id="modalPostAvatar"></div>
                        <div class="modal-post-meta">
                            <a href="#" class="modal-post-author" id="modalPostAuthor"></a>
                            <span class="modal-post-time" id="modalPostTime"></span>
                        </div>
                    </div>
                    <div class="modal-post-actions">
                        <button type="button" class="post-action-btn" id="modalLikeBtn" aria-label="Лайк">
                            <span class="action-icon"><img class="like-heart" src="images/heart.svg" alt=""></span>
                            <span class="action-count">0</span>
                        </button>
                        <button type="button" class="post-action-btn" id="modalRepostBtn" aria-label="Поделиться">
                            <span class="action-icon"><img class="share-icon" src="images/share.svg" alt=""></span>
                            <span class="action-count">0</span>
                        </button>
                    </div>
                </div>

                <div class="comments-list" id="modalCommentsList">
                    <div class="no-comments">Загрузка комментариев...</div>
                </div>
                <form method="POST" action="index.php<?= $view_user_id > 0 ? '?user=' . $view_user_id : '' ?>" class="comment-form-modal ajax-comment-form-modal" data-post-id="">
                    <input type="hidden" name="post_id" id="modalPostId" value="">
                    <input type="hidden" name="add_comment" value="1">
                    <div class="comment-field">
                        <input type="text" name="comment" id="modalCommentInput" placeholder="Написать комментарий..." autocomplete="off" required>
                        <button type="button" class="emoji-button comment-emoji-btn"
                                data-target="modalCommentInput" aria-label="Эмодзи"><?= $svg_comment_smile ?></button>
                    </div>
                    <button type="submit" class="comment-send" aria-label="Отправить"><?= $svg_comment_send ?></button>
                </form>
            </div>
        </div>
    </div>


    <script>
    /* ===== Поделиться → В личном сообщении ===== */
    window.PROFILE_BASE = <?= json_encode($profile_base) ?>;
    window.SHARE_CSRF = <?= json_encode($_SESSION['csrf_token'] ?? '') ?>;

    (function () {
        const overlay = document.getElementById('shareDialog');
        if (!overlay) return;
        const combo   = document.getElementById('shareCombo');
        const search  = document.getElementById('shareSearch');
        const list    = document.getElementById('shareList');
        const sendBtn = document.getElementById('shareSend');
        const cancel  = document.getElementById('shareCancel');

        let targets = [];
        let postId = null;
        let receiverId = null;
        let sending = false;
        const shareApiBase = (window.PROFILE_BASE || '') + '/messages.php?api=';

        function esc(s) {
            return String(s).replace(/[&<>"']/g, function (c) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
            });
        }

        function avatarHtml(t) {
            if (t.is_self) {
                return '<span class="share-avatar share-avatar-self">&#128278;</span>';
            }
            if (t.avatar) {
                return '<span class="share-avatar"><img src="' + esc(t.avatar) + '" alt=""></span>';
            }
            return '<span class="share-avatar">' + esc((t.username || '?').charAt(0).toUpperCase()) + '</span>';
        }

        function renderList(filter) {
            const q = (filter || '').trim().toLowerCase();
            const items = targets.filter(function (t) {
                return !q || t.username.toLowerCase().indexOf(q) !== -1;
            });
            if (!items.length) {
                list.innerHTML = '<div class="share-empty">Ничего не найдено</div>';
                return;
            }
            list.innerHTML = items.map(function (t) {
                return '<button type="button" class="share-item" data-id="' + t.id + '">' +
                    avatarHtml(t) + '<span class="share-item-name">' + esc(t.username) + '</span></button>';
            }).join('');
        }

        function showList() { list.hidden = false; combo.classList.add('open'); }
        function hideList() { list.hidden = true;  combo.classList.remove('open'); }

        function resetSendBtn() {
            sendBtn.textContent = 'Отправить';
            sendBtn.disabled = receiverId === null;
        }

        window.openShareDialog = function (id) {
            postId = id;
            receiverId = null;
            sending = false;
            search.value = '';
            resetSendBtn();
            list.innerHTML = '<div class="share-empty">Загрузка...</div>';
            overlay.hidden = false;
            showList();
            search.focus();

            fetch(shareApiBase + 'share_targets', { credentials: 'same-origin' })
                .then(function (r) {
                    if (!r.ok) throw new Error('share_targets_failed');
                    return r.json();
                })
                .then(function (data) {
                    if (!data || !data.success || !Array.isArray(data.targets)) throw new Error('share_targets_failed');
                    targets = data.targets;
                    renderList(search.value);
                })
                .catch(function () {
                    list.innerHTML = '<div class="share-empty">Не удалось загрузить список</div>';
                });
        };

        function closeShare() {
            overlay.hidden = true;
            hideList();
            postId = null;
            receiverId = null;
        }

        search.addEventListener('input', function () {
            receiverId = null;          // текст поменяли — выбор сброшен
            resetSendBtn();
            renderList(search.value);
            showList();
        });
        search.addEventListener('focus', function () { renderList(search.value); showList(); });
        combo.addEventListener('click', function (e) {
            if (e.target.closest('.share-combo-arrow')) {
                list.hidden ? (renderList(search.value), showList(), search.focus()) : hideList();
            }
        });

        list.addEventListener('click', function (e) {
            const item = e.target.closest('.share-item');
            if (!item) return;
            const t = targets.find(function (x) { return String(x.id) === item.dataset.id; });
            if (!t) return;
            receiverId = t.id;
            search.value = t.username;
            hideList();
            resetSendBtn();
        });

        // клик по пустому месту окна закрывает выпадающий список
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) { closeShare(); return; }
            if (!e.target.closest('.share-combo')) hideList();
        });
        cancel.addEventListener('click', closeShare);
        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape' || overlay.hidden) return;
            e.stopPropagation();
            if (!list.hidden) hideList(); else closeShare();
        }, true);

        sendBtn.addEventListener('click', function () {
            if (sending || receiverId === null || !postId) return;
            sending = true;
            sendBtn.disabled = true;
            sendBtn.textContent = 'Отправка...';

            const fd = new FormData();
            fd.append('post_id', postId);
            fd.append('receiver_id', receiverId);
            fd.append('csrf_token', window.SHARE_CSRF);
            const sentPostId = postId;

            fetch(shareApiBase + 'share_post', {
                method: 'POST',
                body: fd,
                credentials: 'same-origin',
                headers: { 'X-CSRF-Token': window.SHARE_CSRF }
            })
            .then(function (r) {
                if (!r.ok) throw new Error('share_post_failed');
                return r.json();
            })
            .then(function (res) {
                if (!res || !res.success) throw new Error('send_failed');
                sendBtn.textContent = 'Отправлено ✓';
                countShareAsRepost(sentPostId);
                setTimeout(function () { sending = false; closeShare(); }, 700);
            })
            .catch(function () {
                sending = false;
                sendBtn.textContent = 'Ошибка, повторить';
                sendBtn.disabled = false;
            });
        });

        // Отправка = репост: если пост ещё не в репостах, засчитываем его (счётчик ↪ растёт на 1)
        function countShareAsRepost(id) {
            const form = document.querySelector('.ajax-repost-form[data-post-id="' + id + '"]');
            if (!form) return;
            const btn = form.querySelector('.post-action-btn');
            if (!btn || btn.classList.contains('reposted')) return;
            fetch(form.action || window.location.href, {
                method: 'POST',
                body: new FormData(form),
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            }).then(function () {
                btn.classList.add('reposted');
                const count = btn.querySelector('.action-count');
                count.textContent = parseInt(count.textContent || '0', 10) + 1;
                if (window.syncModalPostActions) window.syncModalPostActions(id);
            }).catch(function () {});
        }
    })();
    </script>

    <script>

        /* AJAX: лайк / репост / комментарий — без перезагрузки.
           Серверная логика не меняется, просто форма шлётся через fetch. */
        document.addEventListener('submit', function(e) {
            const form = e.target;

            // «Поделиться» (↪) больше не переключает репост напрямую, а открывает окно выбора получателя
            if (form.classList.contains('ajax-repost-form')) {
                e.preventDefault();
                openShareDialog(form.dataset.postId);
                return;
            }

            if (form.classList.contains('ajax-like-form') ||
                form.classList.contains('ajax-comment-form')) {

                e.preventDefault();
                const fd = new FormData(form);
                const postId = form.dataset.postId;

                fetch(form.action || window.location.href, {
                    method: 'POST',
                    body: fd,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(r => r.text())
                .then(() => {
                    if (form.classList.contains('ajax-like-form')) {
                        const btn = form.querySelector('.post-action-btn');
                        const icon = btn.querySelector('.action-icon');
                        const count = btn.querySelector('.action-count');
                        const liked = btn.classList.toggle('liked');   // вид сердца задаёт CSS (.liked)
                        if (window.setLikeReaction) window.setLikeReaction(btn, liked ? 'like' : '');
                        count.textContent = parseInt(count.textContent || '0', 10) + (liked ? 1 : -1);
                        if (window.syncModalPostActions) window.syncModalPostActions(postId);
                    }
                    if (form.classList.contains('ajax-comment-form')) {
                        form.querySelector('input[name="comment"]').value = '';
                        // подгрузим комментарии заново, если секция открыта
                        const section = document.getElementById('comments-' + postId);
                        if (section && section.style.display !== 'none') {
                            loadComments(postId);
                        }
                    }
                })
                .catch(err => console.error('AJAX error:', err));
            }

            if (form.classList.contains('ajax-comment-form-modal')) {
                e.preventDefault();
                const fd = new FormData(form);
                const postId = document.getElementById('modalPostId').value;
                fd.set('post_id', postId);
                fetch(form.action || window.location.href, {
                    method: 'POST',
                    body: fd,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(r => r.text())
                .then(() => {
                    document.getElementById('modalCommentInput').value = '';
                    loadComments(postId);
                })
                .catch(err => console.error('AJAX error:', err));
            }
        });

        function escHtml(v) {
            return String(v == null ? '' : v).replace(/[&<>"']/g, function(c) {
                return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
            });
        }
        function safeUrl(u) {
            u = String(u || '');
            return /^(https?:\/\/|\/|[\w.\-\/]+$)/i.test(u) && !/^\s*(javascript|data|vbscript):/i.test(u) ? escHtml(u) : '';
        }

        function loadComments(postId) {
            const list = document.getElementById('modalCommentsList');
            if (!list) return;
            list.innerHTML = '<div class="no-comments">Загрузка...</div>';

            fetch('api/get_post_comments.php?post_id=' + encodeURIComponent(postId))
                .then(function(response) {
                    if (!response.ok) throw new Error('Ошибка загрузки комментариев');
                    return response.json();
                })
                .then(function(data) {
                    const comments = Array.isArray(data) ? data : data.comments;
                    if (!Array.isArray(comments) || comments.length === 0) {
                        list.innerHTML = '<div class="no-comments">Нет комментариев</div>';
                        return;
                    }

                    list.innerHTML = comments.map(function(comment) {
                        const avatarHtml = comment.avatar
                            ? '<img src="' + safeUrl(comment.avatar) + '" alt="">'
                            : escHtml(comment.letter || '?');

                        return `
                            <div class="comment-item-modal">
                                <div class="comment-avatar-modal">${avatarHtml}</div>
                                <div class="comment-body-modal">
                                    <a href="${escHtml(window.PROFILE_BASE || '')}/${parseInt(comment.user_id, 10) || 0}" class="comment-author-modal">${escHtml(comment.username || 'Пользователь')}</a>
                                    <span class="comment-time-modal">${escHtml(comment.time || '')}</span>
                                    <div class="comment-text-modal">${escHtml(comment.comment || '')}</div>
                                </div>
                            </div>
                        `;
                    }).join('');
                })
                .catch(function() {
                    list.innerHTML = '<div class="no-comments">Ошибка загрузки комментариев</div>';
                });
        }

        function openPhotoModal(postId, imageSrc) {
            const modal = document.getElementById('photoModal');
            const img = document.getElementById('modalImage');
            const hidden = document.getElementById('modalPostId');
            if (!modal || !img) return;
            img.src = imageSrc;
            if (hidden) hidden.value = postId;
            modal.classList.add('active');
            if (window.fillModalPost) window.fillModalPost(postId);
            loadComments(postId);
        }

        function closePhotoModal() {
            const modal = document.getElementById('photoModal');
            if (modal) modal.classList.remove('active');
        }

        // toggle comments
        document.addEventListener('click', function(e) {
            const btn = e.target.closest('.toggle-comments');
            if (!btn) return;
            const postId = btn.dataset.postId;
            const section = document.getElementById('comments-' + postId);
            if (section) {
                section.style.display = 'block';
                section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        });

        document.addEventListener('keydown', function(e) {
            const icon = e.target.closest('.comment-action-icon');
            if (!icon || (e.key !== 'Enter' && e.key !== ' ')) return;
            e.preventDefault();
            icon.closest('.toggle-comments').click();
        });
    </script>


    <script>
    /* ===== Реакции: окно при наведении на лайк ===== */
    (function () {
        const EMOJI = { laugh: '😆', wow: '😲', love: '😍', sad: '😢', angry: '😡' };
        const HEART = '<img class="like-heart" src="images/heart.svg" alt="">';

        // Показывает на кнопке выбранную реакцию (или сердце) и состояние «поставлено / нет»
        window.setLikeReaction = function (btn, reaction) {
            const icon = btn.querySelector('.action-icon');
            btn.classList.toggle('liked', !!reaction);
            btn.dataset.reaction = reaction || '';
            icon.innerHTML = EMOJI[reaction] ? '<span class="reaction-emoji">' + EMOJI[reaction] + '</span>' : HEART;
        };

        const popup  = document.getElementById('reactionPopup');
        const footer = document.getElementById('reactionPopupFooter');
        if (!popup) return;

        const BTN_SEL = '.ajax-like-form .post-action-btn';
        let showTimer = null, hideTimer = null, currentBtn = null, longPressed = false, pressTimer = null;
        const cache = {};

        function plural(n) {
            const m10 = n % 10, m100 = n % 100;
            if (m10 === 1 && m100 !== 11) return n + ' реакция';
            if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return n + ' реакции';
            return n + ' реакций';
        }

        function renderFooter(data) {
            footer.innerHTML = '';
            if (!data || !data.total) { footer.hidden = true; return; }
            const stack = document.createElement('span');
            stack.className = 'reaction-avatars';
            (data.users || []).forEach(function (u) {
                const av = document.createElement('span');
                av.className = 'reaction-avatar';
                if (u.avatar) {
                    const img = document.createElement('img');
                    img.src = u.avatar;
                    img.alt = '';
                    av.appendChild(img);
                } else {
                    av.textContent = (u.username || '?').charAt(0).toUpperCase();
                }
                av.title = u.username;
                stack.appendChild(av);
            });
            const text = document.createElement('span');
            text.textContent = plural(data.total);
            footer.appendChild(stack);
            footer.appendChild(text);
            footer.hidden = false;
        }

        function loadFooter(postId) {
            if (cache[postId]) { renderFooter(cache[postId]); return; }
            footer.hidden = true;
            fetch('index.php?post_reactions=' + encodeURIComponent(postId), { credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    cache[postId] = data;
                    const form = currentBtn && currentBtn.closest('.ajax-like-form');
                    if (form && form.dataset.postId === String(postId)) {
                        renderFooter(data);
                        place(currentBtn);
                    }
                })
                .catch(function () {});
        }

        function place(btn) {
            const r = btn.getBoundingClientRect();
            const pw = popup.offsetWidth, ph = popup.offsetHeight;
            const left = Math.max(8, Math.min(r.left, window.innerWidth - pw - 8));
            let top = r.top - ph - 8;
            if (top < 8) top = r.bottom + 8;
            popup.style.left = left + 'px';
            popup.style.top = top + 'px';
        }

        function show(btn) {
            clearTimeout(hideTimer);
            currentBtn = btn;
            popup.hidden = false;
            const form = btn.closest('.ajax-like-form');
            const mine = btn.dataset.reaction || (btn.classList.contains('liked') ? 'like' : '');
            popup.querySelectorAll('.reaction-opt').forEach(function (o) {
                o.classList.toggle('active', o.dataset.reaction === mine);
            });
            loadFooter(form.dataset.postId);
            place(btn);
        }

        function hide() {
            clearTimeout(showTimer);
            clearTimeout(hideTimer);
            popup.hidden = true;
            currentBtn = null;
        }

        function choose(reaction) {
            const btn = currentBtn;
            if (!btn) return;
            const form = btn.closest('.ajax-like-form');
            const postId = form.dataset.postId;
            const wasLiked = btn.classList.contains('liked');
            const prev = btn.dataset.reaction || (wasLiked ? 'like' : '');

            const fd = new FormData(form);
            fd.set('reaction', reaction);
            hide();

            fetch(form.action || window.location.href, {
                method: 'POST',
                body: fd,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(function (r) { return r.text(); })
            .then(function () {
                const count = btn.querySelector('.action-count');
                let n = parseInt(count.textContent || '0', 10);
                if (!wasLiked) {
                    n += 1;
                    window.setLikeReaction(btn, reaction);
                } else if (prev === reaction) {          // повторный выбор той же реакции снимает её
                    n -= 1;
                    window.setLikeReaction(btn, '');
                } else {                                  // смена реакции: число не меняется
                    window.setLikeReaction(btn, reaction);
                }
                count.textContent = n;
                delete cache[postId];
                if (window.syncModalPostActions) window.syncModalPostActions(postId);
            })
            .catch(function (err) { console.error('Reaction error:', err); });
        }

        // Мышь: задержка перед показом и перед скрытием, чтобы окно не мигало
        document.addEventListener('mouseover', function (e) {
            const btn = e.target.closest(BTN_SEL);
            if (btn) {
                clearTimeout(hideTimer);
                if (currentBtn !== btn || popup.hidden) {
                    clearTimeout(showTimer);
                    showTimer = setTimeout(function () { show(btn); }, 350);
                }
            } else if (e.target.closest('#reactionPopup')) {
                clearTimeout(hideTimer);
            }
        });
        document.addEventListener('mouseout', function (e) {
            const from = e.target.closest ? e.target.closest(BTN_SEL + ', #reactionPopup') : null;
            if (!from) return;
            const to = e.relatedTarget && e.relatedTarget.closest
                ? e.relatedTarget.closest(BTN_SEL + ', #reactionPopup') : null;
            if (to) return;
            clearTimeout(showTimer);
            hideTimer = setTimeout(hide, 250);
        });

        popup.addEventListener('click', function (e) {
            const opt = e.target.closest('.reaction-opt');
            if (opt) choose(opt.dataset.reaction);
        });

        // Телефон: долгое нажатие на лайк открывает окно, обычное — ставит лайк
        document.addEventListener('touchstart', function (e) {
            const btn = e.target.closest(BTN_SEL);
            if (!btn) return;
            longPressed = false;
            pressTimer = setTimeout(function () { longPressed = true; show(btn); }, 450);
        }, { passive: true });
        ['touchend', 'touchmove', 'touchcancel'].forEach(function (type) {
            document.addEventListener(type, function () { clearTimeout(pressTimer); }, { passive: true });
        });
        document.addEventListener('click', function (e) {
            if (longPressed && e.target.closest(BTN_SEL)) {   // клик после долгого нажатия не ставит лайк
                e.preventDefault();
                e.stopPropagation();
                longPressed = false;
                return;
            }
            if (!popup.hidden && !e.target.closest('#reactionPopup') && !e.target.closest(BTN_SEL)) hide();
        }, true);

        window.addEventListener('scroll', hide, true);
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !popup.hidden) hide(); });
    })();
    </script>

    <script>
    /* Ссылка на пост (#post-ID, например из личного сообщения): прокрутить к посту,
       подсветить его и сразу раскрыть комментарии */
    (function () {
        function showToast(text) {
            const toast = document.createElement('div');
            toast.className = 'post-toast';
            toast.textContent = text;
            document.body.appendChild(toast);
            setTimeout(function () { toast.classList.add('hide'); }, 3000);
            setTimeout(function () { toast.remove(); }, 3500);
        }

        function openSharedPost() {
            const match = /^#post-(\d+)$/.exec(window.location.hash);
            if (!match) return;

            const post = document.getElementById('post-' + match[1]);
            if (!post) {
                showToast('Пост не найден или уже удалён');
                return;
            }

            const commentsBtn = post.querySelector('.toggle-comments');
            if (commentsBtn) commentsBtn.click();

            // Прокрутка вызывается после раскрытия комментариев, чтобы пост остался вверху экрана
            post.scrollIntoView({ behavior: 'smooth', block: 'start' });

            post.classList.remove('post-highlight');
            void post.offsetWidth;
            post.classList.add('post-highlight');
            setTimeout(function () { post.classList.remove('post-highlight'); }, 3500);
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', openSharedPost);
        } else {
            openSharedPost();
        }
        window.addEventListener('hashchange', openSharedPost);
    })();
    </script>


    <!-- Окно подтверждения (вместо встроенного confirm браузера) -->
    <div class="confirm-overlay" id="confirmOverlay" aria-hidden="true">
        <div class="confirm-box" role="dialog" aria-modal="true" aria-labelledby="confirmText">
            <div class="confirm-text" id="confirmText"></div>
            <div class="confirm-actions">
                <button type="button" class="confirm-btn confirm-cancel" id="confirmCancel">Отмена</button>
                <button type="button" class="confirm-btn confirm-ok" id="confirmOk">OK</button>
            </div>
        </div>
    </div>
    <script>
    (function () {
        const overlay = document.getElementById('confirmOverlay');
        const textEl = document.getElementById('confirmText');
        const okBtn = document.getElementById('confirmOk');
        const cancelBtn = document.getElementById('confirmCancel');
        let pending = null;

        function close() {
            overlay.classList.remove('active');
            overlay.setAttribute('aria-hidden', 'true');
            pending = null;
        }

        function open(el) {
            pending = el;
            textEl.textContent = el.getAttribute('data-confirm');
            overlay.classList.add('active');
            overlay.setAttribute('aria-hidden', 'false');
            okBtn.focus();
        }

        document.addEventListener('click', function (e) {
            const el = e.target.closest('[data-confirm]');
            if (!el) return;
            e.preventDefault();
            e.stopPropagation();
            open(el);
        }, true);

        okBtn.addEventListener('click', function () {
            const el = pending;
            close();
            if (!el) return;
            if (el.dataset && el.dataset.postUrl) {
                const f = document.createElement('form');
                f.method = 'POST';
                f.action = el.dataset.postUrl;
                const fields = JSON.parse(el.dataset.postFields || '{}');
                Object.keys(fields).forEach(function (k) {
                    const i = document.createElement('input');
                    i.type = 'hidden'; i.name = k; i.value = fields[k];
                    f.appendChild(i);
                });
                document.body.appendChild(f);
                f.submit();
            } else if (el.tagName === 'A' && el.href) {
                window.location.href = el.href;
            } else if (el.form) {
                el.form.submit();
            }
        });
        cancelBtn.addEventListener('click', close);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    })();
    </script>

    <script>
    // Уведомления и меню профиля: открывается только одно из двух
    document.addEventListener('click', function (e) {
        var notif  = document.getElementById('notificationsDropdown');
        var avatar = document.getElementById('avatarDropdown');
        var cls = ['active', 'show', 'open'];
        function close(el) { if (el) cls.forEach(function (c) { el.classList.remove(c); }); }
        if (e.target.closest('#notificationsBtn')) close(avatar);
        else if (e.target.closest('#avatarBtn'))   close(notif);
    }, true);
    </script>
    <!-- Мини-окно «Подробнее» (переносится в body, чтобы не обрезаться .card { overflow:hidden }) -->
    <div class="pd-overlay" id="profileDetailsOverlay">
    <div class="profile-details-pop" id="profileDetailsPop" role="dialog" aria-modal="true" aria-labelledby="pdTitle">
        <h3 class="pd-title" id="pdTitle">Подробнее</h3>
        <button type="button" class="pd-close" id="pdClose" aria-label="Закрыть">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
        <div class="pd-handle-row">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M16 12v1.4a2.6 2.6 0 0 0 5.2 0V12a9.2 9.2 0 1 0-3.6 7.3"/></svg>
            <span class="pd-handle" id="pdHandle"><?= htmlspecialchars($info_handle, ENT_QUOTES, 'UTF-8') ?></span>
            <button type="button" class="pd-copy" id="pdCopy" data-copy="<?= htmlspecialchars($info_handle, ENT_QUOTES, 'UTF-8') ?>" aria-label="<?= htmlspecialchars($info_handle, ENT_QUOTES, 'UTF-8') ?>">
                <svg class="pd-ic-copy" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6.5A2.5 2.5 0 0 1 7.5 4H15"/></svg>
                <svg class="pd-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
            </button>
        </div>
        <dl class="pd-list">
            <div class="pd-row">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h16v-6.5a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2z"/><path d="M4 16c1.7 0 1.7 1.2 3.4 1.2S9.1 16 10.8 16s1.7 1.2 3.4 1.2S15.9 16 17.6 16 18.6 17 20 17"/><path d="M12 11.5V8"/><path d="M12 3.2c1 1 1.4 1.7 1.4 2.4a1.4 1.4 0 0 1-2.8 0c0-.7.4-1.4 1.4-2.4z"/></svg>
                <div>
                    <dt class="pd-label"><span>Дата рождения</span></dt>
                    <dd class="pd-value<?= $info_birth === '' ? ' is-empty' : '' ?>"><?= $info_birth !== '' ? htmlspecialchars($info_birth, ENT_QUOTES, 'UTF-8') : 'Не указана' ?></dd>
                </div>
            </div>
            <?php if ($info_city_visible): ?>
                <div class="pd-row">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21.2s6.8-5.9 6.8-11.4a6.8 6.8 0 1 0-13.6 0c0 5.5 6.8 11.4 6.8 11.4z"/><circle cx="12" cy="9.8" r="2.5"/></svg>
                    <div>
                        <dt class="pd-label">
                            <span>Город</span>
                            <span class="pd-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>Разработчик 4 уровня</span>
                        </dt>
                        <dd class="pd-value<?= $info_city === '' ? ' is-empty' : '' ?>"><?= $info_city !== '' ? htmlspecialchars($info_city, ENT_QUOTES, 'UTF-8') : 'Не указан' ?></dd>
                    </div>
                </div>
            <?php endif; ?>
        </dl>
    </div>
    </div>
    <script>
        (function () {
            var btn = document.getElementById('profileDetailsBtn');
            var pop = document.getElementById('profileDetailsOverlay');
            if (!btn || !pop) return;
            document.body.appendChild(pop);   // уходим из .card (там overflow:hidden)

            function open() {
                pop.classList.add('is-open');
                btn.setAttribute('aria-expanded', 'true');
                document.body.style.overflow = 'hidden';
                var c = document.getElementById('pdClose'); if (c) c.focus();
            }
            function close() {
                pop.classList.remove('is-open');
                btn.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            }
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                pop.classList.contains('is-open') ? close() : open();
            });
            pop.addEventListener('click', function (e) { if (e.target === pop) close(); });
            var closeBtn = document.getElementById('pdClose');
            if (closeBtn) closeBtn.addEventListener('click', function () { close(); btn.focus(); });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && pop.classList.contains('is-open')) { close(); btn.focus(); }
            });

            var copy = document.getElementById('pdCopy');
            if (copy) copy.addEventListener('click', function () {
                var text = copy.getAttribute('data-copy') || '';
                function done() { copy.classList.add('is-done'); setTimeout(function () { copy.classList.remove('is-done'); }, 1300); }
                if (navigator.clipboard && window.isSecureContext) {
                    navigator.clipboard.writeText(text).then(done, function () {});
                } else {
                    var t = document.createElement('textarea'); t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
                    document.body.appendChild(t); t.select();
                    try { document.execCommand('copy'); done(); } catch (err) {}
                    document.body.removeChild(t);
                }
            });
        })();
    </script>
    <!-- Переключатель темы вынесен в assets/js/theme-switch.js (+ assets/css/theme-switch.css), подключается из includes/site_header.php -->
    <script>
    /* Уведомления и меню профиля: открыта максимум одна панель, без миганий.
       Состояние до клика запоминаем, а после того как отработают обработчики шапки — выставляем итог сами. */
    (function () {
        var notif = document.querySelector('.notifications-dropdown');
        var menu  = document.querySelector('.avatar-dropdown .dropdown-menu') || document.querySelector('.dropdown-menu');
        if (!notif || !menu) return;
        var CLS = ['active', 'show', 'open'];
        var root = document.documentElement;

        function isOpen(el) { return CLS.some(function (c) { return el.classList.contains(c); }); }
        function setOpen(el, on) {
            CLS.forEach(function (c) { if (c !== 'active') el.classList.remove(c); });
            if (el.classList.contains('active') !== on) el.classList.toggle('active', on);
        }
        function apply(n, m) {
            setOpen(notif, n);
            setOpen(menu, m);
            root.setAttribute('data-panel', n ? 'notif' : (m ? 'menu' : ''));
        }
        apply(isOpen(notif) && !isOpen(menu), isOpen(menu));

        document.addEventListener('click', function (e) {
            var inBell   = e.target.closest('#notificationsBtn, .notifications-btn');
            var inAvatar = e.target.closest('#avatarBtn, .header-avatar');
            var inside   = e.target.closest('.notifications-dropdown, .dropdown-menu');
            var wasN = isOpen(notif), wasM = isOpen(menu);

            var want = null;
            if (inBell)        want = [!wasN, false];
            else if (inAvatar) want = [false, !wasM];
            else if (!inside)  want = [false, false];          // клик мимо — закрыть обе
            if (!want) return;

            // сразу (до обработчиков шапки) говорим CSS, какая панель главная — вторая гаснет плавно
            root.setAttribute('data-panel', want[0] ? 'notif' : (want[1] ? 'menu' : ''));

            // после обработчиков шапки (они могли тоже переключить классы) ставим итоговое состояние
            setTimeout(function () { apply(want[0], want[1]); }, 0);
        }, true);

        /* SVG вместо эмодзи 🔔 в пустом списке уведомлений */
        var EMPTY_BELL =
            '<svg viewBox="0 0 64 64" aria-hidden="true">' +
            '<defs>' +
            '<linearGradient id="ebBell" x1="16" y1="8" x2="48" y2="52" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#9aa4ff"/><stop offset="1" stop-color="#5865f2"/></linearGradient>' +
            '<radialGradient id="ebGlow" cx="32" cy="34" r="30" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#5865f2" stop-opacity=".22"/><stop offset="1" stop-color="#5865f2" stop-opacity="0"/></radialGradient>' +
            '</defs>' +
            '<circle cx="32" cy="34" r="30" fill="url(#ebGlow)"/>' +
            '<g class="eb-bell">' +
            '<path d="M32 7.5a3.4 3.4 0 0 1 3.4 3.4v1.2c7.6 1.6 13 8.3 13 16.1v8.4c0 2.4 1 4.7 2.7 6.4l1.3 1.3c1.4 1.4.4 3.8-1.6 3.8H14.2c-2 0-3-2.4-1.6-3.8l1.3-1.3a9 9 0 0 0 2.7-6.4V28c0-7.8 5.4-14.5 13-16.100v-1.200A3.4 3.4 0 0 1 32 7.500z" fill="url(#ebBell)"/>' +
            '<path d="M20.5 27.500c.8-4.6 4-8 8.5-9.1" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="2.6" stroke-linecap="round"/>' +
            '</g>' +
            '<path class="eb-clapper" d="M25.5 51.500h13a6.5 6.5 0 0 1-13 0z" fill="#4752c4"/>' +
            '<g fill="#8b95ff" class="eb-spark">' +
            '<path d="M53 12l1.3 3 3 1.3-3 1.300L53 20.600l-1.3-3-3-1.3 3-1.300z"/>' +
            '<path d="M10 20l.9 2 2 .9-2 .9-.9 2-.9-2-2-.9 2-.9z" opacity=".7"/>' +
            '</g>' +
            '</svg>';
        function fixEmptyBell() {
            document.querySelectorAll('.notifications-empty .empty-icon').forEach(function (el) {
                if (!el.querySelector('svg')) { el.innerHTML = EMPTY_BELL; el.classList.add('is-svg'); }
            });
        }
        fixEmptyBell();
        new MutationObserver(fixEmptyBell).observe(notif, { childList: true, subtree: true });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') apply(false, false);
        });
    })();
    </script>
    <?php if (!$is_other_profile): ?>
    <!-- Редактор обложки: вся картинка, рамка с зонами «мобильное устройство» / «компьютер», углы для размера -->
    <div class="ce-overlay" id="coverModal" hidden>
        <div class="ce-modal" role="dialog" aria-modal="true" aria-labelledby="coverModalTitle">
            <div class="ce-head">
                <h3 id="coverModalTitle">Редактирование обложки</h3>
                <button type="button" class="ce-close" id="coverModalClose" aria-label="Закрыть">&#10005;</button>
            </div>

            <form method="POST" enctype="multipart/form-data" id="coverForm" class="ce-form">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="change_cover" value="1">
                <input type="hidden" name="cover_crop_x" id="coverCropX" value="<?= (int)$cover_crop[0] ?>">
                <input type="hidden" name="cover_crop_y" id="coverCropY" value="<?= (int)$cover_crop[1] ?>">
                <input type="hidden" name="cover_crop_w" id="coverCropW" value="<?= (int)$cover_crop[2] ?>">
                <input type="file" name="cover_image" id="coverFileInput" accept="image/jpeg,image/png,image/webp,image/gif" hidden>

                <div class="ce-body">
                    <label class="ce-drop" id="coverDrop" for="coverFileInput"<?= $profile_cover !== '' ? ' hidden' : '' ?>>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 8.6 4.8 4.8 0 0 1 17.5 18"/>
                            <path d="M12 21v-8"/>
                            <path d="M8.8 15.8L12 12.6l3.2 3.2"/>
                        </svg>
                        <span class="ce-drop-title" id="coverDropTitle">Перетащите картинку сюда или нажмите, чтобы выбрать</span>
                        <span class="ce-drop-hint">JPG, PNG, WEBP или GIF · до 5 МБ · лучше широкая, от 1200×600</span>
                    </label>

                    <div class="ce-stage" id="ceStage" hidden
                         data-src="<?= htmlspecialchars($profile_cover, ENT_QUOTES, 'UTF-8') ?>"
                         data-fx="<?= $cover_fx ?>" data-fcy="<?= $cover_fcy ?>" data-fw="<?= $cover_fw ?>">
                        <div class="ce-canvas" id="ceCanvas">
                            <img id="ceImg" alt="" draggable="false">
                            <div class="ce-dim" aria-hidden="true"><div class="ce-hole" id="ceHole"></div></div>
                            <div class="ce-frame" id="ceFrame" tabindex="0" role="group" aria-label="Область обложки. Стрелки двигают рамку, плюс и минус меняют размер">
                                <span class="ce-label">Мобильное устройство</span>
                                <div class="ce-strip"><span class="ce-label">Компьютер</span></div>
                                <i class="ce-handle" data-c="nw"></i>
                                <i class="ce-handle" data-c="ne"></i>
                                <i class="ce-handle" data-c="sw"></i>
                                <i class="ce-handle" data-c="se"></i>
                            </div>
                        </div>
                    </div>

                    <div class="ce-preview" id="cePreview" hidden>
                        <div class="ce-prev-block">
                            <span class="ce-prev-title">Компьютер</span>
                            <div class="ce-render ce-render-desk" id="cePrevDesk"><img class="cover-img" alt="" draggable="false"></div>
                        </div>
                        <div class="ce-prev-block">
                            <span class="ce-prev-title">Мобильное устройство</span>
                            <div class="ce-render ce-render-mob" id="cePrevMob"><img class="cover-img" alt="" draggable="false"></div>
                        </div>
                    </div>

                    <div class="ce-error" id="coverError" role="alert" hidden></div>
                </div>

                <div class="ce-footer">
                    <div class="ce-footer-left">
                        <button type="button" class="ce-link" id="cePreviewBtn" disabled>Предпросмотр</button>
                        <label class="ce-link" for="coverFileInput" id="ceReplace" hidden>Загрузить другое</label>
                        <?php if ($profile_cover !== ''): ?>
                            <button type="button" class="ce-link ce-link-danger"
                                    data-post-url="index.php"
                                    data-post-fields="<?= htmlspecialchars(json_encode(['remove_cover' => 1, 'csrf' => $_SESSION['csrf_token']]), ENT_QUOTES) ?>"
                                    data-confirm="Вернуть стандартную обложку?">Убрать обложку</button>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="ce-save" id="coverSave" disabled>Установить обложку</button>
                </div>
            </form>
        </div>
    </div>
    <script>
    /* Редактор обложки.
       Рамка (x, центр y, ширина — доли картинки) всегда с пропорцией «мобильного» экрана RATIO:1.
       Внутри неё по центру — полоса «компьютера» (DESK:1). Сайт показывает ту часть, что влезает в обложку:
       полная ширина рамки и высота по пропорции окна, по центру рамки. */
    (function () {
        function $(id) { return document.getElementById(id); }
        var openBtn = $('coverEditBtn'), overlay = $('coverModal'), form = $('coverForm'), input = $('coverFileInput');
        var drop = $('coverDrop'), dropTtl = $('coverDropTitle'), stage = $('ceStage'), canvas = $('ceCanvas');
        var img = $('ceImg'), frame = $('ceFrame'), hole = $('ceHole');
        var preview = $('cePreview'), prevBtn = $('cePreviewBtn'), replaceLbl = $('ceReplace');
        var saveBtn = $('coverSave'), errBox = $('coverError');
        var inX = $('coverCropX'), inY = $('coverCropY'), inW = $('coverCropW');
        var prevDesk = $('cePrevDesk'), prevMob = $('cePrevMob');
        if (!openBtn || !overlay || !form || !input || !stage || !canvas || !img || !frame || !hole) return;

        var RATIO = 2, DESK = 4, K = RATIO / DESK;
        var MAX = 5 * 1024 * 1024;
        var TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        var DROP_TEXT = dropTtl.textContent;

        var existingSrc = stage.dataset.src || '';
        var orig = {
            fx:  parseFloat(stage.dataset.fx),
            fcy: parseFloat(stage.dataset.fcy),
            fw:  parseFloat(stage.dataset.fw)
        };
        if (isNaN(orig.fx) || isNaN(orig.fcy) || isNaN(orig.fw)) orig = { fx: 0, fcy: 0.5, fw: 1 };

        var st = { fx: 0, fcy: 0.5, fw: 1 };
        var base = { fx: 0, fcy: 0.5, fw: 1 };
        var a = 1;                       // ширина / высота картинки
        var hasImg = false, hasFile = false, changed = false, saving = false, previewing = false;
        var objectUrl = null, drag = null;

        frame.style.setProperty('--k', K);

        function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
        function fh() { return st.fw * a / RATIO; }          // высота рамки в долях высоты картинки
        function showError(t) { errBox.textContent = t || ''; errBox.hidden = !t; }
        function updateSave() { saveBtn.disabled = saving || !hasImg || !(hasFile || changed); }

        function clampState() {
            var maxfw = Math.min(1, RATIO / a);
            st.fw = clamp(st.fw, Math.min(0.12, maxfw), maxfw);
            var h = fh();
            st.fx = clamp(st.fx, 0, 1 - st.fw);
            st.fcy = clamp(st.fcy, h / 2, 1 - h / 2);
        }
        function defaultState() {
            st.fw = Math.min(1, RATIO / a);
            st.fx = (1 - st.fw) / 2;
            st.fcy = 0.5;
            clampState();
        }

        function setVars(el) {
            el.style.setProperty('--fx', st.fx.toFixed(4));
            el.style.setProperty('--fcy', st.fcy.toFixed(4));
            el.style.setProperty('--fw', st.fw.toFixed(4));
            el.style.setProperty('--a', a.toFixed(5));
        }

        function render() {
            clampState();
            var h = fh();
            [frame, hole].forEach(function (el) {
                el.style.left   = (st.fx * 100) + '%';
                el.style.top    = ((st.fcy - h / 2) * 100) + '%';
                el.style.width  = (st.fw * 100) + '%';
                el.style.height = (h * 100) + '%';
            });
            inX.value = Math.round(st.fx * 10000);
            inY.value = Math.round(st.fcy * 10000);
            inW.value = Math.round(st.fw * 10000);
            changed = Math.abs(st.fx - base.fx) > 0.0005 || Math.abs(st.fcy - base.fcy) > 0.0005 || Math.abs(st.fw - base.fw) > 0.0005;
            if (previewing) { setVars(prevDesk.firstElementChild); setVars(prevMob.firstElementChild); }
            updateSave();
        }

        function loadImage(src, isNew) {
            img.onload = function () {
                a = (img.naturalWidth / img.naturalHeight) || 1;
                hasImg = true;
                drop.hidden = true;
                stage.hidden = previewing;
                replaceLbl.hidden = false;
                prevBtn.disabled = false;
                if (isNew) {
                    defaultState();
                    base = { fx: st.fx, fcy: st.fcy, fw: st.fw };
                } else {
                    st.fx = orig.fx; st.fcy = orig.fcy; st.fw = orig.fw;
                    clampState();
                    base = { fx: st.fx, fcy: st.fcy, fw: st.fw };
                }
                prevDesk.firstElementChild.src = src;
                prevMob.firstElementChild.src = src;
                render();
            };
            img.onerror = function () { showError('Не удалось открыть картинку.'); };
            img.src = src;
        }

        function reset() {
            if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = null; }
            hasImg = false; hasFile = false; changed = false; saving = false; previewing = false;
            input.value = '';
            dropTtl.textContent = DROP_TEXT;
            drop.hidden = false;
            stage.hidden = true;
            preview.hidden = true;
            replaceLbl.hidden = true;
            prevBtn.disabled = true;
            prevBtn.textContent = 'Предпросмотр';
            saveBtn.textContent = 'Установить обложку';
            showError('');
            updateSave();
        }

        function open() {
            reset();
            overlay.hidden = false;
            document.body.style.overflow = 'hidden';
            openBtn.setAttribute('aria-expanded', 'true');
            if (existingSrc) loadImage(existingSrc, false);
            document.getElementById('coverModalClose').focus({ preventScroll: true });
        }
        function close() {
            if (saving) return;
            overlay.hidden = true;
            document.body.style.overflow = '';
            openBtn.setAttribute('aria-expanded', 'false');
            reset();
            openBtn.focus({ preventScroll: true });
        }

        function accept(file) {
            if (!file) return;
            if (TYPES.indexOf(file.type) === -1) { showError('Разрешены только JPG, PNG, WEBP и GIF.'); return; }
            if (file.size > MAX)                  { showError('Картинка слишком большая — максимум 5 МБ.'); return; }
            showError('');
            if (objectUrl) URL.revokeObjectURL(objectUrl);
            objectUrl = URL.createObjectURL(file);
            hasFile = true;
            loadImage(objectUrl, true);
        }

        /* --- рамка: перемещение и изменение размера за углы (пропорция сохраняется) --- */
        frame.addEventListener('pointerdown', function (e) {
            if (!hasImg) return;
            var r = canvas.getBoundingClientRect();
            var h = fh();
            var L = st.fx, R = st.fx + st.fw, T = st.fcy - h / 2, B = st.fcy + h / 2;
            var handle = e.target.closest ? e.target.closest('.ce-handle') : null;
            if (handle) {
                var c = handle.dataset.c;
                var sx = c.indexOf('e') > -1 ? 1 : -1;      // тянем правый угол: +1, левый: -1
                var sy = c.indexOf('s') > -1 ? 1 : -1;      // нижний: +1, верхний: -1
                drag = { mode: 'resize', r: r, sx: sx, sy: sy, ox: sx > 0 ? L : R, oy: sy > 0 ? T : B };
            } else {
                drag = { mode: 'move', r: r, x: e.clientX, y: e.clientY, fx: st.fx, fcy: st.fcy };
            }
            try { frame.setPointerCapture(e.pointerId); } catch (err) {}
            frame.classList.add('is-active');
            e.preventDefault();
        });
        frame.addEventListener('pointermove', function (e) {
            if (!drag) return;
            if (drag.mode === 'move') {
                st.fx  = drag.fx  + (e.clientX - drag.x) / drag.r.width;
                st.fcy = drag.fcy + (e.clientY - drag.y) / drag.r.height;
            } else {
                var px = (e.clientX - drag.r.left) / drag.r.width;
                var py = (e.clientY - drag.r.top)  / drag.r.height;
                var dx = (px - drag.ox) * drag.sx;
                var dy = (py - drag.oy) * drag.sy;
                var spaceX = drag.sx > 0 ? 1 - drag.ox : drag.ox;
                var spaceY = drag.sy > 0 ? 1 - drag.oy : drag.oy;
                var maxfw = Math.min(spaceX, spaceY * RATIO / a);
                var minfw = Math.min(0.12, maxfw);
                var fw = clamp(Math.max(dx, dy * RATIO / a), minfw, maxfw);
                var h = fw * a / RATIO;
                st.fw = fw;
                st.fx = drag.sx > 0 ? drag.ox : drag.ox - fw;
                st.fcy = (drag.sy > 0 ? drag.oy : drag.oy - h) + h / 2;
            }
            render();
        });
        function endDrag() { drag = null; frame.classList.remove('is-active'); }
        frame.addEventListener('pointerup', endDrag);
        frame.addEventListener('pointercancel', endDrag);

        frame.addEventListener('keydown', function (e) {
            var step = 0.01, used = true;
            if (e.key === 'ArrowLeft') st.fx -= step;
            else if (e.key === 'ArrowRight') st.fx += step;
            else if (e.key === 'ArrowUp') st.fcy -= step;
            else if (e.key === 'ArrowDown') st.fcy += step;
            else if (e.key === '+' || e.key === '=') { st.fw += 0.02; st.fx -= 0.01; }
            else if (e.key === '-' || e.key === '_') { st.fw -= 0.02; st.fx += 0.01; }
            else used = false;
            if (!used || !hasImg) return;
            e.preventDefault();
            render();
        });

        /* --- предпросмотр: как обложка выглядит на компьютере и на телефоне --- */
        prevBtn.addEventListener('click', function () {
            if (!hasImg) return;
            previewing = !previewing;
            stage.hidden = previewing;
            preview.hidden = !previewing;
            prevBtn.textContent = previewing ? 'Редактор' : 'Предпросмотр';
            render();
        });

        openBtn.addEventListener('click', open);
        document.getElementById('coverModalClose').addEventListener('click', close);
        overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) close(); });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && !overlay.hidden) {
                var confirmBox = document.getElementById('confirmOverlay');
                if (confirmBox && confirmBox.classList.contains('active')) return;   // сначала закрывается подтверждение
                close();
            }
        });

        input.addEventListener('change', function () { accept(input.files && input.files[0]); });

        ['dragenter', 'dragover'].forEach(function (t) {
            drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.add('is-drag'); });
        });
        ['dragleave', 'drop'].forEach(function (t) {
            drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.remove('is-drag'); });
        });
        drop.addEventListener('drop', function (e) {
            var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
            if (!f) return;
            try {
                var dt = new DataTransfer();
                dt.items.add(f);
                input.files = dt.files;
            } catch (err) { showError('Перетаскивание не поддерживается — нажмите и выберите файл.'); return; }
            accept(f);
        });

        form.addEventListener('submit', function (e) {
            if (!hasImg || !(hasFile || changed)) { e.preventDefault(); return; }
            render();
            saving = true;
            saveBtn.disabled = true;
            saveBtn.textContent = 'Сохранение…';
        });
    })();
    </script>
    <?php endif; ?>


    <!-- Мини-окно сообщений: внутри обычный messages.php (поэтому звонки, вложения и т.д. работают как там) -->
    <div class="mc-win" id="mcWin" hidden role="dialog" aria-label="Сообщения">
        <div class="mc-bar">
            <span class="mc-title" id="mcTitle">Сообщения</span>
            <a class="mc-btn" id="mcOpen" href="messages.php" data-no-mini title="Открыть в messages.php" aria-label="Открыть в messages.php">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/></svg>
            </a>
            <button type="button" class="mc-btn mc-close" id="mcClose" title="Закрыть" aria-label="Закрыть">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
            </button>
        </div>
        <iframe class="mc-frame" id="mcFrame" title="Сообщения"
                allow="microphone; camera; autoplay; display-capture; clipboard-write; fullscreen"></iframe>
    </div>
    <script>
    (function () {
        var win = document.getElementById('mcWin');
        if (!win) return;
        var frame = document.getElementById('mcFrame'),
            title = document.getElementById('mcTitle'), openLink = document.getElementById('mcOpen'),
            closeBtn = document.getElementById('mcClose');
        var callExpanded = false, loaded = false;

        function applySize() {
            win.classList.toggle('is-expanded', callExpanded);
        }
        function currentDialog() {
            try { return parseInt(new URLSearchParams(frame.contentWindow.location.search).get('dialog'), 10) || 0; }
            catch (e) { return 0; }
        }
        function syncChrome() {
            var d = currentDialog();
            openLink.href = 'messages.php' + (d ? '?dialog=' + d : '');
            var name = '';
            try {
                var el = frame.contentDocument.querySelector('.chat-header-name-text');
                if (d && el) name = el.textContent.trim();
            } catch (e) {}
            title.textContent = d ? (name || 'Диалог') : 'Сообщения';
        }
        function openMini(dialog) {
            var url = 'messages.php' + (dialog ? '?dialog=' + dialog : '');
            win.hidden = false;
            document.body.classList.add('mc-chat-open');
            if (!loaded || (dialog && currentDialog() !== dialog)) {
                loaded = true;
                frame.src = url;
            }
            syncChrome();
        }
        function closeMini() { win.hidden = true; document.body.classList.remove('mc-chat-open'); }

        // Ссылки на messages.php (меню, «Написать» и т.д.) работают как обычно — открывают страницу messages.php.
        // Мини-окно открывается из уведомлений (window.openMiniMessages).

        closeBtn.addEventListener('click', closeMini);
        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') return;
            if (!win.hidden) closeMini();
        });

        frame.addEventListener('load', function () { syncChrome(); });
        setInterval(function () { if (!win.hidden) syncChrome(); }, 700);

        // Идёт звонок — раскрываем окно, чтобы интерфейс звонка поместился; после звонка возвращаем размер
        window.addEventListener('message', function (e) {
            if (e.origin !== location.origin || !e.data || e.data.type !== 'mc-call') return;
            callExpanded = !!e.data.active;
            if (callExpanded) { win.hidden = false; document.body.classList.add('mc-chat-open'); }
            applySize();
        });


        // ===== Уведомления о новых сообщениях: справа сверху, с полоской времени, плавно исчезают =====
        var toastBox = document.createElement('div');
        toastBox.className = 'mc-toasts';
        document.body.appendChild(toastBox);
        var seen = null, DUR = 6000;

        function showToast(d) {
            var t = document.createElement('div');
            t.className = 'mc-toast';
            t.style.setProperty('--mc-dur', DUR + 'ms');
            var ava = document.createElement('div'); ava.className = 'mc-toast-ava';
            if (d.avatar) { var im = document.createElement('img'); im.src = d.avatar; im.alt = ''; ava.appendChild(im); }
            else ava.textContent = (d.name || '?').trim().charAt(0).toUpperCase();
            var body = document.createElement('div'); body.className = 'mc-toast-body';
            var nm = document.createElement('div'); nm.className = 'mc-toast-name'; nm.textContent = d.name || 'Новое сообщение';
            var tx = document.createElement('div'); tx.className = 'mc-toast-text'; tx.textContent = d.text || '';
            body.appendChild(nm); body.appendChild(tx);
            var x = document.createElement('button'); x.type = 'button'; x.className = 'mc-toast-x'; x.setAttribute('aria-label', 'Закрыть'); x.textContent = '×';
            var bar = document.createElement('div'); bar.className = 'mc-toast-bar';
            t.appendChild(ava); t.appendChild(body); t.appendChild(x); t.appendChild(bar);
            toastBox.appendChild(t);
            requestAnimationFrame(function () { requestAnimationFrame(function () { t.classList.add('is-in'); }); });

            var gone = false;
            function hide() {
                if (gone) return; gone = true;
                t.classList.remove('is-in'); t.classList.add('is-out');
                setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 400);
            }
            bar.addEventListener('animationend', hide);
            x.addEventListener('click', function (e) { e.stopPropagation(); hide(); });
            t.addEventListener('click', function () { hide(); if (window.innerWidth < 700) location.href = 'messages.php?dialog=' + d.id; else openMini(d.id); });
        }

        function poll() {
            if (document.hidden) return;
            fetch('messages.php?api=mini_poll', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.ok ? r.json() : null; })
                .then(function (j) {
                    if (!j || !j.success) return;
                    var now = {};
                    j.dialogs.forEach(function (d) {
                        now[d.id] = d.unread;
                        var open = !win.hidden && currentDialog() === d.id;
                        if (seen !== null && d.unread > (seen[d.id] || 0) && !open) showToast(d);
                    });
                    seen = now;
                })
                .catch(function () {});
        }
        poll();
        setInterval(poll, 5000);

        window.openMiniMessages = openMini;
    })();
    </script>
    <script src="assets/js/mentions.js"></script>
    <script src="assets/js/post-emoji.js"></script>
    <script src="assets/js/script.js"></script>
    <script>
    /* Тема переживает F5 и «Назад»: cookie (её читает сервер) главнее чужих скриптов */
    (function () {
        function sync() {
            var m = document.cookie.match(/(?:^|; )theme=(dark|light|system)/), t = m && m[1];
            if (!t) { try { t = localStorage.getItem('theme'); } catch (e) {} }
            if (/^(dark|light|system)$/.test(t) && document.body.getAttribute('data-theme') !== t) document.body.setAttribute('data-theme', t);
            if (window.__syncThemeSwitch) window.__syncThemeSwitch();
        }
        sync();
        window.addEventListener('pageshow', sync);
    })();
    </script>

</body>
</html>

<?php
if ($conn) {
    $conn->close();
}
?>
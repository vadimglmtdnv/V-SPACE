<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

if (!isset($_SESSION['user_id']) || (int)$_SESSION['user_id'] !== 1) {
    http_response_code(403);
    exit('Доступ запрещён.');
}

$maintenanceFile = __DIR__ . DIRECTORY_SEPARATOR . 'maintenance.lock';
$expiresAt = time() + (5 * 60);

if (file_put_contents($maintenanceFile, (string)$expiresAt, LOCK_EX) === false) {
    http_response_code(500);
    exit('Не удалось включить технический режим.');
}

header('Location: reports.php?restart=1');
exit;

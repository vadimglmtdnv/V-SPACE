<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

if (isset($_SESSION["user_id"])) {
    $user_id = (int)$_SESSION["user_id"];
    
    // Создаём таблицу для истории IP если её нет
    $conn->query("
        CREATE TABLE IF NOT EXISTS user_ip_history (
            id INT NOT NULL AUTO_INCREMENT,
            user_id INT NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            user_agent VARCHAR(255) NULL,
            action VARCHAR(20) DEFAULT 'login',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX user_id (user_id),
            INDEX ip_address (ip_address)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Добавляем колонку action если её нет
    $result = $conn->query("SHOW COLUMNS FROM user_ip_history LIKE 'action'");
    if ($result->num_rows === 0) {
        $conn->query("ALTER TABLE user_ip_history ADD COLUMN action VARCHAR(20) DEFAULT 'login'");
    }
    
    // Записываем выход в историю
    $current_ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    if (!empty($current_ip)) {
        $stmt = $conn->prepare("
            INSERT INTO user_ip_history (user_id, ip_address, user_agent, action)
            VALUES (?, ?, ?, 'logout')
        ");
        $stmt->bind_param("iss", $user_id, $current_ip, $user_agent);
        $stmt->execute();
        $stmt->close();
    }
    
    $activePresenceResult = null;
    $presenceTable = $conn->query(
        "SELECT COUNT(*) AS table_exists
         FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = 'user_device_presence'"
    );
    if ($presenceTable && (int)($presenceTable->fetch_assoc()['table_exists'] ?? 0) > 0) {
        $sessionHash = hash('sha256', session_id());
        $removePresence = $conn->prepare(
            "DELETE FROM user_device_presence WHERE user_id = ? AND session_hash = ?"
        );
        $removePresence->bind_param('is', $user_id, $sessionHash);
        $removePresence->execute();
        $removePresence->close();

        $activePresence = $conn->prepare(
            "SELECT MAX(last_seen) AS last_seen
             FROM user_device_presence
             WHERE user_id = ? AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)"
        );
        $activePresence->bind_param('i', $user_id);
        $activePresence->execute();
        $activePresenceResult = $activePresence->get_result()->fetch_assoc();
        $activePresence->close();
    }

    if (!empty($activePresenceResult['last_seen'])) {
        $update = $conn->prepare("UPDATE users SET status = 'online', last_seen = ? WHERE id = ?");
        $update->bind_param('si', $activePresenceResult['last_seen'], $user_id);
    } else {
        $update = $conn->prepare("UPDATE users SET status = 'offline', last_seen = NOW() WHERE id = ?");
        $update->bind_param('i', $user_id);
    }
    $update->execute();
    $update->close();
}

$conn->close();

// ============================================================
// ✅ ОЧИЩАЕМ СЕССИЮ ПОЛНОСТЬЮ
// ============================================================

// 1. Удаляем все переменные сессии
$_SESSION = array();

// 2. Удаляем куку сессии
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// 3. Удаляем куки "Запомнить меня"
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 42000, '/');
}
if (isset($_COOKIE['user_id'])) {
    setcookie('user_id', '', time() - 42000, '/');
}

// 4. Уничтожаем сессию на сервере
session_destroy();

// 5. Отправляем заголовки против кэширования
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

// 6. Перенаправляем на страницу входа
header("Location: login.php");
exit;

?>
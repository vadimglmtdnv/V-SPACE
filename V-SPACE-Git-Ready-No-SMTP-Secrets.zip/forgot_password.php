<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

if (isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

function ensurePasswordResetColumns(\mysqli $conn) {
    $result = $conn->query("SHOW COLUMNS FROM users");
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    
    if (!in_array('reset_token', $columns)) {
        $conn->query("ALTER TABLE users ADD COLUMN reset_token VARCHAR(64) NULL");
    }
    if (!in_array('reset_expires', $columns)) {
        $conn->query("ALTER TABLE users ADD COLUMN reset_expires DATETIME NULL");
    }
}

ensurePasswordResetColumns($conn);

// ===== ПОДКЛЮЧЕНИЕ PHPMailer =====
$phpMailerSrc = __DIR__ . '/includes/PHPMailer/src/';

$files = ['Exception.php', 'PHPMailer.php', 'SMTP.php'];
foreach ($files as $file) {
    $path = $phpMailerSrc . $file;
    if (!file_exists($path)) {
        die("Ошибка: Файл не найден: " . $path);
    }
    require_once $path;
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
// =================================

$message = "";
$error = "";
$old_email = "";

// После редиректа (Post/Redirect/Get) достаём результат прошлой отправки формы
if ($_SERVER["REQUEST_METHOD"] !== "POST" && isset($_SESSION['forgot_flash']) && is_array($_SESSION['forgot_flash'])) {
    $flash     = $_SESSION['forgot_flash'];
    unset($_SESSION['forgot_flash']);
    $message   = (string)($flash['message'] ?? '');
    $error     = (string)($flash['error'] ?? '');
    $old_email = (string)($flash['email'] ?? '');
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";

    if ($email === "") {
        $error = "Email обязателен.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Введите корректный email.";
    } else {
        $stmt = $conn->prepare("SELECT id, username, email FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if ($user) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?");
            $stmt->bind_param("ssi", $token, $expires, $user["id"]);
            
            if ($stmt->execute()) {
                $appUrl = rtrim((string)(function_exists('env') ? env('APP_URL', getenv('APP_URL') ?: '') : getenv('APP_URL')), '/');

                // Локальная разработка (XAMPP): если APP_URL не задан, строим адрес сами,
                // но только для localhost. На боевом сервере по-прежнему нужен APP_URL с HTTPS.
                if ($appUrl === '') {
                    $serverName = strtolower((string)($_SERVER['SERVER_NAME'] ?? ''));
                    if (in_array($serverName, ['localhost', '127.0.0.1', '::1'], true)) {
                        $isHttps = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
                        $port    = (int)($_SERVER['SERVER_PORT'] ?? ($isHttps ? 443 : 80));
                        $portStr = (($isHttps && $port === 443) || (!$isHttps && $port === 80)) ? '' : ':' . $port;
                        $host    = $serverName === '::1' ? '[::1]' : $serverName;
                        $basePath = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
                        $appUrl  = ($isHttps ? 'https' : 'http') . '://' . $host . $portStr . $basePath;
                    }
                    $appUrlIsLocal = $appUrl !== '';
                } else {
                    $appUrlIsLocal = false;
                }

                // http:// допускается только для localhost / 127.0.0.1 (локальная разработка)
                $appUrlHost  = strtolower((string)parse_url($appUrl, PHP_URL_HOST));
                $appUrlLocal = $appUrlIsLocal || in_array($appUrlHost, ['localhost', '127.0.0.1', '[::1]'], true);

                // Только адрес сайта (и, при необходимости, папка): без ?, #, пробелов и имён файлов (.php)
                $pathPart    = '(?:/[A-Za-z0-9_~-]+)*';
                $appUrlValid = $appUrlLocal
                    ? (bool)preg_match('#^https?://[^/?\\#\\s]+' . $pathPart . '$#i', $appUrl)
                    : (bool)preg_match('#^https://[^/?\\#\\s]+' . $pathPart . '$#i', $appUrl);
                if (!$appUrlValid) {
                    $appUrl = '';
                }
                $reset_link = $appUrl . "/reset_password.php?token=" . rawurlencode($token);
                
                $mail = new PHPMailer(true);

                try {
                    if ($appUrl === '') {
                        throw new Exception('APP_URL не настроен: задайте переменную окружения APP_URL (например, https://example.com).');
                    }
                    $mailConfig = require __DIR__ . '/mail_config.php';
                    $providers = is_array($mailConfig['providers'] ?? null) ? $mailConfig['providers'] : [];
                    $recipientDomain = strtolower(substr(strrchr($email, '@') ?: '', 1));
                    if ($recipientDomain === 'gmail.com' || $recipientDomain === 'googlemail.com') {
                        $providerKey = 'gmail';
                    } elseif (in_array($recipientDomain, ['yandex.ru', 'ya.ru', 'yandex.com', 'yandex.by', 'yandex.kz', 'yandex.ua'], true)) {
                        $providerKey = 'yandex';
                    } elseif (in_array($recipientDomain, ['mail.ru', 'inbox.ru', 'list.ru', 'bk.ru', 'internet.ru'], true)) {
                        $providerKey = 'mailru';
                    } else {
                        $providerKey = (string)($mailConfig['default_provider'] ?? 'default');
                    }
                    $provider = $providers[$providerKey] ?? null;

                    // Если для этого провайдера не заданы логин/пароль — берём общий (MAIL_*)
                    if (!is_array($provider) || trim((string)($provider['username'] ?? '')) === '' || trim((string)($provider['password'] ?? '')) === '') {
                        $provider = $providers[$mailConfig['default_provider'] ?? 'default'] ?? $provider;
                    }

                    if (!is_array($provider) || trim((string)($provider['username'] ?? '')) === '' || trim((string)($provider['password'] ?? '')) === '') {
                        throw new Exception('SMTP credentials are not configured.');
                    }

                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->SMTPAuth = true;
                    $mail->Host = trim((string)($provider['host'] ?? 'smtp.mail.ru'));
                    $mail->Username = trim((string)($provider['username'] ?? ''));
                    $mail->Password = trim((string)($provider['password'] ?? ''));
                    $mail->SMTPSecure = strtolower(trim((string)($provider['encryption'] ?? 'ssl'))) === 'starttls'
                        ? PHPMailer::ENCRYPTION_STARTTLS
                        : PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port = (int)($provider['port'] ?? 465);
                    $mail->setFrom($mail->Username, 'V SPACE');
                    $mail->addAddress($user['email'], $user['username']);
                    
                    $mail->isHTML(true);
                    $mail->CharSet = 'UTF-8';
                    $mail->Subject = 'Восстановление пароля — V SPACE';
                    
                    // Данные для письма (экранируем всё, что попадает в HTML)
                    $safeUser = htmlspecialchars((string)$user['username'], ENT_QUOTES, 'UTF-8');
                    $safeLink = htmlspecialchars($reset_link, ENT_QUOTES, 'UTF-8');

                    // Логотип встраивается в письмо как PNG (SVG почтовые клиенты — Gmail, Outlook, Mail.ru, Яндекс — не показывают).
                    // Файл: images/logo_email.png — логотип из logo_type.svg, лучше ширина 440 px (показывается как 220 px, чёткий на Retina),
                    // прозрачный фон, белые буквы (письмо рисует его на тёмно-синем фоне).
                    $logoFile = __DIR__ . '/images/logo_email.png';
                    if (is_file($logoFile)) {
                        $mail->addEmbeddedImage($logoFile, 'vspace_logo', 'logo.png', 'base64', 'image/png');
                        $logoHeader = "<img src='cid:vspace_logo' width='220' alt='V SPACE' style='display:block;margin:0 auto;border:0;outline:none;text-decoration:none;width:220px;max-width:100%;height:auto;'>";
                        $logoFooter = "<img src='cid:vspace_logo' width='104' alt='V SPACE' style='display:block;margin:0 auto;border:0;outline:none;text-decoration:none;width:104px;max-width:100%;height:auto;opacity:0.9;'>";
                    } else {
                        $logoHeader = "<span style='font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:32px;font-weight:800;letter-spacing:5px;color:#ffffff;'>V SPACE</span>";
                        $logoFooter = "<span style='font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;letter-spacing:3px;color:#ffffff;'>V SPACE</span>";
                    }

                    $year    = date('Y');
                    $safeApp = htmlspecialchars($appUrl, ENT_QUOTES, 'UTF-8');

                    // Анимированная шапка: images/email_space_header.gif (мерцающие звёзды + пролетающий метеор).
                    // Почтовые клиенты не поддерживают CSS/JS-анимацию, поэтому анимация — это GIF в фоне ячейки шапки.
                    // Если файла нет или клиент не грузит фоновые картинки — остаётся прежний синий градиент.
                    // Важно: GIF берётся по ссылке APP_URL, поэтому адрес должен быть доступен получателю (на боевом сервере — https).
                    $headerGradient = 'linear-gradient(135deg,#131847 0%,#2b3bdc 100%)';
                    $headerBgAttr   = '';
                    $headerBgStyle  = 'background-image:' . $headerGradient . ';';
                    if (is_file(__DIR__ . '/images/email_space_header.gif')) {
                        $headerGifUrl  = htmlspecialchars($appUrl . '/images/email_space_header.gif', ENT_QUOTES, 'UTF-8');
                        $headerBgAttr  = " background='" . $headerGifUrl . "'";
                        // Первая строка — запасной вариант для клиентов, которые не понимают несколько фонов сразу.
                        $headerBgStyle = 'background-image:' . $headerGradient . ';'
                                       . 'background-image:url(' . $headerGifUrl . '),' . $headerGradient . ';'
                                       . 'background-size:cover;background-position:center;background-repeat:no-repeat;';
                    }

                    $mail->Body = "
<!DOCTYPE html>
<html lang='ru'>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<meta name='color-scheme' content='light'>
<meta name='supported-color-schemes' content='light'>
<title>Восстановление пароля</title>
</head>
<body style='margin:0;padding:0;background-color:#e9ebf7;'>
<div style='display:none;max-height:0;overflow:hidden;opacity:0;color:#e9ebf7;font-size:1px;line-height:1px;'>
Ссылка для сброса пароля действует 1 час. Если это были не вы — просто проигнорируйте письмо.
</div>
<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='background-color:#e9ebf7;'>
<tr><td align='center' style='padding:36px 12px;'>

  <table role='presentation' width='600' cellpadding='0' cellspacing='0' border='0' style='width:100%;max-width:600px;background-color:#ffffff;border-radius:22px;overflow:hidden;box-shadow:0 16px 48px rgba(34,46,132,0.20);'>

    <!-- Цветная полоска -->
    <tr>
      <td height='5' style='height:5px;line-height:5px;font-size:1px;background-color:#8f9bff;background-image:linear-gradient(90deg,#3a4bea 0%,#8f9bff 50%,#3a4bea 100%);'>&nbsp;</td>
    </tr>

    <!-- Шапка с логотипом -->
    <tr>
      <td align='center' bgcolor='#1b2268'{$headerBgAttr} style='background-color:#1b2268;{$headerBgStyle}padding:46px 24px 40px 24px;'>
        {$logoHeader}
        <table role='presentation' cellpadding='0' cellspacing='0' border='0' align='center' style='margin:26px auto 0 auto;'>
          <tr>
            <td align='center' style='padding:7px 18px;border:1px solid rgba(170,182,255,0.35);border-radius:999px;background-color:rgba(255,255,255,0.08);font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:12px;font-weight:600;letter-spacing:3px;text-transform:uppercase;color:#c4ccff;'>
              Безопасный вход
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- Значок замка -->
    <tr>
      <td align='center' style='padding:38px 40px 0 40px;'>
        <table role='presentation' cellpadding='0' cellspacing='0' border='0'>
          <tr>
            <td align='center' width='68' height='68' style='width:68px;height:68px;border-radius:34px;background-color:#eef0ff;border:1px solid #dde1ff;font-size:30px;line-height:68px;text-align:center;'>
              &#128274;
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- Заголовок и текст -->
    <tr>
      <td align='center' style='padding:22px 44px 0 44px;font-family:Segoe UI,Helvetica,Arial,sans-serif;'>
        <div style='font-size:28px;line-height:1.25;font-weight:700;color:#151a4f;margin:0 0 16px 0;'>
          Восстановление пароля
        </div>
        <div style='font-size:16px;line-height:1.6;color:#2d3250;margin:0 0 10px 0;'>
          Здравствуйте, <strong>{$safeUser}</strong>!
        </div>
        <div style='font-size:15px;line-height:1.7;color:#5a607c;margin:0;'>
          Мы получили запрос на сброс пароля для вашего аккаунта на&nbsp;<strong style='color:#2d3250;'>V SPACE</strong>.
          Нажмите на кнопку ниже, чтобы придумать новый пароль.
        </div>
      </td>
    </tr>

    <!-- Кнопка -->
    <tr>
      <td align='center' style='padding:32px 40px 6px 40px;'>
        <table role='presentation' cellpadding='0' cellspacing='0' border='0'>
          <tr>
            <td align='center' bgcolor='#3a4bea' style='border-radius:14px;background-color:#3a4bea;background-image:linear-gradient(135deg,#5865f2 0%,#2b3bdc 100%);box-shadow:0 10px 24px rgba(58,75,234,0.38);'>
              <a href='{$safeLink}' target='_blank' style='display:inline-block;padding:18px 54px;font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:17px;font-weight:700;letter-spacing:0.3px;color:#ffffff;text-decoration:none;border-radius:14px;'>
                Сбросить пароль&nbsp;&#8594;
              </a>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- Срок действия -->
    <tr>
      <td align='center' style='padding:26px 40px 0 40px;'>
        <table role='presentation' cellpadding='0' cellspacing='0' border='0'>
          <tr>
            <td align='center' style='background-color:#fff7e0;border:1px solid #f6dc9a;border-radius:999px;padding:10px 22px;font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:14px;line-height:1.4;color:#7a5a00;'>
              &#9201;&nbsp; Ссылка действительна <strong>1 час</strong>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- Ссылка текстом -->
    <tr>
      <td style='padding:30px 40px 0 40px;font-family:Segoe UI,Helvetica,Arial,sans-serif;'>
        <div style='font-size:13px;color:#8b90a8;margin:0 0 8px 0;'>Если кнопка не работает, скопируйте ссылку в браузер:</div>
        <div style='background-color:#f3f4fb;border:1px solid #e1e4f3;border-radius:12px;padding:13px 15px;font-family:Consolas,Menlo,monospace;font-size:12px;line-height:1.55;color:#3a4bea;word-break:break-all;'>
          <a href='{$safeLink}' target='_blank' style='color:#3a4bea;text-decoration:none;'>{$safeLink}</a>
        </div>
      </td>
    </tr>

    <!-- Предупреждение -->
    <tr>
      <td style='padding:26px 40px 40px 40px;font-family:Segoe UI,Helvetica,Arial,sans-serif;'>
        <table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='background-color:#f6f7fd;border:1px solid #e6e9f7;border-radius:14px;'>
          <tr>
            <td width='34' valign='top' style='width:34px;padding:16px 0 16px 18px;font-size:20px;line-height:1.3;'>&#128737;</td>
            <td valign='top' style='padding:16px 18px 16px 8px;font-size:13px;line-height:1.65;color:#6b7190;'>
              <strong style='color:#3d4263;'>Это были не вы?</strong><br>
              Просто проигнорируйте это письмо — ваш пароль не изменится, а аккаунт останется в безопасности.
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- Подвал -->
    <tr>
      <td align='center' bgcolor='#131847' style='background-color:#131847;padding:30px 24px 28px 24px;font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:12px;line-height:1.7;color:#8f98d6;'>
        {$logoFooter}
        <div style='margin-top:16px;'>
          <a href='{$safeApp}' target='_blank' style='color:#b9c2ff;text-decoration:none;font-weight:600;'>Перейти на сайт</a>
        </div>
        <div style='margin-top:14px;'>
          © {$year} V SPACE. Все права защищены.<br>
          Это автоматическое сообщение, пожалуйста, не отвечайте на него.
        </div>
      </td>
    </tr>

  </table>

</td></tr>
</table>
</body>
</html>
                    ";
                    
                    $mail->AltBody = "Здравствуйте, {$user['username']}!\n\n";
                    $mail->AltBody .= "Вы запросили восстановление пароля на сайте V SPACE.\n\n";
                    $mail->AltBody .= "Для сброса пароля перейдите по ссылке:\n";
                    $mail->AltBody .= $reset_link . "\n\n";
                    $mail->AltBody .= "Ссылка действительна в течение 1 часа.\n\n";
                    $mail->AltBody .= "Если вы не запрашивали сброс пароля, просто проигнорируйте это письмо.\n\n";
                    $mail->AltBody .= "---\n";
                    $mail->AltBody .= "© " . date('Y') . " V SPACE. Все права защищены.\n";
                    $mail->AltBody .= "Это автоматическое сообщение, не отвечайте на него.";
                    
                    $mail->send();
                    $message = "Ссылка для сброса пароля отправлена на вашу почту. Проверьте папку Спам.";
                    
                } catch (Exception $e) {
                    $error = "Ошибка отправки письма: " . ($mail->ErrorInfo !== '' ? $mail->ErrorInfo : $e->getMessage());
                }
                
            } else {
                $error = "Ошибка сохранения токена: " . $conn->error;
            }
            $stmt->close();
        } else {
            $error = "Пользователь с таким email не найден.";
        }
    }
}

// Post/Redirect/Get: после отправки формы перенаправляем на эту же страницу обычным GET-запросом.
// Тогда обновление (F5) не вызывает окно «Подтвердите повторную отправку формы»
// и письмо со ссылкой не уходит повторно.
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $_SESSION['forgot_flash'] = [
        'message' => $message,
        'error'   => $error,
        'email'   => isset($email) ? $email : '',
    ];
    $conn->close();
    header("Location: forgot_password.php", true, 303);
    exit;
}

$conn->close();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>Восстановление пароля</title>
    <link rel="stylesheet" href="assets/css/auth-shared.css">
    <script src="assets/js/auth-shared.js"></script>
    <script src="assets/js/auth-bg.js"></script>
    
    <style>
        /* ===== Оформление страницы восстановления пароля — в одном стиле с login.php и register.php =====
           Переливающийся фон берётся из assets/css/auth-shared.css (.login-background). */
        * { box-sizing: border-box; }

        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            min-height: 100%;
            font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
            background: #313338;
            color: #f2f3f5;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        body .login-card {
            --accent: #5865f2;
            --green: #3ba55d;
            --red: #f23f42;
            --field: #1e1f22;
            --muted: #949ba4;
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 460px;
            padding: 36px 34px 30px;
            background: rgba(43, 45, 49, 0.30);
            -webkit-backdrop-filter: blur(14px);
            backdrop-filter: blur(14px);
            border: 1px solid rgba(255, 255, 255, 0.07);
            border-radius: 18px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.45), 0 2px 0 rgba(255, 255, 255, 0.03) inset;
            overflow: hidden;
        }

        body .login-card::before {
            content: '';
            position: absolute;
            left: 0; right: 0; top: 0;
            height: 3px;
            background: linear-gradient(90deg, #3a4bea, #8f9bff, #3a4bea);
        }

        body .login-card .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 22px;
            text-decoration: none;
        }

        body .login-card .login-title {
            text-align: center;
            font-size: 26px;
            font-weight: 700;
            letter-spacing: 0.2px;
            margin-bottom: 8px;
        }

        body .login-card .login-subtitle {
            text-align: center;
            font-size: 14px;
            color: var(--muted);
            margin-bottom: 26px;
        }

        body .login-card .form-group { margin-bottom: 18px; }

        body .login-card .form-label {
            display: block;
            margin-bottom: 8px;
            color: #b5bac1;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.7px;
        }

        body .login-card .form-input {
            --icon-left: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236d6f78' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='5' width='18' height='14' rx='2'/%3E%3Cpath d='m3 7 9 6 9-6'/%3E%3C/svg%3E");
            --icon-right: none;
            width: 100%;
            height: 48px;
            padding: 0 44px;
            border: 2px solid transparent;
            outline: none;
            border-radius: 10px;
            background-color: var(--field);
            background-image: var(--icon-left), var(--icon-right);
            background-repeat: no-repeat, no-repeat;
            background-position: 14px center, right 12px center;
            background-size: 18px 18px, 22px 22px;
            color: #f2f3f5;
            font-size: 15px;
            transition: border-color 0.2s, box-shadow 0.2s, background-color 0.2s;
        }

        body .login-card .form-input::placeholder { color: #6d6f78; }

        body .login-card .form-input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(88, 101, 242, 0.18);
        }

        body .login-card .form-input.error {
            --icon-right: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Ccircle cx='12' cy='12' r='11' fill='%23f23f42'/%3E%3Cpath d='m8.5 8.5 7 7m0-7-7 7' fill='none' stroke='white' stroke-width='2.4' stroke-linecap='round'/%3E%3C/svg%3E");
            border-color: var(--red);
            background-color: rgba(242, 63, 66, 0.07);
            box-shadow: 0 0 0 4px rgba(242, 63, 66, 0.16);
        }

        body .login-card .error-message,
        body .login-card .success-message {
            margin-top: 10px;
            padding: 12px 15px;
            border-radius: 10px;
            font-size: 14px;
            line-height: 1.5;
        }

        body .login-card .error-message {
            background: rgba(242, 63, 66, 0.14);
            border: 1px solid rgba(242, 63, 66, 0.4);
            color: #ff8a8c;
        }

        body .login-card .success-message {
            background: rgba(59, 165, 93, 0.14);
            border: 1px solid rgba(59, 165, 93, 0.45);
            color: #6fd58f;
        }

        body .login-card .login-button {
            width: 100%;
            height: 50px;
            margin-top: 6px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(135deg, #5865f2 0%, #3a4bea 100%);
            color: #fff;
            font-size: 15px;
            font-weight: 700;
            letter-spacing: 0.3px;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(58, 75, 234, 0.35);
            transition: transform 0.12s, box-shadow 0.2s, filter 0.2s;
        }

        body .login-card .login-button:hover {
            filter: brightness(1.08);
            box-shadow: 0 10px 26px rgba(58, 75, 234, 0.5);
        }

        body .login-card .login-button:active { transform: translateY(1px); }

        body .login-card .divider {
            border: none;
            height: 1px;
            background: rgba(255, 255, 255, 0.09);
            margin: 24px 0 14px;
        }

        body .login-card .links { text-align: center; }

        body .login-card .links a {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 9px 16px;
            border-radius: 10px;
            color: #8f9bff;
            text-decoration: none;
            font-size: 14px;
            font-weight: 700;
            transition: color 0.15s, background 0.15s;
        }

        body .login-card .links a:hover {
            color: #fff;
            background: rgba(88, 101, 242, 0.16);
        }

        body .login-card .links .back-icon {
            width: 18px;
            height: 18px;
            flex: 0 0 auto;
            transition: transform 0.18s;
        }

        body .login-card .links a:hover .back-icon { transform: translateX(-3px); }

        @media (max-width: 520px) {
            body { padding: 12px; }
            body .login-card { padding: 28px 20px 24px; border-radius: 14px; }
            body .login-card .login-title { font-size: 23px; }
        }

        @media (prefers-reduced-motion: reduce) {
            body .login-card * { transition: none !important; }
        }
    </style>
</head>
<body>
    
    <div class="login-background"></div>
    
    <div class="login-card">
        
        <a href="index.php" class="logo">
            <img src="images/logo_type.svg" alt="SPACE" height="56" style="width:auto;height:56px;display:block;">
        </a>
        
        <div class="login-title">Восстановление пароля</div>
        <div class="login-subtitle">Введите ваш email для сброса пароля</div>
        
        <form action="forgot_password.php" method="POST" novalidate>
            <div class="form-group">
                <label class="form-label" for="email">Email Адрес</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    autocomplete="email"
                    class="form-input <?= ($error !== "") ? 'error' : '' ?>"
                    placeholder="Введите email"
                    value="<?= htmlspecialchars($old_email, ENT_QUOTES, "UTF-8") ?>"
                >
                <?php if ($error !== ""): ?>
                    <div class="error-message"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
                <?php endif; ?>
                <?php if ($message !== ""): ?>
                    <div class="success-message"><?= $message ?></div>
                <?php endif; ?>
            </div>
            
            <button type="submit" class="login-button">Отправить ссылку</button>
        </form>
        
        <hr class="divider">
        
        <div class="links">
            <a href="login.php">
                <svg class="back-icon" viewBox="0 0 24 24" fill="none" stroke="url(#backArrowGrad)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <defs>
                        <linearGradient id="backArrowGrad" gradientUnits="userSpaceOnUse" x1="3" y1="3" x2="21" y2="21">
                            <stop offset="0" stop-color="#38b6ff"/>
                            <stop offset="0.5" stop-color="#5865f2"/>
                            <stop offset="1" stop-color="#9a6bff"/>
                        </linearGradient>
                    </defs>
                    <path d="M19 12H5"/>
                    <path d="M12 19l-7-7 7-7"/>
                </svg>
                <span>Вернуться на страницу входа</span>
            </a>
        </div>
        
    </div>
    
</body>
</html>
<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
if (is_file(__DIR__ . '/includes/error_logger.php')) { require_once __DIR__ . '/includes/error_logger.php'; }
require_once __DIR__ . '/maintenance.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/includes/env.php';

// Доступы к БД берём из .env через includes/env.php (константы DB_*), в коде их нет.
// Подробности ошибки пишем только в лог сервера, пользователю не показываем.
$conn = null;
try {
    $conn = db_connect();
} catch (mysqli_sql_exception $e) {
    error_log('[help] DB connect failed: ' . $e->getMessage());
    $conn = null;
}

if (!$conn || $conn->connect_error) {
    if ($conn) {
        error_log('[help] DB connect failed: ' . $conn->connect_error);
    }
    http_response_code(500);
    die('Сервис временно недоступен. Попробуйте позже.');
}

$conn->set_charset("utf8mb4");

$user_id = (int)$_SESSION["user_id"];

/*
|--------------------------------------------------------------------------
| Тема оформления — та же логика, что и в messages.php: переключение через
| ?theme=... сохраняет выбор в куке на год и возвращает на эту же страницу.
|--------------------------------------------------------------------------
*/
if (isset($_GET['theme'])) {
    $allowed_themes = ['dark', 'light', 'system'];
    $theme = in_array($_GET['theme'], $allowed_themes, true) ? $_GET['theme'] : 'dark';
    setcookie('theme', $theme, [
        'expires'  => time() + 365 * 24 * 60 * 60,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    header('Location: help.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Пометить уведомления прочитанными — обычный POST в саму страницу,
| без обращения к отдельному API messages.php (которого здесь нет под рукой).
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_notifications_read') {
    $notifTable = $conn->query("SHOW TABLES LIKE 'notifications'");
    if ($notifTable && $notifTable->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: help.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| Данные пользователя
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT username, avatar, status, last_seen, is_admin
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();


if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$username = $user["username"] ?? "Пользователь";
$avatar = $user["avatar"] ?? "";
$user_status = $user["status"] ?? "offline";
$user_last_seen = $user["last_seen"] ?? null;
$is_admin = !empty($user["is_admin"]);
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], ['dark', 'light', 'system'], true)
    ? $_COOKIE['theme']
    : 'dark';

$avatarLetter = mb_strtoupper(
    mb_substr(
        $username ?: "Я",
        0,
        1,
        "UTF-8"
    ),
    "UTF-8"
);

$avatarExists = !empty($avatar) && file_exists($avatar);

/*
|--------------------------------------------------------------------------
| Уведомления — тот же запрос, что и в шапке messages.php (те же типы
| исключены из колокольчика, т.к. у них своя логика показа).
|--------------------------------------------------------------------------
*/
$notifications = [];
$notif_count = 0;
$notifTable = $conn->query("SHOW TABLES LIKE 'notifications'");
if ($notifTable && $notifTable->num_rows > 0) {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        if (empty($row['sender_avatar']) && !empty($row['sender_id'])) {
            $stmt2 = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
            $stmt2->bind_param("i", $row['sender_id']);
            $stmt2->execute();
            $res2 = $stmt2->get_result();
            if ($sender_row = $res2->fetch_assoc()) {
                $row['sender_avatar'] = $sender_row['avatar'];
            }
            $stmt2->close();
        }
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM notifications
        WHERE user_id = ?
          AND is_read = 0
          AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();
}

/*
|--------------------------------------------------------------------------
| Жалобы, ожидающие модерации — как в messages.php, только для админов.
|--------------------------------------------------------------------------
*/
$pending_reports_count = 0;
if ($is_admin) {
    $reportsTable = $conn->query("SHOW TABLES LIKE 'reports'");
    if ($reportsTable && $reportsTable->num_rows > 0) {
        $res = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
        if ($res) {
            $pending_reports_count = (int)$res->fetch_assoc()['c'];
        }
    }
}

$conn->close();


/*
|--------------------------------------------------------------------------
| Функции
|--------------------------------------------------------------------------
*/

// Онлайн — если статус "online" и последняя активность была не более 2 минут назад.
function isOnline(?string $status, ?string $last_seen = null): bool
{
    if ($status !== 'online') {
        return false;
    }
    if ($last_seen === null || $last_seen === '') {
        return false;
    }
    $ts = strtotime($last_seen);
    return $ts !== false && (time() - $ts) >= 0 && (time() - $ts) <= 120;
}

function safeFileExists(?string $path): bool
{
    if (empty($path)) return false;
    return file_exists($path);
}

function getAvatarLetter(?string $username): string
{
    if (empty($username)) return '?';
    return mb_strtoupper(mb_substr($username, 0, 1, 'UTF-8'), 'UTF-8');
}

function timeAgo(?string $datetime): string
{
    if (empty($datetime)) return 'неизвестно';
    $ts = strtotime($datetime);
    if ($ts === false) return 'неизвестно';
    $diff = time() - $ts;
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . 'м';
    if ($diff < 86400) return floor($diff / 3600) . 'ч';
    if ($diff < 604800) return floor($diff / 86400) . 'д';
    return date('d.m.Y', $ts);
}

function formatNotification(string $type, string $message): array
{
    $icons = [
        'message' => '💬', 'news' => '📰', 'friend_request' => '👋',
        'friend_accepted' => '✅', 'friend_removed' => '❌', 'like' => '❤️',
        'comment' => '💭', 'report' => '⚠️', 'warning' => '⚡',
        'system' => '🔔', 'friend' => '👤', 'invite' => '📨',
        'group' => '👥', 'mention' => '@',
    ];
    return ['icon' => $icons[$type] ?? '🔔', 'text' => $message];
}

// Та же шапка уведомлений, что и в index.php / settings.php: иконка и
// человекочитаемое название по типу уведомления.
function getNotificationIcon(string $type): string
{
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function getNotificationTypeName(string $type): string
{
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>Помощь</title>

    <link rel="stylesheet" href="assets/css/index.css"><!-- общие стили шапки, как в index.php -->
    <link rel="stylesheet" href="assets/css/help.css">
    <style>
        /* шапка — те же правила, что в index.php */
        .header-right { gap: 10px !important; }
        .header-right .avatar-dropdown { margin-left: 4px !important; }
        .header-left { display: flex; align-items: center; gap: 20px; }

        /* Иконки страницы помощи: сами SVG вставлены прямо в разметку (с inline-стилями),
           здесь только блок обращения. Плитку .help-icon оформляет help.css. */
        .support-icon-wrap { margin-bottom: 14px; line-height: 0; }
        .support-icon { display: inline-flex; align-items: center; justify-content: center; width: 52px; height: 52px; border-radius: 16px; background: var(--accent, #5865f2); }
        .support-card .button { display: inline-flex; align-items: center; justify-content: center; gap: 8px; }

        /* ================= Новый дизайн страницы помощи ================= */
        .content { --hp-text:#f2f3f5; --hp-muted:#a3a8b4; --hp-surface:rgba(255,255,255,.045); --hp-surface-hover:rgba(255,255,255,.08); --hp-border:rgba(255,255,255,.09); --hp-border-strong:rgba(255,255,255,.2); }
        [data-theme="light"] .content { --hp-text:#1b1d24; --hp-muted:#5d6270; --hp-surface:rgba(255,255,255,.9); --hp-surface-hover:#fff; --hp-border:rgba(20,25,45,.09); --hp-border-strong:rgba(20,25,45,.2); }
        @media (prefers-color-scheme: light) {
            [data-theme="system"] .content { --hp-text:#1b1d24; --hp-muted:#5d6270; --hp-surface:rgba(255,255,255,.9); --hp-surface-hover:#fff; --hp-border:rgba(20,25,45,.09); --hp-border-strong:rgba(20,25,45,.2); }
        }

        .content .content-title { font-size:clamp(28px,3vw,36px); font-weight:700; letter-spacing:-.02em; line-height:1.15; color:var(--hp-text); }
        .content .content-subtitle { margin-top:8px; font-size:16px; line-height:1.5; color:var(--hp-muted); }

        .content .help-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:16px; max-width:1120px; margin:28px 0 0; }

        /* Цвет плитки = тема раздела (палитра по мотивам планет в шапке) */
        .help-card--blue   { --tone-a:#5aa8ff; --tone-b:#2f63e0; --tone-glow:rgba(47,99,224,.8); }
        .help-card--teal   { --tone-a:#35d6a4; --tone-b:#13967a; --tone-glow:rgba(19,150,122,.8); }
        .help-card--accent { --tone-a:#7a85ff; --tone-b:#4752d6; --tone-glow:rgba(71,82,214,.85); }
        .help-card--gold   { --tone-a:#f0ab3a; --tone-b:#c96a12; --tone-glow:rgba(201,106,18,.8); }
        .help-card--coral  { --tone-a:#ff8f6b; --tone-b:#d9432b; --tone-glow:rgba(217,67,43,.8); }
        .help-card--violet { --tone-a:#c77dff; --tone-b:#8a3fd6; --tone-glow:rgba(138,63,214,.8); }

        .content .help-grid .help-card { position:relative; display:flex; flex-direction:column; padding:24px; border-radius:20px; background:var(--hp-surface); border:1px solid var(--hp-border); color:var(--hp-text); text-decoration:none; box-shadow:none; transform:none; transition:border-color .2s, background-color .2s; }
        .content .help-grid .help-card::after { content:""; position:absolute; top:24px; right:22px; width:18px; height:18px; background:currentColor; opacity:.35; -webkit-mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='black' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m9 6 6 6-6 6'/%3E%3C/svg%3E") center/contain no-repeat; mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='black' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m9 6 6 6-6 6'/%3E%3C/svg%3E") center/contain no-repeat; transition:opacity .2s, transform .2s; }
        .content .help-grid .help-card:hover { background:var(--hp-surface-hover); border-color:var(--tone-a); }
        .content .help-grid .help-card:hover::after { opacity:.8; transform:translateX(2px); }
        .content .help-grid .help-card:focus-visible, .support-card .button:focus-visible { outline:2px solid var(--tone-a, var(--accent,#5865f2)); outline-offset:3px; }

        .content .help-card .help-icon { display:flex; align-items:center; justify-content:center; width:48px; height:48px; margin:0 0 18px; border-radius:14px; background:linear-gradient(145deg,var(--tone-a),var(--tone-b)); box-shadow:0 8px 20px -8px var(--tone-glow), inset 0 1px 0 rgba(255,255,255,.28); }
        .content .help-card .help-title { margin:0 0 6px; padding-right:28px; font-size:17px; font-weight:600; line-height:1.3; color:var(--hp-text); }
        .content .help-card .help-text { margin:0; font-size:14.5px; line-height:1.55; color:var(--hp-muted); }

        /* Блок поддержки: на ПК — одна широкая полоса */
        .content .support-card { display:grid; grid-template-columns:auto 1fr auto; align-items:center; column-gap:22px; max-width:1120px; margin:20px 0 0; padding:26px 28px; text-align:left; border-radius:22px; border:1px solid var(--hp-border); background:radial-gradient(120% 140% at 0% 0%, rgba(88,101,242,.22), transparent 55%), var(--hp-surface); }
        .support-card .support-icon-wrap { margin:0; }
        .support-card .support-icon { background:linear-gradient(145deg,#7a85ff,#4752d6); box-shadow:0 8px 20px -8px rgba(71,82,214,.85), inset 0 1px 0 rgba(255,255,255,.28); }
        .support-card .support-title { margin:0 0 4px; font-size:19px; font-weight:700; color:var(--hp-text); }
        .support-card .support-text { margin:0; max-width:52ch; font-size:14.5px; line-height:1.55; color:var(--hp-muted); }
        .support-card .support-actions { display:flex; flex-wrap:wrap; gap:10px; }
        .support-card .button { height:44px; margin:0; padding:0 20px; border-radius:12px; font-weight:600; text-decoration:none; }
        .support-card .button:not(.secondary) { background:var(--accent,#5865f2); color:#fff; border:1px solid transparent; }
        .support-card .button.secondary { background:transparent; color:var(--hp-text); border:1px solid var(--hp-border-strong); }

        @media (max-width:760px) {
            .content .support-card { grid-template-columns:1fr; row-gap:14px; padding:20px; }
            .support-card .support-actions { flex-direction:column; }
            .support-card .button { width:100%; }
        }
        @media (max-width:640px) {
            .content .help-grid { grid-template-columns:1fr; gap:10px; margin-top:20px; }
            .content .help-grid .help-card { display:grid; grid-template-columns:44px 1fr; column-gap:14px; align-items:center; padding:14px 40px 14px 14px; border-radius:16px; }
            .content .help-grid .help-card::after { top:50%; right:14px; transform:translateY(-50%); }
            .content .help-grid .help-card:hover::after { transform:translateY(-50%) translateX(2px); }
            .content .help-card .help-icon { grid-row:1 / 3; width:44px; height:44px; margin:0; border-radius:12px; }
            .content .help-card .help-title { margin:0 0 2px; padding:0; font-size:16px; }
            .content .help-card .help-text { font-size:13.5px; line-height:1.45; }
        }

        /* ================= Шапка для телефона ================= */
        .header-page-title { display:none; }
        @media (max-width:768px) {
            body { padding-top:0 !important; }
            .layout { margin-top:0 !important; padding-top:0 !important; }
            .content { padding-bottom:calc(96px + env(safe-area-inset-bottom,0px)); }

            .header { position:sticky !important; top:0 !important; left:auto !important; right:auto !important; width:100% !important; box-sizing:border-box; display:flex !important; align-items:center; gap:10px; height:calc(56px + env(safe-area-inset-top,0px)) !important; min-height:0 !important; padding:env(safe-area-inset-top,0px) 12px 0 !important; z-index:1000; }
            .header .header-space, .header .search-box { display:none !important; }   /* планеты и корабль — только на ПК */
            .header .header-left { flex:0 0 auto; gap:0; }
            .header .logo-icon, .header .logo-icon img { width:32px !important; height:32px !important; }
            .header-page-title { display:block; flex:1 1 auto; min-width:0; font-size:18px; font-weight:700; letter-spacing:-.01em; color:inherit; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
            .header .header-right { flex:0 0 auto; margin-left:auto; gap:6px !important; }
            .header .header-right .avatar-dropdown { margin-left:2px !important; }
            .header .notifications-btn, .header .moderation-btn { display:inline-flex; align-items:center; justify-content:center; width:42px; height:42px; border-radius:12px; }
            .header .notifications-btn img, .header .moderation-icon { width:22px; height:22px; }
            .header .header-avatar { width:36px; height:36px; }

            /* выпадашки — под шапкой, не вылезают за экран */
            .header .notifications-wrapper, .header .avatar-dropdown { position:static !important; }
            .header .notifications-dropdown { position:absolute !important; top:calc(100% + 8px) !important; left:8px !important; right:8px !important; width:auto !important; max-width:none !important; max-height:min(70vh,520px) !important; overflow-y:auto; }
            .header .dropdown-menu { position:absolute !important; top:calc(100% + 8px) !important; left:auto !important; right:8px !important; width:min(320px,calc(100vw - 16px)) !important; }
        }
        @media (prefers-reduced-motion: reduce) {
            .content .help-grid .help-card, .content .help-grid .help-card::after { transition:none; }
        }

        /* ===== Профиль и уведомления всегда видны; страница не шире экрана ===== */
        .header .header-right { display:flex !important; align-items:center; flex-shrink:0; min-width:0; position:relative; z-index:3; }
        .header .header-right .notifications-wrapper, .header .header-right .avatar-dropdown { display:block !important; visibility:visible !important; opacity:1 !important; }
        .header .header-right .notifications-btn { display:inline-flex !important; align-items:center; justify-content:center; visibility:visible !important; opacity:1 !important; }
        .header .header-right .header-avatar { display:flex !important; align-items:center; justify-content:center; visibility:visible !important; opacity:1 !important; }
        @media (max-width:1100px) {
            .header .search-box { flex:1 1 0 !important; width:auto !important; min-width:0 !important; }
        }
        .layout, .content { min-width:0; max-width:100%; box-sizing:border-box; }
        .content .help-grid { grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr)) !important; }
        .content .support-card { max-width:100%; box-sizing:border-box; }

        /* ===== Резиновый каркас, как в index.php (help.css фиксировал 1200px и ломал телефон) ===== */
        html, body { min-width:0 !important; overflow-x:visible !important; }
        .layout { width:min(90%,1200px) !important; min-width:0 !important; max-width:1200px !important; padding-left:0 !important; padding-right:0 !important; }
        .content { width:100% !important; min-width:0 !important; max-width:960px !important; margin-left:auto; margin-right:auto; }
        .bottom-nav { min-width:0 !important; }
        @media (max-width:860px) {
            .layout { width:calc(100% - 24px) !important; }
        }
    </style>

<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
    <link rel="stylesheet" href="assets/css/theme-switch.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/theme-switch.css') ?>">
    <script src="assets/js/header-dropdowns.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/header-dropdowns.js') ?>" defer></script>
    <script src="assets/js/theme-switch.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/theme-switch.js') ?>" defer></script>
</head>

<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>">

<header class="header header-cosmic">
    <!-- Космос в шапке: планеты, пояс астероидов и пролетающий корабль -->
    <span class="header-space" aria-hidden="true">
        <svg class="hs-defs" width="0" height="0" focusable="false">
            <defs>
                <linearGradient id="hs-rock" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9097a8"/><stop offset="1" stop-color="#474c5a"/></linearGradient>
                <radialGradient id="hs-sat" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffe6b8"/><stop offset=".55" stop-color="#e9a24f"/><stop offset="1" stop-color="#7a3f17"/></radialGradient>
                <radialGradient id="hs-nep" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#bfe3ff"/><stop offset=".55" stop-color="#3f8cf0"/><stop offset="1" stop-color="#14307a"/></radialGradient>
                <radialGradient id="hs-mars" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffb199"/><stop offset=".6" stop-color="#d8512f"/><stop offset="1" stop-color="#6b1d10"/></radialGradient>
                <linearGradient id="hs-hull" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#a9b1c4"/></linearGradient>
                <linearGradient id="hs-glass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a6ecff"/><stop offset="1" stop-color="#2f7fe0"/></linearGradient>
                <linearGradient id="hs-fire" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="#fff3a8"/><stop offset=".45" stop-color="#ffa63d"/><stop offset="1" stop-color="#ff4d1f" stop-opacity="0"/></linearGradient>

                <symbol id="hs-rock-a" viewBox="0 0 24 24">
                    <polygon points="4,9 8,3 15,2 21,7 22,14 17,21 9,22 3,16" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                    <circle cx="9" cy="9" r="2.2" fill="#000" opacity=".28"/><circle cx="15.5" cy="14" r="2.8" fill="#000" opacity=".25"/><circle cx="8" cy="16.5" r="1.5" fill="#000" opacity=".28"/>
                </symbol>
                <symbol id="hs-rock-b" viewBox="0 0 24 24">
                    <polygon points="3,12 6,5 13,3 20,5 22,12 18,19 11,22 5,19" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                    <circle cx="12" cy="8" r="2.4" fill="#000" opacity=".26"/><circle cx="8" cy="15" r="2" fill="#000" opacity=".28"/><circle cx="16.5" cy="15.5" r="1.6" fill="#000" opacity=".25"/>
                </symbol>
                <symbol id="hs-rock-c" viewBox="0 0 24 24">
                    <polygon points="2,11 7,5 17,4 23,10 21,17 12,20 5,18" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                    <circle cx="10" cy="10" r="2.6" fill="#000" opacity=".26"/><circle cx="17" cy="13" r="1.8" fill="#000" opacity=".28"/>
                </symbol>
            </defs>
        </svg>

        <!-- Планеты -->
        <svg class="hs-planet hs-planet-ringed" viewBox="0 0 80 50">
            <g transform="rotate(-16 40 25)">
                <ellipse cx="40" cy="25" rx="36" ry="9" fill="none" stroke="#f4d28a" stroke-width="3" opacity=".55"/>
                <circle cx="40" cy="25" r="15" fill="url(#hs-sat)"/>
                <path d="M26 21 Q40 17.5 54 21 M25.6 29 Q40 33 54.4 29" fill="none" stroke="#fff" stroke-width="1.6" opacity=".28" stroke-linecap="round"/>
                <path d="M4 25 A36 9 0 0 0 76 25" fill="none" stroke="#ffd98e" stroke-width="3" stroke-linecap="round"/>
            </g>
        </svg>
        <svg class="hs-planet hs-planet-blue" viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="14" fill="url(#hs-nep)"/>
            <path d="M7.5 16 Q20 12 32.5 16 M6.5 23 Q20 27 33.5 23" fill="none" stroke="#fff" stroke-width="1.6" opacity=".3" stroke-linecap="round"/>
            <circle cx="35" cy="7" r="3" fill="#cfd6e6"/><circle cx="34" cy="6" r="1" fill="#fff" opacity=".7"/>
        </svg>
        <svg class="hs-planet hs-planet-red" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" fill="url(#hs-mars)"/>
            <ellipse cx="9" cy="9" rx="2.2" ry="1.6" fill="#000" opacity=".22"/><ellipse cx="15" cy="14.5" rx="2.6" ry="1.8" fill="#000" opacity=".2"/>
        </svg>

        <!-- Пояс астероидов: плывут справа налево -->
        <span class="hs-asteroid" style="--y:9px;  --s:11px; --dur:46s; --delay:-9s;  --spin:360deg;  --sx:8%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
        <span class="hs-asteroid" style="--y:38px; --s:16px; --dur:62s; --delay:-31s; --spin:-300deg; --sx:20%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>
        <span class="hs-asteroid" style="--y:22px; --s:8px;  --dur:38s; --delay:-14s; --spin:420deg;  --sx:37%"><svg viewBox="0 0 24 24"><use href="#hs-rock-c"/></svg></span>
        <span class="hs-asteroid" style="--y:46px; --s:10px; --dur:54s; --delay:-44s; --spin:-360deg; --sx:50%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
        <span class="hs-asteroid hs-far" style="--y:5px;  --s:14px; --dur:70s; --delay:-21s; --spin:240deg;  --sx:64%"><svg viewBox="0 0 24 24"><use href="#hs-rock-c"/></svg></span>
        <span class="hs-asteroid hs-far" style="--y:30px; --s:9px;  --dur:42s; --delay:-3s;  --spin:-420deg; --sx:72%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>
        <span class="hs-asteroid hs-far" style="--y:14px; --s:6px;  --dur:34s; --delay:-26s; --spin:300deg;  --sx:28%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
        <span class="hs-asteroid hs-far" style="--y:42px; --s:7px;  --dur:50s; --delay:-18s; --spin:-240deg; --sx:44%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>

        <!-- Космический корабль -->
        <span class="hs-ship">
            <svg viewBox="0 0 64 28">
                <path class="hs-flame" d="M12 10.5 L0 14 L12 17.5Z" fill="url(#hs-fire)"/>
                <path d="M15 10 L21 2 L28 10Z" fill="#5865f2" stroke="#2a31a0" stroke-width="1" stroke-linejoin="round"/>
                <path d="M15 18 L21 26 L28 18Z" fill="#5865f2" stroke="#2a31a0" stroke-width="1" stroke-linejoin="round"/>
                <rect x="10" y="10" width="5" height="8" rx="1.5" fill="#3a3f4b"/>
                <path d="M14 8 H40 Q56 8 63 14 Q56 20 40 20 H14 Q11 14 14 8Z" fill="url(#hs-hull)" stroke="#59607a" stroke-width="1" stroke-linejoin="round"/>
                <path d="M16 15 H36" stroke="#5865f2" stroke-width="2" stroke-linecap="round"/>
                <ellipse cx="46" cy="13.4" rx="6.4" ry="3.6" fill="url(#hs-glass)" stroke="#2a4f9c" stroke-width=".8"/>
                <ellipse cx="44.4" cy="12.2" rx="2.4" ry="1" fill="#fff" opacity=".7"/>
                <circle cx="22" cy="12.4" r="1.2" fill="#2f7fe0"/><circle cx="27" cy="12.4" r="1.2" fill="#2f7fe0"/><circle cx="32" cy="12.4" r="1.2" fill="#2f7fe0"/>
            </svg>
        </span>
    </span>
    <span class="header-shooting-stars" aria-hidden="true">
        <span class="sky-cloud" aria-hidden="true"></span>
        <span class="sky-rain" aria-hidden="true"></span>
        <span class="sky-snow" aria-hidden="true"></span>
        <span class="sky-fog" aria-hidden="true"></span>
        <span class="sky-flash" aria-hidden="true"></span>
        <span class="header-shooting-star star-one"></span>
        <span class="header-shooting-star star-two"></span>
        <span class="header-shooting-star star-three"></span>
        <span class="header-comet"></span>
    </span>
    <div class="header-left">
        <div class="logo">
            <div class="logo-icon">
                <img src="images/logo_type.svg" alt="SPACE Logo" width="40" height="40">
            </div>
        </div>
    </div>
    <div class="header-page-title">Помощь</div>
    <div class="search-box"></div>
    <div class="header-right">

        <?php if ($is_admin): ?>
            <a href="reports.php" class="moderation-btn" title="Модерация">
            <img src="images/protection.svg" alt="Модерация" class="moderation-icon">
            <?php if ($pending_reports_count > 0): ?>
                <span class="moderation-badge"><?= $pending_reports_count > 99 ? '99+' : $pending_reports_count ?></span>
            <?php endif; ?>
        </a>
        <?php endif; ?>

        <div class="notifications-wrapper">
            <button class="notifications-btn" id="notificationsBtn" aria-label="Уведомления">
                <?php include __DIR__ . '/includes/notification_bell.php'; ?>
                <?php if ($notif_count > 0): ?>
                    <span class="notifications-badge" id="notificationsBadge"><?= $notif_count > 99 ? '99+' : $notif_count ?></span>
                <?php else: ?>
                    <span class="notifications-badge" id="notificationsBadge" style="display:none;">0</span>
                <?php endif; ?>
            </button>
            <div class="notifications-dropdown" id="notificationsDropdown">
                <div class="notifications-header">
                    <span class="notifications-title">Уведомления</span>
                    <div class="notifications-header-actions">
                        <?php if ($notif_count > 0): ?>
                            <form method="POST" action="" style="margin:0;">
                            <input type="hidden" name="action" value="mark_notifications_read">
                            <button type="submit" class="mark-all-read-btn" id="markAllReadBtn">Все прочитано</button>
                        </form>
                        <?php endif; ?>
                        <span class="notifications-count" id="notificationsCount"><?= $notif_count ?> новых</span>
                    </div>
                </div>
                <div class="notifications-list" id="notificationsList">
                    <?php if (empty($notifications)): ?>
                        <div class="notifications-empty">
                            <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
                            <div class="empty-text">Нет уведомлений</div>
                            <div class="empty-sub">Здесь будут появляться ваши уведомления</div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($notifications as $notif): 
                            $icon = getNotificationIcon((string)$notif['type']);
                            $notif_type_class = $notif['type'];
                            $sender_avatar = $notif['sender_avatar'] ?? '';
                            $sender_name = $notif['sender_name'] ?? '';
                            
                            $avatar_exists = false;
                            if (!empty($sender_avatar)) {
                                $paths_to_check = [
                                    $sender_avatar,
                                    'uploads/avatars/' . basename($sender_avatar),
                                    'assets/images/' . basename($sender_avatar)
                                ];
                                foreach ($paths_to_check as $path) {
                                    if (file_exists($path)) {
                                        $avatar_exists = true;
                                        $sender_avatar = $path;
                                        break;
                                    }
                                }
                            }
                        ?>
                            <a href="<?= htmlspecialchars($notif['link'] ?: '#') ?>" class="notification-item <?= $notif['is_read'] ? 'read' : 'unread' ?> type-<?= htmlspecialchars($notif_type_class) ?>" data-notification-id="<?= $notif['id'] ?>">
                                <div class="notif-avatar-wrapper">
                                    <div class="notif-avatar">
                                        <?php if ($avatar_exists): ?>
                                            <img src="<?= htmlspecialchars($sender_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?>">
                                        <?php elseif (!empty($sender_name)): ?>
                                            <span class="avatar-letter"><?= htmlspecialchars(mb_strtoupper(mb_substr($sender_name, 0, 1, 'UTF-8'), 'UTF-8')) ?></span>
                                        <?php else: ?>
                                            <span class="avatar-letter">?</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="notif-content">
                                    <div class="notif-text">
                                        <?php if (!empty($sender_name)): ?>
                                            <?php
                                            // Ник уже выведен жирным — не повторяем его в начале текста («Vadim Vadim поставил(а)…»)
                                            $notif_msg = (string)$notif['message'];
                                            if (mb_strpos($notif_msg, (string)$sender_name) === 0) {
                                                $notif_msg = ltrim(mb_substr($notif_msg, mb_strlen((string)$sender_name)));
                                            }
                                            ?>
                                            <strong class="notif-sender"><?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?></strong><span class="notif-message"><?= htmlspecialchars($notif_msg, ENT_QUOTES, "UTF-8") ?></span>
                                        <?php else: ?>
                                            <span class="notif-message"><?= htmlspecialchars($notif['message'], ENT_QUOTES, "UTF-8") ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="notif-meta">
                                        <span class="notif-time"><?= timeAgo($notif['created_at']) ?></span>
                                    </div>
                                </div>
                                <?php if (!$notif['is_read']): ?>
                                    <span class="notif-dot"></span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div class="notifications-footer">
                    <a href="notifications.php" class="view-all-notifications">Показать всё</a>
                </div>
            </div>
        </div>

        <div class="avatar-dropdown">
            <?php
        $current_avatar = $avatar;
        $current_username = $username;
        require_once __DIR__ . '/includes/display_name.php'; $current_username = userDisplayName($conn ?? null, (int)($_SESSION['user_id'] ?? 0), (string)$current_username);
        $current_letter = $avatarLetter;
        $current_status = 'online';
        ?>
            <button class="header-avatar <?= isOnline($current_status, date('Y-m-d H:i:s')) ? 'is-online' : 'is-offline' ?>" id="avatarBtn" aria-label="Мой профиль">
                <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                    <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                <?php else: ?>
                    <?= htmlspecialchars($current_letter) ?>
                <?php endif; ?>
            </button>
            <div class="dropdown-menu" id="avatarDropdown">
                <div class="dropdown-header">
                    <div class="dropdown-avatar">
                        <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                            <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                        <?php else: ?>
                            <?= htmlspecialchars($current_letter) ?>
                        <?php endif; ?>
                    </div>
                    <div class="dropdown-user-info">
                        <div class="dropdown-username"><?= htmlspecialchars($current_username) ?></div>
                    </div>
                </div>

                <div class="dropdown-divider"></div>

                <a href="settings.php" class="dropdown-item">
                    <span class="dropdown-icon"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;vertical-align:middle;width:18px;height:18px;fill:none;stroke:currentColor;"><path d="M10.36 4.89L10.66 2.49L13.34 2.49L13.64 4.89A7.3 7.3 0 0 1 15.87 5.81L17.78 4.33L19.67 6.22L18.19 8.13A7.3 7.3 0 0 1 19.11 10.36L21.51 10.66L21.51 13.34L19.11 13.64A7.3 7.3 0 0 1 18.19 15.87L19.67 17.78L17.78 19.67L15.87 18.19A7.3 7.3 0 0 1 13.64 19.11L13.34 21.51L10.66 21.51L10.36 19.11A7.3 7.3 0 0 1 8.13 18.19L6.22 19.67L4.33 17.78L5.81 15.87A7.3 7.3 0 0 1 4.89 13.64L2.49 13.34L2.49 10.66L4.89 10.36A7.3 7.3 0 0 1 5.81 8.13L4.33 6.22L6.22 4.33L8.13 5.81A7.3 7.3 0 0 1 10.36 4.89Z"/><circle cx="12" cy="12" r="3"/></svg></span> Настройки
                </a>
                <div class="theme-trigger" id="themeTrigger">
                    <span class="dropdown-icon"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;vertical-align:middle;width:18px;height:18px;fill:none;stroke:currentColor;"><circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/></svg></span>
                    <span>Тема</span>
                    <span class="theme-current">
                        <?php
                        $theme_name = 'Тёмная';
                        if ($theme === 'light') $theme_name = 'Светлая';
                        elseif ($theme === 'system') $theme_name = 'Системная';
                        echo htmlspecialchars($theme_name);
                        ?>
                    </span>
                    <span class="theme-arrow" id="themeArrow"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;vertical-align:middle;width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2.4;"><path d="m6 9 6 6 6-6"/></svg></span>
                </div>

                <div class="theme-submenu" id="themeSubmenu">
                    <a href="?theme=dark" class="theme-item <?= $theme === 'dark' ? 'active' : '' ?>">
                        <span class="theme-option">
                            <span class="theme-dot dark"></span>
                            Тёмная
                        </span>
                        <?php if ($theme === 'dark'): ?>
                            <span class="theme-check">✓</span>
                        <?php endif; ?>
                    </a>

                    <a href="?theme=light" class="theme-item <?= $theme === 'light' ? 'active' : '' ?>">
                        <span class="theme-option">
                            <span class="theme-dot light"></span>
                            Светлая
                        </span>
                        <?php if ($theme === 'light'): ?>
                            <span class="theme-check">✓</span>
                        <?php endif; ?>
                    </a>

                    <a href="?theme=system" class="theme-item <?= $theme === 'system' ? 'active' : '' ?>">
                        <span class="theme-option">
                            <span class="theme-dot system"></span>
                            Системная
                        </span>
                        <?php if ($theme === 'system'): ?>
                            <span class="theme-check">✓</span>
                        <?php endif; ?>
                    </a>
                </div>

                <div class="dropdown-divider"></div>

                <a href="logout.php" class="dropdown-item logout-item">
                    <span class="dropdown-icon"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:inline-block;vertical-align:middle;width:18px;height:18px;fill:none;stroke:currentColor;"><path d="M9 21H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg></span> Выйти
                </a>
            </div>
        </div>
    </div>
</header>


<div class="layout">


    <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

    <!-- CONTENT -->
    <main class="content">

        <div class="content-header">
            <div class="content-title">Помощь</div>
            <div class="content-subtitle">
                Здесь вы найдёте ответы на основные вопросы.
            </div>
        </div>

        <div class="help-grid">

            <a href="messages.php" class="help-card help-card--blue">
                <div class="help-icon"><img src="images/nav-messages.svg" alt="" width="26" height="26" style="display:block;width:26px;height:26px;filter:brightness(0) invert(1)"></div>
                <div class="help-title">Сообщения</div>
                <div class="help-text">
                    Используйте раздел «Сообщения», чтобы общаться
                    с другими пользователями.
                </div>
            </a>

            <a href="friends.php" class="help-card help-card--teal">
                <div class="help-icon"><img src="images/nav-friends.svg" alt="" width="26" height="26" style="display:block;width:26px;height:26px;filter:brightness(0) invert(1)"></div>
                <div class="help-title">Друзья</div>
                <div class="help-text">
                    Находите пользователей, отправляйте заявки
                    в друзья и общайтесь с ними.
                </div>
            </a>

            <a href="index.php" class="help-card help-card--accent">
                <div class="help-icon"><img src="images/profile.svg" alt="" width="26" height="26" style="display:block;width:26px;height:26px;filter:brightness(0) invert(1)"></div>
                <div class="help-title">Профиль</div>
                <div class="help-text">
                    В профиле можно изменить информацию о себе
                    и загрузить фотографию.
                </div>
            </a>

            <a href="settings.php" class="help-card help-card--gold">
                <div class="help-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:block;flex-shrink:0;width:26px;height:26px;fill:none;stroke:#ffffff;opacity:1;visibility:visible"><rect x="5" y="11" width="14" height="9.5" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><path d="M12 15v2"/></svg></div>
                <div class="help-title">Безопасность</div>
                <div class="help-text">
                    Не передавайте пароль другим пользователям
                    и используйте надёжный пароль для аккаунта.
                </div>
            </a>

            <a href="messages.php" class="help-card help-card--coral">
                <div class="help-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:block;flex-shrink:0;width:26px;height:26px;fill:none;stroke:#ffffff;opacity:1;visibility:visible"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0"/><path d="M12 18v3M9 21h6"/></svg></div>
                <div class="help-title">Голосовые сообщения</div>
                <div class="help-text">
                    Разрешите браузеру доступ к микрофону,
                    чтобы записывать и отправлять голосовые сообщения.
                </div>
            </a>

            <a href="avatars.php" class="help-card help-card--violet">
                <div class="help-icon"><img src="images/nav-photo.svg" alt="" width="26" height="26" style="display:block;width:26px;height:26px;filter:brightness(0) invert(1)"></div>
                <div class="help-title">Фотографии</div>
                <div class="help-text">
                    Вы можете загрузить фотографию профиля
                    в поддерживаемом формате изображения.
                </div>
            </a>

        </div>

        <div class="support-card">
            <div class="support-icon-wrap">
                <span class="support-icon"><img src="images/nav-support.svg" alt="" width="28" height="28" style="display:block;width:28px;height:28px;filter:brightness(0) invert(1)"></span>
            </div>
            <div class="support-body">
                <div class="support-title">Не нашли ответ?</div>
            <div class="support-text">
                Если у вас возникла проблема или вопрос,
                обратитесь в службу поддержки.
            </div>
            </div>
            <div class="support-actions">

            <a href="support.php" class="button">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:block;flex-shrink:0;width:18px;height:18px;fill:none;stroke:currentColor;opacity:1;visibility:visible"><path d="M5 12.5V12a7 7 0 0 1 14 0v.5"/><rect x="3" y="12.5" width="4.5" height="6" rx="2"/><rect x="16.5" y="12.5" width="4.5" height="6" rx="2"/><path d="M18.75 18.5v.3a2.7 2.7 0 0 1-2.7 2.7H13"/></svg>
                Служба поддержки
            </a>

            <a href="https://discord.com/" target="_blank" rel="noopener noreferrer" class="button secondary">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="display:block;flex-shrink:0;width:18px;height:18px;fill:none;stroke:currentColor;opacity:1;visibility:visible"><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v3.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 4 17.5v-9A2.5 2.5 0 0 1 6.5 6H10"/></svg>
                Discord
            </a>
            </div>
        </div>

        <div class="footer">
            © <?= date('Y') ?>
        </div>

    </main>

</div>

    <script src="assets/js/help.js"></script>
    <script src="assets/js/error-reporter.js"></script>
</body>
    </html>
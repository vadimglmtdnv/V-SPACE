<?php
/**
 * Защита PIN-кода от подбора: после серии неверных вводов — таймаут,
 * и каждый следующий таймаут длиннее предыдущего (30 мин → 1 ч → 2 ч → 6 ч → 24 ч).
 *
 * Счётчик хранится в БД (таблица pin_attempts создаётся автоматически),
 * поэтому обойти его сменой браузера или очисткой cookie нельзя.
 *
 * Использование — см. комментарий в конце файла.
 */

// Сколько неверных вводов подряд допускается до блокировки (один «раунд»).
// Поставьте 1, если блокировать нужно сразу после первой ошибки.
const PIN_ATTEMPTS_PER_ROUND = 4;

// Длительность блокировок по порядку, в секундах. Дальше всегда используется последняя (24 ч).
const PIN_LOCK_STEPS = [1800, 3600, 7200, 21600, 86400];

// Если ошибок не было столько секунд (48 ч), «лесенка» таймаутов начинается заново.
const PIN_LEVEL_RESET_AFTER = 172800;

function pinGuardEnsureTable(\mysqli $conn): void {
    $conn->query(
        "CREATE TABLE IF NOT EXISTS pin_attempts (
            guard_key    VARCHAR(120)  NOT NULL PRIMARY KEY,
            fails        INT UNSIGNED  NOT NULL DEFAULT 0,
            lvl          INT UNSIGNED  NOT NULL DEFAULT 0,
            locked_until INT UNSIGNED  NOT NULL DEFAULT 0,
            last_fail    INT UNSIGNED  NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
}

/**
 * Ключ, по которому ведётся счётчик: залогиненный пользователь — по user_id,
 * иначе по IP. Используется REMOTE_ADDR, а не X-Forwarded-For (его можно подделать).
 */
function pinGuardKey(string $scope = 'reports'): string {
    $who = isset($_SESSION['user_id'])
        ? 'u' . (int)$_SESSION['user_id']
        : 'ip' . (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    return substr($scope . ':' . $who, 0, 120);
}

/**
 * Текущее состояние: ['locked' => bool, 'wait' => секунд до конца блокировки, 'attempts_left' => int]
 */
function pinGuardStatus(\mysqli $conn, string $key): array {
    $now  = time();
    $stmt = $conn->prepare("SELECT fails, locked_until FROM pin_attempts WHERE guard_key = ? LIMIT 1");
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row && (int)$row['locked_until'] > $now) {
        return ['locked' => true, 'wait' => (int)$row['locked_until'] - $now, 'attempts_left' => 0];
    }
    $fails = $row ? (int)$row['fails'] : 0;
    return ['locked' => false, 'wait' => 0, 'attempts_left' => max(0, PIN_ATTEMPTS_PER_ROUND - $fails)];
}

/**
 * Записать неверный ввод. Возвращает состояние в том же формате, что и pinGuardStatus().
 * Если блокировка уже действует — счётчик не меняется.
 */
function pinGuardFail(\mysqli $conn, string $key): array {
    $now = time();
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT IGNORE INTO pin_attempts (guard_key) VALUES (?)");
        $stmt->bind_param('s', $key);
        $stmt->execute();
        $stmt->close();

        // FOR UPDATE: два одновременных запроса не смогут «проскочить» мимо счётчика
        $stmt = $conn->prepare("SELECT fails, lvl, locked_until, last_fail FROM pin_attempts WHERE guard_key = ? FOR UPDATE");
        $stmt->bind_param('s', $key);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $fails = (int)$row['fails'];
        $lvl   = (int)$row['lvl'];
        $until = (int)$row['locked_until'];
        $last  = (int)$row['last_fail'];

        if ($until > $now) {                       // уже заблокирован — ничего не меняем
            $conn->commit();
            return ['locked' => true, 'wait' => $until - $now, 'attempts_left' => 0];
        }

        if ($last > 0 && ($now - $last) > PIN_LEVEL_RESET_AFTER) {   // давно не ошибался
            $lvl   = 0;
            $fails = 0;
        }

        $fails++;
        if ($fails >= PIN_ATTEMPTS_PER_ROUND) {
            $step  = PIN_LOCK_STEPS[min($lvl, count(PIN_LOCK_STEPS) - 1)];
            $until = $now + $step;
            $lvl++;
            $fails = 0;                            // новый раунд начнётся после окончания блокировки
        }

        $stmt = $conn->prepare("UPDATE pin_attempts SET fails = ?, lvl = ?, locked_until = ?, last_fail = ? WHERE guard_key = ?");
        $stmt->bind_param('iiiis', $fails, $lvl, $until, $now, $key);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
    } catch (\Throwable $e) {
        $conn->rollback();
        throw $e;
    }

    if ($until > $now) {
        return ['locked' => true, 'wait' => $until - $now, 'attempts_left' => 0];
    }
    return ['locked' => false, 'wait' => 0, 'attempts_left' => PIN_ATTEMPTS_PER_ROUND - $fails];
}

/** Верный PIN — сбросить счётчик и «лесенку» таймаутов. */
function pinGuardSuccess(\mysqli $conn, string $key): void {
    $stmt = $conn->prepare("DELETE FROM pin_attempts WHERE guard_key = ?");
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $stmt->close();
}

/** 1800 → «30 мин», 3725 → «1 ч 2 мин», 45 → «45 сек». */
function pinGuardFormatWait(int $sec): string {
    $h = intdiv($sec, 3600);
    $m = intdiv($sec % 3600, 60);
    $s = $sec % 60;
    $parts = [];
    if ($h > 0) $parts[] = $h . ' ч';
    if ($m > 0) $parts[] = $m . ' мин';
    if ($h === 0 && $m === 0 && $s > 0) $parts[] = $s . ' сек';
    return $parts ? implode(' ', $parts) : '1 сек';
}

/*
 * ===== Как подключить в reports.php =====
 *
 * require_once __DIR__ . '/includes/pin_guard.php';
 *
 * pinGuardEnsureTable($conn);                 // создаст таблицу при первом запуске
 * $guardKey = pinGuardKey('reports');
 * $guard    = pinGuardStatus($conn, $guardKey);
 * $pinError = '';
 *
 * if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pin'])) {
 *     if ($guard['locked']) {
 *         // Пока идёт блокировка, PIN вообще не проверяем — даже верный.
 *         $pinError = 'Слишком много попыток. Повторите через ' . pinGuardFormatWait($guard['wait']) . '.';
 *     } elseif (hash_equals($correctPin, (string)$_POST['pin'])) {   // или password_verify(), если PIN хранится хэшем
 *         pinGuardSuccess($conn, $guardKey);
 *         $_SESSION['reports_pin_ok'] = true;                         // ваш способ «пустить внутрь»
 *     } else {
 *         $guard = pinGuardFail($conn, $guardKey);
 *         $pinError = $guard['locked']
 *             ? 'Неверный PIN. Доступ закрыт на ' . pinGuardFormatWait($guard['wait']) . '.'
 *             : 'Неверный PIN. Осталось попыток: ' . $guard['attempts_left'] . '.';
 *     }
 * }
 *
 * В форме при $guard['locked'] стоит добавить disabled на поле и кнопку.
 */

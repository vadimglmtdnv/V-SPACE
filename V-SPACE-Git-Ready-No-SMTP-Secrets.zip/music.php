<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
// Если в настройках выбран English — содержимое страницы переводится «на лету» (includes/lang.php)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| ПОДКЛЮЧЕНИЕ К MYSQL
|--------------------------------------------------------------------------
*/

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

$user_id = (int)$_SESSION["user_id"];

// Страница артиста вынесена в artist.php: старые ссылки music.php?artist=ID ведут туда
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["artist"]) && ctype_digit((string)$_GET["artist"])) {
    header("Location: artist.php?id=" . (int)$_GET["artist"], true, 301);
    exit;
}

/*
|--------------------------------------------------------------------------
| СОЗДАНИЕ ТАБЛИЦЫ MUSIC ЕСЛИ ЕЁ НЕТ
|--------------------------------------------------------------------------
*/

$conn->query("
    CREATE TABLE IF NOT EXISTS music (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        title VARCHAR(255) NOT NULL,
        filename VARCHAR(255) NOT NULL,
        filepath VARCHAR(255) NOT NULL,
        filesize INT(11) DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX user_id (user_id),
        INDEX title (title)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Проверяем и добавляем колонки если их нет
$columns = [
    'filename' => 'VARCHAR(255) NOT NULL AFTER title',
    'filepath' => 'VARCHAR(255) NOT NULL AFTER filename',
    'filesize' => 'INT(11) DEFAULT 0 AFTER filepath'
];

foreach ($columns as $col_name => $col_def) {
    $check = $conn->query("SHOW COLUMNS FROM music LIKE '$col_name'");
    if ($check && $check->num_rows == 0) {
        $conn->query("ALTER TABLE music ADD COLUMN $col_name $col_def");
    }
}

// Роль «музыкант / продюсер»: загружать музыку могут только они и администраторы.
// Колонка создаётся автоматически; выдаёт и забирает роль продюсер (блок справа).
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'is_musician'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN is_musician TINYINT(1) NOT NULL DEFAULT 0");
}

// Роль «продюсер»: только продюсер управляет музыкантами (выдаёт и забирает им доступ к загрузке).
// Колонка создаётся автоматически, роль выдаётся вручную в SQL:
//   UPDATE users SET is_producer = 1 WHERE id = 123;
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'is_producer'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN is_producer TINYINT(1) NOT NULL DEFAULT 0");
}

// Альбомы: отдельная таблица + колонка album_id в music (NULL = трек вне альбома)
$conn->query("
    CREATE TABLE IF NOT EXISTS music_albums (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description VARCHAR(1000) NOT NULL DEFAULT '',
        cover VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$check = $conn->query("SHOW COLUMNS FROM music LIKE 'album_id'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE music ADD COLUMN album_id INT(11) NULL DEFAULT NULL");
    $conn->query("ALTER TABLE music ADD INDEX album_id (album_id)");
}

// Счётчик прослушиваний: по нему строится блок «Популярное» на странице артиста
$check = $conn->query("SHOW COLUMNS FROM music LIKE 'plays'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE music ADD COLUMN plays INT(11) NOT NULL DEFAULT 0");
}

// Шапка (баннер) страницы артиста: путь к картинке в uploads/music/banners/
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'music_banner'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN music_banner VARCHAR(255) NULL DEFAULT NULL");
}

// Имя артиста на его странице (необязательно): пусто = показывается обычный ник
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'music_name'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN music_name VARCHAR(40) NULL DEFAULT NULL");
}

// Обложка трека (необязательная): её ставит тот, кто загружает трек
$check = $conn->query("SHOW COLUMNS FROM music LIKE 'cover'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE music ADD COLUMN cover VARCHAR(255) NULL DEFAULT NULL");
}

// «Моя музыка»: личная подборка — чужие треки, которые пользователь добавил себе
$conn->query("
    CREATE TABLE IF NOT EXISTS music_library (
        user_id INT(11) NOT NULL,
        track_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, track_id),
        INDEX track_id (track_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Подписки на артистов
$conn->query("
    CREATE TABLE IF NOT EXISTS music_follows (
        follower_id INT(11) NOT NULL,
        artist_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (follower_id, artist_id),
        INDEX artist_id (artist_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

/*
|--------------------------------------------------------------------------
| CSRF-ТОКЕН (общий с остальными страницами сайта)
|--------------------------------------------------------------------------
*/

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION["csrf_token"];

function musicCsrfOk(): bool
{
    $token = $_POST["csrf_token"] ?? ($_GET["csrf"] ?? "");
    return is_string($token) && $token !== ""
        && hash_equals($_SESSION["csrf_token"] ?? "", $token);
}

/*
|--------------------------------------------------------------------------
| ДАННЫЕ ПОЛЬЗОВАТЕЛЯ
|--------------------------------------------------------------------------
*/

$username = "Пользователь";
$avatarLetter = "P";
$is_admin = false;
$is_musician = false;
$is_producer = false;

$stmt = $conn->prepare("
    SELECT username, avatar, is_admin, is_musician, is_producer
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    if (!empty($user["username"])) {
        $username = $user["username"];
    }
    $avatarLetter = mb_strtoupper(
        mb_substr($username, 0, 1, "UTF-8"),
        "UTF-8"
    );
    $is_admin = !empty($user["is_admin"]);
    $is_musician = !empty($user["is_musician"]);
    $is_producer = !empty($user["is_producer"]);
}

$stmt->close();

// Как и в ленте, пользователь с id 1 считается администратором
if ($user_id === 1) {
    $is_admin = true;
}

// Добавлять треки и альбомы может любой вошедший пользователь (роль музыканта больше не нужна)
$can_upload = true;

// Какие треки пользователь уже добавил себе (для кнопки «+» в строке трека)
$libraryIds = [];
$stmt = $conn->prepare("SELECT track_id FROM music_library WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$libRes = $stmt->get_result();
while ($libRes && ($libRow = $libRes->fetch_row())) {
    $libraryIds[(int)$libRow[0]] = true;
}
$stmt->close();

/*
|--------------------------------------------------------------------------
| ПАПКА МУЗЫКИ
|--------------------------------------------------------------------------
*/

$musicDir = __DIR__ . "/uploads/music/";
$musicUrl = "uploads/music/";

if (!is_dir($musicDir)) {
    mkdir($musicDir, 0755, true);
}

/*
|--------------------------------------------------------------------------
| ЗАГРУЗКА MP3
|--------------------------------------------------------------------------
*/

$error = "";
$success = "";

// Сообщение, оставленное предыдущим POST-запросом (см. редирект ниже), показываем один раз
if (!empty($_SESSION["music_flash"]) && is_array($_SESSION["music_flash"])) {
    $flash = $_SESSION["music_flash"];
    unset($_SESSION["music_flash"]);
    if (($flash["type"] ?? "") === "success") {
        $success = (string)($flash["text"] ?? "");
    } else {
        $error = (string)($flash["text"] ?? "");
    }
}

// Куда вернуться после POST (по умолчанию — список музыки)
$redirectTo = "music.php";

function musicRedirect(string $type, string $text, string $to): void
{
    $_SESSION["music_flash"] = ["type" => $type, "text" => $text];
    header("Location: " . $to);
    exit;
}

$action = $_POST["action"] ?? "upload";

/*
|--------------------------------------------------------------------------
| СТРАНИЦА АРТИСТА: подписка, шапка, счётчик прослушиваний
|--------------------------------------------------------------------------
*/

// Подписаться / отписаться
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($action === "artist_follow" || $action === "artist_unfollow")) {
    $followId = (int)($_POST["artist_id"] ?? 0);
    $back = "artist.php?id=" . $followId;

    if (!musicCsrfOk()) {
        musicRedirect("error", "Сессия устарела. Обновите страницу и попробуйте снова.", $back);
    }
    if ($followId <= 0 || $followId === $user_id) {
        musicRedirect("error", "На эту страницу подписаться нельзя.", "music.php");
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $followId);
    $stmt->execute();
    $exists = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$exists) {
        musicRedirect("error", "Артист не найден.", "music.php");
    }

    if ($action === "artist_follow") {
        $stmt = $conn->prepare("INSERT IGNORE INTO music_follows (follower_id, artist_id) VALUES (?, ?)");
    } else {
        $stmt = $conn->prepare("DELETE FROM music_follows WHERE follower_id = ? AND artist_id = ?");
    }
    $stmt->bind_param("ii", $user_id, $followId);
    $stmt->execute();
    $stmt->close();

    header("Location: " . $back);
    exit;
}

// Сменить / убрать шапку: только владелец страницы и администратор
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($action === "artist_banner" || $action === "artist_banner_remove")) {
    $bannerOwner = (int)($_POST["artist_id"] ?? 0);
    $back = "artist.php?id=" . $bannerOwner;
    $bannerDir = $musicDir . "banners/";

    if (!musicCsrfOk()) {
        musicRedirect("error", "Сессия устарела. Обновите страницу и попробуйте снова.", $back);
    }
    if ($bannerOwner <= 0 || $bannerOwner !== $user_id) {
        musicRedirect("error", "Менять шапку может только владелец страницы.", $back);
    }

    $stmt = $conn->prepare("SELECT music_banner FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $bannerOwner);
    $stmt->execute();
    $oldRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$oldRow) {
        musicRedirect("error", "Артист не найден.", "music.php");
    }
    $oldBanner = (string)($oldRow["music_banner"] ?? "");

    // Удаляем только файлы из своей папки баннеров, чужие пути из БД не трогаем
    $deleteOldBanner = function () use ($oldBanner, $bannerDir) {
        if ($oldBanner !== "" && strpos($oldBanner, "uploads/music/banners/") === 0) {
            $f = $bannerDir . basename($oldBanner);
            if (is_file($f)) {
                @unlink($f);
            }
        }
    };

    if ($action === "artist_banner_remove") {
        $stmt = $conn->prepare("UPDATE users SET music_banner = NULL WHERE id = ?");
        $stmt->bind_param("i", $bannerOwner);
        $stmt->execute();
        $stmt->close();
        $deleteOldBanner();
        musicRedirect("success", "Шапка убрана.", $back);
    }

    if (!isset($_FILES["banner"]) || $_FILES["banner"]["error"] === UPLOAD_ERR_NO_FILE) {
        musicRedirect("error", "Выберите картинку для шапки.", $back);
    }
    $bf = $_FILES["banner"];
    $bannerTypes = [IMAGETYPE_JPEG => "jpg", IMAGETYPE_PNG => "png", IMAGETYPE_WEBP => "webp"];

    if ($bf["error"] !== UPLOAD_ERR_OK) {
        musicRedirect("error", "Не удалось загрузить шапку.", $back);
    }
    if ($bf["size"] > 8 * 1024 * 1024) {
        musicRedirect("error", "Шапка не должна быть больше 8 МБ.", $back);
    }
    $bi = @getimagesize($bf["tmp_name"]);
    if (!$bi || !isset($bannerTypes[$bi[2]])) {
        musicRedirect("error", "Шапка должна быть JPG, PNG или WEBP.", $back);
    }
    if (!is_dir($bannerDir)) {
        mkdir($bannerDir, 0755, true);
    }
    $bannerName = "banner_" . $bannerOwner . "_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $bannerTypes[$bi[2]];
    if (!move_uploaded_file($bf["tmp_name"], $bannerDir . $bannerName)) {
        musicRedirect("error", "Не удалось сохранить шапку.", $back);
    }
    $bannerPath = $musicUrl . "banners/" . $bannerName;
    $stmt = $conn->prepare("UPDATE users SET music_banner = ? WHERE id = ?");
    $stmt->bind_param("si", $bannerPath, $bannerOwner);
    if ($stmt->execute()) {
        $stmt->close();
        $deleteOldBanner();
        musicRedirect("success", "Шапка обновлена.", $back);
    }
    $stmt->close();
    @unlink($bannerDir . $bannerName);
    musicRedirect("error", "Не удалось сохранить шапку.", $back);
}

// «Моя музыка»: добавить чужой трек себе / убрать (запрос из JS, ответ JSON)
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($action === "library_add" || $action === "library_remove")) {
    header("Content-Type: application/json; charset=utf-8");
    $libId = (int)($_POST["track_id"] ?? 0);

    if (!musicCsrfOk() || $libId <= 0) {
        http_response_code(400);
        echo '{"ok":false}';
        exit;
    }

    $stmt = $conn->prepare("SELECT user_id FROM music WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $libId);
    $stmt->execute();
    $libTrack = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Трека нет, либо это свой трек (свои и так в «Моей музыке»)
    if (!$libTrack || ($action === "library_add" && (int)$libTrack["user_id"] === $user_id)) {
        http_response_code(400);
        echo '{"ok":false}';
        exit;
    }

    if ($action === "library_add") {
        $stmt = $conn->prepare("INSERT IGNORE INTO music_library (user_id, track_id) VALUES (?, ?)");
    } else {
        $stmt = $conn->prepare("DELETE FROM music_library WHERE user_id = ? AND track_id = ?");
    }
    $stmt->bind_param("ii", $user_id, $libId);
    $stmt->execute();
    $stmt->close();

    echo $action === "library_add" ? '{"ok":true,"in":true}' : '{"ok":true,"in":false}';
    exit;
}

// Счётчик прослушиваний (страница шлёт один запрос на трек за визит)
if ($_SERVER["REQUEST_METHOD"] === "POST" && $action === "track_play") {
    header("Content-Type: application/json; charset=utf-8");
    $playId = (int)($_POST["track_id"] ?? 0);
    if (musicCsrfOk() && $playId > 0) {
        $stmt = $conn->prepare("UPDATE music SET plays = plays + 1 WHERE id = ?");
        $stmt->bind_param("i", $playId);
        $stmt->execute();
        $stmt->close();
        echo '{"ok":true}';
    } else {
        http_response_code(400);
        echo '{"ok":false}';
    }
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && $action === "upload") {
    if (!$can_upload) {
        // Проверка на сервере: скрытой формы мало, POST можно отправить и вручную
        $error = "Загружать музыку могут только музыканты, продюсеры и администраторы.";
    } elseif (!musicCsrfOk()) {
        $error = "Сессия устарела. Обновите страницу и попробуйте снова.";
    } elseif (!isset($_FILES["music"])) {
        $error = "Выберите MP3-файл.";
    } else {
        $file = $_FILES["music"];

        if ($file["error"] !== UPLOAD_ERR_OK) {
            $error = "Ошибка загрузки файла.";
        } elseif ($file["size"] > 20 * 1024 * 1024) {
            $error = "Максимальный размер файла — 20 МБ.";
        } else {
            $extension = strtolower(
                pathinfo($file["name"], PATHINFO_EXTENSION)
            );

            if ($extension !== "mp3") {
                $error = "Разрешены только MP3-файлы.";
            } else {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $file["tmp_name"]);
                finfo_close($finfo);

                $allowedMime = [
                    "audio/mpeg",
                    "audio/mp3",
                    "application/octet-stream"
                ];

                if (!in_array($mime, $allowedMime, true)) {
                    $error = "Файл не является MP3.";
                } else {
                    $title = pathinfo($file["name"], PATHINFO_FILENAME);
                    $title = trim($title);
                    if ($title === "") {
                        $title = "Без названия";
                    }

                    $title = mb_substr($title, 0, 255, "UTF-8");

                    // Обложка трека (необязательная): проверяем до сохранения MP3, чтобы не оставлять «сирот»
                    $trackCoverPath = null;
                    $trackCoverFile = "";
                    if (isset($_FILES["track_cover"]) && $_FILES["track_cover"]["error"] !== UPLOAD_ERR_NO_FILE) {
                        $tc = $_FILES["track_cover"];
                        $tcTypes = [IMAGETYPE_JPEG => "jpg", IMAGETYPE_PNG => "png", IMAGETYPE_WEBP => "webp"];
                        $tcInfo = $tc["error"] === UPLOAD_ERR_OK ? @getimagesize($tc["tmp_name"]) : false;

                        if ($tc["error"] !== UPLOAD_ERR_OK) {
                            $error = "Не удалось загрузить обложку.";
                        } elseif ($tc["size"] > 8 * 1024 * 1024) {
                            $error = "Обложка не должна быть больше 8 МБ.";
                        } elseif (!$tcInfo || !isset($tcTypes[$tcInfo[2]])) {
                            $error = "Обложка должна быть JPG, PNG или WEBP.";
                        } else {
                            $tcDir = $musicDir . "covers/";
                            if (!is_dir($tcDir)) {
                                mkdir($tcDir, 0755, true);
                            }
                            $tcName = "tcover_" . $user_id . "_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $tcTypes[$tcInfo[2]];
                            if (move_uploaded_file($tc["tmp_name"], $tcDir . $tcName)) {
                                $trackCoverFile = $tcDir . $tcName;
                                $trackCoverPath = $musicUrl . "covers/" . $tcName;
                            } else {
                                $error = "Не удалось сохранить обложку.";
                            }
                        }
                    }

                    $newFileName = "music_" . $user_id . "_" . time() . "_" . bin2hex(random_bytes(4)) . ".mp3";
                    $filePath = $musicDir . $newFileName;
                    $databasePath = $musicUrl . $newFileName;

                    if ($error !== "") {
                        // обложка не прошла проверку — MP3 не сохраняем
                    } elseif (!move_uploaded_file($file["tmp_name"], $filePath)) {
                        $error = "Не удалось сохранить MP3.";
                        if ($trackCoverFile !== "" && file_exists($trackCoverFile)) {
                            unlink($trackCoverFile);
                        }
                    } else {
                        $stmt = $conn->prepare("
                            INSERT INTO music (user_id, title, filename, filepath, filesize, cover)
                            VALUES (?, ?, ?, ?, ?, ?)
                        ");

                        $fileSize = (int)$file["size"];
                        $stmt->bind_param("isssis", $user_id, $title, $newFileName, $databasePath, $fileSize, $trackCoverPath);

                        if ($stmt->execute()) {
                            $success = "Музыка успешно загружена.";
                        } else {
                            if (file_exists($filePath)) {
                                unlink($filePath);
                            }
                            if ($trackCoverFile !== "" && file_exists($trackCoverFile)) {
                                unlink($trackCoverFile);
                            }
                            $error = "Не удалось сохранить данные в MySQL.";
                        }
                        $stmt->close();
                    }
                }
            }
        }
    }
}

// Загрузка со страницы артиста: возвращаем обратно на неё с сообщением
if ($_SERVER["REQUEST_METHOD"] === "POST" && $action === "upload" && ($_POST["return_to"] ?? "") === "artist") {
    musicRedirect($error !== "" ? "error" : "success", $error !== "" ? $error : $success, "artist.php?id=" . $user_id);
}

/*
|--------------------------------------------------------------------------
| РОЛЬ «МУЗЫКАНТ / ПРОДЮСЕР» (только администратор)
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST" && ($action === "musician_grant" || $action === "musician_revoke")) {
    if (!$is_producer) {
        $error = "Недостаточно прав.";
    } elseif (!musicCsrfOk()) {
        $error = "Сессия устарела. Обновите страницу и попробуйте снова.";
    } else {
        $target = trim((string)($_POST["target"] ?? ""));
        $target_row = null;

        if ($target !== "") {
            if (ctype_digit($target)) {
                $stmt = $conn->prepare("SELECT id, username FROM users WHERE id = ? LIMIT 1");
                $target_id = (int)$target;
                $stmt->bind_param("i", $target_id);
            } else {
                $stmt = $conn->prepare("SELECT id, username FROM users WHERE username = ? LIMIT 1");
                $stmt->bind_param("s", $target);
            }
            $stmt->execute();
            $target_row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }

        if (!$target_row) {
            $error = "Пользователь не найден. Введите его ID или точный ник.";
        } else {
            $flag = $action === "musician_grant" ? 1 : 0;
            $target_id = (int)$target_row["id"];
            $stmt = $conn->prepare("UPDATE users SET is_musician = ? WHERE id = ?");
            $stmt->bind_param("ii", $flag, $target_id);
            if ($stmt->execute()) {
                $success = $flag
                    ? "Пользователь " . $target_row["username"] . " теперь может загружать музыку."
                    : "У пользователя " . $target_row["username"] . " отозвана возможность загружать музыку.";
            } else {
                $error = "Не удалось изменить роль.";
            }
            $stmt->close();
        }
    }
}

/*
|--------------------------------------------------------------------------
| АЛЬБОМЫ: СОЗДАНИЕ И УДАЛЕНИЕ
|--------------------------------------------------------------------------
*/

$coverDir = $musicDir . "covers/";

if ($_SERVER["REQUEST_METHOD"] === "POST" && $action === "album_create") {
    if (!$can_upload) {
        $error = "Создавать альбомы могут только музыканты, продюсеры и администраторы.";
    } elseif (!musicCsrfOk()) {
        $error = "Сессия устарела. Обновите страницу и попробуйте снова.";
    } else {
        $albumTitle = trim((string)($_POST["album_title"] ?? ""));
        $albumTitle = mb_substr($albumTitle, 0, 255, "UTF-8");
        $albumDesc  = mb_substr(trim((string)($_POST["album_desc"] ?? "")), 0, 1000, "UTF-8");
        $coverPath  = null;
        $coverFile  = "";

        if ($albumTitle === "") {
            $error = "Введите название альбома.";
        } elseif (isset($_FILES["cover"]) && $_FILES["cover"]["error"] !== UPLOAD_ERR_NO_FILE) {
            // Обложка необязательна, но если выбрана — проверяем по содержимому, а не по имени
            $cf = $_FILES["cover"];
            $imageTypes = [IMAGETYPE_JPEG => "jpg", IMAGETYPE_PNG => "png", IMAGETYPE_WEBP => "webp"];

            if ($cf["error"] !== UPLOAD_ERR_OK) {
                $error = "Не удалось загрузить обложку.";
            } elseif ($cf["size"] > 5 * 1024 * 1024) {
                $error = "Обложка не должна быть больше 5 МБ.";
            } else {
                $info = @getimagesize($cf["tmp_name"]);
                if (!$info || !isset($imageTypes[$info[2]])) {
                    $error = "Обложка должна быть JPG, PNG или WEBP.";
                } else {
                    if (!is_dir($coverDir)) {
                        mkdir($coverDir, 0755, true);
                    }
                    $coverName = "cover_" . $user_id . "_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $imageTypes[$info[2]];
                    $coverFile = $coverDir . $coverName;
                    if (move_uploaded_file($cf["tmp_name"], $coverFile)) {
                        $coverPath = $musicUrl . "covers/" . $coverName;
                    } else {
                        $error = "Не удалось сохранить обложку.";
                    }
                }
            }
        }

        if ($error === "" && $albumTitle !== "") {
            $stmt = $conn->prepare("INSERT INTO music_albums (user_id, title, description, cover) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $user_id, $albumTitle, $albumDesc, $coverPath);
            if ($stmt->execute()) {
                $redirectTo = "music.php?album=" . (int)$conn->insert_id;
                $success = "Альбом создан. Теперь можно загружать в него треки.";
            } else {
                if ($coverFile !== "" && file_exists($coverFile)) {
                    unlink($coverFile);
                }
                $error = "Не удалось создать альбом.";
            }
            $stmt->close();
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && $action === "album_delete") {
    if (!musicCsrfOk()) {
        $error = "Сессия устарела. Обновите страницу и попробуйте снова.";
    } else {
        $delAlbumId = (int)($_POST["album_id"] ?? 0);
        $stmt = $conn->prepare("SELECT user_id, cover FROM music_albums WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $delAlbumId);
        $stmt->execute();
        $delAlbum = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$delAlbum || (!$is_admin && (int)$delAlbum["user_id"] !== $user_id)) {
            $error = "Альбом не найден или нет прав на удаление.";
        } else {
            // Треки остаются на сайте, просто выходят из альбома
            $stmt = $conn->prepare("UPDATE music SET album_id = NULL WHERE album_id = ?");
            $stmt->bind_param("i", $delAlbumId);
            $stmt->execute();
            $stmt->close();

            if (!empty($delAlbum["cover"])) {
                $coverPhysical = __DIR__ . "/" . $delAlbum["cover"];
                if (is_file($coverPhysical)) {
                    unlink($coverPhysical);
                }
            }

            $stmt = $conn->prepare("DELETE FROM music_albums WHERE id = ?");
            $stmt->bind_param("i", $delAlbumId);
            $stmt->execute();
            $stmt->close();

            $success = "Альбом удалён. Треки остались в общем списке.";
        }
    }
}

/*
|--------------------------------------------------------------------------
| АЛЬБОМЫ: ДОБАВИТЬ ТРЕКИ ИЗ СВОИХ И УБРАТЬ ИЗ АЛЬБОМА
|--------------------------------------------------------------------------
| В альбом попадают только уже загруженные треки (прямой загрузки в альбом нет).
*/

if ($_SERVER["REQUEST_METHOD"] === "POST" && ($action === "album_add_tracks" || $action === "album_remove_track")) {
    $manageAlbumId = (int)($_POST["album_id"] ?? 0);
    $manageAlbum = null;

    if ($manageAlbumId > 0) {
        $stmt = $conn->prepare("SELECT id, user_id FROM music_albums WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $manageAlbumId);
        $manageAlbum = musicRows($stmt)[0] ?? null;
    }

    if (!musicCsrfOk()) {
        $error = "Сессия устарела. Обновите страницу и попробуйте снова.";
    } elseif (!$manageAlbum) {
        $error = "Альбом не найден.";
    } else {
        $redirectTo = "music.php?album=" . $manageAlbumId;
        $albumOwner = (int)$manageAlbum["user_id"] === $user_id;

        if ($action === "album_add_tracks") {
            if (!$albumOwner || !$can_upload) {
                $error = "Добавлять треки может только владелец альбома.";
            } else {
                $ids = array_filter(array_map("intval", (array)($_POST["track_ids"] ?? [])), fn($v) => $v > 0);
                if (empty($ids)) {
                    $error = "Выберите хотя бы один трек.";
                } else {
                    // Только свои треки, которые ещё не лежат в другом альбоме
                    $added = 0;
                    $stmt = $conn->prepare("UPDATE music SET album_id = ? WHERE id = ? AND user_id = ? AND album_id IS NULL");
                    foreach (array_unique($ids) as $tid) {
                        $stmt->bind_param("iii", $manageAlbumId, $tid, $user_id);
                        $stmt->execute();
                        $added += $stmt->affected_rows > 0 ? 1 : 0;
                    }
                    $stmt->close();
                    if ($added > 0) {
                        $success = "Добавлено треков в альбом: " . $added . ".";
                    } else {
                        $error = "Не удалось добавить выбранные треки.";
                    }
                }
            }
        } else {
            if (!$albumOwner && !$is_admin) {
                $error = "Нет прав на изменение этого альбома.";
            } else {
                $tid = (int)($_POST["track_id"] ?? 0);
                $stmt = $conn->prepare("UPDATE music SET album_id = NULL WHERE id = ? AND album_id = ?");
                $stmt->bind_param("ii", $tid, $manageAlbumId);
                $stmt->execute();
                $success = $stmt->affected_rows > 0 ? "Трек убран из альбома, на сайте он остался." : "";
                $error = $success === "" ? "Трека нет в этом альбоме." : "";
                $stmt->close();
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| РЕДИРЕКТ ПОСЛЕ ЛЮБОГО POST (Post/Redirect/Get)
|--------------------------------------------------------------------------
| Результат кладём в сессию и отправляем браузер на обычный GET —
| тогда F5 просто перезагружает страницу и ничего не отправляет повторно.
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if ($error !== "") {
        musicRedirect("error", $error, $redirectTo);
    }
    if ($success !== "") {
        musicRedirect("success", $success, $redirectTo);
    }
    header("Location: " . $redirectTo);
    exit;
}

/*
|--------------------------------------------------------------------------
| УДАЛЕНИЕ ТРЕКА (свой — владелец, любой — администратор)
|--------------------------------------------------------------------------
*/

if (isset($_GET["delete"]) && is_numeric($_GET["delete"])) {
    $track_id = (int)$_GET["delete"];
    $deleted = false;
    $deleteOwner = 0;

    if (musicCsrfOk()) {
        $stmt = $conn->prepare("
            SELECT filepath, user_id, cover
            FROM music
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->bind_param("i", $track_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $track = $result->fetch_assoc();
        $stmt->close();

        $deleteOwner = $track ? (int)$track["user_id"] : 0;

        if ($track && ($is_admin || (int)$track["user_id"] === $user_id)) {
            $deleted = true;
            $physicalPath = __DIR__ . "/" . $track["filepath"];
            if (file_exists($physicalPath)) {
                unlink($physicalPath);
            }

            // Обложку трека удаляем только из своей папки
            if (!empty($track["cover"]) && strpos($track["cover"], "uploads/music/covers/") === 0) {
                $coverPhysical = $musicDir . "covers/" . basename($track["cover"]);
                if (is_file($coverPhysical)) {
                    unlink($coverPhysical);
                }
            }

            $stmt = $conn->prepare("DELETE FROM music WHERE id = ?");
            $stmt->bind_param("i", $track_id);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM music_library WHERE track_id = ?");
            $stmt->bind_param("i", $track_id);
            $stmt->execute();
            $stmt->close();
        }
    }

    // Удаляли со страницы артиста — возвращаемся на неё
    if (($_GET["back"] ?? "") === "artist" && $deleteOwner > 0) {
        $backUrl = "artist.php?id=" . $deleteOwner;
        if ($deleted) {
            musicRedirect("success", "Трек удалён.", $backUrl);
        }
        header("Location: " . $backUrl);
        exit;
    }

    header("Location: music.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| ПОИСК МУЗЫКИ
|--------------------------------------------------------------------------
*/

$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_tracks = [];

if (!empty($search_query) && strlen($search_query) >= 2) {
    $search_pattern = "%" . $search_query . "%";
    $stmt = $conn->prepare("
        SELECT
            m.id,
            m.user_id,
            m.title,
            m.filename,
            m.filepath,
            m.filesize,
            m.created_at,
            m.album_id,
            m.cover AS track_cover,
            al.title AS album_title,
            COALESCE(NULLIF(u.music_name, ''), u.username) AS username
        FROM music m
        LEFT JOIN users u ON u.id = m.user_id
        LEFT JOIN music_albums al ON al.id = m.album_id
        WHERE m.title LIKE ? OR u.username LIKE ? OR u.music_name LIKE ?
        ORDER BY m.id DESC
    ");
    $stmt->bind_param("sss", $search_pattern, $search_pattern, $search_pattern);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $search_tracks[] = $row;
    }
    $stmt->close();
}

/*
|--------------------------------------------------------------------------
| СПИСОК МУЗЫКИ
|--------------------------------------------------------------------------
*/

$tracks = [];

$result = $conn->query("
    SELECT
        m.id,
        m.user_id,
        m.title,
        m.filename,
        m.filepath,
        m.filesize,
        m.created_at,
        m.album_id,
        m.cover AS track_cover,
        al.title AS album_title,
        COALESCE(NULLIF(u.music_name, ''), u.username) AS username
    FROM music m
    LEFT JOIN users u ON u.id = m.user_id
    LEFT JOIN music_albums al ON al.id = m.album_id
    ORDER BY m.id DESC
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $tracks[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| ДАННЫЕ ДЛЯ АЛЬБОМОВ И КАРТОЧКИ АРТИСТА
|--------------------------------------------------------------------------
*/

function musicRows(mysqli_stmt $stmt): array
{
    $stmt->execute();
    $rows = [];
    $res = $stmt->get_result();
    while ($res && ($row = $res->fetch_assoc())) {
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

$trackSelect = "
    SELECT m.id, m.user_id, m.title, m.filename, m.filepath, m.filesize, m.created_at,
           m.plays, m.album_id, m.cover AS track_cover, al.title AS album_title, al.cover AS album_cover,
           COALESCE(NULLIF(u.music_name, ''), u.username) AS username
    FROM music m
    LEFT JOIN users u ON u.id = m.user_id
    LEFT JOIN music_albums al ON al.id = m.album_id
";
$albumSelect = "
    SELECT a.id, a.user_id, a.title, a.description, a.cover, a.created_at, COALESCE(NULLIF(u.music_name, ''), u.username) AS username,
           (SELECT COUNT(*) FROM music mm WHERE mm.album_id = a.id) AS tracks_count
    FROM music_albums a
    LEFT JOIN users u ON u.id = a.user_id
";

$view = "home";
$album = null;
$album_tracks = [];
$album_size = 0;
$artist = null;
$artist_albums = [];
$artist_tracks = [];
$artist_popular = [];
$artist_followers = 0;
$artist_following = false;
$all_albums = [];
$free_tracks = [];

if (isset($_GET["album"]) && ctype_digit((string)$_GET["album"])) {
    $stmt = $conn->prepare($albumSelect . " WHERE a.id = ? LIMIT 1");
    $viewAlbumId = (int)$_GET["album"];
    $stmt->bind_param("i", $viewAlbumId);
    $rows = musicRows($stmt);
    $album = $rows[0] ?? null;

    if ($album) {
        $view = "album";
        $stmt = $conn->prepare($trackSelect . " WHERE m.album_id = ? ORDER BY m.id ASC");
        $stmt->bind_param("i", $viewAlbumId);
        $album_tracks = musicRows($stmt);
        foreach ($album_tracks as $t) {
            $album_size += (int)$t["filesize"];
        }

        // Свои треки, которых ещё нет ни в одном альбоме: их можно добавить в этот альбом
        if ($can_upload && (int)$album["user_id"] === $user_id) {
            $stmt = $conn->prepare("SELECT id, title FROM music WHERE user_id = ? AND album_id IS NULL ORDER BY id DESC");
            $stmt->bind_param("i", $user_id);
            $free_tracks = musicRows($stmt);
        }
    } else {
        $error = "Альбом не найден.";
    }
} elseif (isset($_GET["artist"]) && ctype_digit((string)$_GET["artist"])) {
    $viewArtistId = (int)$_GET["artist"];
    $stmt = $conn->prepare("SELECT id, username, avatar, status, is_musician, is_producer, is_admin, music_banner FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $viewArtistId);
    $rows = musicRows($stmt);
    $artist = $rows[0] ?? null;

    if ($artist) {
        $view = "artist";
        $stmt = $conn->prepare($albumSelect . " WHERE a.user_id = ? ORDER BY a.id DESC");
        $stmt->bind_param("i", $viewArtistId);
        $artist_albums = musicRows($stmt);

        $stmt = $conn->prepare($trackSelect . " WHERE m.user_id = ? ORDER BY m.id DESC");
        $stmt->bind_param("i", $viewArtistId);
        $artist_tracks = musicRows($stmt);

        // Подписчики и состояние подписки
        $stmt = $conn->prepare("SELECT COUNT(*) FROM music_follows WHERE artist_id = ?");
        $stmt->bind_param("i", $viewArtistId);
        $stmt->execute();
        $artist_followers = (int)($stmt->get_result()->fetch_row()[0] ?? 0);
        $stmt->close();

        $stmt = $conn->prepare("SELECT 1 FROM music_follows WHERE follower_id = ? AND artist_id = ? LIMIT 1");
        $stmt->bind_param("ii", $user_id, $viewArtistId);
        $stmt->execute();
        $artist_following = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();

        // «Популярное»: сначала самые прослушиваемые, при равенстве — новые; не больше 9 (3 колонки по 3)
        $artist_popular = $artist_tracks;
        usort($artist_popular, function ($a, $b) {
            return ((int)$b["plays"] <=> (int)$a["plays"]) ?: ((int)$b["id"] <=> (int)$a["id"]);
        });
        $artist_popular = array_slice($artist_popular, 0, 9);
    } else {
        $error = "Артист не найден.";
    }
}

$my_tracks = [];

if ($view === "home") {
    // Моя музыка: свои загрузки + чужие треки, добавленные себе
    $stmt = $conn->prepare($trackSelect . " WHERE m.user_id = ? OR m.id IN (SELECT track_id FROM music_library WHERE user_id = ?) ORDER BY m.id DESC");
    $stmt->bind_param("ii", $user_id, $user_id);
    $my_tracks = musicRows($stmt);

    $result = $conn->query($albumSelect . " ORDER BY a.id DESC LIMIT 24");
    while ($result && ($row = $result->fetch_assoc())) {
        $all_albums[] = $row;
    }
}


/*
|--------------------------------------------------------------------------
| ФУНКЦИЯ РАЗМЕРА ФАЙЛА
|--------------------------------------------------------------------------
*/

function formatFileSize($bytes)
{
    if ($bytes < 1024) {
        return $bytes . " Б";
    }
    if ($bytes < 1024 * 1024) {
        return round($bytes / 1024, 1) . " КБ";
    }
    return round($bytes / 1024 / 1024, 1) . " МБ";
}

/*
|--------------------------------------------------------------------------
| СПИСОК МУЗЫКАНТОВ (для блока администратора)
|--------------------------------------------------------------------------
*/

$musicians = [];

if ($is_producer) {
    $result = $conn->query("
        SELECT id, username
        FROM users
        WHERE is_musician = 1
        ORDER BY username ASC
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $musicians[] = $row;
        }
    }
}

/*
|--------------------------------------------------------------------------
| ОДНА СТРОКА ТРЕКА (общая для поиска и общего списка)
|--------------------------------------------------------------------------
*/

function renderTrack(array $track, int $user_id, bool $is_admin, string $csrf_token, int $removeFromAlbum = 0): void
{
    $author = $track["username"] ?: "Пользователь";
    $can_delete = $is_admin || (int)$track["user_id"] === $user_id;
    // Обложка трека; если её нет — обложка альбома (когда она есть в выборке)
    $trackCover = !empty($track["track_cover"]) ? (string)$track["track_cover"]
        : (!empty($track["album_cover"]) ? (string)$track["album_cover"] : "");
    $hasCover = $trackCover !== "" && is_file(__DIR__ . "/" . $trackCover);
    // Кнопка «+ / ✓» — только на чужих треках: добавить в свою музыку или убрать оттуда
    $showLib = (int)$track["user_id"] !== $user_id;
    $inLib = !empty($GLOBALS["libraryIds"][(int)$track["id"]]);
    $libTitle = $inLib ? "Убрать из моей музыки" : "Добавить в мою музыку";
    ?>
    <div class="track">
        <button type="button" class="track-icon track-play<?= $hasCover ? " has-cover" : "" ?>"<?= $hasCover ? ' style="background-image:url(\'' . htmlspecialchars($trackCover, ENT_QUOTES, "UTF-8") . '\')"' : "" ?> aria-label="Воспроизвести" title="Воспроизвести">
            <svg class="i-play" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.52.85l10.4-6.5a1 1 0 0 0 0-1.7L9.52 4.65A1 1 0 0 0 8 5.5z"/></svg>
            <svg class="i-pause" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4.2" height="14" rx="1.2"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.2"/></svg>
        </button>
        <div class="track-info">
            <div class="track-name"><?= htmlspecialchars($track["title"], ENT_QUOTES, "UTF-8") ?></div>
            <div class="track-author">
                Исполнитель: <a href="artist.php?id=<?= (int)$track["user_id"] ?>" class="artist-link"><?= htmlspecialchars($author, ENT_QUOTES, "UTF-8") ?></a>
                <?php if (!empty($track["album_id"]) && !empty($track["album_title"])): ?>
                    · Альбом: <a href="music.php?album=<?= (int)$track["album_id"] ?>" class="artist-link"><?= htmlspecialchars($track["album_title"], ENT_QUOTES, "UTF-8") ?></a>
                <?php endif; ?>
                · Размер: <?= formatFileSize((int)$track["filesize"]) ?>
            </div>
        </div>
        <div class="mp" data-title="<?= htmlspecialchars($track["title"], ENT_QUOTES, "UTF-8") ?>" data-artist="<?= htmlspecialchars($author, ENT_QUOTES, "UTF-8") ?>">
            <audio controls preload="metadata">
                <source src="<?= htmlspecialchars($track["filepath"], ENT_QUOTES, "UTF-8") ?>" type="audio/mpeg">
                Ваш браузер не поддерживает аудио.
            </audio>
            <div class="mp-ui">
                <span class="mp-time mp-cur">0:00</span>
                <input type="range" class="mp-seek" min="0" max="100" value="0" step="any" aria-label="Перемотка">
                <span class="mp-time mp-dur">0:00</span>
                <div class="mp-vol">
                    <button type="button" class="mp-btn mp-mute" aria-label="Выключить звук" title="Выключить звук">
                        <svg class="i-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z" fill="currentColor"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>
                        <svg class="i-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z" fill="currentColor"/><path d="m16 9 5 6M21 9l-5 6"/></svg>
                    </button>
                    <input type="range" class="mp-volume" min="0" max="1" step="0.01" value="1" aria-label="Громкость">
                </div>
            </div>
        </div>
        <?php if ($can_delete || $removeFromAlbum > 0 || $showLib): ?>
            <div class="track-actions">
                <?php if ($showLib): ?>
                    <button type="button" class="track-lib<?= $inLib ? " is-added" : "" ?>"
                            data-track-id="<?= (int)$track["id"] ?>"
                            data-csrf="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>"
                            aria-pressed="<?= $inLib ? "true" : "false" ?>"
                            title="<?= $libTitle ?>" aria-label="<?= $libTitle ?>">
                        <svg class="i-plus" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                        <svg class="i-check" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>
                    </button>
                <?php endif; ?>
                <?php if ($removeFromAlbum > 0): ?>
                    <form method="POST" class="track-remove-form">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                        <input type="hidden" name="action" value="album_remove_track">
                        <input type="hidden" name="album_id" value="<?= $removeFromAlbum ?>">
                        <input type="hidden" name="track_id" value="<?= (int)$track["id"] ?>">
                        <button type="submit" class="track-delete" data-confirm="Убрать трек из альбома? Сам трек останется на сайте.">− Из альбома</button>
                    </form>
                <?php endif; ?>
                <?php if ($can_delete): ?>
                    <a href="music.php?delete=<?= (int)$track["id"] ?>&amp;csrf=<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>"
                       class="track-delete" title="Удалить трек" aria-label="Удалить трек"
                       data-confirm="Удалить этот трек? Это нельзя отменить.">✕</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/*
|--------------------------------------------------------------------------
| КАРТОЧКА АЛЬБОМА И АВАТАР (общие для всех видов страницы)
|--------------------------------------------------------------------------
*/

function renderAlbumCard(array $a): void
{
    $count = (int)$a["tracks_count"];
    ?>
    <a class="album-card" href="music.php?album=<?= (int)$a["id"] ?>">
        <div class="album-cover">
            <?php if (!empty($a["cover"])): ?>
                <img src="<?= htmlspecialchars($a["cover"], ENT_QUOTES, "UTF-8") ?>" alt="" loading="lazy">
            <?php else: ?>
                <span>♪</span>
            <?php endif; ?>
        </div>
        <div class="album-title"><?= htmlspecialchars($a["title"], ENT_QUOTES, "UTF-8") ?></div>
        <div class="album-meta">
            <?= htmlspecialchars($a["username"] ?: "Пользователь", ENT_QUOTES, "UTF-8") ?> · <?= $count ?> <?= $count === 1 ? "трек" : "треков" ?>
        </div>
    </a>
    <?php
}

// Путь к аватару: берём как в БД, а если там только имя файла — ищем в uploads/avatars/
function musicAvatarUrl(?string $avatar): string
{
    $avatar = trim((string)$avatar);
    if ($avatar === "") {
        return "";
    }
    if (preg_match('~^(https?:)?//~', $avatar)) {
        return $avatar;
    }
    if (is_file(__DIR__ . "/" . $avatar)) {
        return $avatar;
    }
    if (is_file(__DIR__ . "/uploads/avatars/" . $avatar)) {
        return "uploads/avatars/" . $avatar;
    }
    return "";
}

/*
|--------------------------------------------------------------------------
| ОБОЛОЧКА СТРАНИЦЫ (шапка, уведомления, тема) — как в index.php
|--------------------------------------------------------------------------
*/

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: music.php");
    exit;
}

$notifications = [];
$notif_count = 0;
$unread_count = 0;
$pending_reports_count = 0;
$current_user_data = [];

try {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

    $stmt = $conn->prepare("SELECT id, username, avatar, status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    if ($is_admin) {
        $result = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
        if ($result) {
            $pending_reports_count = (int)$result->fetch_assoc()['c'];
        }
    }
} catch (Throwable $e) {
    error_log('music.php shell: ' . $e->getMessage());
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function isOnline(?string $status): bool {
    return $status === 'online';
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Музыка</title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/music.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/music.css') ?>">
    <link rel="stylesheet" href="assets/css/music-player.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/music-player.css') ?>">
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout music-layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main class="music-main">

            <section class="card music-head">
                <div class="music-head-title">
                    <span class="music-head-icon">♪</span>
                    <div>
                        <h1>Музыка</h1>
                        <p>Слушайте треки прямо на сайте</p>
                    </div>
                </div>

                <form method="GET" action="music.php" class="search-center<?= $can_upload ? ' has-tools' : '' ?>">
                    <input
                        class="search-center-input"
                        type="text"
                        name="search"
                        id="musicSearch"
                        placeholder="Найти музыку или исполнителя..."
                        value="<?= htmlspecialchars($search_query, ENT_QUOTES, "UTF-8") ?>"
                        autocomplete="off"
                    >
                    <?php if (!empty($search_query)): ?>
                        <a href="music.php" class="search-center-clear" title="Сбросить поиск">✕</a>
                    <?php endif; ?>
                    <button type="submit" class="search-center-btn">Найти</button>
                    <?php if ($can_upload): ?>
                        <button type="button" class="icon-btn" data-panel="panelUpload" aria-expanded="false" aria-controls="panelUpload" title="Загрузить музыку" aria-label="Загрузить музыку">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></svg>
                        </button>
                        <button type="button" class="icon-btn" data-panel="panelAlbum" aria-expanded="false" aria-controls="panelAlbum" title="Создать альбом" aria-label="Создать альбом">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 8v8M8 12h8"/></svg>
                        </button>
                    <?php endif; ?>
                </form>

                <?php if ($can_upload): ?>
                    <div class="head-panel" id="panelUpload" hidden>
                        <div class="head-panel-title">Загрузить музыку</div>
                        <form method="POST" enctype="multipart/form-data" class="upload-form head-form"
                              id="uploadForm" data-max-bytes="<?= 20 * 1024 * 1024 ?>">
                            <input type="hidden" name="action" value="upload">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                            <input type="file" name="music" class="file-input" accept=".mp3,audio/mpeg" required>
                            <label class="cover-pick">
                                <span>Обложка трека (необязательно)</span>
                                <input type="file" name="track_cover" class="file-input" accept="image/jpeg,image/png,image/webp">
                            </label>
                            <button type="submit" class="button">Загрузить MP3</button>
                        </form>
                        <div class="alert error upload-error" id="uploadError" hidden></div>
                    </div>

                    <div class="head-panel" id="panelAlbum" hidden>
                        <div class="head-panel-title">Новый альбом</div>
                        <form method="POST" enctype="multipart/form-data" class="upload-form head-form head-form-album">
                            <input type="hidden" name="action" value="album_create">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                            <input type="text" name="album_title" class="text-input head-grow" placeholder="Название альбома" maxlength="255" required>
                            <input type="file" name="cover" class="file-input head-grow" accept="image/jpeg,image/png,image/webp" title="Обложка (необязательно)">
                            <textarea name="album_desc" class="text-input textarea-input head-full" placeholder="Описание (необязательно)" maxlength="1000" rows="2"></textarea>
                            <button type="submit" class="button">Создать альбом</button>
                        </form>
                    </div>
                <?php endif; ?>
            </section>

            <?php if ($success): ?>
                <div class="alert success"><?= htmlspecialchars($success, ENT_QUOTES, "UTF-8") ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
            <?php endif; ?>

            <?php if ($view === "artist"):
                $artistAvatar = musicAvatarUrl($artist["avatar"] ?? "");
                $artistLetter = mb_strtoupper(mb_substr($artist["username"], 0, 1, "UTF-8"), "UTF-8");
                $artistRole = !empty($artist["is_producer"]) ? "Продюсер"
                    : (!empty($artist["is_musician"]) ? "Музыкант"
                    : (!empty($artist["is_admin"]) || (int)$artist["id"] === 1 ? "Администратор" : ""));
                $artistSize = 0;
                foreach ($artist_tracks as $t) { $artistSize += (int)$t["filesize"]; }
            ?>
                <?php
                $bannerUrl = "";
                if (!empty($artist["music_banner"]) && is_file(__DIR__ . "/" . $artist["music_banner"])) {
                    $bannerUrl = (string)$artist["music_banner"];
                }
                $heroImg = $bannerUrl !== "" ? $bannerUrl : $artistAvatar;
                $isOwnPage = (int)$artist["id"] === $user_id;
                $canEditBanner = $isOwnPage || $is_admin;
                $followersWord = function (int $n): string {
                    $m10 = $n % 10; $m100 = $n % 100;
                    if ($m10 === 1 && $m100 !== 11) return "подписчик";
                    if ($m10 >= 2 && $m10 <= 4 && ($m100 < 12 || $m100 > 14)) return "подписчика";
                    return "подписчиков";
                };
                ?>
                <section class="card artist-page">
                    <nav class="artist-crumbs" aria-label="Навигация">
                        <a href="music.php">Музыка</a>
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>
                        <span aria-current="page"><?= htmlspecialchars($artist["username"], ENT_QUOTES, "UTF-8") ?></span>
                    </nav>

                    <div class="artist-hero<?= $heroImg === "" ? " no-image" : "" ?><?= $bannerUrl === "" && $artistAvatar !== "" ? " from-avatar" : "" ?>">
                        <?php if ($heroImg !== ""): ?>
                            <img class="artist-hero-img" src="<?= htmlspecialchars($heroImg, ENT_QUOTES, "UTF-8") ?>" alt="">
                        <?php endif; ?>
                        <div class="artist-hero-shade"></div>

                        <?php if ($canEditBanner): ?>
                            <div class="artist-banner-tools">
                                <form method="POST" enctype="multipart/form-data" class="artist-banner-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                    <input type="hidden" name="action" value="artist_banner">
                                    <input type="hidden" name="artist_id" value="<?= (int)$artist["id"] ?>">
                                    <label class="artist-banner-btn" title="Сменить шапку">
                                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8a2 2 0 0 1 2-2h1.5l1.4-2h6.2l1.4 2H18a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3.5"/></svg>
                                        <span>Сменить шапку</span>
                                        <input type="file" name="banner" id="bannerInput" accept="image/jpeg,image/png,image/webp" hidden>
                                    </label>
                                </form>
                                <?php if ($bannerUrl !== ""): ?>
                                    <form method="POST" class="artist-banner-form">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                        <input type="hidden" name="action" value="artist_banner_remove">
                                        <input type="hidden" name="artist_id" value="<?= (int)$artist["id"] ?>">
                                        <button type="submit" class="artist-banner-btn" title="Убрать шапку" aria-label="Убрать шапку" data-confirm="Убрать шапку страницы?">✕</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="artist-hero-body">
                            <div class="artist-hero-text">
                                <h1 class="artist-hero-name"><?= htmlspecialchars($artist["username"], ENT_QUOTES, "UTF-8") ?></h1>
                                <div class="artist-hero-meta">
                                    <?php if ($artistRole !== ""): ?><span class="artist-badge"><?= $artistRole ?></span><?php endif; ?>
                                    <span><?= $artist_followers ?> <?= $followersWord($artist_followers) ?></span>
                                    <span><?= count($artist_tracks) ?> <?= count($artist_tracks) === 1 ? "трек" : "треков" ?></span>
                                    <?php if (!empty($artist_albums)): ?><span><?= count($artist_albums) ?> <?= count($artist_albums) === 1 ? "альбом" : "альбомов" ?></span><?php endif; ?>
                                </div>
                            </div>
                            <div class="artist-hero-actions">
                                <?php if (!$isOwnPage): ?>
                                    <form method="POST" class="artist-follow-form">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                        <input type="hidden" name="action" value="<?= $artist_following ? "artist_unfollow" : "artist_follow" ?>">
                                        <input type="hidden" name="artist_id" value="<?= (int)$artist["id"] ?>">
                                        <button type="submit" class="hero-btn"<?= $artist_following ? ' title="Нажмите, чтобы отписаться"' : "" ?>>
                                            <?php if ($artist_following): ?>
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4.5 12.5 5 5 10-11"/></svg>
                                                <span>Вы подписаны</span>
                                            <?php else: ?>
                                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                                                <span>Подписаться</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <?php if (!empty($artist_popular)): ?>
                                    <button type="button" class="hero-btn" id="artistListen">
                                        <svg class="i-play" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.52.85l10.4-6.5a1 1 0 0 0 0-1.7L9.52 4.65A1 1 0 0 0 8 5.5z"/></svg>
                                        <svg class="i-pause" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4.2" height="14" rx="1.2"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.2"/></svg>
                                        <span>Слушать</span>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($artist_popular)): ?>
                        <div class="artist-popular" id="artistPopular" data-csrf="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                            <div class="artist-popular-head">
                                <h2>Популярное</h2>
                                <a href="#artistTracks" class="artist-popular-all" id="artistAll">
                                    Показать все
                                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>
                                </a>
                            </div>
                            <div class="artist-popular-grid">
                                <?php foreach ($artist_popular as $pt):
                                    $ptCover = !empty($pt["album_cover"]) ? (string)$pt["album_cover"] : $artistAvatar;
                                    ?>
                                    <button type="button" class="pop-row"
                                            data-id="<?= (int)$pt["id"] ?>"
                                            data-src="<?= htmlspecialchars($pt["filepath"], ENT_QUOTES, "UTF-8") ?>"
                                            data-size="<?= (int)$pt["filesize"] ?>">
                                        <span class="pop-cover">
                                            <?php if ($ptCover !== ""): ?>
                                                <img src="<?= htmlspecialchars($ptCover, ENT_QUOTES, "UTF-8") ?>" alt="" loading="lazy">
                                            <?php else: ?>
                                                <span class="pop-cover-note">♪</span>
                                            <?php endif; ?>
                                            <span class="pop-state" aria-hidden="true">
                                                <svg class="i-play" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M8 5.5v13a1 1 0 0 0 1.52.85l10.4-6.5a1 1 0 0 0 0-1.7L9.52 4.65A1 1 0 0 0 8 5.5z"/></svg>
                                                <svg class="i-pause" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><rect x="6" y="5" width="4.2" height="14" rx="1.2"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.2"/></svg>
                                            </span>
                                        </span>
                                        <span class="pop-info">
                                            <span class="pop-title"><?= htmlspecialchars($pt["title"], ENT_QUOTES, "UTF-8") ?></span>
                                            <span class="pop-artist"><?= htmlspecialchars($pt["username"] ?: $artist["username"], ENT_QUOTES, "UTF-8") ?></span>
                                        </span>
                                        <span class="pop-meta">
                                            <span class="pop-dur">–:––</span>
                                            <span class="pop-kbps" hidden></span>
                                        </span>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </section>

                <?php if (!empty($artist_albums)): ?>
                    <section class="card music-block">
                        <div class="music-block-title">Альбомы <span class="search-result-count"><?= count($artist_albums) ?></span></div>
                        <div class="album-grid">
                            <?php foreach ($artist_albums as $a): renderAlbumCard($a); endforeach; ?>
                        </div>
                    </section>
                <?php endif; ?>

                <section class="card music-block" id="artistTracks">
                    <div class="music-block-title">Треки <span class="search-result-count"><?= count($artist_tracks) ?></span></div>
                    <?php if (empty($artist_tracks)): ?>
                        <div class="empty">
                            <div class="empty-icon">🎵</div>
                            <div>У этого артиста пока нет треков.</div>
                        </div>
                    <?php else: ?>
                        <div class="track-list">
                            <?php foreach ($artist_tracks as $track): renderTrack($track, $user_id, $is_admin, $csrf_token); endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>

            <?php elseif ($view === "album"):
                $can_manage_album = $is_admin || (int)$album["user_id"] === $user_id;
            ?>
                <section class="card album-head">
                    <div class="album-cover album-cover-big">
                        <?php if (!empty($album["cover"])): ?>
                            <img src="<?= htmlspecialchars($album["cover"], ENT_QUOTES, "UTF-8") ?>" alt="">
                        <?php else: ?>
                            <span>♪</span>
                        <?php endif; ?>
                    </div>
                    <div class="album-head-info">
                        <div class="album-kicker">Альбом</div>
                        <h2 class="album-head-title"><?= htmlspecialchars($album["title"], ENT_QUOTES, "UTF-8") ?></h2>
                        <div class="album-head-artist">
                            <a href="artist.php?id=<?= (int)$album["user_id"] ?>" class="artist-link"><?= htmlspecialchars($album["username"] ?: "Пользователь", ENT_QUOTES, "UTF-8") ?></a>
                            · <?= count($album_tracks) ?> треков
                            <?php if ($album_size > 0): ?>· <?= formatFileSize($album_size) ?><?php endif; ?>
                            · <?= date("d.m.Y", strtotime($album["created_at"])) ?>
                        </div>
                        <?php if (!empty($album["description"])): ?>
                            <p class="album-desc"><?= nl2br(htmlspecialchars($album["description"], ENT_QUOTES, "UTF-8")) ?></p>
                        <?php endif; ?>
                        <div class="album-actions">
                            <a href="music.php" class="artist-back">← Вся музыка</a>
                            <?php if ($is_admin || (int)$album["user_id"] === $user_id): ?>
                                <form method="POST" class="album-delete-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                    <input type="hidden" name="action" value="album_delete">
                                    <input type="hidden" name="album_id" value="<?= (int)$album["id"] ?>">
                                    <button type="submit" class="button button-danger album-delete-btn"
                                            data-confirm="Удалить альбом? Треки останутся на сайте.">Удалить альбом</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>

                <?php if ($can_upload && (int)$album["user_id"] === $user_id): ?>
                    <section class="card music-block">
                        <div class="music-block-title">Добавить треки в альбом</div>
                        <?php if (empty($free_tracks)): ?>
                            <div class="music-subtitle music-subtitle-flush">
                                Свободных треков нет. Сначала загрузите музыку (иконка ↑ возле поиска), потом её можно будет добавить сюда.
                            </div>
                        <?php else: ?>
                            <form method="POST" class="add-tracks-form">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                <input type="hidden" name="action" value="album_add_tracks">
                                <input type="hidden" name="album_id" value="<?= (int)$album["id"] ?>">
                                <div class="add-tracks-list">
                                    <?php foreach ($free_tracks as $ft): ?>
                                        <label class="add-track">
                                            <input type="checkbox" name="track_ids[]" value="<?= (int)$ft["id"] ?>">
                                            <span><?= htmlspecialchars($ft["title"], ENT_QUOTES, "UTF-8") ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                                <button type="submit" class="button">Добавить выбранные</button>
                            </form>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>

                <section class="card music-block">
                    <div class="music-block-title">Треки альбома</div>
                    <?php if (empty($album_tracks)): ?>
                        <div class="empty">
                            <div class="empty-icon">🎵</div>
                            <div>В альбоме пока нет треков.</div>
                            <?php if ((int)$album["user_id"] === $user_id && $can_upload): ?>
                                <div class="empty-hint">Добавьте сюда свои загруженные треки в блоке выше.</div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="track-list">
                            <?php foreach ($album_tracks as $track): renderTrack($track, $user_id, $is_admin, $csrf_token, $can_manage_album ? (int)$album["id"] : 0); endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>

            <?php else: ?>

            <?php if (!empty($search_query)): ?>
                <section class="card music-block">
                    <div class="search-result-bar">
                        <span class="search-result-text">
                            Результаты по запросу: <strong><?= htmlspecialchars($search_query, ENT_QUOTES, "UTF-8") ?></strong>
                            <?php if (!empty($search_tracks)): ?>
                                <span class="search-result-count"><?= count($search_tracks) ?></span>
                            <?php endif; ?>
                        </span>
                        <a href="music.php" class="search-result-all">Показать все</a>
                    </div>

                    <?php if (empty($search_tracks)): ?>
                        <div class="empty">
                            <div class="empty-icon">🔍</div>
                            <div>По вашему запросу ничего не найдено</div>
                            <div class="empty-hint">Попробуйте изменить запрос</div>
                        </div>
                    <?php else: ?>
                        <div class="track-list">
                            <?php foreach ($search_tracks as $track): ?>
                                <?php renderTrack($track, $user_id, $is_admin, $csrf_token); ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

            <?php if (empty($search_query)): ?>
                <section class="card music-block" id="myMusic">
                    <div class="music-block-title">Моя музыка <span class="search-result-count" id="myMusicCount"><?= count($my_tracks) ?></span></div>
                    <div class="track-list" id="myMusicList"<?= empty($my_tracks) ? " hidden" : "" ?>>
                        <?php foreach ($my_tracks as $track): renderTrack($track, $user_id, $is_admin, $csrf_token); endforeach; ?>
                    </div>
                    <div class="empty" id="myMusicEmpty"<?= !empty($my_tracks) ? " hidden" : "" ?>>
                        <div class="empty-icon">🎧</div>
                        <div>Здесь пока пусто.</div>
                        <div class="empty-hint">Нажмите «+» у любого трека, чтобы добавить его в свою музыку.</div>
                    </div>
                </section>
            <?php endif; ?>

            <?php if (!empty($all_albums) && empty($search_query)): ?>
                <section class="card music-block">
                    <div class="music-block-title">Альбомы <span class="search-result-count"><?= count($all_albums) ?></span></div>
                    <div class="album-grid">
                        <?php foreach ($all_albums as $a): renderAlbumCard($a); endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>


            <?php endif; ?>
        </main>

        <aside class="music-aside">

            <?php if ($is_producer): ?>
                <div class="card music-card">
                    <div class="music-title">Музыканты и продюсеры</div>
                    <div class="music-subtitle">
                        Выдайте пользователю возможность загружать музыку или заберите её. Введите ID или точный ник.
                    </div>

                    <form method="POST" class="upload-form role-form">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                        <input type="text" name="target" class="text-input" placeholder="ID или ник пользователя" required>
                        <div class="role-actions">
                            <button type="submit" name="action" value="musician_grant" class="button">Выдать роль</button>
                            <button type="submit" name="action" value="musician_revoke" class="button button-danger"
                                    data-confirm="Забрать у пользователя возможность загружать музыку?">Забрать</button>
                        </div>
                    </form>

                    <?php if (!empty($musicians)): ?>
                        <div class="musician-list">
                            <?php foreach ($musicians as $musician): ?>
                                <form method="POST" class="musician-chip">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, "UTF-8") ?>">
                                    <input type="hidden" name="action" value="musician_revoke">
                                    <input type="hidden" name="target" value="<?= (int)$musician["id"] ?>">
                                    <span><?= htmlspecialchars($musician["username"], ENT_QUOTES, "UTF-8") ?> <small>#<?= (int)$musician["id"] ?></small></span>
                                    <button type="submit" class="musician-remove" title="Забрать роль"
                                            data-confirm="Забрать у пользователя возможность загружать музыку?">✕</button>
                                </form>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="music-subtitle music-subtitle-flush">Пока нет ни одного музыканта.</div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </aside>

        <div class="site-footer">
            SPACE &copy; <span class="year">2026</span>
        </div>

    </div>

    <script src="assets/js/script.js"></script>
    <script src="assets/js/music.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/music.js') ?>"></script>
    <script src="assets/js/music-player.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/music-player.js') ?>"></script>
    
</body>
</html>

<?php
$conn->close();

<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');

$conn = db_connect();
if ($conn->connect_error) {
    http_response_code(503);
    exit('Не удалось подключиться к базе данных.');
}
$conn->set_charset('utf8mb4');

$action = (string)($_GET['action'] ?? '');
if ($action !== 'poll') {
    $createTable = $conn->query("
        CREATE TABLE IF NOT EXISTS qr_login_sessions (
            token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            browser_session_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            approved_user_id INT NULL DEFAULT NULL,
            status ENUM('pending', 'approved', 'consumed', 'rejected') NOT NULL DEFAULT 'pending',
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (token_hash),
            KEY idx_qr_login_expiry (expires_at),
            KEY idx_qr_login_browser (browser_session_hash, status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    if (!$createTable) {
        error_log('Could not create QR login table: ' . $conn->error);
        http_response_code(503);
        exit('Вход по QR-коду сейчас недоступен.');
    }
}

function qrLoginJson(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function qrLoginTokenHash(string $token): ?string {
    return preg_match('/\A[a-f0-9]{64}\z/i', $token) ? hash('sha256', strtolower($token)) : null;
}

if ($action !== '') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        qrLoginJson(['error' => 'Метод не поддерживается.'], 405);
    }
    $originParts = parse_url((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
    $requestScheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $requestParts = parse_url($requestScheme . '://' . (string)($_SERVER['HTTP_HOST'] ?? ''));
    $originPort = is_array($originParts) ? (int)($originParts['port'] ?? (($originParts['scheme'] ?? '') === 'https' ? 443 : 80)) : 0;
    $requestPort = is_array($requestParts) ? (int)($requestParts['port'] ?? 80) : 0;
    if (
        !is_array($originParts)
        || !is_array($requestParts)
        || !isset($originParts['host'], $requestParts['host'])
        || strcasecmp((string)($originParts['scheme'] ?? ''), $requestScheme) !== 0
        || strcasecmp((string)$originParts['host'], (string)$requestParts['host']) !== 0
        || $originPort !== $requestPort
    ) {
        qrLoginJson(['error' => 'Недействительный источник запроса.'], 403);
    }

    if ($action === 'start') {
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $browserHash = hash('sha256', session_id());

        $cleanup = $conn->prepare("
            DELETE FROM qr_login_sessions
            WHERE expires_at < NOW()
        ");
        if (!$cleanup) {
            error_log('Could not prepare QR login cleanup: ' . $conn->error);
            qrLoginJson(['error' => 'Не удалось создать QR-код.'], 500);
        }
        if (!$cleanup->execute()) {
            error_log('Could not clean QR login sessions: ' . $cleanup->error);
            $cleanup->close();
            qrLoginJson(['error' => 'Не удалось создать QR-код.'], 500);
        }
        $cleanup->close();

        $insert = $conn->prepare("
            INSERT INTO qr_login_sessions (token_hash, browser_session_hash, expires_at)
            VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 120 SECOND))
        ");
        if (!$insert) {
            error_log('Could not prepare QR login session: ' . $conn->error);
            qrLoginJson(['error' => 'Не удалось создать QR-код.'], 500);
        }
        $insert->bind_param('ss', $tokenHash, $browserHash);
        if (!$insert->execute()) {
            error_log('Could not create QR login session: ' . $insert->error);
            $insert->close();
            qrLoginJson(['error' => 'Не удалось создать QR-код.'], 500);
        }
        $insert->close();
        qrLoginJson(['token' => $token, 'expires_in' => 120]);
    }

    if ($action === 'poll') {
        $tokenHash = qrLoginTokenHash((string)($_POST['token'] ?? ''));
        if ($tokenHash === null) {
            qrLoginJson(['error' => 'QR-код недействителен.'], 400);
        }
        $browserHash = hash('sha256', session_id());
        $conn->begin_transaction();
        $lookup = $conn->prepare("
            SELECT approved_user_id, status
            FROM qr_login_sessions
            WHERE token_hash = ? AND browser_session_hash = ? AND expires_at > NOW()
            FOR UPDATE
        ");
        if (!$lookup) {
            $conn->rollback();
            error_log('Could not prepare QR login polling: ' . $conn->error);
            qrLoginJson(['error' => 'Не удалось проверить QR-код.'], 500);
        }
        $lookup->bind_param('ss', $tokenHash, $browserHash);
        if (!$lookup->execute()) {
            $lookup->close();
            $conn->rollback();
            error_log('Could not poll QR login session: ' . $conn->error);
            qrLoginJson(['error' => 'Не удалось проверить QR-код.'], 500);
        }
        $session = $lookup->get_result()->fetch_assoc();
        $lookup->close();
        if (!$session) {
            $conn->rollback();
            qrLoginJson(['status' => 'expired']);
        }
        if ($session['status'] !== 'approved') {
            $status = $session['status'];
            $conn->commit();
            qrLoginJson(['status' => $status]);
        }

        $approvedUserId = (int)$session['approved_user_id'];
        $userStmt = $conn->prepare("
            SELECT id, username, session_version, is_blocked, deleted_at, deactivated_at
            FROM users WHERE id = ? LIMIT 1
        ");
        if (!$userStmt) {
            $conn->rollback();
            error_log('Could not prepare QR login user lookup: ' . $conn->error);
            qrLoginJson(['error' => 'Не удалось завершить вход.'], 500);
        }
        $userStmt->bind_param('i', $approvedUserId);
        if (!$userStmt->execute()) {
            $userStmt->close();
            $conn->rollback();
            error_log('Could not load QR login user: ' . $conn->error);
            qrLoginJson(['error' => 'Не удалось завершить вход.'], 500);
        }
        $user = $userStmt->get_result()->fetch_assoc();
        $userStmt->close();
        if (!$user || (int)$user['is_blocked'] === 1 || !empty($user['deleted_at']) || !empty($user['deactivated_at'])) {
            $reject = $conn->prepare("UPDATE qr_login_sessions SET status = 'rejected' WHERE token_hash = ?");
            if ($reject) {
                $reject->bind_param('s', $tokenHash);
                if (!$reject->execute()) {
                    error_log('Could not reject invalid QR login user: ' . $reject->error);
                }
                $reject->close();
            } else {
                error_log('Could not prepare QR login rejection: ' . $conn->error);
            }
            $conn->commit();
            qrLoginJson(['status' => 'rejected']);
        }

        $consume = $conn->prepare("
            UPDATE qr_login_sessions SET status = 'consumed'
            WHERE token_hash = ? AND status = 'approved'
        ");
        if (!$consume) {
            $conn->rollback();
            error_log('Could not prepare QR login consumption: ' . $conn->error);
            qrLoginJson(['error' => 'Не удалось завершить вход.'], 500);
        }
        $consume->bind_param('s', $tokenHash);
        if (!$consume->execute() || $consume->affected_rows !== 1) {
            $consume->close();
            $conn->rollback();
            qrLoginJson(['status' => 'expired']);
        }
        $consume->close();
        $conn->commit();

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['username'] = (string)$user['username'];
        $_SESSION['session_version'] = (int)$user['session_version'];
        $_SESSION['fresh_login'] = true;
        unset($_SESSION['saved_login']);

        $online = $conn->prepare("UPDATE users SET status = 'online', last_seen = NOW() WHERE id = ?");
        if (!$online) {
            error_log('Could not prepare QR login presence update: ' . $conn->error);
        } else {
            $userId = (int)$user['id'];
            $online->bind_param('i', $userId);
            if (!$online->execute()) {
                error_log('Could not update QR login presence: ' . $online->error);
            }
            $online->close();
        }

        $currentIp = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        if ($currentIp !== '') {
            $recentLogin = $conn->prepare("
                SELECT id FROM user_ip_history
                WHERE user_id = ? AND ip_address = ?
                  AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)
                  AND action = 'login'
                LIMIT 1
            ");
            if (!$recentLogin) {
                error_log('Could not prepare QR login IP history lookup: ' . $conn->error);
            } else {
                $recentLogin->bind_param('is', $userId, $currentIp);
                if (!$recentLogin->execute()) {
                    error_log('Could not query QR login IP history: ' . $recentLogin->error);
                } elseif (!$recentLogin->get_result()->fetch_assoc()) {
                    $ipInsert = $conn->prepare("
                        INSERT INTO user_ip_history (user_id, ip_address, user_agent, action)
                        VALUES (?, ?, ?, 'login')
                    ");
                    if (!$ipInsert) {
                        error_log('Could not prepare QR login IP history insert: ' . $conn->error);
                    } else {
                        $userAgent = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
                        $ipInsert->bind_param('iss', $userId, $currentIp, $userAgent);
                        if (!$ipInsert->execute()) {
                            error_log('Could not record QR login IP: ' . $ipInsert->error);
                        }
                        $ipInsert->close();
                    }
                }
                $recentLogin->close();
            }

            $ipUpdate = $conn->prepare("UPDATE users SET ip_address = ? WHERE id = ?");
            if (!$ipUpdate) {
                error_log('Could not prepare QR login IP update: ' . $conn->error);
            } else {
                $ipUpdate->bind_param('si', $currentIp, $userId);
                if (!$ipUpdate->execute()) {
                    error_log('Could not update QR login IP: ' . $ipUpdate->error);
                }
                $ipUpdate->close();
            }
        }
        qrLoginJson(['status' => 'logged_in']);
    }

    qrLoginJson(['error' => 'Неизвестное действие.'], 400);
}

$loggedInUserId = (int)($_SESSION['user_id'] ?? 0);
$csrf = $_SESSION['qr_login_csrf'] ?? '';
if (!is_string($csrf) || strlen($csrf) < 32) {
    $csrf = bin2hex(random_bytes(32));
    $_SESSION['qr_login_csrf'] = $csrf;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_qr_login'])) {
    $tokenHash = qrLoginTokenHash((string)($_POST['token'] ?? ''));
    $postedCsrf = (string)($_POST['csrf_token'] ?? '');
    if ($loggedInUserId <= 0) {
        http_response_code(401);
        exit('Войдите в приложение, затем отсканируйте QR-код ещё раз.');
    }
    if ($tokenHash === null || !hash_equals($csrf, $postedCsrf)) {
        http_response_code(400);
        exit('Запрос подтверждения недействителен. Отсканируйте QR-код ещё раз.');
    }
    $userCheck = $conn->prepare("
        SELECT id FROM users
        WHERE id = ? AND COALESCE(is_blocked, 0) = 0
          AND deleted_at IS NULL AND deactivated_at IS NULL
        LIMIT 1
    ");
    if (!$userCheck) {
        error_log('Could not prepare QR approval user check: ' . $conn->error);
        http_response_code(500);
        exit('Не удалось проверить аккаунт.');
    }
    $userCheck->bind_param('i', $loggedInUserId);
    if (!$userCheck->execute() || !$userCheck->get_result()->fetch_assoc()) {
        $userCheck->close();
        http_response_code(403);
        exit('Этому аккаунту запрещён вход.');
    }
    $userCheck->close();

    $approve = $conn->prepare("
        UPDATE qr_login_sessions
        SET approved_user_id = ?, status = 'approved'
        WHERE token_hash = ? AND status = 'pending' AND expires_at > NOW()
    ");
    if (!$approve) {
        error_log('Could not prepare QR approval: ' . $conn->error);
        http_response_code(500);
        exit('Не удалось подтвердить вход.');
    }
    $approve->bind_param('is', $loggedInUserId, $tokenHash);
    if (!$approve->execute()) {
        error_log('Could not approve QR login: ' . $approve->error);
        $approve->close();
        http_response_code(500);
        exit('Не удалось подтвердить вход.');
    }
    $approved = $approve->affected_rows === 1;
    $approve->close();
    if (!$approved) {
        http_response_code(410);
        exit('QR-код уже использован или истёк. Создайте новый код на компьютере.');
    }
    header('Location: qr_login.php?approved=1');
    exit;
}

$approveToken = (string)($_GET['approve'] ?? '');
$approveHash = qrLoginTokenHash($approveToken);
$approveValid = false;
if ($approveHash !== null) {
    $lookup = $conn->prepare("
        SELECT status FROM qr_login_sessions
        WHERE token_hash = ? AND status = 'pending' AND expires_at > NOW()
        LIMIT 1
    ");
    if (!$lookup) {
        error_log('Could not prepare QR approval page lookup: ' . $conn->error);
    } else {
        $lookup->bind_param('s', $approveHash);
        if (!$lookup->execute()) {
            error_log('Could not load QR approval page: ' . $lookup->error);
        } else {
            $approveValid = (bool)$lookup->get_result()->fetch_assoc();
        }
        $lookup->close();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Вход по QR-коду — V SPACE</title>
    <style>
        :root { color-scheme: dark; --bg:#11131b; --card:#1c2030; --text:#f3f4f8; --muted:#aeb4c4; --accent:#7284ff; }
        * { box-sizing:border-box; }
        body { min-height:100vh; margin:0; padding:24px; display:grid; place-items:center; background:radial-gradient(ellipse at top,#29294e,var(--bg) 62%); color:var(--text); font:16px/1.5 system-ui,sans-serif; }
        main { width:min(440px,100%); padding:30px; border:1px solid #ffffff20; border-radius:22px; background:var(--card); box-shadow:0 24px 70px #0006; text-align:center; }
        h1 { margin:0 0 10px; font-size:24px; }
        p { color:var(--muted); }
        button,.link { display:inline-flex; justify-content:center; align-items:center; min-height:48px; width:100%; margin-top:12px; padding:12px 18px; border:0; border-radius:12px; background:linear-gradient(120deg,#6677ff,#a24bff); color:white; font:inherit; font-weight:700; text-decoration:none; cursor:pointer; }
        .secondary { background:#ffffff12; border:1px solid #ffffff20; }
        .notice { margin:18px 0 0; padding:12px; border-radius:12px; background:#ffffff0b; color:var(--muted); font-size:14px; }
        .ok { color:#87e6ad; }
    </style>
</head>
<body>
<main>
    <?php if (isset($_GET['approved'])): ?>
        <h1 class="ok">Вход подтверждён</h1>
        <p>Вернитесь к компьютеру — вход завершится автоматически.</p>
    <?php elseif (isset($_GET['scanner'])): ?>
        <h1>Вход на компьютере</h1>
        <?php if ($loggedInUserId <= 0): ?>
            <p>Сначала войдите в аккаунт V SPACE в приложении, затем вернитесь сюда.</p>
            <a class="link secondary" href="login.php">Открыть вход</a>
        <?php else: ?>
            <p>Нажмите кнопку и наведите камеру на QR-код, показанный на компьютере.</p>
            <button type="button" id="startQrScan" hidden>Сканировать QR-код</button>
            <p class="notice" id="scannerStatus">Откройте эту страницу в приложении V SPACE для сканирования.</p>
        <?php endif; ?>
    <?php elseif (!$approveValid): ?>
        <h1>QR-код недействителен</h1>
        <p>Создайте новый QR-код на странице входа и отсканируйте его в приложении.</p>
        <a class="link secondary" href="login.php">Ко входу</a>
    <?php elseif ($loggedInUserId <= 0): ?>
        <h1>Нужно войти в приложение</h1>
        <p>Войдите в приложение V SPACE, затем отсканируйте QR-код ещё раз.</p>
        <a class="link secondary" href="login.php">Открыть вход</a>
    <?php else: ?>
        <h1>Подтвердить вход?</h1>
        <p>Разрешить вход на компьютере в аккаунт <strong><?= htmlspecialchars((string)($_SESSION['username'] ?? ''), ENT_QUOTES, 'UTF-8') ?></strong>?</p>
        <p class="notice">Подтверждайте только если вы сами открыли страницу входа на своём компьютере.</p>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="token" value="<?= htmlspecialchars($approveToken, ENT_QUOTES, 'UTF-8') ?>">
            <button type="submit" name="approve_qr_login" value="1">Подтвердить вход</button>
        </form>
        <a class="link secondary" href="qr_login.php?scanner=1">Отмена</a>
    <?php endif; ?>
</main>
<?php if (isset($_GET['scanner']) && $loggedInUserId > 0): ?>
<script>
    if (window.VSpaceApp && typeof window.VSpaceApp.scanQr === 'function') {
        const scanButton = document.getElementById('startQrScan');
        const status = document.getElementById('scannerStatus');
        scanButton.hidden = false;
        status.textContent = 'Вы вошли как <?= htmlspecialchars((string)($_SESSION['username'] ?? ''), ENT_QUOTES, 'UTF-8') ?>.';
        scanButton.addEventListener('click', () => window.VSpaceApp.scanQr());
    }
</script>
<?php endif; ?>
</body>
</html>

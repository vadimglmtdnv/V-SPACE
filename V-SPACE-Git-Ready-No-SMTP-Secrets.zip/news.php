<?php

// ============================================================
// ОБРАБОТКА ОШИБОК
// Любая ошибка (БД, PHP-исключение, фатальная ошибка) не должна давать белый экран:
//  • обычный запрос  → страница error.php (деталь видна только при заходе с localhost);
//  • AJAX-запрос     → JSON {success:false, message:"..."} — news.js покажет его всплывающим окном.
// ============================================================
ob_start();
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function newsFail(int $code, string $message, string $detail = ''): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    error_log('news.php [' . $code . ']: ' . $message . ($detail !== '' ? ' | ' . $detail : ''));

    $is_local = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
    $is_ajax  = strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'
        || stripos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

    if ($is_ajax) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        $out = ['success' => false, 'error' => 'server_error', 'message' => $message];
        if ($is_local && $detail !== '') {
            $out['detail'] = $detail;
        }
        echo json_encode($out, JSON_UNESCAPED_UNICODE);
        exit;
    }

    $error_code      = $code;
    $error_text      = $message;
    $error_detail    = $detail;
    $error_back_url  = 'news.php';
    require __DIR__ . '/error.php';
    exit;
}

set_exception_handler(static function (Throwable $e): void {
    $is_db = $e instanceof mysqli_sql_exception;
    newsFail(
        $is_db ? 503 : 500,
        $is_db ? 'Не удалось выполнить запрос к базе данных.' : 'На сервере произошла ошибка.',
        get_class($e) . ': ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')'
    );
});

register_shutdown_function(static function (): void {
    $last = error_get_last();
    if ($last && in_array($last['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        newsFail(500, 'На сервере произошла критическая ошибка.',
            $last['message'] . ' (' . basename($last['file']) . ':' . $last['line'] . ')');
    }
});

header("Content-Security-Policy: script-src 'self' 'unsafe-inline';");
header('Content-Type: text/html; charset=utf-8');

// Имя и фамилия лежат в user_profiles; если колонок ещё нет — создаём их (так же, как в edit.php)
if (!function_exists('ensureProfileNameColumns')) {
    function ensureProfileNameColumns(mysqli $conn): void {
        $conn->query("
            CREATE TABLE IF NOT EXISTS user_profiles (
                id INT(11) NOT NULL AUTO_INCREMENT,
                user_id INT(11) NOT NULL,
                first_name VARCHAR(50) DEFAULT NULL,
                last_name VARCHAR(50) DEFAULT NULL,
                birth_date DATE DEFAULT NULL,
                city VARCHAR(255) DEFAULT NULL,
                bio TEXT DEFAULT NULL,
                website_url VARCHAR(2048) DEFAULT NULL,
                updated_at TIMESTAMP NULL DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY user_id (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $chk = $conn->query("SHOW COLUMNS FROM user_profiles LIKE 'first_name'");
        if ($chk && $chk->num_rows === 0) {
            foreach (['first_name' => 'VARCHAR(50)', 'last_name' => 'VARCHAR(50)', 'birth_date' => 'DATE'] as $col => $def) {
                $c2 = $conn->query("SHOW COLUMNS FROM user_profiles LIKE '" . $col . "'");
                if ($c2 && $c2->num_rows === 0) {
                    $conn->query("ALTER TABLE user_profiles ADD COLUMN " . $col . " " . $def . " DEFAULT NULL");
                }
            }
        }
    }
}

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
// Если в настройках выбран English — содержимое страницы переводится «на лету» (includes/lang.php)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();
require_once __DIR__ . '/maintenance.php';

try {
    $conn = db_connect(true);
    ensureProfileNameColumns($conn);
} catch (Throwable $e) {
    $detail = get_class($e) . ': ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')';
    if ($e instanceof mysqli_sql_exception && in_array((int)$e->getCode(), [2002, 2003], true)) {
        $detail = 'Подключение не установлено, т.к. конечный компьютер отверг запрос на подключение';
    }
    newsFail(
        503,
        'Нет связи с базой данных. Попробуйте позже.',
        $detail
    );
}

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: news.php");
    exit;
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

// Получаем данные текущего пользователя
$current_user_data = [];
$stmt = $conn->prepare("SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, u.status, u.is_admin FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$current_user_data = $result->fetch_assoc();
$stmt->close();

$is_admin = isset($current_user_data['is_admin']) && $current_user_data['is_admin'] == 1;

// Жалобы, ожидающие модерации (кнопка «Модерация» в шапке, как в index.php)
$pending_reports_count = 0;
if ($is_admin) {
    $result = $conn->query("SELECT COUNT(*) as c FROM reports WHERE status = 'pending'");
    if ($result) {
        $pending_reports_count = (int)$result->fetch_assoc()['c'];
    }
}

// Количество непрочитанных сообщений
$unread_count = 0;
// Только входящие от других и ещё не прочитанные (как в index.php): свои сообщения и «Избранное» не считаются
$unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

// Уведомления для шапки — те же таблица и фильтр, что в index.php
$notifications = [];
$notif_count = 0;

$stmt = $conn->prepare("
    SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) as sender_name, u.username as sender_username, u.avatar as sender_avatar
    FROM notifications n
    LEFT JOIN users u ON u.id = n.sender_id
    LEFT JOIN user_profiles sp ON sp.user_id = u.id
    WHERE n.user_id = ?
      AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
    ORDER BY n.created_at DESC
    LIMIT 30
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$notif_count = $result->fetch_assoc()['count'] ?? 0;
$stmt->close();

$notification_count = $notif_count;

// ============================================================
// ШИФРОВАНИЕ ПОСТОВ — те же функции и тот же ключ, что в index.php.
// Посты из профиля хранятся в базе зашифрованными, поэтому в ленте их
// нужно расшифровывать, иначе вместо текста виден набор символов.
// ============================================================
if (!function_exists('getPostsEncryptionKey')) {
    function getPostsEncryptionKey(): string {
        static $key = null;
        if ($key !== null) return $key;

        $shared_config = __DIR__ . '/config.local.php';
        if (is_file($shared_config)) {
            @require_once $shared_config;
            if (defined('ENCRYPTION_SALT') && ENCRYPTION_SALT !== '') {
                $key = hash('sha256', 'posts:' . ENCRYPTION_SALT, true);
                return $key;
            }
        }

        $secret_file = __DIR__ . '/posts_encryption.key';
        if (!is_file($secret_file)) {
            @file_put_contents($secret_file, bin2hex(random_bytes(32)), LOCK_EX);
            @chmod($secret_file, 0600);
        }
        $secret = is_file($secret_file) ? trim((string)file_get_contents($secret_file)) : '';
        if ($secret === '') $secret = 'posts-fallback-secret';
        $key = hash('sha256', 'posts:' . $secret, true);
        return $key;
    }
}

if (!function_exists('encryptPostContent')) {
    function encryptPostContent(string $text): string {
        if ($text === '') return '';
        $iv_len = openssl_cipher_iv_length('aes-256-cbc');
        $iv = openssl_random_pseudo_bytes($iv_len);
        $encrypted = openssl_encrypt($text, 'aes-256-cbc', getPostsEncryptionKey(), OPENSSL_RAW_DATA, $iv);
        if ($encrypted === false) return '';
        return base64_encode($iv . $encrypted);
    }
}

if (!function_exists('decryptPostContent')) {
    function decryptPostContent(string $encrypted): string {
        if ($encrypted === '') return '';
        $data = base64_decode($encrypted, true);
        if ($data === false) return '';
        $iv_len = openssl_cipher_iv_length('aes-256-cbc');
        if (strlen($data) < $iv_len) return '';
        $iv = substr($data, 0, $iv_len);
        $cipher = substr($data, $iv_len);
        $decrypted = openssl_decrypt($cipher, 'aes-256-cbc', getPostsEncryptionKey(), OPENSSL_RAW_DATA, $iv);
        return $decrypted === false ? '' : $decrypted;
    }
}

// Колонка is_encrypted могла ещё не создаться, если index.php на этой базе не открывали.
$posts_col_check = $conn->query("SHOW COLUMNS FROM posts LIKE 'is_encrypted'");
if ($posts_col_check && $posts_col_check->num_rows === 0) {
    $conn->query("ALTER TABLE posts ADD COLUMN is_encrypted TINYINT(1) NOT NULL DEFAULT 0 AFTER content");
}

// ============================================================
// ТОКЕНЫ (CSRF). Два отдельных токена, чтобы они не пересекались:
//  • csrf_news  — действия самой ленты (пост, лайк, репост, комментарий, удаление);
//  • csrf_token — общий токен сессии, он нужен только окну «Поделиться» (messages.php).
// Токен ленты не уходит в messages.php, а токен сообщений не принимается лентой.
// ============================================================
if (empty($_SESSION['csrf_news'])) {
    $_SESSION['csrf_news'] = bin2hex(random_bytes(32));
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token       = (string)$_SESSION['csrf_news'];
$share_csrf_token = (string)$_SESSION['csrf_token'];

// ===== ОБРАБОТКА ДОБАВЛЕНИЯ ПОСТА =====
$error = "";
$success = "";
$warning = "";

// Сообщение об ошибке, оставленное перед редиректом (например, при удалении комментария)
if (!empty($_SESSION['news_flash_error'])) {
    $error = (string)$_SESSION['news_flash_error'];
    unset($_SESSION['news_flash_error']);
}

// Если файл больше post_max_size, PHP молча обнуляет $_POST и $_FILES — сообщим об этом
if ($_SERVER["REQUEST_METHOD"] === "POST" && empty($_POST) && empty($_FILES)
    && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    $error = "Файл слишком большой: сервер принимает не больше " . ini_get('post_max_size') . " за одну отправку.";
    if (newsIsAjax()) {
        newsJson(['success' => false, 'error' => 'too_large', 'message' => $error], 413);
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_post"])) {
    $content = trim($_POST["content"] ?? "");
    $image_path = "";

    if (!hash_equals($csrf_token, (string)($_POST['csrf_token'] ?? ''))) {
        $error = "Сессия устарела. Обновите страницу и попробуйте снова.";
    } elseif ($content === "" && !(isset($_FILES["post_image"]) && $_FILES["post_image"]["error"] !== UPLOAD_ERR_NO_FILE)) {
        $error = "Напишите текст или прикрепите файл.";
    } else {
        $media_error = '';
        if (isset($_FILES["post_image"]) && $_FILES["post_image"]["error"] === UPLOAD_ERR_OK) {
            $file = $_FILES["post_image"];
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_file($finfo, $file["tmp_name"]) : false;
            if ($finfo) {
                finfo_close($finfo);
            }
            $mime = is_string($mime) ? strtolower($mime) : '';
            $orig_name = (string)($file["name"] ?? '');
            $orig_ext  = strtolower(pathinfo($orig_name, PATHINFO_EXTENSION));
            $media     = newsDetectUpload($mime, $orig_ext);
            $upload_dir = "uploads/posts/";

            if (!is_dir($upload_dir) && !@mkdir($upload_dir, 0777, true) && !is_dir($upload_dir)) {
                $media_error = "Не удалось создать папку " . $upload_dir . " (проверьте права на запись).";
            }

            if ($media_error !== '') {
                // папку создать не удалось — причина уже записана
            } elseif ($media === null) {
                $media_error = "Формат файла не поддерживается (фото, видео, музыка или документ: PDF, DOC, XLS, ZIP и т. п.).";
            } elseif ($file["size"] > $media['max']) {
                $media_error = "Файл слишком большой: " . $media['limit'] . ".";
            } else {
                $label = in_array($media['kind'], ['audio', 'file'], true) ? newsSafeLabel(pathinfo($orig_name, PATHINFO_FILENAME)) : '';
                $new_name = "post_" . time() . "_" . $user_id . "_" . bin2hex(random_bytes(6)) . ($label !== '' ? "__" . $label : "") . "." . $media['ext'];
                $target = $upload_dir . $new_name;
                if (move_uploaded_file($file["tmp_name"], $target)) {
                    $image_path = $target;
                } else {
                    $media_error = "Не удалось сохранить файл на сервере (проверьте права на папку " . $upload_dir . ").";
                }
            }
        } elseif (isset($_FILES["post_image"]) && $_FILES["post_image"]["error"] !== UPLOAD_ERR_NO_FILE) {
            // например, файл больше upload_max_filesize из php.ini
            $media_error = newsUploadErrorText((int)$_FILES["post_image"]["error"]);
        }

        if ($content === "" && $image_path === "") {
            $error = $media_error !== '' ? $media_error : "Напишите текст или прикрепите файл.";
        } else {
        $stored_content = $content === "" ? "" : encryptPostContent($content);
        $is_encrypted = 1;
        if ($stored_content === '' && $content !== '') {
            // Шифрование не удалось — не теряем пост, храним как есть.
            error_log('news.php: не удалось зашифровать пост, сохранён без шифрования');
            $stored_content = $content;
            $is_encrypted = 0;
        }
        if ($content === "") { $is_encrypted = 0; }

        $stmt = $conn->prepare("INSERT INTO posts (user_id, content, image, is_encrypted, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("issi", $user_id, $stored_content, $image_path, $is_encrypted);

        if ($stmt->execute()) {
            if ($media_error !== '') {
                $warning = "Запись опубликована, но файл не загрузился. " . $media_error;
            } else {
                $success = "✅ Запись опубликована!";
            }
        } else {
            $error = "Не удалось опубликовать запись: " . $stmt->error;
        }
        $stmt->close();
        }
    }
}

// ============================================================
// ЛАЙКИ / РЕАКЦИИ / «ПОДЕЛИТЬСЯ» / КОММЕНТАРИИ — та же логика, что в index.php
// ============================================================
$reaction_emojis = ['laugh' => '😆', 'wow' => '😲', 'love' => '😍', 'sad' => '😢', 'angry' => '😡'];
$svg_comment_smile = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9.2"/><path d="M8.3 14.2c.9 1.3 2.1 2 3.7 2s2.8-.7 3.7-2"/><circle cx="9" cy="9.7" r=".6" fill="currentColor"/><circle cx="15" cy="9.7" r=".6" fill="currentColor"/></svg>';
$svg_comment_send  = '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M3.4 20.4 20.85 12.92a1 1 0 0 0 0-1.84L3.4 3.6a1 1 0 0 0-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91z"/></svg>';

// Таблицы создаёт index.php, но если его на этой базе ещё не открывали — создадим здесь.
$conn->query("
    CREATE TABLE IF NOT EXISTS post_likes (
        id INT(11) NOT NULL AUTO_INCREMENT,
        post_id INT(11) NOT NULL,
        user_id INT(11) NOT NULL,
        reaction VARCHAR(16) NOT NULL DEFAULT 'like',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_like (post_id, user_id),
        INDEX post_id (post_id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    CREATE TABLE IF NOT EXISTS post_comments (
        id INT(11) NOT NULL AUTO_INCREMENT,
        post_id INT(11) NOT NULL,
        user_id INT(11) NOT NULL,
        comment TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX post_id (post_id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$conn->query("
    CREATE TABLE IF NOT EXISTS post_reposts (
        id INT(11) NOT NULL AUTO_INCREMENT,
        post_id INT(11) NOT NULL,
        user_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_repost (post_id, user_id),
        INDEX post_id (post_id),
        INDEX user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
$reaction_col = $conn->query("SHOW COLUMNS FROM post_likes LIKE 'reaction'");
if ($reaction_col && $reaction_col->num_rows === 0) {
    $conn->query("ALTER TABLE post_likes ADD COLUMN reaction VARCHAR(16) NOT NULL DEFAULT 'like' AFTER user_id");
}

if (!function_exists('addNotification')) {
    function addNotification(mysqli $conn, int $user_id, string $type, string $message, ?string $link = null, ?int $sender_id = null): bool {
        $sender_avatar = null;
        if ($sender_id) {
            $stmt = $conn->prepare("SELECT avatar FROM users WHERE id = ?");
            $stmt->bind_param("i", $sender_id);
            $stmt->execute();
            if ($row = $stmt->get_result()->fetch_assoc()) {
                $sender_avatar = $row['avatar'];
            }
            $stmt->close();
        }
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, sender_id, sender_avatar, type, message, link, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("iissss", $user_id, $sender_id, $sender_avatar, $type, $message, $link);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }
}

$my_username = (string)($current_user_data['username'] ?? 'Пользователь');

// --- Кто и как отреагировал на пост (окно реакций при наведении на лайк) ---
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["post_reactions"])) {
    $react_post_id = (int)$_GET["post_reactions"];
    $out = ['total' => newsCount($conn, 'post_likes', $react_post_id), 'users' => []];

    $stmt = $conn->prepare("
        SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, l.reaction
        FROM post_likes l
        INNER JOIN users u ON u.id = l.user_id
        LEFT JOIN user_profiles up ON up.user_id = u.id
        WHERE l.post_id = ?
        ORDER BY l.id DESC
        LIMIT 3
    ");
    $stmt->bind_param("i", $react_post_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) {
        $avatar = (string)($r['avatar'] ?? '');
        $out['users'][] = [
            'id'       => (int)$r['id'],
            'username' => (string)$r['username'],
            'avatar'   => ($avatar !== '' && file_exists($avatar)) ? $avatar : '',
            'reaction' => (string)$r['reaction'],
        ];
    }
    $stmt->close();
    newsJson($out);
}

// --- Удаление комментария (ссылка с токеном) ---
if (isset($_GET["delete_comment"]) && is_numeric($_GET["delete_comment"])) {
    $comment_id = (int)$_GET["delete_comment"];
    if (!hash_equals($csrf_token, (string)($_GET['token'] ?? ''))) {
        newsReject('csrf', 'Сессия устарела. Обновите страницу и повторите удаление.', 403);
    }

    $stmt = $conn->prepare("SELECT user_id FROM post_comments WHERE id = ?");
    $stmt->bind_param("i", $comment_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        newsReject('not_found', 'Комментарий уже удалён.', 404);
    }
    if ((int)$row['user_id'] !== $user_id && !$is_admin) {
        newsReject('forbidden', 'Нельзя удалить чужой комментарий.', 403);
    }

    $stmt = $conn->prepare("DELETE FROM post_comments WHERE id = ?");
    $stmt->bind_param("i", $comment_id);
    $stmt->execute();
    $stmt->close();

    header("Location: news.php");
    exit;
}

// --- POST-действия: лайк / репост / комментарий ---
$is_post_action = $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["post_id"])
    && (isset($_POST["toggle_like"]) || isset($_POST["toggle_repost"]) || isset($_POST["add_comment"]));

if ($is_post_action) {
    if (!hash_equals($csrf_token, (string)($_POST['csrf_token'] ?? ''))) {
        newsReject('csrf', 'Сессия устарела. Обновите страницу и повторите действие.', 403);
    }

    $post_id = (int)$_POST["post_id"];

    $stmt = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $post_row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$post_row) {
        newsReject('not_found', 'Пост не найден — возможно, его уже удалили.', 404);
    }
    $post_owner_id = (int)$post_row['user_id'];

    // ----- Лайк / реакция -----
    if (isset($_POST["toggle_like"])) {
        $allowed_reactions = ['like', 'laugh', 'wow', 'love', 'sad', 'angry'];
        $reaction = (string)($_POST["reaction"] ?? "");
        if (!in_array($reaction, $allowed_reactions, true)) {
            $reaction = "";
        }

        $stmt = $conn->prepare("SELECT id, reaction FROM post_likes WHERE post_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $post_id, $user_id);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $final_reaction = '';
        if ($exists && $reaction !== "" && $reaction !== $exists["reaction"]) {
            // выбрали другую реакцию — меняем её, число реакций не меняется
            $stmt = $conn->prepare("UPDATE post_likes SET reaction = ? WHERE id = ?");
            $exists_id = (int)$exists["id"];
            $stmt->bind_param("si", $reaction, $exists_id);
            $stmt->execute();
            $stmt->close();
            $final_reaction = $reaction;
        } elseif ($exists) {
            $stmt = $conn->prepare("DELETE FROM post_likes WHERE post_id = ? AND user_id = ?");
            $stmt->bind_param("ii", $post_id, $user_id);
            $stmt->execute();
            $stmt->close();
        } else {
            $new_reaction = $reaction !== "" ? $reaction : "like";
            $stmt = $conn->prepare("INSERT INTO post_likes (post_id, user_id, reaction, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->bind_param("iis", $post_id, $user_id, $new_reaction);
            $stmt->execute();
            $stmt->close();
            $final_reaction = $new_reaction;

            if ($post_owner_id !== $user_id) {
                addNotification($conn, $post_owner_id, 'like',
                    $my_username . ($new_reaction === 'like' ? ' поставил(а) лайк на ваш пост' : ' отреагировал(а) на ваш пост'),
                    'index.php?user=' . $user_id,
                    $user_id
                );
            }
        }

        newsFinish(['reaction' => $final_reaction, 'count' => newsCount($conn, 'post_likes', $post_id)]);
    }

    // ----- «Поделиться» (репост) -----
    if (isset($_POST["toggle_repost"])) {
        $stmt = $conn->prepare("SELECT id FROM post_reposts WHERE post_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $post_id, $user_id);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($exists) {
            $stmt = $conn->prepare("DELETE FROM post_reposts WHERE post_id = ? AND user_id = ?");
            $stmt->bind_param("ii", $post_id, $user_id);
            $stmt->execute();
            $stmt->close();
            $reposted = false;
        } else {
            $stmt = $conn->prepare("INSERT INTO post_reposts (post_id, user_id, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $post_id, $user_id);
            $stmt->execute();
            $stmt->close();
            $reposted = true;

            if ($post_owner_id !== $user_id) {
                addNotification($conn, $post_owner_id, 'repost',
                    $my_username . ' репостнул(а) ваш пост',
                    'index.php?user=' . $user_id,
                    $user_id
                );
            }
        }

        newsFinish(['reposted' => $reposted, 'count' => newsCount($conn, 'post_reposts', $post_id)]);
    }

    // ----- Комментарий -----
    if (isset($_POST["add_comment"])) {
        $comment = trim((string)($_POST["comment"] ?? ""));
        $comment = mb_substr($comment, 0, 2000, 'UTF-8');
        $new_comment_html = '';

        if ($comment === "") {
            newsReject('empty', 'Напишите текст комментария.', 422);
        }

        if ($comment !== "") {
            $stmt = $conn->prepare("INSERT INTO post_comments (post_id, user_id, comment, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->bind_param("iis", $post_id, $user_id, $comment);
            $stmt->execute();
            $new_comment_id = (int)$conn->insert_id;
            $stmt->close();

            if ($post_owner_id !== $user_id) {
                addNotification($conn, $post_owner_id, 'comment',
                    $my_username . ' прокомментировал(а) ваш пост: "' . mb_substr($comment, 0, 50, 'UTF-8') . '"',
                    'index.php?user=' . $user_id,
                    $user_id
                );
            }

            // Готовый блок комментария — JS вставит его в ленту без перезагрузки страницы
            $stmt = $conn->prepare("
                SELECT c.id, c.comment, c.created_at, u.id AS user_id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar
                FROM post_comments c
                INNER JOIN users u ON u.id = c.user_id
                LEFT JOIN user_profiles up ON up.user_id = u.id
                WHERE c.id = ?
            ");
            $stmt->bind_param("i", $new_comment_id);
            $stmt->execute();
            $new_row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($new_row) {
                $new_comment_html = renderNewsComment($new_row, $user_id, $is_admin, $csrf_token);
            }
        }

        newsFinish(['html' => $new_comment_html, 'count' => newsCount($conn, 'post_comments', $post_id)]);
    }
}

// ===== ПОЛУЧАЕМ ВСЕ ПОСТЫ =====
$posts = [];
$stmt = $conn->prepare("
    SELECT p.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) as author_name, u.avatar as author_avatar,
        (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) AS likes_count,
        (SELECT COUNT(*) FROM post_comments WHERE post_id = p.id) AS comments_count,
        (SELECT COUNT(*) FROM post_reposts WHERE post_id = p.id) AS reposts_count,
        (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id AND user_id = ?) AS user_liked,
        (SELECT COUNT(*) FROM post_reposts WHERE post_id = p.id AND user_id = ?) AS user_reposted
    FROM posts p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    ORDER BY p.created_at DESC
    LIMIT 100
");
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$posts_result = $stmt->get_result();
while ($row = $posts_result->fetch_assoc()) {
    if (!empty($row['is_encrypted']) && $row['content'] !== '') {
        $row['content'] = decryptPostContent((string)$row['content']);
    }
    $posts[] = $row;
}
$stmt->close();

// Какую реакцию поставил текущий пользователь + комментарии ко всем показанным постам (одним запросом)
$my_reactions = [];
$comments_by_post = [];
if (!empty($posts)) {
    $ids_sql = implode(',', array_map('intval', array_column($posts, 'id')));

    $res_my = $conn->query("SELECT post_id, reaction FROM post_likes WHERE user_id = " . (int)$user_id . " AND post_id IN ($ids_sql)");
    if ($res_my) {
        while ($r = $res_my->fetch_assoc()) {
            $my_reactions[(int)$r['post_id']] = (string)$r['reaction'];
        }
    }

    $res_comm = $conn->query("
        SELECT c.id, c.post_id, c.comment, c.created_at, u.id AS user_id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar
        FROM post_comments c
        INNER JOIN users u ON u.id = c.user_id
        LEFT JOIN user_profiles up ON up.user_id = u.id
        WHERE c.post_id IN ($ids_sql)
        ORDER BY c.created_at ASC, c.id ASC
    ");
    if ($res_comm) {
        while ($c = $res_comm->fetch_assoc()) {
            $pid = (int)$c['post_id'];
            if (!isset($comments_by_post[$pid])) $comments_by_post[$pid] = [];
            if (count($comments_by_post[$pid]) < 20) {
                $comments_by_post[$pid][] = $c;
            }
        }
    }
}

// ===== ПОЛУЧАЕМ ДРУЗЕЙ ДЛЯ ПРАВОЙ ПАНЕЛИ =====
$friends_list = [];
$stmt = $conn->prepare("
    SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, u.status, u.is_admin
    FROM friend_requests fr
    INNER JOIN users u ON (
        CASE
            WHEN fr.sender_id = ? THEN u.id = fr.receiver_id
            ELSE u.id = fr.sender_id
        END
    )
    LEFT JOIN user_profiles up ON up.user_id = u.id
    WHERE (fr.sender_id = ? OR fr.receiver_id = ?)
      AND fr.status = 'accepted'
      AND u.id != ?
    ORDER BY u.username ASC
    LIMIT 9
");
$stmt->bind_param("iiii", $user_id, $user_id, $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $friends_list[] = $row;
}
$stmt->close();

// Количество друзей
$friends_count = 0;
$stmt = $conn->prepare("
    SELECT COUNT(*) as count
    FROM friend_requests
    WHERE (sender_id = ? OR receiver_id = ?)
      AND status = 'accepted'
");
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$friends_count = $result->fetch_assoc()['count'] ?? 0;
$stmt->close();

function getAvatarLetter(?string $username) {
    return mb_strtoupper(mb_substr($username ?: "?", 0, 1, 'UTF-8'), 'UTF-8');
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function isOnline(?string $status) {
    return $status === 'online';
}

function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . 'м';
    if ($diff < 86400) return floor($diff / 3600) . 'ч';
    if ($diff < 604800) return floor($diff / 86400) . 'д';
    return date('d.m.Y', $timestamp);
}

function pluralRu(int $n, string $one, string $few, string $many): string {
    $n = abs($n) % 100;
    if ($n >= 11 && $n <= 19) return $many;
    $n = $n % 10;
    if ($n === 1) return $one;
    if ($n >= 2 && $n <= 4) return $few;
    return $many;
}

/**
 * Короткое время публикации для низа поста:
 * «только что», «1 мин», «3 часа», «вчера», «позавчера», «3 окт», «3 окт 2025».
 */
function timeShort($datetime): string {
    $ts = strtotime((string)$datetime);
    if (!$ts) return '';

    $now  = time();
    $diff = max(0, $now - $ts);

    if ($diff < 60)    return 'только что';
    if ($diff < 3600)  return floor($diff / 60) . ' мин';
    if ($diff < 86400) {
        $h = (int)floor($diff / 3600);
        return $h . ' ' . pluralRu($h, 'час', 'часа', 'часов');
    }

    // Дальше считаем календарные дни, а не 24-часовые отрезки
    $days = (int)round((strtotime(date('Y-m-d', $now)) - strtotime(date('Y-m-d', $ts))) / 86400);
    if ($days <= 1) return 'вчера';
    if ($days === 2) return 'позавчера';

    $months = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
    $label = (int)date('j', $ts) . ' ' . $months[(int)date('n', $ts) - 1];
    if (date('Y', $ts) !== date('Y', $now)) {
        $label .= ' ' . date('Y', $ts);
    }
    return $label;
}

// Ошибка действия: AJAX получает JSON с понятным текстом, обычный запрос — сообщение на странице после редиректа
function newsReject(string $code, string $message, int $http = 400): void {
    if (newsIsAjax()) {
        newsJson(['success' => false, 'error' => $code, 'message' => $message], $http);
    }
    $_SESSION['news_flash_error'] = $message;
    header('Location: news.php');
    exit;
}

function newsUploadErrorText(int $code): string {
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
            return 'Файл больше разрешённого сервером размера (upload_max_filesize = ' . ini_get('upload_max_filesize') . ').';
        case UPLOAD_ERR_FORM_SIZE:
            return 'Файл больше разрешённого размера.';
        case UPLOAD_ERR_PARTIAL:
            return 'Файл загрузился не полностью. Попробуйте ещё раз.';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'На сервере нет временной папки для загрузок.';
        case UPLOAD_ERR_CANT_WRITE:
            return 'Серверу не удалось записать файл на диск.';
        case UPLOAD_ERR_EXTENSION:
            return 'Загрузку остановило расширение PHP.';
        default:
            return 'Неизвестная ошибка загрузки (код ' . $code . ').';
    }
}

function newsIsVideo(string $path): bool {
    return in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), ['mp4', 'webm', 'mov', 'm4v', 'ogv'], true);
}

// Тип вложения по расширению: image | video | audio | file
function newsMediaKind(string $path): string {
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if (in_array($ext, ['mp4', 'webm', 'mov', 'm4v', 'ogv'], true)) return 'video';
    if (in_array($ext, ['mp3', 'ogg', 'oga', 'opus', 'wav', 'm4a', 'aac', 'flac', 'weba'], true)) return 'audio';
    if (in_array($ext, ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf', 'csv', 'odt', 'ods', 'odp', 'zip', 'rar', '7z'], true)) return 'file';
    return 'image';
}

// Что за файл загрузили и можно ли его принять. null — нельзя.
function newsDetectUpload(string $mime, string $ext): ?array {
    $mb = 1024 * 1024;
    $img = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $vid = ['video/mp4' => 'mp4', 'video/webm' => 'webm'];

    if (isset($img[$mime])) {
        return ['kind' => 'image', 'ext' => $img[$mime], 'max' => 5 * $mb, 'limit' => 'фото — до 5 МБ'];
    }
    $audio_ext = ['mp3', 'ogg', 'oga', 'opus', 'wav', 'm4a', 'aac', 'flac', 'weba'];
    if (in_array($ext, $audio_ext, true)
        && (strpos($mime, 'audio/') === 0 || in_array($mime, ['application/ogg', 'video/ogg', 'video/mp4', 'video/webm', 'application/octet-stream'], true))) {
        return ['kind' => 'audio', 'ext' => $ext, 'max' => 20 * $mb, 'limit' => 'музыка — до 20 МБ'];
    }
    if (isset($vid[$mime])) {
        return ['kind' => 'video', 'ext' => $vid[$mime], 'max' => 50 * $mb, 'limit' => 'видео — до 50 МБ'];
    }
    $file_ext = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf', 'csv', 'odt', 'ods', 'odp', 'zip', 'rar', '7z'];
    if (in_array($ext, $file_ext, true) && !preg_match('~php|html|x-sh|dosexec|executable|javascript~', $mime)) {
        return ['kind' => 'file', 'ext' => $ext, 'max' => 20 * $mb, 'limit' => 'файлы — до 20 МБ'];
    }
    return null;
}

// Безопасное имя для хранения (латиница), чтобы показывать название файла в ленте
function newsSafeLabel(string $name): string {
    $map = ['а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z','и'=>'i','й'=>'y','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya'];
    $name = strtr(mb_strtolower($name, 'UTF-8'), $map);
    $name = preg_replace('/[^a-z0-9]+/', '_', $name);
    $name = trim(preg_replace('/_+/', '_', (string)$name), '_');
    return substr($name, 0, 40);
}

// Название вложения для ленты (из имени файла на диске)
function newsAttachmentTitle(string $path, string $fallback): string {
    if (preg_match('/^post_\d+_\d+_[0-9a-f]{12}__(.+)\.[A-Za-z0-9]+$/', basename($path), $m)) {
        return str_replace('_', ' ', $m[1]);
    }
    return $fallback;
}

function newsHumanSize(int $bytes): string {
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 1, ',', '') . ' МБ';
    return max(1, (int)round($bytes / 1024)) . ' КБ';
}

function newsIsAjax(): bool {
    return strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest';
}

function newsJson(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// AJAX получает JSON, обычная отправка формы — возврат на ленту
function newsFinish(array $data): void {
    if (newsIsAjax()) {
        newsJson(['success' => true] + $data);
    }
    header('Location: news.php');
    exit;
}

function newsCount(mysqli $conn, string $table, int $post_id): int {
    if (!in_array($table, ['post_likes', 'post_comments', 'post_reposts'], true)) return 0;
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM `$table` WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $c = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();
    return $c;
}

function formatCommentText(string $comment): string {
    $formatted = htmlspecialchars($comment, ENT_QUOTES, 'UTF-8');
    $formatted = preg_replace_callback(
        '/[\x{1F1E6}-\x{1F1FF}][\x{1F1E6}-\x{1F1FF}]/u',
        static function (array $matches): string {
            $codepoints = [];
            foreach (preg_split('//u', $matches[0], -1, PREG_SPLIT_NO_EMPTY) as $symbol) {
                $codepoints[] = strtolower(dechex(mb_ord($symbol, 'UTF-8')));
            }
            $src = 'https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/svg/'
                . implode('-', $codepoints) . '.svg';
            return '<img class="comment-flag" src="' . $src . '" alt="' . $matches[0] . '">';
        },
        $formatted
    );
    return nl2br($formatted, false);
}

// Один комментарий (используется и в ленте, и в AJAX-ответе после отправки)
function renderNewsComment(array $c, int $viewer_id, bool $is_admin, string $csrf): string {
    $avatar = trim((string)($c['avatar'] ?? ''));
    $avatar_path = $avatar !== ''
        ? __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($avatar, '/'))
        : '';

    if ($avatar !== '' && is_file($avatar_path)) {
        $avatar_html = '<img src="' . htmlspecialchars(str_replace('\\', '/', $avatar), ENT_QUOTES, 'UTF-8') . '" alt="">';
    } else {
        $avatar_html = htmlspecialchars(getAvatarLetter($c['username'] ?? ''), ENT_QUOTES, 'UTF-8');
    }

    $uid  = (int)$c['user_id'];
    $name = htmlspecialchars((string)$c['username'], ENT_QUOTES, 'UTF-8');

    $html  = '<div class="comment-item" data-comment-id="' . (int)$c['id'] . '">';
    $html .= '<div class="comment-avatar">' . $avatar_html . '</div>';
    $html .= '<div class="comment-body">';
    $html .= '<a href="' . sprintf('%05d', (int)$uid) . '" class="comment-author">' . $name . '</a>';
    $html .= '<span class="comment-time">' . htmlspecialchars(timeShort($c['created_at']), ENT_QUOTES, 'UTF-8') . '</span>';
    $html .= '<div class="comment-text">' . formatCommentText((string)$c['comment']) . '</div>';
    $html .= '</div>';
    if ($uid === $viewer_id || $is_admin) {
        $html .= '<a href="news.php?delete_comment=' . (int)$c['id'] . '&amp;token=' . rawurlencode($csrf)
              . '" class="comment-delete" data-confirm="Удалить комментарий?">✕</a>';
    }
    $html .= '</div>';
    return $html;
}

$conn->close();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/index.css?v=share-dialog-v2">
    <title>Новости</title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <style>
        .header-left { display: flex; align-items: center; gap: 20px; }

        /* Стили для постов */
        .news-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }

        .news-card {
            background: var(--card-bg, #2b2d31);
            border-radius: 12px;
            padding: 24px 28px;
            margin-bottom: 20px;
            border: 1px solid var(--card-border, #3f4147);
        }

        /* ===== Иконка «Пост» (SVG вместо эмодзи) ===== */
        .title-ic {
            flex: 0 0 auto;
            width: 34px; height: 34px;
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 10px;
            background: rgba(88, 101, 242, .16);
            color: #7b87ff;
        }
        .empty-posts .icon svg { width: 56px; height: 56px; color: #7b87ff; opacity: .55; }
        [data-theme="light"] .title-ic { background: rgba(88, 101, 242, .12); color: #5865f2; }

        .news-card h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary, #f2f3f5);
            margin-bottom: 8px;
        }

        .post-form textarea {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid var(--card-border, #3f4147);
            border-radius: 6px;
            background: var(--input-bg, #1e1f22);
            color: var(--text-primary, #f2f3f5);
            font-size: 14px;
            outline: none;
            transition: border-color 0.2s;
            font-family: inherit;
            resize: vertical;
            min-height: 80px;
        }

        .post-form textarea:focus {
            border-color: #5865f2;
        }

        .post-form .post-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
            flex-wrap: wrap;
            gap: 8px;
        }

        .file-label {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 14px;
            background: var(--input-bg, #1e1f22);
            border-radius: 6px;
            color: var(--text-secondary, #b5bac1);
            cursor: pointer;
            font-size: 13px;
            transition: 0.15s;
            border: 1px solid var(--card-border, #3f4147);
        }

        .file-label:hover {
            background: var(--card-border, #3f4147);
            color: var(--text-primary, #f2f3f5);
        }

        .file-label input[type="file"] {
            display: none;
        }

        .btn-post {
            padding: 8px 20px;
            background: #5865f2;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: 0.15s;
        }

        .btn-post:hover {
            background: #4752c4;
        }

        .post-item {
            padding: 16px 0;
            border-bottom: 1px solid var(--card-border, #3f4147);
        }

        .post-item:last-child {
            border-bottom: none;
        }

        .post-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }

        .post-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--bg-avatar, #5865f2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 600;
            font-size: 16px;
            overflow: hidden;
            flex-shrink: 0;
        }

        .post-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .post-author {
            font-weight: 600;
            color: var(--text-primary, #f2f3f5);
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
        }

        .post-author:hover {
            color: #5865f2;
        }

        .post-time {
            color: var(--text-secondary, #b5bac1);
            font-size: 12px;
            margin-left: auto;
        }

        .post-content {
            color: var(--text-primary, #f2f3f5);
            font-size: 14px;
            line-height: 1.6;
            word-break: break-word;
        }

        .post-image {
            margin-top: 10px;
            border-radius: 8px;
            overflow: hidden;
            max-width: 100%;
        }

        .post-image img {
            width: 100%;
            max-height: 400px;
            object-fit: cover;
            border-radius: 8px;
        }

        .empty-posts {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-secondary, #b5bac1);
        }

        .empty-posts .icon {
            font-size: 48px;
            margin-bottom: 12px;
        }

        .empty-posts h3 {
            color: var(--text-primary, #f2f3f5);
            margin-bottom: 6px;
        }

        .error-message {
            padding: 12px 16px;
            border-radius: 6px;
            background: rgba(242, 63, 66, 0.12);
            border: 1px solid rgba(242, 63, 66, 0.3);
            color: #f23f42;
            font-size: 14px;
            margin-bottom: 16px;
        }

        .success-message {
            padding: 12px 16px;
            border-radius: 6px;
            background: rgba(35, 165, 89, 0.12);
            border: 1px solid rgba(35, 165, 89, 0.3);
            color: #23a559;
            font-size: 14px;
            margin-bottom: 16px;
        }

        [data-theme="light"] .news-card {
            background: #ffffff;
            border-color: #e0e0e0;
        }

        [data-theme="light"] .post-form textarea {
            background: #f5f5f5;
            border-color: #d0d0d0;
            color: #2d2d2d;
        }

        [data-theme="light"] .file-label {
            background: #f5f5f5;
            border-color: #d0d0d0;
            color: #555;
        }

        /* ===== Форма «Создать запись» ===== */
        .pc-box { padding: 0; }
        .pc-form .pc-box textarea {
            display: block;
            width: 100%;
            box-sizing: border-box;
            height: 104px;
            min-height: 104px;
            resize: vertical;               /* как в index.php: сам не растёт, только вручную */
            padding: 14px 16px;
            font: inherit;
            font-size: 15px;
            line-height: 1.55;
            color: inherit;
            background: rgba(128, 132, 150, .07);
            border: 1px solid rgba(128, 132, 150, .28);
            border-radius: 14px;
            box-shadow: none;
            transition: border-color .2s ease, box-shadow .2s ease, background .2s ease;
        }
        .pc-form .pc-box textarea::placeholder { color: inherit; opacity: .5; }
        .pc-form .pc-box textarea:hover { border-color: rgba(128, 132, 150, .45); }
        .pc-form .pc-box textarea:focus {
            outline: none;
            border-color: #5865f2;
            background: rgba(88, 101, 242, .06);
            box-shadow: 0 0 0 3px rgba(88, 101, 242, .25);
        }

        .pc-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-top: 6px;
            flex-wrap: wrap;
        }
        .pc-tools { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; min-width: 0; }

        /* Кнопка «+» с раскрывающимся меню — оформление как в index.php:
           скруглённые квадраты 40×40, серая база, акцент #5865f2, подсказки над значками.
           Открывается по наведению (на устройствах с мышью) и по клику/тапу. */
        .pc-tools { position: relative; display: inline-flex; align-items: center; flex-wrap: nowrap; min-width: 0; }
        .pc-plus {
            flex: 0 0 auto;
            display: grid; place-items: center; width: 40px; height: 40px; padding: 0;
            color: var(--text-secondary, #b5bac1); cursor: pointer;
            background: rgba(128, 132, 150, .12);
            border: 1px solid rgba(128, 132, 150, .28);
            border-radius: 10px;
            transition: background .2s ease, border-color .2s ease, color .2s ease, box-shadow .2s ease, transform .15s ease;
        }
        .pc-plus svg { transition: transform .3s cubic-bezier(.34, 1.56, .64, 1); }
        .pc-plus[aria-expanded="true"] {
            color: #fff; background: #5865f2; border-color: #5865f2;
            box-shadow: 0 4px 14px rgba(88, 101, 242, .38);
        }
        .pc-plus[aria-expanded="true"] svg { transform: rotate(135deg); }
        .pc-plus:focus-visible, .pc-opt:focus-visible, .pc-chip-x:focus-visible { outline: 2px solid #8b95ff; outline-offset: 2px; }

        .pc-menu {
            position: absolute; left: 100%; top: 50%; z-index: 20;
            display: flex; align-items: center; gap: 8px; flex-wrap: nowrap;
            padding-left: 10px;            /* «мостик», чтобы наведение не пропадало между кнопками */
            transform: translateY(-50%);
            visibility: hidden; pointer-events: none;
        }
        .pc-menu.is-open { visibility: visible; pointer-events: auto; }

        .pc-opt {
            position: relative; display: grid; place-items: center;
            width: 40px; height: 40px; padding: 0; margin: 0; cursor: pointer;
            color: var(--text-secondary, #b5bac1);
            background: rgba(128, 132, 150, .12);
            border: 1px solid rgba(128, 132, 150, .28); border-radius: 10px;
            opacity: 0; transform: translateX(-12px) scale(.6);
            transition: opacity .2s ease, transform .3s cubic-bezier(.34, 1.56, .64, 1), background .2s ease, border-color .2s ease, color .2s ease;
            transition-delay: calc(var(--i) * 45ms);
        }
        .pc-menu.is-open .pc-opt { opacity: 1; transform: none; }

        /* раскрытие по наведению — только там, где есть мышь (на тачскрине «залипало» бы) */
        @media (hover: hover) {
            .pc-tools:hover .pc-plus { color: #fff; background: #5865f2; border-color: #5865f2; box-shadow: 0 4px 14px rgba(88, 101, 242, .38); }
            .pc-tools:hover .pc-plus svg { transform: rotate(135deg); }
            .pc-tools:hover .pc-menu { visibility: visible; pointer-events: auto; }
            .pc-tools:hover .pc-opt { opacity: 1; transform: none; }
        }

        .pc-menu .pc-opt:hover {
            color: #8b95ff; background: rgba(88, 101, 242, .16); border-color: rgba(88, 101, 242, .55);
            transform: translateY(-1px); transition-delay: 0s;
        }
        .pc-opt::after {
            content: attr(data-label);
            position: absolute; bottom: calc(100% + 8px); left: 50%;
            transform: translateX(-50%) translateY(4px);
            padding: 4px 9px; white-space: nowrap; font-size: 12px; font-weight: 500; color: #fff;
            background: rgba(20, 21, 24, .92); border-radius: 7px;
            opacity: 0; pointer-events: none; transition: opacity .15s ease, transform .15s ease;
        }
        .pc-opt:hover::after { opacity: 1; transform: translateX(-50%); }

        /* Превью вложения */
        .pc-preview { margin-top: 8px; }
        .pc-chip {
            display: flex; align-items: center; gap: 12px;
            padding: 8px 10px 8px 8px;
            border: 1px solid var(--card-border, #3f4147);
            border-radius: 12px;
            background: var(--card-bg, #2b2d31);
            animation: pc-pop .3s cubic-bezier(.34, 1.56, .64, 1);
        }
        @keyframes pc-pop { from { opacity: 0; transform: translateY(6px) scale(.97); } to { opacity: 1; transform: none; } }
        .pc-thumb {
            position: relative; flex: 0 0 auto;
            width: 56px; height: 56px; border-radius: 10px; overflow: hidden;
            display: flex; align-items: center; justify-content: center;
            color: #fff;
        }
        .pc-thumb img, .pc-thumb video { width: 100%; height: 100%; object-fit: cover; display: block; }
        .pc-thumb.k-audio { background: #a35cf2; }
        .pc-thumb.k-file { background: #e8912d; }
        .pc-thumb.k-video::after {
            content: ""; position: absolute; left: 50%; top: 50%; width: 22px; height: 22px; margin: -11px 0 0 -11px;
            border-radius: 50%; background: rgba(0, 0, 0, .55) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23fff'%3E%3Cpath d='M9 7l9 5-9 5z'/%3E%3C/svg%3E") center / 14px no-repeat;
        }
        .pc-chip-info { flex: 1 1 auto; min-width: 0; }
        .pc-chip-name { font-size: 14px; font-weight: 600; color: var(--text-primary, #f2f3f5); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .pc-chip-meta { font-size: 12px; color: var(--text-secondary, #b5bac1); margin-top: 2px; }
        .pc-chip-x {
            flex: 0 0 auto; width: 30px; height: 30px; border: none; border-radius: 50%;
            background: transparent; color: var(--text-secondary, #b5bac1);
            display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
            transition: background .15s, color .15s;
        }
        .pc-chip-x:hover { background: rgba(237, 66, 69, .15); color: #ed4245; }

        .pc-error {
            margin-top: 8px; padding: 8px 12px; border-radius: 10px; font-size: 13px;
            background: rgba(237, 66, 69, .12); border: 1px solid rgba(237, 66, 69, .3); color: #ed4245;
        }

        /* Эмодзи */
        .pc-emoji {
            margin-top: 8px; padding: 8px;
            display: grid; grid-template-columns: repeat(auto-fill, minmax(38px, 1fr)); gap: 2px;
            max-height: 176px; overflow-y: auto;
            border: 1px solid var(--card-border, #3f4147);
            border-radius: 12px; background: var(--card-bg, #2b2d31);
            animation: pc-pop .25s ease;
        }
        .pc-emoji[hidden], .pc-preview[hidden], .pc-error[hidden] { display: none; }
        .pc-emoji button {
            height: 38px; border: none; border-radius: 8px; background: transparent;
            font-size: 22px; line-height: 1; cursor: pointer;
            transition: background .12s, transform .12s;
        }
        .pc-emoji button:hover { background: var(--card-border, #3f4147); transform: scale(1.18); }

        /* Кнопка «Опубликовать» */
        .pc-form .btn-post {
            margin-left: auto;
            padding: 10px 24px;
            border-radius: 999px;
            background: linear-gradient(135deg, #5865f2, #6d79f7);
            box-shadow: 0 4px 12px rgba(88, 101, 242, .35);
            transition: transform .15s, box-shadow .15s, filter .15s;
        }
        .pc-form .btn-post:hover { background: linear-gradient(135deg, #5865f2, #6d79f7); filter: brightness(1.08); box-shadow: 0 6px 16px rgba(88, 101, 242, .5); transform: translateY(-1px); }
        .pc-form .btn-post:active { transform: scale(.97); }
        .pc-form .btn-post.is-sending { opacity: .7; cursor: progress; }

        /* ===== Вложения в ленте: музыка и файлы ===== */
        .post-attach {
            display: flex; align-items: center; gap: 12px;
            margin-top: 10px; padding: 10px 12px;
            border: 1px solid var(--card-border, #3f4147);
            border-radius: 14px;
            background: var(--input-bg, #1e1f22);
            color: inherit; text-decoration: none;
            max-width: 520px;
        }
        a.post-file { transition: background .15s, border-color .15s; }
        a.post-file:hover { border-color: #5865f2; background: rgba(88, 101, 242, .08); }
        .post-attach-ic {
            flex: 0 0 auto; width: 46px; height: 46px; border-radius: 12px; color: #fff;
            display: flex; align-items: center; justify-content: center;
        }
        .post-audio .post-attach-ic { background: linear-gradient(135deg, #a35cf2, #d16bff); }
        .post-file .post-attach-ic { background: linear-gradient(135deg, #e8912d, #f5b350); }
        .post-attach-main { flex: 1 1 auto; min-width: 0; }
        .post-attach-title { font-size: 14px; font-weight: 600; color: var(--text-primary, #f2f3f5); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .post-attach-meta { font-size: 12px; color: var(--text-secondary, #b5bac1); margin-top: 2px; }
        .post-audio audio { width: 100%; height: 34px; margin-top: 6px; display: block; }
        .post-attach-dl { flex: 0 0 auto; color: var(--text-secondary, #b5bac1); }
        a.post-file:hover .post-attach-dl { color: #5865f2; }

        [data-theme="light"] .pc-chip, [data-theme="light"] .pc-emoji { background: #fff; border-color: #d9d9d9; color: #2d2d2d; }
        [data-theme="light"] .pc-emoji button:hover { background: #eceef1; }
        [data-theme="light"] .pc-chip-name, [data-theme="light"] .post-attach-title { color: #2d2d2d; }
        [data-theme="light"] .post-attach { background: #f5f5f5; border-color: #d9d9d9; }

        @media (max-width: 520px) {
            .pc-opt { width: 38px; height: 38px; }
            .pc-form .btn-post { padding: 10px 20px; }
        }
        @media (prefers-reduced-motion: reduce) {
            .pc-plus, .pc-opt, .pc-chip, .pc-emoji { transition: none; animation: none; }
        }

        /* ===== Ширина страницы — как у панели навигации (90% окна, до 1200px), края карточек по краям панели ===== */
        @media (min-width: 861px) {
            body[data-nav-pos="top"] .layout,
            body[data-nav-pos="bottom"] .layout { width: min(90%, 1200px); max-width: 1200px; padding-left: 0; padding-right: 0; }
        }
        @media (min-width: 601px) and (max-width: 860px) {
            body[data-nav-pos="top"] .layout,
            body[data-nav-pos="bottom"] .layout { width: calc(100% - 24px); max-width: 1200px; padding-left: 0; padding-right: 0; }
        }
        @media (min-width: 601px) {
            body[data-nav-pos="top"] .news-container,
            body[data-nav-pos="bottom"] .news-container { max-width: none; padding-left: 0; padding-right: 0; }
        }

        /* ===== Телефон: форма «Создать запись» ===== */
        @media (max-width: 600px) {
            /* убираем двойные отступы (контейнер 20px + карточка 28px), из-за них поле ввода было узким */
            .news-container { padding: 0 !important; }
            .news-card { padding: 16px !important; border-radius: 16px; margin-bottom: 14px; }
            .news-card h2 { font-size: 18px; }

            /* 16px — чтобы iOS не приближал страницу при фокусе в поле */
            .pc-form .pc-box textarea { height: 96px; min-height: 96px; font-size: 16px; padding: 12px 14px; }

            /* «+» и «Опубликовать» в одну строку; меню вложений — отдельной строкой и только когда открыто */
            .pc-bar { gap: 8px; margin-top: 10px; }
            .pc-tools { display: contents; }
            .pc-plus { order: 1; }
            .pc-form .btn-post { order: 2; flex: 1 1 auto; margin-left: 0; text-align: center; }
            .pc-menu { order: 3; flex: 1 1 100%; position: static; transform: none; padding-left: 0; }
            .pc-menu:not(.is-open) { display: none; }
        }

        /* Телефон: колокольчик в углу (42px сверху + 6px отступ) не должен заходить на карточку —
           «Создать запись» начинается на 10px ниже колокольчика */
        @media (max-width: 640px) {
            main .news-container { padding-top: calc(36px + env(safe-area-inset-top, 0px)) !important; }
        }
    </style>
    <link rel="stylesheet" href="assets/css/news.css">
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= $theme ?>">

    <!-- ===== ШАПКА (как в index.php) ===== -->
    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <!-- ===== ОСНОВНОЙ КОНТЕЙНЕР ===== -->
    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <!-- ===== ОСНОВНОЙ КОНТЕНТ ===== -->
        <main>

            <div class="news-container">

                <!-- ===== ФОРМА ДОБАВЛЕНИЯ ЗАПИСИ ===== -->
                <div class="news-card" data-mobile-friends-anchor>
                    <h2><span class="title-ic"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="15" height="16" rx="2.5"/><path d="M18 9h1.5a1.5 1.5 0 0 1 1.5 1.5V18a2 2 0 0 1-2 2"/><path d="M7 8.5h7M7 12h7M7 15.5h4"/></svg></span>Создать запись</h2>
                    
                    <?php if ($error): ?>
                        <div class="error-message"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
                    <?php endif; ?>
                    
                    <?php if ($warning): ?>
                        <div class="warning-message"><?= htmlspecialchars($warning, ENT_QUOTES, "UTF-8") ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="success-message"><?= htmlspecialchars($success, ENT_QUOTES, "UTF-8") ?></div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data" class="post-form pc-form" id="pcForm" novalidate>
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="add_post" value="1">
                        <div class="pc-box">
                            <textarea name="content" id="pcText" rows="3" placeholder="Что у вас нового?"></textarea>

                            <!-- Превью вложения: пока не нажата «Опубликовать», ничего не отправляется -->
                            <div class="pc-preview" id="pcPreview" hidden></div>
                            <div class="pc-error" id="pcError" role="alert" hidden></div>

                            <div class="pc-bar">
                                <div class="pc-tools">
                                    <button type="button" class="pc-plus" id="pcPlus" aria-expanded="false" aria-haspopup="true" aria-controls="pcMenu" aria-label="Добавить к записи">
                                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                                    </button>
                                    <div class="pc-menu" id="pcMenu" role="menu">
                                        <button type="button" class="pc-opt pc-o-image" style="--i:0;" data-kind="image" data-label="Фото" aria-label="Фото" role="menuitem">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5-8 9"/></svg>
                                        </button>
                                        <button type="button" class="pc-opt pc-o-video" style="--i:1;" data-kind="video" data-label="Видео" aria-label="Видео" role="menuitem">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="6" width="13" height="12" rx="3"/><path d="M16 10.5l5-3v9l-5-3z"/></svg>
                                        </button>
                                        <button type="button" class="pc-opt pc-o-audio" style="--i:2;" data-kind="audio" data-label="Музыка" aria-label="Музыка" role="menuitem">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></svg>
                                        </button>
                                        <button type="button" class="pc-opt pc-o-file" style="--i:3;" data-kind="file" data-label="Файл" aria-label="Файл" role="menuitem">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>
                                        </button>
                                        <button type="button" class="pc-opt pc-o-emoji" style="--i:4;" data-kind="emoji" data-label="Эмодзи" aria-label="Эмодзи" role="menuitem">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8.5 14.3c.9 1.2 2 1.8 3.5 1.8s2.6-.6 3.5-1.8"/><circle cx="9" cy="9.8" r=".5" fill="currentColor"/><circle cx="15" cy="9.8" r=".5" fill="currentColor"/></svg>
                                        </button>
                                    </div>
                                </div>
                                <button type="submit" class="btn-post" id="pcSubmit">Опубликовать</button>
                            </div>

                            <div class="pc-emoji" id="pcEmoji" hidden></div>
                            <input type="file" name="post_image" id="pcFile" hidden>
                        </div>
                    </form>
                </div>

                <!-- ===== ЛЕНТА НОВОСТЕЙ ===== -->
                <div class="news-card">
                    <h2><span class="title-ic"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="15" height="16" rx="2.5"/><path d="M18 9h1.5a1.5 1.5 0 0 1 1.5 1.5V18a2 2 0 0 1-2 2"/><path d="M7 8.5h7M7 12h7M7 15.5h4"/></svg></span>Лента новостей</h2>
                    
                    <?php if (empty($posts)): ?>
                        <div class="empty-posts">
                            <div class="icon"><svg viewBox="0 0 24 24" width="56" height="56" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="15" height="16" rx="2.5"/><path d="M18 9h1.5a1.5 1.5 0 0 1 1.5 1.5V18a2 2 0 0 1-2 2"/><path d="M7 8.5h7M7 12h7M7 15.5h4"/></svg></div>
                            <h3>Пока нет постов</h3>
                            <p>Опубликуйте первый пост!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($posts as $post):
                            $pid = (int)$post['id'];
                            $my_reaction = $my_reactions[$pid] ?? '';
                            $post_ts = (int)strtotime((string)$post['created_at']);
                            $post_is_recent = (time() - $post_ts) < 86400;
                        ?>
                            <div class="post-item" id="post-<?= $pid ?>" data-post-id="<?= $pid ?>">
                                <div class="post-header">
                                    <div class="post-avatar">
                                        <?php if (!empty($post['author_avatar']) && file_exists($post['author_avatar'])): ?>
                                            <img src="<?= htmlspecialchars($post['author_avatar'], ENT_QUOTES, "UTF-8") ?>" alt="">
                                        <?php else: ?>
                                            <?= getAvatarLetter($post['author_name'] ?? 'Аноним') ?>
                                        <?php endif; ?>
                                    </div>
                                    <a href="<?= sprintf('%05d', (int)$post['user_id']) ?>" class="post-author">
                                        <?= htmlspecialchars($post['author_name'] ?? 'Аноним', ENT_QUOTES, "UTF-8") ?>
                                    </a>
                                </div>
                                <?php if (trim((string)$post['content']) !== ''): ?>
                                <div class="post-content">
                                    <?= nl2br(htmlspecialchars($post['content'], ENT_QUOTES, "UTF-8")) ?>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($post['image']) && file_exists($post['image'])): ?>
                                    <?php $media_src = htmlspecialchars($post['image'], ENT_QUOTES, "UTF-8"); ?>
                                    <?php $att_kind = newsMediaKind($post['image']); ?>
                                    <?php if ($att_kind === 'audio'): ?>
                                        <div class="post-attach post-audio">
                                            <div class="post-attach-ic" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></svg></div>
                                            <div class="post-attach-main">
                                                <div class="post-attach-title"><?= htmlspecialchars(newsAttachmentTitle($post['image'], 'Музыка'), ENT_QUOTES, "UTF-8") ?></div>
                                                <audio controls preload="none" src="<?= $media_src ?>"></audio>
                                            </div>
                                        </div>
                                    <?php elseif ($att_kind === 'file'): ?>
                                        <a class="post-attach post-file" href="<?= $media_src ?>" download target="_blank" rel="noopener">
                                            <div class="post-attach-ic" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg></div>
                                            <div class="post-attach-main">
                                                <div class="post-attach-title"><?= htmlspecialchars(newsAttachmentTitle($post['image'], 'Файл'), ENT_QUOTES, "UTF-8") ?></div>
                                                <div class="post-attach-meta"><?= htmlspecialchars(strtoupper(pathinfo($post['image'], PATHINFO_EXTENSION)), ENT_QUOTES, "UTF-8") ?> · <?= newsHumanSize((int)@filesize($post['image'])) ?></div>
                                            </div>
                                            <div class="post-attach-dl" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11M7 11l5 5 5-5M5 20h14"/></svg></div>
                                        </a>
                                    <?php elseif (newsIsVideo($post['image'])): ?>
                                        <div class="post-image post-media post-video" role="button" tabindex="0" aria-label="Открыть видео"
                                             data-media-type="video" data-src="<?= $media_src ?>">
                                            <video src="<?= $media_src ?>#t=0.1" preload="metadata" muted playsinline></video>
                                            <span class="post-video-play" aria-hidden="true"></span>
                                        </div>
                                    <?php else: ?>
                                        <div class="post-image post-media" role="button" tabindex="0" aria-label="Открыть фото"
                                             data-media-type="image" data-src="<?= $media_src ?>">
                                            <img src="<?= $media_src ?>" alt="Изображение" loading="lazy">
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <!-- Лайк / комментарии / поделиться + время публикации -->
                                <div class="post-actions-bar">
                                    <form method="POST" action="news.php" class="ajax-like-form" style="display:inline;" data-post-id="<?= $pid ?>">
                                        <input type="hidden" name="post_id" value="<?= $pid ?>">
                                        <input type="hidden" name="toggle_like" value="1">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="submit" class="post-action-btn <?= $post['user_liked'] ? 'liked' : '' ?>" aria-label="Лайк"
                                                data-reaction="<?= htmlspecialchars($my_reaction, ENT_QUOTES, 'UTF-8') ?>">
                                            <span class="action-icon"><?php if (isset($reaction_emojis[$my_reaction])): ?><span class="reaction-emoji"><?= $reaction_emojis[$my_reaction] ?></span><?php else: ?><img class="like-heart" src="images/heart.svg" alt=""><?php endif; ?></span>
                                            <span class="action-count"><?= (int)$post['likes_count'] ?></span>
                                        </button>
                                    </form>

                                    <button type="button" class="post-action-btn toggle-comments" data-post-id="<?= $pid ?>" data-tooltip="Оставить комментарий">
                                        <span class="action-icon comment-action-icon" role="button" tabindex="0" aria-label="Открыть комментарии"><img class="chat-icon" src="images/chat.svg" alt=""></span>
                                        <span class="action-count"><?= (int)$post['comments_count'] ?></span>
                                    </button>

                                    <form method="POST" action="news.php" class="ajax-repost-form" style="display:inline;" data-post-id="<?= $pid ?>">
                                        <input type="hidden" name="post_id" value="<?= $pid ?>">
                                        <input type="hidden" name="toggle_repost" value="1">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="submit" class="post-action-btn <?= $post['user_reposted'] ? 'reposted' : '' ?>" aria-label="Поделиться" data-tooltip="Поделиться">
                                            <span class="action-icon"><img class="share-icon" src="images/share.svg" alt=""></span>
                                            <span class="action-count"><?= (int)$post['reposts_count'] ?></span>
                                        </button>
                                    </form>

                                    <time class="post-date"
                                          datetime="<?= date('c', $post_ts) ?>"
                                          title="<?= date('d.m.Y H:i', $post_ts) ?>"
                                          data-ts="<?= $post_ts ?>"
                                          <?= $post_is_recent ? 'data-rel="1"' : '' ?>><?= htmlspecialchars(timeShort($post['created_at']), ENT_QUOTES, 'UTF-8') ?></time>
                                </div>

                                <!-- Комментарии -->
                                <div class="comments-section" id="comments-<?= $pid ?>" style="display:none;">
                                    <?php foreach ($comments_by_post[$pid] ?? [] as $comment): ?>
                                        <?= renderNewsComment($comment, $user_id, $is_admin, $csrf_token) ?>
                                    <?php endforeach; ?>
                                    <form method="POST" action="news.php" class="comment-form ajax-comment-form" data-post-id="<?= $pid ?>">
                                        <input type="hidden" name="post_id" value="<?= $pid ?>">
                                        <input type="hidden" name="add_comment" value="1">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
                                        <div class="comment-field">
                                            <input type="text" name="comment" id="commentInput-<?= $pid ?>"
                                                   placeholder="Написать комментарий..." autocomplete="off" maxlength="2000" required>
                                            <button type="button" class="emoji-button comment-emoji-btn"
                                                    data-target="commentInput-<?= $pid ?>" aria-label="Эмодзи"><?= $svg_comment_smile ?></button>
                                        </div>
                                        <button type="submit" class="comment-send" aria-label="Отправить"><?= $svg_comment_send ?></button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            </div>

        </main>

        <!-- ===== ПРАВАЯ ПАНЕЛЬ ===== -->
        <aside class="right-sidebar">

            <div class="right-card">
                <a href="friends.php" style="text-decoration:none;color:inherit;display:block;">
                    <div class="right-title">
                        Друзья
                        <span style="font-size:13px;font-weight:400;color:var(--text-secondary);margin-left:auto;"><?= $friends_count ?></span>
                    </div>
                </a>

                <?php if (!empty($friends_list)): ?>
                    <div class="friends-avatar-grid">
                        <?php foreach ($friends_list as $friend): ?>
                            <a href="<?= sprintf('%05d', (int)$friend['id']) ?>" class="friend-avatar-card">

                                <div class="friend-avatar-big"
                                     data-presence-avatar="<?= (int)$friend['id'] ?>"
                                     data-presence-pending>
                                    <?php if (!empty($friend['avatar']) && file_exists($friend['avatar'])): ?>
                                        <img src="<?= htmlspecialchars($friend['avatar'], ENT_QUOTES, 'UTF-8') ?>"
                                             alt="<?= htmlspecialchars($friend['username'], ENT_QUOTES, 'UTF-8') ?>">
                                    <?php else: ?>
                                        <span class="avatar-letter"><?= htmlspecialchars(getAvatarLetter($friend['username'])) ?></span>
                                    <?php endif; ?>

                                    <span class="friend-status-dot offline"
                                              data-presence-dot="<?= (int)$friend['id'] ?>"
                                              data-presence-pending></span>
                                </div>

                                <span class="friend-avatar-name">
                                    <?= htmlspecialchars($friend['username'], ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </a>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($friends_count > 9): ?>
                        <a href="friends.php" class="view-all-link">Показать всех →</a>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="friends-empty">
                        <span class="empty-icon">👥</span>
                        <span class="empty-text">Нет друзей</span>
                        <a href="friends.php" style="color:#5865f2;text-decoration:none;font-size:13px;">Найти друзей</a>
                    </div>
                <?php endif; ?>
            </div>

        </aside>

        <!-- ===== ФУТЕР ===== -->
        <div class="site-footer">
            &copy; <span class="year">2026</span>
        </div>

    </div>

    <!-- Реакции: появляются при наведении на лайк (на телефоне — долгое нажатие) -->
    <div class="reaction-popup" id="reactionPopup" hidden>
        <div class="reaction-popup-row">
            <button type="button" class="reaction-opt" data-reaction="like" title="Нравится"><img class="like-heart" src="images/heart.svg" alt=""></button>
            <button type="button" class="reaction-opt" data-reaction="laugh" title="Ха-ха">😆</button>
            <button type="button" class="reaction-opt" data-reaction="wow" title="Ух ты">😲</button>
            <button type="button" class="reaction-opt" data-reaction="love" title="Восторг">😍</button>
            <button type="button" class="reaction-opt" data-reaction="sad" title="Грустно">😢</button>
            <button type="button" class="reaction-opt" data-reaction="angry" title="Возмутительно">😡</button>
        </div>
        <div class="reaction-popup-footer" id="reactionPopupFooter" hidden></div>
    </div>

    <!-- Поделиться: «В личном сообщении» -->
    <div class="share-dialog-overlay" id="shareDialog" hidden>
        <div class="share-dialog" role="dialog" aria-modal="true" aria-labelledby="shareDialogTitle">
            <div class="share-dialog-tabs">
                <span class="share-dialog-tab" id="shareDialogTitle">Поделиться</span>
            </div>
            <div class="share-dialog-body">
                <div class="share-option">
                    <span class="share-radio" aria-hidden="true"></span>
                    <span>В личном сообщении</span>
                </div>

                <div class="share-combo" id="shareCombo">
                    <input type="text" id="shareSearch" autocomplete="off"
                           placeholder="Введите имя получателя или название чата">
                    <span class="share-combo-arrow" aria-hidden="true">⌄</span>
                    <div class="share-list" id="shareList" hidden></div>
                </div>
            </div>
            <div class="share-dialog-footer">
                <button type="button" class="share-btn share-btn-cancel" id="shareCancel">Отмена</button>
                <button type="button" class="share-btn share-btn-send" id="shareSend" disabled>Отправить</button>
            </div>
        </div>
    </div>

    <!-- Просмотр фото / видео прямо в ленте -->
    <div class="news-lightbox" id="newsLightbox" hidden>
        <button type="button" class="news-lightbox-close" id="newsLightboxClose" aria-label="Закрыть">&times;</button>
        <div class="news-lightbox-stage" id="newsLightboxStage"></div>
    </div>

    <!-- Окно подтверждения (удаление комментария) -->
    <div class="confirm-overlay" id="confirmOverlay" aria-hidden="true">
        <div class="confirm-box" role="dialog" aria-modal="true" aria-labelledby="confirmText">
            <div class="confirm-text" id="confirmText"></div>
            <div class="confirm-actions">
                <button type="button" class="confirm-btn confirm-cancel" id="confirmCancel">Отмена</button>
                <button type="button" class="confirm-btn confirm-ok" id="confirmOk">OK</button>
            </div>
        </div>
    </div>

    <script>
        window.SHARE_CSRF = <?= json_encode($share_csrf_token) ?>;
        window.NEWS_SERVER_TS = <?= time() ?>;
    </script>
    <script>
    (function () {
        var form = document.getElementById('pcForm');
        if (!form) return;
        var text = document.getElementById('pcText'), file = document.getElementById('pcFile'),
            plus = document.getElementById('pcPlus'), menu = document.getElementById('pcMenu'),
            preview = document.getElementById('pcPreview'), errBox = document.getElementById('pcError'),
            emoji = document.getElementById('pcEmoji'), submit = document.getElementById('pcSubmit');
        var sending = false, objUrl = null, errTimer = null;

        var LIMIT = { image: 5, video: 50, audio: 20, file: 20 };   // МБ — как на сервере
        var LABEL = { image: 'Фото', video: 'Видео', audio: 'Музыка', file: 'Файл' };
        var ACCEPT = {
            image: 'image/jpeg,image/png,image/webp,image/gif',
            video: 'video/mp4,video/webm',
            audio: 'audio/*,.mp3,.ogg,.oga,.opus,.wav,.m4a,.aac,.flac',
            file: '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.rtf,.csv,.odt,.ods,.odp,.zip,.rar,.7z'
        };
        var RE_AUDIO = /\.(mp3|ogg|oga|opus|wav|m4a|aac|flac|weba)$/i,
            RE_FILE = /\.(pdf|docx?|xlsx?|pptx?|txt|rtf|csv|od[tsp]|zip|rar|7z)$/i;
        var ICON = {
            audio: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></svg>',
            file: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
            x: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>'
        };

        function kindOf(f) {
            if (RE_AUDIO.test(f.name)) return 'audio';
            if (/^image\/(jpeg|png|webp|gif)$/.test(f.type)) return 'image';
            if (/^video\/(mp4|webm)$/.test(f.type)) return 'video';
            if (RE_FILE.test(f.name)) return 'file';
            return '';
        }
        function size(b) { return b >= 1048576 ? (b / 1048576).toFixed(1).replace('.', ',') + ' МБ' : Math.max(1, Math.round(b / 1024)) + ' КБ'; }
        function showError(msg) {
            errBox.textContent = msg; errBox.hidden = false;
            clearTimeout(errTimer); errTimer = setTimeout(function () { errBox.hidden = true; }, 6000);
        }
        function hideError() { errBox.hidden = true; }

        /* меню «+» */
        function setMenu(open) {
            menu.classList.toggle('is-open', open);
            plus.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
        plus.addEventListener('click', function () { setMenu(!menu.classList.contains('is-open')); });
        document.addEventListener('click', function (e) {
            if (!form.contains(e.target)) { setMenu(false); emoji.hidden = true; }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') { setMenu(false); emoji.hidden = true; }
        });
        menu.addEventListener('click', function (e) {
            var b = e.target.closest('.pc-opt'); if (!b) return;
            var kind = b.getAttribute('data-kind');
            setMenu(false);
            if (kind === 'emoji') { toggleEmoji(); return; }
            emoji.hidden = true;
            file.setAttribute('accept', ACCEPT[kind]);
            file.click();                      // только открывает выбор файла, ничего не отправляется
        });

        /* вложение */
        function clearAttach() {
            if (objUrl) { URL.revokeObjectURL(objUrl); objUrl = null; }
            file.value = '';
            preview.innerHTML = ''; preview.hidden = true;
        }
        file.addEventListener('change', function () {
            var f = file.files && file.files[0];
            if (!f) { clearAttach(); return; }
            var kind = kindOf(f);
            hideError();
            if (!kind) { clearAttach(); showError('Этот формат не поддерживается. Можно фото, видео, музыку или документы (PDF, DOC, XLS, ZIP и т. п.).'); return; }
            if (f.size > LIMIT[kind] * 1048576) { clearAttach(); showError(LABEL[kind] + ': максимум ' + LIMIT[kind] + ' МБ.'); return; }
            if (objUrl) URL.revokeObjectURL(objUrl);
            objUrl = null;

            var thumb = '';
            if (kind === 'image' || kind === 'video') {
                objUrl = URL.createObjectURL(f);
                thumb = '<div class="pc-thumb k-' + kind + '">' + (kind === 'image'
                    ? '<img alt="" src="' + objUrl + '">'
                    : '<video muted preload="metadata" src="' + objUrl + '#t=0.1"></video>') + '</div>';
            } else {
                thumb = '<div class="pc-thumb k-' + kind + '">' + ICON[kind] + '</div>';
            }
            preview.innerHTML = '<div class="pc-chip">' + thumb +
                '<div class="pc-chip-info"><div class="pc-chip-name"></div><div class="pc-chip-meta">' + LABEL[kind] + ' · ' + size(f.size) + '</div></div>' +
                '<button type="button" class="pc-chip-x" aria-label="Убрать вложение">' + ICON.x + '</button></div>';
            preview.querySelector('.pc-chip-name').textContent = f.name;
            preview.hidden = false;
        });
        preview.addEventListener('click', function (e) {
            if (e.target.closest('.pc-chip-x')) clearAttach();
        });

        /* эмодзи */
        var EMOJIS = '😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😍 🥰 😘 😋 😜 🤪 😎 🤩 🥳 😏 😒 😔 😢 😭 😤 😡 🤯 😱 😴 🤔 🤗 🤭 🙄 😬 🥺 😳 🤝 👍 👎 👏 🙌 🙏 💪 👀 👋 ✌️ 🤞 👌 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💕 💖 🔥 ✨ ⭐ 🌟 💯 🎉 🎊 🎁 🎂 🎵 🎶 🎮 📷 🎬 📚 💡 ✅ ❌ ⚡ 🌈 ☀️ 🌙 ❄️ 🍂 🍁 🌸 🌹 🐶 🐱 🦊 🐼 🍕 🍔 🍟 🍩 ☕ 🍺 🚀 🚗 ✈️ 🏆 ⚽ 🏠 💬 📌'.split(' ');
        function toggleEmoji() {
            if (!emoji.firstChild) {
                emoji.innerHTML = EMOJIS.map(function (e) { return '<button type="button" tabindex="-1">' + e + '</button>'; }).join('');
            }
            emoji.hidden = !emoji.hidden;
            if (!emoji.hidden) text.focus();
        }
        emoji.addEventListener('mousedown', function (e) { e.preventDefault(); });   // фокус остаётся в тексте
        emoji.addEventListener('click', function (e) {
            var b = e.target.closest('button'); if (!b) return;
            text.focus();
            text.setRangeText(b.textContent, text.selectionStart, text.selectionEnd, 'end');
        });

        /* высота поля фиксированная, как в index.php (только ручной resize) */
        text.addEventListener('input', hideError);

        /* отправка только по кнопке «Опубликовать» */
        form.addEventListener('submit', function (e) {
            if (sending) { e.preventDefault(); return; }
            if (text.value.trim() === '' && !(file.files && file.files.length)) {
                e.preventDefault(); showError('Напишите текст или прикрепите фото, видео, музыку или файл.'); text.focus(); return;
            }
            sending = true;
            submit.classList.add('is-sending');
            submit.textContent = 'Публикуем…';
        });
        window.addEventListener('pageshow', function () {
            sending = false; submit.classList.remove('is-sending'); submit.textContent = 'Опубликовать';
        });
    })();
    </script>
    <script src="assets/js/mentions.js"></script>
    <script src="assets/js/post-emoji.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/news.js"></script>

    
</body>
</html>
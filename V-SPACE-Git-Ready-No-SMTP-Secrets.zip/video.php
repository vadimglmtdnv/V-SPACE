<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
// Если в настройках выбран English — содержимое страницы переводится «на лету» (includes/lang.php)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();

/*
|--------------------------------------------------------------------------
| PLAYERCHAT — Видео
|--------------------------------------------------------------------------
*/

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$user_id = (int)$_SESSION["user_id"];

$stmt = $conn->prepare("SELECT id, username, email, avatar, status, last_seen, is_admin FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    $_SESSION = [];
    session_destroy();
    header("Location: login.php?account_missing=1");
    exit;
}

$username = $user["username"];
$is_admin = isset($user["is_admin"]) && $user["is_admin"] == 1;

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: video.php");
    exit;
}

$notifications = [];
$notif_count = 0;
$unread_count = 0;
$pending_reports_count = 0;
$current_user_data = [];

try {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $unread_count = shell_unread_messages($conn, $user_id);   // как в messages.php: гаснет, когда открыт диалог

    $stmt = $conn->prepare("SELECT id, username, avatar, status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    if ($is_admin) {
        $result = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
        if ($result) {
            $pending_reports_count = (int)$result->fetch_assoc()['c'];
        }
    }
} catch (Throwable $e) {
    error_log('video.php shell: ' . $e->getMessage());
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

function isOnline(?string $status): bool {
    return $status === 'online';
}


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Видео</title>
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/media.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/media.css') ?>">
    <style>
        /* ===== Панель «Лайк / Комментарий / Поделиться» под видео (иконки — SVG, классы — как в index.php) ===== */
        .md-vactions {
            position: fixed; z-index: 2147483000;
            display: flex; align-items: center; gap: 6px;
            padding: 5px; border-radius: 999px;
            background: rgba(20, 22, 28, .72);
            -webkit-backdrop-filter: blur(14px) saturate(1.4); backdrop-filter: blur(14px) saturate(1.4);
            border: 1px solid rgba(255, 255, 255, .10);
            box-shadow: 0 8px 28px rgba(0, 0, 0, .38);
            transition: opacity .18s ease;
        }
        .md-vactions[hidden], .md-vcomments[hidden] { display: none; }
        .md-vactions .post-action-btn {
            position: relative; display: inline-flex; align-items: center; gap: 8px;
            height: 38px; padding: 0 15px 0 12px; margin: 0;
            border: 0; border-radius: 999px; background: transparent;
            color: #c9ccd6; font: 600 14px/1 inherit; font-family: inherit;
            cursor: pointer; user-select: none; -webkit-tap-highlight-color: transparent;
            transition: background .16s ease, color .16s ease, transform .12s ease;
        }
        .md-vactions .post-action-btn:hover { background: rgba(255, 255, 255, .09); color: #fff; }
        .md-vactions .post-action-btn:active { transform: scale(.94); }
        .md-vactions .post-action-btn:focus-visible { outline: 2px solid #5865f2; outline-offset: 1px; }
        .md-vactions .action-icon { display: inline-flex; width: 22px; height: 22px; }
        .md-vactions .action-icon svg { width: 22px; height: 22px; display: block; fill: none; stroke: currentColor; stroke-width: 1.9; stroke-linecap: round; stroke-linejoin: round; overflow: visible; transition: fill .16s ease, stroke .16s ease, transform .16s ease; }
        .md-vactions .action-count { min-width: 8px; font-variant-numeric: tabular-nums; }
        .md-vactions .action-count:empty::before { content: '0'; }

        .md-vactions .post-action-btn.liked { color: #ff4d6a; }
        .md-vactions .post-action-btn.liked:hover { background: rgba(255, 77, 106, .14); }
        .md-vactions .post-action-btn.liked .action-icon svg { fill: #ff4d6a; stroke: #ff4d6a; animation: mdHeartPop .42s cubic-bezier(.2, 1.6, .4, 1); }
        .md-vactions .post-action-btn.toggle-comments.is-open { color: #7b86ff; background: rgba(88, 101, 242, .18); }
        .md-vactions .post-action-btn.reposted { color: #3ddc97; }
        .md-vactions .post-action-btn.reposted .action-icon svg { animation: mdSharePop .45s ease; }
        @keyframes mdHeartPop { 0% { transform: scale(.6); } 55% { transform: scale(1.3); } 100% { transform: scale(1); } }
        @keyframes mdSharePop { 0% { transform: translate(0, 0); } 40% { transform: translate(3px, -3px) scale(1.1); } 100% { transform: translate(0, 0); } }

        /* Окно комментариев */
        .md-vcomments {
            position: fixed; z-index: 2147483001; width: 330px; max-width: calc(100vw - 16px);
            display: flex; flex-direction: column; border-radius: 16px; overflow: hidden;
            background: rgba(24, 26, 33, .94);
            -webkit-backdrop-filter: blur(16px); backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, .10); box-shadow: 0 16px 44px rgba(0, 0, 0, .5);
            color: #e6e8ef; font-size: 14px;
        }
        .md-vcomments-head { display: flex; align-items: center; justify-content: space-between; padding: 12px 14px 10px; font-weight: 700; }
        .md-vcomments-head button { border: 0; background: transparent; color: #9aa0b0; font-size: 16px; cursor: pointer; padding: 2px 6px; border-radius: 8px; }
        .md-vcomments-head button:hover { color: #fff; background: rgba(255, 255, 255, .08); }
        .md-vcomments-list { max-height: 220px; overflow-y: auto; padding: 0 14px; display: flex; flex-direction: column; gap: 8px; }
        .md-vcomments-empty { color: #8b91a1; padding: 6px 0 12px; font-size: 13px; }
        .md-vc-item { background: rgba(255, 255, 255, .06); border-radius: 12px; padding: 8px 11px; line-height: 1.4; word-break: break-word; white-space: pre-wrap; }
        .md-vc-item small { display: block; color: #8b91a1; font-size: 11px; margin-top: 3px; }
        .md-vcomments-form { display: flex; gap: 8px; padding: 10px 12px 12px; }
        .md-vcomments-form input { flex: 1; min-width: 0; height: 38px; padding: 0 14px; border-radius: 999px; border: 1px solid rgba(255, 255, 255, .12); background: rgba(0, 0, 0, .28); color: #fff; font: inherit; outline: none; }
        .md-vcomments-form input:focus { border-color: #5865f2; }
        .md-vcomments-form button { width: 38px; height: 38px; border: 0; border-radius: 50%; background: #5865f2; color: #fff; cursor: pointer; display: grid; place-items: center; transition: background .16s ease, transform .12s ease; }
        .md-vcomments-form button:hover { background: #4752c4; }
        .md-vcomments-form button:active { transform: scale(.92); }
        .md-vcomments-form svg { width: 18px; height: 18px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }

        .md-vtoast { position: fixed; left: 50%; bottom: 28px; transform: translate(-50%, 12px); z-index: 2147483002; padding: 10px 18px; border-radius: 999px; background: rgba(20, 22, 28, .92); color: #fff; font-size: 14px; border: 1px solid rgba(255, 255, 255, .12); opacity: 0; pointer-events: none; transition: opacity .2s ease, transform .2s ease; }
        .md-vtoast.show { opacity: 1; transform: translate(-50%, 0); }

        @media (prefers-reduced-motion: reduce) { .md-vactions *, .md-vtoast { animation: none !important; transition: none !important; } }
        @media (max-width: 520px) { .md-vactions .post-action-btn { padding: 0 11px 0 9px; gap: 6px; } }
    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <?php include __DIR__ . '/includes/site_header.php'; ?>

    <div class="layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main>
            <div class="md-page md-wrap" data-md-kind="video">

                <section class="md-hero">
                    <div class="md-hero-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4.5-2.5z" fill="currentColor"/></svg></div>
                    <div class="md-hero-text">
                        <h1>Видео</h1>
                        <p>Смотрите свои ролики прямо на сайте. Перетащите файл в окно или выберите его на компьютере.</p>
                    </div>
                    <label class="md-btn" for="mdInput"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M5 20h14"/></svg>Выбрать видео</label>
                </section>

                <input type="file" id="mdInput" accept="video/*" multiple hidden>

                <div class="md-toolbar" id="mdToolbar" hidden>
                    <div class="md-count" id="mdCount">0</div>
                    
                </div>

                <div class="md-drop" id="mdDrop">
                    <div class="md-drop-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4.5-2.5z" fill="currentColor"/></svg></div>
                    <strong>Перетащите видео сюда</strong>
                    <small>MP4, WebM, MOV — сколько угодно файлов</small>
                    <label class="md-btn" for="mdInput"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M5 20h14"/></svg>Выбрать видео</label>
                </div>

                <div class="md-grid video" id="mdGrid" data-size="m" hidden></div>

                <p class="md-note">Пока видео воспроизводится только в вашем браузере и не сохраняется на сервере — после обновления страницы оно пропадёт.</p>
            </div>
        </main>
    </div>

    <div class="md-viewer" id="mdViewer" aria-hidden="true">
        <button type="button" class="md-vbtn close" aria-label="Закрыть">✕</button>
        <button type="button" class="md-vbtn prev" aria-label="Назад">‹</button>
        <div class="md-viewer-stage" id="mdStage"></div>
        <button type="button" class="md-vbtn next" aria-label="Вперёд">›</button>
        <div class="md-vcap" id="mdVcap"></div>
    </div>

    <!-- Лайк / комментарий / поделиться: показываются под открытым видео (логика — скрипт в конце страницы) -->
    <div class="md-vactions" id="mdActions" hidden>
        <button type="button" class="post-action-btn" id="mdLikeBtn" aria-label="Лайк" aria-pressed="false" data-tooltip="Нравится">
            <span class="action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></span>
            <span class="action-count">0</span>
        </button>
        <button type="button" class="post-action-btn toggle-comments" id="mdCommentBtn" aria-label="Комментарии" aria-expanded="false" data-tooltip="Оставить комментарий">
            <span class="action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8z"/></svg></span>
            <span class="action-count">0</span>
        </button>
        <button type="button" class="post-action-btn" id="mdShareBtn" aria-label="Поделиться" data-tooltip="Поделиться">
            <span class="action-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/></svg></span>
            <span class="action-count">0</span>
        </button>
    </div>

    <div class="md-vcomments" id="mdComments" role="dialog" aria-label="Комментарии" hidden>
        <div class="md-vcomments-head"><span>Комментарии</span><button type="button" id="mdCommentsClose" aria-label="Закрыть">✕</button></div>
        <div class="md-vcomments-list" id="mdCommentsList"></div>
        <form class="md-vcomments-form" id="mdCommentsForm" autocomplete="off">
            <input type="text" id="mdCommentsInput" maxlength="500" placeholder="Написать комментарий…" aria-label="Комментарий">
            <button type="submit" aria-label="Отправить"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/></svg></button>
        </form>
    </div>
    <div class="md-vtoast" id="mdToast" role="status" aria-live="polite"></div>

    <script src="assets/js/script.js"></script>
    <script src="assets/js/media.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/media.js') ?>"></script>

    <script>
    /* Лайк / комментарий / поделиться для открытого видео.
       Видео на этой странице живут только в браузере (на сервер не загружаются), поэтому лайки, комментарии
       и счётчик «поделиться» хранятся здесь же, в localStorage, по имени файла. */
    (function () {
        'use strict';
        var viewer = document.getElementById('mdViewer');
        var stage = document.getElementById('mdStage');
        var cap = document.getElementById('mdVcap');
        var bar = document.getElementById('mdActions');
        if (!viewer || !stage || !bar) return;

        var likeBtn = document.getElementById('mdLikeBtn');
        var cmtBtn = document.getElementById('mdCommentBtn');
        var shareBtn = document.getElementById('mdShareBtn');
        var panel = document.getElementById('mdComments');
        var list = document.getElementById('mdCommentsList');
        var form = document.getElementById('mdCommentsForm');
        var input = document.getElementById('mdCommentsInput');
        var toastEl = document.getElementById('mdToast');

        var STORE = 'vd_actions_v1';
        var data = {};
        try { data = JSON.parse(window.localStorage.getItem(STORE)) || {}; } catch (e) { data = {}; }
        function save() { try { window.localStorage.setItem(STORE, JSON.stringify(data)); } catch (e) { /* ignore */ } }

        var key = '';
        function rec() { return data[key] || (data[key] = { liked: false, shares: 0, comments: [] }); }

        function esc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
        function fmtTime(ts) {
            var d = new Date(ts), p = function (n) { return (n < 10 ? '0' : '') + n; };
            return p(d.getDate()) + '.' + p(d.getMonth() + 1) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
        }
        var toastTimer = null;
        function toast(text) {
            toastEl.textContent = text;
            toastEl.classList.add('show');
            clearTimeout(toastTimer);
            toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, 1800);
        }

        function render() {
            var r = rec();
            likeBtn.classList.toggle('liked', r.liked);
            likeBtn.setAttribute('aria-pressed', r.liked ? 'true' : 'false');
            likeBtn.querySelector('.action-count').textContent = r.liked ? 1 : 0;
            cmtBtn.querySelector('.action-count').textContent = r.comments.length;
            shareBtn.classList.toggle('reposted', r.shares > 0);
            shareBtn.querySelector('.action-count').textContent = r.shares;
            if (!r.comments.length) {
                list.innerHTML = '<div class="md-vcomments-empty">Пока нет комментариев. Напишите первый!</div>';
            } else {
                list.innerHTML = r.comments.map(function (c) {
                    return '<div class="md-vc-item">' + esc(c.t) + '<small>' + fmtTime(c.d) + '</small></div>';
                }).join('');
                list.scrollTop = list.scrollHeight;
            }
        }

        // Что сейчас открыто: <video> в окне просмотра (если окно закрыто или скрыто — null)
        function openVideo() {
            var v = stage.querySelector('video');
            if (!v) return null;
            var cs = window.getComputedStyle(viewer);
            if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) return null;
            var r = v.getBoundingClientRect();
            return (r.width > 0 && r.height > 0) ? v : null;
        }

        // Под видео, если там хватает места, иначе поверх видео в правом верхнем углу
        var under = true;
        function place(v) {
            var r = v.getBoundingClientRect();
            var h = bar.offsetHeight || 48, w = bar.offsetWidth || 220;
            under = (window.innerHeight - r.bottom) >= h + 16;
            var left, top;
            if (under) {
                left = r.left + r.width / 2 - w / 2;
                top = r.bottom + 10;
            } else {
                left = r.right - w - 14;
                top = r.top + 14;
            }
            left = Math.max(8, Math.min(window.innerWidth - w - 8, left));
            bar.style.left = left + 'px';
            bar.style.top = Math.max(8, top) + 'px';
            if (!panel.hidden) placePanel();
        }
        function placePanel() {
            var b = bar.getBoundingClientRect();
            var pw = panel.offsetWidth || 330, ph = panel.offsetHeight || 300;
            var left = Math.max(8, Math.min(window.innerWidth - pw - 8, b.left + b.width / 2 - pw / 2));
            var top = under ? b.top - ph - 10 : b.bottom + 10;
            if (top < 8) top = Math.min(window.innerHeight - ph - 8, b.bottom + 10);
            panel.style.left = left + 'px';
            panel.style.top = Math.max(8, top) + 'px';
        }

        function setComments(open) {
            panel.hidden = !open;
            cmtBtn.classList.toggle('is-open', open);
            cmtBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (open) { placePanel(); setTimeout(function () { try { input.focus({ preventScroll: true }); } catch (e) { input.focus(); } }, 0); }
        }

        function sync() {
            var v = openVideo();
            if (!v) {
                if (!bar.hidden) { bar.hidden = true; setComments(false); }
                return;
            }
            var k = ((cap && cap.textContent) || '').trim() || v.currentSrc || v.getAttribute('src') || 'video';
            if (k !== key) { key = k; render(); setComments(false); }
            if (bar.hidden) bar.hidden = false;
            place(v);
        }

        likeBtn.addEventListener('click', function () { var r = rec(); r.liked = !r.liked; save(); render(); });
        cmtBtn.addEventListener('click', function () { setComments(panel.hidden); });
        document.getElementById('mdCommentsClose').addEventListener('click', function () { setComments(false); });
        shareBtn.addEventListener('click', function () {
            var url = window.location.href.split('#')[0];
            var done = function (msg) { rec().shares++; save(); render(); toast(msg); };
            var copy = function () {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(url).then(function () { done('Ссылка скопирована'); }, function () { toast('Не удалось скопировать ссылку'); });
                } else {
                    var t = document.createElement('textarea'); t.value = url; t.style.position = 'fixed'; t.style.opacity = '0';
                    document.body.appendChild(t); t.select();
                    var ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
                    document.body.removeChild(t);
                    ok ? done('Ссылка скопирована') : toast('Не удалось скопировать ссылку');
                }
            };
            if (navigator.share) {
                navigator.share({ title: document.title, url: url }).then(function () { done('Отправлено'); }, function (e) { if (e && e.name !== 'AbortError') copy(); });
            } else { copy(); }
        });
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var t = input.value.replace(/\s+$/, '').replace(/^\s+/, '');
            if (!t) return;
            rec().comments.push({ t: t.slice(0, 500), d: Date.now() });
            save(); input.value = ''; render();
        });
        // Пока пишем комментарий, клавиши (пробел, стрелки, Esc) не должны управлять плеером/окном просмотра
        ['keydown', 'keyup', 'keypress'].forEach(function (ev) {
            panel.addEventListener(ev, function (e) {
                e.stopPropagation();
                if (ev === 'keydown' && e.key === 'Escape') setComments(false);
            });
        });

        if (window.MutationObserver) {
            var mo = new MutationObserver(sync);
            mo.observe(stage, { childList: true, subtree: true });
            mo.observe(viewer, { attributes: true });
            if (cap) mo.observe(cap, { childList: true, characterData: true, subtree: true });
        }
        stage.addEventListener('loadedmetadata', sync, true);
        window.addEventListener('resize', sync);
        document.addEventListener('fullscreenchange', sync);
        setInterval(sync, 500);   // страховка, если окно просмотра открывается без изменений в DOM
        sync();
    })();
    </script>

</body>
</html>
<?php
$conn->close();

<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
require_once __DIR__ . '/account_state.php';

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: login.php");
    exit;
}

$error = '';
$conn = null;
$googleErrors = require __DIR__ . '/api/google_errors.php';

if (isset($_GET['account_missing'])) {
    $error = 'Аккаунт не найден. Войдите снова или зарегистрируйте новый аккаунт.';
} elseif (isset($_GET['deleted'])) {
    $error = 'Аккаунт помечен как удалённый. Войдите с прежними данными, чтобы восстановить его.';
} elseif (isset($_GET['session_ended'])) {
    $error = 'Сеанс был завершён (например, кнопкой «Завершить все сеансы» на другом устройстве). Войдите снова.';
} elseif (isset($_GET['deactivated'])) {
    $error = 'Аккаунт временно отключён. Войдите с прежним паролем, чтобы включить его обратно.';
} elseif (isset($_GET['google_error'])) {
    // Ошибка входа через Google (коды и тексты — в api/google_errors.php)
    $googleCode = $_GET['google_error'];
    $error = (is_string($googleCode) && isset($googleErrors[$googleCode]))
        ? $googleErrors[$googleCode]
        : $googleErrors['server'];
}

try {
    $conn = db_connect();
    if ($conn->connect_error) {
        throw new Exception("Ошибка подключения: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
    require_once __DIR__ . '/account_state.php';
    ensureAccountStateColumns($conn);
} catch (Exception $e) {
    error_log("MySQL Error: " . $e->getMessage());
    // Без базы войти всё равно нельзя — показываем единую страницу ошибок (error.php)
    $error_code   = 503;
    $error_title  = 'Нет связи с базой данных';
    $error_text   = 'Не удалось подключиться к серверу MySQL, войти сейчас нельзя. Попробуйте чуть позже.';
    $error_detail = $e->getMessage();   // видно только при заходе с localhost
    require __DIR__ . '/error.php';
    exit;
}

// Создаём таблицу для истории IP если её нет
if ($conn && !$conn->connect_error) {
    $conn->query("
        CREATE TABLE IF NOT EXISTS user_ip_history (
            id INT NOT NULL AUTO_INCREMENT,
            user_id INT NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            user_agent VARCHAR(255) NULL,
            action VARCHAR(20) DEFAULT 'login',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX user_id (user_id),
            INDEX ip_address (ip_address)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Добавляем колонку action если её нет
    $result = $conn->query("SHOW COLUMNS FROM user_ip_history LIKE 'action'");
    if ($result->num_rows === 0) {
        $conn->query("ALTER TABLE user_ip_history ADD COLUMN action VARCHAR(20) DEFAULT 'login'");
    }

    // Версия сессии — нужна для кнопки «Завершить все сеансы» в чате (messages.php).
    $svCol = $conn->query("SHOW COLUMNS FROM users LIKE 'session_version'");
    if ($svCol && $svCol->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN session_version INT NOT NULL DEFAULT 0");
    }

    // Временное отключение аккаунта (кнопка в settings.php, выше «Удалить профиль»).
    // В отличие от deleted_at это не мягкое удаление, а именно пауза: аккаунт снимается
    // с сессий и выглядит офлайн, а обычный вход по паролю сам же его и включает обратно.
    $daCol = $conn->query("SHOW COLUMNS FROM users LIKE 'deactivated_at'");
    if ($daCol && $daCol->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN deactivated_at DATETIME NULL DEFAULT NULL");
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["login"])) {
    if (!$conn || $conn->connect_error) {
        $error = "Нет подключения к базе данных.";
    } else {
        $login = trim($_POST["login"] ?? "");
        $password = trim($_POST["password"] ?? "");
        $remember = isset($_POST["remember"]) && $_POST["remember"] === "on";

        if ($login === "" || $password === "") {
            $error = "Заполните все поля.";
            // ✅ СОХРАНЯЕМ ЛОГИН В СЕССИИ
            $_SESSION['saved_login'] = $login;
        } else {
            $stmt = $conn->prepare("
                SELECT id, username, email, password, status, deleted_at, is_blocked, session_version, deactivated_at
                FROM users
                WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)
                LIMIT 1
            ");
            $stmt->bind_param("ss", $login, $login);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();

            if ($user && !empty($user['deleted_at'])) {
                if ((int)($user['is_blocked'] ?? 0) !== 1 && password_verify($password, $user['password'])) {
                    session_regenerate_id(true);
                    $_SESSION["user_id"] = (int)$user["id"];
                    $_SESSION["username"] = $user["username"];
                    $_SESSION["deleted_account_pending"] = true;
                    unset($_SESSION['saved_login']);
                    header("Location: index.php");
                    exit;
                }
                $error = "Этот аккаунт удалён. Войдите с прежним паролем, чтобы открыть восстановление.";
            } elseif ($user && (int)($user['is_blocked'] ?? 0) === 1) {
                $error = "Этот аккаунт заблокирован.";
            } elseif ($user && password_verify($password, $user["password"])) {
                // Записываем IP в историю при входе
                $current_ip = $_SERVER['REMOTE_ADDR'] ?? '';
                $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
                
                if (!empty($current_ip)) {
                    // Проверяем, был ли этот IP за последние 10 минут
                    $stmt2 = $conn->prepare("
                        SELECT id 
                        FROM user_ip_history 
                        WHERE user_id = ? AND ip_address = ? 
                        AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)
                        AND action = 'login'
                        LIMIT 1
                    ");
                    $stmt2->bind_param("is", $user["id"], $current_ip);
                    $stmt2->execute();
                    $checkResult = $stmt2->get_result();
                    
                    // Если нет - добавляем новый
                    if ($checkResult->num_rows === 0) {
                        $stmt3 = $conn->prepare("
                            INSERT INTO user_ip_history (user_id, ip_address, user_agent, action)
                            VALUES (?, ?, ?, 'login')
                        ");
                        $stmt3->bind_param("iss", $user["id"], $current_ip, $user_agent);
                        $stmt3->execute();
                        $stmt3->close();
                    }
                    $stmt2->close();
                    
                    // Обновляем текущий IP в таблице users
                    $stmt4 = $conn->prepare("UPDATE users SET ip_address = ? WHERE id = ?");
                    $stmt4->bind_param("si", $current_ip, $user["id"]);
                    $stmt4->execute();
                    $stmt4->close();
                }
                
                // Если аккаунт был временно отключён — обычный успешный вход по паролю
                // сам его и включает обратно. Никакого отдельного «восстановления»,
                // как у удалённых аккаунтов, тут не нужно — отключение для того и
                // существует, чтобы это была просто пауза.
                $was_deactivated = !empty($user['deactivated_at']);
                if ($was_deactivated) {
                    $stmtReact = $conn->prepare("UPDATE users SET deactivated_at = NULL WHERE id = ?");
                    $stmtReact->bind_param("i", $user["id"]);
                    $stmtReact->execute();
                    $stmtReact->close();
                }

                // Сохраняем сессию
                session_regenerate_id(true);
                $_SESSION["user_id"] = (int)$user["id"];
                $_SESSION["username"] = $user["username"];
                $_SESSION["session_version"] = (int)($user["session_version"] ?? 0);

                // Помечаем, что это настоящий вход по логину/паролю (а не тихий
                // автовход по токену «Запомнить меня» ниже в этом файле). Только
                // при этом флаге messages.php пришлёт сообщение «Выполнен вход…» —
                // см. recordLoginAndNotify() в messages.php.
                $_SESSION["fresh_login"] = true;
                
                // ✅ УДАЛЯЕМ СОХРАНЁННЫЙ ЛОГИН ПРИ УСПЕШНОМ ВХОДЕ
                unset($_SESSION['saved_login']);

                // Если включен "Запомнить меня" - создаем токен для автоматического входа
                if ($remember) {
                    $lifetime = playerchat_session_lifetime();
                    $token = bin2hex(random_bytes(32));
                    $expires = date('Y-m-d H:i:s', time() + $lifetime);
                    
                    // Сохраняем токен в БД
                    $stmt5 = $conn->prepare("UPDATE users SET remember_token = ?, token_expires = ? WHERE id = ?");
                    $stmt5->bind_param("ssi", $token, $expires, $user["id"]);
                    $stmt5->execute();
                    $stmt5->close();
                    
                    // Сохраняем токен для восстановления входа на срок жизни сессии.
                    setcookie('remember_token', $token, [
                        'expires' => time() + $lifetime,
                        'path' => '/',
                        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                        'httponly' => true,
                        'samesite' => 'Lax',
                    ]);
                }

                // Обновляем статус на online
                $stmt6 = $conn->prepare("UPDATE users SET last_seen = NOW(), status = 'online' WHERE id = ?");
                $stmt6->bind_param("i", $user["id"]);
                $stmt6->execute();
                $stmt6->close();

                header("Location: index.php" . ($was_deactivated ? "?reactivated=1" : ""));
                exit;
            } else {
                $error = "Неверный логин или пароль.";
                // ✅ СОХРАНЯЕМ ЛОГИН В СЕССИИ ПРИ ОШИБКЕ
                $_SESSION['saved_login'] = $login;
            }
        }
    }
}

// ============================================================
// ✅ АВТОМАТИЧЕСКИЙ ВХОД ПО ТОКЕНУ (С ЗАПИСЬЮ IP)
// ============================================================

if (!isset($_SESSION["user_id"]) && isset($_COOKIE['remember_token']) && isset($_COOKIE['user_id'])) {
    $token = $_COOKIE['remember_token'];
    $user_id = (int)$_COOKIE['user_id'];
    
    if ($conn && !$conn->connect_error) {
        $stmt = $conn->prepare("
            SELECT id, username, remember_token, token_expires, deleted_at, is_blocked, session_version
            FROM users
            WHERE id = ? AND remember_token = ? AND token_expires > NOW()
        ");
        $stmt->bind_param("is", $user_id, $token);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        if ($user && empty($user['deleted_at']) && (int)($user['is_blocked'] ?? 0) !== 1) {
            session_regenerate_id(true);
            $_SESSION["user_id"] = (int)$user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["session_version"] = (int)($user["session_version"] ?? 0);
            
            // ✅ ЗАПИСЫВАЕМ IP В ИСТОРИЮ ПРИ АВТОМАТИЧЕСКОМ ВХОДЕ
            $current_ip = $_SERVER['REMOTE_ADDR'] ?? '';
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            
            if (!empty($current_ip)) {
                // Проверяем, был ли этот IP за последние 10 минут
                $stmt2 = $conn->prepare("
                    SELECT id 
                    FROM user_ip_history 
                    WHERE user_id = ? AND ip_address = ? 
                    AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)
                    AND action = 'login'
                    LIMIT 1
                ");
                $stmt2->bind_param("is", $user["id"], $current_ip);
                $stmt2->execute();
                $checkResult = $stmt2->get_result();
                
                // Если нет - добавляем новый
                if ($checkResult->num_rows === 0) {
                    $stmt3 = $conn->prepare("
                        INSERT INTO user_ip_history (user_id, ip_address, user_agent, action)
                        VALUES (?, ?, ?, 'login')
                    ");
                    $stmt3->bind_param("iss", $user["id"], $current_ip, $user_agent);
                    $stmt3->execute();
                    $stmt3->close();
                }
                $stmt2->close();
                
                // Обновляем текущий IP в таблице users
                $stmt4 = $conn->prepare("UPDATE users SET ip_address = ? WHERE id = ?");
                $stmt4->bind_param("si", $current_ip, $user["id"]);
                $stmt4->execute();
                $stmt4->close();
            }
            
            // Обновляем время последнего визита и статус
            $stmt2 = $conn->prepare("UPDATE users SET last_seen = NOW(), status = 'online' WHERE id = ?");
            $stmt2->bind_param("i", $user["id"]);
            $stmt2->execute();
            $stmt2->close();
            
            header("Location: index.php");
            exit;
        } else {
            // Токен недействителен - удаляем куки
            setcookie('remember_token', '', time() - 3600, '/');
            setcookie('user_id', '', time() - 3600, '/');
        }
    }
}

if ($conn && !$conn->connect_error) {
    $conn->close();
}

// ✅ ПОЛУЧАЕМ СОХРАНЁННЫЙ ЛОГИН ИЗ СЕССИИ
$saved_login = isset($_SESSION['saved_login']) ? $_SESSION['saved_login'] : '';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <meta name="theme-color" content="<?= $theme === 'light' ? '#f0f2f5' : '#313338' ?>">
    <title>Вход</title>
    <link rel="stylesheet" href="assets/css/login.css">
    <link rel="stylesheet" href="assets/css/auth-shared.css">
    <script src="assets/js/auth-shared.js"></script>
    <script src="assets/js/auth-bg.js"></script>
    <style>
        /* ===== Оформление страницы входа (поверх assets/css/login.css) — в стиле register.php ===== */
        body .login-container {
            --accent: #5865f2;
            --green: #3ba55d;
            --red: #f23f42;
            --text: #f2f3f5;
            --label: #b5bac1;
            --muted: #949ba4;
            --placeholder: #6d6f78;
            --field: #1e1f22;
            --link: #8f9bff;
            --line: rgba(255, 255, 255, 0.09);
            --card: rgba(43, 45, 49, 0.30);
            --card-border: rgba(255, 255, 255, 0.07);
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 460px;
            padding: 36px 34px 30px;
            background: var(--card);
            -webkit-backdrop-filter: blur(14px);
            backdrop-filter: blur(14px);
            border: 1px solid var(--card-border);
            border-radius: 18px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.45), 0 2px 0 rgba(255, 255, 255, 0.03) inset;
            color: var(--text);
        }

        /* Светлая тема */
        body[data-theme="light"] .login-container {
            --text: #1f2328;
            --label: #4e5058;
            --muted: #5c6068;
            --placeholder: #8a8e96;
            --field: rgba(255, 255, 255, 0.85);
            --link: #4752c4;
            --line: rgba(0, 0, 0, 0.1);
            --card: rgba(255, 255, 255, 0.45);
            --card-border: rgba(0, 0, 0, 0.08);
            box-shadow: 0 24px 60px rgba(30, 40, 80, 0.18), 0 2px 0 rgba(255, 255, 255, 0.5) inset;
        }

        /* Системная тема */
        @media (prefers-color-scheme: light) {
            body[data-theme="system"] .login-container {
                --text: #1f2328;
                --label: #4e5058;
                --muted: #5c6068;
                --placeholder: #8a8e96;
                --field: rgba(255, 255, 255, 0.85);
                --link: #4752c4;
                --line: rgba(0, 0, 0, 0.1);
                --card: rgba(255, 255, 255, 0.45);
                --card-border: rgba(0, 0, 0, 0.08);
                box-shadow: 0 24px 60px rgba(30, 40, 80, 0.18), 0 2px 0 rgba(255, 255, 255, 0.5) inset;
            }
        }

        /* Убрано RGB-свечение вокруг карточки: переопределяем анимацию rgbPulse из login.css (и её запасной вариант
           в auth-shared.css) на статичную тень, поэтому остаётся только обычная тёмная тень. */
        @keyframes rgbPulse {
            0%, 100% { box-shadow: 0 24px 60px rgba(0, 0, 0, 0.45), 0 2px 0 rgba(255, 255, 255, 0.03) inset; }
        }

        /* Цветная полоска сверху карточки.
           Слой повторяет форму карточки (скругление 18px), а маска оставляет видимыми только верхние 3px,
           поэтому полоска плавно изгибается по углам и не выступает за них. */
        body .login-container::before {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: inherit;
            background: linear-gradient(90deg, #3a4bea, #8f9bff, #3a4bea);
            -webkit-mask: linear-gradient(#000, #000) top / 100% 3px no-repeat;
            mask: linear-gradient(#000, #000) top / 100% 3px no-repeat;
            pointer-events: none;
        }

        body .login-container .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 22px;
            text-decoration: none;
        }

        body .login-container .welcome-title {
            text-align: center;
            font-size: 26px;
            font-weight: 700;
            letter-spacing: 0.2px;
            margin-bottom: 8px;
            color: var(--text);
        }

        body .login-container .welcome-subtitle {
            text-align: center;
            font-size: 14px;
            color: var(--muted);
            margin-bottom: 26px;
        }

        /* Сообщение об ошибке */
        body .login-container .error-message {
            position: relative;
            margin-bottom: 20px;
            padding: 13px 40px 13px 16px;
            border-radius: 10px;
            background: rgba(242, 63, 66, 0.14);
            border: 1px solid rgba(242, 63, 66, 0.4);
            color: #ff8a8c;
            font-size: 14px;
            line-height: 1.55;
            text-align: left;
        }

        body .login-container .error-message .error-title { font-weight: 700; margin-bottom: 2px; }
        body .login-container .error-message .error-text  { color: inherit; }
        body .login-container .error-message .error-hint  { margin-top: 4px; font-size: 12.5px; opacity: 0.75; }

        body .login-container .error-message .error-close {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 24px;
            height: 24px;
            padding: 0;
            border: none;
            border-radius: 6px;
            background: transparent;
            color: inherit;
            font-size: 13px;
            line-height: 24px;
            cursor: pointer;
            opacity: 0.7;
            transition: opacity 0.2s, background 0.2s;
        }

        body .login-container .error-message .error-close:hover {
            opacity: 1;
            background: rgba(242, 63, 66, 0.2);
        }

        /* Поля */
        body .login-container .form-group { margin-bottom: 18px; }

        body .login-container .form-group label {
            display: block;
            margin-bottom: 8px;
            line-height: 16px;
            color: var(--label);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.7px;
        }

        body .login-container .form-group input {
            width: 100%;
            height: 48px;
            padding: 0 16px 0 44px;
            border: 2px solid transparent;
            outline: none;
            border-radius: 10px;
            background-color: var(--field);
            background-repeat: no-repeat;
            background-position: 14px center;
            background-size: 18px 18px;
            color: var(--text);
            font-size: 15px;
            box-sizing: border-box;
            transition: border-color 0.2s, box-shadow 0.2s, background-color 0.2s;
        }

        body .login-container .form-group input::placeholder { color: var(--placeholder); }

        /* Иконки в полях рисуются ОТДЕЛЬНЫМ элементом поверх поля, а не фоном самого input:
           Chrome убирает background-image у автозаполненных (сохранённых) полей, и иконки пропадали. */
        body .login-container .form-group { position: relative; }

        body .login-container .form-group:nth-of-type(1)::before,
        body .login-container .form-group:nth-of-type(2)::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 38px;               /* подпись 16px + отступ 8px + (48px поле − 20px иконка) / 2 */
            width: 20px;
            height: 20px;
            background-repeat: no-repeat;
            background-position: center;
            background-size: contain;
            pointer-events: none;
            z-index: 2;
            transition: filter 0.2s;
        }

        body .login-container .form-group:nth-of-type(1)::before { background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cdefs%3E%3ClinearGradient id='g' gradientUnits='userSpaceOnUse' x1='3' y1='3' x2='21' y2='21'%3E%3Cstop offset='0' stop-color='%2338b6ff'/%3E%3Cstop offset='.5' stop-color='%235865f2'/%3E%3Cstop offset='1' stop-color='%239a6bff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg stroke='%2314183f' stroke-width='4.2' opacity='.85'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21a8 8 0 0 1 16 0'/%3E%3C/g%3E%3Cg stroke='url(%23g)' stroke-width='2.2'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21a8 8 0 0 1 16 0'/%3E%3C/g%3E%3C/svg%3E"); }
        body .login-container .form-group:nth-of-type(2)::before { background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cdefs%3E%3ClinearGradient id='g' gradientUnits='userSpaceOnUse' x1='3' y1='3' x2='21' y2='21'%3E%3Cstop offset='0' stop-color='%2338b6ff'/%3E%3Cstop offset='.5' stop-color='%235865f2'/%3E%3Cstop offset='1' stop-color='%239a6bff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg stroke='%2314183f' stroke-width='4.2' opacity='.85'%3E%3Crect x='4' y='11' width='16' height='10' rx='2'/%3E%3Cpath d='M8 11V7a4 4 0 0 1 8 0v4'/%3E%3C/g%3E%3Cg stroke='url(%23g)' stroke-width='2.2'%3E%3Crect x='4' y='11' width='16' height='10' rx='2'/%3E%3Cpath d='M8 11V7a4 4 0 0 1 8 0v4'/%3E%3C/g%3E%3C/svg%3E"); }

        /* Поле выделено (в фокусе) — иконка ярче */
        body .login-container .form-group:nth-of-type(1):focus-within::before { background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cdefs%3E%3ClinearGradient id='g' gradientUnits='userSpaceOnUse' x1='3' y1='3' x2='21' y2='21'%3E%3Cstop offset='0' stop-color='%237fdcff'/%3E%3Cstop offset='.5' stop-color='%238a96ff'/%3E%3Cstop offset='1' stop-color='%23c39bff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg stroke='%2314183f' stroke-width='4.2' opacity='.85'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21a8 8 0 0 1 16 0'/%3E%3C/g%3E%3Cg stroke='url(%23g)' stroke-width='2.2'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21a8 8 0 0 1 16 0'/%3E%3C/g%3E%3C/svg%3E"); }
        body .login-container .form-group:nth-of-type(2):focus-within::before { background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cdefs%3E%3ClinearGradient id='g' gradientUnits='userSpaceOnUse' x1='3' y1='3' x2='21' y2='21'%3E%3Cstop offset='0' stop-color='%237fdcff'/%3E%3Cstop offset='.5' stop-color='%238a96ff'/%3E%3Cstop offset='1' stop-color='%23c39bff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg stroke='%2314183f' stroke-width='4.2' opacity='.85'%3E%3Crect x='4' y='11' width='16' height='10' rx='2'/%3E%3Cpath d='M8 11V7a4 4 0 0 1 8 0v4'/%3E%3C/g%3E%3Cg stroke='url(%23g)' stroke-width='2.2'%3E%3Crect x='4' y='11' width='16' height='10' rx='2'/%3E%3Cpath d='M8 11V7a4 4 0 0 1 8 0v4'/%3E%3C/g%3E%3C/svg%3E"); }

        body .login-container .form-group input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(88, 101, 242, 0.18);
        }

        /* Автозаполнение браузера (сохранённый пароль): вместо светло-голубого оставляем тёмное поле */
        body .login-container .form-group input:-webkit-autofill,
        body .login-container .form-group input:-webkit-autofill:hover,
        body .login-container .form-group input:-webkit-autofill:active {
            -webkit-text-fill-color: var(--text) !important;
            caret-color: var(--text);
            -webkit-box-shadow: 0 0 0 1000px var(--field) inset !important;
            box-shadow: 0 0 0 1000px var(--field) inset !important;
            transition: background-color 600000s 0s, color 600000s 0s, border-color 0.2s;
        }

        body .login-container .form-group input:-webkit-autofill:focus {
            -webkit-text-fill-color: var(--text) !important;
            caret-color: var(--text);
            -webkit-box-shadow: 0 0 0 1000px var(--field) inset, 0 0 0 4px rgba(88, 101, 242, 0.18) !important;
            box-shadow: 0 0 0 1000px var(--field) inset, 0 0 0 4px rgba(88, 101, 242, 0.18) !important;
            transition: background-color 600000s 0s, color 600000s 0s, border-color 0.2s;
        }

        body .login-container .form-group input:autofill {
            background-color: var(--field) !important;
            color: var(--text) !important;
        }

        /* Ошибка в поле — красный */
        body .login-container .form-group input.error,
        body .login-container .form-group input.invalid,
        body .login-container .form-group input.is-invalid,
        body .login-container .form-group input.has-error,
        body .login-container .form-group.error input,
        body .login-container .form-group.has-error input {
            border-color: var(--red);
            background-color: rgba(242, 63, 66, 0.07);
            box-shadow: 0 0 0 4px rgba(242, 63, 66, 0.16);
        }

        body .login-container .field-error {
            margin-top: 7px;
            font-size: 13px;
            font-weight: 600;
            color: #ff7a7c;
        }

        body .login-container .field-error:empty { display: none; }

        /* Запомнить меня */
        .remember-me {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 4px 0 18px;
            color: var(--label, #b5bac1);
            font-size: 14px;
            cursor: pointer;
            user-select: none;
        }

        .remember-me input[type="checkbox"] {
            width: 18px;
            height: 18px;
            margin: 0;
            cursor: pointer;
            accent-color: #5865f2;
        }

        /* Кнопка «Войти» */
        body .login-container .btn-login {
            width: 100%;
            height: 50px;
            margin-top: 2px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(135deg, #5865f2 0%, #3a4bea 100%);
            color: #fff;
            font-size: 15px;
            font-weight: 700;
            letter-spacing: 0.3px;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(58, 75, 234, 0.35);
            transition: transform 0.12s, box-shadow 0.2s, filter 0.2s;
        }

        body .login-container .btn-login:hover:not(:disabled) {
            filter: brightness(1.08);
            box-shadow: 0 10px 26px rgba(58, 75, 234, 0.5);
        }

        body .login-container .btn-login:active:not(:disabled) { transform: translateY(1px); }
        body .login-container .btn-login:disabled { opacity: 0.5; cursor: not-allowed; box-shadow: none; }

        /* Разделитель «или» */
        body .login-container .auth-divider {
            display: flex;
            align-items: center;
            gap: 14px;
            margin: 22px 0;
            color: var(--muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        body .login-container .auth-divider::before,
        body .login-container .auth-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--line);
        }

        body .login-container .auth-divider span { background: none; padding: 0; }

        /* Кнопка Google */
        body .login-container .btn-google {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: 100%;
            height: 48px;
            box-sizing: border-box;
            border: 1px solid var(--line);
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.04);
            color: var(--text);
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.2s, border-color 0.2s, transform 0.12s;
        }

        body .login-container .btn-google:hover {
            background: rgba(255, 255, 255, 0.09);
            border-color: rgba(255, 255, 255, 0.22);
        }

        body[data-theme="light"] .login-container .btn-google { background: rgba(255, 255, 255, 0.6); }
        body[data-theme="light"] .login-container .btn-google:hover { background: #fff; border-color: rgba(0, 0, 0, 0.2); }

        body .login-container .btn-google:active { transform: translateY(1px); }
        body .login-container .btn-google__icon { width: 20px; height: 20px; flex: 0 0 auto; }

        body .login-container .qr-login-toggle {
            display: flex;
            width: 100%;
            min-height: 48px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 12px;
            margin-bottom: 10px;
            border: 1px solid var(--line);
            border-radius: 10px;
            background: rgba(255, 255, 255, .04);
            color: var(--text);
            font: inherit;
            font-size: 14px;
            font-weight: 650;
            cursor: pointer;
        }
        .qr-login-toggle svg { width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 1.8; }
        body .login-container .qr-login-panel {
            margin-top: 14px;
            padding: 18px;
            border: 1px solid var(--line);
            border-radius: 14px;
            background: rgba(255, 255, 255, .035);
            text-align: center;
        }
        .qr-login-panel[hidden] { display: none !important; }
        .qr-login-panel h2 { margin: 0 0 6px; color: var(--text); font-size: 17px; }
        .qr-login-panel p { margin: 6px 0; color: var(--muted); font-size: 13px; line-height: 1.5; }
        .qr-login-image { display: grid; place-items: center; min-height: 210px; margin: 12px 0; border-radius: 12px; background: #fff; }
        .qr-login-image svg { display: block; width: 200px; max-width: 100%; height: auto; }
        .qr-login-status { min-height: 20px; }
        .qr-login-close { padding: 8px 14px; border: 0; background: transparent; color: var(--link); font: inherit; font-weight: 650; cursor: pointer; }

        /* Ссылки внизу */
        body .login-container .footer-links {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            gap: 14px;
            margin-top: 22px;
            padding-top: 0;
            border-top: 0;
            font-size: 14px;
        }

        body .login-container .footer-links a {
            color: var(--link);
            font-weight: 700;
            text-decoration: none;
        }

        body .login-container .footer-links a:hover { text-decoration: underline; }

        body .login-container .footer-links .divider {
            width: 1px;
            height: 14px;
            background: var(--line);
        }

        @media (max-width: 520px) {
            body .login-container { padding: 28px 20px 24px; border-radius: 14px; }
            body .login-container::before { border-radius: 14px 14px 0 0; }
            body .login-container .welcome-title { font-size: 23px; }
        }

        @media (prefers-reduced-motion: reduce) {
            body .login-container * { transition: none !important; }
        }
    </style>
</head>
<body data-theme="<?= $theme ?>">

    <div class="login-background" aria-hidden="true"></div>

    <div class="login-container">

        <button class="theme-toggle-btn" id="themeToggleBtn">
            <img src="images/change.svg" alt="Меню" class="theme-icon">
        </button>

        <div class="theme-menu" id="themeMenu">
            <button class="theme-item <?= $theme === 'dark' ? 'active' : '' ?>" data-theme="dark">
                <span class="theme-option">
                    <span class="theme-dot dark"></span>
                    Тёмная
                </span>
                <span class="theme-check"><?= $theme === 'dark' ? '✓' : '' ?></span>
            </button>

            <button class="theme-item <?= $theme === 'light' ? 'active' : '' ?>" data-theme="light">
                <span class="theme-option">
                    <span class="theme-dot light"></span>
                    Светлая
                </span>
                <span class="theme-check"><?= $theme === 'light' ? '✓' : '' ?></span>
            </button>

            <button class="theme-item <?= $theme === 'system' ? 'active' : '' ?>" data-theme="system">
                <span class="theme-option">
                    <span class="theme-dot system"></span>
                    Системная
                </span>
                <span class="theme-check"><?= $theme === 'system' ? '✓' : '' ?></span>
            </button>
        </div>

        <a href="index.php" class="logo">
            <img src="images/logo_type.svg" alt="SPACE" height="56" style="width:auto;height:56px;display:block;">
        </a>

        <div class="welcome-title">Добро пожаловать!</div>
        <div class="welcome-subtitle">Рады снова видеть вас</div>

        <?php if (!empty($error)): ?>
            <div class="error-message" id="errorMessage">
                <div class="error-content">
                    <div class="error-title">Ошибка входа</div>
                    <div class="error-text"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
                    <div class="error-hint">Проверьте введённые данные и попробуйте снова.</div>
                </div>
                <button class="error-close" id="errorClose" aria-label="Закрыть">✕</button>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php" id="loginForm" novalidate>
            <div class="form-group">
                <label for="login">ЛОГИН ИЛИ EMAIL</label>
                <input 
                    type="text" 
                    id="login" 
                    name="login" 
                    placeholder="Введите логин или email" 
                    value="<?= htmlspecialchars($saved_login, ENT_QUOTES, "UTF-8") ?>" 
                    required 
                    autofocus
                >
                <div class="field-error" id="loginError"></div>
            </div>

            <div class="form-group">
                <label for="password">ПАРОЛЬ</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    placeholder="Введите пароль" 
                    required
                >
                <div class="field-error" id="passwordError"></div>
            </div>

            <!-- Чекбокс "Запомнить меня" -->
            <label class="remember-me">
                <input type="checkbox" name="remember" id="remember" <?= isset($_POST['remember']) && $_POST['remember'] === 'on' ? 'checked' : '' ?>>
                <span>Запомнить меня</span>
            </label>

            <button type="submit" name="login" class="btn-login">Войти</button>
        </form>

        <div class="auth-divider"><span>или</span></div>

        <button type="button" class="qr-login-toggle" id="qrLoginToggle" aria-expanded="false" aria-controls="qrLoginPanel">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zm4 4h3v3h-3zm0-4h3m-7 7h3"/></svg>
            Войти по QR-коду из приложения
        </button>
        <section class="qr-login-panel" id="qrLoginPanel" hidden aria-live="polite">
            <h2>Вход по QR-коду</h2>
            <p>Откройте V SPACE на телефоне, нажмите «Войти на компьютере» и отсканируйте код.</p>
            <div class="qr-login-image" id="qrLoginImage"></div>
            <p class="qr-login-status" id="qrLoginStatus">Подготавливаем QR-код…</p>
            <button type="button" class="qr-login-close" id="qrLoginClose">Отмена</button>
        </section>

        <a href="api/google_login.php?from=login" class="btn-google" data-google-login>
            <svg class="btn-google__icon" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
            </svg>
            <span class="btn-google__text">Войти через Google</span>
        </a>

        <div class="footer-links">
            <a href="register.php" data-auth-switch>Регистрация</a>
            <span class="divider"></span>
            <a href="forgot_password.php">Забыли пароль?</a>
        </div>

    </div>

    <script src="assets/js/login.js"></script>
    <script src="assets/js/qrcode-generator.js"></script>
    <script src="assets/js/qr-login.js"></script>
</body>
</html>
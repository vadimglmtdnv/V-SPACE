<?php
/**
 * Example SMTP settings for PHPMailer.
 * Set these values in your local environment; do not commit credentials.
 */
return [
    'host'       => getenv('SMTP_HOST') ?: 'smtp.gmail.com',
    'port'       => (int)(getenv('SMTP_PORT') ?: 587),
    'encryption' => getenv('SMTP_ENCRYPTION') ?: 'tls',
    'username'   => getenv('SMTP_USERNAME') ?: '',
    'password'   => getenv('SMTP_PASSWORD') ?: '',
    'from_email' => getenv('SMTP_FROM_EMAIL') ?: '',
    'from_name'  => getenv('SMTP_FROM_NAME') ?: 'V-SPACE',
    'debug'      => 0,
];

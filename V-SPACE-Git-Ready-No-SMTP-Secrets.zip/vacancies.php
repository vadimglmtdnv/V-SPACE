<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

/* =========================================================
   V SPACE — СПИСОК ВАКАНСИЙ
   ========================================================= */

$db = db_connect();

if ($db->connect_error) {
    die('Ошибка подключения к базе данных: ' . htmlspecialchars($db->connect_error));
}

$db->set_charset('utf8mb4');

$userId = (int)$_SESSION['user_id'];

/* =========================================================
   ПРОВЕРКА АДМИНИСТРАТОРА (ДЛЯ TINYINT(1))
   ========================================================= */

// Проверяем через сессию
$isAdmin = false;

// Если в сессии есть is_admin и он равен 1 (как число)
if (isset($_SESSION['is_admin']) && (int)$_SESSION['is_admin'] === 1) {
    $isAdmin = true;
}

// Дополнительная проверка через БД (для синхронизации)
$stmt = $db->prepare("SELECT is_admin FROM users WHERE id = ? LIMIT 1");
if ($stmt) {
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $currentUser = $result->fetch_assoc();
    $stmt->close();
    
    // Если в БД is_admin = 1, обновляем сессию
    if ($currentUser && isset($currentUser['is_admin']) && (int)$currentUser['is_admin'] === 1) {
        $isAdmin = true;
        $_SESSION['is_admin'] = 1; // Синхронизируем сессию
    } else {
        // Если в БД is_admin = 0, очищаем сессию
        $_SESSION['is_admin'] = 0;
    }
}

/* =========================================================
   ПРОВЕРКА ТАБЛИЦЫ VACANCIES
   ========================================================= */
$tableCheck = $db->query("SHOW TABLES LIKE 'vacancies'");

if (!$tableCheck || $tableCheck->num_rows === 0) {
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Вакансии — V SPACE</title>
        <style>
            *{box-sizing:border-box}
            body{
                margin:0;
                min-height:100vh;
                display:flex;
                align-items:center;
                justify-content:center;
                background:#303136;
                color:#f1f1f3;
                font-family:Arial,Helvetica,sans-serif;
            }
            .card{
                width:min(520px,calc(100% - 30px));
                padding:30px;
                background:#1d1e21;
                border:1px solid #292a2f;
                border-radius:12px;
                box-shadow:0 10px 35px rgba(0,0,0,.25);
            }
            h1{margin:0 0 12px;font-size:23px}
            p{
                margin:0 0 18px;
                color:#999ba4;
                line-height:1.6;
                font-size:14px;
            }
            code{
                display:block;
                padding:13px;
                margin-bottom:18px;
                border-radius:7px;
                background:#25262a;
                color:#b7beff;
                font-size:12px;
                overflow:auto;
            }
            a{
                display:inline-block;
                padding:11px 18px;
                background:#5865f2;
                color:#fff;
                border-radius:7px;
                text-decoration:none;
                font-size:13px;
                font-weight:700;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <h1>Таблица вакансий не найдена</h1>
            <p>
                Файл <b>vacancies.php</b> работает, но в базе данных
                <b><?= htmlspecialchars(DB_NAME, ENT_QUOTES, 'UTF-8') ?></b> ещё нет таблицы <b>vacancies</b>.
            </p>

            <code>CREATE TABLE vacancies (...)</code>

            <p>
                Выполни SQL из файла <b>vacancies.sql</b> в phpMyAdmin,
                после этого страница откроется нормально.
            </p>

            <a href="index.php">Вернуться</a>
        </div>
    </body>
    </html>
    <?php
    exit;
}

/* =========================================================
   ПОЛУЧЕНИЕ ВАКАНСИЙ
   ========================================================= */
$vacancies = [];

$sql = "
    SELECT
        id,
        title,
        company,
        location,
        salary,
        employment,
        experience,
        description,
        created_at
    FROM vacancies
    ORDER BY created_at DESC, id DESC
";

$result = $db->query($sql);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $vacancies[] = $row;
    }
}

function vacancyEscape($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function shortDescription($text, $length = 180): string
{
    $text = trim(strip_tags((string)$text));

    if (function_exists('mb_strlen') && mb_strlen($text, 'UTF-8') > $length) {
        return mb_substr($text, 0, $length, 'UTF-8') . '...';
    }

    if (strlen($text) > $length) {
        return substr($text, 0, $length) . '...';
    }

    return $text;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Вакансии — V SPACE</title>

    <style>
        *{box-sizing:border-box}

        html,body{
            margin:0;
            padding:0;
            min-height:100%;
        }

        body{
            background:#303136;
            color:#f1f1f3;
            font-family:Arial,Helvetica,sans-serif;
        }

        a{
            color:inherit;
            text-decoration:none;
        }

        /* =====================================================
           HEADER
        ===================================================== */

        .top-header{
            height:57px;
            position:fixed;
            top:0;
            left:0;
            right:0;
            z-index:1000;

            display:flex;
            align-items:center;
            justify-content:space-between;

            padding:0 16px;

            background:#1d1e21;
            border-bottom:1px solid #34353a;
        }

        .logo{
            display:flex;
            align-items:center;
            gap:5px;

            font-size:18px;
            font-weight:700;
        }

        .logo-v{
            color:#5865f2;
            font-size:25px;
            font-weight:900;
        }

        .logo-space{
            color:#e8e8ea;
        }

        .header-actions{
            display:flex;
            align-items:center;
            gap:18px;
        }

        .header-icon{
            color:#dfe3ea;
            font-size:19px;
        }

        .header-avatar{
            width:38px;
            height:38px;
            border-radius:50%;

            display:flex;
            align-items:center;
            justify-content:center;

            background:#5865f2;
        }

        /* =====================================================
           PAGE
        ===================================================== */

        .page{
            width:min(1000px,calc(100% - 30px));
            margin:0 auto;
            padding:82px 0 110px;
        }

        .breadcrumbs{
            display:flex;
            align-items:center;
            gap:8px;

            color:#858791;
            font-size:13px;
            margin-bottom:15px;
        }

        .breadcrumbs a:hover{
            color:#5865f2;
        }

        .page-header{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:20px;

            margin-bottom:18px;
        }

        .page-title{
            margin:0;
            font-size:27px;
        }

        .page-subtitle{
            margin-top:6px;
            color:#858791;
            font-size:13px;
        }

        /* =====================================================
           КНОПКА СОЗДАНИЯ
        ===================================================== */
        .create-button{
            flex-shrink:0;

            padding:11px 17px;
            border-radius:7px;

            background:#5865f2;
            color:#fff;

            font-size:13px;
            font-weight:700;

            transition:.2s;
        }

        .create-button:hover{
            background:#6875ff;
            transform:translateY(-1px);
        }

        /* =====================================================
           VACANCY CARDS
        ===================================================== */

        .vacancies{
            display:flex;
            flex-direction:column;
            gap:12px;
        }

        .vacancy-card{
            position:relative;
            overflow:hidden;

            padding:20px;

            background:#1d1e21;
            border:1px solid #292a2f;
            border-radius:12px;

            box-shadow:0 5px 20px rgba(0,0,0,.15);

            transition:.2s;
        }

        .vacancy-card:hover{
            border-color:#3e4358;
            transform:translateY(-1px);
        }

        .vacancy-card:before{
            content:"";

            position:absolute;
            left:0;
            top:0;
            bottom:0;

            width:3px;

            background:#5865f2;
        }

        .vacancy-top{
            display:flex;
            justify-content:space-between;
            gap:15px;
        }

        .vacancy-title{
            margin:0 0 7px;

            font-size:19px;
            line-height:1.35;
        }

        .vacancy-title:hover{
            color:#7d88ff;
        }

        .vacancy-company{
            color:#aeb0b8;
            font-size:13px;
        }

        .vacancy-date{
            flex-shrink:0;
            color:#6f717b;
            font-size:11px;
        }

        .vacancy-description{
            margin-top:15px;

            color:#999ba4;
            font-size:13px;
            line-height:1.6;
        }

        .vacancy-info{
            display:flex;
            flex-wrap:wrap;
            gap:7px;

            margin-top:15px;
        }

        .info-item{
            display:flex;
            align-items:center;
            gap:6px;

            padding:7px 9px;

            background:#25262a;
            border:1px solid #323338;
            border-radius:6px;

            color:#bfc0c6;
            font-size:11px;
        }

        .info-icon{
            color:#5865f2;
        }

        .salary{
            color:#55d98b;
            font-weight:700;
        }

        .vacancy-bottom{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:15px;

            margin-top:17px;
            padding-top:14px;

            border-top:1px solid #2b2c31;
        }

        .open-link{
            color:#7d88ff;
            font-size:12px;
            font-weight:700;
        }

        .open-link:hover{
            color:#a1a8ff;
        }

        .vacancy-id{
            color:#666872;
            font-size:10px;
        }

        /* =====================================================
           EMPTY
        ===================================================== */

        .empty{
            padding:50px 25px;
            text-align:center;

            background:#1d1e21;
            border:1px solid #292a2f;
            border-radius:12px;
        }

        .empty-icon{
            margin-bottom:12px;
            font-size:40px;
        }

        .empty-title{
            margin-bottom:7px;
            font-size:17px;
            font-weight:700;
        }

        .empty-text{
            color:#858791;
            font-size:13px;
        }

        /* =====================================================
           BOTTOM NAV
        ===================================================== */

        .bottom-nav{
            position:fixed;
            left:50%;
            bottom:10px;
            transform:translateX(-50%);

            z-index:900;

            display:flex;
            align-items:center;
            gap:22px;

            width:max-content;
            max-width:calc(100% - 20px);

            padding:11px 16px;

            background:#191a1d;
            border:1px solid #2d2e33;
            border-radius:13px;

            box-shadow:0 8px 30px rgba(0,0,0,.35);

            overflow-x:auto;
        }

        .nav-item{
            display:flex;
            align-items:center;
            gap:5px;

            white-space:nowrap;

            color:#c6c7cb;
            font-size:10px;
            font-weight:700;
        }

        .nav-item:hover,
        .nav-item.active{
            color:#5865f2;
        }

        .nav-icon{
            font-size:15px;
        }

        @media(max-width:800px){
            .page-header{
                align-items:flex-start;
                flex-direction:column;
            }

            .create-button{
                width:100%;
                text-align:center;
            }

            .bottom-nav{
                justify-content:flex-start;
                width:calc(100% - 12px);
                gap:13px;
            }
        }

        @media(max-width:600px){
            .page{
                width:calc(100% - 20px);
            }

            .page-title{
                font-size:23px;
            }

            .vacancy-card{
                padding:17px;
            }

            .vacancy-top{
                flex-direction:column;
                gap:8px;
            }

            .vacancy-date{
                order:-1;
            }

            .nav-item span:not(.nav-icon){
                display:none;
            }

            .nav-item{
                font-size:18px;
            }
        }
    </style>
</head>

<body>

<header class="top-header">

    <a href="index.php" class="logo">
        <span class="logo-v">V</span>
        <span class="logo-space">SPACE</span>
    </a>

    <div class="header-actions">
        <a href="verification.php" class="header-icon">🛡</a>
        <a href="notifications.php" class="header-icon">🔔</a>
        <a href="profile.php" class="header-avatar">👤</a>
    </div>

</header>

<main class="page">

    <div class="breadcrumbs">
        <a href="index.php">Главная</a>
        <span>›</span>
        <span>Вакансии</span>
    </div>

    <div class="page-header">

        <div>
            <h1 class="page-title">Вакансии</h1>

            <div class="page-subtitle">
                Актуальные вакансии V SPACE
            </div>
        </div>

        <!-- =====================================================
             КНОПКА СОЗДАНИЯ
             Показываем только если пользователь админ (is_admin = 1)
        ===================================================== -->
        <?php if ($isAdmin): ?>
            <a href="create-vacancy.php" class="create-button">
                ＋ Создать вакансию
            </a>
        <?php endif; ?>

    </div>

    <section class="vacancies">

        <?php if (!$vacancies): ?>

            <div class="empty">
                <div class="empty-icon">💼</div>

                <div class="empty-title">
                    Пока нет вакансий
                </div>

                <div class="empty-text">
                    <?php if ($isAdmin): ?>
                        Создайте первую вакансию для пользователей V SPACE.
                    <?php else: ?>
                        Новые вакансии появятся здесь.
                    <?php endif; ?>
                </div>
            </div>

        <?php else: ?>

            <?php foreach ($vacancies as $vacancy): ?>

                <article class="vacancy-card">

                    <div class="vacancy-top">

                        <div>
                            <a
                                href="vacancy-detail.php?id=<?= (int)$vacancy['id'] ?>"
                                class="vacancy-title"
                            >
                                <?= vacancyEscape($vacancy['title']) ?>
                            </a>

                            <div class="vacancy-company">
                                <?= vacancyEscape($vacancy['company']) ?>
                            </div>
                        </div>

                        <div class="vacancy-date">
                            <?= !empty($vacancy['created_at'])
                                ? vacancyEscape(date('d.m.Y', strtotime($vacancy['created_at'])))
                                : ''
                            ?>
                        </div>

                    </div>

                    <?php if (!empty($vacancy['description'])): ?>

                        <div class="vacancy-description">
                            <?= vacancyEscape(shortDescription($vacancy['description'])) ?>
                        </div>

                    <?php endif; ?>

                    <div class="vacancy-info">

                        <?php if (!empty($vacancy['salary'])): ?>

                            <div class="info-item">
                                <span class="info-icon">💰</span>
                                <span class="salary">
                                    <?= vacancyEscape($vacancy['salary']) ?>
                                </span>
                            </div>

                        <?php endif; ?>

                        <?php if (!empty($vacancy['location'])): ?>

                            <div class="info-item">
                                <span class="info-icon">📍</span>
                                <?= vacancyEscape($vacancy['location']) ?>
                            </div>

                        <?php endif; ?>

                        <?php if (!empty($vacancy['employment'])): ?>

                            <div class="info-item">
                                <span class="info-icon">💼</span>
                                <?= vacancyEscape($vacancy['employment']) ?>
                            </div>

                        <?php endif; ?>

                        <?php if (!empty($vacancy['experience'])): ?>

                            <div class="info-item">
                                <span class="info-icon">⌛</span>
                                <?= vacancyEscape($vacancy['experience']) ?>
                            </div>

                        <?php endif; ?>

                    </div>

                    <div class="vacancy-bottom">

                        <span class="vacancy-id">
                            Вакансия #<?= (int)$vacancy['id'] ?>
                        </span>

                        <a
                            href="vacancy-detail.php?id=<?= (int)$vacancy['id'] ?>"
                            class="open-link"
                        >
                            Подробнее →
                        </a>

                    </div>

                </article>

            <?php endforeach; ?>

        <?php endif; ?>

    </section>

</main>

<nav class="bottom-nav">

    <a href="profile.php" class="nav-item">
        <span class="nav-icon">👤</span>
        <span>ПРОФИЛЬ</span>
    </a>

    <a href="index.php" class="nav-item">
        <span class="nav-icon">📰</span>
        <span>НОВОСТИ</span>
    </a>

    <a href="messages.php" class="nav-item">
        <span class="nav-icon">💬</span>
        <span>СООБЩЕНИЯ</span>
    </a>

    <a href="friends.php" class="nav-item">
        <span class="nav-icon">👥</span>
        <span>ДРУЗЬЯ</span>
    </a>

    <a href="communities.php" class="nav-item">
        <span class="nav-icon">●</span>
        <span>СООБЩЕСТВА</span>
    </a>

    <a href="photos.php" class="nav-item">
        <span class="nav-icon">◉</span>
        <span>ФОТО</span>
    </a>

    <a href="music.php" class="nav-item">
        <span class="nav-icon">♫</span>
        <span>МУЗЫКА</span>
    </a>

    <a href="video.php" class="nav-item">
        <span class="nav-icon">▶</span>
        <span>ВИДЕО</span>
    </a>

    <a href="favorites.php" class="nav-item">
        <span class="nav-icon">★</span>
        <span>ИЗБРАННОЕ</span>
    </a>

</nav>

</body>
</html>
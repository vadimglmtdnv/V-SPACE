<?php

require_once __DIR__ . '/includes/db.php';
/**
 * V+ (рубли ₽): состояние окна и автоматическая покупка подписки.
 * Заявок и подтверждений нет — при покупке ₽ списываются, V+ включается сразу.
 * Цены берутся ТОЛЬКО из БД (vplus_rub_plans), клиенту доверяется лишь номер тарифа.
 */
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

class VplusUserError extends Exception {}

function out(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function planFinal(int $cost, int $discount): int
{
    $discount = max(0, min(90, $discount));
    return max(1, (int)round($cost * (100 - $discount) / 100));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    out(['ok' => false, 'error' => 'Метод не поддерживается.'], 405);
}
if (empty($_SESSION['user_id'])) {
    out(['ok' => false, 'error' => 'Войдите в аккаунт.'], 401);
}
$uid = (int)$_SESSION['user_id'];
if (empty($_SESSION['vplus_csrf'])) {
    $_SESSION['vplus_csrf'] = bin2hex(random_bytes(32));
}

try {
    $conn = db_connect();
    $conn->set_charset("utf8mb4");

    // ---- Схема: рублёвый баланс, тарифы, заказы ----
    $col = $conn->query("SHOW COLUMNS FROM users LIKE 'rub_balance'");
    $need = $col->num_rows === 0;
    $col->close();
    if ($need) {
        try {
            $conn->query("ALTER TABLE users ADD COLUMN rub_balance INT UNSIGNED NOT NULL DEFAULT 0");
        } catch (mysqli_sql_exception $e) {
            if ((int)$e->getCode() !== 1060) throw $e;
        }
    }
    $conn->query("
        CREATE TABLE IF NOT EXISTS vplus_rub_plans (
            months INT UNSIGNED NOT NULL,
            label VARCHAR(50) NOT NULL,
            days INT UNSIGNED NOT NULL,
            cost INT UNSIGNED NOT NULL,
            discount_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
            updated_by INT UNSIGNED NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (months)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $conn->query("
        INSERT IGNORE INTO vplus_rub_plans (months, label, days, cost)
        VALUES (1, '1 месяц', 30, 149), (3, '3 месяца', 90, 399), (12, '12 месяцев', 365, 1290)
    ");
    $conn->query("
        CREATE TABLE IF NOT EXISTS vplus_orders (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            label VARCHAR(50) NOT NULL,
            days INT UNSIGNED NOT NULL,
            amount INT UNSIGNED NOT NULL,
            status ENUM('paid','canceled') NOT NULL DEFAULT 'paid',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX idx_vplus_orders_user (user_id, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (Throwable $e) {
    error_log('vplus.php init error: ' . $e->getMessage());
    out(['ok' => false, 'error' => 'Сервис временно недоступен.'], 503);
}

function buildState(mysqli $conn, int $uid): array
{
    $stmt = $conn->prepare("SELECT is_premium, premium_expires, rub_balance FROM users WHERE id = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $u = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    $expTs = !empty($u['premium_expires']) ? (int)strtotime($u['premium_expires']) : 0;
    $active = !empty($u['is_premium']) && ($expTs === 0 || $expTs > time());

    $plans = [];
    $res = $conn->query("SELECT months, label, days, cost, discount_percent FROM vplus_rub_plans ORDER BY months");
    while ($r = $res->fetch_assoc()) {
        $final = planFinal((int)$r['cost'], (int)$r['discount_percent']);
        $plans[] = [
            'months' => (int)$r['months'],
            'label' => $r['label'],
            'base' => (int)$r['cost'],
            'discount' => (int)$r['discount_percent'],
            'final' => $final,
            'per_month' => (int)round($final / max(1, (int)$r['months'])),
            'saving' => 0,
            'best' => false,
        ];
    }
    // Экономия — относительно покупки тарифа «1 месяц» нужное число раз.
    $monthly = null;
    foreach ($plans as $p) {
        if ($p['months'] === 1) $monthly = $p['final'];
    }
    $bestIdx = -1; $bestSaving = 0;
    foreach ($plans as $i => $p) {
        if ($monthly !== null && $p['months'] > 1) {
            $plans[$i]['saving'] = max(0, $monthly * $p['months'] - $p['final']);
            if ($plans[$i]['saving'] > $bestSaving) { $bestSaving = $plans[$i]['saving']; $bestIdx = $i; }
        }
    }
    if ($bestIdx >= 0) $plans[$bestIdx]['best'] = true;

    // История: новые покупки (vplus_orders) + старые заявки (premium_orders), если таблица ещё есть.
    $history = [];
    $sql = "SELECT label, amount, status, created_at FROM vplus_orders WHERE user_id = ?
            UNION ALL
            SELECT CASE months WHEN 1 THEN '1 месяц' WHEN 3 THEN '3 месяца' WHEN 12 THEN '12 месяцев'
                       ELSE CONCAT(months, ' мес.') END,
                   price,
                   CASE status WHEN 'paid' THEN 'paid' ELSE 'canceled' END,
                   created_at
            FROM premium_orders WHERE user_id = ? AND status IN ('paid', 'cancelled')
            ORDER BY created_at DESC LIMIT 10";
    try {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $uid, $uid);
        $stmt->execute();
    } catch (Throwable $e) {
        // Старой таблицы нет (или другая кодировка) — берём только новые покупки.
        $stmt = $conn->prepare("SELECT label, amount, status, created_at FROM vplus_orders WHERE user_id = ? ORDER BY id DESC LIMIT 10");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
    }
    $hr = $stmt->get_result();
    while ($h = $hr->fetch_assoc()) {
        $history[] = [
            'date' => date('d.m.Y', strtotime($h['created_at'])),
            'label' => $h['label'],
            'amount' => (int)$h['amount'],
            'status' => $h['status'],
        ];
    }
    $stmt->close();

    return [
        'ok' => true,
        'csrf' => $_SESSION['vplus_csrf'],
        'active' => $active,
        'expires' => $expTs ? date('d.m.Y', $expTs) : null,
        'days_left' => $active && $expTs ? (int)ceil(($expTs - time()) / 86400) : 0,
        'balance' => (int)($u['rub_balance'] ?? 0),
        'plans' => $plans,
        'history' => $history,
    ];
}

$action = (string)($_POST['action'] ?? 'state');

if ($action === 'state') {
    out(buildState($conn, $uid));
}

if ($action === 'buy') {
    if (!hash_equals((string)$_SESSION['vplus_csrf'], (string)($_POST['csrf'] ?? ''))) {
        out(['ok' => false, 'error' => 'Сессия устарела. Обновите страницу.'], 419);
    }
    $months = (int)($_POST['months'] ?? 0);
    $expected = (int)($_POST['expected'] ?? -1);

    try {
        $conn->begin_transaction();

        // Блокируем строку пользователя ДО проверки баланса — параллельные клики не потратят ₽ дважды.
        $stmt = $conn->prepare("SELECT rub_balance, premium_expires FROM users WHERE id = ? FOR UPDATE");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$u) throw new VplusUserError('Пользователь не найден.');

        $stmt = $conn->prepare("SELECT label, days, cost, discount_percent FROM vplus_rub_plans WHERE months = ?");
        $stmt->bind_param("i", $months);
        $stmt->execute();
        $plan = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$plan) throw new VplusUserError('Тариф не найден.');

        $price = planFinal((int)$plan['cost'], (int)$plan['discount_percent']);
        if ($expected !== $price) {
            throw new VplusUserError('Цена изменилась. Проверьте новую цену и повторите.');
        }
        if ((int)$u['rub_balance'] < $price) {
            throw new VplusUserError('Недостаточно средств: не хватает ' . number_format($price - (int)$u['rub_balance'], 0, ',', ' ') . ' ₽.');
        }

        // Продление идёт от текущей даты окончания, а не от «сегодня».
        $current = !empty($u['premium_expires']) ? (int)strtotime($u['premium_expires']) : 0;
        $newExpires = date('Y-m-d H:i:s', max($current, time()) + (int)$plan['days'] * 86400);

        $stmt = $conn->prepare("
            UPDATE users
            SET rub_balance = rub_balance - ?, is_premium = 1, premium_type = 'v_plus',
                premium_expires = ?, donation_amount = donation_amount + ?, last_premium_activation = NOW()
            WHERE id = ?
        ");
        $stmt->bind_param("isii", $price, $newExpires, $price, $uid);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO vplus_orders (user_id, label, days, amount, status) VALUES (?, ?, ?, ?, 'paid')");
        $days = (int)$plan['days'];
        $stmt->bind_param("isii", $uid, $plan['label'], $days, $price);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
    } catch (VplusUserError $e) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
        $state = buildState($conn, $uid);
        $state['ok'] = false;
        $state['error'] = $e->getMessage();
        out($state, 422);
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
        error_log('vplus.php buy error: ' . $e->getMessage());
        out(['ok' => false, 'error' => 'Не удалось оформить подписку. Попробуйте позже.'], 500);
    }

    $state = buildState($conn, $uid);
    $state['message'] = 'V+ активирован до ' . $state['expires'] . '!';
    out($state);
}

out(['ok' => false, 'error' => 'Неизвестное действие.'], 400);

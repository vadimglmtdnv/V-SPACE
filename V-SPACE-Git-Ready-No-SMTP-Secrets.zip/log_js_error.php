<?php
// Приёмник ошибок JavaScript с клиента → error.txt
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
if (!is_file(__DIR__ . '/includes/error_logger.php')) { http_response_code(204); exit; }
require_once __DIR__ . '/includes/error_logger.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    http_response_code(204);
    exit;
}

// Защита от флуда: не больше 30 записей за сессию в час
$now = time();
if (empty($_SESSION['js_err_window']) || $now - $_SESSION['js_err_window'] > 3600) {
    $_SESSION['js_err_window'] = $now;
    $_SESSION['js_err_count'] = 0;
}
if (++$_SESSION['js_err_count'] > 30) {
    http_response_code(204);
    exit;
}

$data = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($data)) {
    http_response_code(204);
    exit;
}

$cut = fn($v, int $n) => mb_substr(trim((string)($v ?? '')), 0, $n);

site_log_error(
    'JS',
    $cut($data['message'] ?? '', 500),
    $cut($data['source'] ?? '', 300),
    (int)($data['line'] ?? 0),
    $cut($data['stack'] ?? '', 1500) . ($data['page'] ?? '' ? "\npage: " . $cut($data['page'], 300) : '')
);

http_response_code(204);

<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/shell.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

/*
|--------------------------------------------------------------------------
| PLAYERCHAT — Избранное (личные фото)
|--------------------------------------------------------------------------
| Здесь сохраняются только фотографии. Они статично показываются
| в блоке «Избранные фото» на index.php и profile.php.
|--------------------------------------------------------------------------
*/

// Подключение к базе данных
$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// Проверка авторизации
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

// Получение данных пользователя
$stmt = $conn->prepare("
    SELECT id, username, email, avatar, status, last_seen, is_admin
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$username = $user["username"];
$user_avatar = $user["avatar"] ?? '';
$user_letter = mb_substr($username ?: "Я", 0, 1, "UTF-8");
$user_status = $user["status"] ?? 'offline';
$last_seen = $user["last_seen"] ?? null;
$is_admin = isset($user["is_admin"]) && $user["is_admin"] == 1;

// Функции
function isOnline($status) {
    return $status === 'online';
}

function formatLastSeen($datetime) {
    if (empty($datetime)) {
        return 'Неизвестно';
    }
    
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) {
        return 'Только что';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' ' . getMinutesWord($minutes) . ' назад';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' ' . getHoursWord($hours) . ' назад';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' ' . getDaysWord($days) . ' назад';
    } else {
        return date('d.m.Y H:i', $timestamp);
    }
}

function getMinutesWord($n) {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'минут';
    $n = $n % 10;
    if ($n == 1) return 'минуту';
    if ($n >= 2 && $n <= 4) return 'минуты';
    return 'минут';
}

function getHoursWord($n) {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'часов';
    $n = $n % 10;
    if ($n == 1) return 'час';
    if ($n >= 2 && $n <= 4) return 'часа';
    return 'часов';
}

function getDaysWord($n) {
    $n = $n % 100;
    if ($n >= 11 && $n <= 19) return 'дней';
    $n = $n % 10;
    if ($n == 1) return 'день';
    if ($n >= 2 && $n <= 4) return 'дня';
    return 'дней';
}

// Общий модуль «Избранные фото»
require_once __DIR__ . '/favorite_photos.php';
ensureFavoritePhotosTable($conn);

// CSRF-токен
if (empty($_SESSION['csrf_favorite'])) {
    $_SESSION['csrf_favorite'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_favorite'];

const FAVORITE_MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 МБ на фото
const FAVORITE_MAX_PER_UPLOAD = 20;             // за одну отправку

$flash_error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        die("Недействительный токен формы.");
    }

    $action = $_POST['action'] ?? '';

    // ---- Добавление фото (сохраняются ТОЛЬКО изображения) ----
    if ($action === 'add' && isset($_FILES['photos'])) {
        $allowed = [
            "image/jpeg" => "jpg",
            "image/png"  => "png",
            "image/webp" => "webp",
            "image/gif"  => "gif",
        ];

        $upload_dir = __DIR__ . '/' . FAVORITE_PHOTOS_DIR;
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $names  = (array)$_FILES['photos']['name'];
        $tmps   = (array)$_FILES['photos']['tmp_name'];
        $errors = (array)$_FILES['photos']['error'];
        $sizes  = (array)$_FILES['photos']['size'];

        $saved = 0;
        $rejected = 0;
        $finfo = finfo_open(FILEINFO_MIME_TYPE);

        for ($i = 0; $i < min(count($names), FAVORITE_MAX_PER_UPLOAD); $i++) {
            if ($errors[$i] !== UPLOAD_ERR_OK) {
                if ($errors[$i] !== UPLOAD_ERR_NO_FILE) {
                    $rejected++;
                }
                continue;
            }

            $mime = $finfo ? finfo_file($finfo, $tmps[$i]) : false;

            // Проверяем и MIME, и что файл реально является картинкой, и размер
            if (
                !isset($allowed[$mime]) ||
                @getimagesize($tmps[$i]) === false ||
                $sizes[$i] > FAVORITE_MAX_FILE_SIZE
            ) {
                $rejected++;
                continue;
            }

            $new_name = "fav_" . time() . "_" . $user_id . "_" . bin2hex(random_bytes(6)) . "." . $allowed[$mime];

            if (move_uploaded_file($tmps[$i], $upload_dir . $new_name)) {
                $db_path = FAVORITE_PHOTOS_DIR . $new_name;
                $stmt = $conn->prepare("INSERT INTO favorite_photos (user_id, image) VALUES (?, ?)");
                $stmt->bind_param("is", $user_id, $db_path);
                $stmt->execute();
                $stmt->close();
                $saved++;
            } else {
                $rejected++;
            }
        }

        if ($finfo) {
            finfo_close($finfo);
        }

        if ($rejected > 0) {
            $_SESSION['favorite_flash'] = "Не сохранено файлов: {$rejected}. Разрешены только изображения (JPG, PNG, WEBP, GIF) до 5 МБ.";
        }
    }

    // ---- Удаление фото ----
    if ($action === 'delete') {
        $photo_id = (int)($_POST['photo_id'] ?? 0);

        $stmt = $conn->prepare("SELECT image FROM favorite_photos WHERE id = ? AND user_id = ? LIMIT 1");
        $stmt->bind_param("ii", $photo_id, $user_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($row) {
            $stmt = $conn->prepare("DELETE FROM favorite_photos WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $photo_id, $user_id);
            $stmt->execute();
            $stmt->close();

            // Удаляем файл только из папки избранного
            if (strpos($row['image'], FAVORITE_PHOTOS_DIR) === 0) {
                $file = __DIR__ . '/' . $row['image'];
                if (is_file($file)) {
                    @unlink($file);
                }
            }
        }
    }

    header("Location: favorite.php");
    exit;
}

$flash_error = $_SESSION['favorite_flash'] ?? '';
unset($_SESSION['favorite_flash']);

// Получение фото
$photos = getFavoritePhotos($conn, $user_id);

/*
|--------------------------------------------------------------------------
| ОБОЛОЧКА СТРАНИЦЫ (шапка, уведомления, тема) — как в index.php
|--------------------------------------------------------------------------
*/

$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    $theme = $_GET['theme'];
    setcookie('theme', $theme, ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: favorite.php");
    exit;
}

$notifications = [];
$notif_count = 0;
$unread_count = 0;
$pending_reports_count = 0;
$current_user_data = [];

try {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) AS sender_name, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();

    $unread_count = shell_unread_messages($conn, $user_id);   // как в index.php: гаснет, когда открыт диалог

    $stmt = $conn->prepare("SELECT id, username, avatar, status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_user_data = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    if ($is_admin) {
        $result = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status = 'pending'");
        if ($result) {
            $pending_reports_count = (int)$result->fetch_assoc()['c'];
        }
    }
} catch (Throwable $e) {
    error_log('music.php shell: ' . $e->getMessage());
}

function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationTypeName(string $type): string {
    $names = [
        'friend_request' => 'Заявка в друзья',
        'friend_accepted' => 'Заявка принята',
        'friend_removed' => 'Удаление из друзей',
        'like' => 'Лайк',
        'comment' => 'Комментарий',
        'repost' => 'Репост',
        'message' => 'Сообщение',
        'news' => 'Новость',
        'tag' => 'Отметка',
        'mention' => 'Упоминание',
        'info' => 'Информация'
    ];
    return $names[$type] ?? 'Уведомление';
}

function getNotificationIcon(string $type): string {
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>Избранное</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/favorite.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/favorite.css') ?>">
    <link rel="stylesheet" href="assets/css/theme-switch.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/theme-switch.css') ?>">
    <script src="assets/js/header-dropdowns.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/header-dropdowns.js') ?>" defer></script>
    <script src="assets/js/theme-switch.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/theme-switch.js') ?>" defer></script>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme) ?>">

    <header class="header header-cosmic">
        <span class="header-shooting-stars" aria-hidden="true">
            <span class="sky-cloud" aria-hidden="true"></span>
            <span class="sky-rain" aria-hidden="true"></span>
            <span class="sky-snow" aria-hidden="true"></span>
            <span class="sky-fog" aria-hidden="true"></span>
            <span class="sky-flash" aria-hidden="true"></span>
            <span class="header-shooting-star star-one"></span>
            <span class="header-shooting-star star-two"></span>
            <span class="header-shooting-star star-three"></span>
            <span class="header-comet"></span>
        </span>
        <div class="header-left">
            <div class="logo">
                <div class="logo-icon">
                    <img src="images/logo_type.svg" alt="SPACE Logo" width="40" height="40">
                </div>
            </div>
        </div>
        <div class="search-box"></div>
        <div class="header-right">

            <?php if ($is_admin): ?>
                <a href="reports.php" class="moderation-btn" title="Модерация">
                <img src="images/protection.svg" alt="Модерация" class="moderation-icon">
                <?php if ($pending_reports_count > 0): ?>
                    <span class="moderation-badge"><?= $pending_reports_count > 99 ? '99+' : $pending_reports_count ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>

            <div class="notifications-wrapper">
                <button class="notifications-btn" id="notificationsBtn" title="Уведомления">
                    <?php include __DIR__ . '/includes/notification_bell.php'; ?>
                    <?php if ($notif_count > 0): ?>
                        <span class="notifications-badge" id="notificationsBadge"><?= $notif_count > 99 ? '99+' : $notif_count ?></span>
                    <?php else: ?>
                        <span class="notifications-badge" id="notificationsBadge" style="display:none;">0</span>
                    <?php endif; ?>
                </button>
                <div class="notifications-dropdown" id="notificationsDropdown">
                    <div class="notifications-header">
                        <span class="notifications-title">Уведомления</span>
                        <div class="notifications-header-actions">
                            <?php if ($notif_count > 0): ?>
                                <button class="mark-all-read-btn" id="markAllReadBtn">Все прочитано</button>
                            <?php endif; ?>
                            <span class="notifications-count" id="notificationsCount"><?= $notif_count ?> новых</span>
                        </div>
                    </div>
                    <div class="notifications-list" id="notificationsList">
                        <?php if (empty($notifications)): ?>
                            <div class="notifications-empty">
                                <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
                                <div class="empty-text">Нет уведомлений</div>
                                <div class="empty-sub">Здесь будут появляться ваши уведомления</div>
                            </div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notif): 
                                $icon = getNotificationIcon((string)$notif['type']);
                                $notif_type_class = $notif['type'];
                                $sender_avatar = $notif['sender_avatar'] ?? '';
                                $sender_name = $notif['sender_name'] ?? '';
                                
                                $avatar_exists = false;
                                if (!empty($sender_avatar)) {
                                    $paths_to_check = [
                                        $sender_avatar,
                                        'uploads/avatars/' . basename($sender_avatar),
                                        'assets/images/' . basename($sender_avatar)
                                    ];
                                    foreach ($paths_to_check as $path) {
                                        if (file_exists($path)) {
                                            $avatar_exists = true;
                                            $sender_avatar = $path;
                                            break;
                                        }
                                    }
                                }
                            ?>
                                <a href="<?= htmlspecialchars($notif['link'] ?: '#') ?>" class="notification-item <?= $notif['is_read'] ? 'read' : 'unread' ?> type-<?= htmlspecialchars($notif_type_class) ?>" data-notification-id="<?= $notif['id'] ?>">
                                    <div class="notif-avatar-wrapper">
                                        <div class="notif-avatar">
                                            <?php if ($avatar_exists): ?>
                                                <img src="<?= htmlspecialchars($sender_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?>">
                                            <?php elseif (!empty($sender_name)): ?>
                                                <span class="avatar-letter"><?= htmlspecialchars(mb_strtoupper(mb_substr($sender_name, 0, 1, 'UTF-8'), 'UTF-8')) ?></span>
                                            <?php else: ?>
                                                <span class="avatar-letter">?</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="notif-content">
                                        <div class="notif-text">
                                            <?php if (!empty($sender_name)): ?>
                                                <?php
                                                // Ник уже выведен жирным — не повторяем его в начале текста («Vadim Vadim поставил(а)…»)
                                                $notif_msg = (string)$notif['message'];
                                                if (mb_strpos($notif_msg, (string)$sender_name) === 0) {
                                                    $notif_msg = ltrim(mb_substr($notif_msg, mb_strlen((string)$sender_name)));
                                                }
                                                ?>
                                                <strong class="notif-sender"><?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?></strong><span class="notif-message"><?= htmlspecialchars($notif_msg, ENT_QUOTES, "UTF-8") ?></span>
                                            <?php else: ?>
                                                <span class="notif-message"><?= htmlspecialchars($notif['message'], ENT_QUOTES, "UTF-8") ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="notif-meta">
                                            <span class="notif-time"><?= timeAgo($notif['created_at']) ?></span>
                                        </div>
                                    </div>
                                    <?php if (!$notif['is_read']): ?>
                                        <span class="notif-dot"></span>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="notifications-footer">
                        <a href="notifications.php" class="view-all-notifications">Показать всё</a>
                    </div>
                </div>
            </div>

            <div class="avatar-dropdown">
                <?php
                $current_avatar = $current_user_data['avatar'] ?? '';
                $current_username = $current_user_data['username'] ?? 'Пользователь';
                require_once __DIR__ . '/includes/display_name.php'; $current_username = userDisplayName($conn ?? null, (int)($_SESSION['user_id'] ?? 0), (string)$current_username);
                $current_letter = mb_strtoupper(mb_substr($current_username, 0, 1, 'UTF-8'), 'UTF-8');
                $current_status = 'online';
                ?>
                <button class="header-avatar <?= isOnline($current_status) ? 'is-online' : 'is-offline' ?>" id="avatarBtn" title="Мой профиль" aria-label="Мой профиль">
                    <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                        <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                    <?php else: ?>
                        <?= htmlspecialchars($current_letter) ?>
                    <?php endif; ?>
                </button>
                <div class="dropdown-menu" id="avatarDropdown">
                    <div class="dropdown-header">
                        <div class="dropdown-avatar">
                            <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                                <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                            <?php else: ?>
                                <?= htmlspecialchars($current_letter) ?>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-user-info">
                            <div class="dropdown-username"><?= htmlspecialchars($current_username) ?></div>
                        </div>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a href="settings.php" class="dropdown-item">
                        <span class="dropdown-icon">⚙</span> Настройки
                    </a>
                    <div class="theme-trigger" id="themeTrigger">
                        <span class="dropdown-icon">🎨</span>
                        <span>Тема</span>
                        <span class="theme-current">
                            <?php
                            $theme_name = 'Тёмная';
                            if ($theme === 'light') $theme_name = 'Светлая';
                            elseif ($theme === 'system') $theme_name = 'Системная';
                            echo htmlspecialchars($theme_name);
                            ?>
                        </span>
                        <span class="theme-arrow" id="themeArrow">▼</span>
                    </div>

                    <div class="theme-submenu" id="themeSubmenu">
                        <a href="?theme=dark" class="theme-item <?= $theme === 'dark' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot dark"></span>
                                Тёмная
                            </span>
                            <?php if ($theme === 'dark'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="?theme=light" class="theme-item <?= $theme === 'light' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot light"></span>
                                Светлая
                            </span>
                            <?php if ($theme === 'light'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="?theme=system" class="theme-item <?= $theme === 'system' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot system"></span>
                                Системная
                            </span>
                            <?php if ($theme === 'system'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a href="logout.php" class="dropdown-item logout-item">
                        <span class="dropdown-icon">↪</span> Выйти
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="layout favorite-layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main class="favorite-main">

            <section class="card favorite-head">
                <div class="favorite-head-title">
                    <span class="favorite-head-icon"><img src="images/nav-favorite.svg" alt=""></span>
                    <div>
                        <h1>Избранные фото</h1>
                        <p>Они показываются в блоке «Избранные фото» на вашей странице</p>
                    </div>
                </div>
                <?php if (!empty($photos)): ?>
                    <span class="favorite-count"><?= count($photos) ?></span>
                <?php endif; ?>
            </section>

            <?php if ($flash_error !== ''): ?>
                <div class="alert error"><?= htmlspecialchars($flash_error, ENT_QUOTES, "UTF-8") ?></div>
            <?php endif; ?>

            <section class="card favorite-block">
                <?php if (empty($photos)): ?>
                    <div class="empty">
                        <div class="empty-icon"><img src="images/nav-favorite.svg" alt=""></div>
                        <div>Пока нет фото</div>
                        <div class="empty-hint">Загрузите фото — они появятся на вашей странице.</div>
                    </div>
                <?php else: ?>
                    <div class="photos-grid">
                        <?php foreach ($photos as $photo): ?>
                            <div class="photo-item">
                                <a href="<?= htmlspecialchars($photo["image"], ENT_QUOTES, "UTF-8") ?>" target="_blank" rel="noopener">
                                    <img src="<?= htmlspecialchars($photo["image"], ENT_QUOTES, "UTF-8") ?>" alt="" loading="lazy">
                                </a>
                                <form method="POST" action="favorite.php" class="photo-delete-form"
                                      onsubmit="return confirm('Удалить это фото?')">
                                    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, "UTF-8") ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="photo_id" value="<?= (int)$photo["id"] ?>">
                                    <button type="submit" title="Удалить">✕</button>
                                </form>
                                <div class="photo-time"><?= date("d.m.Y H:i", strtotime($photo["created_at"])) ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </main>

        <div class="site-footer">
            &copy; <span class="year">2026</span>
        </div>

    </div>

    <script src="assets/js/script.js"></script>

</body>
</html>
<?php
$conn->close();

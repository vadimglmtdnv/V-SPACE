<?php


require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

if (isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

require_once 'includes/PHPMailer/src/PHPMailer.php';
require_once 'includes/PHPMailer/src/SMTP.php';
require_once 'includes/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

function ensureUsersTable(mysqli $conn): bool {
    $table_exists = $conn->query("SHOW TABLES LIKE 'users'")->num_rows > 0;

    if (!$table_exists) {
        $sql = "CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            status ENUM('online', 'offline', 'away') DEFAULT 'offline',
            last_seen DATETIME NULL,
            verification_token VARCHAR(64) NULL,
            token_expiry DATETIME NULL,
            verified BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            timezone VARCHAR(64) NOT NULL DEFAULT 'UTC'
        )";
        if (!$conn->query($sql)) {
            die("Ошибка создания таблицы: " . $conn->error);
        }
        return true;
    }

    $result = $conn->query("SHOW COLUMNS FROM users");
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }

    foreach (['verification_token', 'token_expiry', 'verified', 'timezone'] as $column) {
        if (!in_array($column, $columns)) {
            $type = $column === 'verified'
                ? 'BOOLEAN DEFAULT FALSE'
                : ($column === 'verification_token'
                    ? 'VARCHAR(64) NULL'
                    : ($column === 'token_expiry' ? 'DATETIME NULL' : "VARCHAR(64) NOT NULL DEFAULT 'UTC'"));
            $conn->query("ALTER TABLE users ADD COLUMN $column $type");
        }
    }
    return true;
}

ensureUsersTable($conn);

$error = "";
$success = "";
$form_data = ["username" => "", "email" => ""];

// Ошибка входа через Google (коды и тексты — в api/google_errors.php)
$googleErrors = require __DIR__ . '/api/google_errors.php';
if (isset($_GET['google_error'])) {
    $googleCode = $_GET['google_error'];
    $error = (is_string($googleCode) && isset($googleErrors[$googleCode]))
        ? $googleErrors[$googleCode]
        : $googleErrors['server'];
}

/**
 * Отправляет письмо с кодом. Возвращает null при успехе или строку с ошибкой.
 */
function sendConfirmationEmail(string $email, string $username, string $token): ?string {
    $mail = new PHPMailer(true);
    $providerKey = 'unknown';

    try {
        if (!file_exists(__DIR__ . '/mail_config.php')) {
            return "Файл mail_config.php не найден рядом с register.php.";
        }

        $mailConfig = require __DIR__ . '/mail_config.php';
        if (!is_array($mailConfig)) {
            return "mail_config.php должен возвращать массив.";
        }

        $providers = is_array($mailConfig['providers'] ?? null) ? $mailConfig['providers'] : [];

        $recipientDomain = strtolower(substr(strrchr($email, '@') ?: '', 1));
        if ($recipientDomain === 'gmail.com' || $recipientDomain === 'googlemail.com') {
            $providerKey = 'gmail';
        } elseif (in_array($recipientDomain, ['mail.ru','inbox.ru','list.ru','bk.ru','internet.ru'], true)) {
            $providerKey = 'mailru';
        } elseif (in_array($recipientDomain, ['yandex.ru','ya.ru','yandex.com','yandex.by','yandex.kz','yandex.ua'], true)) {
            $providerKey = 'yandex';
        } else {
            $providerKey = (string)($mailConfig['default_provider'] ?? 'mailru');
        }

        $provider = $providers[$providerKey] ?? null;
        $defaultProviderKey = (string)($mailConfig['default_provider'] ?? 'mailru');
        $defaultProvider = $providers[$defaultProviderKey] ?? null;
        $providerPassword = is_array($provider) ? preg_replace('/\s+/', '', (string)($provider['password'] ?? '')) : '';
        $defaultPassword = is_array($defaultProvider) ? preg_replace('/\s+/', '', (string)($defaultProvider['password'] ?? '')) : '';

        if (
            (!is_array($provider) || $providerPassword === '' || str_contains($providerPassword, 'ВСТАВЬ') || str_contains($providerPassword, 'ПАРОЛЬ_ПРИЛОЖЕНИЯ')) &&
            is_array($defaultProvider) &&
            $defaultPassword !== ''
        ) {
            $providerKey = $defaultProviderKey;
            $provider = $defaultProvider;
        }

        if (!is_array($provider)) {
            return "Провайдер «{$providerKey}» не настроен в mail_config.php.";
        }

        $host       = trim((string)($provider['host'] ?? ''));
        $smtpUser   = trim((string)($provider['username'] ?? ''));
        $smtpPass   = preg_replace('/\s+/', '', (string)($provider['password'] ?? ''));
        $port       = (int)($provider['port'] ?? 465);
        $encryption = strtolower(trim((string)($provider['encryption'] ?? 'ssl')));

        if ($host === '')     return "Не указан SMTP host для «{$providerKey}».";
        if ($smtpUser === '') return "Не указан SMTP логин для «{$providerKey}».";
        if (!filter_var($smtpUser, FILTER_VALIDATE_EMAIL)) {
            return "SMTP логин для «{$providerKey}» должен быть email-адресом.";
        }
        if ($smtpPass === '') return "Не указан пароль приложения для «{$providerKey}».";
        if (str_contains($smtpPass, 'ВСТАВЬ') || str_contains($smtpPass, 'ПАРОЛЬ_ПРИЛОЖЕНИЯ')) {
            return "В mail_config.php не заменён пароль для «{$providerKey}».";
        }

        // Быстрая проверка TCP-доступности SMTP
        $socketHost = ($encryption === 'starttls' ? 'tcp://' : 'ssl://') . $host;
        $fp = @fsockopen($socketHost, $port, $errno, $errstr, 10);
        if (!$fp) {
            return "Не удаётся подключиться к {$host}:{$port} ({$errstr}). Хостинг может блокировать SMTP.";
        }
        fclose($fp);

        $mail->isSMTP();
        $mail->SMTPAuth   = true;
        $mail->Host       = $host;
        $mail->Username   = $smtpUser;
        $mail->Password   = $smtpPass;
        $mail->Port       = $port;
        $mail->SMTPSecure = $encryption === 'starttls'
            ? PHPMailer::ENCRYPTION_STARTTLS
            : PHPMailer::ENCRYPTION_SMTPS;
        $mail->Timeout    = 20;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom($smtpUser);
        $mail->addReplyTo($smtpUser);
        $mail->addAddress($email, $username);

        $mail->isHTML(true);
        $mail->Subject = 'Проверочный код';

        $safeUsername = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $safeCode     = htmlspecialchars($token, ENT_QUOTES, 'UTF-8');

        $mail->Body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .content { padding: 30px; background: #f9f9f9; border-radius: 0 0 8px 8px; }
                .token-code { background: #e8e8e8; padding: 10px; border-radius: 4px;
                              font-family: monospace; word-break: break-all; }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='content'>
                    <p>Привет, $safeUsername!</p>
                    <p>Чтобы завершить регистрацию, подтвердите, что эта почта принадлежит вам.</p>
                    <p>Введите проверочный код на странице подтверждения:</p>
                    <p class='token-code' style='text-align:center;font-size:34px;letter-spacing:8px;font-weight:700;color:#5865f2;'>$safeCode</p>
                    <p><small>Код действителен в течение 24 часов.</small></p>
                    <hr>
                    <p style='color:#888;font-size:14px;'>Если вы не запрашивали этот код, проигнорируйте это письмо.</p>
                    <p>С заботой,<br><strong>Команда</strong></p>
                </div>
                <div class='footer'>
                    <p>Это автоматическое сообщение, пожалуйста, не отвечайте на него.</p>
                </div>
            </div>
        </body>
        </html>
        ";

        $mail->AltBody = "Привет, $username!\n\nВаш код подтверждения: $token\n\nКод действителен 24 часа.\n\nКоманда";

        $mail->send();
        return null;

    } catch (Exception $e) {
        $err = $mail->ErrorInfo ?: $e->getMessage();

        error_log(sprintf(
            "Ошибка отправки email: %s [provider=%s, host=%s, user=%s]",
            $err, $providerKey, $mail->Host ?: 'empty', $mail->Username ?: 'empty'
        ));

        $low = strtolower($err);

        if (str_contains($low, 'could not authenticate') || str_contains($low, 'username and password not accepted')) {
            return "SMTP отклонил логин/пароль для «{$providerKey}». "
                 . "Mail.ru требует пароль для внешнего приложения, Gmail — App Password (16 символов).";
        }
        if (str_contains($low, 'connection refused') || str_contains($low, 'could not connect')) {
            return "SMTP-сервер {$mail->Host} недоступен. Проверьте host/port.";
        }
        if (str_contains($low, 'ssl') || str_contains($low, 'tls')) {
            return "Ошибка шифрования SMTP для «{$providerKey}». Попробуйте порт 465 (ssl) или 587 (starttls).";
        }
        if (str_contains($low, 'from address') || str_contains($low, 'sender')) {
            return "Mail.ru/Gmail требуют, чтобы From совпадал с SMTP-логином.";
        }

        return "Ошибка SMTP: " . $err;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $password_confirm = $_POST["password_confirm"] ?? "";

    $form_data["username"] = $username;
    $form_data["email"]    = $email;

    if ($username === "" || $email === "" || $password === "") {
        $error = "Заполните все поля.";
    } elseif (strlen($username) < 3) {
        $error = "Имя пользователя должно содержать минимум 3 символа.";
    } elseif (strlen($password) < 6) {
        $error = "Пароль должен содержать минимум 6 символов.";
    } elseif ($password !== $password_confirm) {
        $error = "Пароли не совпадают.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Введите корректный email адрес.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1");
        $stmt->bind_param("ss", $email, $username);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($exists) {
            $error = "Пользователь с таким email или именем уже существует.";
        } else {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $verification_token = (string)random_int(100000, 999999);
            $token_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
            $timezone = trim((string)($_POST['timezone'] ?? 'UTC'));
            if (!in_array($timezone, DateTimeZone::listIdentifiers(), true)) {
                $timezone = 'UTC';
            }

            $stmt = $conn->prepare("
                INSERT INTO users (username, email, password, status, last_seen, verification_token, token_expiry, verified, timezone)
                VALUES (?, ?, ?, 'offline', NULL, ?, ?, 0, ?)
            ");
            $stmt->bind_param("ssssss", $username, $email, $password_hash, $verification_token, $token_expiry, $timezone);

            $conn->begin_transaction();

            if ($stmt->execute()) {
                $mailError = sendConfirmationEmail($email, $username, $verification_token);

                if ($mailError === null) {
                    $conn->commit();
                    $success = "✅ Регистрация успешна! На ваш email отправлено письмо с подтверждением.";
                    header("Location: verify.php");
                    exit;
                } else {
                    $conn->rollback();
                    // Показываем пользователю сразу несколько подсказок
                    $error = "❌ " . $mailError
                           . " Если не уверены, что настроить, посмотрите пример в mail_config.php.";
                }
                $stmt->close();
            } else {
                $conn->rollback();
                $error = "❌ Ошибка регистрации: " . $conn->error;
                $stmt->close();
            }
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>Регистрация</title>
    <link rel="stylesheet" href="assets/css/register.css">
    <link rel="stylesheet" href="assets/css/auth-shared.css">
    <script src="assets/js/auth-shared.js"></script>
    <style>
        /* ===== Оформление страницы регистрации (поверх assets/css/register.css) ===== */
        body .login-card {
            --accent: #5865f2;
            --green: #3ba55d;
            --red: #f23f42;
            --field: #1e1f22;
            --muted: #949ba4;
            position: relative;
            width: 100%;
            max-width: 460px;
            padding: 36px 34px 30px;
            background: rgba(43, 45, 49, 0.28);
            -webkit-backdrop-filter: blur(10px);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.07);
            border-radius: 18px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.45), 0 2px 0 rgba(255, 255, 255, 0.03) inset;
            overflow: hidden;
        }

        body .login-card::before {
            content: '';
            position: absolute;
            left: 0; right: 0; top: 0;
            height: 3px;
            background: linear-gradient(90deg, #3a4bea, #8f9bff, #3a4bea);
        }

        body .login-card .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 22px;
            text-decoration: none;
        }

        body .login-card .login-title {
            text-align: center;
            font-size: 26px;
            font-weight: 700;
            letter-spacing: 0.2px;
            margin-bottom: 8px;
        }

        body .login-card .login-subtitle {
            text-align: center;
            font-size: 14px;
            color: var(--muted);
            margin-bottom: 26px;
        }

        /* Сообщения */
        body .login-card .login-error,
        body .login-card .login-success {
            padding: 13px 16px;
            margin-bottom: 20px;
            border-radius: 10px;
            font-size: 14px;
            line-height: 1.55;
        }

        body .login-card .login-error {
            background: rgba(242, 63, 66, 0.14);
            border: 1px solid rgba(242, 63, 66, 0.4);
            color: #ff8a8c;
        }

        body .login-card .login-success {
            background: rgba(59, 165, 93, 0.14);
            border: 1px solid rgba(59, 165, 93, 0.45);
            color: #6fd58f;
        }

        /* Поля */
        body .login-card .form-group { margin-bottom: 18px; }

        body .login-card .form-label {
            display: block;
            margin-bottom: 8px;
            color: #b5bac1;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.7px;
        }

        body .login-card .form-input {
            --icon-left: none;
            --icon-right: none;
            width: 100%;
            height: 48px;
            padding: 0 44px 0 44px;
            border: 2px solid transparent;
            outline: none;
            border-radius: 10px;
            background-color: var(--field);
            background-image: var(--icon-left), var(--icon-right);
            background-repeat: no-repeat, no-repeat;
            background-position: 14px center, right 12px center;
            background-size: 18px 18px, 22px 22px;
            color: #f2f3f5;
            font-size: 15px;
            transition: border-color 0.2s, box-shadow 0.2s, background-color 0.2s;
        }

        body .login-card .form-input::placeholder { color: #6d6f78; }

        body .login-card #username         { --icon-left: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236d6f78' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21a8 8 0 0 1 16 0'/%3E%3C/svg%3E"); }
        body .login-card #email            { --icon-left: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236d6f78' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='5' width='18' height='14' rx='2'/%3E%3Cpath d='m3 7 9 6 9-6'/%3E%3C/svg%3E"); }
        body .login-card #password,
        body .login-card #password_confirm { --icon-left: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236d6f78' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='4' y='11' width='16' height='10' rx='2'/%3E%3Cpath d='M8 11V7a4 4 0 0 1 8 0v4'/%3E%3C/svg%3E"); }

        body .login-card .form-input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(88, 101, 242, 0.18);
        }

        /* Верно — зелёный */
        body .login-card .form-input.is-valid,
        body .login-card .form-input.valid,
        body .login-card .form-input.success {
            --icon-right: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Ccircle cx='12' cy='12' r='11' fill='%233ba55d'/%3E%3Cpath d='m7 12.5 3.2 3.2L17 9' fill='none' stroke='white' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
            border-color: var(--green);
            background-color: rgba(59, 165, 93, 0.07);
            box-shadow: 0 0 0 4px rgba(59, 165, 93, 0.16);
        }

        /* Ошибка — красный */
        body .login-card .form-input.is-invalid,
        body .login-card .form-input.invalid,
        body .login-card .form-input.error,
        body .login-card .form-input.has-error {
            --icon-right: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Ccircle cx='12' cy='12' r='11' fill='%23f23f42'/%3E%3Cpath d='m8.5 8.5 7 7m0-7-7 7' fill='none' stroke='white' stroke-width='2.4' stroke-linecap='round'/%3E%3C/svg%3E");
            border-color: var(--red);
            background-color: rgba(242, 63, 66, 0.07);
            box-shadow: 0 0 0 4px rgba(242, 63, 66, 0.16);
        }

        body .login-card .error-message {
            display: block;
            min-height: 0;
            margin-top: 7px;
            font-size: 13px;
            font-weight: 600;
            color: #ff7a7c;
        }

        body .login-card .error-message:empty { display: none; }

        /* Подсказка о совпадении паролей */
        body .login-card .match-hint {
            margin-top: 7px;
            font-size: 13px;
            font-weight: 600;
            min-height: 0;
        }

        body .login-card .match-hint.ok  { color: #6fd58f; }
        body .login-card .match-hint.bad { color: #ff7a7c; }
        body .login-card .match-hint:empty { display: none; }

        /* Кнопка */
        body .login-card .login-button {
            width: 100%;
            height: 50px;
            margin-top: 6px;
            border: none;
            border-radius: 10px;
            background: linear-gradient(135deg, #5865f2 0%, #3a4bea 100%);
            color: #fff;
            font-size: 15px;
            font-weight: 700;
            letter-spacing: 0.3px;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(58, 75, 234, 0.35);
            transition: transform 0.12s, box-shadow 0.2s, filter 0.2s;
        }

        body .login-card .login-button:hover:not(:disabled) {
            filter: brightness(1.08);
            box-shadow: 0 10px 26px rgba(58, 75, 234, 0.5);
        }

        body .login-card .login-button:active:not(:disabled) { transform: translateY(1px); }
        body .login-card .login-button:disabled { opacity: 0.5; cursor: not-allowed; box-shadow: none; }

        /* Разделитель «или» */
        body .login-card .auth-divider {
            display: flex;
            align-items: center;
            gap: 14px;
            margin: 22px 0;
            color: var(--muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        body .login-card .auth-divider::before,
        body .login-card .auth-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255, 255, 255, 0.09);
        }

        body .login-card .auth-divider span { background: none; padding: 0; }

        /* Кнопка Google */
        body .login-card .btn-google {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: 100%;
            height: 48px;
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.04);
            color: #f2f3f5;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.2s, border-color 0.2s, transform 0.12s;
        }

        body .login-card .btn-google:hover {
            background: rgba(255, 255, 255, 0.09);
            border-color: rgba(255, 255, 255, 0.22);
        }

        body .login-card .btn-google:active { transform: translateY(1px); }
        body .login-card .btn-google__icon { width: 20px; height: 20px; flex: 0 0 auto; }

        /* Ссылка «Войти» */
        body .login-card .register-link {
            margin-top: 22px;
            text-align: center;
            font-size: 14px;
            color: var(--muted);
        }

        body .login-card .register-link a {
            color: #8f9bff;
            font-weight: 700;
            text-decoration: none;
        }

        body .login-card .register-link a:hover { text-decoration: underline; }

        @media (max-width: 520px) {
            body .login-card { padding: 28px 20px 24px; border-radius: 14px; }
            body .login-card .login-title { font-size: 23px; }
        }

        @media (prefers-reduced-motion: reduce) {
            body .login-card * { transition: none !important; }
        }
    </style>
</head>
<body>
    <div class="login-background"></div>

    <div class="login-card">
        <a href="index.php" class="logo">
            <img src="images/logo_type.svg" alt="SPACE" height="56" style="width:auto;height:56px;display:block;">
        </a>

        <div class="login-title">Создать аккаунт</div>
        <div class="login-subtitle">Присоединяйтесь к нам</div>

        <?php if ($error !== ""): ?>
            <div class="login-error"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
        <?php endif; ?>

        <?php if ($success !== ""): ?>
            <div class="login-success"><?= htmlspecialchars($success, ENT_QUOTES, "UTF-8") ?></div>
        <?php endif; ?>

        <form id="registerForm" action="register.php" method="POST" novalidate>
            <input type="hidden" name="timezone" id="timezone" value="UTC">
            <div class="form-group">
                <label class="form-label" for="username">Имя пользователя</label>
                <input type="text" id="username" name="username" class="form-input" autocomplete="username"
                       placeholder="Введите имя пользователя"
                       value="<?= htmlspecialchars($form_data["username"], ENT_QUOTES, "UTF-8") ?>"
                       required minlength="3">
                <span class="error-message" id="usernameError"></span>
            </div>

            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input type="email" id="email" name="email" class="form-input" autocomplete="email"
                       placeholder="Введите email"
                       value="<?= htmlspecialchars($form_data["email"], ENT_QUOTES, "UTF-8") ?>"
                       required>
                <span class="error-message" id="emailError"></span>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Пароль</label>
                <input type="password" id="password" name="password" class="form-input" autocomplete="new-password"
                       placeholder="Минимум 6 символов" required minlength="6">
                <span class="error-message" id="passwordError"></span>
            </div>

            <div class="form-group">
                <label class="form-label" for="password_confirm">Подтвердите пароль</label>
                <input type="password" id="password_confirm" name="password_confirm" class="form-input" autocomplete="new-password"
                       placeholder="Повторите пароль" required>
                <span class="error-message" id="passwordConfirmError"></span>
                <div class="match-hint" id="matchHint" aria-live="polite"></div>
            </div>

            <button type="submit" class="login-button" id="submitBtn">Зарегистрироваться</button>
        </form>

        <div class="auth-divider"><span>или</span></div>

        <a href="api/google_login.php?from=register" class="btn-google" data-google-login>
            <svg class="btn-google__icon" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
            </svg>
            <span class="btn-google__text">Регистрация через Google</span>
        </a>

        <div class="register-link">
            Уже есть аккаунт?
            <a href="login.php" data-auth-switch>Войти</a>
        </div>
    </div>

    <script src="assets/js/register.js"></script>
    <script>
        // Живая подсветка полей: зелёный — верно, красный — неверно (не мешает assets/js/register.js)
        (function () {
            var u  = document.getElementById('username');
            var e  = document.getElementById('email');
            var p  = document.getElementById('password');
            var c  = document.getElementById('password_confirm');
            var mh = document.getElementById('matchHint');
            if (!u || !e || !p || !c) return;

            function mark(el, ok) {
                el.classList.toggle('is-valid', ok === true);
                el.classList.toggle('is-invalid', ok === false);
            }

            function checkUser()  { mark(u, u.value.length === 0 ? null : u.value.trim().length >= 3); }
            function checkEmail() { mark(e, e.value.length === 0 ? null : /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.value.trim())); }
            function checkPass()  { mark(p, p.value.length === 0 ? null : p.value.length >= 6); }
            function checkConf() {
                if (c.value.length === 0) { mark(c, null); mh.textContent = ''; mh.className = 'match-hint'; return; }
                var ok = c.value === p.value && p.value.length > 0;
                mark(c, ok);
                mh.textContent = ok ? 'Пароли совпадают' : 'Пароли не совпадают';
                mh.className = 'match-hint ' + (ok ? 'ok' : 'bad');
            }

            u.addEventListener('input', checkUser);
            e.addEventListener('input', checkEmail);
            p.addEventListener('input', function () { checkPass(); checkConf(); });
            c.addEventListener('input', checkConf);

            // если форма вернулась с ошибкой и поля уже заполнены
            checkUser(); checkEmail(); checkPass(); checkConf();
        })();
    </script>
</body>
</html>
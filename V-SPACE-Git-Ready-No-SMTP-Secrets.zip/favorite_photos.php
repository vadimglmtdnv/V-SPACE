<?php
/*
|--------------------------------------------------------------------------
| PLAYERCHAT — общий модуль «Избранные фото»
|--------------------------------------------------------------------------
| Подключается в favorite.php, profile.php и index.php:
|     require_once __DIR__ . '/favorite_photos.php';
|--------------------------------------------------------------------------
*/

if (!defined('FAVORITE_PHOTOS_DIR')) {
    define('FAVORITE_PHOTOS_DIR', 'uploads/favorites/');
}

if (!function_exists('ensureFavoritePhotosTable')) {
    function ensureFavoritePhotosTable(mysqli $conn): void
    {
        $conn->query("
            CREATE TABLE IF NOT EXISTS favorite_photos (
                id INT(11) NOT NULL AUTO_INCREMENT,
                user_id INT(11) NOT NULL,
                image VARCHAR(255) NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                INDEX user_id (user_id),
                INDEX created_at (created_at)
            ) ENGINE=InnoDB
            DEFAULT CHARSET=utf8mb4
            COLLATE=utf8mb4_unicode_ci
        ");
    }
}

if (!function_exists('getFavoritePhotos')) {
    /**
     * Возвращает фото пользователя (новые первыми). Записи, чьи файлы пропали с диска, пропускаются.
     */
    function getFavoritePhotos(mysqli $conn, int $userId, int $limit = 0): array
    {
        ensureFavoritePhotosTable($conn);

        $sql = "SELECT id, image, created_at FROM favorite_photos WHERE user_id = ? ORDER BY created_at DESC, id DESC";
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit;
        }

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        $photos = [];
        while ($row = $result->fetch_assoc()) {
            if (file_exists(__DIR__ . '/' . $row['image'])) {
                $photos[] = $row;
            }
        }
        $stmt->close();

        return $photos;
    }
}

if (!function_exists('renderFavoritePhotosCard')) {
    /**
     * Статичный блок «Избранные фото» (без загрузки/удаления — только просмотр).
     * Управление фото — на странице favorite.php.
     */
    function renderFavoritePhotosCard(array $photos, bool $showManageLink = true): void
    {
        static $stylePrintedOnce = false;

        if (!$stylePrintedOnce) {
            $stylePrintedOnce = true;
            ?>
            <style>
                .fav-photos-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px; }
                .fav-photos-grid a { display: block; aspect-ratio: 1 / 1; overflow: hidden; border-radius: 6px; background: #1e1f22; }
                .fav-photos-grid img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform .2s; }
                .fav-photos-grid a:hover img { transform: scale(1.06); }
                .fav-photos-empty { color: #949ba4; font-size: 13px; text-align: center; padding: 10px 0; }
                .fav-photos-link { display: block; margin-top: 10px; color: #5865f2; text-decoration: none; font-size: 13px; }
            </style>
            <?php
        }
        ?>
        <div class="right-card fav-photos-card">
            <a href="favorite.php" style="text-decoration:none;color:inherit;display:block;">
                <div class="right-title">
                    Избранные фото
                    <span style="font-size:13px;font-weight:400;margin-left:auto;opacity:.7;"><?= count($photos) ?></span>
                </div>
            </a>

            <?php if (empty($photos)): ?>
                <div class="fav-photos-empty">Пока нет фото</div>
            <?php else: ?>
                <div class="fav-photos-grid">
                    <?php foreach ($photos as $p): ?>
                        <a href="<?= htmlspecialchars($p['image'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener">
                            <img src="<?= htmlspecialchars($p['image'], ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy">
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($showManageLink): ?>
                <a href="favorite.php" class="fav-photos-link">Открыть избранное →</a>
            <?php endif; ?>
        </div>
        <?php
    }
}

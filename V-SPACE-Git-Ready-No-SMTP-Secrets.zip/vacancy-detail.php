<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

/* =========================================================
   НАСТРОЙКИ БД
   ========================================================= */
$db = db_connect();

if ($db->connect_error) {
    die('Ошибка подключения к базе данных: ' . htmlspecialchars($db->connect_error));
}

$db->set_charset('utf8mb4');

$userId = (int)$_SESSION['user_id'];
$vacancyId = (int)($_GET['id'] ?? 0);

if ($vacancyId <= 0) {
    header('Location: vacancies.php');
    exit;
}

/* =========================================================
   ПРОВЕРКА АДМИНИСТРАТОРА (ИСПРАВЛЕННАЯ)
   ========================================================= */
$isAdmin = !empty($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;

// Проверяем через БД для синхронизации
$stmt = $db->prepare("SELECT role FROM users WHERE id = ? LIMIT 1");
if ($stmt) {
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $userResult = $stmt->get_result();
    $currentUser = $userResult->fetch_assoc();
    $stmt->close();

    if (($currentUser['role'] ?? '') === 'admin') {
        $isAdmin = true;
        $_SESSION['is_admin'] = true; // Синхронизируем сессию
    }
}

/* =========================================================
   ПОЛУЧЕНИЕ ВАКАНСИИ
   ========================================================= */
$stmt = $db->prepare("SELECT * FROM vacancies WHERE id = ? LIMIT 1");
if (!$stmt) {
    die('Ошибка подготовки запроса');
}
$stmt->bind_param("i", $vacancyId);
$stmt->execute();
$vacancyResult = $stmt->get_result();
$vacancy = $vacancyResult->fetch_assoc();
$stmt->close();

if (!$vacancy) {
    http_response_code(404);
    die('Вакансия не найдена.');
}

/* =========================================================
   ОТКЛИК
   ========================================================= */
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'apply') {

    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $terms = isset($_POST['terms']) && $_POST['terms'] === '1';

    if ($firstName === '' || $lastName === '' || $phone === '' || $email === '') {
        $error = 'Заполните Имя, Фамилию, Телефон и Email.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Введите корректный Email.';
    } elseif (!$terms) {
        $error = 'Необходимо принять условия.';
    } else {

        /* Проверяем, не отправлял ли пользователь отклик ранее */
        $check = $db->prepare("
            SELECT id
            FROM vacancy_applications
            WHERE vacancy_id = ? AND user_id = ?
            LIMIT 1
        ");
        if ($check) {
            $check->bind_param("ii", $vacancyId, $userId);
            $check->execute();
            $alreadyApplied = $check->get_result()->fetch_assoc();
            $check->close();

            if ($alreadyApplied) {
                $error = 'Вы уже отправляли отклик на эту вакансию.';
            } else {

                $filePath = null;
                $fileName = null;

                /* =================================================
                   ФАЙЛ
                   ================================================= */
                if (!empty($_FILES['attachment']['name'])) {

                    if ($_FILES['attachment']['error'] !== UPLOAD_ERR_OK) {
                        $error = 'Не удалось загрузить файл.';
                    } elseif ($_FILES['attachment']['size'] > 10 * 1024 * 1024) {
                        $error = 'Размер файла не должен превышать 10 МБ.';
                    } else {

                        $allowedExtensions = [
                            'pdf',
                            'doc',
                            'docx',
                            'txt',
                            'zip'
                        ];

                        $originalName = $_FILES['attachment']['name'];
                        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

                        if (!in_array($extension, $allowedExtensions, true)) {
                            $error = 'Разрешены файлы PDF, DOC, DOCX, TXT и ZIP.';
                        } else {

                            $uploadDir = __DIR__ . '/uploads/vacancy_applications/';

                            if (!is_dir($uploadDir)) {
                                mkdir($uploadDir, 0755, true);
                            }

                            $safeName = preg_replace(
                                '/[^a-zA-Z0-9_\-\.]/',
                                '_',
                                pathinfo($originalName, PATHINFO_FILENAME)
                            );

                            $newFileName =
                                time() . '_' .
                                bin2hex(random_bytes(8)) . '_' .
                                $safeName . '.' . $extension;

                            $target = $uploadDir . $newFileName;

                            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $target)) {
                                $filePath = 'uploads/vacancy_applications/' . $newFileName;
                                $fileName = $originalName;
                            } else {
                                $error = 'Не удалось сохранить файл.';
                            }
                        }
                    }
                }

                if ($error === '') {

                    $stmt = $db->prepare("
                        INSERT INTO vacancy_applications
                        (vacancy_id, user_id, first_name, last_name, phone, email, message, file_path, file_name, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");

                    if ($stmt) {
                        $stmt->bind_param(
                            "iisssssss",
                            $vacancyId,
                            $userId,
                            $firstName,
                            $lastName,
                            $phone,
                            $email,
                            $message,
                            $filePath,
                            $fileName
                        );

                        if ($stmt->execute()) {
                            $success = 'Ваш отклик успешно отправлен!';
                            $_POST = [];
                        } else {
                            if ($filePath && file_exists(__DIR__ . '/' . $filePath)) {
                                unlink(__DIR__ . '/' . $filePath);
                            }

                            $error = 'Не удалось отправить отклик: ' . $stmt->error;
                        }

                        $stmt->close();
                    } else {
                        $error = 'Ошибка подготовки запроса';
                    }
                }
            }
        } else {
            $error = 'Ошибка проверки отклика';
        }
    }
}

/* =========================================================
   ПРОВЕРКА СОБСТВЕННОГО ОТКЛИКА
   ========================================================= */
$hasApplied = false;

$check = $db->prepare("
    SELECT id
    FROM vacancy_applications
    WHERE vacancy_id = ? AND user_id = ?
    LIMIT 1
");
if ($check) {
    $check->bind_param("ii", $vacancyId, $userId);
    $check->execute();
    $hasApplied = (bool)$check->get_result()->fetch_assoc();
    $check->close();
}

$requirements = array_filter(
    array_map('trim', preg_split('/\r\n|\r|\n/', (string)($vacancy['requirements'] ?? '')))
);

$conditions = array_filter(
    array_map('trim', preg_split('/\r\n|\r|\n/', (string)($vacancy['conditions'] ?? '')))
);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= htmlspecialchars($vacancy['title']) ?> — V SPACE</title>

    <style>
        *{box-sizing:border-box}
        html,body{margin:0;padding:0;min-height:100%}
        body{
            background:#303136;
            color:#f1f1f3;
            font-family:Arial,Helvetica,sans-serif;
        }
        a{color:inherit;text-decoration:none}

        .top-header{
            height:57px;
            position:fixed;
            top:0;left:0;right:0;
            z-index:1000;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:0 16px;
            background:#1d1e21;
            border-bottom:1px solid #34353a;
        }
        .logo{
            display:flex;
            align-items:center;
            gap:5px;
            font-size:18px;
            font-weight:700;
        }
        .logo-v{
            color:#5865f2;
            font-size:25px;
            font-weight:900;
        }
        .logo-space{color:#e8e8ea}
        .header-actions{display:flex;align-items:center;gap:18px}
        .header-icon{font-size:19px;color:#dfe3ea}
        .header-avatar{
            width:38px;height:38px;
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            background:#5865f2;
        }

        .page{
            max-width:1050px;
            margin:0 auto;
            padding:82px 20px 115px;
        }

        .breadcrumbs{
            display:flex;
            gap:8px;
            align-items:center;
            color:#858791;
            font-size:13px;
            margin-bottom:14px;
        }
        .breadcrumbs a:hover{color:#5865f2}

        .vacancy-card,
        .content-card,
        .sidebar-card{
            background:#1d1e21;
            border:1px solid #292a2f;
            border-radius:12px;
            box-shadow:0 5px 20px rgba(0,0,0,.15);
        }

        .vacancy-card{overflow:hidden}

        .vacancy-cover{
            height:155px;
            position:relative;
            background:
                radial-gradient(circle at 20% 80%,rgba(88,101,242,.55),transparent 35%),
                radial-gradient(circle at 85% 20%,rgba(75,85,190,.45),transparent 35%),
                linear-gradient(135deg,#5967ed,#38418f);
        }

        .vacancy-logo{
            position:absolute;
            left:28px;
            bottom:-40px;
            width:82px;
            height:82px;
            border-radius:20px;
            background:#1d1e21;
            border:5px solid #1d1e21;
            display:flex;
            align-items:center;
            justify-content:center;
            color:#5865f2;
            font-size:34px;
            font-weight:900;
            box-shadow:0 5px 15px rgba(0,0,0,.3);
        }

        .vacancy-main{padding:55px 28px 28px}
        .vacancy-title{
            margin:0 0 8px;
            font-size:27px;
            line-height:1.25;
        }
        .vacancy-company{
            color:#aeb0b8;
            font-size:14px;
            margin-bottom:22px;
        }
        .vacancy-company strong{color:#e7e7ea}

        .vacancy-info{
            display:flex;
            flex-wrap:wrap;
            gap:9px;
        }
        .info-item{
            display:flex;
            align-items:center;
            gap:7px;
            padding:9px 12px;
            background:#25262a;
            border:1px solid #323338;
            border-radius:8px;
            color:#c9cad0;
            font-size:13px;
        }
        .info-icon{color:#5865f2}
        .salary{color:#55d98b;font-weight:700}

        .content-layout{
            display:grid;
            grid-template-columns:minmax(0,1fr) 310px;
            gap:16px;
            margin-top:16px;
        }

        .content-card{padding:24px}
        .content-card + .content-card{margin-top:16px}

        .section-title{
            margin:0 0 17px;
            font-size:18px;
        }
        .section-title:before{
            content:"";
            display:inline-block;
            width:4px;
            height:18px;
            background:#5865f2;
            border-radius:3px;
            margin-right:9px;
            vertical-align:-3px;
        }

        .description{
            color:#b9bac1;
            font-size:14px;
            line-height:1.7;
        }

        .requirements{
            list-style:none;
            padding:0;
            margin:0;
        }
        .requirements li{
            position:relative;
            padding-left:24px;
            margin-bottom:12px;
            color:#c4c5ca;
            font-size:14px;
            line-height:1.5;
        }
        .requirements li:before{
            content:"✓";
            position:absolute;
            left:0;
            color:#5865f2;
            font-weight:bold;
        }

        .sidebar-card{
            padding:20px;
            height:fit-content;
            position:sticky;
            top:75px;
        }

        .sidebar-title{
            font-size:16px;
            font-weight:700;
            margin-bottom:15px;
        }

        .apply-button{
            width:100%;
            border:0;
            border-radius:7px;
            padding:12px 15px;
            background:#5865f2;
            color:#fff;
            font-size:14px;
            font-weight:700;
            cursor:pointer;
        }
        .apply-button:hover{background:#6875ff}

        .admin-create{
            display:block;
            width:100%;
            margin-top:10px;
            padding:10px;
            text-align:center;
            border:1px solid #3b3d45;
            border-radius:7px;
            color:#aeb4ff;
            font-size:13px;
        }
        .admin-create:hover{background:#25262a}

        .success{
            margin-bottom:15px;
            padding:11px 13px;
            border-radius:8px;
            background:rgba(50,205,120,.1);
            border:1px solid rgba(50,205,120,.25);
            color:#65dc98;
            font-size:13px;
        }

        .error{
            margin-bottom:15px;
            padding:11px 13px;
            border-radius:8px;
            background:rgba(220,70,70,.1);
            border:1px solid rgba(220,70,70,.25);
            color:#ff8585;
            font-size:13px;
        }

        /* =====================================================
           ФОРМА ОТКЛИКА
        ===================================================== */
        .application-form{
            display:none;
            margin-top:16px;
            padding:20px;
            border-radius:10px;
            background:#25262a;
            border:1px solid #34353b;
        }
        .application-form.open{display:block}

        .form-title{
            margin:0 0 5px;
            font-size:17px;
        }
        .form-subtitle{
            color:#858791;
            font-size:12px;
            line-height:1.5;
            margin-bottom:18px;
        }

        .form-grid{
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:12px;
        }
        .form-field.full{grid-column:1/-1}

        .form-field label{
            display:block;
            margin-bottom:6px;
            color:#cfd0d5;
            font-size:12px;
            font-weight:600;
        }
        .required{color:#5865f2}

        .form-field input,
        .form-field textarea{
            width:100%;
            border:1px solid #3a3b42;
            outline:none;
            border-radius:7px;
            background:#1d1e21;
            color:#f1f1f3;
            padding:10px;
            font:inherit;
            font-size:12px;
        }
        .form-field textarea{
            min-height:90px;
            resize:vertical;
        }
        .form-field input:focus,
        .form-field textarea:focus{
            border-color:#5865f2;
        }

        .file-box{
            position:relative;
            display:flex;
            align-items:center;
            gap:10px;
            padding:11px;
            border:1px dashed #454750;
            border-radius:7px;
            background:#1d1e21;
            cursor:pointer;
        }
        .file-box:hover{border-color:#5865f2}
        .file-box input{
            position:absolute;
            width:100%;
            height:100%;
            inset:0;
            opacity:0;
            cursor:pointer;
        }
        .file-icon{font-size:18px}
        .file-text{
            color:#aeb0b8;
            font-size:12px;
        }

        /* =====================================================
           ЧЕКБОКС С ГАЛОЧКОЙ
        ===================================================== */
        .terms{
            margin-top:14px;
        }

        .terms-label{
            display:flex;
            align-items:flex-start;
            gap:10px;
            cursor:pointer;
            color:#aeb0b8;
            font-size:12px;
            line-height:1.5;
        }

        .terms-label input{
            position:absolute;
            opacity:0;
            pointer-events:none;
        }

        .checkmark{
            flex:0 0 19px;
            width:19px;
            height:19px;
            border-radius:5px;
            border:1px solid #4a4c55;
            background:#1d1e21;
            display:flex;
            align-items:center;
            justify-content:center;
            transition:.2s;
            margin-top:1px;
        }

        .checkmark:after{
            content:"✓";
            opacity:0;
            transform:scale(.5);
            color:#fff;
            font-size:13px;
            font-weight:900;
            transition:.15s;
        }

        .terms-label input:checked + .checkmark{
            background:#5865f2;
            border-color:#5865f2;
            box-shadow:0 0 0 2px rgba(88,101,242,.15);
        }

        .terms-label input:checked + .checkmark:after{
            opacity:1;
            transform:scale(1);
        }

        .terms-label a{
            color:#7d88ff;
        }
        .terms-label a:hover{text-decoration:underline}

        .send-button{
            width:100%;
            margin-top:14px;
            border:0;
            border-radius:7px;
            padding:11px;
            background:#5865f2;
            color:#fff;
            font-size:13px;
            font-weight:700;
            cursor:pointer;
        }
        .send-button:hover{background:#6875ff}

        .already{
            margin-top:10px;
            color:#65dc98;
            font-size:12px;
            text-align:center;
        }

        .company-box{
            margin-top:20px;
            padding-top:18px;
            border-top:1px solid #303136;
        }
        .company-name{
            font-weight:700;
            margin-bottom:7px;
        }
        .company-text{
            color:#898b94;
            font-size:12px;
            line-height:1.5;
        }

        .meta-row{
            display:flex;
            justify-content:space-between;
            color:#777982;
            font-size:12px;
            margin-top:20px;
        }

        @media(max-width:800px){
            .content-layout{grid-template-columns:1fr}
            .sidebar-card{position:static}
        }

        @media(max-width:600px){
            .page{padding-left:10px;padding-right:10px}
            .vacancy-cover{height:120px}
            .vacancy-main{padding:50px 18px 20px}
            .vacancy-title{font-size:22px}
            .content-card{padding:18px}
            .form-grid{grid-template-columns:1fr}
            .form-field.full{grid-column:auto}
        }
    </style>
</head>

<body>

<header class="top-header">
    <a href="index.php" class="logo">
        <span class="logo-v">V</span>
        <span class="logo-space">SPACE</span>
    </a>

    <div class="header-actions">
        <a href="notifications.php" class="header-icon">🔔</a>
        <a href="profile.php" class="header-avatar">👤</a>
    </div>
</header>

<main class="page">

    <div class="breadcrumbs">
        <a href="index.php">Главная</a>
        <span>›</span>
        <a href="vacancies.php">Вакансии</a>
        <span>›</span>
        <span><?= htmlspecialchars($vacancy['title']) ?></span>
    </div>

    <section class="vacancy-card">

        <div class="vacancy-cover">
            <div class="vacancy-logo">V</div>
        </div>

        <div class="vacancy-main">

            <h1 class="vacancy-title">
                <?= htmlspecialchars($vacancy['title']) ?>
            </h1>

            <div class="vacancy-company">
                Компания:
                <strong><?= htmlspecialchars($vacancy['company']) ?></strong>
            </div>

            <div class="vacancy-info">

                <?php if (!empty($vacancy['salary'])): ?>
                    <div class="info-item">
                        <span class="info-icon">💰</span>
                        <span class="salary"><?= htmlspecialchars($vacancy['salary']) ?></span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($vacancy['location'])): ?>
                    <div class="info-item">
                        <span class="info-icon">📍</span>
                        <?= htmlspecialchars($vacancy['location']) ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($vacancy['employment'])): ?>
                    <div class="info-item">
                        <span class="info-icon">💼</span>
                        <?= htmlspecialchars($vacancy['employment']) ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($vacancy['experience'])): ?>
                    <div class="info-item">
                        <span class="info-icon">⌛</span>
                        <?= htmlspecialchars($vacancy['experience']) ?>
                    </div>
                <?php endif; ?>

            </div>

        </div>

    </section>

    <div class="content-layout">

        <div>

            <?php if ($success): ?>
                <div class="success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <section class="content-card">

                <h2 class="section-title">О вакансии</h2>

                <div class="description">
                    <?= nl2br(htmlspecialchars($vacancy['description'])) ?>
                </div>

            </section>

            <?php if ($requirements): ?>
                <section class="content-card">

                    <h2 class="section-title">Требования</h2>

                    <ul class="requirements">
                        <?php foreach ($requirements as $item): ?>
                            <li><?= htmlspecialchars($item) ?></li>
                        <?php endforeach; ?>
                    </ul>

                </section>
            <?php endif; ?>

            <?php if ($conditions): ?>
                <section class="content-card">

                    <h2 class="section-title">Условия работы</h2>

                    <ul class="requirements">
                        <?php foreach ($conditions as $item): ?>
                            <li><?= htmlspecialchars($item) ?></li>
                        <?php endforeach; ?>
                    </ul>

                </section>
            <?php endif; ?>

            <div class="meta-row">
                <span>
                    Опубликовано:
                    <?= htmlspecialchars(date('d.m.Y', strtotime($vacancy['created_at']))) ?>
                </span>
                <span>ID: #<?= (int)$vacancy['id'] ?></span>
            </div>

        </div>

        <aside>

            <div class="sidebar-card">

                <div class="sidebar-title">
                    Откликнуться на вакансию
                </div>

                <?php if ($hasApplied): ?>

                    <div class="already">
                        ✓ Вы уже отправили отклик
                    </div>

                <?php else: ?>

                    <button
                        type="button"
                        class="apply-button"
                        onclick="openApplication()"
                    >
                        Откликнуться
                    </button>

                    <div id="applicationForm" class="application-form">

                        <h3 class="form-title">Ваш отклик</h3>

                        <div class="form-subtitle">
                            Заполните контактные данные. Поля со
                            <span style="color:#5865f2">*</span>
                            обязательны.
                        </div>

                        <form method="POST" enctype="multipart/form-data">

                            <input type="hidden" name="action" value="apply">

                            <div class="form-grid">

                                <div class="form-field">
                                    <label>
                                        Имя <span class="required">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="first_name"
                                        maxlength="80"
                                        required
                                        value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>"
                                        placeholder="Иван"
                                    >
                                </div>

                                <div class="form-field">
                                    <label>
                                        Фамилия <span class="required">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="last_name"
                                        maxlength="80"
                                        required
                                        value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>"
                                        placeholder="Иванов"
                                    >
                                </div>

                                <div class="form-field">
                                    <label>
                                        Телефон <span class="required">*</span>
                                    </label>
                                    <input
                                        type="tel"
                                        name="phone"
                                        maxlength="30"
                                        required
                                        value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
                                        placeholder="+7 900 000-00-00"
                                    >
                                </div>

                                <div class="form-field">
                                    <label>
                                        Email <span class="required">*</span>
                                    </label>
                                    <input
                                        type="email"
                                        name="email"
                                        maxlength="150"
                                        required
                                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                                        placeholder="example@mail.ru"
                                    >
                                </div>

                                <div class="form-field full">
                                    <label>
                                        Если хотите что-то добавить
                                    </label>
                                    <textarea
                                        name="message"
                                        maxlength="5000"
                                        placeholder="Напишите дополнительную информацию о себе..."
                                    ><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                                </div>

                                <div class="form-field full">

                                    <label>Файл</label>

                                    <label class="file-box">
                                        <input
                                            type="file"
                                            name="attachment"
                                            accept=".pdf,.doc,.docx,.txt,.zip"
                                            onchange="showFileName(this)"
                                        >

                                        <span class="file-icon">📎</span>

                                        <span
                                            id="fileName"
                                            class="file-text"
                                        >
                                            Выберите файл
                                        </span>
                                    </label>

                                    <div class="form-subtitle" style="margin:6px 0 0">
                                        Необязательно. PDF, DOC, DOCX, TXT или ZIP, до 10 МБ.
                                    </div>

                                </div>

                            </div>

                            <div class="terms">

                                <label class="terms-label">

                                    <input
                                        type="checkbox"
                                        name="terms"
                                        value="1"
                                        required
                                        <?= isset($_POST['terms']) ? 'checked' : '' ?>
                                    >

                                    <span class="checkmark"></span>

                                    <span>
                                        Я принимаю
                                        <a href="terms.php" target="_blank">
                                            условия подачи отклика
                                        </a>
                                        и согласен на обработку указанных данных.
                                    </span>

                                </label>

                            </div>

                            <button type="submit" class="send-button">
                                Отправить отклик
                            </button>

                        </form>

                    </div>

                <?php endif; ?>

                <!-- =====================================================
                     ССЫЛКА ДЛЯ АДМИНИСТРАТОРА (ИСПРАВЛЕНА)
                ===================================================== -->
                <?php if ($isAdmin): ?>
                    <a href="create-vacancy.php" class="admin-create">
                        🛡 Создать вакансию
                    </a>
                <?php endif; ?>

                <div class="company-box">

                    <div class="company-name">
                        <?= htmlspecialchars($vacancy['company']) ?>
                    </div>

                    <div class="company-text">
                        Информация о работодателе и вакансии V SPACE.
                    </div>

                </div>

            </div>

        </aside>

    </div>

</main>

<script>
function openApplication() {
    const form = document.getElementById('applicationForm');

    if (form.classList.contains('open')) {
        form.classList.remove('open');
    } else {
        form.classList.add('open');
        setTimeout(() => {
            form.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest'
            });
        }, 50);
    }
}

function showFileName(input) {
    const fileName = document.getElementById('fileName');

    if (input.files && input.files.length > 0) {
        fileName.textContent = input.files[0].name;
    } else {
        fileName.textContent = 'Выберите файл';
    }
}

/* Если сервер вернул ошибку формы — сразу показываем форму */
<?php if ($error && ($_SERVER['REQUEST_METHOD'] === 'POST')): ?>
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('applicationForm')?.classList.add('open');
});
<?php endif; ?>
</script>

</body>
</html>
<?php

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();

// Подключение к базе данных
$conn = db_connect();

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

$message = "";
$message_type = "";
$redirect = false;

// Получаем код из POST (форма) или GET (?token=... из письма)
$token = '';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $token = trim($_POST['code'] ?? '');
} elseif (isset($_GET['token'])) {
    $token = trim($_GET['token']);
}

// Обрабатываем только если код передан и он валиден по формату
if ($token !== '' && preg_match('/^\d{6}$/', $token)) {

    $stmt = $conn->prepare("
        SELECT id, username, verified, token_expiry
        FROM users
        WHERE verification_token = ? AND verified = 0
        LIMIT 1
    ");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user) {
        // Проверяем срок действия токена
        if (!empty($user['token_expiry']) && strtotime($user['token_expiry']) > time()) {

            $stmt = $conn->prepare("
                UPDATE users
                SET verified = 1, verification_token = NULL, token_expiry = NULL
                WHERE id = ?
            ");
            $stmt->bind_param("i", $user['id']);

            if ($stmt->execute()) {
                $message = "✅ Ваш email успешно подтверждён! Сейчас вы будете перенаправлены на страницу входа.";
                $message_type = "success";
                $redirect = true;
            } else {
                $message = "❌ Ошибка при подтверждении email. Попробуйте позже.";
                $message_type = "error";
            }
            $stmt->close();

        } else {
            $message = "❌ Срок действия кода истёк. Пожалуйста, зарегистрируйтесь заново.";
            $message_type = "error";
        }
    } else {
        $message = "❌ Недействительный код или аккаунт уже подтверждён.";
        $message_type = "error";
    }

} elseif ($token !== '') {
    $message = "❌ Код должен состоять из 6 цифр.";
    $message_type = "error";
} else {
    $message = "Введите код подтверждения из письма.";
    $message_type = "info";
}

$conn->close();

// Редирект ДО вывода HTML
if ($redirect) {
    header("Refresh: 3; url=login.php");
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подтверждение email — VS SAPCE</title>
    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #313338;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .verification-card {
            background: #2b2d31;
            padding: 40px;
            border-radius: 8px;
            max-width: 500px;
            width: 90%;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.35);
        }

        .verification-card h1 {
            color: #f2f3f5;
            margin-bottom: 10px;
            font-size: 28px;
            font-weight: 600;
        }

        .verification-card p {
            color: #b5bac1;
            line-height: 1.6;
            margin: 20px 0;
        }

        .success {
            color: #4CAF50;
            font-size: 16px;
            font-weight: 600;
            padding: 12px;
            background: rgba(76, 175, 80, 0.12);
            border-radius: 5px;
            border: 1px solid rgba(76, 175, 80, 0.35);
        }

        .error {
            color: #f23f42;
            font-size: 16px;
            font-weight: 600;
            padding: 12px;
            background: rgba(242, 63, 66, 0.12);
            border-radius: 5px;
            border: 1px solid rgba(242, 63, 66, 0.35);
        }

        .info {
            color: #b5bac1;
            font-size: 15px;
            padding: 12px;
            background: rgba(88, 101, 242, 0.10);
            border-radius: 5px;
            border: 1px solid rgba(88, 101, 242, 0.30);
        }

        .code-form {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin: 20px 0 10px;
        }

        .code-input {
            width: 100%;
            padding: 14px 16px;
            font-size: 24px;
            letter-spacing: 8px;
            text-align: center;
            font-family: 'Courier New', monospace;
            font-weight: 700;
            color: #f2f3f5;
            background: #1e1f22;
            border: 1px solid #1e1f22;
            border-radius: 4px;
            outline: none;
            transition: border-color 0.15s;
        }

        .code-input:focus {
            border-color: #5865f2;
        }

        .code-input::placeholder {
            color: #6d6f78;
            letter-spacing: 2px;
            font-size: 16px;
            font-weight: 400;
        }

        .button {
            display: inline-block;
            padding: 12px 32px;
            background: #5865f2;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: background 0.15s;
            margin-top: 10px;
        }

        .button:hover { background: #4752c4; }

        .button.secondary {
            background: transparent;
            color: #b5bac1;
            border: 1px solid #4e5058;
        }

        .button.secondary:hover {
            background: #383a40;
            color: #f2f3f5;
        }

        .actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 20px;
        }

        @media (max-width: 520px) {
            .verification-card { padding: 24px 20px; }
            .verification-card h1 { font-size: 24px; }
        }
    </style>
</head>
<body>
    <div class="verification-card">
        <h1>Подтверждение email</h1>

        <?php if ($message !== ""): ?>
            <p class="<?= htmlspecialchars($message_type, ENT_QUOTES, "UTF-8") ?>">
                <?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?>
            </p>
        <?php endif; ?>

        <?php if ($message_type === "success" && $redirect): ?>
            <div class="actions">
                <a href="login.php" class="button">Перейти ко входу</a>
            </div>
        <?php else: ?>
            <form method="POST" action="verify.php" class="code-form" autocomplete="off">
                <input
                    type="text"
                    name="code"
                    class="code-input"
                    inputmode="numeric"
                    pattern="[0-9]{6}"
                    maxlength="6"
                    placeholder="Введите 6-значный код"
                    required
                    autofocus
                >
                <button type="submit" class="button">Подтвердить email</button>
            </form>
            <div class="actions">
                <a href="register.php" class="button secondary">Зарегистрироваться снова</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
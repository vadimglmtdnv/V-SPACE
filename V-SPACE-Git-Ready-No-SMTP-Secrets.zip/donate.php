<?php
require_once __DIR__ . '/includes/helpers.php';
start_secure_session();
// Перевод страницы на английский (если выбран English в настройках)
require_once __DIR__ . '/includes/lang.php';
ui_translate_start();
require_once __DIR__ . '/includes/db.php';
if (is_file(__DIR__ . '/includes/shell.php')) {
    require_once __DIR__ . '/includes/shell.php';   // как в index.php: общие функции оболочки (счётчик сообщений и т.д.)
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

// Ошибки mysqli -> исключения, чтобы их можно было ловить (и откатывать транзакции).
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$user_id = (int)$_SESSION["user_id"];

// ===== ТЕМА (обрабатываем до обращения к БД) =====
$allowed_themes = ['dark', 'light', 'system'];
$theme = isset($_COOKIE['theme']) && in_array($_COOKIE['theme'], $allowed_themes, true)
    ? $_COOKIE['theme']
    : 'dark';

if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes, true)) {
    setcookie('theme', $_GET['theme'], ['expires' => time() + 365 * 24 * 60 * 60, 'path' => '/', 'samesite' => 'Lax']);
    header("Location: donate.php");
    exit;
}

// ===== ПОДКЛЮЧЕНИЕ К БД =====
try {
    $conn = db_connect(true);
} catch (Throwable $e) {
    error_log('donate.php DB connect error: ' . $e->getMessage());
    http_response_code(503);
    die("Сервис временно недоступен. Попробуйте позже.");
}

/**
 * COUNT(*)-запрос для счётчиков в шапке. Если таблицы нет или запрос упал —
 * возвращаем 0, а не роняем всю страницу.
 */
function safeCount(mysqli $conn, string $sql, ?int $userId = null): int
{
    try {
        if ($userId !== null) {
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        } else {
            $result = $conn->query($sql);
            $row = $result ? $result->fetch_assoc() : null;
        }
        return (int)($row['count'] ?? 0);
    } catch (Throwable $e) {
        error_log('donate.php safeCount error: ' . $e->getMessage());
        return 0;
    }
}

function isOnline(?string $status): bool
{
    return $status === 'online';
}

/** Монета VS (символ #vs-coin объявлен в начале <body>). */
function vsCoin(string $class = ''): string
{
    return '<svg class="vs-coin' . ($class !== '' ? ' ' . $class : '') . '" aria-hidden="true" focusable="false"><use href="#vs-coin"/></svg>';
}

function timeAgo(string $datetime): string
{
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;

    if ($diff < 60) return 'только что';
    if ($diff < 3600) return floor($diff / 60) . ' м';
    if ($diff < 86400) return floor($diff / 3600) . ' ч';
    if ($diff < 604800) return floor($diff / 86400) . ' д';
    return date('d.m.Y', $timestamp);
}

function getNotificationIcon(string $type): string
{
    $icons = [
        'friend_request' => '👋',
        'friend_accepted' => '✅',
        'friend_removed' => '❌',
        'like' => '❤️',
        'comment' => '💭',
        'repost' => '🔁',
        'message' => '💬',
        'news' => '📰',
        'tag' => '🔖',
        'mention' => '@',
        'info' => 'ℹ️'
    ];
    return $icons[$type] ?? '🔔';
}

// ===== СХЕМА: баланс V Space и журнал операций =====
try {
    $balanceColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'v_space_balance'");
    $needBalanceColumn = $balanceColumn && $balanceColumn->num_rows === 0;
    if ($balanceColumn) {
        $balanceColumn->close();
    }
    if ($needBalanceColumn) {
        try {
            $conn->query("ALTER TABLE users ADD COLUMN v_space_balance INT UNSIGNED NOT NULL DEFAULT 0");
        } catch (mysqli_sql_exception $e) {
            // 1060 — колонку параллельно уже создал другой запрос, это нормально.
            if ((int)$e->getCode() !== 1060) {
                throw $e;
            }
        }
    }
    // Единый баланс — V Space (VS). Рублёвый баланс больше не используется: колонку удаляем.
    $rubColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'rub_balance'");
    $hasRubColumn = $rubColumn && $rubColumn->num_rows > 0;
    if ($rubColumn) {
        $rubColumn->close();
    }
    if ($hasRubColumn) {
        try {
            $conn->query("ALTER TABLE users DROP COLUMN rub_balance");
        } catch (mysqli_sql_exception $e) {
            // 1091 — колонку параллельно уже удалил другой запрос, это нормально.
            if ((int)$e->getCode() !== 1091) {
                throw $e;
            }
        }
    }
    // Тарифы V+ в VS (цены и скидки меняются в reports.php).
    $conn->query("
        CREATE TABLE IF NOT EXISTS v_plus_plans (
            duration INT UNSIGNED NOT NULL,
            label VARCHAR(50) NOT NULL,
            cost INT UNSIGNED NOT NULL,
            discount_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
            updated_by INT UNSIGNED NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (duration)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    // Тарифы по умолчанию: 1 месяц, 3 месяца, 12 месяцев (дальше цены правятся в reports.php).
    $conn->query("
        INSERT IGNORE INTO v_plus_plans (duration, label, cost, discount_percent)
        VALUES (30, '1 месяц', 150, 0), (90, '3 месяца', 400, 0), (365, '12 месяцев', 1290, 0)
    ");
    // Старый тариф «1 год» переименовываем; цену меняем только если её ещё не трогали вручную.
    $conn->query("UPDATE v_plus_plans SET label = '12 месяцев' WHERE duration = 365 AND label = '1 год'");
    $conn->query("UPDATE v_plus_plans SET cost = 1290 WHERE duration = 365 AND cost = 2500 AND updated_by IS NULL");
    $conn->query("
        CREATE TABLE IF NOT EXISTS v_space_transactions (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            operation ENUM('credit', 'debit') NOT NULL,
            amount INT UNSIGNED NOT NULL,
            balance_after INT UNSIGNED NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX idx_v_space_user_created (user_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (Throwable $e) {
    error_log('donate.php schema error: ' . $e->getMessage());
    http_response_code(500);
    die("Ошибка инициализации базы данных.");
}

// ===== ДАННЫЕ ТЕКУЩЕГО ПОЛЬЗОВАТЕЛЯ (V+, баланс, шапка) — одним запросом =====
try {
    $stmt = $conn->prepare("
        SELECT id, username, avatar, status, is_admin,
               is_premium, premium_expires, premium_type, v_space_balance
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} catch (Throwable $e) {
    error_log('donate.php user fetch error: ' . $e->getMessage());
    http_response_code(500);
    die("Не удалось загрузить данные пользователя.");
}

if (!$user) {
    // Аккаунт удалён, а сессия осталась.
    session_destroy();
    header("Location: login.php");
    exit;
}

// Данные для шапки — тем же запросом, что и в index.php (имя + фамилия из профиля).
$current_user_data = $user;
try {
    $stmt = $conn->prepare("SELECT u.id, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', up.first_name, up.last_name)), ''), u.username) AS username, u.avatar, u.status FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id WHERE u.id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $current_user_data = $stmt->get_result()->fetch_assoc() ?: $user;
    $stmt->close();
} catch (Throwable $e) {
    error_log('donate.php header user error: ' . $e->getMessage());
}
$is_admin = (int)($user['is_admin'] ?? 0) === 1;
// Ручное изменение баллов — только основатель (id=1, как и консоль в reports.php).
$is_founder = $is_admin && $user_id === 1;

// ===== СЧЁТЧИКИ В ШАПКЕ =====
$unread_count = safeCount($conn, "SELECT COUNT(*) AS count FROM messages WHERE receiver_id = ? AND is_read = 0", $user_id);
// Как в index.php: тот же счётчик непрочитанных сообщений, что и на остальных страницах.
if (function_exists('shell_unread_messages')) {
    try {
        $unread_count = (int)shell_unread_messages($conn, $user_id);
    } catch (Throwable $e) {
        error_log('donate.php unread count error: ' . $e->getMessage());
    }
}
$notifications = [];
$notif_count = 0;
try {
    $stmt = $conn->prepare("
        SELECT n.*, COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sp.first_name, sp.last_name)), ''), u.username) as sender_name, u.username as sender_username, u.avatar as sender_avatar
        FROM notifications n
        LEFT JOIN users u ON u.id = n.sender_id
        LEFT JOIN user_profiles sp ON sp.user_id = u.id
        WHERE n.user_id = ?
          AND n.type NOT IN ('message', 'friend_accepted', 'friend_removed')
        ORDER BY n.created_at DESC
        LIMIT 30
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0 AND type NOT IN ('message', 'friend_accepted', 'friend_removed')");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif_count = (int)($stmt->get_result()->fetch_assoc()['count'] ?? 0);
    $stmt->close();
} catch (Throwable $e) {
    error_log('donate.php notifications error: ' . $e->getMessage());
}
$notification_count = $notif_count;
$pending_reports_count = $is_admin
    ? safeCount($conn, "SELECT COUNT(*) AS count FROM reports WHERE status = 'pending'")
    : 0;

// ===== ЗАЩИТА ОТ ПОДДЕЛКИ ЗАПРОСА / ПОВТОРНОЙ ОТПРАВКИ =====
if (empty($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Тарифы V+ берутся из БД (v_plus_plans) — цены и скидки меняются в reports.php.

// Максимальная скидка — не даёт уйти в ноль или в минус.
const MAX_DISCOUNT_PERCENT = 90;

function planCost(int $baseCost, int $percent): int
{
    $percent = max(0, min(MAX_DISCOUNT_PERCENT, $percent));
    return max(1, (int)round($baseCost * (100 - $percent) / 100));
}

function loadPlans(mysqli $conn): array
{
    $plans = [];
    try {
        $res = $conn->query("SELECT duration, label, cost, discount_percent FROM v_plus_plans ORDER BY duration");
        while ($r = $res->fetch_assoc()) {
            $plans[(int)$r['duration']] = [
                'label' => (string)$r['label'],
                'cost' => (int)$r['cost'],
                'discount' => (int)$r['discount_percent'],
            ];
        }
    } catch (Throwable $e) {
        error_log('donate.php plans load error: ' . $e->getMessage());
    }
    return $plans ?: [
        30  => ['label' => '1 месяц',    'cost' => 150,  'discount' => 0],
        90  => ['label' => '3 месяца',   'cost' => 400,  'discount' => 0],
        365 => ['label' => '12 месяцев', 'cost' => 1290, 'discount' => 0],
    ];
}

$plans = loadPlans($conn);

// ===== Пополнение баланса: суммы и способы оплаты =====
// Чтобы добавить/убрать способ — правится только этот массив.
$topup_amounts = [100, 500, 1000, 5000];
$payment_methods = [
    'card'   => ['label' => 'Банковская карта', 'hint' => 'Visa, Mastercard, МИР', 'icon' => '💳'],
    'sbp'    => ['label' => 'СБП',              'hint' => 'Через приложение банка', 'icon' => '⚡'],
    'wallet' => ['label' => 'ЮMoney',           'hint' => 'Электронный кошелёк',    'icon' => '👛'],
];

$message = "";
$error = "";

if (isset($_SESSION['donate_flash'])) {
    $message = (string)($_SESSION['donate_flash']['message'] ?? '');
    $error = (string)($_SESSION['donate_flash']['error'] ?? '');
    unset($_SESSION['donate_flash']);
}

/**
 * Списание/зачисление V Space + запись в журнал, всё в одной транзакции.
 * Строка пользователя блокируется (FOR UPDATE) ДО проверки баланса,
 * поэтому два параллельных запроса не могут потратить одни и те же баллы.
 * $onLockedRow получает заблокированную строку и может выполнить свои UPDATE-ы.
 * Возвращает новый баланс. Для ожидаемых ошибок бросает RuntimeException.
 */
function vSpaceTransaction(mysqli $conn, int $userId, string $operation, int $amount, ?callable $onLockedRow = null): int
{
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("SELECT v_space_balance, is_premium, premium_expires FROM users WHERE id = ? FOR UPDATE");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row) {
            throw new RuntimeException("Пользователь не найден.");
        }

        $balance = (int)$row['v_space_balance'];

        if ($operation === 'debit' && $balance < $amount) {
            throw new RuntimeException("Недостаточно VS-баллов. Нужно: " . number_format($amount, 0, ',', ' ') . " VS.");
        }

        $newBalance = $operation === 'credit' ? $balance + $amount : $balance - $amount;

        if ($onLockedRow !== null) {
            $onLockedRow($row, $newBalance);
        } else {
            $stmt = $conn->prepare("UPDATE users SET v_space_balance = ? WHERE id = ?");
            $stmt->bind_param("ii", $newBalance, $userId);
            $stmt->execute();
            $stmt->close();
        }

        $stmt = $conn->prepare("
            INSERT INTO v_space_transactions (user_id, operation, amount, balance_after)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("isii", $userId, $operation, $amount, $newBalance);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
        return $newBalance;
    } catch (Throwable $e) {
        try {
            $conn->rollback();
        } catch (Throwable $ignored) {
        }
        throw $e;
    }
}

// ===== ОБРАБОТКА POST =====
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $submitted_token = (string)($_POST['form_token'] ?? '');

    if (!hash_equals((string)$_SESSION['form_token'], $submitted_token)) {
        $error = "Недействительный запрос. Обновите страницу и попробуйте снова.";
    } else {
        // Токен одноразовый — повторная отправка той же формы уже не пройдёт.
        $_SESSION['form_token'] = bin2hex(random_bytes(32));

        try {
            if (isset($_POST["activate_premium"])) {

                // --- Покупка / продление V+ за VS. Цену берём из БД, а не из формы. ---
                $duration = (int)($_POST['duration'] ?? 0);
                if (!isset($plans[$duration])) {
                    throw new RuntimeException("Выберите тариф.");
                }
                $cost = planCost($plans[$duration]['cost'], $plans[$duration]['discount']);
                $newExpires = '';

                vSpaceTransaction($conn, $user_id, 'debit', $cost, function (array $row, int $newBalance) use ($conn, $user_id, $duration, &$newExpires) {
                    // Бессрочный V+ (выдан вручную) продлевать не нужно.
                    if ((int)$row['is_premium'] === 1 && $row['premium_expires'] === null) {
                        throw new RuntimeException("У вас бессрочный V+, продлевать не нужно.");
                    }
                    // Если подписка ещё идёт — прибавляем срок к её концу, иначе считаем от сегодня.
                    $base = time();
                    if (!empty($row['premium_expires']) && strtotime($row['premium_expires']) > $base) {
                        $base = strtotime($row['premium_expires']);
                    }
                    $newExpires = date('Y-m-d H:i:s', $base + $duration * 86400);

                    $stmt = $conn->prepare("
                        UPDATE users
                        SET v_space_balance = ?, is_premium = 1, premium_type = 'v_plus', premium_expires = ?
                        WHERE id = ?
                    ");
                    $stmt->bind_param("isi", $newBalance, $newExpires, $user_id);
                    $stmt->execute();
                    $stmt->close();
                });

                $message = 'V+ активирован до ' . date('d.m.Y', strtotime($newExpires))
                    . '. Списано ' . number_format($cost, 0, ',', ' ') . ' VS.';

            } elseif (isset($_POST["v_space_operation"])) {

                // --- Пополнение/списание V Space (пока только основатель, без платёжной системы) ---
                $operation = (string)$_POST['v_space_operation'];
                $allowedAmounts = [100, 500, 1000, 5000];
                $amount = (int)($_POST['v_space_amount'] ?? 0);

                if (!in_array($operation, ['credit', 'debit'], true) || !in_array($amount, $allowedAmounts, true)) {
                    throw new RuntimeException("Выберите корректную операцию и сумму.");
                }

                // Любое изменение баллов вручную — только основатель (не обычные админы).
                if (!$is_founder) {
                    throw new RuntimeException("Изменять баллы может только основатель.");
                }

                $newBalance = vSpaceTransaction($conn, $user_id, $operation, $amount);

                $message = ($operation === 'credit' ? 'Зачислено ' : 'Списано ')
                    . number_format($amount, 0, ',', ' ') . ' VS. Баланс: '
                    . number_format($newBalance, 0, ',', ' ') . ' VS.';

            } elseif (isset($_POST['topup_start'])) {

                // --- Пополнение через платёжную систему: выбор суммы и способа оплаты ---
                $amount = (int)($_POST['topup_amount'] ?? 0);
                $method = (string)($_POST['payment_method'] ?? '');

                if (!in_array($amount, $topup_amounts, true) || !isset($payment_methods[$method])) {
                    throw new RuntimeException("Выберите сумму и способ оплаты.");
                }

                // TODO: здесь создаём счёт у платёжного провайдера и делаем redirect на его страницу.
                // VS зачисляются ТОЛЬКО по подтверждённому уведомлению (вебхуку) провайдера,
                // а не по кнопке на странице — иначе баланс можно накрутить.
                throw new RuntimeException(
                    'Оплата через «' . $payment_methods[$method]['label'] . '» пока недоступна: платёжная система ещё не подключена.'
                );

            }
        } catch (mysqli_sql_exception $e) {
            // ВАЖНО: mysqli_sql_exception наследует RuntimeException, поэтому ловим её раньше —
            // текст SQL-ошибки пользователю показывать нельзя.
            error_log('donate.php SQL error: ' . $e->getMessage());
            $error = "Не удалось выполнить операцию. Попробуйте позже.";
        } catch (RuntimeException $e) {
            // Ожидаемая ошибка с понятным пользователю текстом.
            $error = $e->getMessage();
        } catch (Throwable $e) {
            // Неожиданная ошибка — детали только в лог.
            error_log('donate.php transaction error: ' . $e->getMessage());
            $error = "Не удалось выполнить операцию. Попробуйте позже.";
        }
    }

    // Post/Redirect/Get: обновление страницы не повторяет операцию.
    $_SESSION['donate_flash'] = ['message' => $message, 'error' => $error];
    $conn->close();
    header('Location: donate.php');
    exit;
}

// ===== Свежие данные для отображения (после возможных изменений) =====
$conn->close();

$is_premium = $user['is_premium'] ?? 0;
$premium_type = $user['premium_type'] ?? 'v_plus';
$premium_expires = $user['premium_expires'] ?? null;
$is_active = $is_premium && ($premium_expires === null || strtotime($premium_expires) > time());
$vs_balance = (int)($user['v_space_balance'] ?? 0);

$current_avatar = $user['avatar'] ?? '';
$current_username = $user['username'] ?? 'Пользователь';
$current_letter = mb_strtoupper(mb_substr($current_username, 0, 1, 'UTF-8'), 'UTF-8');
$current_status = $user['status'] ?? 'offline';
$current_avatar_ok = !empty($current_avatar) && is_file(__DIR__ . "/" . $current_avatar);

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="images/favicon.ico?v=2" sizes="any">
    <link rel="shortcut icon" href="images/favicon.ico?v=2">
    <title>V+ Premium — PLAYERCHAT</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/donate.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/donate.css') ?>">
    <style>
        /* как в index.php: кнопки в шапке не слипаются */
        .header-right { gap: 10px !important; }
        .header-right .avatar-dropdown { margin-left: 4px !important; }
        .header-left { display: flex; align-items: center; gap: 20px; }
    </style>
<?php require_once __DIR__ . '/includes/seasons.php'; echo seasonHead(); ?>
    <link rel="stylesheet" href="assets/css/theme-switch.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/theme-switch.css') ?>">
    <script src="assets/js/header-dropdowns.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/header-dropdowns.js') ?>" defer></script>
    <script src="assets/js/theme-switch.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/theme-switch.js') ?>" defer></script>
</head>
<body<?= seasonBodyAttrs() ?> data-theme="<?= htmlspecialchars($theme, ENT_QUOTES, "UTF-8") ?>">

    <!-- Монета V Space (vplus_coin_front.svg): используется через <use href="#vs-coin"> -->
    <svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
            <defs>
    <radialGradient id="vc-bg" cx="42%" cy="30%" r="75%"><stop stop-color="#28292b"/><stop offset=".68" stop-color="#101113"/><stop offset="1" stop-color="#030303"/></radialGradient>
      <linearGradient id="vc-gold" x1="0" y1="0" x2=".85" y2="1"><stop stop-color="#fff9a0"/><stop offset=".16" stop-color="#ffdf26"/><stop offset=".34" stop-color="#fff36a"/><stop offset=".53" stop-color="#f4a900"/><stop offset=".72" stop-color="#ffcf19"/><stop offset=".88" stop-color="#b96300"/><stop offset="1" stop-color="#ffdc39"/></linearGradient>
      <linearGradient id="vc-rim" x1="0" y1="0" x2="0.8" y2="1"><stop stop-color="#fffdb3"/><stop offset=".22" stop-color="#ffc900"/><stop offset=".43" stop-color="#fff05b"/><stop offset=".62" stop-color="#d98200"/><stop offset=".8" stop-color="#ffcf17"/><stop offset="1" stop-color="#8e4300"/></linearGradient>
      <linearGradient id="vc-face" x1="0" y1="0" x2=".9" y2="1"><stop stop-color="#343538"/><stop offset=".45" stop-color="#151619"/><stop offset="1" stop-color="#090a0b"/></linearGradient>
      <linearGradient id="vc-letter" x1="0" y1="0" x2=".25" y2="1"><stop stop-color="#fffda0"/><stop offset=".22" stop-color="#ffe82f"/><stop offset=".55" stop-color="#ffbf12"/><stop offset=".82" stop-color="#e58b00"/><stop offset="1" stop-color="#9c4c00"/></linearGradient>
      <filter id="vc-shadow" x="-30%" y="-30%" width="160%" height="170%"><feGaussianBlur in="SourceAlpha" stdDeviation="5"/><feOffset dy="5"/><feComponentTransfer><feFuncA type="linear" slope=".8"/></feComponentTransfer><feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge></filter>
                <symbol id="vs-coin" viewBox="0 0 512 512">
    <circle cx="256" cy="256" r="229" fill="#000" opacity=".75"/>
     <circle cx="256" cy="250" r="226" fill="url(#vc-rim)" stroke="#9a5100" stroke-width="3"/>
     <circle cx="256" cy="250" r="216" fill="url(#vc-gold)" stroke="#fff06a" stroke-width="2"/>
     <circle cx="256" cy="250" r="190" fill="#8e4400" stroke="#ffef56" stroke-width="3"/>
     <circle cx="256" cy="247" r="185" fill="url(#vc-face)" stroke="url(#vc-rim)" stroke-width="5"/>
     <circle cx="256" cy="247" r="177" fill="none" stroke="#66605a" stroke-width="1.2" opacity=".55"/>
     <g filter="url(#vc-shadow)" stroke-linejoin="round">
      <path d="M128 165 L184 165 L236 281 L286 165 L345 165 L268 356 L221 356 Z" fill="#8b4300" stroke="#a85a00" stroke-width="5" transform="translate(0 5)"/>
      <path d="M126 160 L182 160 L235 278 L287 160 L343 160 L266 351 L220 351 Z" fill="url(#vc-letter)" stroke="#ffcf21" stroke-width="3"/>
      <path d="M130 163 L181 163 L235 278 L287 163 L338 163" fill="none" stroke="#fff9a0" stroke-width="3" opacity=".95"/>
      <path d="M326 244 H354 V216 H381 V244 H410 V272 H381 V302 H354 V272 H326 Z" fill="#8d4300" stroke="#a65a00" stroke-width="4" transform="translate(0 5)"/>
      <path d="M323 239 H352 V210 H379 V239 H408 V266 H379 V296 H352 V266 H323 Z" fill="url(#vc-letter)" stroke="#ffc91d" stroke-width="3"/>
      <path d="M327 242 H352 V214 M356 214 H376 V242 H404" fill="none" stroke="#fff8a0" stroke-width="2.5"/>
     </g>
     <circle cx="256" cy="250" r="222" fill="none" stroke="#fff8a0" stroke-width="2" opacity=".8"/>
                </symbol>
            </defs>
        </svg>

    <header class="header header-cosmic">
        <!-- Космос в шапке: планеты, пояс астероидов и пролетающий корабль -->
        <span class="header-space" aria-hidden="true">
            <svg class="hs-defs" width="0" height="0" focusable="false">
                <defs>
                    <linearGradient id="hs-rock" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9097a8"/><stop offset="1" stop-color="#474c5a"/></linearGradient>
                    <radialGradient id="hs-sat" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffe6b8"/><stop offset=".55" stop-color="#e9a24f"/><stop offset="1" stop-color="#7a3f17"/></radialGradient>
                    <radialGradient id="hs-nep" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#bfe3ff"/><stop offset=".55" stop-color="#3f8cf0"/><stop offset="1" stop-color="#14307a"/></radialGradient>
                    <radialGradient id="hs-mars" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffb199"/><stop offset=".6" stop-color="#d8512f"/><stop offset="1" stop-color="#6b1d10"/></radialGradient>
                    <linearGradient id="hs-hull" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#a9b1c4"/></linearGradient>
                    <linearGradient id="hs-glass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a6ecff"/><stop offset="1" stop-color="#2f7fe0"/></linearGradient>
                    <linearGradient id="hs-fire" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="#fff3a8"/><stop offset=".45" stop-color="#ffa63d"/><stop offset="1" stop-color="#ff4d1f" stop-opacity="0"/></linearGradient>

                    <symbol id="hs-rock-a" viewBox="0 0 24 24">
                        <polygon points="4,9 8,3 15,2 21,7 22,14 17,21 9,22 3,16" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                        <circle cx="9" cy="9" r="2.2" fill="#000" opacity=".28"/><circle cx="15.5" cy="14" r="2.8" fill="#000" opacity=".25"/><circle cx="8" cy="16.5" r="1.5" fill="#000" opacity=".28"/>
                    </symbol>
                    <symbol id="hs-rock-b" viewBox="0 0 24 24">
                        <polygon points="3,12 6,5 13,3 20,5 22,12 18,19 11,22 5,19" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                        <circle cx="12" cy="8" r="2.4" fill="#000" opacity=".26"/><circle cx="8" cy="15" r="2" fill="#000" opacity=".28"/><circle cx="16.5" cy="15.5" r="1.6" fill="#000" opacity=".25"/>
                    </symbol>
                    <symbol id="hs-rock-c" viewBox="0 0 24 24">
                        <polygon points="2,11 7,5 17,4 23,10 21,17 12,20 5,18" fill="url(#hs-rock)" stroke="#2f3340" stroke-width="1.2" stroke-linejoin="round"/>
                        <circle cx="10" cy="10" r="2.6" fill="#000" opacity=".26"/><circle cx="17" cy="13" r="1.8" fill="#000" opacity=".28"/>
                    </symbol>
                </defs>
            </svg>

            <!-- Планеты -->
            <svg class="hs-planet hs-planet-ringed" viewBox="0 0 80 50">
                <g transform="rotate(-16 40 25)">
                    <ellipse cx="40" cy="25" rx="36" ry="9" fill="none" stroke="#f4d28a" stroke-width="3" opacity=".55"/>
                    <circle cx="40" cy="25" r="15" fill="url(#hs-sat)"/>
                    <path d="M26 21 Q40 17.5 54 21 M25.6 29 Q40 33 54.4 29" fill="none" stroke="#fff" stroke-width="1.6" opacity=".28" stroke-linecap="round"/>
                    <path d="M4 25 A36 9 0 0 0 76 25" fill="none" stroke="#ffd98e" stroke-width="3" stroke-linecap="round"/>
                </g>
            </svg>
            <svg class="hs-planet hs-planet-blue" viewBox="0 0 40 40">
                <circle cx="20" cy="20" r="14" fill="url(#hs-nep)"/>
                <path d="M7.5 16 Q20 12 32.5 16 M6.5 23 Q20 27 33.5 23" fill="none" stroke="#fff" stroke-width="1.6" opacity=".3" stroke-linecap="round"/>
                <circle cx="35" cy="7" r="3" fill="#cfd6e6"/><circle cx="34" cy="6" r="1" fill="#fff" opacity=".7"/>
            </svg>
            <svg class="hs-planet hs-planet-red" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="url(#hs-mars)"/>
                <ellipse cx="9" cy="9" rx="2.2" ry="1.6" fill="#000" opacity=".22"/><ellipse cx="15" cy="14.5" rx="2.6" ry="1.8" fill="#000" opacity=".2"/>
            </svg>

            <!-- Пояс астероидов: плывут справа налево -->
            <span class="hs-asteroid" style="--y:9px;  --s:11px; --dur:46s; --delay:-9s;  --spin:360deg;  --sx:8%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
            <span class="hs-asteroid" style="--y:38px; --s:16px; --dur:62s; --delay:-31s; --spin:-300deg; --sx:20%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>
            <span class="hs-asteroid" style="--y:22px; --s:8px;  --dur:38s; --delay:-14s; --spin:420deg;  --sx:37%"><svg viewBox="0 0 24 24"><use href="#hs-rock-c"/></svg></span>
            <span class="hs-asteroid" style="--y:46px; --s:10px; --dur:54s; --delay:-44s; --spin:-360deg; --sx:50%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:5px;  --s:14px; --dur:70s; --delay:-21s; --spin:240deg;  --sx:64%"><svg viewBox="0 0 24 24"><use href="#hs-rock-c"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:30px; --s:9px;  --dur:42s; --delay:-3s;  --spin:-420deg; --sx:72%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:14px; --s:6px;  --dur:34s; --delay:-26s; --spin:300deg;  --sx:28%"><svg viewBox="0 0 24 24"><use href="#hs-rock-a"/></svg></span>
            <span class="hs-asteroid hs-far" style="--y:42px; --s:7px;  --dur:50s; --delay:-18s; --spin:-240deg; --sx:44%"><svg viewBox="0 0 24 24"><use href="#hs-rock-b"/></svg></span>

            <!-- Космический корабль -->
            <span class="hs-ship">
                <svg viewBox="0 0 64 28">
                    <path class="hs-flame" d="M12 10.5 L0 14 L12 17.5Z" fill="url(#hs-fire)"/>
                    <path d="M15 10 L21 2 L28 10Z" fill="#5865f2" stroke="#2a31a0" stroke-width="1" stroke-linejoin="round"/>
                    <path d="M15 18 L21 26 L28 18Z" fill="#5865f2" stroke="#2a31a0" stroke-width="1" stroke-linejoin="round"/>
                    <rect x="10" y="10" width="5" height="8" rx="1.5" fill="#3a3f4b"/>
                    <path d="M14 8 H40 Q56 8 63 14 Q56 20 40 20 H14 Q11 14 14 8Z" fill="url(#hs-hull)" stroke="#59607a" stroke-width="1" stroke-linejoin="round"/>
                    <path d="M16 15 H36" stroke="#5865f2" stroke-width="2" stroke-linecap="round"/>
                    <ellipse cx="46" cy="13.4" rx="6.4" ry="3.6" fill="url(#hs-glass)" stroke="#2a4f9c" stroke-width=".8"/>
                    <ellipse cx="44.4" cy="12.2" rx="2.4" ry="1" fill="#fff" opacity=".7"/>
                    <circle cx="22" cy="12.4" r="1.2" fill="#2f7fe0"/><circle cx="27" cy="12.4" r="1.2" fill="#2f7fe0"/><circle cx="32" cy="12.4" r="1.2" fill="#2f7fe0"/>
                </svg>
            </span>
        </span>
        <span class="header-shooting-stars" aria-hidden="true">
            <span class="sky-cloud" aria-hidden="true"></span>
            <span class="sky-rain" aria-hidden="true"></span>
            <span class="sky-snow" aria-hidden="true"></span>
            <span class="sky-fog" aria-hidden="true"></span>
            <span class="sky-flash" aria-hidden="true"></span>
            <span class="header-shooting-star star-one"></span>
            <span class="header-shooting-star star-two"></span>
            <span class="header-shooting-star star-three"></span>
            <span class="header-comet"></span>
        </span>
        <div class="header-left">
            <div class="logo">
                <div class="logo-icon">
                    <img src="images/logo_type.svg" alt="SPACE Logo" width="40" height="40">
                </div>
            </div>
        </div>
        <div class="search-box"></div>
        <div class="header-right">

            <?php if ($is_admin): ?>
                <a href="reports.php" class="moderation-btn" title="Модерация">
                <img src="images/protection.svg" alt="Модерация" class="moderation-icon">
                <?php if ($pending_reports_count > 0): ?>
                    <span class="moderation-badge"><?= $pending_reports_count > 99 ? '99+' : $pending_reports_count ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>

            <div class="notifications-wrapper">
                <button class="notifications-btn" id="notificationsBtn" aria-label="Уведомления">
                    <?php include __DIR__ . '/includes/notification_bell.php'; ?>
                    <?php if ($notif_count > 0): ?>
                        <span class="notifications-badge" id="notificationsBadge"><?= $notif_count > 99 ? '99+' : $notif_count ?></span>
                    <?php else: ?>
                        <span class="notifications-badge" id="notificationsBadge" style="display:none;">0</span>
                    <?php endif; ?>
                </button>
                <div class="notifications-dropdown" id="notificationsDropdown">
                    <div class="notifications-header">
                        <span class="notifications-title">Уведомления</span>
                        <div class="notifications-header-actions">
                            <?php if ($notif_count > 0): ?>
                                <button class="mark-all-read-btn" id="markAllReadBtn">Все прочитано</button>
                            <?php endif; ?>
                            <span class="notifications-count" id="notificationsCount" data-zero-text="<?= htmlspecialchars(ui_new_count(0), ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(ui_new_count($notif_count), ENT_QUOTES, 'UTF-8') ?></span>
                        </div>
                    </div>
                    <div class="notifications-list" id="notificationsList">
                        <?php if (empty($notifications)): ?>
                            <div class="notifications-empty">
                                <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
                                <div class="empty-text">Нет уведомлений</div>
                                <div class="empty-sub">Здесь будут появляться ваши уведомления</div>
                            </div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notif): 
                                $icon = getNotificationIcon((string)$notif['type']);
                                $notif_type_class = $notif['type'];
                                $sender_avatar = $notif['sender_avatar'] ?? '';
                                $sender_name = $notif['sender_name'] ?? '';
                                
                                $avatar_exists = false;
                                if (!empty($sender_avatar)) {
                                    $paths_to_check = [
                                        $sender_avatar,
                                        'uploads/avatars/' . basename($sender_avatar),
                                        'assets/images/' . basename($sender_avatar)
                                    ];
                                    foreach ($paths_to_check as $path) {
                                        if (file_exists($path)) {
                                            $avatar_exists = true;
                                            $sender_avatar = $path;
                                            break;
                                        }
                                    }
                                }
                            ?>
                                <a href="<?= htmlspecialchars($notif['link'] ?: '#') ?>" class="notification-item <?= $notif['is_read'] ? 'read' : 'unread' ?> type-<?= htmlspecialchars($notif_type_class) ?>" data-notification-id="<?= $notif['id'] ?>">
                                    <div class="notif-avatar-wrapper">
                                        <div class="notif-avatar">
                                            <?php if ($avatar_exists): ?>
                                                <img src="<?= htmlspecialchars($sender_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?>">
                                            <?php elseif (!empty($sender_name)): ?>
                                                <span class="avatar-letter"><?= htmlspecialchars(mb_strtoupper(mb_substr($sender_name, 0, 1, 'UTF-8'), 'UTF-8')) ?></span>
                                            <?php else: ?>
                                                <span class="avatar-letter">?</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="notif-content">
                                        <div class="notif-text">
                                            <?php if (!empty($sender_name)): ?>
                                                <?php
                                                // Ник уже выведен жирным — не повторяем его в начале текста («Vadim Vadim поставил(а)…»)
                                                $notif_msg = (string)$notif['message'];
                                                foreach ([(string)$sender_name, (string)($notif['sender_username'] ?? '')] as $strip_name) {
                                                    if ($strip_name !== '' && mb_strpos($notif_msg, $strip_name) === 0) {
                                                        $notif_msg = ltrim(mb_substr($notif_msg, mb_strlen($strip_name)));
                                                        break;
                                                    }
                                                }
                                                ?>
                                                <strong class="notif-sender"><?= htmlspecialchars($sender_name, ENT_QUOTES, "UTF-8") ?></strong><span class="notif-message"><?= htmlspecialchars(ui_notif_msg($notif_msg), ENT_QUOTES, "UTF-8") ?></span>
                                            <?php else: ?>
                                                <span class="notif-message"><?= htmlspecialchars(ui_notif_msg((string)$notif['message']), ENT_QUOTES, "UTF-8") ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="notif-meta">
                                            <span class="notif-time"><?= htmlspecialchars(ui_time((string)timeAgo($notif['created_at'])), ENT_QUOTES, 'UTF-8') ?></span>
                                        </div>
                                    </div>
                                    <?php if (!$notif['is_read']): ?>
                                        <span class="notif-dot"></span>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="notifications-footer">
                        <a href="notifications.php" class="view-all-notifications">Показать всё</a>
                    </div>
                </div>
            </div>

            <div class="avatar-dropdown">
                <?php
                $current_avatar = $current_user_data['avatar'] ?? '';
                $current_username = $current_user_data['username'] ?? 'Пользователь';
                require_once __DIR__ . '/includes/display_name.php'; $current_username = userDisplayName($conn ?? null, (int)($_SESSION['user_id'] ?? 0), (string)$current_username);
                $current_letter = mb_strtoupper(mb_substr($current_username, 0, 1, 'UTF-8'), 'UTF-8');
                $current_status = 'online';
                ?>
                <button class="header-avatar <?= isOnline($current_status) ? 'is-online' : 'is-offline' ?>" id="avatarBtn" aria-label="Мой профиль">
                    <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                        <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                    <?php else: ?>
                        <?= htmlspecialchars($current_letter) ?>
                    <?php endif; ?>
                </button>
                <div class="dropdown-menu" id="avatarDropdown">
                    <div class="dropdown-header">
                        <div class="dropdown-avatar">
                            <?php if (!empty($current_avatar) && file_exists($current_avatar)): ?>
                                <img src="<?= htmlspecialchars($current_avatar, ENT_QUOTES, "UTF-8") ?>" alt="<?= htmlspecialchars($current_username, ENT_QUOTES, "UTF-8") ?>">
                            <?php else: ?>
                                <?= htmlspecialchars($current_letter) ?>
                            <?php endif; ?>
                        </div>
                        <div class="dropdown-user-info">
                            <div class="dropdown-username"><?= htmlspecialchars($current_username) ?></div>
                        </div>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a href="settings.php" class="dropdown-item">
                        <span class="dropdown-icon">⚙</span> Настройки
                    </a>
                    <div class="theme-trigger" id="themeTrigger">
                        <span class="dropdown-icon">🎨</span>
                        <span>Тема</span>
                        <span class="theme-current">
                            <?php
                            $theme_name = 'Тёмная';
                            if ($theme === 'light') $theme_name = 'Светлая';
                            elseif ($theme === 'system') $theme_name = 'Системная';
                            echo htmlspecialchars($theme_name);
                            ?>
                        </span>
                        <span class="theme-arrow" id="themeArrow">▼</span>
                    </div>

                    <div class="theme-submenu" id="themeSubmenu">
                        <a href="?theme=dark" class="theme-item <?= $theme === 'dark' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot dark"></span>
                                Тёмная
                            </span>
                            <?php if ($theme === 'dark'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="?theme=light" class="theme-item <?= $theme === 'light' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot light"></span>
                                Светлая
                            </span>
                            <?php if ($theme === 'light'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>

                        <a href="?theme=system" class="theme-item <?= $theme === 'system' ? 'active' : '' ?>">
                            <span class="theme-option">
                                <span class="theme-dot system"></span>
                                Системная
                            </span>
                            <?php if ($theme === 'system'): ?>
                                <span class="theme-check">✓</span>
                            <?php endif; ?>
                        </a>
                    </div>

                    <div class="dropdown-divider"></div>

                    <a href="logout.php" class="dropdown-item logout-item">
                        <span class="dropdown-icon">↪</span> Выйти
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- ===== ОСНОВНОЙ КОНТЕЙНЕР ===== -->
    <div class="layout donate-layout">

        <?php include __DIR__ . '/includes/bottom_nav.php'; ?>

        <main>

            <div class="donate-container">

                <div class="vp-card">

                    <?php if ($message): ?>
                        <div class="vp-alert ok"><?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?></div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                        <div class="vp-alert bad"><?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?></div>
                    <?php endif; ?>

                    <?php
                    $days_left = ($is_active && $premium_expires) ? max(0, (int)ceil((strtotime($premium_expires) - time()) / 86400)) : 0;
                    ?>
                    <div class="vp-cols">
                    <div class="vp-col vp-col-info">
                    <!-- Шапка -->
                    <div class="vp-head vp-rise" style="--i:0">
                        <div class="vp-gem<?= $is_active ? ' is-active' : '' ?>">
                            <img src="images/diamond_vplus_original_style.svg" alt="V+" width="60" height="60">
                            <span class="vp-gem-badge" title="<?= $is_active ? 'V+ активен' : 'V+ не активен' ?>">
                                <?php if ($is_active): ?>
                                    <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 6.4l2.4 2.4 4.6-5"/></svg>
                                <?php else: ?>
                                    <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2.6" y="5.4" width="6.8" height="5" rx="1.2"/><path d="M4.2 5.4V4a1.8 1.8 0 0 1 3.6 0v1.4"/></svg>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="vp-head-text">
                            <div class="vp-title"><?= $is_active ? 'V+ активен' : 'V+ не активен' ?></div>
                            <div class="vp-sub">
                                <?php if ($is_active && $premium_expires): ?>
                                    <?php if (ui_lang() === 'en'): ?>
                                        Until <?= date('d.m.Y', strtotime($premium_expires)) ?> (<span class="vp-num"><?= $days_left ?></span> days left)
                                    <?php else: ?>
                                        До <?= date('d.m.Y', strtotime($premium_expires)) ?> (осталось <span class="vp-num"><?= $days_left ?></span> дн.)
                                    <?php endif; ?>
                                <?php elseif ($is_active): ?>
                                    Бессрочно
                                <?php else: ?>
                                    Оформите подписку — включится мгновенно
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Баланс -->
                    <div class="vp-balance vp-rise" style="--i:1">
                        <span class="vp-coin-stage"><?= vsCoin() ?></span>
                        <div class="vp-balance-text">
                            <span class="vp-balance-label">Ваш баланс</span>
                            <strong class="vp-balance-num" id="vpBalance" data-value="<?= (int)$vs_balance ?>"><?= number_format($vs_balance, 0, ',', ' ') ?> VS</strong>
                        </div>
                    </div>

                    <!-- Пополнение -->
                    <div class="vp-section vp-rise" style="--i:2" id="vpTopup">
                        <h3>Пополнить баланс</h3>
                        <button type="button" class="vp-btn topup vp-btn-wide" data-open-topup>Пополнить баланс</button>
                        <p class="vp-note">Выберите сумму и удобный способ оплаты.</p>
                    </div>

                    <!-- Что входит -->
                    <div class="vp-section vp-rise" style="--i:3">
                        <h3>Что входит</h3>
                        <ul class="vp-features">
                            <li><span class="vp-check">✓</span>Значок V+ рядом с именем в профиле</li>
                            <li><span class="vp-check">✓</span>Поддержка развития SPACE</li>
                            <li><span class="vp-check">✓</span>Ранний доступ к новым функциям</li>
                        </ul>
                    </div>

                    </div><!-- /vp-col-info -->

                    <div class="vp-col vp-col-plans">
                    <!-- Тарифы -->
                    <?php
                    $plan_final = [];
                    foreach ($plans as $d => $pl) {
                        $plan_final[$d] = planCost($pl['cost'], $pl['discount']);
                    }
                    $min_d = min(array_keys($plans));
                    $best_duration = null;
                    if (count($plans) > 1) {
                        $best_rate = null;
                        foreach ($plans as $d => $pl) {
                            $rate = $plan_final[$d] / $d;
                            if ($best_rate === null || $rate < $best_rate) {
                                $best_rate = $rate;
                                $best_duration = $d;
                            }
                        }
                    }
                    ?>
                    <div class="vp-section vp-rise" style="--i:4; --plan-n:<?= count($plans) ?>">
                        <h3><?= $is_active ? 'Продлить подписку' : 'Выберите тариф' ?></h3>

                        <?php foreach ($plans as $d => $pl):
                            $final = $plan_final[$d];
                            $short = max(0, $final - $vs_balance);
                            $months = max(1, (int)round($d / 30));
                            $per_month = (int)round($final / ($d / 30));
                            $saving = (int)round(($plan_final[$min_d] / $min_d) * $d) - $final;
                        ?>
                            <?php
                            // «12 месяцев» → крупная цифра + подпись; если название нестандартное — выводим его целиком.
                            $term_num = null;
                            $term_unit = $pl['label'];
                            if (preg_match('/^\s*(\d+)\s+(.+)$/u', $pl['label'], $tm)) {
                                $term_num = $tm[1];
                                $term_unit = $tm[2];
                            }
                            ?>
                            <form method="POST" data-lock class="vp-plan <?= $d === $best_duration ? 'best' : '' ?>">
                                <input type="hidden" name="form_token" value="<?= htmlspecialchars($_SESSION['form_token'], ENT_QUOTES, "UTF-8") ?>">
                                <input type="hidden" name="duration" value="<?= (int)$d ?>">

                                <?php if ($d === $best_duration): ?><span class="vp-plan-flag">Выгоднее всего</span><?php endif; ?>

                                <div class="vp-plan-main">
                                    <?php if ($pl['discount'] > 0): ?>
                                        <span class="vp-plan-off" title="Скидка"><?= '−' . (int)$pl['discount'] ?>%</span>
                                    <?php endif; ?>

                                    <div class="vp-plan-term">
                                        <?php if ($term_num !== null): ?>
                                            <span class="vp-term-num"><?= htmlspecialchars($term_num, ENT_QUOTES, "UTF-8") ?></span>
                                            <span class="vp-term-unit"><?= htmlspecialchars($term_unit, ENT_QUOTES, "UTF-8") ?></span>
                                        <?php else: ?>
                                            <span class="vp-term-unit only"><?= htmlspecialchars($term_unit, ENT_QUOTES, "UTF-8") ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <?php if (!($d === $min_d || $months <= 1)): ?>
                                        <div class="vp-plan-meta">Один платёж за весь срок</div>
                                    <?php endif; ?>
                                </div>

                                <div class="vp-plan-stub">
                                    <div class="vp-price">
                                        <?php if ($pl['discount'] > 0): ?>
                                            <s class="vp-old"><?= vsCoin() ?><?= number_format($pl['cost'], 0, ',', ' ') ?> VS</s>
                                        <?php endif; ?>
                                        <span class="vp-price-now"><?= vsCoin() ?><span><?= number_format($final, 0, ',', ' ') ?></span><small>VS</small></span>
                                    </div>
                                    <div class="vp-plan-short<?= $short > 0 ? '' : ' enough' ?>">
                                        <?= $short > 0 ? 'Не хватает ' . number_format($short, 0, ',', ' ') . ' VS' : 'Хватает с баланса' ?>
                                    </div>
                                    <?php if ($short > 0): ?>
                                        <button type="button" class="vp-btn topup" data-open-topup>Пополнить</button>
                                    <?php else: ?>
                                        <button type="submit" name="activate_premium" value="1" class="vp-btn"><?= $is_active ? 'Продлить' : 'Купить' ?></button>
                                    <?php endif; ?>
                                </div>
                            </form>
                        <?php endforeach; ?>

                    </div>
                    </div><!-- /vp-col-plans -->
                    </div><!-- /vp-cols -->

                </div>

            </div>

        </main>


        <div class="site-footer">
            <div class="footer-content">

                <a href="documents/v-space-info.pdf" class="footer-link" target="_blank" rel="noopener" data-pdf-open>О донате и VS</a>

                <span class="footer-copy">
                    SPACE &copy; <span class="year">2026</span>
                </span>

            </div>
        </div>

    </div>

    <!-- ===== ОКНО: ПОПОЛНЕНИЕ БАЛАНСА ===== -->
    <dialog class="vp-modal vp-modal-sm" id="topupModal" aria-labelledby="topupTitle">
        <form method="POST" data-lock class="vp-modal-box" id="topupForm">
            <input type="hidden" name="form_token" value="<?= htmlspecialchars($_SESSION['form_token'], ENT_QUOTES, "UTF-8") ?>">

            <div class="vp-modal-head">
                <h3 id="topupTitle">Пополнение баланса</h3>
                <button type="button" class="vp-modal-x" data-modal-close aria-label="Закрыть">✕</button>
            </div>

            <div class="vp-modal-body">
                <div class="vp-modal-label">Сумма</div>
                <div class="vp-amounts">
                    <?php foreach ($topup_amounts as $i => $amt): ?>
                        <label class="vp-amt">
                            <input type="radio" name="topup_amount" value="<?= (int)$amt ?>" <?= $amt === 500 ? 'checked' : '' ?> required>
                            <span><?= vsCoin() ?><?= number_format($amt, 0, ',', ' ') ?> VS</span>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div class="vp-modal-label">Способ оплаты</div>
                <div class="vp-pays">
                    <?php $first = true; foreach ($payment_methods as $key => $pm): ?>
                        <label class="vp-pay">
                            <input type="radio" name="payment_method" value="<?= htmlspecialchars($key, ENT_QUOTES, "UTF-8") ?>"
                                   data-label="<?= htmlspecialchars($pm['label'], ENT_QUOTES, "UTF-8") ?>" <?= $first ? 'checked' : '' ?> required>
                            <span class="vp-pay-body">
                                <span class="vp-pay-ico" aria-hidden="true"><?= $pm['icon'] ?></span>
                                <span class="vp-pay-text">
                                    <b><?= htmlspecialchars($pm['label'], ENT_QUOTES, "UTF-8") ?></b>
                                    <small><?= htmlspecialchars($pm['hint'], ENT_QUOTES, "UTF-8") ?></small>
                                </span>
                                <span class="vp-pay-dot" aria-hidden="true"></span>
                            </span>
                        </label>
                    <?php $first = false; endforeach; ?>
                </div>

                <div class="vp-summary" id="topupSummary" aria-live="polite"></div>
            </div>

            <div class="vp-modal-foot">
                <button type="button" class="vp-btn ghost" data-modal-close>Отмена</button>
                <button type="submit" name="topup_start" value="1" class="vp-btn">Перейти к оплате</button>
            </div>
        </form>
    </dialog>

    <!-- ===== ОКНО: PDF «О ДОНАТЕ И VS» ===== -->
    <dialog class="vp-modal vp-modal-pdf" id="pdfModal" aria-labelledby="pdfTitle">
        <div class="vp-modal-box">
            <div class="vp-modal-head">
                <h3 id="pdfTitle">О донате и VS</h3>
                <div class="vp-modal-actions">
                    <a class="vp-modal-link" href="documents/v-space-info.pdf" target="_blank" rel="noopener">В новой вкладке</a>
                    <button type="button" class="vp-modal-x" data-modal-close aria-label="Закрыть">✕</button>
                </div>
            </div>
            <div class="vp-pdf-wrap">
                <iframe id="pdfFrame" class="vp-pdf-frame" title="О донате и VS (PDF)"
                        data-src="documents/v-space-info.pdf#toolbar=1&amp;navpanes=0&amp;view=FitH"></iframe>
            </div>
            <div class="site-footer vp-pdf-foot">
                <div class="footer-content">
                    <span class="footer-copy">
                        SPACE &copy; <span class="year">2026</span>
                    </span>
                </div>
            </div>
        </div>
    </dialog>

<script>
    // Уведомления и меню профиля: открывается только одно из двух
    document.addEventListener('click', function (e) {
        var notif  = document.getElementById('notificationsDropdown');
        var avatar = document.getElementById('avatarDropdown');
        var cls = ['active', 'show', 'open'];
        function close(el) { if (el) cls.forEach(function (c) { el.classList.remove(c); }); }
        if (e.target.closest('#notificationsBtn')) close(avatar);
        else if (e.target.closest('#avatarBtn'))   close(notif);
    }, true);
    </script>
<script src="assets/js/script.js"></script>
<script src="assets/js/donate.js?v=<?= (int)@filemtime(__DIR__ . '/assets/js/donate.js') ?>"></script>

</body>
</html>
/* ==========================================================
   Окно V+ (рубли ₽). Открывается по клику на любой элемент [data-open-vplus]
   или через window.VPlus.open(). Всё покупается автоматически, без заявок.
   ========================================================== */
(function () {
    'use strict';

    var API = 'vplus.php';
    var ICON = window.VPLUS_ICON || 'images/donate.svg';
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    var overlay, body, state = null, busy = false, lastFocus = null, poll = null, quiet = false;
    var topupAmount = 0;           // сумма, введённая в блоке «Пополнить баланс»
    var PRESETS = [100, 300, 500, 1000];

    function fmt(n) { return new Intl.NumberFormat('ru-RU').format(n); }

    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined) n.textContent = text;
        return n;
    }

    function api(action, data) {
        var params = new URLSearchParams(data || {});
        params.set('action', action);
        if (state && state.csrf) params.set('csrf', state.csrf);
        return fetch(API, { method: 'POST', body: params, credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .catch(function () { return { ok: false, error: 'Нет соединения с сервером.' }; });
    }

    /* Плавный счётчик числа */
    function countUp(node, to, suffix, from) {
        suffix = suffix || '';
        if (reduce || from === undefined || from === to) { node.textContent = fmt(to) + suffix; return; }
        var start = performance.now(), dur = 700;
        (function tick(now) {
            var t = Math.min(1, (now - start) / dur);
            var e = 1 - Math.pow(1 - t, 3);
            node.textContent = fmt(Math.round(from + (to - from) * e)) + suffix;
            if (t < 1) requestAnimationFrame(tick);
        })(start);
    }

    /* ---------- Каркас окна ---------- */
    function build() {
        overlay = el('div', 'vplus-overlay');
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-label', 'V+');

        var modal = el('div', 'vplus-modal');
        body = el('div', 'vplus-body');
        var close = el('button', 'vplus-close', '✕');
        close.type = 'button';
        close.setAttribute('aria-label', 'Закрыть');
        close.addEventListener('click', hide);

        modal.appendChild(close);
        modal.appendChild(body);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) hide(); });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && overlay.classList.contains('open')) hide();
        });
    }

    function show() {
        if (!overlay) build();
        lastFocus = document.activeElement;
        body.innerHTML = '';
        body.appendChild(skeleton());
        overlay.classList.add('open');
        document.body.classList.add('vplus-lock');
        api('state').then(function (s) {
            if (!s.ok) { body.innerHTML = ''; body.appendChild(el('div', 'vplus-error', s.error || 'Ошибка загрузки.')); return; }
            state = s;
            render(null);
            startPoll();
        });
    }

    /* Цены/баланс могут поменяться (например, админом в reports.php) — подтягиваем без перезагрузки */
    function startPoll() {
        stopPoll();
        poll = setInterval(refresh, 10000);
    }
    function stopPoll() { if (poll) { clearInterval(poll); poll = null; } }
    function sig(s) { return JSON.stringify([s.plans, s.balance, s.active, s.expires]); }
    function refresh() {
        if (busy || !overlay.classList.contains('open') || document.hidden) return;
        api('state').then(function (s) {
            if (!s.ok || busy || !state || sig(s) === sig(state)) return;
            var prev = state;
            state = s;
            render(prev, true);
            toast('Цены обновились', 'ok');
        });
    }
    document.addEventListener('visibilitychange', function () { if (!document.hidden && overlay && overlay.classList.contains('open')) refresh(); });

    function hide() {
        stopPoll();
        overlay.classList.remove('open');
        document.body.classList.remove('vplus-lock');
        if (lastFocus && lastFocus.focus) lastFocus.focus();
    }

    function skeleton() {
        var w = el('div', 'vplus-skeleton');
        for (var i = 0; i < 4; i++) w.appendChild(el('div', 'vplus-skel-row'));
        return w;
    }

    /* ---------- Отрисовка ---------- */
    function render(prev, isQuiet) {
        var s = state;
        quiet = !!isQuiet;
        var scroll = body.scrollTop;
        body.innerHTML = '';
        var i = 0;
        function rise(node) { if (quiet) return node; node.classList.add('vplus-rise'); node.style.setProperty('--i', i++); return node; }

        /* Шапка */
        var head = rise(el('div', 'vplus-head'));
        var gem = el('div', 'vplus-gem');
        var img = document.createElement('img');
        img.src = ICON; img.alt = ''; img.width = 34; img.height = 34;
        gem.appendChild(img);
        head.appendChild(gem);
        var ht = el('div', 'vplus-head-text');
        ht.appendChild(el('div', 'vplus-title', s.active ? 'V+ активен' : 'V+ не активен'));
        var sub = el('div', 'vplus-sub');
        if (s.active && s.expires) {
            sub.appendChild(document.createTextNode('До ' + s.expires + ' (осталось '));
            var d = el('span', 'vplus-num');
            countUp(d, s.days_left, '', prev ? prev.days_left : 0);
            sub.appendChild(d);
            sub.appendChild(document.createTextNode(' дн.)'));
        } else {
            sub.textContent = 'Оформите подписку — включится мгновенно';
        }
        ht.appendChild(sub);
        head.appendChild(ht);
        body.appendChild(head);

        /* Баланс */
        var bal = rise(el('div', 'vplus-balance'));
        bal.appendChild(el('span', 'vplus-balance-label', 'Ваш баланс'));
        var bn = el('strong', 'vplus-balance-num');
        countUp(bn, s.balance, ' ₽', prev ? prev.balance : 0);
        bal.appendChild(bn);
        body.appendChild(bal);

        /* Пополнение баланса */
        body.appendChild(rise(topupBlock()));

        /* Что входит */
        var f = rise(el('div', 'vplus-section'));
        f.appendChild(el('h3', null, 'Что входит'));
        var ul = el('ul', 'vplus-features');
        ['Значок V+ рядом с именем в профиле', 'Поддержка развития SPACE', 'Ранний доступ к новым функциям']
            .forEach(function (t) {
                var li = el('li');
                li.appendChild(el('span', 'vplus-check', '✓'));
                li.appendChild(document.createTextNode(t));
                ul.appendChild(li);
            });
        f.appendChild(ul);
        body.appendChild(f);

        /* Тарифы */
        var ps = rise(el('div', 'vplus-section'));
        ps.appendChild(el('h3', null, s.active ? 'Продлить подписку' : 'Выберите тариф'));
        s.plans.forEach(function (p) { ps.appendChild(planCard(p)); });
        ps.appendChild(el('p', 'vplus-note', 'Оплата с баланса ₽, подписка включается сразу — без заявок и ожидания.'));
        body.appendChild(ps);

        body.scrollTop = scroll;
    }

    /* ---------- Пополнение баланса ---------- */
    function topupBlock() {
        var box = el('div', 'vplus-section vplus-topup');
        box.appendChild(el('h3', null, 'Пополнить баланс'));

        var chips = el('div', 'vplus-chips');
        var input = el('input', 'vplus-amount');
        input.type = 'number';
        input.inputMode = 'numeric';
        input.min = '1';
        input.step = '1';
        input.placeholder = 'Другая сумма, ₽';
        input.setAttribute('aria-label', 'Сумма пополнения, ₽');
        if (topupAmount > 0) input.value = topupAmount;

        var go = el('button', 'vplus-btn vplus-topup-btn', 'Пополнить');
        go.type = 'button';

        function sync() {
            var v = parseInt(input.value, 10) || 0;
            topupAmount = v > 0 ? v : 0;
            chips.querySelectorAll('.vplus-chip').forEach(function (c) {
                c.classList.toggle('on', parseInt(c.dataset.amount, 10) === topupAmount);
            });
            go.disabled = topupAmount < 1;
            go.textContent = topupAmount > 0 ? 'Пополнить на ' + fmt(topupAmount) + ' ₽' : 'Пополнить';
        }

        PRESETS.forEach(function (a) {
            var c = el('button', 'vplus-chip', fmt(a) + ' ₽');
            c.type = 'button';
            c.dataset.amount = a;
            c.addEventListener('click', function () { input.value = a; sync(); });
            chips.appendChild(c);
        });
        input.addEventListener('input', sync);
        input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); go.click(); } });
        go.addEventListener('click', function () { if (topupAmount > 0) topup(topupAmount, go); });

        box.appendChild(chips);
        var row = el('div', 'vplus-topup-row');
        row.appendChild(input);
        row.appendChild(go);
        box.appendChild(row);
        box.appendChild(el('p', 'vplus-note', 'Пополните баланс, затем оплатите подписку с него — без заявок и ожидания.'));
        sync();
        return box;
    }

    /* Кнопка «Пополнить» у тарифа: подставляем недостающую сумму и переходим к блоку пополнения */
    function goTopup(missing) {
        topupAmount = Math.max(1, missing);
        render(null, true);
        var input = body.querySelector('.vplus-amount');
        if (input) {
            input.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
            input.focus();
        }
    }

    function topup(amount, btn) {
        if (busy) return;
        busy = true;
        btn.disabled = true;
        btn.classList.add('loading');
        btn.textContent = '';

        api('topup', { amount: amount }).then(function (res) {
            busy = false;
            if (res.ok && res.url) {
                // Платёжная система: уходим на страницу оплаты
                window.location.href = res.url;
                return;
            }
            if (res.ok) {
                var prev = state;
                if (res.plans) state = res;
                topupAmount = 0;
                toast(res.message || 'Баланс пополнен', 'ok');
                render(prev);
            } else {
                toast(res.error || 'Не удалось пополнить баланс.', 'bad');
                btn.classList.remove('loading');
                btn.disabled = false;
                btn.textContent = 'Повторить';
            }
        });
    }

    function planCard(p) {
        var can = state.balance >= p.final;
        var card = el('div', 'vplus-plan' + (p.best ? ' best' : ''));
        card.dataset.months = p.months;

        var left = el('div', 'vplus-plan-left');
        var name = el('div', 'vplus-plan-name');
        name.appendChild(document.createTextNode(p.label));
        if (p.best) name.appendChild(el('span', 'vplus-tag', 'Выгоднее всего'));
        if (p.discount > 0) name.appendChild(el('span', 'vplus-tag sale', '−' + p.discount + '%'));
        left.appendChild(name);

        var meta;
        if (p.months === 1) meta = 'Без обязательств';
        else meta = fmt(p.per_month) + ' ₽ в месяц' + (p.saving > 0 ? ', экономия ' + fmt(p.saving) + ' ₽' : '');
        left.appendChild(el('div', 'vplus-plan-meta', meta));
        if (!can) left.appendChild(el('div', 'vplus-plan-short', 'Не хватает ' + fmt(p.final - state.balance) + ' ₽'));
        card.appendChild(left);

        var right = el('div', 'vplus-plan-right');
        var price = el('div', 'vplus-price');
        if (p.discount > 0) price.appendChild(el('s', 'vplus-old', fmt(p.base) + ' ₽'));
        price.appendChild(el('span', null, fmt(p.final) + ' ₽'));
        right.appendChild(price);

        var btn = el('button', 'vplus-btn', state.active ? 'Продлить' : 'Купить');
        btn.type = 'button';
        if (!can) {
            btn.textContent = 'Пополнить';
            btn.classList.add('topup');
            btn.addEventListener('click', function () { goTopup(p.final - state.balance); });
        } else {
            btn.addEventListener('click', function () { buy(p, btn, card); });
        }
        right.appendChild(btn);
        card.appendChild(right);
        return card;
    }

    /* ---------- Покупка ---------- */
    function buy(p, btn, card) {
        if (busy) return;
        busy = true;
        btn.classList.add('loading');
        btn.textContent = '';
        btn.disabled = true;

        api('buy', { months: p.months, expected: p.final }).then(function (res) {
            busy = false;
            if (res.ok) {
                var prev = state;
                state = res;
                btn.classList.remove('loading');
                btn.classList.add('done');
                btn.textContent = '✓';
                celebrate(card);
                toast(res.message || 'V+ активирован!', 'ok');
                setTimeout(function () { render(prev); }, reduce ? 0 : 900);
            } else {
                if (res.plans) { state = res; }
                card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake');
                toast(res.error || 'Не удалось оформить подписку.', 'bad');
                setTimeout(function () { if (res.plans) render(null); else { btn.classList.remove('loading'); btn.textContent = 'Повторить'; btn.disabled = false; } }, reduce ? 0 : 450);
            }
        });
    }

    function celebrate(card) {
        if (reduce) return;
        var colors = ['#f0b232', '#5865f2', '#57f287', '#eb459e', '#fee75c'];
        var box = el('div', 'vplus-confetti');
        for (var i = 0; i < 26; i++) {
            var c = el('i');
            var a = Math.random() * Math.PI * 2, r = 60 + Math.random() * 110;
            c.style.setProperty('--x', Math.cos(a) * r + 'px');
            c.style.setProperty('--y', Math.sin(a) * r - 30 + 'px');
            c.style.setProperty('--rot', Math.round(Math.random() * 540) + 'deg');
            c.style.background = colors[i % colors.length];
            c.style.animationDelay = (Math.random() * 80) + 'ms';
            box.appendChild(c);
        }
        card.appendChild(box);
        setTimeout(function () { box.remove(); }, 1300);
    }

    function toast(text, kind) {
        var old = overlay.querySelector('.vplus-toast');
        if (old) old.remove();
        var t = el('div', 'vplus-toast ' + kind, text);
        overlay.querySelector('.vplus-modal').appendChild(t);
        setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 300); }, 3200);
    }

    /* Ловим и новые кнопки [data-open-vplus], и старые [data-donate-open] (index.php?donate=1).
       Фаза перехвата + stopImmediatePropagation — старое окно с зашитыми ценами не откроется. */
    document.addEventListener('click', function (e) {
        var t = e.target.closest && e.target.closest('[data-open-vplus],[data-donate-open]');
        if (!t) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        show();
    }, true);

    /* Переход по ссылке index.php?donate=1 открывает окно сразу */
    document.addEventListener('DOMContentLoaded', function () {
        if (new URLSearchParams(location.search).get('donate') === '1') show();
    });

    window.VPlus = { open: show, close: hide };
})();

/* call-watch.js — входящие звонки на любой странице сайта (в «Сообщениях» звонки ведёт calls.js).
   Приложение V SPACE: сразу открывает «Сообщения» с этим человеком — там звонок на весь экран и в шторке.
   Браузер: плашка «Входящий звонок» с кнопками «Принять» и «Отклонить».
   Подключается из includes/bottom_nav.php. */
(function () {
    'use strict';
    if (window.__vsCallWatch) return;
    window.__vsCallWatch = true;
    try { if (window.top !== window.self) return; } catch (e) { return; }   // во встроенных окнах звонки слушает главная страница

    var me = document.currentScript;
    var CSRF = (me && me.getAttribute('data-csrf')) || '';
    var API = 'api/call.php', SEEN_KEY = 'vs_seen_calls';
    var RING = ['assets/js/call_ring.mp3', 'assets/ring/call_ring.mp3'];
    var lastId = 0, first = true, stopped = false, failDelay = 0, handled = {}, shown = null;

    // на странице свои звонки (calls.js) или открыто окно «Сообщений» — там всё покажут сами
    function callsHere() {
        return !!(window.VSCalls || document.querySelector('script[src*="assets/js/calls.js"]') ||
                  document.querySelector('iframe[src*="messages.php"]'));
    }
    function seenList() { try { return JSON.parse(localStorage.getItem(SEEN_KEY) || '[]') || []; } catch (e) { return []; } }
    function markSeen(id) {
        try {
            var l = seenList();
            if (l.indexOf(id) === -1) l.push(id);
            localStorage.setItem(SEEN_KEY, JSON.stringify(l.slice(-30)));
        } catch (e) {}
    }

    // звонок уже принят на другом устройстве (телефон / другая вкладка) — плашку убираем
    function taken(s) {
        if (s.type !== 'ringing') return false;
        try { return !!(JSON.parse(s.payload || 'null') || {}).taken; } catch (e) { return false; }
    }

    function next(ms) {
        if (stopped) return;
        if (ms <= 0) { Promise.resolve().then(poll); return; }   // сразу, без таймера: в фоне таймеры замедляются
        setTimeout(poll, ms);
    }

    function poll() {
        if (stopped) return;
        if (callsHere()) { stopped = true; return; }
        var ctrl = ('AbortController' in window) ? new AbortController() : null;
        var guard = setTimeout(function () { if (ctrl) ctrl.abort(); }, 35000);
        var started = Date.now(), init = first;
        fetch(API + '?action=poll&' + (init ? 'init=1' : 'wait=1') + '&since=' + lastId, {
            credentials: 'same-origin', cache: 'no-store', signal: ctrl ? ctrl.signal : undefined
        }).then(function (r) {
            if (r.status === 401 || r.status === 403 || r.status === 404) { stopped = true; throw new Error('stop'); }
            return r.json();
        }).then(function (d) {
            clearTimeout(guard);
            if (!d || !d.success) throw new Error('bad');
            failDelay = 0;
            if (init) first = false;
            var sigs = d.signals || [], finished = {};
            sigs.forEach(function (s) {
                if (s.type === 'hangup' || s.type === 'decline' || s.type === 'busy' || taken(s)) finished[s.call_id] = true;
            });
            sigs.forEach(function (s) {
                if (s.id <= lastId) return;
                lastId = s.id;
                if (finished[s.call_id]) { if (shown && shown.id === s.call_id) hideBanner(); return; }
                if (s.type === 'offer') onOffer(s);
            });
            if (d.last_id > lastId) lastId = d.last_id;
            var quick = Date.now() - started < 800;
            next(init ? 0 : (quick && !sigs.length ? 2500 : 0));
        }).catch(function () {
            clearTimeout(guard);
            if (stopped) return;
            failDelay = failDelay ? Math.min(failDelay * 2, 15000) : 1500;
            next(failDelay);
        });
    }

    function onOffer(s) {
        if ((s.age || 0) > 40 || handled[s.call_id] || seenList().indexOf(s.call_id) !== -1) return;
        try { var pl = JSON.parse(s.payload || '{}') || {}; if (pl.resume || pl.restart) return; } catch (e) {}   // это не новый звонок
        if (callsHere()) return;
        handled[s.call_id] = true;
        var url = 'messages.php?dialog=' + encodeURIComponent(s.from);
        if (window.VSpaceApp) {          // приложение: сразу к звонку (звонок на весь экран и в шторке)
            stopped = true;
            location.href = url;
            return;
        }
        showBanner(s, url);
    }

    /* ---------- плашка «Входящий звонок» (браузер) ---------- */

    var PHONE = 'M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1L6.6 10.8z';
    function icon(rot) {
        return '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"' +
            (rot ? ' style="transform:rotate(135deg)"' : '') + '><path d="' + PHONE + '"/></svg>';
    }
    function css() {
        if (document.getElementById('vsIncallCss')) return;
        var st = document.createElement('style');
        st.id = 'vsIncallCss';
        st.textContent =
            '.vs-incall{position:fixed;z-index:10020;top:16px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:12px;' +
            'width:min(92vw,420px);padding:10px 10px 10px 12px;border-radius:16px;border:1px solid rgba(255,255,255,.08);' +
            'background:linear-gradient(90deg,rgba(35,165,89,.22),rgba(35,165,89,.06)),#1e1f22;color:#f2f3f5;' +
            'box-shadow:0 12px 40px rgba(0,0,0,.5);font-family:inherit;animation:vsIncallIn .22s ease}' +
            '@keyframes vsIncallIn{from{opacity:0;transform:translate(-50%,-10px)}to{opacity:1;transform:translateX(-50%)}}' +
            '.vs-incall-ava{flex:none;width:44px;height:44px;border-radius:50%;overflow:hidden;display:flex;align-items:center;justify-content:center;' +
            'background:#5865f2;color:#fff;font-weight:700;font-size:18px;animation:vsIncallRing 1.6s ease-out infinite}' +
            '@keyframes vsIncallRing{0%{box-shadow:0 0 0 0 rgba(35,165,89,.6)}100%{box-shadow:0 0 0 14px rgba(35,165,89,0)}}' +
            '.vs-incall-ava img{width:100%;height:100%;object-fit:cover}' +
            '.vs-incall-text{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;cursor:pointer}' +
            '.vs-incall-text b{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
            '.vs-incall-text span{font-size:12.5px;color:#4fd68a}' +
            '.vs-incall-btn{flex:none;width:44px;height:44px;border:0;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:#fff;cursor:pointer;transition:transform .12s}' +
            '.vs-incall-btn:hover{transform:scale(1.07)}.vs-incall-btn:active{transform:scale(.95)}' +
            '.vs-incall-no{background:#ed4245}.vs-incall-yes{background:#23a559}' +
            '@media (prefers-reduced-motion:reduce){.vs-incall,.vs-incall-ava{animation:none}}';
        document.head.appendChild(st);
    }

    function ringStart() {
        try {
            var a = new Audio(RING[0]), i = 0;
            a.loop = true;
            a.addEventListener('error', function () { if (++i < RING.length) { a.src = RING[i]; a.play().catch(function () {}); } });
            var p = a.play();
            if (p && p.catch) p.catch(function () {});   // браузер не дал играть без нажатия — плашка всё равно видна
            return a;
        } catch (e) { return null; }
    }

    function showBanner(s, url) {
        hideBanner();
        css();
        var el = document.createElement('div');
        el.className = 'vs-incall';
        el.setAttribute('role', 'alertdialog');
        el.setAttribute('aria-label', 'Входящий звонок');
        el.innerHTML =
            '<div class="vs-incall-ava"></div>' +
            '<div class="vs-incall-text"><b></b><span></span></div>' +
            '<button type="button" class="vs-incall-btn vs-incall-no" title="Отклонить" aria-label="Отклонить">' + icon(true) + '</button>' +
            '<button type="button" class="vs-incall-btn vs-incall-yes" title="Принять" aria-label="Принять">' + icon(false) + '</button>';
        var name = s.from_name || 'Пользователь';
        el.querySelector('b').textContent = name;
        el.querySelector('span').textContent = s.media === 'video' ? 'Входящий видеозвонок' : 'Входящий звонок';
        var ava = el.querySelector('.vs-incall-ava');
        if (s.from_avatar) { var img = document.createElement('img'); img.src = s.from_avatar; img.alt = ''; ava.appendChild(img); }
        else ava.textContent = name.trim().charAt(0).toUpperCase();
        document.body.appendChild(el);

        var oldTitle = document.title;
        document.title = '📞 ' + name;
        shown = {
            id: s.call_id, el: el, title: oldTitle, audio: ringStart(),
            timer: setTimeout(hideBanner, Math.max(5, 45 - (s.age || 0)) * 1000)
        };
        el.querySelector('.vs-incall-yes').addEventListener('click', function () {
            hideBanner();
            location.href = url + '&answer=' + encodeURIComponent(s.call_id);   // «Сообщения» примут звонок сами
        });
        el.querySelector('.vs-incall-text').addEventListener('click', function () { hideBanner(); location.href = url; });
        el.querySelector('.vs-incall-no').addEventListener('click', function () { decline(s); });
    }

    function hideBanner() {
        if (!shown) return;
        clearTimeout(shown.timer);
        if (shown.audio) { try { shown.audio.pause(); } catch (e) {} }
        if (shown.el && shown.el.parentNode) shown.el.parentNode.removeChild(shown.el);
        if (/^📞 /.test(document.title)) document.title = shown.title;
        shown = null;
    }

    function decline(s) {
        hideBanner();
        markSeen(s.call_id);
        var body = new URLSearchParams();
        body.set('to', String(s.from));
        body.set('call_id', s.call_id);
        body.set('type', 'decline');
        body.set('media', s.media || 'audio');
        body.set('payload', '');
        fetch(API + '?action=send', {
            method: 'POST', credentials: 'same-origin', keepalive: true,
            headers: { 'X-CSRF-Token': CSRF || ((document.body && document.body.dataset.csrfToken) || '') }, body: body
        }).catch(function () {});
    }

    /* ---------- прерванный звонок: вернуться в течение 3 минут ---------- */
    var RESUME_KEY = 'vs_call_resume', RESUME_MS = 180000;
    function freshResume() {
        try {
            var r = JSON.parse(localStorage.getItem(RESUME_KEY) || 'null');
            if (r && r.id && r.peerId && Date.now() - r.at < RESUME_MS) return r;
        } catch (e) {}
        return null;
    }
    function showResume(r) {
        hideBanner();
        css();
        var url = 'messages.php?dialog=' + encodeURIComponent(r.peerId);
        var el = document.createElement('div');
        el.className = 'vs-incall';
        el.setAttribute('role', 'alertdialog');
        el.innerHTML =
            '<div class="vs-incall-ava"></div>' +
            '<div class="vs-incall-text"><b></b><span>Звонок прервался — можно вернуться</span></div>' +
            '<button type="button" class="vs-incall-btn vs-incall-no" title="Завершить звонок" aria-label="Завершить звонок">' + icon(true) + '</button>' +
            '<button type="button" class="vs-incall-btn vs-incall-yes" title="Вернуться в звонок" aria-label="Вернуться в звонок">' + icon(false) + '</button>';
        var name = r.peerName || 'Пользователь';
        el.querySelector('b').textContent = name;
        var ava = el.querySelector('.vs-incall-ava');
        if (r.peerAvatar) { var img = document.createElement('img'); img.src = r.peerAvatar; img.alt = ''; ava.appendChild(img); }
        else ava.textContent = name.trim().charAt(0).toUpperCase();
        document.body.appendChild(el);
        shown = { id: r.id, el: el, title: document.title, audio: null, timer: setTimeout(hideBanner, Math.max(1000, r.at + RESUME_MS - Date.now())) };
        el.querySelector('.vs-incall-yes').addEventListener('click', function () { hideBanner(); location.href = url; });
        el.querySelector('.vs-incall-text').addEventListener('click', function () { hideBanner(); location.href = url; });
        el.querySelector('.vs-incall-no').addEventListener('click', function () {
            hideBanner();
            try { localStorage.removeItem(RESUME_KEY); } catch (e) {}
            var body = new URLSearchParams();
            body.set('to', String(r.peerId)); body.set('call_id', r.id); body.set('type', 'hangup');
            body.set('media', r.media || 'audio'); body.set('payload', '');
            fetch(API + '?action=send', {
                method: 'POST', credentials: 'same-origin', keepalive: true,
                headers: { 'X-CSRF-Token': CSRF || ((document.body && document.body.dataset.csrfToken) || '') }, body: body
            }).catch(function () {});
        });
    }

    function start() {
        if (callsHere()) return;
        var r = freshResume();
        if (r) {
            if (window.VSpaceApp) { location.href = 'messages.php?dialog=' + encodeURIComponent(r.peerId); return; }   // приложение: сразу назад в звонок
            showResume(r);
        }
        poll();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
})();

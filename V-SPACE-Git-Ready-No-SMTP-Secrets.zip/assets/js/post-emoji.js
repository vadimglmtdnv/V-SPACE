// ============================================================
// post-emoji.js — простой пикер эмодзи для постов и комментариев.
// Не зависит от emoji.js из переписки (там своя, более тяжёлая логика
// под чат) — здесь достаточно вставить символ в текстовое поле.
//
// Работает с любой кнопкой .emoji-button[data-target="idПоля"]:
// открывает панель рядом с кнопкой, по клику на эмодзи вставляет его
// в поле с этим id на месте курсора и не закрывается, чтобы можно
// было добавить сразу несколько эмодзи подряд.
// ============================================================
(function () {
    var EMOJI_LIST = [
        '😀', '😁', '😂', '🤣', '😊', '😉', '😍', '😘',
        '😎', '🤩', '🥳', '🙃', '😅', '😇', '🤔', '🤨',
        '😐', '😴', '🥱', '😭', '😢', '😡', '🤬', '😱',
        '😳', '🥺', '😬', '🤗', '🤭', '🤫', '🤤', '😷',
        '👍', '👎', '👏', '🙌', '🤝', '🙏', '💪', '✌️',
        '👋', '🤞', '👌', '🤙', '🫶', '❤️', '🧡', '💛',
        '💚', '💙', '💜', '🖤', '🤍', '💔', '💯', '🔥',
        '✨', '🎉', '🎊', '⭐', '🌟', '💥', '👀', '🎵'
    ];

    var panel = null;
    var activeTarget = null;
    var activeBtn = null;

    function ensurePanel() {
        if (panel) return panel;
        panel = document.createElement('div');
        panel.className = 'emoji-picker-panel';
        panel.hidden = true;
        EMOJI_LIST.forEach(function (emoji) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.textContent = emoji;
            btn.addEventListener('click', function () {
                insertEmoji(emoji);
            });
            panel.appendChild(btn);
        });
        document.body.appendChild(panel);
        return panel;
    }

    function insertEmoji(emoji) {
        if (!activeTarget) return;
        var start = activeTarget.selectionStart;
        var end = activeTarget.selectionEnd;
        if (typeof start !== 'number' || typeof end !== 'number') {
            activeTarget.value += emoji;
        } else {
            var value = activeTarget.value;
            activeTarget.value = value.slice(0, start) + emoji + value.slice(end);
            var caret = start + emoji.length;
            activeTarget.setSelectionRange(caret, caret);
        }
        activeTarget.dispatchEvent(new Event('input', { bubbles: true }));
        activeTarget.focus();
    }

    function positionPanel(btn) {
        var rect = btn.getBoundingClientRect();
        var p = ensurePanel();
        p.style.visibility = 'hidden';
        p.hidden = false;

        var panelHeight = p.offsetHeight;
        var panelWidth = p.offsetWidth;
        var top = rect.top - panelHeight - 8;
        if (top < 8) top = rect.bottom + 8;   // не влезает сверху — показываем снизу

        var left = rect.left;
        if (left + panelWidth > window.innerWidth - 8) {
            left = window.innerWidth - panelWidth - 8;
        }
        if (left < 8) left = 8;

        p.style.top = top + 'px';
        p.style.left = left + 'px';
        p.style.visibility = 'visible';
    }

    function openPicker(btn) {
        var targetId = btn.getAttribute('data-target');
        var target = targetId ? document.getElementById(targetId) : null;
        if (!target) return;

        activeTarget = target;
        activeBtn = btn;
        btn.classList.add('active');
        positionPanel(btn);
    }

    function closePicker() {
        if (panel) panel.hidden = true;
        if (activeBtn) activeBtn.classList.remove('active');
        activeBtn = null;
        activeTarget = null;
    }

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('.emoji-button');
        if (btn) {
            event.preventDefault();
            if (activeBtn === btn) {
                closePicker();
            } else {
                openPicker(btn);
            }
            return;
        }
        // Клик вне кнопки и вне самой панели — закрыть
        if (panel && !panel.hidden && !event.target.closest('.emoji-picker-panel')) {
            closePicker();
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && panel && !panel.hidden) closePicker();
    });

    window.addEventListener('resize', function () {
        if (activeBtn) positionPanel(activeBtn);
    });
})();

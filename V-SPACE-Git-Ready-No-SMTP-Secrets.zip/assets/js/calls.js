/*
 * Звонки и видеозвонки (WebRTC) для messages.php.
 *
 * Звук/видео идут напрямую между браузерами. Служебные сообщения
 * (offer, answer, ice, ringing, hangup, decline, busy) передаются через api/call.php.
 *
 * Что сделано ради «естественности»:
 *  - мгновенный дозвон (длинный опрос) и честное «Звонит…» — гудки только когда
 *    у собеседника правда звонит;
 *  - эхоподавление, шумоподавление, автоусиление, настройка Opus (FEC, мягкий битрейт);
 *  - индикатор речи собеседника, значки «микрофон/камера выключены»;
 *  - автоматическое переподключение при обрыве связи (ICE restart);
 *  - окно можно свернуть, аудиозвонок не блокирует переписку;
 *  - приятные мелодии, вибрация, системное уведомление, экран не гаснет.
 *
 * Работает только на HTTPS (или localhost): иначе браузер не даст доступ к микрофону.
 */
(function () {
    'use strict';

    var API = 'api/call.php';
    // messages.php?answer=ID — «Принять» нажали на другой странице сайта (call-watch.js): принимаем звонок сразу
    var autoAnswer = (function () {
        try {
            var q = new URLSearchParams(location.search), a = q.get('answer');
            if (!a) return null;
            q.delete('answer');
            history.replaceState(null, '', location.pathname + (q.toString() ? '?' + q.toString() : '') + location.hash);
            return a;
        } catch (e) { return null; }
    })();
    var RING_TIMEOUT_MS = 45000;      // сколько ждём ответа
    var NO_RING_TIMEOUT_MS = 15000;   // если у собеседника вообще не зазвонило
    var CONNECT_TIMEOUT_MS = 20000;   // сколько ждём установления связи после ответа

    var state = 'idle';               // idle | calling | ringing | connecting | connected
    var pc = null, dc = null;
    var localStream = null, remoteStream = null;
    var call = null;                  // { id, peerId, peerName, peerAvatar, media, incoming, offer }
    var pendingIce = [], iceBatch = [];
    var iceTimer = null, ringTimeout = null, noRingTimer = null, connectTimer = null;
    var dropTimer = null, giveUpTimer = null, durationTimer = null, controlsTimer = null;
    var connectedAt = 0, restartAttempts = 0, reconnecting = false;
    // Вернуться в звонок можно 3 минуты: после обновления страницы, перезапуска приложения или обрыва интернета
    var RESUME_MS = 180000, RESUME_KEY = 'vs_call_resume';
    var leaveIntent = false, lastGoodAt = 0, reconnectSince = 0, heartbeat = 0;
    var resumeRid = '', resumeTimer = null, resumeTick = null, resumeDeadline = 0, restartTimer = null, restartHoldUntil = 0;
    var pendingResume = null, peerStartedAt = 0;
    var gotRinging = false;
    var lastSignalId = 0;
    var iceServers = null;
    var micOn = true, camOn = true;
    var remoteMicOff = false, remoteCamOff = false;
    var mini = false, currentMode = 'idle';
    var screen = null, shareBusy = false, shareOpen = false, remoteScreen = false;   // демонстрация экрана
    var overlay = null, notif = null, wake = null;
    var originalTitle = document.title;

    /* ---------- утилиты ---------- */

    function csrf() { return (document.body && document.body.dataset.csrfToken) || ''; }
    function $(id) { return document.getElementById(id); }

    function randomId() {
        var a = new Uint8Array(12);
        window.crypto.getRandomValues(a);
        return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    }

    function postSignal(peerId, callId, media, type, payload) {
        var body = new URLSearchParams();
        body.set('to', String(peerId));
        body.set('call_id', callId);
        body.set('type', type);
        body.set('media', media);
        body.set('payload', payload ? JSON.stringify(payload) : '');
        return fetch(API + '?action=send', {
            method: 'POST', credentials: 'same-origin', keepalive: true,
            headers: { 'X-CSRF-Token': csrf() }, body: body
        }).then(function (r) { return r.json(); }).catch(function () { return { success: false }; });
    }

    function sendSignal(type, payload) {
        if (!call) return Promise.resolve({ success: false });
        return postSignal(call.peerId, call.id, call.media, type, payload);
    }

    // Запись о звонке в переписку (messages.php?api=call_log). Пишут обе стороны, дубли сервер
    // отсекает по call_id. Вызывать ДО cleanup(): после него call и state уже сброшены.
    // forcedStatus: 'declined' | 'busy'; без него — 'answered', если связь была, иначе 'missed'.
    function logCall(forcedStatus) {
        if (!call) return;
        var connected = state === 'connected';
        var status = forcedStatus || (connected ? 'answered' : 'missed');
        var secs = (status === 'answered' && connected && connectedAt)
            ? Math.max(0, Math.round((Date.now() - connectedAt) / 1000)) : 0;
        var body = new URLSearchParams();
        body.set('call_id', call.id);
        body.set('peer_id', String(call.peerId));
        body.set('incoming', call.incoming ? '1' : '0');
        body.set('status', status);
        body.set('kind', (call.baseMedia === 'video' && call.media === 'video') ? 'video' : 'audio');
        body.set('duration', String(secs));
        try {
            fetch('messages.php?api=call_log', {
                method: 'POST', credentials: 'same-origin', keepalive: true,
                headers: { 'X-CSRF-Token': csrf() }, body: body
            }).catch(function () {});
        } catch (e) {}
    }

    function toast(text) {
        var t = document.createElement('div');
        t.className = 'call-toast';
        t.textContent = text;
        document.body.appendChild(t);
        var life = Math.max(3200, String(text || '').length * 60);   // длинное сообщение висит дольше
        setTimeout(function () { t.classList.add('hide'); }, life);
        setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, life + 500);
    }

    function fmtDuration(sec) {
        var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
        var mm = (m < 10 ? '0' : '') + m, ss = (s < 10 ? '0' : '') + s;
        return h > 0 ? h + ':' + mm + ':' + ss : mm + ':' + ss;
    }

    /* ---------- звуки (без внешних файлов) ---------- */

    var audioCtx = null, toneTimer = null, ringAudio = null;

    // Мелодия входящего звонка. Ищем call_ring.mp3 сначала рядом с calls.js (assets/js/),
    // потом в assets/ring/ — работает любой из вариантов.
    var RING_SRCS = (function () {
        var s = document.currentScript;
        var dir = (s && s.src) ? s.src.replace(/[^\/]*$/, '') : 'assets/js/';
        return [dir + 'call_ring.mp3', dir + '../ring/call_ring.mp3'];
    })();
    var RING_SRC = RING_SRCS[0];

    function getAudioCtx() {
        if (!audioCtx) {
            var AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return null;
            audioCtx = new AC();
        }
        if (audioCtx.state === 'suspended') audioCtx.resume().catch(function () {});
        return audioCtx;
    }

    // Мягкая нота «колокольчик»: быстрая атака, плавное затухание, лёгкая гармоника
    function note(freq, start, dur, vol) {
        var ctx = getAudioCtx();
        if (!ctx) return;
        var t0 = ctx.currentTime + start;
        [[1, 1], [2, 0.22]].forEach(function (h) {
            var osc = ctx.createOscillator(), g = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.value = freq * h[0];
            g.gain.setValueAtTime(0.0001, t0);
            g.gain.exponentialRampToValueAtTime(vol * h[1], t0 + 0.015);
            g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
            osc.connect(g); g.connect(ctx.destination);
            osc.start(t0); osc.stop(t0 + dur + 0.05);
        });
    }

    // Ровный гудок (для «гудков вызова» и «занято»)
    function tone(freq, start, dur, vol) {
        var ctx = getAudioCtx();
        if (!ctx) return;
        var t0 = ctx.currentTime + start;
        var osc = ctx.createOscillator(), g = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        g.gain.setValueAtTime(0, t0);
        g.gain.linearRampToValueAtTime(vol, t0 + 0.04);
        g.gain.setValueAtTime(vol, t0 + dur - 0.06);
        g.gain.linearRampToValueAtTime(0, t0 + dur);
        osc.connect(g); g.connect(ctx.destination);
        osc.start(t0); osc.stop(t0 + dur + 0.05);
    }

    function startTone(kind) {
        stopTone();
        var play, period;
        if (kind === 'incoming') {
            var synth = function () {
                [[659, 0], [784, .22], [988, .44], [784, .66], [659, 1.1], [784, 1.32], [988, 1.54], [1319, 1.76]]
                    .forEach(function (n) { note(n[0], n[1], 0.55, 0.16); });
            };
            var buzz = function () { if (navigator.vibrate) navigator.vibrate([500, 250, 500]); };
            var fallback = function (a, why) {
                // файл не загрузился или браузер не дал его проиграть — играем встроенный звук
                if (ringAudio !== a) return;          // звонок уже закончился
                if (window.console) console.warn('[calls] рингтон не сыграл (' + why + '): ' + RING_SRC);
                ringAudio = null;
                stopTone();
                toneTimer = setInterval(function () { synth(); buzz(); }, 3600);
                synth(); buzz();
            };
            try {
                var a = new Audio(RING_SRC);
                a.loop = true;
                a.volume = 1;
                ringAudio = a;
                var idx = 0;
                a.addEventListener('error', function () {
                    if (ringAudio !== a) return;
                    if (idx + 1 < RING_SRCS.length) {          // пробуем запасной путь
                        idx++;
                        a.src = RING_SRCS[idx];
                        var p2 = a.play();
                        if (p2 && p2.catch) p2.catch(function (err) { fallback(a, 'браузер не разрешил автозапуск: ' + (err && err.name)); });
                        return;
                    }
                    fallback(a, 'файл не найден ни в assets/js, ни в assets/ring');
                });
                var pr = a.play();
                if (pr && pr.catch) pr.catch(function (err) { fallback(a, 'браузер не разрешил автозапуск: ' + (err && err.name)); });
                buzz();
                toneTimer = setInterval(buzz, 4800);
                return;
            } catch (e) {
                if (window.console) console.warn('[calls] рингтон: ошибка', e);
                ringAudio = null;
            }
            period = 3600;
            play = function () { synth(); buzz(); };
        } else {
            period = 4000;   // европейские гудки вызова: 1 с звук, 3 с пауза
            play = function () { tone(425, 0, 1.0, 0.1); };
        }
        play();
        toneTimer = setInterval(play, period);
    }

    function stopTone() {
        if (toneTimer) { clearInterval(toneTimer); toneTimer = null; }
        if (ringAudio) { try { ringAudio.pause(); ringAudio.currentTime = 0; } catch (e) {} ringAudio = null; }
        if (navigator.vibrate) navigator.vibrate(0);
    }

    function chimeConnected() { note(523, 0, 0.35, 0.14); note(784, 0.12, 0.5, 0.14); }
    function chimeEnd()       { note(587, 0, 0.3, 0.12);  note(392, 0.16, 0.45, 0.12); }
    function busyTone()       { tone(425, 0, 0.35, 0.1); tone(425, 0.7, 0.35, 0.1); tone(425, 1.4, 0.35, 0.1); }

    /* ---------- интерфейс ---------- */

    var PHONE = 'M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z';
    function svg(path, size, extra) {
        return '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="currentColor"><path ' + (extra || '') + ' d="' + path + '"/></svg>';
    }
    var ICON = {
        spk:    svg('M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 7.97v8.05A4.5 4.5 0 0 0 16.5 12zM14 3.23v2.06a7 7 0 0 1 0 13.42v2.06A9 9 0 0 0 14 3.23z', 22),
        spkOff: svg('M3 9v6h4l5 5V4L7 9H3z', 22),
        mic:    svg('M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11h-2z', 22),
        micOff: svg('M19 11h-2a5 5 0 0 1-.6 2.4l1.5 1.5A7 7 0 0 0 19 11zM3.3 2.3 2 3.6l6.9 6.9V11a3 3 0 0 0 4.4 2.6l1.5 1.5A5 5 0 0 1 7 11H5a7 7 0 0 0 6 6.92V21h2v-3.08c.9-.13 1.7-.4 2.4-.8l4 4 1.3-1.3L3.3 2.3zM15 6a3 3 0 0 0-5.9-.8L15 11.1V6z', 22),
        cam:    svg('M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 4z', 22),
        camOff: svg('M21 6.5l-4 4V7a1 1 0 0 0-1-1H9.8l11.2 11.2V6.5zM3.3 2.3 2 3.6 4.4 6H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12c.2 0 .4-.1.6-.2l2.8 2.8 1.3-1.3L3.3 2.3z', 22),
        hang:   svg(PHONE, 24, 'transform="rotate(135 12 12)"'),
        accept: svg(PHONE, 24),
        mini:   svg('M19 13H5v-2h14v2z', 20),
        gear:   svg('M19.14 12.94c.04-.3.06-.61.06-.94s-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.48.48 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6a3.6 3.6 0 1 1 0-7.2 3.6 3.6 0 0 1 0 7.2z', 22),
        expand: svg('M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z', 20),
        screen: svg('M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.11-.89-2-2-2H4c-1.11 0-2 .89-2 2v10c0 1.1.89 2 2 2H0v2h24v-2h-4zm-7-3.53v-2.19c-2.78 0-4.61.85-6 2.72.56-2.67 2.11-5.33 6-5.87V7l4 3.73-4 3.74z', 22)
    };

    function buildOverlay() {
        if (overlay) return overlay;
        overlay = document.createElement('div');
        overlay.className = 'call-overlay';
        overlay.id = 'callOverlay';
        overlay.hidden = true;
        overlay.innerHTML =
            '<div class="call-panel" id="callPanel">' +
                '<video class="call-remote-bg" id="callRemoteBg" autoplay playsinline muted aria-hidden="true"></video>' +
                '<video class="call-remote-video" id="callRemoteVideo" autoplay playsinline muted></video>' +
                '<video class="call-local-video" id="callLocalVideo" autoplay playsinline muted></video>' +
                '<audio id="callRemoteAudio" autoplay></audio>' +
                '<button type="button" class="call-back-btn" id="callBackBtn" aria-label="Вернуться в сообщения">' +
                    '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg><span>Сообщения</span>' +
                '</button>' +
                '<div class="call-topbar">' +
                    '<button type="button" class="call-top-btn" id="callMiniBtn" title="Свернуть" aria-label="Свернуть">' + ICON.mini + '</button>' +
                    '<button type="button" class="call-top-btn" id="callFsBtn" title="На весь экран" aria-label="На весь экран">' + ICON.expand + '</button>' +
                '</div>' +
                '<div class="call-info">' +
                    '<div class="call-avatar" id="callAvatar"></div>' +
                    '<div class="call-name"><span id="callName"></span><span class="call-muted-badge" id="callMutedBadge" title="Микрофон выключен">' + ICON.micOff.replace('width="22" height="22"', 'width="14" height="14"') + '</span></div>' +
                    '<div class="call-status" id="callStatus"></div>' +
                '</div>' +
                '<div class="call-controls" id="callControls">' +
                    '<button type="button" class="call-ctrl" id="callMicBtn" title="Микрофон" aria-label="Микрофон"></button>' +
                    '<button type="button" class="call-ctrl" id="callCamBtn" title="Камера" aria-label="Камера"></button>' +
                    ((navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) ? '<button type="button" class="call-ctrl call-screen" id="callScreenBtn" title="Показать экран" aria-label="Показать экран">' + ICON.screen + '</button>' : '') +
                    '<button type="button" class="call-ctrl call-gear" id="callGearBtn" title="Настройки звука" aria-label="Настройки звука">' + ICON.gear + '</button>' +
                    '<button type="button" class="call-ctrl call-hangup" id="callHangupBtn" title="Завершить" aria-label="Завершить">' + ICON.hang + '</button>' +
                    '<button type="button" class="call-ctrl call-decline" id="callDeclineBtn" title="Отклонить" aria-label="Отклонить">' + ICON.hang + '</button>' +
                    '<button type="button" class="call-ctrl call-accept" id="callAcceptBtn" title="Принять" aria-label="Принять">' + ICON.accept + '</button>' +
                '</div>' +
            '</div>' +
                '<div class="call-settings" id="callSettings">' +
                '<div class="call-share-card" role="dialog" aria-label="Настройки звука">' +
                    '<div class="call-share-head"><span>Настройки звука</span><button type="button" class="call-share-close" id="callSettingsClose" title="Закрыть" aria-label="Закрыть">&times;</button></div>' +
                    '<label class="call-vol-row"><span>Громкость звонка <b id="callVolVal">100%</b></span><input type="range" class="call-range" id="callVol" min="0" max="100" step="1"></label>' +
                    '<label class="call-set-row"><span>Шумоподавление</span><input type="checkbox" id="callSetNs"><i></i></label>' +
                    '<label class="call-set-row"><span>Эхоподавление</span><input type="checkbox" id="callSetEc"><i></i></label>' +
                    '<label class="call-set-row"><span>Автоусиление</span><input type="checkbox" id="callSetAgc"><i></i></label>' +
                    '<div class="call-set-video" id="callSetVideo" hidden>' +
                        '<div class="call-settings-title">Камера</div>' +
                        '<select class="call-set-select" id="callSetCam" aria-label="Камера"></select>' +
                        '<select class="call-set-select" id="callSetQ" aria-label="Качество видео" hidden><option value="1080">1080p</option></select>' +
                        '<label class="call-set-row"><span>Зеркало для себя</span><input type="checkbox" id="callSetMirror"><i></i></label>' +
                    '</div>' +
                '</div>' +
                '</div>' +
            '<div class="call-share-menu" id="callShareMenu">' +
                '<div class="call-share-card" role="dialog" aria-label="Показать экран">' +
                    '<div class="call-share-head"><span>Показать экран</span><button type="button" class="call-share-close" id="callShareClose" title="Закрыть" aria-label="Закрыть">&times;</button></div>' +
                    '<button type="button" class="call-share-opt" data-kind="monitor"><b>Весь экран</b><span>Рабочий стол целиком. Если мониторов несколько — нужный выберете в окне браузера</span></button>' +
                    '<button type="button" class="call-share-opt" data-kind="window"><b>Окно или игра</b><span>Видно только выбранное окно или игру, остальное не показывается</span></button>' +
                    '<label class="call-set-row"><span>Передавать звук</span><input type="checkbox" id="callShareAudio"><i></i></label>' +
                    '<label class="call-vol-row"><span>Громкость звука экрана <b id="callShareVolVal">100%</b></span><input type="range" class="call-range" id="callShareVol" min="0" max="200" step="5"></label>' +
                    '<button type="button" class="call-share-opt call-share-stop" id="callShareStop" hidden><b>Остановить показ</b></button>' +
                    '<div class="call-share-hint">Звук браузер передаёт только при показе «Весь экран» или вкладки — у отдельного окна звука нет. Для игры лучше оконный режим «без рамки»: в «настоящем» полноэкранном захват окна может быть чёрным.</div>' +
                '</div>' +
            '</div>';
        document.body.appendChild(overlay);
        // размытие фона не используем нигде (задаём напрямую — не зависит от версии CSS в кэше)
        [overlay, $('callShareMenu'), $('callSettings')].forEach(function (el) {
            if (!el) return;
            el.style.backdropFilter = 'none';
            el.style.webkitBackdropFilter = 'none';
        });

        $('callHangupBtn').addEventListener('click', function () { hangup(true, ''); });
        $('callDeclineBtn').addEventListener('click', declineIncoming);
        $('callAcceptBtn').addEventListener('click', acceptIncoming);
        $('callMicBtn').addEventListener('click', toggleMic);
        // Приложение V SPACE: громкая связь (динамик) — переключает сам Android
        var appSpk = window.VSpaceApp;
        if (appSpk && typeof appSpk.toggleSpeaker === 'function') {
            var spk = document.createElement('button');
            spk.type = 'button'; spk.className = 'call-ctrl call-spk'; spk.id = 'callSpkBtn';
            spk.title = 'Динамик'; spk.setAttribute('aria-label', 'Динамик');
            var gearEl = $('callGearBtn');
            gearEl.parentNode.insertBefore(spk, gearEl);
            spk.addEventListener('click', function (e) {
                e.stopPropagation();
                try { appSpk.toggleSpeaker(); } catch (err) {}
                updateControlIcons();
            });
        }
        $('callCamBtn').addEventListener('click', toggleCam);
        var screenBtn = $('callScreenBtn');
        if (screenBtn) screenBtn.addEventListener('click', function (e) { e.stopPropagation(); setShareOpen(!shareOpen); });
        $('callShareMenu').addEventListener('click', function (e) {
            var opt = e.target.closest('[data-kind]');
            if (opt) { setShareOpen(false); startScreenShare(opt.getAttribute('data-kind')); return; }
            if (e.target.closest('#callShareStop')) { setShareOpen(false); stopScreenShare(); }
            else if (e.target === this || e.target.closest('#callShareClose')) setShareOpen(false);
        });
        $('callShareAudio').addEventListener('change', function () { saveSharePrefs({ audio: this.checked }); });
        document.addEventListener('pointerdown', function (e) {
            if (!settingsOpen) return;
            if (e.target.closest('#callSettings .call-share-card') || e.target.closest('#callGearBtn')) return;
            setSettingsOpen(false);
        });
        window.addEventListener('resize', function () { if (settingsOpen) positionSettings(); });
        $('callVol').addEventListener('input', function () {
            var p = volPrefs(); p.call = parseInt(this.value, 10) || 0; saveVolPrefs(p);
            showRange('callVol', 'callVolVal', p.call, 100);
            applyRemoteVolume();
        });
        $('callShareVol').addEventListener('input', function () {
            var p = volPrefs(); p.screen = parseInt(this.value, 10) || 0; saveVolPrefs(p);
            showRange('callShareVol', 'callShareVolVal', p.screen, 200);
            if (screen && screen.mix) screen.mix.gain.gain.value = p.screen / 100;   // меняется на лету
        });
        applyRemoteVolume();
        $('callSettings').addEventListener('click', function (e) {
            if (e.target === this || e.target.closest('#callSettingsClose')) setSettingsOpen(false);
        });
        $('callGearBtn').addEventListener('click', function (e) { e.stopPropagation(); setSettingsOpen(!settingsOpen); });
        ['callSetNs', 'callSetEc', 'callSetAgc'].forEach(function (id) {
            $(id).addEventListener('change', function () {
                saveAudioPrefs({ ns: $('callSetNs').checked, ec: $('callSetEc').checked, agc: $('callSetAgc').checked });
                applyAudioPrefsLive();
            });
        });
        $('callSetCam').addEventListener('change', function () { if (this.value) switchCamera(this.value, false); });
        $('callSetQ').addEventListener('change', function () {
            var p = videoPrefs(); p.q = this.value; saveVideoPrefs(p); applyQualityLive();
        });
        $('callSetMirror').addEventListener('change', function () {
            var p = videoPrefs(); p.mirror = this.checked; saveVideoPrefs(p); applyMirror();
        });
        applyMirror();
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { if (settingsOpen) setSettingsOpen(false); if (shareOpen) setShareOpen(false); } });
        $('callMiniBtn').addEventListener('click', function (e) { e.stopPropagation(); setMini(true); });
        $('callBackBtn').addEventListener('click', function (e) { e.stopPropagation(); setMini(true); });
        $('callFsBtn').addEventListener('click', function (e) {
            e.stopPropagation();
            var el = overlay;
            if (document.fullscreenElement) { document.exitFullscreen(); }
            else if (el.requestFullscreen) { el.requestFullscreen().catch(function () {}); }
        });
        // клик по свёрнутому окну разворачивает его
        $('callPanel').addEventListener('click', function (e) {
            if (dragMoved) { dragMoved = false; return; }
            if (mini && !e.target.closest('button')) setMini(false);
        });
        initDrag();
        ['loadedmetadata', 'resize'].forEach(function (ev) {
            $('callRemoteVideo').addEventListener(ev, remoteFit);
            $('callLocalVideo').addEventListener(ev, localFit);
        });
        window.addEventListener('resize', remoteFit);
        document.addEventListener('fullscreenchange', remoteFit);
        // в видеозвонке панель управления скрывается, если мышь давно не двигали
        overlay.addEventListener('pointermove', wakeControls);
        overlay.addEventListener('pointerdown', wakeControls);
        return overlay;
    }

    /* ---------- перетаскивание плавающего окна (аудиозвонок и свёрнутое окно) ---------- */

    var dragX = 0, dragY = 0, dragMoved = false;

    function isDraggable() {
        if (!overlay) return false;
        if (!mini && window.matchMedia('(max-width: 640px)').matches) return false;   // телефон: окно на весь экран
        return mini || (currentMode === 'active' && !(call && call.media === 'video'));
    }

    function applyDrag() {
        var p = $('callPanel');
        if (p) p.style.transform = (dragX || dragY) ? 'translate(' + dragX + 'px,' + dragY + 'px)' : '';
    }

    function resetDrag() {
        if (!dragX && !dragY) return;
        dragX = 0; dragY = 0;
        applyDrag();
    }

    function initDrag() {
        var panel = $('callPanel');
        var start = null;

        panel.addEventListener('pointerdown', function (e) {
            if (!isDraggable() || e.button > 0 || e.target.closest('button, .call-settings, .call-share-menu')) return;
            var r = panel.getBoundingClientRect();
            start = { sx: e.clientX, sy: e.clientY, ox: dragX, oy: dragY, rect: r, id: e.pointerId };
            dragMoved = false;
            try { panel.setPointerCapture(e.pointerId); } catch (err) {}
        });

        panel.addEventListener('pointermove', function (e) {
            if (!start || e.pointerId !== start.id) return;
            var dx = e.clientX - start.sx, dy = e.clientY - start.sy;
            if (!dragMoved && Math.abs(dx) + Math.abs(dy) < 5) return;   // защита от случайного дрожания
            dragMoved = true;
            panel.classList.add('dragging');
            var M = 8, vw = window.innerWidth, vh = window.innerHeight, r = start.rect;
            // не даём окну уйти за экран
            dx = Math.min(Math.max(dx, M - r.left), vw - M - r.right);
            dy = Math.min(Math.max(dy, M - r.top), vh - M - r.bottom);
            dragX = start.ox + dx;
            dragY = start.oy + dy;
            applyDrag();
        });

        function end(e) {
            if (!start || (e && e.pointerId !== start.id)) return;
            try { panel.releasePointerCapture(start.id); } catch (err) {}
            start = null;
            panel.classList.remove('dragging');
            // dragMoved сбросится в обработчике click (если он придёт) или при следующем нажатии
            setTimeout(function () { dragMoved = false; }, 0);
        }
        panel.addEventListener('pointerup', end);
        panel.addEventListener('pointercancel', end);

        // при смене размера окна браузера возвращаем на место, чтобы не потерять окно за краем
        window.addEventListener('resize', resetDrag);
    }

    function wakeControls() {
        if (!overlay) return;
        overlay.classList.remove('ui-idle');
        clearTimeout(controlsTimer);
        if (currentMode === 'active' && call && call.media === 'video' && !mini) {
            controlsTimer = setTimeout(function () { overlay.classList.add('ui-idle'); }, 3500);
        }
    }

    function setMini(v) {
        mini = !!v;
        resetDrag();
        applyClasses();
        if (mini && document.fullscreenElement) document.exitFullscreen();
    }

    function applyClasses() {
        if (!overlay) return;
        var speaking = overlay.classList.contains('speaking');
        overlay.className = 'call-overlay mode-' + currentMode +
            (call && call.media === 'video' ? ' is-video' : ' is-audio') +
            (mini ? ' is-mini' : '') +
            (mini && window.matchMedia('(max-width: 640px)').matches ? ' is-bar' : '') +   // телефон: свёрнутый звонок — плашка внизу
            (settingsOpen && currentMode === 'active' && !mini ? ' settings-open' : '') +
            (shareOpen && currentMode === 'active' && !mini ? ' share-open' : '') +
            (remoteScreen ? ' remote-screen' : '') +
            (screen ? ' is-sharing' : '') +
            (remoteCamOff ? ' remote-cam-off' : '') +
            (remoteMicOff ? ' remote-mic-off' : '') +
            (camOn && localStream && localStream.getVideoTracks().length ? ' local-cam' : '') +
            (remoteAr && call && call.media === 'video' ? ' rv-sized' : '') +
            (speaking ? ' speaking' : '');
        // кнопка камеры в идущем звонке показывается независимо от версии CSS в кэше
        var camBtn = $('callCamBtn');
        if (camBtn) camBtn.style.display = (currentMode === 'active') ? 'inline-flex' : '';
        // размер свёрнутого окна задаём напрямую — его не перебьёт ни одно правило стилей
        // Свёрнутое окно: если у собеседника нет картинки — компактная карточка с аватаркой (как обычное окно звонка),
        // если есть — маленькое видео. Всё задаём напрямую, чтобы не зависеть от порядка правил в CSS.
        overlay.style.backdropFilter = 'none';
        overlay.style.webkitBackdropFilter = 'none';
        var panelEl = $('callPanel');
        if (panelEl) {
            // на телефоне свёрнутый звонок (и обычный, и видео) — плашка над нижней панелью, её размеры задаёт CSS
            var phoneBar = mini && window.matchMedia('(max-width: 640px)').matches;
            var compact = mini && remoteCamOff && !phoneBar;
            var ps = panelEl.style;
            ps.width = mini && !phoneBar ? '280px' : '';
            ps.height = mini && !phoneBar ? (compact ? 'auto' : '180px') : '';
            ps.minHeight = compact ? '0' : '';
            ps.padding = compact ? '18px 16px 16px' : '';
            ps.justifyContent = compact ? 'center' : '';
            var infoEl = overlay.querySelector('.call-info'), topEl = overlay.querySelector('.call-topbar');
            if (infoEl) {
                var is = infoEl.style;
                is.display = compact ? 'flex' : '';
                is.position = compact ? 'relative' : '';
                is.top = is.left = compact ? 'auto' : '';
                is.transform = compact ? 'none' : '';
                is.background = compact ? 'none' : '';
                is.padding = compact ? '0' : '';
                is.alignItems = compact ? 'center' : '';
                is.textAlign = compact ? 'center' : '';
            }
            if (topEl) topEl.style.display = mini ? 'none' : '';
        }
        remoteFit();   // видео собеседника: целиком или на всё окно (экран — всегда целиком)
        if (!isDraggable()) resetDrag();
    }

    /* ---------- видео собеседника целиком: «человека должно быть видно» ---------- */
    // Телефон присылает вертикальное видео, веб-камера — горизонтальное. Если форма видео и окна сильно
    // различается, показываем видео целиком (по бокам — размытая копия), а на компьютере само окно
    // принимает форму видео собеседника (CSS: .rv-sized и --rv-ar).
    var remoteAr = 0, localAr = 0, fitRaf = 0;
    function remoteFit() {
        if (!overlay) return;
        var rv = $('callRemoteVideo');
        if (!rv) return;
        if (rv.videoWidth && rv.videoHeight) {
            var ar = rv.videoWidth / rv.videoHeight;
            if (Math.abs(ar - remoteAr) > 0.01) {
                var first = !remoteAr;
                remoteAr = ar;
                overlay.style.setProperty('--rv-ar', ar.toFixed(4));
                if (first) { applyClasses(); return; }   // добавит rv-sized и снова вызовет remoteFit
            }
        }
        if (window.cancelAnimationFrame) cancelAnimationFrame(fitRaf);
        fitRaf = (window.requestAnimationFrame || setTimeout)(applyRemoteFit);
    }
    function applyRemoteFit() {
        var rv = $('callRemoteVideo'), bg = $('callRemoteBg'), panel = $('callPanel');
        if (!overlay || !rv || !panel) return;
        var contain = false;
        if (remoteAr && !mini && !remoteCamOff && call && call.media === 'video' && currentMode === 'active') {
            var pw = panel.clientWidth, ph = panel.clientHeight;
            if (pw && ph) {
                var par = pw / ph, diff = Math.max(par / remoteAr, remoteAr / par);
                // на компьютере человек должен быть виден целиком; на телефоне небольшую обрезку оставляем ради полного экрана
                contain = ((par < 1) !== (remoteAr < 1)) ? diff > 1.1 : diff > (isPhoneUi() ? 1.2 : 1.06);
            }
        }
        rv.style.objectFit = (remoteScreen || contain) ? 'contain' : '';
        if (bg) bg.style.display = (contain && !remoteScreen) ? 'block' : 'none';
    }
    function localFit() {
        var lv = $('callLocalVideo');
        if (!overlay || !lv || !lv.videoWidth || !lv.videoHeight) return;
        var ar = lv.videoWidth / lv.videoHeight;
        if (Math.abs(ar - localAr) > 0.01) { localAr = ar; overlay.style.setProperty('--lv-ar', ar.toFixed(4)); }
    }

    function setStatus(text) { var el = $('callStatus'); if (el) el.textContent = text; }

    function renderAvatar() {
        var box = $('callAvatar');
        if (!box || !call) return;
        box.textContent = '';
        if (call.peerAvatar) {
            var img = document.createElement('img');
            img.src = call.peerAvatar; img.alt = '';
            box.appendChild(img);
        } else {
            box.textContent = (call.peerName || '?').trim().charAt(0).toUpperCase();
        }
    }

    function showOverlay(mode) {
        buildOverlay();
        currentMode = mode;
        if (mode !== 'active') mini = false;
        overlay.hidden = false;
        applyClasses();
        $('callName').textContent = call ? call.peerName : '';
        renderAvatar();
        updateControlIcons();
        wakeControls();
    }

    function updateControlIcons() {
        if (!overlay) return;
        $('callMicBtn').innerHTML = micOn ? ICON.mic : ICON.micOff;
        var hasCam = !!(localStream && localStream.getVideoTracks().length);
        var camActive = camOn && hasCam;
        $('callCamBtn').innerHTML = camActive ? ICON.cam : ICON.camOff;
        var noMic = !!(localStream && !localStream.getAudioTracks().length);
        if (noMic) $('callMicBtn').innerHTML = ICON.micOff;
        $('callMicBtn').classList.toggle('off', !micOn || noMic);
        $('callMicBtn').title = noMic ? 'Разрешить микрофон' : 'Микрофон';
        $('callCamBtn').classList.toggle('off', !camActive);
        $('callLocalVideo').style.visibility = camActive ? 'visible' : 'hidden';
        overlay.classList.toggle('local-cam', camActive);   // телефон: своя камера на весь экран, пока идёт вызов
        var spkBtn = $('callSpkBtn');
        if (spkBtn) {
            var on = true;
            try { on = window.VSpaceApp.isSpeakerOn(); } catch (e) {}
            spkBtn.innerHTML = on ? ICON.spk : ICON.spkOff;
            spkBtn.classList.toggle('off', !on);
            spkBtn.title = on ? 'Динамик включён' : 'Динамик выключен';
        }
        var sb = $('callScreenBtn');
        if (sb) { sb.classList.toggle('live', !!screen); sb.title = screen ? 'Вы показываете экран' : 'Показать экран'; }
    }

    function hideOverlay() {
        clearTimeout(controlsTimer);
        if (document.fullscreenElement) document.exitFullscreen();
        if (overlay) {
            overlay.hidden = true;
            overlay.className = 'call-overlay';
            ['callRemoteVideo', 'callRemoteBg', 'callLocalVideo', 'callRemoteAudio'].forEach(function (id) {
                var el = $(id); if (el) el.srcObject = null;
            });
            overlay.style.removeProperty('--rv-ar');
            overlay.style.removeProperty('--lv-ar');
            var bgEl = $('callRemoteBg'); if (bgEl) bgEl.style.display = 'none';
        }
        remoteAr = 0; localAr = 0;
        mini = false; currentMode = 'idle'; settingsOpen = false; shareOpen = false; remoteScreen = false;
        remoteMicOff = false; remoteCamOff = false;
        document.title = originalTitle;
    }

    // Микрофона в звонке нет (не разрешили, был занят) — по нажатию на кнопку просим ещё раз и подключаем его к разговору
    var micBusy = false;
    function requestMic() {
        if (micBusy) return;
        var md = navigator.mediaDevices;
        if (!md || !md.getUserMedia) { toast(mediaErrorText(new Error('insecure'))); return; }
        micBusy = true;
        md.getUserMedia({ audio: audioConstraints(), video: false })
            .catch(function () { return md.getUserMedia({ audio: true, video: false }); })
            .then(function (s) {
                micBusy = false;
                var track = s.getAudioTracks()[0];
                if (!track) return;
                if (!call || !localStream) { track.stop(); return; }
                localStream.addTrack(track);
                micOn = true;
                updateControlIcons();
                appMic();
                if (!pc) return;
                var tr = null;
                if (pc.getTransceivers) pc.getTransceivers().forEach(function (t) {
                    if (!tr && t.receiver && t.receiver.track && t.receiver.track.kind === 'audio' && !t.sender.track) tr = t;
                });
                var done;
                if (tr) {
                    done = tr.sender.replaceTrack(track).then(function () {
                        if (tr.direction === 'sendrecv') return;
                        tr.direction = 'sendrecv';
                        return renegotiate();
                    });
                } else {
                    pc.addTrack(track, localStream);
                    done = renegotiate();
                }
                Promise.resolve(done).then(function () {
                    sendMediaState();
                    toast('Микрофон подключён');
                }).catch(function () { toast('Не удалось подключить микрофон, попробуйте ещё раз'); });
            })
            .catch(function (err) {
                micBusy = false;
                toast(mediaErrorText(err));
                appFixPermission(err, 'microphone', requestMic);
            });
    }

    // приложение: кнопка микрофона в уведомлении показывает текущее состояние
    function appMic() {
        var app = window.VSpaceApp;
        if (!app || typeof app.callMic !== 'function') return;
        try { app.callMic(!!(micOn && localStream && localStream.getAudioTracks().length)); } catch (e) {}
    }

    function toggleMic() {
        if (!localStream) return;
        if (!localStream.getAudioTracks().length) { requestMic(); return; }
        micOn = !micOn;
        localStream.getAudioTracks().forEach(function (t) { t.enabled = micOn; });
        updateControlIcons();
        sendMediaState();
        appMic();
    }

    // Включить камеру посреди обычного звонка: добавляем видеодорожку и договариваемся заново
    var camBusy = false;
    function enableCamera() {
        if (camBusy) return;
        if (!pc || !call || state !== 'connected') { toast('Подождите, пока соединение установится'); return; }
        if (pc.signalingState !== 'stable') { toast('Подождите секунду и повторите'); return; }
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { toast('Камера работает только на сайте с https://'); return; }
        camBusy = true;
        var c = call;
        var md = navigator.mediaDevices, camStage = 'media';
        md.getUserMedia({ video: videoConstraints(), audio: false }).catch(function (e) {
            if (e && (e.name === 'NotAllowedError' || e.name === 'SecurityError')) throw e;   // запрет — повторять бессмысленно
            return md.getUserMedia({ video: { facingMode: 'user' }, audio: false });       // фронтальная камера телефона
        }).catch(function (e) {
            if (e && (e.name === 'NotAllowedError' || e.name === 'SecurityError')) throw e;
            return md.getUserMedia({ video: true, audio: false });                          // любая камера
        }).then(function (s) {
            camStage = 'link';
            var nt = s.getVideoTracks()[0];
            if (!nt || call !== c || !pc) { s.getTracks().forEach(function (t) { t.stop(); }); throw new Error('cancelled'); }
            localStream.addTrack(nt);
            pc.addTrack(nt, localStream);
            camOn = true;
            c.media = 'video';
            $('callLocalVideo').srcObject = localStream;
            applyClasses();
            updateControlIcons();
            startCamWatch();
            return pc.createOffer().then(function (o) { return setLocal(o); }).then(function () {
                return sendSignal('offer', localDesc());
            });
        }).then(function () {
            sendMediaState();
            appCall(true);   // приложение: фоновый режим теперь и для камеры
        }).catch(function (err) {
            if (err && err.message === 'cancelled') return;
            if (camStage === 'link') { toast('Камера включена, но не удалось передать видео — попробуйте ещё раз'); return; }
            toast(cameraErrorText(err));
            appFixPermission(err, 'camera', enableCamera);
        }).then(function () { camBusy = false; });
    }

    // Доступ к камере/микрофону запрещён: окно с понятным объяснением и кнопкой «Открыть разрешения».
    // Вернулись из настроек с включённым доступом — окно закрывается и действие повторяется само.
    var permSheet = null;
    function appFixPermission(err, kind, retry) {
        var n = err && err.name;
        if (n !== 'NotAllowedError' && n !== 'SecurityError' && n !== 'PermissionDeniedError') return;
        var app = window.VSpaceApp;
        var isCam = kind === 'camera';
        var what = isCam ? 'камере' : 'микрофону', sw = isCam ? 'Камера' : 'Микрофон';
        var blockedBySite = policyBlocks(isCam ? 'camera' : 'microphone');
        var canOpen = !blockedBySite && !!(app && (typeof app.openAppSettings === 'function' || typeof app.requestMedia === 'function'));
        if (permSheet) permSheet.remove();
        permSheet = document.createElement('div');
        permSheet.className = 'call-pick perm-sheet';
        var how = app
            ? (canOpen
                ? 'Android запретил приложению V SPACE доступ к ' + what + '. Нажмите «Открыть разрешения» и включите «' + sw + '».'
                : 'Откройте на телефоне: Настройки → Приложения → V SPACE → Разрешения и включите «' + sw + '». Или установите новую версию приложения — в ней это окно открывается само.')
            : 'Браузер запретил сайту доступ к ' + what + '. Нажмите на значок слева от адреса сайта и разрешите «' + sw + '».';
        // что именно отказало: Android (разрешение приложения) или встроенный браузер
        var osOk = null;
        try { if (app && typeof app.hasPermission === 'function') osOk = !!app.hasPermission(kind); } catch (e) {}
        if (blockedBySite) {
            how = 'Доступ к ' + what + ' запрещён настройками сервера сайта (заголовок Permissions-Policy), а не телефоном или браузером. ' +
                  'Нужно обновить файлы сайта на сервере — после этого ' + (isCam ? 'камера заработает' : 'микрофон заработает') + ' без лишних действий.';
        } else if (osOk === true) {
            how = 'В настройках телефона доступ к ' + what + ' у приложения уже есть, но ' + (isCam ? 'камеру' : 'микрофон') + ' не отдал встроенный браузер. ' +
                  'Закройте приложение V SPACE полностью (смахните из недавних) и откройте снова. Если не поможет — проверьте, что в шторке телефона не выключен значок «Доступ к ' + (isCam ? 'камере' : 'микрофону') + '».';
        }
        var detail = (err && err.name ? err.name : '') + (err && err.message ? ': ' + err.message : '') +
                     (blockedBySite ? ' · Сервер: запрещено' : '') +
                     (osOk === null ? '' : ' · Android: ' + (osOk ? 'разрешено' : 'не разрешено'));
        permSheet.innerHTML =
            '<div class="call-pick-card" role="dialog" aria-label="Нет доступа к ' + what + '">' +
                '<div class="call-pick-head"><span>Нужен доступ к ' + what + '</span><button type="button" class="call-pick-x" aria-label="Закрыть">✕</button></div>' +
                '<p class="perm-text">' + how + '</p>' +
                (detail ? '<p class="perm-detail"></p>' : '') +
                (canOpen ? '<button type="button" class="perm-btn perm-open">Открыть разрешения</button>' : '') +
                '<button type="button" class="perm-btn perm-retry">Попробовать снова</button>' +
            '</div>';
        document.body.appendChild(permSheet);
        var box = permSheet;
        var det = box.querySelector('.perm-detail');
        if (det) det.textContent = 'Подробности: ' + detail;
        function done() { if (permSheet === box) { box.remove(); permSheet = null; } document.removeEventListener('visibilitychange', onBack); }
        function again() { done(); if (typeof retry === 'function') retry(); }
        function onBack() {
            if (document.hidden || permSheet !== box) return;
            var ok = false;
            try { ok = app && typeof app.hasPermission === 'function' && app.hasPermission(kind); } catch (e) {}
            if (ok) again();
        }
        document.addEventListener('visibilitychange', onBack);
        box.addEventListener('click', function (e) {
            if (e.target === box || e.target.closest('.call-pick-x')) { done(); return; }
            if (e.target.closest('.perm-retry')) { again(); return; }
            if (e.target.closest('.perm-open')) {
                try {
                    if (typeof app.openAppSettings === 'function') app.openAppSettings();
                    else app.requestMedia();
                } catch (e2) {}
            }
        });
    }

    // Камеру/микрофон может запретить сам сайт заголовком Permissions-Policy — тогда разрешения телефона ни при чём
    function policyBlocks(feature) {
        try {
            var fp = document.permissionsPolicy || document.featurePolicy;
            if (fp && typeof fp.allowsFeature === 'function') return !fp.allowsFeature(feature);
        } catch (e) {}
        return false;
    }

    function cameraErrorText(err) {
        var n = err && err.name;
        var inApp = !!window.VSpaceApp;
        if (n === 'NotAllowedError' || n === 'SecurityError' || n === 'PermissionDeniedError') {
            if (policyBlocks('camera')) return 'Камеру запрещают настройки сервера сайта';
            return inApp ? 'Нет доступа к камере'
                         : 'Нет доступа к камере — разрешите её в настройках сайта (значок слева от адреса)';
        }
        if (n === 'NotFoundError' || n === 'DevicesNotFoundError' || n === 'OverconstrainedError') return 'Камера не найдена';
        if (n === 'NotReadableError' || n === 'TrackStartError' || n === 'AbortError') return 'Камера занята другим приложением — закройте его и нажмите на кнопку камеры';
        return 'Камера недоступна' + (n ? ' (' + n + ')' : '');
    }

    function toggleCam() {
        if (!localStream) return;
        if (!localStream.getVideoTracks().length) {
            if (screen) { toast('Сначала остановите показ экрана'); return; }
            enableCamera();
            return;
        }
        camOn = !camOn;
        localStream.getVideoTracks().forEach(function (t) { t.enabled = camOn; });
        updateControlIcons();
        sendMediaState();
    }

    /* ---------- индикатор речи собеседника ---------- */

    var meter = null;

    function startMeter(stream) {
        stopMeter();
        var ctx = getAudioCtx();
        if (!ctx || !stream.getAudioTracks().length) return;
        try {
            var src = ctx.createMediaStreamSource(stream);
            var an = ctx.createAnalyser();
            an.fftSize = 512;
            src.connect(an);                       // в колонки не подключаем — звук играет <audio>
            var buf = new Uint8Array(an.fftSize), smooth = 0;
            meter = {
                src: src,
                timer: setInterval(function () {
                    an.getByteTimeDomainData(buf);
                    var sum = 0;
                    for (var i = 0; i < buf.length; i++) { var v = (buf[i] - 128) / 128; sum += v * v; }
                    var lvl = Math.min(1, Math.sqrt(sum / buf.length) * 5);
                    smooth = smooth * 0.6 + lvl * 0.4;
                    if (overlay) {
                        overlay.style.setProperty('--lvl', smooth.toFixed(2));
                        overlay.classList.toggle('speaking', smooth > 0.14);
                    }
                }, 80)
            };
        } catch (e) { meter = null; }
    }

    function stopMeter() {
        if (!meter) return;
        clearInterval(meter.timer);
        try { meter.src.disconnect(); } catch (e) {}
        meter = null;
        if (overlay) { overlay.style.removeProperty('--lvl'); overlay.classList.remove('speaking'); }
    }

    /* ---------- «экран не гаснет» и уведомления ---------- */

    function lockScreen() {
        if (navigator.wakeLock && navigator.wakeLock.request) {
            navigator.wakeLock.request('screen').then(function (w) { wake = w; }).catch(function () {});
        }
    }
    function unlockScreen() {
        if (wake) { wake.release().catch(function () {}); wake = null; }
    }

    function notifyIncoming() {
        if (!document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
        try {
            notif = new Notification(call.peerName, {
                body: call.media === 'video' ? 'Входящий видеозвонок' : 'Входящий звонок',
                tag: 'vs-call', requireInteraction: true, icon: call.peerAvatar || undefined
            });
            notif.onclick = function () { window.focus(); notif.close(); };
        } catch (e) { notif = null; }
    }
    function closeNotification() {
        if (notif) { try { notif.close(); } catch (e) {} notif = null; }
    }

    /* ---------- WebRTC ---------- */

    function loadConfig() {
        if (iceServers) return Promise.resolve(iceServers);
        return fetch(API + '?action=config', { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (d) { iceServers = (d && d.ice_servers) || [{ urls: 'stun:stun.l.google.com:19302' }]; return iceServers; })
            .catch(function () { iceServers = [{ urls: 'stun:stun.l.google.com:19302' }]; return iceServers; });
    }

    /* ---------- настройки звука (шестерёнка) ---------- */

    var AUDIO_KEY = 'vs_call_audio';
    var settingsOpen = false;

    function audioPrefs() {
        var p = { ns: true, ec: true, agc: true };
        try {
            var s = JSON.parse(localStorage.getItem(AUDIO_KEY) || '{}');
            if (s && typeof s === 'object') {
                if (typeof s.ns === 'boolean') p.ns = s.ns;
                if (typeof s.ec === 'boolean') p.ec = s.ec;
                if (typeof s.agc === 'boolean') p.agc = s.agc;
            }
        } catch (e) {}
        return p;
    }
    function saveAudioPrefs(p) {
        try { localStorage.setItem(AUDIO_KEY, JSON.stringify(p)); } catch (e) {}
    }
    function audioConstraints() {
        var p = audioPrefs();
        return { echoCancellation: p.ec, noiseSuppression: p.ns, autoGainControl: p.agc, channelCount: 1 };
    }
    // применяем к уже идущему звонку, без переподключения
    function applyAudioPrefsLive() {
        if (!localStream) return;
        var c = audioConstraints();
        localStream.getAudioTracks().forEach(function (t) {
            if (t.applyConstraints) {
                t.applyConstraints(c).catch(function () { toast('Браузер не смог изменить настройку на лету — она сработает со следующего звонка'); });
            }
        });
    }
    /* ---------- настройки камеры ---------- */

    var VIDEO_KEY = 'vs_call_video';
    var QUALITY = { '360': { w: 640, h: 360 }, '720': { w: 1280, h: 720 }, '1080': { w: 1920, h: 1080 } };

    function videoPrefs() {
        var p = { q: '1080', mirror: true, dev: '', manual: false };
        try {
            var s = JSON.parse(localStorage.getItem(VIDEO_KEY) || '{}');
            if (s && typeof s === 'object') {
                if (typeof s.mirror === 'boolean') p.mirror = s.mirror;
                if (typeof s.dev === 'string') p.dev = s.dev;
                if (s.manual === true) p.manual = true;
            }
        } catch (e) {}
        return p;
    }
    function saveVideoPrefs(p) {
        try { localStorage.setItem(VIDEO_KEY, JSON.stringify(p)); } catch (e) {}
    }
    function videoConstraints() {
        var p = videoPrefs(), q = QUALITY[p.q] || QUALITY['720'];
        var v = { width: { ideal: q.w }, height: { ideal: q.h }, frameRate: { ideal: 30 } };
        if (p.dev) v.deviceId = { ideal: p.dev }; else v.facingMode = 'user';
        return v;
    }
    // зеркальное отображение своего видео (только у меня на экране, собеседник видит как обычно)
    function applyMirror() {
        if (overlay) overlay.style.setProperty('--mirror', videoPrefs().mirror ? '-1' : '1');
    }
    function applyQualityLive() {
        if (!localStream) return;
        var q = QUALITY[videoPrefs().q] || QUALITY['720'];
        localStream.getVideoTracks().forEach(function (t) {
            if (t.applyConstraints) {
                t.applyConstraints({ width: { ideal: q.w }, height: { ideal: q.h }, frameRate: { ideal: 30 } })
                    .catch(function () { toast('Браузер не смог изменить качество на лету — оно сработает со следующего звонка'); });
            }
        });
    }
    function fillCameras() {
        var sel = $('callSetCam');
        if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;
        navigator.mediaDevices.enumerateDevices().then(function (list) {
            var cams = list.filter(function (d) { return d.kind === 'videoinput'; });
            var cur = '';
            var t = localStream && localStream.getVideoTracks()[0];
            if (t && t.getSettings) cur = t.getSettings().deviceId || '';
            sel.innerHTML = '';
            cams.forEach(function (d, i) {
                var o = document.createElement('option');
                o.value = d.deviceId;
                o.textContent = d.label || ('Камера ' + (i + 1));
                if (d.deviceId === cur) o.selected = true;
                sel.appendChild(o);
            });
            sel.disabled = cams.length < 2;
        }).catch(function () {});
    }
    // смена камеры прямо во время звонка, без переподключения
    function switchCamera(devId, auto) {
        var p = videoPrefs(); p.dev = devId; if (!auto) p.manual = true; saveVideoPrefs(p);
        if (screen) return;   // сейчас в эфире экран — камера подставится после остановки показа
        var old = localStream && localStream.getVideoTracks()[0];
        if (!old) return;
        var vc = videoConstraints();
        vc.deviceId = { exact: devId };
        navigator.mediaDevices.getUserMedia({ video: vc, audio: false }).then(function (s) {
            var nt = s.getVideoTracks()[0];
            nt.enabled = camOn;
            var sender = pc && pc.getSenders().filter(function (x) { return x.track && x.track.kind === 'video'; })[0];
            var done = function () {
                localStream.removeTrack(old);
                old.stop();
                localStream.addTrack(nt);
                $('callLocalVideo').srcObject = localStream;
                startCamWatch();
            };
            if (sender) {
                sender.replaceTrack(nt).then(done).catch(function () { nt.stop(); toast('Не удалось переключить камеру'); });
            } else { done(); }
        }).catch(function () {
            if (auto) { camTried[devId] = true; startCamWatch(); return; }   // эта не открылась — пробуем следующую
            toast('Не удалось включить выбранную камеру');
        });
    }

    /* ---------- своя камера: не виртуальная и не чёрная ---------- */
    // На компьютере первой в списке часто стоит виртуальная камера (OBS и т.п.) — без запущенной программы она
    // показывает чёрный экран. Такую камеру пропускаем, а если картинка чёрная несколько секунд — включаем другую.
    var VIRTUAL_CAM = /obs|virtual|nvidia broadcast|manycam|snap camera|xsplit|vmix|splitcam|e2esoft|youcam|camtwist|mmhmm/i;
    var camTried = {}, blackTimer = null;
    function camKey(t) {
        var st = {};
        try { st = t.getSettings ? t.getSettings() : {}; } catch (e) {}
        return st.deviceId || t.label || t.id;
    }
    function isPhoneUi() {
        return !!window.VSpaceApp || (window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
    }
    function startCamWatch() {
        clearInterval(blackTimer);
        var t = localStream && localStream.getVideoTracks()[0];
        var md = navigator.mediaDevices;
        if (!t || screen || !call) return;
        camTried[camKey(t)] = true;
        if (!isPhoneUi() && !videoPrefs().manual && VIRTUAL_CAM.test(t.label || '') && md && md.enumerateDevices) {
            md.enumerateDevices().then(function (list) {
                var real = list.filter(function (d) {
                    return d.kind === 'videoinput' && d.label && !VIRTUAL_CAM.test(d.label) && !camTried[d.deviceId];
                })[0];
                if (real) switchCamera(real.deviceId, true); else watchBlack(t);
            }).catch(function () { watchBlack(t); });
            return;
        }
        watchBlack(t);
    }
    function watchBlack(t) {
        clearInterval(blackTimer);
        var v = $('callLocalVideo');
        var cv = document.createElement('canvas');
        cv.width = 32; cv.height = 18;
        var g = cv.getContext('2d', { willReadFrequently: true });
        if (!v || !g) return;
        var started = Date.now(), dark = 0;
        blackTimer = setInterval(function () {
            var cur = localStream && localStream.getVideoTracks()[0];
            if (cur !== t || t.readyState !== 'live' || !t.enabled || !camOn || screen || !call || Date.now() - started > 15000) {
                clearInterval(blackTimer); return;
            }
            if (v.readyState < 2 || !v.videoWidth) return;
            var max = 0;
            try {
                g.drawImage(v, 0, 0, 32, 18);
                var d = g.getImageData(0, 0, 32, 18).data;
                for (var i = 0; i < d.length; i += 4) {
                    var l = d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11;
                    if (l > max) max = l;
                }
            } catch (e) { clearInterval(blackTimer); return; }
            if (max > 16) { clearInterval(blackTimer); return; }          // картинка есть — всё хорошо
            if (++dark >= 5) { clearInterval(blackTimer); onBlackCamera(t); }   // ~4 секунды подряд чёрный экран
        }, 800);
    }
    function onBlackCamera(t) {
        var hint = window.VSpaceApp
            ? 'Камера показывает чёрный экран — проверьте, не выключен ли «Доступ к камере» в шторке телефона и не закрыта ли камера'
            : 'Камера показывает чёрный экран — проверьте, не закрыта ли она шторкой, или выберите другую камеру в настройках звонка (шестерёнка)';
        var md = navigator.mediaDevices;
        if (isPhoneUi() || videoPrefs().manual || !md || !md.enumerateDevices) { toast(hint); return; }
        md.enumerateDevices().then(function (list) {
            var next = list.filter(function (d) { return d.kind === 'videoinput' && !camTried[d.deviceId]; })
                .sort(function (a, b) { return (VIRTUAL_CAM.test(a.label) ? 1 : 0) - (VIRTUAL_CAM.test(b.label) ? 1 : 0); })[0];
            if (!next) { toast(hint); return; }
            var curName = (t.label && t.label.length <= 48) ? '«' + t.label + '» ' : '';
            toast('Камера ' + curName + 'показывает чёрный экран — включаю ' + (next.label ? '«' + next.label + '»' : 'другую камеру'));
            switchCamera(next.deviceId, true);
        }).catch(function () { toast(hint); });
    }

    // всплывающее окно настроек — прямо над кнопкой-шестерёнкой
    function positionSettings() {
        var card = document.querySelector('#callSettings .call-share-card'), gear = $('callGearBtn');
        if (!card || !gear) return;
        var r = gear.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight, M = 8;
        var w = card.offsetWidth || 300;
        card.style.left = Math.min(Math.max(r.left + r.width / 2 - w / 2, M), Math.max(M, vw - w - M)) + 'px';
        card.style.bottom = Math.max(M, vh - r.top + 12) + 'px';
        card.style.maxHeight = Math.max(160, r.top - 12 - M) + 'px';
    }

    function setSettingsOpen(v) {
        settingsOpen = !!v;
        if (settingsOpen) {
            shareOpen = false;
            var p = audioPrefs();
            $('callSetNs').checked = p.ns;
            $('callSetEc').checked = p.ec;
            $('callSetAgc').checked = p.agc;
            showRange('callVol', 'callVolVal', volPrefs().call, 100);
            var hasVideo = !!(localStream && localStream.getVideoTracks().length);
            $('callSetVideo').hidden = !hasVideo;
            if (hasVideo) {
                var vp = videoPrefs();
                $('callSetQ').value = vp.q;
                $('callSetMirror').checked = vp.mirror;
                fillCameras();
            }
        }
        applyClasses();
        if (settingsOpen) positionSettings();
    }

    // Микрофон и камера. Если микрофона нет, он занят или запрещён — звонок всё равно идёт:
    // вы слышите (и видите) собеседника, а он вас — нет. Сообщение об этом показываем один раз.
    function getMedia(wantVideo) {
        var md = navigator.mediaDevices;
        function listenOnly(err) {
            toast(mediaErrorText(err) + '. Пока вы только слышите собеседника — нажмите на кнопку микрофона, чтобы включить его');
            appFixPermission(err, 'microphone', requestMic);
            return new MediaStream();
        }
        if (!md || !md.getUserMedia) return Promise.resolve(listenOnly(new Error('insecure')));
        var audio = audioConstraints();
        var video = wantVideo ? videoConstraints() : false;
        return md.getUserMedia({ audio: audio, video: video })
            .catch(function (err) {
                if (wantVideo) {
                    // сначала пробуем фронтальную камеру телефона, иначе — обычный звонок
                    return md.getUserMedia({ audio: audio, video: { facingMode: 'user' } }).catch(function (e2) {
                        toast(cameraErrorText(e2) + '. Звонок только со звуком');
                        appFixPermission(e2, 'camera', function () { if (state === 'connected') enableCamera(); });
                        return md.getUserMedia({ audio: audio, video: false });
                    });
                }
                throw err;
            })
            .catch(function () {
                // выбранного в настройках микрофона может уже не быть — пробуем любой
                return md.getUserMedia({ audio: true, video: false });
            })
            .catch(listenOnly);
    }

    function mediaErrorText(err) {
        var n = err && err.name;
        if (err && err.message === 'insecure') return 'Микрофон работает только на сайте с https://';
        if ((n === 'NotAllowedError' || n === 'SecurityError') && policyBlocks('microphone')) return 'Микрофон запрещают настройки сервера сайта';
        if (n === 'NotAllowedError' || n === 'SecurityError' || n === 'PermissionDeniedError') return window.VSpaceApp ? 'Нет доступа к микрофону' : 'Нет доступа к микрофону — разрешите его в настройках сайта (значок слева от адреса)';
        if (n === 'NotFoundError' || n === 'DevicesNotFoundError') return 'Микрофон не найден';
        if (n === 'NotReadableError' || n === 'TrackStartError' || n === 'AbortError') return 'Микрофон занят другим приложением — закройте его и нажмите на кнопку микрофона';
        return 'Микрофон недоступен' + (n ? ' (' + n + ')' : '');
    }

    // Opus: коррекция ошибок (FEC), моно, комфортный битрейт для речи
    function tuneSdp(sdp) {
        var m = sdp.match(/a=rtpmap:(\d+) opus\/48000\/2/i);
        if (!m) return sdp;
        var pt = m[1];
        var want = { minptime: '10', useinbandfec: '1', stereo: '0', 'sprop-stereo': '0', maxaveragebitrate: '48000' };
        var re = new RegExp('a=fmtp:' + pt + ' ([^\\r\\n]*)');
        if (re.test(sdp)) {
            return sdp.replace(re, function (_, params) {
                var map = {};
                params.split(';').forEach(function (p) {
                    p = p.trim(); if (!p) return;
                    var kv = p.split('=');
                    map[kv[0]] = kv.length > 1 ? kv[1] : null;
                });
                Object.keys(want).forEach(function (k) { map[k] = want[k]; });
                return 'a=fmtp:' + pt + ' ' + Object.keys(map).map(function (k) { return map[k] === null ? k : k + '=' + map[k]; }).join(';');
            });
        }
        return sdp.replace(m[0], m[0] + '\r\na=fmtp:' + pt + ' ' + Object.keys(want).map(function (k) { return k + '=' + want[k]; }).join(';'));
    }

    function setLocal(desc) {
        return pc.setLocalDescription({ type: desc.type, sdp: tuneSdp(desc.sdp) });
    }

    function localDesc() {
        return { sdp: pc.localDescription.sdp, type: pc.localDescription.type };
    }

    function tuneVideoSender() {
        if (!pc) return;
        pc.getSenders().forEach(function (s) {
            if (!s.track || s.track.kind !== 'video') return;
            try {
                var p = s.getParameters();
                if (!p.encodings || !p.encodings.length) p.encodings = [{}];
                p.encodings[0].maxBitrate = 4000000;
                p.encodings[0].maxFramerate = 30;
                p.degradationPreference = 'maintain-resolution';
                s.setParameters(p).catch(function () {});
            } catch (e) {}
        });
    }

    function sendMediaState() {
        if (dc && dc.readyState === 'open') {
            var hasVideo = !!(localStream && localStream.getVideoTracks().length);
            try { dc.send(JSON.stringify({ mic: micOn, cam: (camOn && hasVideo) || !!screen, screen: !!screen })); } catch (e) {}
        }
    }

    function setupChannel(ch) {
        dc = ch;
        dc.onopen = sendMediaState;
        dc.onmessage = function (e) {
            var m = null;
            try { m = JSON.parse(e.data); } catch (err) {}
            if (!m) return;
            remoteMicOff = m.mic === false;
            remoteCamOff = m.cam === false;
            var wasScreen = remoteScreen;
            remoteScreen = m.screen === true;
            if (m.cam === true && call && call.media !== 'video') call.media = 'video';   // собеседник показал камеру
            else if (m.cam === false) backToAudio(wasScreen && !remoteScreen);   // собеседник закончил показ экрана
            applyClasses();
            updateControlIcons();
        };
    }

    function createPeer(iceList, isCaller) {
        pc = new RTCPeerConnection({ iceServers: iceList, bundlePolicy: 'max-bundle', iceCandidatePoolSize: 2 });
        remoteStream = new MediaStream();
        restartAttempts = 0;

        localStream.getTracks().forEach(function (t) { pc.addTrack(t, localStream); });
        // без своего микрофона/камеры всё равно принимаем звук и видео собеседника
        if (isCaller && pc.addTransceiver) {
            if (!localStream.getAudioTracks().length) pc.addTransceiver('audio', { direction: 'recvonly' });
            if (call && call.media === 'video' && !localStream.getVideoTracks().length) pc.addTransceiver('video', { direction: 'recvonly' });
        }

        if (isCaller) setupChannel(pc.createDataChannel('ctl'));
        else pc.ondatachannel = function (e) { setupChannel(e.channel); };

        pc.ontrack = function (e) {
            var stream = (e.streams && e.streams[0]) || remoteStream;
            if (!(e.streams && e.streams[0])) remoteStream.addTrack(e.track);
            var rv = $('callRemoteVideo'), ra = $('callRemoteAudio');
            rv.srcObject = stream;      // видео
            ra.srcObject = stream;
            var rbg = $('callRemoteBg');
            if (rbg && rbg.srcObject !== stream) { rbg.srcObject = stream; var pb = rbg.play(); if (pb && pb.catch) pb.catch(function () {}); }
            applyRemoteVolume();      // звук (у <video> звук выключен, чтобы не было эха/удвоения)
            var p1 = rv.play(), p2 = ra.play();
            if (p1 && p1.catch) p1.catch(function () {});
            if (p2 && p2.catch) p2.catch(function () {});
            if (e.track.kind === 'audio') startMeter(stream);
        };

        pc.onicecandidate = function (e) {
            if (!e.candidate) return;
            iceBatch.push(e.candidate.toJSON ? e.candidate.toJSON() : e.candidate);
            if (!iceTimer) iceTimer = setTimeout(flushIce, 60);
        };

        pc.onconnectionstatechange = function () {
            if (!pc) return;
            var s = pc.connectionState;
            if (s === 'connected') {
                onConnected();
            } else if (s === 'disconnected' || s === 'failed') {
                onLinkDropped(s === 'failed');
            }
        };
    }

    function flushIce() {
        iceTimer = null;
        if (!iceBatch.length || !call) { iceBatch = []; return; }
        var batch = iceBatch; iceBatch = [];
        sendSignal('ice', batch);
    }

    function addRemoteIce(list) {
        (list || []).forEach(function (c) {
            if (pc && pc.remoteDescription) pc.addIceCandidate(c).catch(function () {});
            else pendingIce.push(c);
        });
    }

    function flushPendingIce() {
        var list = pendingIce; pendingIce = [];
        list.forEach(function (c) { pc.addIceCandidate(c).catch(function () {}); });
    }

    function onConnected() {
        clearTimeout(dropTimer); clearTimeout(giveUpTimer); giveUpTimer = null; clearTimeout(connectTimer);
        clearTimeout(resumeTimer); clearInterval(resumeTick); clearTimeout(restartTimer);
        resumeRid = ''; reconnectSince = 0; lastGoodAt = Date.now();
        if (state === 'connected') {          // связь восстановилась после обрыва
            reconnecting = false;
            if (connectedAt) setStatus(fmtDuration(Math.floor((Date.now() - connectedAt) / 1000)));
            tuneVideoSender();
            saveResume();
            return;
        }
        state = 'connected';
        appCall(true);
        reconnecting = false;
        clearTimeout(ringTimeout); clearTimeout(noRingTimer);
        stopTone();
        chimeConnected();
        if (!(call && call.resumed && connectedAt)) connectedAt = Date.now();   // вернулись в звонок — время идёт с начала разговора
        showOverlay('active');
        $('callLocalVideo').srcObject = localStream;
        setStatus(fmtDuration(Math.floor((Date.now() - connectedAt) / 1000)));
        clearInterval(durationTimer);
        durationTimer = setInterval(function () {
            if (!reconnecting) {
                setStatus(fmtDuration(Math.floor((Date.now() - connectedAt) / 1000)));
                lastGoodAt = Date.now();
                if (++heartbeat % 5 === 0) saveResume();   // приложение могут закрыть без предупреждения
            } else {
                setStatus(reconnectText());
            }
        }, 1000);
        saveResume();
        tuneVideoSender();
        sendMediaState();
        lockScreen();
        closeNotification();
    }

    // Обрыв связи: сначала тихо пробуем восстановить (ICE restart), и только потом сдаёмся
    function onLinkDropped(failed) {
        if (state !== 'connected' && state !== 'connecting') return;
        if (call && call.resumed && state === 'connecting') return;   // возвращаемся в звонок — попытки повторяет sendResumeOffer
        if (state === 'connected') {
            if (!reconnecting) { reconnectSince = Date.now(); saveResume(); }
            reconnecting = true;
            setStatus(reconnectText());
        }
        clearTimeout(dropTimer);
        dropTimer = setTimeout(function () {
            if (!pc || pc.connectionState === 'connected') return;
            tryRestart();
        }, failed ? 0 : 3000);
        if (!giveUpTimer) {
            giveUpTimer = setTimeout(function () {
                giveUpTimer = null;
                if (!pc || pc.connectionState !== 'connected') hangup(true, 'Соединение потеряно');
            }, state === 'connected' ? RESUME_MS : 20000);
        }
    }

    function reconnectText() {
        var left = Math.max(0, RESUME_MS - (Date.now() - (reconnectSince || Date.now())));
        return 'Переподключение… ' + fmtDuration(Math.ceil(left / 1000));
    }

    // Пока связи нет, звонивший каждые 8 секунд перезапускает соединение (интернет может вернуться в любой момент)
    function tryRestart() {
        clearTimeout(restartTimer);
        if (!pc || !call || state === 'idle' || pc.connectionState === 'connected') return;
        if (!call.incoming && Date.now() >= restartHoldUntil && pc.signalingState !== 'have-remote-offer') {
            restartAttempts++;
            pc.createOffer({ iceRestart: true }).then(function (o) { return setLocal(o); }).then(function () {
                var d = localDesc(); d.restart = true;
                return sendSignal('offer', d);
            }).catch(function () {});
        }
        restartTimer = setTimeout(tryRestart, 8000);
    }

    /* ---------- возвращение в звонок (обновили страницу, перезапустили приложение, пропал интернет) ---------- */

    function saveResume() {
        if (!call || !connectedAt) return;
        if (state === 'connected' && !reconnecting) lastGoodAt = Date.now();
        try {
            localStorage.setItem(RESUME_KEY, JSON.stringify({
                id: call.id, peerId: call.peerId, peerName: call.peerName, peerAvatar: call.peerAvatar,
                media: call.media, baseMedia: call.baseMedia, incoming: !!call.incoming,
                startedAt: connectedAt, at: lastGoodAt || Date.now(), mic: micOn, cam: camOn
            }));
        } catch (e) {}
    }
    function loadResume() {
        try {
            var r = JSON.parse(localStorage.getItem(RESUME_KEY) || 'null');
            if (r && r.id && r.peerId && Date.now() - r.at < RESUME_MS) return r;
        } catch (e) {}
        clearResume();
        return null;
    }
    function clearResume() { try { localStorage.removeItem(RESUME_KEY); } catch (e) {} }

    // закрыть соединение, не завершая звонок (дальше будет новое)
    function closePeer() {
        if (screen) { try { releaseScreen(screen, false); } catch (e) {} screen = null; }
        if (dc) { try { dc.close(); } catch (e) {} dc = null; }
        if (pc) {
            pc.ontrack = pc.onicecandidate = pc.onconnectionstatechange = pc.ondatachannel = null;
            try { pc.close(); } catch (e) {}
            pc = null;
        }
        clearTimeout(iceTimer); iceTimer = null;
        pendingIce = []; iceBatch = [];
        stopMeter();
    }

    // эта страница вернулась в звонок: заново берём микрофон/камеру и предлагаем собеседнику новое соединение
    function resumeCall(r) {
        state = 'connecting';
        micOn = r.mic !== false; camOn = r.cam !== false;
        call = {
            id: r.id, peerId: r.peerId, peerName: r.peerName || 'Пользователь', peerAvatar: r.peerAvatar || '',
            media: r.media === 'video' ? 'video' : 'audio', baseMedia: r.baseMedia || r.media, incoming: !!r.incoming, resumed: true
        };
        connectedAt = r.startedAt || Date.now();
        lastGoodAt = r.at;
        resumeDeadline = r.at + RESUME_MS;
        showOverlay('connecting');
        var tick = function () {
            var left = Math.max(0, resumeDeadline - Date.now());
            if (state === 'connecting') setStatus('Возвращаемся в звонок… ' + fmtDuration(Math.ceil(left / 1000)));
        };
        tick();
        resumeTick = setInterval(tick, 1000);
        var c = call;
        getMedia(call.media === 'video').then(function (stream) {
            if (call !== c) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
            localStream = stream;
            localStream.getAudioTracks().forEach(function (t) { t.enabled = micOn; });
            localStream.getVideoTracks().forEach(function (t) { t.enabled = camOn; });
            if (c.media === 'video' && !stream.getVideoTracks().length) { c.media = 'audio'; applyClasses(); }
            $('callLocalVideo').srcObject = localStream;
            appCall(true);
            updateControlIcons();
            if (pendingResume) { var o = pendingResume; pendingResume = null; onResumeOffer(o); return; }
            sendResumeOffer();
        });
    }

    function sendResumeOffer() {
        clearTimeout(resumeTimer);
        if (!call || !call.resumed || state !== 'connecting' || !localStream) return;
        if (Date.now() > resumeDeadline) { hangup(true, 'Не удалось вернуться в звонок'); return; }
        // ответ уже пришёл и соединение устанавливается — не мешаем
        if (pc && pc.remoteDescription && Date.now() - peerStartedAt < 12000 &&
            (pc.connectionState === 'connecting' || pc.iceConnectionState === 'checking')) {
            resumeTimer = setTimeout(sendResumeOffer, 4000);
            return;
        }
        closePeer();
        var c = call;
        loadConfig().then(function (ice) {
            if (call !== c || state !== 'connecting') return;
            createPeer(ice, true);
            peerStartedAt = Date.now();
            var rid = resumeRid = randomId();
            return pc.createOffer().then(function (o) { return setLocal(o); }).then(function () {
                var d = localDesc(); d.resume = rid;
                return sendSignal('offer', d);
            });
        }).catch(function () {});
        resumeTimer = setTimeout(sendResumeOffer, 8000);   // нет ответа (собеседник тоже без связи) — пробуем ещё
    }

    // собеседник вернулся в звонок: старое соединение закрываем и отвечаем на новое
    function onResumeOffer(off) {
        if (!call || (state !== 'connected' && state !== 'connecting')) return;
        var selfResuming = call.resumed && state === 'connecting';
        // вернулись оба одновременно — остаётся предложение того, кто звонил
        if (selfResuming && !call.incoming) return;
        if (resumeRid && pc && pc.signalingState === 'have-local-offer' && !call.incoming) return;
        if (!localStream) { pendingResume = off; return; }      // микрофон ещё включается — ответим сразу после
        clearTimeout(resumeTimer); clearTimeout(restartTimer); clearTimeout(dropTimer);
        resumeRid = '';
        // сами тоже возвращаемся: если за 8 секунд не соединились — предложим соединение сами
        if (selfResuming) resumeTimer = setTimeout(sendResumeOffer, 8000);
        restartHoldUntil = Date.now() + 15000;
        if (state === 'connected') {
            if (!reconnecting) reconnectSince = Date.now();
            reconnecting = true;
            setStatus(reconnectText());
        }
        if (!giveUpTimer) {
            giveUpTimer = setTimeout(function () {
                giveUpTimer = null;
                if (!pc || pc.connectionState !== 'connected') hangup(true, 'Соединение потеряно');
            }, RESUME_MS);
        }
        closePeer();
        var c = call;
        loadConfig().then(function (ice) {
            if (call !== c) return;
            createPeer(ice, false);
            peerStartedAt = Date.now();
            return pc.setRemoteDescription({ type: off.type, sdp: off.sdp }).then(function () {
                flushPendingIce();
                if (call.media !== 'video' && /m=video [1-9]/.test(off.sdp || '')) { call.media = 'video'; applyClasses(); updateControlIcons(); }
                return pc.createAnswer();
            }).then(function (a) { return setLocal(a); }).then(function () {
                var d = localDesc(); d.rid = off.resume;
                return sendSignal('answer', d);
            });
        }).catch(function () {});
    }

    function onRenegotiate(sig) {
        var offer = null;
        try { offer = JSON.parse(sig.payload); } catch (e) {}
        if (!offer || !pc) return;
        pc.setRemoteDescription({ type: offer.type, sdp: offer.sdp }).then(function () {
            if (call && call.media !== 'video' && /m=video [1-9]/.test(offer.sdp || '')) {
                call.media = 'video';
                applyClasses();
                updateControlIcons();
            }
            return pc.createAnswer();
        }).then(function (a) { return setLocal(a); }).then(function () {
            return sendSignal('answer', localDesc());
        }).catch(function () {});
    }

    /* ---------- демонстрация экрана ---------- */

    var SHARE_KEY = 'vs_call_share';

    function sharePrefs() {
        var p = { audio: true };
        try {
            var s = JSON.parse(localStorage.getItem(SHARE_KEY) || '{}');
            if (s && typeof s.audio === 'boolean') p.audio = s.audio;
        } catch (e) {}
        return p;
    }
    function saveSharePrefs(p) {
        try { localStorage.setItem(SHARE_KEY, JSON.stringify(p)); } catch (e) {}
    }

    var VOL_KEY = 'vs_call_vol';
    function volPrefs() {
        var p = { call: 100, screen: 100 };
        try {
            var s = JSON.parse(localStorage.getItem(VOL_KEY) || '{}');
            if (s && typeof s.call === 'number') p.call = Math.min(100, Math.max(0, s.call));
            if (s && typeof s.screen === 'number') p.screen = Math.min(200, Math.max(0, s.screen));
        } catch (e) {}
        return p;
    }
    function saveVolPrefs(p) {
        try { localStorage.setItem(VOL_KEY, JSON.stringify(p)); } catch (e) {}
    }
    function showRange(inputId, valId, value, max) {
        var inp = $(inputId), lab = $(valId);
        if (inp) { inp.value = value; inp.style.setProperty('--p', (value / max * 100) + '%'); }
        if (lab) lab.textContent = value + '%';
    }
    // громкость всего, что слышим от собеседника
    function applyRemoteVolume() {
        var ra = $('callRemoteAudio');
        if (ra) ra.volume = volPrefs().call / 100;
    }

    function setShareOpen(v) {
        shareOpen = !!v;
        if (shareOpen) {
            settingsOpen = false;
            $('callShareAudio').checked = sharePrefs().audio;
            showRange('callShareVol', 'callShareVolVal', volPrefs().screen, 200);
            $('callShareStop').hidden = !screen;
        }
        applyClasses();
    }

    function videoTransceiver() {
        if (!pc) return null;
        var list = pc.getTransceivers();
        for (var i = 0; i < list.length; i++) {
            var t = list[i];
            if (t.receiver && t.receiver.track && t.receiver.track.kind === 'video') return t;
        }
        return null;
    }
    // видео уже «в эфире» — дорожку можно подменить без нового согласования
    function canSendVideo(t) {
        return !!t && (t.currentDirection === 'sendrecv' || t.currentDirection === 'sendonly');
    }

    function renegotiate() {
        return pc.createOffer().then(function (o) { return setLocal(o); }).then(function () {
            return sendSignal('offer', localDesc());
        });
    }

    // Микрофон + звук экрана/игры смешиваем в одну дорожку
    function mixScreenAudio(sc) {
        var at = sc.stream.getAudioTracks()[0];
        var mic = localStream && localStream.getAudioTracks()[0];
        var ctx = getAudioCtx();
        var sender = null;
        if (pc) pc.getSenders().forEach(function (s) { if (!sender && s.track && s.track.kind === 'audio') sender = s; });
        if (!at || !mic || !ctx || !sender) return false;
        try {
            var dest = ctx.createMediaStreamDestination();
            var s1 = ctx.createMediaStreamSource(new MediaStream([mic]));
            var s2 = ctx.createMediaStreamSource(new MediaStream([at]));
            var g2 = ctx.createGain();
            g2.gain.value = volPrefs().screen / 100;
            s1.connect(dest); s2.connect(g2); g2.connect(dest);
            sender.replaceTrack(dest.stream.getAudioTracks()[0]).catch(function () {});
            sc.mix = { dest: dest, s1: s1, s2: s2, gain: g2, sender: sender, mic: mic };
            return true;
        } catch (e) { return false; }
    }

    function unmix(m) {
        try { m.sender.replaceTrack(m.mic).catch(function () {}); } catch (e) {}
        try { m.s1.disconnect(); m.s2.disconnect(); m.gain.disconnect(); } catch (e) {}
        try { m.dest.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    }

    function tuneScreenSender(sc) {
        var t = videoTransceiver();
        if (!t) return;
        try {
            var p = t.sender.getParameters();
            if (!p.encodings || !p.encodings.length) p.encodings = [{}];
            p.encodings[0].maxBitrate = 25000000;                     // высокий потолок под 1080p120
            p.encodings[0].scaleResolutionDownBy = 1;                 // не уменьшать картинку
            p.encodings[0].maxFramerate = 120;
            p.encodings[0].priority = 'high';
            p.encodings[0].networkPriority = 'high';
            p.degradationPreference = 'maintain-resolution';           // разрешение держим 1080p, не уменьшаем
            t.sender.setParameters(p).catch(function () {});
        } catch (e) {}
    }

    function noAudioHint(vt) {
        var s = (vt && vt.getSettings && vt.getSettings().displaySurface) || '';
        if (s === 'window') return 'Звук отдельного окна браузер не передаёт — для звука покажите «Весь экран» или вкладку';
        if (s === 'browser') return 'Звук вкладки выключен — в окне выбора отметьте «Поделиться звуком вкладки»';
        return 'Звук не передаётся — в окне выбора отметьте «Поделиться звуком системы»';
    }

    // kind: 'monitor' — весь экран (монитор выбирается в окне браузера), 'window' — окно или игра
    function startScreenShare(kind) {
        if (shareBusy) return;
        if (!pc || !call || state !== 'connected') { toast('Подождите, пока соединение установится'); return; }
        if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) { toast('Ваш браузер не умеет показывать экран'); return; }
        var direct = canSendVideo(videoTransceiver());
        if (!direct && pc.signalingState !== 'stable') { toast('Подождите секунду и повторите'); return; }

        shareBusy = true;
        var c = call, game = kind === 'window', wantAudio = sharePrefs().audio;
        var opts = {
            video: { displaySurface: game ? 'window' : 'monitor', width: { ideal: 1920, max: 1920 }, height: { ideal: 1080, max: 1080 }, frameRate: { ideal: 120, max: 120 } },
            audio: wantAudio ? { echoCancellation: false, noiseSuppression: false, autoGainControl: false, suppressLocalAudioPlayback: true } : false,
            selfBrowserSurface: 'exclude',
            surfaceSwitching: 'include',
            systemAudio: 'include',
            monitorTypeSurfaces: (game && !wantAudio) ? 'exclude' : 'include'   // без звука «Окно или игра» не предлагает мониторы
        };
        var ds = null, committed = false;

        navigator.mediaDevices.getDisplayMedia(opts).catch(function (err) {
            if (err && err.name === 'TypeError') return navigator.mediaDevices.getDisplayMedia({ video: true, audio: wantAudio });
            throw err;
        }).then(function (stream) {
            ds = stream;
            var vt = ds.getVideoTracks()[0];
            if (!vt || call !== c || !pc) throw new Error('cancelled');
            var prev = screen;
            var next = { stream: ds, vt: vt, kind: kind, mix: null, cam: prev ? prev.cam : (localStream.getVideoTracks()[0] || null) };
            try { vt.contentHint = 'motion'; } catch (e) {}   // приоритет плавности
            vt.addEventListener('ended', function () { if (screen === next) stopScreenShare(); });

            var t = videoTransceiver(), p;
            if (canSendVideo(t)) p = t.sender.replaceTrack(vt);
            else { pc.addTrack(vt, localStream); p = renegotiate(); }

            return p.then(function () {
                committed = true;
                if (prev) { screen = null; releaseScreen(prev, false); }
                screen = next;
                var audioNote = '', withSound = false;
                if (wantAudio) {
                    if (!ds.getAudioTracks().length) audioNote = noAudioHint(vt);
                    else if (!mixScreenAudio(next)) audioNote = 'Не удалось подключить звук экрана';
                    else withSound = true;
                }
                tuneScreenSender(next);
                if (prev && prev.autoMini) next.autoMini = true;
                else if (call.media === 'video' && !mini) { setMini(true); next.autoMini = true; }   // окно звонка не закрывает то, что показываете
                applyClasses();
                updateControlIcons();
                sendMediaState();
                var fps = 0;
                try { fps = Math.round(vt.getSettings().frameRate || 0); } catch (e) {}
                toast(audioNote || ((game ? 'Вы показываете окно или игру' : 'Вы показываете экран') + (withSound ? ' со звуком' : '') + (fps ? ' · ' + fps + ' к/с' : '')));
            });
        }).catch(function (err) {
            if (!committed && ds) ds.getTracks().forEach(function (t) { t.stop(); });
            if (err && (err.name === 'NotAllowedError' || err.name === 'AbortError' || err.message === 'cancelled')) return;   // закрыли окно выбора
            toast('Не удалось начать показ экрана');
        }).then(function () { shareBusy = false; });
    }

    function releaseScreen(sc, restore) {
        if (!sc) return null;
        var result = null;
        if (sc.mix) { unmix(sc.mix); sc.mix = null; }
        if (restore && pc) {
            var t = videoTransceiver();
            if (t) {
                var cam = (sc.cam && sc.cam.readyState === 'live') ? sc.cam : null;
                try { result = t.sender.replaceTrack(cam).catch(function () {}); } catch (e) {}
            }
        }
        sc.stream.getTracks().forEach(function (t) { try { t.stop(); } catch (e) {} });
        return result;
    }

    // Видео больше ни у кого нет — возвращаем компактное окно с аватаркой, как в обычном звонке.
    // force — вызвано окончанием показа экрана (возвращаемся при любом типе звонка);
    // без force — только если звонок изначально был аудио
    function backToAudio(force) {
        if (!call || call.media !== 'video') return;
        if (!force && call.baseMedia !== 'audio') return;
        var camActive = !!(camOn && localStream && localStream.getVideoTracks().length);
        if (!remoteCamOff || screen || camActive) return;
        call.media = 'audio';
        mini = false;
        resetDrag();
        applyClasses();
        updateControlIcons();
    }

    function stopScreenShare() {
        if (!screen) return;
        var sc = screen;
        screen = null;
        if (sc.autoMini && mini) setMini(false);     // окно, свёрнутое на время показа, разворачиваем обратно
        var p = releaseScreen(sc, true);
        (p || Promise.resolve()).then(function () { tuneVideoSender(); });
        backToAudio(true);
        applyClasses();
        updateControlIcons();
        sendMediaState();
    }

    /* ---------- исходящий звонок ---------- */

    function startCall(peerId, peerName, peerAvatar, media) {
        if (state !== 'idle') { toast('Вы уже разговариваете'); return; }
        if (!window.RTCPeerConnection) { toast('Ваш браузер не поддерживает звонки'); return; }

        state = 'calling';
        getAudioCtx();                      // разблокируем звук по клику
        micOn = true; camOn = true; gotRinging = false;
        if ('Notification' in window && Notification.permission === 'default') {
            try { Notification.requestPermission(); } catch (e) {}
        }

        var c = call = { id: randomId(), peerId: peerId, peerName: peerName, peerAvatar: peerAvatar, media: media, baseMedia: media, incoming: false };
        showOverlay('calling');
        setStatus('Соединение…');

        Promise.all([getMedia(media === 'video'), loadConfig()]).then(function (res) {
            var stream = res[0], ice = res[1];
            if (call !== c) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }   // отменили, пока шёл запрос доступа
            localStream = stream;
            appCall(true);
            if (c.media === 'video' && !stream.getVideoTracks().length) { c.media = 'audio'; applyClasses(); }
            $('callLocalVideo').srcObject = localStream;
            updateControlIcons();
            startCamWatch();

            createPeer(ice, true);
            return pc.createOffer().then(function (o) { return setLocal(o); }).then(function () {
                return sendSignal('offer', localDesc());
            }).then(function (r) {
                if (!r || !r.success) throw new Error('send_failed');
                setStatus('Вызов…');
                ringTimeout = setTimeout(function () { if (state === 'calling') hangup(true, 'Нет ответа'); }, RING_TIMEOUT_MS);
                noRingTimer = setTimeout(function () {
                    if (state === 'calling' && !gotRinging) hangup(true, 'Собеседник недоступен');
                }, NO_RING_TIMEOUT_MS);
            });
        }).catch(function (err) {
            if (call !== c) return;
            var text = (err && err.message === 'send_failed') ? 'Не удалось начать звонок' : mediaErrorText(err);
            cleanup();
            toast(text);
        });
    }

    /* ---------- уже показанные звонки: после F5 они больше не звонят ---------- */

    var SEEN_KEY = 'vs_seen_calls';

    function seenCalls() {
        try {
            var list = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');
            return Array.isArray(list) ? list : [];
        } catch (e) { return []; }
    }
    function wasSeen(id) { return seenCalls().indexOf(id) !== -1; }
    function markSeen(id) {
        try {
            var list = seenCalls();
            if (list.indexOf(id) === -1) list.push(id);
            localStorage.setItem(SEEN_KEY, JSON.stringify(list.slice(-30)));
        } catch (e) {}
    }

    /* ---------- входящий звонок ---------- */

    function onIncomingOffer(sig) {
        if (sig.age > 40) return;
        if (wasSeen(sig.call_id)) return;   // этот звонок уже показывали (например, до F5)
        markSeen(sig.call_id);
        if (state !== 'idle') {
            postSignal(sig.from, sig.call_id, sig.media, 'busy');
            return;
        }
        var offer = null;
        try { offer = JSON.parse(sig.payload); } catch (e) { return; }
        if (!offer || !offer.sdp) return;
        if (offer.resume || offer.restart) return;   // возвращение в чужой (уже завершённый здесь) звонок — не входящий

        state = 'ringing';
        micOn = true; camOn = true;
        call = {
            id: sig.call_id, peerId: sig.from, peerName: sig.from_name, peerAvatar: sig.from_avatar,
            media: sig.media === 'video' ? 'video' : 'audio', baseMedia: sig.media === 'video' ? 'video' : 'audio', incoming: true, offer: offer
        };
        pendingIce = [];
        showOverlay('incoming');
        setStatus(call.media === 'video' ? 'Входящий видеозвонок' : 'Входящий звонок');
        document.title = '📞 ' + call.peerName;
        // приложение свёрнуто — звонит само приложение (уведомление в шторке), страница молчит
        if (!(window.VSpaceApp && document.hidden)) startTone('incoming');
        notifyIncoming();
        appIncoming(true);
        loadConfig();                                  // готовим заранее, чтобы «Принять» срабатывало мгновенно
        sendSignal('ringing');                         // звонящий услышит гудки только сейчас

        ringTimeout = setTimeout(function () {
            if (state === 'ringing') endCall('Пропущенный звонок', false);
        }, Math.max(5000, RING_TIMEOUT_MS - sig.age * 1000));

        if (autoAnswer && (autoAnswer === sig.call_id || autoAnswer === '1')) {
            autoAnswer = null;
            setTimeout(acceptIncoming, 150);
        } else {
            appAction();   // «Принять»/«Отклонить» в уведомлении нажали, пока страница загружалась
        }
    }

    /* ---------- приложение V SPACE: входящий звонок в шторке ---------- */
    var appIncomingOn = false;
    function appIncoming(on) {
        var app = window.VSpaceApp;
        if (!app || typeof app.incomingCall !== 'function') return;
        try {
            if (on) { app.incomingCall(call ? String(call.peerName || '') : '', !!(call && call.media === 'video')); appIncomingOn = true; }
            else if (appIncomingOn) { app.incomingEnded(); appIncomingOn = false; }
        } catch (e) {}
    }
    // кнопка, нажатая в уведомлении о звонке
    function appAction() {
        var app = window.VSpaceApp;
        if (!app || typeof app.takeAction !== 'function' || state !== 'ringing') return;
        var a = '';
        try { a = app.takeAction() || ''; } catch (e) {}
        if (a === 'accept') acceptIncoming();
        else if (a === 'decline') declineIncoming();
    }
    // приложение снова на экране — звонит страница; свёрнуто — звонит уведомление
    function appVisible() { if (state === 'ringing' && !ringAudio && !toneTimer) startTone('incoming'); }
    function appHidden() { if (state === 'ringing' && window.VSpaceApp) stopTone(); }

    function acceptIncoming() {
        if (state !== 'ringing' || !call) return;
        state = 'connecting';
        clearTimeout(ringTimeout);
        stopTone(); closeNotification(); appIncoming(false);
        getAudioCtx();
        showOverlay('connecting');
        setStatus('Соединение…');

        var c = call;
        Promise.all([getMedia(c.media === 'video'), loadConfig()]).then(function (res) {
            var stream = res[0], ice = res[1];
            if (call !== c) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
            localStream = stream;
            appCall(true);
            if (c.media === 'video' && !stream.getVideoTracks().length) { c.media = 'audio'; applyClasses(); }
            $('callLocalVideo').srcObject = localStream;
            updateControlIcons();
            startCamWatch();

            createPeer(ice, false);
            return pc.setRemoteDescription({ type: c.offer.type, sdp: c.offer.sdp }).then(function () {
                flushPendingIce();
                return pc.createAnswer();
            }).then(function (a) { return setLocal(a); }).then(function () {
                return sendSignal('answer', localDesc());
            }).then(function () {
                connectTimer = setTimeout(function () {
                    if (state === 'connecting') hangup(true, 'Не удалось установить соединение');
                }, CONNECT_TIMEOUT_MS);
            });
        }).catch(function (err) {
            if (call !== c) return;
            var text = mediaErrorText(err);
            sendSignal('decline');
            cleanup();
            toast(text);
        });
    }

    function declineIncoming() {
        if (state !== 'ringing') return;
        sendSignal('decline');
        endCall('', false, undefined, 'declined');
    }

    /* ---------- завершение ---------- */

    function hangup(notifyPeer, message) {
        if (state === 'idle') return;
        if (notifyPeer) sendSignal('hangup');
        endCall(message, true);
    }

    function endCall(message, withSound, sound, logStatus) {
        var wasActive = state === 'connected';
        // приложение свёрнуто — «Пропущенный звонок» остаётся в шторке
        if (message === 'Пропущенный звонок' && call && call.incoming && window.VSpaceApp && typeof window.VSpaceApp.missedCall === 'function') {
            try { window.VSpaceApp.missedCall(String(call.peerName || ''), call.media === 'video'); } catch (e) {}
        }
        logCall(logStatus);
        cleanup();
        if (withSound || wasActive) { if (sound === 'busy') busyTone(); else chimeEnd(); }
        if (message) toast(message);
    }

    // Android-приложение V SPACE: сообщаем о звонке, чтобы он шёл в свёрнутом приложении и был виден в шторке
    var appCallOn = false;
    function appCall(on) {
        var app = window.VSpaceApp;
        if (!app) return;
        try {
            if (on) { app.callStarted(call ? String(call.peerName || '') : '', !!(call && call.media === 'video')); appCallOn = true; appMic(); updateControlIcons(); }
            else if (appCallOn) { app.callEnded(); appCallOn = false; }
        } catch (e) {}
    }

    function cleanup() {
        appCall(false);
        appIncoming(false);
        clearResume();
        clearTimeout(resumeTimer); clearInterval(resumeTick); clearTimeout(restartTimer);
        resumeRid = ''; reconnectSince = 0; lastGoodAt = 0; restartHoldUntil = 0; pendingResume = null;
        [ringTimeout, noRingTimer, connectTimer, dropTimer, giveUpTimer, iceTimer].forEach(clearTimeout);
        ringTimeout = noRingTimer = connectTimer = dropTimer = giveUpTimer = iceTimer = null;
        clearInterval(durationTimer);
        iceBatch = []; pendingIce = [];
        stopTone(); stopMeter(); unlockScreen(); closeNotification();
        clearInterval(blackTimer); camTried = {};
        if (screen) { try { releaseScreen(screen, false); } catch (e) {} screen = null; }
        shareBusy = false;
        if (dc) { try { dc.close(); } catch (e) {} dc = null; }
        if (pc) {
            pc.ontrack = pc.onicecandidate = pc.onconnectionstatechange = pc.ondatachannel = null;
            try { pc.close(); } catch (e) {}
            pc = null;
        }
        if (localStream) { localStream.getTracks().forEach(function (t) { t.stop(); }); localStream = null; }
        remoteStream = null; call = null; state = 'idle'; reconnecting = false; restartAttempts = 0;
        hideOverlay();
    }

    /* ---------- обработка сигналов ---------- */

    function handleSignal(sig) {
        if (sig.type === 'offer') {
            if (call && sig.call_id === call.id) {
                var off = sigPayload(sig);
                if (off.resume) { if ((sig.age || 0) <= 10) onResumeOffer(off); }   // собеседник вернулся в звонок (старые попытки пропускаем)
                else if (call.resumed && state !== 'connected') {}          // старое соединение — ждём ответ на своё
                else if (pc) onRenegotiate(sig);                            // перезапуск связи / экран в идущем звонке
            } else onIncomingOffer(sig);
            return;
        }
        if (!call || sig.call_id !== call.id) return;

        if (state === 'ringing' && call.incoming) {
            var why = elsewhere(sig);
            if (why) { endElsewhere(why); return; }
        }

        switch (sig.type) {
            case 'ringing':
                if (state === 'calling' && !call.incoming && !gotRinging) {
                    gotRinging = true;
                    clearTimeout(noRingTimer);
                    setStatus('Звонит…');
                    startTone('outgoing');
                }
                break;
            case 'answer':
                if (pc && pc.signalingState === 'have-local-offer') {
                    var ans = null;
                    try { ans = JSON.parse(sig.payload); } catch (e) {}
                    if (!ans) return;
                    if (ans.rid ? ans.rid !== resumeRid : (resumeRid && call.resumed)) return;   // ответ на старую попытку вернуться
                    if (state === 'calling') {
                        clearTimeout(ringTimeout); clearTimeout(noRingTimer);
                        // у собеседника звонок мог звонить сразу на телефоне и компьютере — на остальных устройствах он гаснет
                        if (!call.takenSent) { call.takenSent = true; postSignal(call.peerId, call.id, call.media, 'ringing', { taken: true }); }
                        stopTone();
                        state = 'connecting';
                        showOverlay('connecting');
                        setStatus('Соединение…');
                        connectTimer = setTimeout(function () {
                            if (state === 'connecting') hangup(true, 'Не удалось установить соединение');
                        }, CONNECT_TIMEOUT_MS);
                    }
                    pc.setRemoteDescription({ type: ans.type, sdp: ans.sdp }).then(flushPendingIce).catch(function () {
                        if (call && (call.resumed || reconnecting)) return;   // восстанавливаем связь — будет следующая попытка
                        hangup(true, 'Ошибка соединения');
                    });
                }
                break;
            case 'ice':
                var list = [];
                try { list = JSON.parse(sig.payload) || []; } catch (e) {}
                addRemoteIce(list);
                break;
            case 'hangup':
                endCall(state === 'ringing' ? 'Пропущенный звонок' : 'Собеседник завершил звонок', true);
                break;
            case 'decline':
                if (!call.incoming) postSignal(call.peerId, call.id, call.media, 'hangup', { reason: 'declined' });
                endCall('Собеседник отклонил звонок', true, undefined, 'declined');
                break;
            case 'busy':
                if (!call.incoming) postSignal(call.peerId, call.id, call.media, 'hangup', { reason: 'busy' });
                endCall('Собеседник занят', true, 'busy', 'busy');
                break;
        }
    }

    // Один и тот же человек открыт на нескольких устройствах (телефон и компьютер): входящий звонит везде.
    // Ответили или отклонили на одном — звонящий сообщает об этом, и на остальных звонок гаснет.
    function sigPayload(sig) {
        try { return JSON.parse(sig.payload || 'null') || {}; } catch (e) { return {}; }
    }
    function elsewhere(sig) {
        if (sig.type === 'ringing' && sigPayload(sig).taken) return 'Вы ответили на другом устройстве';
        if (sig.type === 'hangup') {
            var r = sigPayload(sig).reason;
            if (r === 'declined') return 'Звонок отклонён на другом устройстве';
            if (r === 'busy') return 'Звонок завершён';
        }
        return '';
    }
    // тихо закрываем входящий: без «Пропущенного» в переписке и в шторке
    function endElsewhere(text) {
        if (call) markSeen(call.id);
        cleanup();
        if (text) toast(text);
    }

    /* ---------- длинный опрос: сигнал приходит мгновенно ---------- */

    var polling = false, failDelay = 0, firstPoll = true;

    function pollOnce() {
        var started = Date.now();
        var ctrl = ('AbortController' in window) ? new AbortController() : null;
        var abortTimer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 35000);

        var init = firstPoll;
        fetch(API + '?action=poll&' + (init ? 'init=1' : 'wait=1') + '&since=' + lastSignalId, {
            credentials: 'same-origin', cache: 'no-store', signal: ctrl ? ctrl.signal : undefined
        }).then(function (r) {
            if (r.status === 401) { polling = false; throw new Error('logged_out'); }
            return r.json();
        }).then(function (d) {
            clearTimeout(abortTimer);
            failDelay = 0;
            if (init && d && d.success) firstPoll = false;
            var gotAny = false;
            if (d && d.success) {
                var signals = d.signals || [];
                // уже завершённый звонок (в пачке есть hangup/decline/busy) не показываем как входящий
                var finished = {};
                signals.forEach(function (s) {
                    if (s.type === 'hangup' || s.type === 'decline' || s.type === 'busy' || elsewhere(s)) finished[s.call_id] = true;
                });
                signals.forEach(function (s) {
                    if (s.id <= lastSignalId) return;
                    lastSignalId = s.id;
                    gotAny = true;
                    if (s.type === 'offer' && finished[s.call_id]) return;
                    handleSignal(s);
                });
                if (d.last_id > lastSignalId) lastSignalId = d.last_id;
            }
            // Если сервер ответил сразу и без сигналов (длинный опрос выключен) — не долбим его, ждём
            var quick = Date.now() - started < 800;
            var delay = init ? 0 : ((quick && !gotAny) ? (state === 'idle' ? 2500 : 800) : 50);
            // следующий запрос — сразу, без таймера: в свёрнутом приложении таймеры сильно замедляются
            if (delay <= 50) Promise.resolve().then(pollOnce); else setTimeout(pollOnce, delay);
        }).catch(function (err) {
            clearTimeout(abortTimer);
            if (err && err.message === 'logged_out') return;
            failDelay = failDelay ? Math.min(failDelay * 2, 8000) : 1000;
            setTimeout(pollOnce, failDelay);
        });
    }

    function startPolling() {
        if (polling) return;
        polling = true;
        pollOnce();
    }

    /* ---------- запуск ---------- */


    /* ---------- Переходы по сайту во время звонка ----------
       Звонок живёт на этой странице. Пока он идёт, разделы «Профиль … Избранное» открываются
       поверх неё во встроенном окне (страница со звонком остаётся под ним), поэтому разговор не прерывается.
       Настройки, поддержка, «О проекте», «Разработчикам», модерация и выход — звонок завершается. */
    var CALL_BLOCK_PAGES = ['settings.php', 'support.php', 'help.php', 'about.php', 'developers.php', 'reports.php', 'logout.php'];
    var shellFrame = null;

    function linkTarget(a, e) {
        if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return null;
        if (a.hasAttribute('download') || (a.target && a.target !== '_self')) return null;
        var href = a.getAttribute('href');
        if (!href || href.charAt(0) === '#' || /^(javascript|mailto|tel):/i.test(href)) return null;
        var u;
        try { u = new URL(a.href, location.href); } catch (err) { return null; }
        if (u.origin !== location.origin) return null;
        if (u.pathname === location.pathname && u.search === location.search && u.hash) return null;   // якорь на той же странице
        var page = (u.pathname.split('/').pop() || 'index.php').toLowerCase();
        return { url: u.href, blocked: CALL_BLOCK_PAGES.indexOf(page) !== -1 };
    }

    function openShell(url) {
        if (!shellFrame) {
            shellFrame = document.createElement('iframe');
            shellFrame.className = 'vs-call-shell';
            shellFrame.title = 'V SPACE';
            shellFrame.setAttribute('allow', 'microphone; camera; display-capture; autoplay; fullscreen');
            document.body.appendChild(shellFrame);
            document.documentElement.classList.add('has-call-shell');
            window.__vsCallShell = true;
            shellFrame.addEventListener('load', function () {
                try {
                    var w = shellFrame.contentWindow;
                    document.title = w.document.title || document.title;
                    history.replaceState(null, '', w.location.href);   // в адресной строке — страница, которую видно
                } catch (err) {}
            });
        }
        shellFrame.src = url;
        if (call && currentMode === 'active' && !mini) setMini(true);   // окно звонка сворачиваем, чтобы видеть страницу
    }

    document.addEventListener('click', function (e) {
        if (state === 'idle' || !call) return;
        var t = linkTarget(e.target.closest && e.target.closest('a[href]'), e);
        if (t && t.blocked) leaveIntent = true;   // запрещённые разделы — звонок завершается (возвращаться в него не нужно)
        if (!t || t.blocked) return;          // запрещённые разделы — обычный переход, звонок завершится сам
        e.preventDefault();
        e.stopPropagation();
        openShell(t.url);
    }, true);

    // страница внутри встроенного окна (сайт открыт поверх звонка) — звонками управляет главное окно
    function shellParent() {
        try {
            if (window.top !== window.self && window.top.__vsCallShell && window.top.VSCalls) return window.top;
        } catch (err) {}
        return null;
    }

    function init() {
        var shellTop = shellParent();
        if (shellTop) {
            window.VSCalls = shellTop.VSCalls;
            var b0 = $('chatCallActions');
            if (b0) b0.addEventListener('click', function (e) {
                var btn = e.target.closest('[data-call-media]');
                if (!btn) return;
                shellTop.VSCalls.start(parseInt(b0.dataset.peerId, 10), b0.dataset.peerName || 'Пользователь',
                    b0.dataset.peerAvatar ? new URL(b0.dataset.peerAvatar, location.href).href : '',
                    btn.dataset.callMedia === 'video' ? 'video' : 'audio');
            });
            return;   // без своего опроса: иначе два окна делили бы сигналы одного звонка
        }
        var box = $('chatCallActions');
        if (box) {
            box.addEventListener('click', function (e) {
                var btn = e.target.closest('[data-call-media]');
                if (!btn) return;
                startCall(
                    parseInt(box.dataset.peerId, 10),
                    box.dataset.peerName || 'Пользователь',
                    box.dataset.peerAvatar || '',
                    btn.dataset.callMedia === 'video' ? 'video' : 'audio'
                );
            });
        }

        // закрыли вкладку — сообщаем собеседнику
        window.addEventListener('pagehide', function () {
            if (state === 'idle' || !call) return;
            if (!leaveIntent && !window.__vsCallLeave && (state === 'connected' || (call.resumed && state === 'connecting'))) {
                saveResume();     // обновление страницы / перезапуск приложения: вернёмся в звонок сами
                return;
            }
            clearResume();
            logCall(state === 'ringing' ? 'declined' : undefined);
            postSignal(call.peerId, call.id, call.media, state === 'ringing' ? 'decline' : 'hangup');
        });

        // свернули вкладку во время звонка — экран снова не должен гаснуть
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden && state === 'connected' && !wake) lockScreen();
            if (document.hidden) appHidden(); else appVisible();
        });

        loadConfig();     // заранее: первый звонок не ждёт загрузки настроек
        // недавно прерванный звонок (обновили страницу, перезапустили приложение) — возвращаемся в него
        var resume = loadResume();
        if (resume && state === 'idle') resumeCall(resume);

        startPolling();

        // messages.php?dialog=ID&call=audio|video — выбрали человека в окне «Кому позвонить?»: сразу звоним
        try {
            var q = new URLSearchParams(location.search), want = q.get('call');
            if ((want === 'audio' || want === 'video') && box && !resume) {
                q.delete('call');
                history.replaceState(null, '', location.pathname + (q.toString() ? '?' + q.toString() : '') + location.hash);
                setTimeout(function () {
                    startCall(parseInt(box.dataset.peerId, 10), box.dataset.peerName || 'Пользователь', box.dataset.peerAvatar || '', want);
                }, 300);
            }
        } catch (err) {}
    }

    window.VSCalls = {
        start: startCall, hangup: function () { hangup(true, ''); }, toggleMic: function () { toggleMic(); },
        accept: function () { acceptIncoming(); }, decline: function () { declineIncoming(); },
        appAction: appAction, appVisible: appVisible, appHidden: appHidden
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();

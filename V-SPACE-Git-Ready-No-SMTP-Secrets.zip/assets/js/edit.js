document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    /* ---------- Выпадающее меню аватарки ---------- */
    const avatarBtn = document.getElementById('avatarBtn');
    const dropdown = document.getElementById('avatarDropdown');

    if (avatarBtn && dropdown) {
        const overlay = document.createElement('div');
        overlay.className = 'dropdown-overlay';
        document.body.appendChild(overlay);

        function closeDropdown() {
            dropdown.classList.remove('active');
            overlay.classList.remove('active');
        }

        avatarBtn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            dropdown.classList.toggle('active');
            overlay.classList.toggle('active');
        });

        overlay.addEventListener('click', function (e) {
            e.preventDefault();
            closeDropdown();
        });

        document.addEventListener('click', function (e) {
            if (!dropdown.contains(e.target) && !avatarBtn.contains(e.target)) {
                closeDropdown();
            }
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeDropdown();
        });
    }

    /* ---------- Всплывающие уведомления: автоскрытие, крестик, пауза при наведении ---------- */
    const TOAST_ICONS = {
        success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
        error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6.5v7"/><path d="M12 17.5h.01"/></svg>'
    };
    const TOAST_CLOSE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';

    function initToast(toast) {
        const isError = toast.getAttribute('data-toast') === 'error';
        const delay = isError ? 7000 : 4500;
        let timer = null;
        let remaining = delay;     // сколько мс осталось до скрытия
        let startedAt = 0;

        // Полоска-таймер внизу уведомления: сходит на нет за то же время, что и автоскрытие
        const bar = document.createElement('span');
        bar.className = 'toast-progress';
        bar.setAttribute('aria-hidden', 'true');
        bar.style.animationDuration = delay + 'ms';
        toast.appendChild(bar);

        function dismiss() {
            clearTimeout(timer);
            if (toast.classList.contains('fade-out')) return;
            toast.classList.add('fade-out');
            setTimeout(function () {
                const stack = toast.parentNode;
                toast.remove();
                if (stack && stack.classList.contains('toast-stack') && !stack.children.length) stack.remove();
            }, 300);
        }
        function start() {
            clearTimeout(timer);
            startedAt = Date.now();
            bar.style.animationPlayState = 'running';
            timer = setTimeout(dismiss, remaining);
        }
        function stop() {
            if (startedAt) remaining = Math.max(0, remaining - (Date.now() - startedAt));
            startedAt = 0;
            clearTimeout(timer);
            bar.style.animationPlayState = 'paused';
        }

        const close = toast.querySelector('.toast-close');
        if (close) close.addEventListener('click', dismiss);
        toast.addEventListener('mouseenter', stop);
        toast.addEventListener('mouseleave', start);
        toast.addEventListener('focusin', stop);
        toast.addEventListener('focusout', start);
        start();
    }

    function showToast(type, text) {
        let stack = document.querySelector('.toast-stack');
        if (!stack) {
            stack = document.createElement('div');
            stack.className = 'toast-stack';
            stack.setAttribute('role', 'status');
            stack.setAttribute('aria-live', 'polite');
            document.body.appendChild(stack);
        }
        const toast = document.createElement('div');
        toast.className = 'notification ' + type;
        toast.setAttribute('data-toast', type);

        const icon = document.createElement('span');
        icon.className = 'toast-icon';
        icon.setAttribute('aria-hidden', 'true');
        icon.innerHTML = TOAST_ICONS[type] || TOAST_ICONS.success;

        const msg = document.createElement('span');
        msg.className = 'toast-text';
        msg.textContent = text;

        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'toast-close';
        close.setAttribute('aria-label', 'Закрыть');
        close.innerHTML = TOAST_CLOSE;

        toast.appendChild(icon);
        toast.appendChild(msg);
        toast.appendChild(close);
        stack.appendChild(toast);
        initToast(toast);
    }

    document.querySelectorAll('.toast-stack .notification').forEach(initToast);

    /* ---------- Выход ---------- */
    document.querySelectorAll('.logout-item').forEach(function (item) {
        item.addEventListener('click', function (e) {
            if (!confirm('Вы уверены, что хотите выйти?')) e.preventDefault();
        });
    });

    /* ---------- Сохранение профиля ---------- */
    const editForm = document.getElementById('editForm');
    if (editForm) {
        editForm.addEventListener('submit', function () {
            const submitBtn = document.getElementById('saveBtn');
            if (!submitBtn) return;
            // Откладываем disable, иначе в некоторых браузерах не уйдёт значение формы.
            setTimeout(function () { submitBtn.disabled = true; }, 0);
            const btnText = document.getElementById('saveBtnText');
            const saveIcon = document.getElementById('saveIcon');
            if (btnText) btnText.textContent = 'Сохранение...';
            if (saveIcon) saveIcon.style.animation = 'spin 1s linear infinite';
        });
    }

    /* ---------- Плавающая панель «Есть несохранённые изменения» ---------- */
    const saveBar = document.getElementById('saveBar');
    const saveBarReset = document.getElementById('saveBarReset');
    const saveBarSave = document.getElementById('saveBarSave');
    const editCard = document.querySelector('.edit-card');

    if (editForm && saveBar && saveBarReset && saveBarSave && editCard) {
        // Обычная кнопка «Сохранить» внизу формы видна всегда.
        // Плавающая панель появляется только если есть изменения, а нижних кнопок на экране не видно.
        let actionsInView = false;
        let forced = saveBar.getAttribute('data-force') === '1';   // после ошибки проверки панель видна сразу

        const snapshot = function () {
            const out = [];
            new FormData(editForm).forEach(function (v, k) {
                if (k !== 'csrf_token' && k !== 'update_profile') out.push(k + '=' + v);
            });
            return out.join('&');
        };
        const initial = snapshot();
        const checkDirty = function () {
            const dirty = forced || snapshot() !== initial;
            saveBar.classList.toggle('is-visible', dirty && !actionsInView);
        };

        // Следим, видны ли нижние кнопки (нижние 90px окна не считаем — там нижняя навигация)
        const actionsRow = editForm.querySelector('.form-actions');
        if (actionsRow && 'IntersectionObserver' in window) {
            new IntersectionObserver(function (entries) {
                actionsInView = entries[0].isIntersecting;
                checkDirty();
            }, { rootMargin: '0px 0px -90px 0px' }).observe(actionsRow);
        }

        editForm.addEventListener('input', checkDirty);
        editForm.addEventListener('change', checkDirty);

        saveBarReset.addEventListener('click', function () {
            editForm.reset();
            // пусть счётчик «О себе» и ссылка на профиль пересчитаются
            editForm.querySelectorAll('input, textarea').forEach(function (el) {
                el.dispatchEvent(new Event('input', { bubbles: true }));
            });
            forced = false;
            checkDirty();
        });

        editForm.addEventListener('submit', function () {
            setTimeout(function () {
                saveBarSave.disabled = true;
                saveBarSave.textContent = 'Сохранение...';
            }, 0);
        });

        // Ctrl/Cmd + S — сохранить, пока панель видна
        document.addEventListener('keydown', function (e) {
            if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && String(e.key).toLowerCase() === 's') {
                e.preventDefault();
                if (saveBar.classList.contains('is-visible') && !saveBarSave.disabled) {
                    if (typeof editForm.requestSubmit === 'function') editForm.requestSubmit(saveBarSave);
                    else saveBarSave.click();
                }
            }
        });
    }

    /* ---------- Аватар: клик по кружку -> выбор фото -> окно настройки (двигать/масштаб) -> сохранение без перезагрузки ---------- */
    const MAX_SIZE = 5 * 1024 * 1024;
    const ALLOWED = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    const avatarUpload = document.getElementById('avatarUpload');
    const avatarForm = document.getElementById('avatarForm');
    const avatarPreview = document.getElementById('avatarPreview');
    const avatarRemoveForm = document.getElementById('avatarRemoveForm');

    if (avatarUpload && avatarForm && avatarPreview) {
        const previewText = function () { return avatarPreview.querySelector('.avatar-text'); };
        const previewImg = function () {
            let img = avatarPreview.querySelector('img');
            if (!img) {
                img = document.createElement('img');
                img.alt = '';
                avatarPreview.insertBefore(img, avatarPreview.firstChild);
            }
            return img;
        };
        const currentSrc = function () {
            const img = avatarPreview.querySelector('img');
            return img && img.style.display !== 'none' ? (img.getAttribute('src') || '') : '';
        };
        const showImage = function (src) {
            const img = previewImg();
            img.src = src;
            img.style.display = 'block';
            const text = previewText();
            if (text) text.style.display = 'none';
        };
        const showLetter = function () {
            const img = avatarPreview.querySelector('img');
            if (img) { img.style.display = 'none'; img.removeAttribute('src'); }
            const text = previewText();
            if (text) text.style.display = '';
        };
        const pathOf = function (src) { return String(src || '').split('?')[0]; };

        const pickFile = function () { if (!avatarPreview.classList.contains('uploading')) avatarUpload.click(); };
        avatarPreview.addEventListener('click', pickFile);
        avatarPreview.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                pickFile();
            }
        });

        // Отправка готового (уже обрезанного) файла на сервер
        const sendAvatar = function (file) {
            const prevSrc = currentSrc();
            const localUrl = URL.createObjectURL(file);
            let keepLocal = false;
            showImage(localUrl);                         // мгновенный предпросмотр в кружке
            avatarPreview.classList.add('uploading');

            const fail = function (message) {
                if (prevSrc) showImage(prevSrc); else showLetter();   // возвращаем как было
                showToast('error', message);
            };

            const fd = new FormData(avatarForm);
            fd.set('avatar', file, file.name);

            fetch(avatarForm.getAttribute('action') || 'avatars.php', {
                method: 'POST',
                body: fd,
                headers: { 'Accept': 'application/json' },
                credentials: 'same-origin'
            })
                .then(function (res) {
                    return res.json().then(function (data) { return { ok: res.ok && data && data.ok, data: data || {} }; },
                                           function () { return { ok: false, data: {} }; });
                })
                .then(function (r) {
                    if (!r.ok) {
                        fail(r.data.message || 'Не удалось сохранить фотографию. Обновите страницу и попробуйте снова.');
                        return;
                    }
                    // Сохранено: в кружок ставим уже обработанную серверную версию
                    keepLocal = !r.data.avatar;
                    const newSrc = r.data.avatar ? (r.data.avatar + '?v=' + Date.now()) : localUrl;
                    showImage(newSrc);
                    // ту же аватарку в шапке/меню (если она там картинкой) обновляем тоже
                    const oldPath = pathOf(prevSrc);
                    if (oldPath) {
                        document.querySelectorAll('img').forEach(function (img) {
                            if (img.closest('#avatarPreview')) return;
                            if (pathOf(img.getAttribute('src')) === oldPath) img.src = newSrc;
                        });
                    }
                    if (avatarRemoveForm) avatarRemoveForm.hidden = false;
                    showToast('success', r.data.message || 'Аватар обновлён!');
                })
                .catch(function () { fail('Нет соединения. Фотография не сохранена.'); })
                .then(function () {
                    avatarPreview.classList.remove('uploading');
                    avatarUpload.value = '';
                    if (!keepLocal) URL.revokeObjectURL(localUrl);
                });
        };

        /* ----- Окно настройки: фото двигается и масштабируется внутри круга ----- */
        const cropper = (function () {
            const modal = document.getElementById('cropModal');
            if (!modal) return null;
            const stage = document.getElementById('cropStage');
            const img = document.getElementById('cropImg');
            const mask = modal.querySelector('.crop-mask');
            const zoom = document.getElementById('cropZoom');
            const zoomIn = document.getElementById('cropZoomIn');
            const zoomOut = document.getElementById('cropZoomOut');
            const saveBtn = document.getElementById('cropSave');
            if (!stage || !img || !mask || !zoom || !saveBtn) return null;

            const MAX_ZOOM = 5;        // самый крупный масштаб — в 5 раз больше, чем «вписать в круг»
            const OUT_MAX = 1024;      // максимальная сторона итоговой картинки, px

            let srcFile = null, srcUrl = '', onDone = null, lastFocus = null, isOpen = false;
            let nw = 0, nh = 0;        // размер исходного фото
            let t = 0;                 // масштаб 0..1 (0 — фото целиком закрывает круг)
            let cx = 0, cy = 0;        // точка фото (в px оригинала), которая стоит в центре круга
            let SW = 0, SH = 0, D = 0, minS = 1;   // ширина и высота области, диаметр круга, минимальный масштаб
            const pointers = new Map();
            let pinch = null;

            const clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
            const measure = function () {
                SW = stage.clientWidth;
                SH = stage.clientHeight;
                D = mask.offsetWidth;
                minS = Math.min(SW / nw, SH / nh);   // минимальный масштаб: фото помещается в область целиком
            };
            const scale = function () { return minS * Math.pow(MAX_ZOOM, t); };

            const render = function () {
                const s = scale();
                const halfX = SW / 2 / s, halfY = SH / 2 / s;   // фото не должно «отрываться» от краёв области
                // если фото по этой оси меньше области — держим по центру, иначе не даём оторваться от краёв
                cx = (nw * s <= SW) ? nw / 2 : clamp(cx, halfX, nw - halfX);
                cy = (nh * s <= SH) ? nh / 2 : clamp(cy, halfY, nh - halfY);
                img.style.width = (nw * s) + 'px';
                img.style.height = (nh * s) + 'px';
                img.style.transform = 'translate3d(' + (SW / 2 - cx * s) + 'px,' + (SH / 2 - cy * s) + 'px,0)';
                zoom.value = Math.round(t * 1000);
                zoom.style.setProperty('--crop-p', (t * 100) + '%');
            };
            const setT = function (v) { t = clamp(v, 0, 1); render(); };

            const close = function () {
                if (!isOpen) return;
                isOpen = false;
                modal.hidden = true;
                document.documentElement.classList.remove('crop-open');
                pointers.clear();
                pinch = null;
                stage.classList.remove('is-dragging');
                img.onload = img.onerror = null;
                img.removeAttribute('src');
                if (srcUrl) { URL.revokeObjectURL(srcUrl); srcUrl = ''; }
                srcFile = null;
                if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
            };
            const cancel = function () { close(); avatarUpload.value = ''; };

            const open = function (file, done) {
                srcFile = file;
                onDone = done;
                lastFocus = document.activeElement;
                let triedData = false;

                img.onload = function () {
                    nw = img.naturalWidth;
                    nh = img.naturalHeight;
                    if (!nw || !nh) { img.onerror(); return; }
                    isOpen = true;
                    modal.hidden = false;
                    document.documentElement.classList.add('crop-open');
                    measure();
                    t = 0; cx = nw / 2; cy = nh / 2;
                    saveBtn.disabled = false;
                    render();
                    saveBtn.focus();
                };
                const giveUp = function () {
                    img.onload = img.onerror = null;
                    if (srcUrl) { URL.revokeObjectURL(srcUrl); srcUrl = ''; }
                    srcFile = null;
                    avatarUpload.value = '';
                    showToast('error', 'Не удалось открыть изображение. Выберите другой файл.');
                };
                img.onerror = function () {
                    // blob:-ссылка не открылась (например, её блокирует CSP) — пробуем data:-ссылку через FileReader
                    if (!triedData) {
                        triedData = true;
                        const fr = new FileReader();
                        fr.onload = function () { img.src = String(fr.result); };
                        fr.onerror = giveUp;
                        fr.readAsDataURL(file);
                        return;
                    }
                    giveUp();
                };

                try {
                    srcUrl = URL.createObjectURL(file);
                    img.src = srcUrl;
                } catch (err) {
                    img.onerror();
                }
            };

            // готовим итоговую квадратную картинку (то, что внутри круга)
            const encode = function (side, sx, sy, out, jpeg) {
                return new Promise(function (resolve, reject) {
                    const run = function (asJpeg, quality) {
                        const canvas = document.createElement('canvas');
                        canvas.width = canvas.height = out;
                        const ctx = canvas.getContext('2d');
                        if (!ctx) { reject(); return; }
                        if (asJpeg) { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, out, out); }
                        ctx.imageSmoothingEnabled = true;
                        ctx.imageSmoothingQuality = 'high';
                        // рисуем только ту часть круга, где есть фото (если фото целиком меньше круга — остальное остаётся фоном)
                        const k = out / side;
                        const x0 = Math.max(0, sx), y0 = Math.max(0, sy);
                        const x1 = Math.min(nw, sx + side), y1 = Math.min(nh, sy + side);
                        if (x1 <= x0 || y1 <= y0) { reject(); return; }
                        ctx.drawImage(img, x0, y0, x1 - x0, y1 - y0, (x0 - sx) * k, (y0 - sy) * k, (x1 - x0) * k, (y1 - y0) * k);
                        canvas.toBlob(function (blob) {
                            if (!blob) { reject(); return; }
                            if (blob.size > MAX_SIZE) {
                                if (!asJpeg) { run(true, 0.9); return; }   // PNG вышел тяжёлым — пробуем JPEG
                                reject();
                                return;
                            }
                            resolve(new File([blob], asJpeg ? 'avatar.jpg' : 'avatar.png',
                                { type: asJpeg ? 'image/jpeg' : 'image/png' }));
                        }, asJpeg ? 'image/jpeg' : 'image/png', quality);
                    };
                    run(jpeg, 0.92);
                });
            };

            saveBtn.addEventListener('click', function () {
                if (!isOpen || !srcFile) return;
                saveBtn.disabled = true;
                const s = scale();
                const side = D / s;                                    // сторона обрезки в px оригинала
                const sx = cx - side / 2;                              // может выходить за фото, если оно целиком меньше круга
                const sy = cy - side / 2;
                const out = Math.max(1, Math.min(OUT_MAX, Math.round(side)));
                encode(side, sx, sy, out, srcFile.type === 'image/jpeg')
                    .then(function (file) {
                        const cb = onDone;
                        close();
                        if (cb) cb(file);
                    })
                    .catch(function () {
                        saveBtn.disabled = false;
                        showToast('error', 'Не удалось обработать фото. Попробуйте другое изображение.');
                    });
            });

            // перетаскивание и «щипок» двумя пальцами
            stage.addEventListener('pointerdown', function (e) {
                if (e.pointerType === 'mouse' && e.button !== 0) return;
                try { stage.setPointerCapture(e.pointerId); } catch (err) {}
                pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
                stage.classList.add('is-dragging');
                if (pointers.size === 2) {
                    const p = Array.from(pointers.values());
                    pinch = { dist: Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y), scale: scale() };
                } else {
                    pinch = null;
                }
            });
            stage.addEventListener('pointermove', function (e) {
                const p = pointers.get(e.pointerId);
                if (!p) return;
                const dx = e.clientX - p.x, dy = e.clientY - p.y;
                p.x = e.clientX; p.y = e.clientY;
                if (pointers.size === 1) {
                    const s = scale();
                    cx -= dx / s;
                    cy -= dy / s;
                    render();
                } else if (pointers.size === 2 && pinch && pinch.dist > 0) {
                    const q = Array.from(pointers.values());
                    const dist = Math.hypot(q[0].x - q[1].x, q[0].y - q[1].y);
                    const ns = pinch.scale * dist / pinch.dist;
                    setT(Math.log(ns / minS) / Math.log(MAX_ZOOM));
                }
            });
            const endPointer = function (e) {
                pointers.delete(e.pointerId);
                pinch = null;
                if (!pointers.size) stage.classList.remove('is-dragging');
            };
            stage.addEventListener('pointerup', endPointer);
            stage.addEventListener('pointercancel', endPointer);

            // колесо мыши — масштаб
            stage.addEventListener('wheel', function (e) {
                e.preventDefault();
                const dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
                setT(t - dy * 0.0012);
            }, { passive: false });

            // клавиатура: стрелки — сдвиг, +/− — масштаб
            stage.addEventListener('keydown', function (e) {
                const step = 12 / scale();
                if (e.key === 'ArrowLeft')       { cx -= step; render(); }
                else if (e.key === 'ArrowRight') { cx += step; render(); }
                else if (e.key === 'ArrowUp')    { cy -= step; render(); }
                else if (e.key === 'ArrowDown')  { cy += step; render(); }
                else if (e.key === '+' || e.key === '=') { setT(t + 0.05); }
                else if (e.key === '-' || e.key === '_') { setT(t - 0.05); }
                else return;
                e.preventDefault();
            });

            zoom.addEventListener('input', function () { setT(parseInt(zoom.value, 10) / 1000); });
            if (zoomIn)  zoomIn.addEventListener('click', function () { setT(t + 0.1); });
            if (zoomOut) zoomOut.addEventListener('click', function () { setT(t - 0.1); });

            modal.querySelectorAll('[data-crop-close]').forEach(function (el) { el.addEventListener('click', cancel); });
            document.addEventListener('keydown', function (e) { if (isOpen && e.key === 'Escape') cancel(); });
            window.addEventListener('resize', function () { if (isOpen) { measure(); render(); } });

            // Tab не уходит за пределы окна
            modal.addEventListener('keydown', function (e) {
                if (e.key !== 'Tab') return;
                const f = Array.prototype.filter.call(modal.querySelectorAll('button, input, [tabindex="0"]'),
                    function (el) { return !el.disabled && el.offsetParent !== null; });
                if (!f.length) return;
                const first = f[0], last = f[f.length - 1];
                if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
            });

            return { open: open };
        })();

        avatarUpload.addEventListener('change', function () {
            const file = this.files && this.files[0];
            if (!file) return;

            if (ALLOWED.indexOf(file.type) === -1) {
                showToast('error', 'Разрешены только JPG, PNG, GIF и WEBP.');
                this.value = '';
                return;
            }
            if (file.size > MAX_SIZE) {
                showToast('error', 'Фотография слишком большая. Максимальный размер — 5 МБ.');
                this.value = '';
                return;
            }

            // GIF отправляем как есть (через canvas анимация бы пропала); остальные — через окно настройки
            if (file.type === 'image/gif' || !cropper) sendAvatar(file);
            else cropper.open(file, sendAvatar);
        });
    }

    /* ---------- Аватар: удаление ---------- */
    if (avatarRemoveForm) {
        avatarRemoveForm.addEventListener('submit', function (e) {
            if (!confirm('Вы уверены, что хотите удалить аватар?')) e.preventDefault();
        });
    }

    /* ---------- ID (ник): только допустимые символы + живая ссылка ---------- */
    const handleInput = document.getElementById('handleInput');
    const handleInfo = document.getElementById('handleLinkText');
    const handleOut = document.getElementById('handleLinkValue');

    function fullProfileLink() {
        const v = (handleInput ? handleInput.value : '').trim().toLowerCase();
        if (!handleInfo) return v;
        return (handleInfo.getAttribute('data-prefix') || '') + (v || handleInfo.getAttribute('data-default') || '');
    }

    if (handleInput && !handleInput.readOnly) {
        handleInput.addEventListener('input', function () {
            const pos = this.selectionStart;
            const clean = this.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
            if (clean !== this.value) {
                this.value = clean;
                this.setSelectionRange(Math.max(0, pos - 1), Math.max(0, pos - 1));
            }
        });
    }
    if (handleInput && handleOut) {
        handleInput.addEventListener('input', function () { handleOut.textContent = fullProfileLink(); });
    }

    /* ---------- Копирование ссылки на профиль ---------- */
    const copyBtn = document.getElementById('copyHandleBtn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            const text = fullProfileLink();
            const oldLabel = copyBtn.getAttribute('data-label') || copyBtn.textContent;
            copyBtn.setAttribute('data-label', oldLabel);

            const done = function () {
                copyBtn.textContent = 'Скопировано';
                copyBtn.classList.add('copied');
                setTimeout(function () {
                    copyBtn.textContent = oldLabel;
                    copyBtn.classList.remove('copied');
                }, 1500);
            };

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(done, function () {});
            } else {
                const t = document.createElement('textarea');
                t.value = text;
                t.style.position = 'fixed';
                t.style.opacity = '0';
                document.body.appendChild(t);
                t.select();
                try { document.execCommand('copy'); done(); } catch (err) {}
                t.remove();
            }
        });
    }

    /* ---------- Счётчик символов в поле «О себе» ---------- */
    const bio = document.getElementById('bio');
    if (bio && !bio.readOnly) {
        const help = bio.parentNode.querySelector('.help-text');
        if (help) {
            const max = parseInt(bio.getAttribute('maxlength'), 10) || 500;
            const counter = document.createElement('span');
            counter.className = 'bio-count';
            help.classList.add('has-count');
            help.appendChild(counter);
            const update = function () {
                const n = bio.value.length;
                counter.textContent = n + ' / ' + max;
                counter.classList.toggle('is-near', n >= max - 30);
            };
            bio.addEventListener('input', update);
            update();
        }
    }
});

// Ручка нижней панели навигации — как в index.php / settings.php:
// панель скрыта, показывается по наведению на ручку или клику.
document.addEventListener('DOMContentLoaded', function () {
    var handle = document.getElementById('handleBtn');
    var nav = document.getElementById('site-navigator');
    if (!handle || !nav) return;
    if (nav.hasAttribute('data-managed-by-partial')) return;

    function showNav() {
        nav.classList.remove('nav-hidden');
        handle.classList.add('handle-hidden');
    }
    function hideNav() {
        nav.classList.add('nav-hidden');
        handle.classList.remove('handle-hidden');
    }

    hideNav();

    handle.addEventListener('click', function (e) {
        e.stopPropagation();
        if (nav.classList.contains('nav-hidden')) showNav(); else hideNav();
    });
    handle.addEventListener('mouseenter', showNav);
    nav.addEventListener('mouseenter', showNav);
    nav.addEventListener('mouseleave', function () {
        if (!handle.matches(':hover')) hideNav();
    });
});

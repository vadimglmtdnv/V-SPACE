/* Резервная реализация AES-GCM на чистом JS.
   Нужна, когда сайт открыт не по https и браузер отключил crypto.subtle.
   Формат совместим с WebCrypto: encrypt() -> шифртекст || тег(16 байт), IV 12 байт. */
(function (g) {
    'use strict';

    var SBOX = new Uint8Array(256);
    (function () {
        var p = 1, q = 1, x;
        function rotl(v, n) { return ((v << n) | (v >> (8 - n))) & 0xff; }
        do {
            p = (p ^ ((p << 1) & 0xff) ^ ((p & 0x80) ? 0x1b : 0)) & 0xff;
            q = (q ^ (q << 1)) & 0xff;
            q = (q ^ (q << 2)) & 0xff;
            q = (q ^ (q << 4)) & 0xff;
            if (q & 0x80) q ^= 0x09;
            x = q ^ rotl(q, 1) ^ rotl(q, 2) ^ rotl(q, 3) ^ rotl(q, 4);
            SBOX[p] = (x ^ 0x63) & 0xff;
        } while (p !== 1);
        SBOX[0] = 0x63;
    })();

    function xtime(a) { return ((a << 1) ^ ((a & 0x80) ? 0x1b : 0)) & 0xff; }

    function expandKey(key) {
        var nk = key.length / 4;
        if (nk !== 4 && nk !== 6 && nk !== 8) throw new Error('bad key length');
        var nr = nk + 6, total = 16 * (nr + 1);
        var w = new Uint8Array(total);
        w.set(key);
        var rcon = 1, t = new Uint8Array(4), i, j;
        for (i = key.length; i < total; i += 4) {
            for (j = 0; j < 4; j++) t[j] = w[i - 4 + j];
            if ((i / 4) % nk === 0) {
                var tmp = t[0];
                t[0] = SBOX[t[1]] ^ rcon; t[1] = SBOX[t[2]]; t[2] = SBOX[t[3]]; t[3] = SBOX[tmp];
                rcon = xtime(rcon);
            } else if (nk > 6 && (i / 4) % nk === 4) {
                for (j = 0; j < 4; j++) t[j] = SBOX[t[j]];
            }
            for (j = 0; j < 4; j++) w[i + j] = w[i - key.length + j] ^ t[j];
        }
        return { w: w, nr: nr };
    }

    function encryptBlock(k, inp) {
        var s = new Uint8Array(16), w = k.w, nr = k.nr, r, i, t;
        for (i = 0; i < 16; i++) s[i] = inp[i] ^ w[i];
        for (r = 1; r <= nr; r++) {
            for (i = 0; i < 16; i++) s[i] = SBOX[s[i]];
            // ShiftRows
            t = s[1]; s[1] = s[5]; s[5] = s[9]; s[9] = s[13]; s[13] = t;
            t = s[2]; s[2] = s[10]; s[10] = t; t = s[6]; s[6] = s[14]; s[14] = t;
            t = s[15]; s[15] = s[11]; s[11] = s[7]; s[7] = s[3]; s[3] = t;
            if (r < nr) {
                for (i = 0; i < 16; i += 4) {
                    var a0 = s[i], a1 = s[i + 1], a2 = s[i + 2], a3 = s[i + 3];
                    var all = a0 ^ a1 ^ a2 ^ a3;
                    s[i]     = a0 ^ all ^ xtime(a0 ^ a1);
                    s[i + 1] = a1 ^ all ^ xtime(a1 ^ a2);
                    s[i + 2] = a2 ^ all ^ xtime(a2 ^ a3);
                    s[i + 3] = a3 ^ all ^ xtime(a3 ^ a0);
                }
            }
            for (i = 0; i < 16; i++) s[i] ^= w[16 * r + i];
        }
        return s;
    }

    // умножение в GF(2^128) по спецификации GCM
    function gmul(x, h) {
        var z = new Uint8Array(16), v = new Uint8Array(h), i, j, lsb;
        for (i = 0; i < 16; i++) {
            for (j = 7; j >= 0; j--) {
                if ((x[i] >> j) & 1) { for (var m = 0; m < 16; m++) z[m] ^= v[m]; }
                lsb = v[15] & 1;
                for (var n = 15; n > 0; n--) v[n] = ((v[n] >> 1) | (v[n - 1] << 7)) & 0xff;
                v[0] >>= 1;
                if (lsb) v[0] ^= 0xe1;
            }
        }
        return z;
    }

    function ghash(h, data, y) {
        var blk = new Uint8Array(16), i, j;
        for (i = 0; i < data.length; i += 16) {
            blk.fill(0);
            blk.set(data.subarray(i, Math.min(i + 16, data.length)));
            for (j = 0; j < 16; j++) y[j] ^= blk[j];
            y = gmul(y, h);
        }
        return y;
    }

    function inc32(c) {
        for (var i = 15; i >= 12; i--) { c[i] = (c[i] + 1) & 0xff; if (c[i] !== 0) break; }
    }

    function ctr(k, j0, data) {
        var out = new Uint8Array(data.length), c = new Uint8Array(j0), i, j, ks;
        for (i = 0; i < data.length; i += 16) {
            inc32(c);
            ks = encryptBlock(k, c);
            var n = Math.min(16, data.length - i);
            for (j = 0; j < n; j++) out[i + j] = data[i + j] ^ ks[j];
        }
        return out;
    }

    function makeTag(k, h, j0, ct) {
        var y = ghash(h, ct, new Uint8Array(16));
        var len = new Uint8Array(16), bits = ct.length * 8;
        len[12] = (bits >>> 24) & 0xff; len[13] = (bits >>> 16) & 0xff; len[14] = (bits >>> 8) & 0xff; len[15] = bits & 0xff;
        y = ghash(h, len, y);
        var e = encryptBlock(k, j0), tag = new Uint8Array(16);
        for (var i = 0; i < 16; i++) tag[i] = e[i] ^ y[i];
        return tag;
    }

    function setup(key, iv) {
        if (iv.length !== 12) throw new Error('bad iv');
        var h = encryptBlock(key, new Uint8Array(16));
        var j0 = new Uint8Array(16);
        j0.set(iv); j0[15] = 1;
        return { h: h, j0: j0 };
    }

    g.VSAesGcm = {
        importKey: function (raw) { return expandKey(raw); },
        encrypt: function (key, iv, plain) {
            var p = setup(key, iv), ct = ctr(key, p.j0, plain), tag = makeTag(key, p.h, p.j0, ct);
            var out = new Uint8Array(ct.length + 16);
            out.set(ct); out.set(tag, ct.length);
            return out;
        },
        decrypt: function (key, iv, data) {
            if (data.length < 16) throw new Error('bad data');
            var p = setup(key, iv), ct = data.subarray(0, data.length - 16), tag = data.subarray(data.length - 16);
            var exp = makeTag(key, p.h, p.j0, ct), diff = 0;
            for (var i = 0; i < 16; i++) diff |= exp[i] ^ tag[i];
            if (diff !== 0) throw new Error('auth failed');
            return ctr(key, p.j0, ct);
        }
    };
})(typeof window !== 'undefined' ? window : globalThis);

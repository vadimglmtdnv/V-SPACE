/*
 * pin-spin.js — анимация «крутятся цифры» после ВЕРНОГО ввода PIN.
 *
 * Цифры в барабанах случайные и не имеют отношения к настоящему PIN: сам PIN на экран не выводится.
 * Анимация чисто визуальная и запускается только после того, как сервер уже проверил PIN.
 * Подключение:  <script src="assets/js/pin-spin.js"></script>  (CSS внутри, отдельный файл не нужен)
 *
 *   PinSpin.overlay({ length: 6, onDone: function () { ... } });   // на весь экран
 *   PinSpin.spin(element, { length: 6, onDone: function () { ... } }); // внутри своего блока
 */
(function (root) {
  'use strict';

  var CELL_H = 58;
  var CSS =
    '.pinspin{display:flex;gap:10px;justify-content:center}' +
    '.pinspin-cell{width:44px;height:' + CELL_H + 'px;border-radius:10px;background:#1e1f22;border:2px solid #5865f2;' +
    'overflow:hidden;box-shadow:0 0 0 4px rgba(88,101,242,.18);transition:border-color .25s,box-shadow .25s}' +
    '.pinspin-strip{will-change:transform;transition:filter .2s}' +
    '.pinspin-strip.fast{filter:blur(1.6px)}' +
    '.pinspin-strip span{display:block;height:' + CELL_H + 'px;text-align:center;' +
    "font:700 28px/" + CELL_H + "px Consolas,Menlo,'Courier New',monospace;color:#f2f3f5}" +
    '.pinspin-cell.done{border-color:#3ba55d;box-shadow:0 0 0 4px rgba(59,165,93,.24)}' +
    '.pinspin-cell.done span{color:#6fd58f}' +
    '.pinspin-overlay{position:fixed;inset:0;z-index:9999;display:flex;flex-direction:column;align-items:center;' +
    'justify-content:center;gap:22px;background:rgba(19,24,71,.94);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);' +
    "font-family:'Segoe UI','Helvetica Neue',Arial,sans-serif;color:#c4ccff;opacity:0;transition:opacity .3s}" +
    '.pinspin-overlay.show{opacity:1}' +
    '.pinspin-label{font-size:15px;letter-spacing:2px;text-transform:uppercase;min-height:20px;transition:color .25s}' +
    '.pinspin-label.ok{color:#6fd58f;font-weight:700}' +
    '@media(max-width:420px){.pinspin-cell{width:38px}.pinspin{gap:7px}}';

  function injectCss() {
    if (document.getElementById('pinspin-css')) return;
    var s = document.createElement('style');
    s.id = 'pinspin-css';
    s.appendChild(document.createTextNode(CSS));
    document.head.appendChild(s);
  }

  function rnd(n) { return Math.floor(Math.random() * n); }

  function spin(el, opts) {
    opts = opts || {};
    injectCss();
    var n = Math.max(1, opts.length || 6);
    var base = opts.duration || 1500;     // когда остановится первый барабан, мс
    var step = opts.stagger || 280;       // следующий останавливается позже на столько
    var reduce = root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches;

    el.classList.add('pinspin');
    el.innerHTML = '';
    var cells = [];
    for (var i = 0; i < n; i++) {
      var cell = document.createElement('div'); cell.className = 'pinspin-cell';
      var strip = document.createElement('div'); strip.className = 'pinspin-strip fast';
      var len = 22 + i * 7;                                   // чем правее барабан, тем длиннее путь
      for (var k = 0; k < len; k++) {
        var sp = document.createElement('span'); sp.textContent = rnd(10); strip.appendChild(sp);
      }
      cell.appendChild(strip); el.appendChild(cell);
      cells.push({ cell: cell, strip: strip, len: len, dur: base + i * step, done: false });
    }

    var t0 = null, finished = false;
    function finish() {
      if (finished) return; finished = true;
      if (opts.onDone) setTimeout(opts.onDone, reduce ? 0 : 450);
    }
    function frame(now) {
      if (t0 === null) t0 = now;
      var all = true;
      for (var i = 0; i < cells.length; i++) {
        var c = cells[i];
        var t = Math.min(1, (now - t0) / c.dur);
        var e = 1 - Math.pow(1 - t, 3);                       // замедление к концу
        c.strip.style.transform = 'translateY(' + (-e * (c.len - 1) * CELL_H) + 'px)';
        if (t > 0.82) c.strip.classList.remove('fast');
        if (t >= 1 && !c.done) { c.done = true; c.cell.classList.add('done'); }
        if (!c.done) all = false;
      }
      if (all) finish(); else root.requestAnimationFrame(frame);
    }

    if (reduce) {                                             // «уменьшить анимацию» в системе — без кручения
      cells.forEach(function (c) {
        c.strip.classList.remove('fast');
        c.strip.style.transform = 'translateY(' + (-(c.len - 1) * CELL_H) + 'px)';
        c.cell.classList.add('done');
      });
      finish();
    } else {
      root.requestAnimationFrame(frame);
    }
  }

  function overlay(opts) {
    opts = opts || {};
    injectCss();
    var ov = document.createElement('div'); ov.className = 'pinspin-overlay';
    var row = document.createElement('div');
    var label = document.createElement('div'); label.className = 'pinspin-label';
    label.textContent = opts.checkingText || 'Проверка PIN…';
    ov.appendChild(row); ov.appendChild(label);
    document.body.appendChild(ov);
    root.requestAnimationFrame(function () { ov.classList.add('show'); });

    spin(row, {
      length: opts.length, duration: opts.duration, stagger: opts.stagger,
      onDone: function () {
        label.textContent = opts.okText || 'Доступ разрешён';
        label.classList.add('ok');
        setTimeout(function () {
          ov.classList.remove('show');
          setTimeout(function () { if (ov.parentNode) ov.parentNode.removeChild(ov); if (opts.onDone) opts.onDone(); }, 320);
        }, opts.holdMs || 650);
      }
    });
  }

  root.PinSpin = { spin: spin, overlay: overlay };
})(window);

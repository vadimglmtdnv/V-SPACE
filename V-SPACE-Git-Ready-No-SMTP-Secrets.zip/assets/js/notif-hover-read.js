/* notif-hover-read.js — уведомление отмечается прочитанным при наведении курсора (и при нажатии).
   Работает на всех страницах с колокольчиком (подключается из includes/bottom_nav.php):
   - выпадающее окно: .notification-item.unread
   - страница notifications.php: .n-card.unread
   У прочитанного пропадают точка и подсветка «не прочитано», счётчики уменьшаются. */
(function () {
    'use strict';
    if (window.__notifHoverReadBound) return;
    window.__notifHoverReadBound = true;

    var HOVER_DELAY = 350;   // мс: чтобы не отмечать всё подряд, когда курсор просто пролетает над списком
    var ENDPOINTS = ['api/mark_notification_read.php', 'api/mark_notifications_read.php'];
    var timers = new WeakMap();

    function itemOf(target) {
        return target && target.closest ? target.closest('.notification-item.unread, .n-card.unread') : null;
    }

    function idOf(item) {
        if (item.dataset && item.dataset.notificationId) return item.dataset.notificationId;
        var link = item.querySelector('a[href*="open="]') || (item.matches('a[href*="open="]') ? item : null);
        if (!link) return '';
        var m = /[?&]open=(\d+)/.exec(link.getAttribute('href') || '');
        return m ? m[1] : '';
    }

    function setCounters(delta) {
        var badge = document.getElementById('notificationsBadge');
        var label = document.getElementById('notificationsCount');
        var markAll = document.getElementById('markAllReadBtn');
        var current = badge ? parseInt(badge.textContent, 10) : NaN;
        if (!isFinite(current)) current = document.querySelectorAll('.notification-item.unread, .n-card.unread').length + delta * -1;
        if (badge && /99\+/.test(badge.textContent)) return;   // при «99+» точное число неизвестно
        var next = Math.max(0, current + delta);
        if (badge) {
            badge.textContent = next > 99 ? '99+' : String(next);
            badge.style.display = next > 0 ? 'flex' : 'none';
        }
        if (label) {
            label.textContent = next === 0 ? (label.dataset.zeroText || '0 новых') : next + ' новых';
        }
        if (markAll && next === 0) markAll.style.display = 'none';
    }

    function send(id, index) {
        var url = ENDPOINTS[index];
        if (!url) return;
        fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            keepalive: true,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ id: id }).toString()
        }).then(function (response) {
            if (!response.ok) send(id, index + 1);   // нет такого файла — пробуем второй адрес
        }).catch(function () {});
    }

    function markRead(item) {
        if (!item || !item.classList.contains('unread')) return;
        var id = idOf(item);
        if (!id) return;
        item.classList.remove('unread');
        item.classList.add('read');
        var dot = item.querySelector('.notif-dot, .n-dot');
        if (dot) dot.remove();
        setCounters(-1);
        send(id, 0);
    }

    document.addEventListener('mouseover', function (event) {
        var item = itemOf(event.target);
        if (!item || timers.has(item)) return;
        timers.set(item, window.setTimeout(function () {
            timers.delete(item);
            markRead(item);
        }, HOVER_DELAY));
    });

    document.addEventListener('mouseout', function (event) {
        var item = itemOf(event.target);
        if (!item || !timers.has(item)) return;
        if (event.relatedTarget && item.contains(event.relatedTarget)) return;
        window.clearTimeout(timers.get(item));
        timers.delete(item);
    });

    // телефон / нажатие: отмечаем сразу
    document.addEventListener('click', function (event) {
        markRead(itemOf(event.target));
    });
})();

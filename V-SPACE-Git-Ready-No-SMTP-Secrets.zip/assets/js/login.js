(function() {
    'use strict';

    // ============================================
    // КОНСТАНТЫ
    // ============================================
    const COOKIE_NAME = 'theme';
    const THEME_DARK = 'dark';
    const THEME_LIGHT = 'light';
    const THEME_SYSTEM = 'system';
    const COOKIE_DAYS = 365;

    // ============================================
    // РАБОТА С COOKIES
    // ============================================
    function setCookie(name, value, days) {
        const d = new Date();
        d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000);
        document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/';
    }

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : null;
    }

    // ============================================
    // ОПРЕДЕЛЕНИЕ СИСТЕМНОЙ ТЕМЫ
    // ============================================
    function getSystemTheme() {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? THEME_DARK : THEME_LIGHT;
    }

    // ============================================
    // ОБНОВЛЕНИЕ МЕНЮ
    // ============================================
    function updateMenu(activeTheme) {
        const items = document.querySelectorAll('.theme-item');
        items.forEach(function(item) {
            const theme = item.getAttribute('data-theme');
            const check = item.querySelector('.theme-check');
            if (theme === activeTheme) {
                item.classList.add('active');
                if (check) check.textContent = '✓';
            } else {
                item.classList.remove('active');
                if (check) check.textContent = '';
            }
        });

        // Обновляем текст текущей темы
        const themeCurrent = document.querySelector('.theme-current');
        if (themeCurrent) {
            const themeNames = {
                'dark': 'Тёмная',
                'light': 'Светлая',
                'system': 'Системная'
            };
            themeCurrent.textContent = themeNames[activeTheme] || 'Тёмная';
        }
    }

    // ============================================
    // ПРИМЕНЕНИЕ ТЕМЫ
    // ============================================
    function applyTheme(theme) {
        const body = document.body;
        if (!body) return;

        const effective = theme === THEME_SYSTEM ? getSystemTheme() : theme;
        body.setAttribute('data-theme', effective);
        setCookie(COOKIE_NAME, theme, COOKIE_DAYS);
        updateMenu(theme);

        const metaTheme = document.querySelector('meta[name="theme-color"]');
        if (metaTheme) {
            metaTheme.content = effective === THEME_LIGHT ? '#f0f2f5' : '#313338';
        }

        // Обновляем иконку темы
        const themeIcon = document.querySelector('.theme-icon');
        if (themeIcon) {
            const icons = {
                'dark': '🌙',
                'light': '☀️',
                'system': '🖥️'
            };
            themeIcon.textContent = icons[theme] || '🌙';
        }

        console.log('✅ Тема применена:', theme);
    }

    // ============================================
    // ПОКАЗ/СКРЫТИЕ ОШИБКИ
    // ============================================
    function showError(errorMessage, title, text, hint) {
        if (!errorMessage) return;
        const errorText = errorMessage.querySelector('.error-text');
        const errorTitle = errorMessage.querySelector('.error-title');
        const errorHint = errorMessage.querySelector('.error-hint');
        if (errorText) errorText.textContent = text || 'Заполните все поля.';
        if (errorTitle) errorTitle.textContent = title || 'Ошибка входа';
        if (errorHint) errorHint.textContent = hint || 'Пожалуйста, заполните все обязательные поля.';
        errorMessage.classList.remove('hidden');
        errorMessage.style.display = 'flex';
    }

    function hideError(errorMessage) {
        if (errorMessage) {
            errorMessage.classList.add('hidden');
        }
    }

    // ============================================
    // ИНИЦИАЛИЗАЦИЯ
    // ============================================
    function init() {
        // ============================================
        // УПРАВЛЕНИЕ ТЕМОЙ
        // ============================================
        const themeBtn = document.getElementById('themeToggleBtn');
        const themeMenu = document.getElementById('themeMenu');
        const themeItems = themeMenu ? themeMenu.querySelectorAll('.theme-item') : [];

        // Загружаем сохранённую тему
        const savedTheme = getCookie(COOKIE_NAME) || THEME_DARK;
        applyTheme(savedTheme);

        // Открытие/закрытие меню
        if (themeBtn) {
            themeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                if (themeMenu) themeMenu.classList.toggle('active');
            });
        }

        // Выбор темы
        themeItems.forEach(function(item) {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const theme = this.getAttribute('data-theme');
                if (theme) {
                    applyTheme(theme);
                    if (themeMenu) themeMenu.classList.remove('active');
                }
            });
        });

        // Закрытие меню при клике вне
        document.addEventListener('click', function(e) {
            if (themeMenu && themeBtn) {
                if (!themeMenu.contains(e.target) && e.target !== themeBtn && !themeBtn.contains(e.target)) {
                    themeMenu.classList.remove('active');
                }
            }
        });

        // Закрытие по ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && themeMenu) {
                themeMenu.classList.remove('active');
            }
        });

        // Слежение за системной темой
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        mediaQuery.addEventListener('change', function() {
            if (getCookie(COOKIE_NAME) === THEME_SYSTEM) {
                applyTheme(THEME_SYSTEM);
            }
        });

        // ============================================
        // ЗАКРЫТИЕ СООБЩЕНИЯ ОБ ОШИБКЕ
        // ============================================
        const errorClose = document.getElementById('errorClose');
        const errorMessage = document.getElementById('errorMessage');

        if (errorClose && errorMessage) {
            errorClose.addEventListener('click', function() {
                errorMessage.classList.add('hidden');
                setTimeout(function() {
                    errorMessage.style.display = 'none';
                }, 300);
            });
        }

        // ============================================
        // ВАЛИДАЦИЯ ПОЛЕЙ
        // ============================================
        const loginForm = document.getElementById('loginForm');
        const loginInput = document.getElementById('login');
        const passwordInput = document.getElementById('password');
        const submitBtn = loginForm ? loginForm.querySelector('.btn-login') : null;

        if (loginForm && loginInput && passwordInput) {
            // Скрываем ошибку при вводе
            loginInput.addEventListener('input', function() {
                this.classList.remove('error');
                this.classList.remove('success');
                hideError(errorMessage);
            });

            passwordInput.addEventListener('input', function() {
                this.classList.remove('error');
                this.classList.remove('success');
                hideError(errorMessage);
            });

            // Валидация при потере фокуса
            loginInput.addEventListener('blur', function() {
                const val = this.value.trim();
                if (val.length > 0 && val.length < 2) {
                    this.classList.add('error');
                } else if (val.length > 0) {
                    this.classList.add('success');
                }
            });

            passwordInput.addEventListener('blur', function() {
                const val = this.value.trim();
                if (val.length > 0 && val.length < 4) {
                    this.classList.add('error');
                } else if (val.length > 0) {
                    this.classList.add('success');
                }
            });

            // Отправка формы
            let formSubmitted = false;
            loginForm.addEventListener('submit', function(e) {
                const loginVal = loginInput.value.trim();
                const passwordVal = passwordInput.value.trim();

                let hasError = false;

                // Проверяем поля
                if (loginVal === '' || passwordVal === '') {
                    if (loginVal === '') loginInput.classList.add('error');
                    if (passwordVal === '') passwordInput.classList.add('error');
                    hasError = true;
                    showError(errorMessage, 'Ошибка входа', 'Заполните все поля.', 'Пожалуйста, заполните все обязательные поля.');
                }

                if (loginVal.length > 0 && loginVal.length < 2) {
                    loginInput.classList.add('error');
                    hasError = true;
                    showError(errorMessage, 'Ошибка входа', 'Логин слишком короткий.', 'Логин должен содержать минимум 2 символа.');
                }

                if (passwordVal.length > 0 && passwordVal.length < 4) {
                    passwordInput.classList.add('error');
                    hasError = true;
                    showError(errorMessage, 'Ошибка входа', 'Пароль слишком короткий.', 'Пароль должен содержать минимум 4 символа.');
                }

                if (hasError) {
                    e.preventDefault();
                    return false;
                }

                if (formSubmitted) {
                    e.preventDefault();
                    return false;
                }

                formSubmitted = true;
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.textContent = '⏳ Вход...';
                }
            });

            if (loginInput.value === '') {
                loginInput.focus();
            }
        }

        console.log('🚀 Login/Theme manager initialized');
    }

    // ============================================
    // ЗАПУСК
    // ============================================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
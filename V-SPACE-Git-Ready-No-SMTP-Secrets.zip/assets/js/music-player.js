/* Плеер для треков на HTMLMediaElement API.
   Разметка: .mp > audio + .mp-ui (см. renderTrack в music.php).
   — один трек играет одновременно, по окончании включается следующий в списке;
   — перемотка/громкость с клавиатуры (стрелки), громкость запоминается;
   — Media Session API: название и исполнитель на экране блокировки и в медиа-клавишах;
   — значок вкладки: «плей», пока музыка играет, и «стоп» на паузе / когда трек закончился. */
(function () {
    'use strict';

    var VOL_KEY = 'mp_volume';
    var players = [];
    var current = null;

    // Значки вкладки. Положите play.ico и stop.ico в папку images/ (или поменяйте пути здесь).
    var FAVICON_PLAY = 'images/play.ico';
    var FAVICON_STOP = 'images/stop.ico';
    var faviconState = '';

    // Chrome надёжно обновляет значок, только если <link rel="icon"> заменить целиком, а не менять href
    function setFavicon(state) {
        if (state === faviconState) return;
        faviconState = state;
        var href = state === 'play' ? FAVICON_PLAY : FAVICON_STOP;
        var head = document.head || document.getElementsByTagName('head')[0];
        if (!head) return;
        var old = head.querySelectorAll('link[rel~="icon"]');
        for (var i = 0; i < old.length; i++) old[i].parentNode.removeChild(old[i]);
        var link = document.createElement('link');
        link.rel = 'icon';
        link.type = 'image/x-icon';
        link.href = href + '?v=1';   // ?v=1 — чтобы Chrome не держал старую картинку в кэше; при замене файлов увеличьте число
        head.appendChild(link);
    }
    // Состояние берём по факту: если играет хотя бы один трек — «плей», иначе «стоп».
    // (При переключении треков старый трек получает pause уже после play нового, так что смотреть на событие нельзя.)
    function syncFavicon() {
        var playing = false;
        for (var i = 0; i < players.length; i++) {
            if (!players[i].audio.paused && !players[i].audio.ended) { playing = true; break; }
        }
        setFavicon(playing ? 'play' : 'stop');
    }

    function fmt(t) {
        if (!isFinite(t) || t < 0) t = 0;
        var m = Math.floor(t / 60), s = Math.floor(t % 60);
        return m + ':' + (s < 10 ? '0' : '') + s;
    }
    function lsGet(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } }
    function lsSet(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* ignore */ } }

    var savedVol = parseFloat(lsGet(VOL_KEY));
    if (!isFinite(savedVol) || savedVol < 0 || savedVol > 1) savedVol = 1;

    // Запоминаем, какой трек и с какого места играл — после F5 позиция возвращается (воспроизведение включает сам пользователь)
    var RESUME_KEY = 'mp_resume';
    var lastSave = 0;
    function saveResume(p) {
        if (!p || !p.src) return;
        lsSet(RESUME_KEY, JSON.stringify({ src: p.src, t: p.audio.currentTime || 0 }));
        lastSave = Date.now();
    }

    function Player(root) {
        var self = this;
        this.root = root;
        this.audio = root.querySelector('audio');
        var track = root.closest('.track');
        // кнопка пуск/пауза — это иконка слева в строке трека
        this.play = (track && track.querySelector('.track-play')) || root.querySelector('.mp-play');
        this.seek = root.querySelector('.mp-seek');
        this.cur = root.querySelector('.mp-cur');
        this.dur = root.querySelector('.mp-dur');
        this.mute = root.querySelector('.mp-mute');
        this.vol = root.querySelector('.mp-volume');
        this.title = root.getAttribute('data-title') || '';
        this.artist = root.getAttribute('data-artist') || '';
        var srcEl = root.querySelector('audio source');
        this.src = srcEl ? (srcEl.getAttribute('src') || '') : '';
        this.dragging = false;
        if (!this.audio || !this.play || !this.seek) return;

        this.audio.removeAttribute('controls');
        this.audio.volume = savedVol;
        root.classList.add('is-enhanced');

        // состояния плеера дублируем на строку трека — по ним иконка меняет ▶ / ⏸
        if (track && window.MutationObserver) {
            var syncTrack = function () {
                ['is-playing', 'is-loading', 'is-error'].forEach(function (c) {
                    track.classList.toggle(c, root.classList.contains(c));
                });
            };
            new MutationObserver(syncTrack).observe(root, { attributes: true, attributeFilter: ['class'] });
        }
        this.setSeekMax();
        this.syncVolume();

        var a = this.audio;
        a.addEventListener('loadedmetadata', function () { self.setSeekMax(); self.renderTime(); self.renderBuffered(); });
        a.addEventListener('durationchange', function () { self.setSeekMax(); self.renderTime(); });
        a.addEventListener('timeupdate', function () {
            if (!self.dragging) self.renderTime();
            if (self === current && Date.now() - lastSave > 1000) saveResume(self);
        });
        a.addEventListener('progress', function () { self.renderBuffered(); });
        a.addEventListener('play', function () { self.onPlay(); });
        a.addEventListener('pause', function () {
            root.classList.remove('is-playing'); self.setPlayLabel(false);
            if (self === current && !a.ended) saveResume(self);
            syncFavicon();
        });
        a.addEventListener('waiting', function () { root.classList.add('is-loading'); });
        a.addEventListener('playing', function () { root.classList.remove('is-loading'); });
        a.addEventListener('canplay', function () { root.classList.remove('is-loading'); });
        a.addEventListener('ended', function () { self.onEnded(); });
        a.addEventListener('volumechange', function () { self.syncVolume(); });
        a.addEventListener('error', function () {
            root.classList.remove('is-loading', 'is-playing');
            root.classList.add('is-error');
            self.play.setAttribute('aria-label', 'Не удалось загрузить трек');
            self.play.title = 'Не удалось загрузить трек';
        });

        this.play.addEventListener('click', function () { self.toggle(); });

        // Перемотка: во время перетаскивания только двигаем ползунок, время ставим по отпусканию/каждому input
        this.seek.addEventListener('pointerdown', function () { self.dragging = true; root.classList.add('is-seeking'); });
        var endDrag = function () { self.dragging = false; root.classList.remove('is-seeking'); };
        this.seek.addEventListener('pointerup', endDrag);
        this.seek.addEventListener('pointercancel', endDrag);
        this.seek.addEventListener('blur', endDrag);
        this.seek.addEventListener('input', function () {
            var t = parseFloat(self.seek.value);
            if (isFinite(t)) {
                try { a.currentTime = t; } catch (e) { /* метаданные ещё не загружены */ }
                self.cur.textContent = fmt(t);
                self.paintSeek();
                saveResume(self);
            }
        });

        if (this.mute) this.mute.addEventListener('click', function () { a.muted = !a.muted; if (!a.muted && a.volume === 0) a.volume = 0.5; });
        if (this.vol) this.vol.addEventListener('input', function () {
            var v = parseFloat(self.vol.value);
            a.muted = false;
            a.volume = isFinite(v) ? v : 1;
            lsSet(VOL_KEY, String(a.volume));
            savedVol = a.volume;
        });
    }

    Player.prototype.setSeekMax = function () {
        var d = this.audio.duration;
        this.seek.max = isFinite(d) && d > 0 ? d : 100;
        this.seek.step = 'any';
        this.dur.textContent = isFinite(d) && d > 0 ? fmt(d) : '0:00';
        this.paintSeek();
    };
    Player.prototype.paintSeek = function () {
        var max = parseFloat(this.seek.max) || 1;
        var p = Math.min(100, Math.max(0, (parseFloat(this.seek.value) / max) * 100));
        this.seek.style.setProperty('--p', p + '%');
    };
    Player.prototype.renderTime = function () {
        var t = this.audio.currentTime || 0;
        this.seek.value = t;
        this.cur.textContent = fmt(t);
        this.paintSeek();
    };
    Player.prototype.renderBuffered = function () {
        var a = this.audio, d = a.duration, end = 0;
        if (isFinite(d) && d > 0 && a.buffered && a.buffered.length) {
            var t = a.currentTime;
            for (var i = 0; i < a.buffered.length; i++) {
                if (a.buffered.start(i) <= t + 0.5 && a.buffered.end(i) >= t) { end = a.buffered.end(i); break; }
                end = Math.max(end, a.buffered.end(i));
            }
        }
        this.seek.style.setProperty('--b', (d > 0 ? Math.min(100, end / d * 100) : 0) + '%');
    };
    Player.prototype.syncVolume = function () {
        var a = this.audio, shown = a.muted ? 0 : a.volume;
        this.root.classList.toggle('is-muted', a.muted || a.volume === 0);
        if (this.vol) {
            this.vol.value = shown;
            this.vol.style.setProperty('--p', (shown * 100) + '%');
            this.vol.style.setProperty('--b', '0%');
        }
        if (this.mute) {
            var label = (a.muted || a.volume === 0) ? 'Включить звук' : 'Выключить звук';
            this.mute.setAttribute('aria-label', label);
            this.mute.title = label;
        }
    };
    Player.prototype.setPlayLabel = function (playing) {
        var label = playing ? 'Пауза' : 'Воспроизвести';
        this.play.setAttribute('aria-label', label);
        this.play.title = label;
    };
    Player.prototype.toggle = function () {
        var a = this.audio;
        if (this.root.classList.contains('is-error')) {
            this.root.classList.remove('is-error');       // повторная попытка
            a.load();
        }
        if (a.paused) {
            var pr = a.play();
            if (pr && pr.catch) pr.catch(function () { /* автоплей запрещён / ошибка — состояние обновит событие error */ });
        } else {
            a.pause();
        }
    };
    Player.prototype.onPlay = function () {
        if (current && current !== this) current.audio.pause();   // одновременно играет один трек
        current = this;
        saveResume(this);
        this.root.classList.add('is-playing');
        this.setPlayLabel(true);
        this.updateMediaSession();
        syncFavicon();
    };
    Player.prototype.onEnded = function () {
        lsSet(RESUME_KEY, '');   // трек доигран — запоминать нечего (следующий трек сохранит себя сам)
        this.root.classList.remove('is-playing');
        this.audio.currentTime = 0;
        this.renderTime();
        this.setPlayLabel(false);
        syncFavicon();
        this.step(1);
    };
    // Переключение на соседний трек в том же списке
    Player.prototype.step = function (dir) {
        var list = players.filter(function (p) { return p.root.closest('.track-list') === this.root.closest('.track-list'); }, this);
        var i = list.indexOf(this), next = list[i + dir];
        if (!next) return;
        if (dir < 0 && this.audio.currentTime > 3) { this.audio.currentTime = 0; return; }
        next.toggle();
        next.root.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    };
    Player.prototype.updateMediaSession = function () {
        if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
        var self = this;
        try {
            navigator.mediaSession.metadata = new MediaMetadata({ title: this.title, artist: this.artist, album: 'SPACE' });
            navigator.mediaSession.setActionHandler('play', function () { self.audio.play(); });
            navigator.mediaSession.setActionHandler('pause', function () { self.audio.pause(); });
            navigator.mediaSession.setActionHandler('previoustrack', function () { self.step(-1); });
            navigator.mediaSession.setActionHandler('nexttrack', function () { self.step(1); });
            navigator.mediaSession.setActionHandler('seekto', function (d) { if (d && isFinite(d.seekTime)) self.audio.currentTime = d.seekTime; });
        } catch (e) { /* часть действий может не поддерживаться */ }
    };

    // Вернуть сохранённую позицию: ставим время, но не запускаем — автоплей браузеры всё равно блокируют
    Player.prototype.resumeAt = function (t) {
        var a = this.audio, self = this, done = false;
        function apply() {
            if (done || !a.paused) return;                 // пользователь уже нажал ▶ — не мешаем
            var d = a.duration;
            if (!isFinite(d) || d <= 0 || t >= d - 1) { if (d > 0) done = true; return; }
            self.setSeekMax();
            if (Math.abs(a.currentTime - t) > 1) {
                try { a.currentTime = t; } catch (e) { /* метаданные ещё не готовы — повторим позже */ }
            }
            self.renderTime();
        }
        // браузер/сервер могли сбросить время при догрузке — пробуем на каждом этапе, пока позиция не встанет
        a.addEventListener('seeked', function () { if (Math.abs(a.currentTime - t) <= 1) done = true; });
        a.addEventListener('loadedmetadata', apply);
        a.addEventListener('canplay', apply);
        if (a.readyState >= 1) apply();
    };

    function restore() {
        var raw = lsGet(RESUME_KEY), data = null;
        if (!raw) return;
        try { data = JSON.parse(raw); } catch (e) { return; }
        if (!data || !data.src || !(data.t > 1)) return;
        for (var i = 0; i < players.length; i++) {
            if (players[i].src === data.src) players[i].resumeAt(data.t);
        }
    }

    function init() {
        var roots = document.querySelectorAll('.mp');
        for (var i = 0; i < roots.length; i++) {
            var p = new Player(roots[i]);
            if (p.audio) players.push(p);
        }
        restore();
    }
    // F5 / закрытие вкладки во время игры: сохраняем последнюю позицию
    function saveCurrent() { if (current) saveResume(current); }
    window.addEventListener('pagehide', saveCurrent);
    window.addEventListener('beforeunload', saveCurrent);
    document.addEventListener('visibilitychange', function () { if (document.hidden) saveCurrent(); });
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();

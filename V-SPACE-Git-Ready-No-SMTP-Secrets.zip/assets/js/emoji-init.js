// emoji-init.js — показ собственных эмодзи (custom-emoji.js) в сообщениях и в поле ввода.
// Подключать ПОСЛЕ custom-emoji.js и emoji.js.

// ------------------------------------------------------------
// 1. Сообщения и превью диалогов: :код: -> картинка
// ------------------------------------------------------------
document.addEventListener('DOMContentLoaded', function () {
    if (!window.CustomEmoji) return;

    // Контейнер выбираем по .messages-layout: messages.js подменяет .chat-area (а вместе с ним
    // и #chatMessages) при смене диалога, поэтому наблюдать за самим #chatMessages нельзя.
    const root = document.getElementById('messagesLayout')
        || document.getElementById('chatMessages')
        || document.getElementById('messages')
        || document.querySelector('.messages');
    if (!root) return;

    // :код: -> картинка в уже выведенных сообщениях
    CustomEmoji.parse(root);

    // и в тех, что появляются позже (новые сообщения, смена диалога, подгрузка)
    new MutationObserver(function (mutations) {
        mutations.forEach(function (m) {
            m.addedNodes.forEach(function (n) {
                if (n.nodeType === 1) CustomEmoji.parse(n);
            });
        });
    }).observe(root, { childList: true, subtree: true });
});

// ------------------------------------------------------------
// 2. Поле ввода #messageInput: эмодзи видны картинками, а сам :код: спрятан и «не берётся».
//
// <input> не умеет показывать картинки, поэтому поверх него рисуется «зеркало» с тем же текстом,
// где :код: заменён на <img>, а текст в поле делается прозрачным (курсор остаётся видимым).
// Под каждое эмодзи в зеркале резервируется ширина исходного :кода:, поэтому курсор и выделение
// в поле совпадают с картинками. В value по-прежнему лежит :код: — на сервер уходит именно он.
//
// Эмодзи ведёт себя как один символ:
//  - курсор и края выделения не могут оказаться внутри :кода: (прижимаются к границе);
//  - стрелки, Backspace и Delete перескакивают/удаляют эмодзи целиком;
//  - родная подсветка выделения скрыта, выделение рисуется в зеркале;
//  - при копировании и вырезании :код: в буфер обмена не попадает, перетаскивание выделения с эмодзи отключено.
// ------------------------------------------------------------
(function () {
    'use strict';

    var CODE_RE_G   = /:[\p{L}\p{N}_+\-]+:/gu;
    var CODE_END_RE = /:[\p{L}\p{N}_+\-]+:$/u;
    var CODE_BEG_RE = /^:[\p{L}\p{N}_+\-]+:/u;

    var mirror = null, inner = null;
    var state  = { input: null, key: null, value: null, active: false, origColor: '', origSpell: null, ranges: [], lastPos: 0 };
    var valid  = new Set();                       // коды, которые custom-emoji.js реально превратил в картинки
    var mouseDown = false;
    var ctx    = document.createElement('canvas').getContext('2d');

    function getInput() { return document.getElementById('messageInput'); }
    function isMsgInput(el) { return !!(el && el.id === 'messageInput'); }
    function hasCustomEmoji() { return !!(window.CustomEmoji && typeof window.CustomEmoji.parse === 'function'); }
    function px(v) { return parseFloat(v) || 0; }

    function ensureMirror(input) {
        var parent = input.parentElement;
        if (!parent) return false;

        if (!mirror) {
            mirror = document.createElement('div');
            mirror.className = 'emoji-input-mirror';
            mirror.setAttribute('aria-hidden', 'true');
            var viewport = document.createElement('div');
            viewport.className = 'emoji-input-mirror-viewport';
            inner = document.createElement('span');
            inner.className = 'emoji-input-mirror-inner';
            viewport.appendChild(inner);
            mirror.appendChild(viewport);
        }

        // Зеркало должно стоять сразу после поля. Если mentions.js обернул поле в свой контейнер
        // или .chat-area подменили целиком, возвращаем зеркало на место.
        if (mirror.previousElementSibling !== input) {
            if (window.getComputedStyle(parent).position === 'static') parent.style.position = 'relative';
            input.insertAdjacentElement('afterend', mirror);
        }
        return true;
    }

    function layout(input) {
        var cs = window.getComputedStyle(input);
        mirror.style.left   = input.offsetLeft + 'px';
        mirror.style.top    = input.offsetTop + 'px';
        mirror.style.width  = input.offsetWidth + 'px';
        mirror.style.height = input.offsetHeight + 'px';
        mirror.style.paddingLeft   = (px(cs.paddingLeft)   + px(cs.borderLeftWidth))   + 'px';
        mirror.style.paddingRight  = (px(cs.paddingRight)  + px(cs.borderRightWidth))  + 'px';
        mirror.style.paddingTop    = (px(cs.paddingTop)    + px(cs.borderTopWidth))    + 'px';
        mirror.style.paddingBottom = (px(cs.paddingBottom) + px(cs.borderBottomWidth)) + 'px';
        mirror.style.fontFamily    = cs.fontFamily;
        mirror.style.fontSize      = cs.fontSize;
        mirror.style.fontWeight    = cs.fontWeight;
        mirror.style.fontStyle     = cs.fontStyle;
        mirror.style.letterSpacing = cs.letterSpacing;
        mirror.style.lineHeight    = cs.lineHeight;
        mirror.style.color         = state.origColor || cs.color;
    }

    function measure(text, input) {
        var cs = window.getComputedStyle(input);
        ctx.font = cs.fontStyle + ' ' + cs.fontWeight + ' ' + cs.fontSize + ' ' + cs.fontFamily;
        var w = ctx.measureText(text).width;
        var ls = px(cs.letterSpacing);
        if (ls) w += ls * text.length;
        return Math.ceil(w);
    }

    function setActive(input, on) {
        if (on) {
            if (!state.active || input.getAttribute('data-emoji-mirror') !== '1') {
                state.origSpell = input.getAttribute('spellcheck');
            }
            input.style.setProperty('color', 'transparent', 'important');
            input.style.caretColor = state.origColor || '';
            input.spellcheck = false;                      // красное подчёркивание «ошибок» просвечивало бы сквозь прозрачный текст
            input.setAttribute('data-emoji-mirror', '1');
            input.classList.add('has-emoji-mirror');       // прячет родную подсветку выделения (см. emoji.css)
            mirror.style.display = 'flex';
        } else {
            if (input.getAttribute('data-emoji-mirror') === '1') {
                input.removeAttribute('data-emoji-mirror');
                if (state.origSpell === null) input.removeAttribute('spellcheck');
                else input.setAttribute('spellcheck', state.origSpell);
            }
            input.style.removeProperty('color');
            input.style.caretColor = '';
            input.classList.remove('has-emoji-mirror');
            if (mirror) mirror.style.display = 'none';
        }
        state.active = on;
    }

    function render(input, selS, selE) {
        var value = input.value;
        state.value = value;
        valid.clear();
        state.ranges = [];
        inner.textContent = '';

        var hasSel = selE > selS;
        var frag = document.createDocumentFragment();

        // текст с подсветкой выделенной части (выделение рисуем сами — родное спрятано)
        function addText(from, to) {
            if (from >= to) return;
            var a = Math.max(from, Math.min(to, selS));
            var b = Math.max(from, Math.min(to, selE));
            var pieces = (hasSel && b > a)
                ? [[from, a, false], [a, b, true], [b, to, false]]
                : [[from, to, false]];
            pieces.forEach(function (p) {
                if (p[0] >= p[1]) return;
                var t = value.slice(p[0], p[1]);
                if (p[2]) {
                    var sp = document.createElement('span');
                    sp.className = 'emoji-input-sel';
                    sp.textContent = t;
                    frag.appendChild(sp);
                } else {
                    frag.appendChild(document.createTextNode(t));
                }
            });
        }

        var last = 0, m, hasEmoji = false;
        CODE_RE_G.lastIndex = 0;
        while ((m = CODE_RE_G.exec(value)) !== null) {
            var code = m[0], start = m.index, end = m.index + code.length;
            addText(last, start);

            var slot = document.createElement('span');
            slot.textContent = code;
            var ok = false;
            try {
                window.CustomEmoji.parse(slot);
                ok = !!slot.querySelector('img');
            } catch (e) { ok = false; }

            if (ok) {
                slot.className = 'emoji-input-slot' + ((hasSel && start < selE && end > selS) ? ' is-selected' : '');
                slot.style.width = measure(code, input) + 'px';
                valid.add(code);
                state.ranges.push({ start: start, end: end, code: code });
                hasEmoji = true;
                frag.appendChild(slot);
            } else {
                addText(start, end);                       // неизвестный :код: остаётся обычным текстом
            }
            last = end;
        }
        addText(last, value.length);
        inner.appendChild(frag);

        setActive(input, hasEmoji);
    }

    function syncScroll(input) {
        if (inner) inner.style.transform = 'translateX(' + (-input.scrollLeft) + 'px)';
    }

    function refresh(force) {
        if (!hasCustomEmoji()) return;
        var input = getInput();
        if (!input) return;
        if (!ensureMirror(input)) return;

        // исходный цвет текста запоминаем, пока поле ещё не сделано прозрачным
        if (input.style.getPropertyValue('color') !== 'transparent') {
            state.origColor = window.getComputedStyle(input).color;
        }
        layout(input);

        var focused = document.activeElement === input;
        var selS = focused ? (input.selectionStart || 0) : 0;
        var selE = focused ? (input.selectionEnd || 0) : 0;
        var key = input.value + '\u0000' + selS + ',' + selE + (focused ? 'f' : '');

        if (force || input !== state.input || key !== state.key) {
            state.input = input;
            state.key = key;
            render(input, selS, selE);
        }
        syncScroll(input);
    }

    // Курсор и края выделения не должны оказываться внутри :кода:
    function snap(input, byMouse) {
        if (mouseDown || !state.ranges.length || document.activeElement !== input) return;
        var s = input.selectionStart, e = input.selectionEnd;
        if (s === null || e === null) return;
        var dir = input.selectionDirection || 'none';
        var ns = s, ne = e;

        state.ranges.forEach(function (r) {
            if (s === e) {
                if (s > r.start && s < r.end) {
                    var toEnd = byMouse ? (r.end - s) <= (s - r.start) : s >= state.lastPos;
                    ns = ne = toEnd ? r.end : r.start;
                }
            } else {
                if (s > r.start && s < r.end) ns = r.start;
                if (e > r.start && e < r.end) ne = r.end;
            }
        });

        if (ns !== s || ne !== e) {
            input.setSelectionRange(ns, ne, dir);
            refresh(false);
        }
        state.lastPos = (dir === 'backward') ? ns : ne;
    }

    function selectionHasEmoji(input) {
        var s = input.selectionStart, e = input.selectionEnd;
        if (s === null || s === e) return false;
        return state.ranges.some(function (r) { return r.start < e && r.end > s; });
    }

    function stripCodes(text) {
        return text.replace(CODE_RE_G, function (c) { return valid.has(c) ? '' : c; });
    }

    // Плавная прокрутка зеркала и «прижимание» курсора, пока поле в фокусе
    var rafId = 0;
    function loop() {
        var input = getInput();
        if (!input || document.activeElement !== input) { rafId = 0; refresh(false); return; }
        refresh(false);
        snap(input, false);
        rafId = window.requestAnimationFrame(loop);
    }

    document.addEventListener('input', function (e) {
        if (isMsgInput(e.target)) refresh(false);
    });
    document.addEventListener('focusin', function (e) {
        if (isMsgInput(e.target) && !rafId) rafId = window.requestAnimationFrame(loop);
    });
    document.addEventListener('focusout', function (e) {
        if (isMsgInput(e.target)) setTimeout(function () { refresh(false); }, 0);
    });
    ['keyup', 'click', 'select', 'scroll'].forEach(function (type) {
        document.addEventListener(type, function (e) {
            if (isMsgInput(e.target)) refresh(false);
        }, true);
    });

    document.addEventListener('mousedown', function (e) {
        if (isMsgInput(e.target)) mouseDown = true;
    }, true);
    document.addEventListener('mouseup', function () {
        if (!mouseDown) return;
        mouseDown = false;
        setTimeout(function () {
            var input = getInput();
            if (!input) return;
            refresh(false);
            snap(input, true);
        }, 0);
    }, true);

    document.addEventListener('submit', function () { setTimeout(function () { refresh(true); }, 50); });
    window.addEventListener('resize', function () { refresh(true); });
    window.addEventListener('load', function () { refresh(true); });
    document.addEventListener('DOMContentLoaded', function () { refresh(true); });

    // Значение могут менять программно (черновик, очистка после отправки, вставка из панели)
    // и .chat-area может быть заменена целиком — подхватываем это по таймеру.
    setInterval(function () { refresh(false); }, 250);

    // Стрелки перескакивают эмодзи целиком (с Shift — расширяют выделение целыми эмодзи)
    // Backspace / Delete удаляют эмодзи целиком, а не по одной букве из :кода:
    document.addEventListener('keydown', function (e) {
        var input = e.target;
        if (!isMsgInput(input)) return;
        if (e.ctrlKey || e.metaKey || e.altKey || e.isComposing) return;

        refresh(false);

        if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
            var s = input.selectionStart, en = input.selectionEnd;
            var collapsed = s === en;
            if (!collapsed && !e.shiftKey) return;       // обычное сворачивание выделения — штатно, края уже на границах

            var dir    = input.selectionDirection;
            var focus  = collapsed ? s : (dir === 'backward' ? s : en);
            var anchor = collapsed ? s : (dir === 'backward' ? en : s);
            var right  = e.key === 'ArrowRight';
            var hit = null;
            state.ranges.forEach(function (r) {
                if (right ? r.start === focus : r.end === focus) hit = r;
            });
            if (!hit) return;

            var nf = right ? hit.end : hit.start;
            e.preventDefault();
            if (e.shiftKey) {
                input.setSelectionRange(Math.min(anchor, nf), Math.max(anchor, nf), nf < anchor ? 'backward' : 'forward');
            } else {
                input.setSelectionRange(nf, nf);
            }
            state.lastPos = nf;
            refresh(false);
            return;
        }

        if (e.key !== 'Backspace' && e.key !== 'Delete') return;
        if (input.selectionStart !== input.selectionEnd) return;

        var pos = input.selectionStart, v = input.value, m, start, end;
        if (e.key === 'Backspace') {
            m = v.slice(0, pos).match(CODE_END_RE);
            if (!m || !valid.has(m[0])) return;
            start = pos - m[0].length; end = pos;
        } else {
            m = v.slice(pos).match(CODE_BEG_RE);
            if (!m || !valid.has(m[0])) return;
            start = pos; end = pos + m[0].length;
        }
        e.preventDefault();
        input.value = v.slice(0, start) + v.slice(end);
        input.setSelectionRange(start, start);
        input.dispatchEvent(new Event('input', { bubbles: true }));
    });

    // Копирование / вырезание: :код: в буфер обмена не попадает
    function onClipboard(cut) {
        return function (e) {
            var input = e.target;
            if (!isMsgInput(input)) return;
            refresh(false);
            if (!selectionHasEmoji(input)) return;

            var s = input.selectionStart, en = input.selectionEnd;
            var stripped = stripCodes(input.value.slice(s, en));
            e.preventDefault();
            if (e.clipboardData) e.clipboardData.setData('text/plain', stripped);

            if (cut) {
                input.value = input.value.slice(0, s) + input.value.slice(en);
                input.setSelectionRange(s, s);
                input.dispatchEvent(new Event('input', { bubbles: true }));
            }
        };
    }
    document.addEventListener('copy', onClipboard(false), true);
    document.addEventListener('cut',  onClipboard(true),  true);

    // Выделение с эмодзи нельзя утащить мышью (иначе в другое поле упал бы :код:)
    document.addEventListener('dragstart', function (e) {
        if (isMsgInput(e.target) && selectionHasEmoji(e.target)) e.preventDefault();
    }, true);
})();

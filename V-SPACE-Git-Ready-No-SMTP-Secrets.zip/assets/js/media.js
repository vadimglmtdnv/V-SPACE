/* Страницы «Фото» и «Видео»: выбор файлов, сетка, просмотрщик.
   Файлы показываются только в браузере (blob-ссылки) и на сервер не отправляются. */
(function () {
    var root = document.querySelector('[data-md-kind]');
    if (!root) return;
    var kind = root.getAttribute('data-md-kind');          // photo | video
    var input = document.getElementById('mdInput');
    var drop = document.getElementById('mdDrop');
    var grid = document.getElementById('mdGrid');
    var toolbar = document.getElementById('mdToolbar');
    var countEl = document.getElementById('mdCount');
    var viewer = document.getElementById('mdViewer');
    var stage = document.getElementById('mdStage');
    var vcap = document.getElementById('mdVcap');
    var items = [];
    var current = -1;

    var words = kind === 'photo' ? ['фото', 'фото', 'фото'] : ['видео', 'видео', 'видео'];

    function fmt(sec) {
        if (!isFinite(sec)) return '';
        var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
        return m + ':' + (s < 10 ? '0' : '') + s;
    }

    function render() {
        var has = items.length > 0;
        drop.hidden = has;
        grid.hidden = !has;
        toolbar.hidden = !has;
        countEl.innerHTML = items.length + ' <span>' + words[0] + '</span>';
    }

    function addFiles(files) {
        Array.prototype.forEach.call(files, function (file) {
            var ok = kind === 'photo' ? /^image\//.test(file.type) : /^video\//.test(file.type);
            if (!ok) return;
            var url = URL.createObjectURL(file);
            var item = { url: url, name: file.name.replace(/\.[^.]+$/, '') };
            items.push(item);
            var el = document.createElement('div');
            el.className = 'md-item';
            item.el = el;

            var del = document.createElement('button');
            del.type = 'button'; del.className = 'md-del'; del.title = 'Убрать'; del.textContent = '×';
            del.addEventListener('click', function (e) {
                e.stopPropagation();
                var i = items.indexOf(item);
                if (i > -1) items.splice(i, 1);
                el.remove(); URL.revokeObjectURL(url); render();
            });

            var cap = document.createElement('div');
            cap.className = 'md-cap'; cap.textContent = item.name;

            if (kind === 'photo') {
                var img = document.createElement('img');
                img.src = url; img.alt = item.name; img.loading = 'lazy';
                el.appendChild(img);
            } else {
                var v = document.createElement('video');
                v.src = url + '#t=0.5'; v.preload = 'metadata'; v.muted = true;
                var dur = document.createElement('span');
                dur.className = 'md-dur';
                v.addEventListener('loadedmetadata', function () { dur.textContent = fmt(v.duration); });
                var play = document.createElement('span');
                play.className = 'md-play';
                play.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
                el.appendChild(v); el.appendChild(dur); el.appendChild(play);
            }
            el.appendChild(cap); el.appendChild(del);
            el.addEventListener('click', function () { open(items.indexOf(item)); });
            grid.appendChild(el);
        });
        render();
    }

    function open(i) {
        if (i < 0 || i >= items.length) return;
        current = i;
        stage.innerHTML = '';
        var it = items[i], node;
        if (kind === 'photo') {
            node = document.createElement('img'); node.src = it.url; node.alt = it.name;
        } else {
            node = document.createElement('video'); node.src = it.url; node.controls = true; node.autoplay = true;
        }
        stage.appendChild(node);
        vcap.textContent = it.name + '  ·  ' + (i + 1) + ' / ' + items.length;
        viewer.classList.add('open');
        document.body.style.overflow = 'hidden';
    }
    function close() {
        viewer.classList.remove('open');
        stage.innerHTML = '';          // останавливает видео
        document.body.style.overflow = '';
        current = -1;
    }
    function step(d) { if (items.length > 1) open((current + d + items.length) % items.length); }

    input.addEventListener('change', function () { addFiles(input.files); input.value = ''; });

    ['dragenter', 'dragover'].forEach(function (ev) {
        document.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); });
    });
    ['dragleave', 'drop'].forEach(function (ev) {
        document.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); });
    });
    document.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files); });

    document.querySelectorAll('.md-seg button').forEach(function (b) {
        b.addEventListener('click', function () {
            document.querySelectorAll('.md-seg button').forEach(function (x) { x.classList.remove('active'); });
            b.classList.add('active');
            grid.setAttribute('data-size', b.getAttribute('data-size'));
        });
    });

    viewer.addEventListener('click', function (e) { if (e.target === viewer) close(); });
    viewer.querySelector('.close').addEventListener('click', close);
    viewer.querySelector('.prev').addEventListener('click', function (e) { e.stopPropagation(); step(-1); });
    viewer.querySelector('.next').addEventListener('click', function (e) { e.stopPropagation(); step(1); });
    document.addEventListener('keydown', function (e) {
        if (!viewer.classList.contains('open')) return;
        if (e.key === 'Escape') close();
        else if (e.key === 'ArrowLeft') step(-1);
        else if (e.key === 'ArrowRight') step(1);
    });

    render();
})();

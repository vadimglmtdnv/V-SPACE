        const moodBtn = document.getElementById('emojiBtn');

        if (moodBtn) {
            // При наведении мыши меняем на грустный
            moodBtn.addEventListener('mouseenter', function() {
                this.textContent = '😔';
                this.setAttribute('title', 'Вставить грустное эмодзи');
            });

            // Когда мышь уходит, возвращаем весёлый
            moodBtn.addEventListener('mouseleave', function() {
                this.textContent = '😊';
                this.setAttribute('title', 'Вставить эмодзи');
            });
        }
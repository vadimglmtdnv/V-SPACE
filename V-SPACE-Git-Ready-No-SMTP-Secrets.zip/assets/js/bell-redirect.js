/* bell-redirect.js — на телефоне колокольчик ведёт на страницу уведомлений (notifications.php),
   а не открывает выпадающее окно. Слушатель стоит на window в фазе перехвата, поэтому срабатывает
   раньше всех остальных обработчиков шапки (header-dropdowns.js, index.php, edit.php и т.д.). */
(function () {
    'use strict';
    if (window.__bellRedirectBound) return;
    window.__bellRedirectBound = true;

    var phone = window.matchMedia('(max-width: 768px)');

    window.addEventListener('click', function (event) {
        var target = event.target;
        if (!target || !target.closest) return;
        if (!target.closest('#notificationsBtn')) return;
        if (!phone.matches) return;

        // не даём открыться выпадающему окну
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        if (!/notifications\.php$/.test(window.location.pathname)) {
            window.location.href = 'notifications.php';
        }
    }, true);
})();

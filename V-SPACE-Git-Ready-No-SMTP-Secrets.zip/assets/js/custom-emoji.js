/**
 * custom-emoji.js — собственный эмодзи-пак для соцсети (200 шт.).
 * Подключать ДО emoji.js.
 *
 * В поле ввода эмодзи хранится как шорткод  :happy:  /  :flag_ru:  /  :zodiac_leo:
 * При показе сообщения шорткод превращается в <img>.
 */
(function () {
    const BASE_PATH = 'images/icons/custom-emoji/';   // папка с эмодзи: playerchat/images/icons/custom-emoji

    // [код, название]  → файл BASE_PATH + код + '.svg'
    const categories = [
        { title: 'Смайлы', icon: '🙂', items: [
            ['happy', 'Радость'],
            ['joy', 'Ржу'],
            ['smile', 'Улыбка'],
            ['love', 'Влюблён'],
            ['cool', 'Круто'],
            ['wink', 'Подмигиваю'],
            ['tongue', 'Дразнюсь'],
            ['shy', 'Смущён'],
            ['party', 'Праздник'],
            ['think', 'Думаю'],
            ['shock', 'Шок'],
            ['sleep', 'Сплю'],
            ['sad', 'Грустно'],
            ['cry', 'Плачу'],
            ['angry', 'Злюсь'],
            ['evil', 'Злодей'],
            ['sick', 'Заболел'],
            ['cold', 'Мёрзну'],
            ['dead', 'Всё…']
        ] },
        { title: 'Сердечки', icon: '❤️', items: [
            ['heart_red', 'Красное сердце'],
            ['heart_orange', 'Оранжевое сердце'],
            ['heart_yellow', 'Жёлтое сердце'],
            ['heart_green', 'Зелёное сердце'],
            ['heart_blue', 'Синее сердце'],
            ['heart_purple', 'Фиолетовое сердце'],
            ['heart_black', 'Чёрное сердце'],
            ['heart_white', 'Белое сердце'],
            ['heart_brown', 'Коричневое сердце'],
            ['heart_pink', 'Розовое сердце'],
            ['heart_broken', 'Разбитое сердце'],
            ['heart_sparkle', 'Сверкающее сердце'],
            ['hearts_two', 'Два сердца'],
            ['heart_arrow', 'Сердце со стрелой'],
            ['heart_bow', 'Сердце с бантом'],
            ['heart_fire', 'Горящее сердце']
        ] },
        { title: 'Природа', icon: '🌿', items: [
            ['sakura', 'Сакура'],
            ['tulip', 'Тюльпан'],
            ['sunflower', 'Подсолнух'],
            ['rose', 'Роза'],
            ['tree', 'Дерево'],
            ['pine', 'Ёлка'],
            ['palm', 'Пальма'],
            ['cactus', 'Кактус'],
            ['mushroom', 'Гриб'],
            ['clover', 'Клевер'],
            ['maple', 'Кленовый лист'],
            ['sun', 'Солнце'],
            ['moon', 'Луна'],
            ['cloud', 'Облако'],
            ['rain', 'Дождь'],
            ['snow', 'Снежинка'],
            ['rainbow', 'Радуга'],
            ['lightning', 'Молния'],
            ['drop', 'Капля'],
            ['mountain', 'Горы'],
            ['butterfly', 'Бабочка'],
            ['cat', 'Котик'],
            ['dog', 'Собачка'],
            ['bunny', 'Зайка'],
            ['frog', 'Лягушка'],
            ['panda', 'Панда'],
            ['fox', 'Лисичка']
        ] },
        { title: 'Еда', icon: '🍕', items: [
            ['pizza', 'Пицца'],
            ['burger', 'Бургер'],
            ['fries', 'Картошка фри'],
            ['sushi', 'Суши'],
            ['ramen', 'Рамен'],
            ['donut', 'Пончик'],
            ['cake', 'Тортик'],
            ['cupcake', 'Капкейк'],
            ['icecream', 'Мороженое'],
            ['cookie', 'Печенье'],
            ['coffee', 'Кофе'],
            ['boba', 'Бабл-ти'],
            ['beer', 'Пиво'],
            ['wine', 'Вино'],
            ['apple', 'Яблоко'],
            ['banana', 'Банан'],
            ['strawberry', 'Клубника'],
            ['watermelon', 'Арбуз'],
            ['orange', 'Апельсин'],
            ['grapes', 'Виноград'],
            ['cherry', 'Вишня'],
            ['avocado', 'Авокадо'],
            ['carrot', 'Морковка'],
            ['corn', 'Кукуруза'],
            ['bread', 'Хлеб'],
            ['egg', 'Яичница'],
            ['popcorn', 'Попкорн'],
            ['lollipop', 'Леденец']
        ] },
        { title: 'Транспорт', icon: '🚗', items: [
            ['car', 'Машина'],
            ['taxi', 'Такси'],
            ['police', 'Полиция'],
            ['bus', 'Автобус'],
            ['truck', 'Грузовик'],
            ['ambulance', 'Скорая'],
            ['train', 'Поезд'],
            ['plane', 'Самолёт'],
            ['helicopter', 'Вертолёт'],
            ['rocket', 'Ракета'],
            ['ship', 'Корабль'],
            ['sailboat', 'Парусник'],
            ['bike', 'Велосипед'],
            ['scooter', 'Самокат'],
            ['ufo', 'НЛО'],
            ['balloon', 'Воздушный шар']
        ] },
        { title: 'Город', icon: '🏙️', items: [
            ['house', 'Домик'],
            ['apartments', 'Многоэтажка'],
            ['skyscraper', 'Небоскрёб'],
            ['hospital', 'Больница'],
            ['school', 'Школа'],
            ['bank', 'Банк'],
            ['store', 'Магазин'],
            ['castle', 'Замок'],
            ['church', 'Церковь'],
            ['ferris', 'Колесо обозрения'],
            ['bridge', 'Мост'],
            ['traffic', 'Светофор'],
            ['factory', 'Завод'],
            ['night_city', 'Ночной город'],
            ['tent', 'Палатка']
        ] },
        { title: 'Флаги', icon: '🏁', items: [
            ['flag_ru', 'Россия'],
            ['flag_ua', 'Украина'],
            ['flag_fr', 'Франция'],
            ['flag_it', 'Италия'],
            ['flag_de', 'Германия'],
            ['flag_nl', 'Нидерланды'],
            ['flag_pl', 'Польша'],
            ['flag_am', 'Армения'],
            ['flag_ar', 'Аргентина'],
            ['flag_mx', 'Мексика'],
            ['flag_es', 'Испания'],
            ['flag_jp', 'Япония'],
            ['flag_cz', 'Чехия'],
            ['flag_se', 'Швеция'],
            ['flag_fi', 'Финляндия'],
            ['flag_dk', 'Дания'],
            ['flag_no', 'Норвегия'],
            ['flag_is', 'Исландия'],
            ['flag_gr', 'Греция'],
            ['flag_tr', 'Турция'],
            ['flag_kz', 'Казахстан'],
            ['flag_uz', 'Узбекистан'],
            ['flag_az', 'Азербайджан'],
            ['flag_ge', 'Грузия'],
            ['flag_by', 'Беларусь'],
            ['flag_il', 'Израиль'],
            ['flag_cn', 'Китай'],
            ['flag_kr', 'Корея'],
            ['flag_in', 'Индия'],
            ['flag_us', 'США'],
            ['flag_ca', 'Канада'],
            ['flag_br', 'Бразилия'],
            ['flag_gb', 'Великобритания'],
            ['flag_eu', 'Евросоюз'],
            ['flag_pride', 'Радужный флаг'],
            ['flag_checkered', 'Финиш'],
            ['flag_white', 'Белый флаг'],
            ['flag_pirate', 'Весёлый Роджер']
        ] },
        { title: 'Гороскоп', icon: '♈', items: [
            ['zodiac_aries', 'Овен'],
            ['zodiac_taurus', 'Телец'],
            ['zodiac_gemini', 'Близнецы'],
            ['zodiac_cancer', 'Рак'],
            ['zodiac_leo', 'Лев'],
            ['zodiac_virgo', 'Дева'],
            ['zodiac_libra', 'Весы'],
            ['zodiac_scorpio', 'Скорпион'],
            ['zodiac_sagittarius', 'Стрелец'],
            ['zodiac_capricorn', 'Козерог'],
            ['zodiac_aquarius', 'Водолей'],
            ['zodiac_pisces', 'Рыбы']
        ] },
        { title: 'От себя', icon: '✨', items: [
            ['heart', 'Сердце'],
            ['fire', 'Огонь'],
            ['star', 'Звезда'],
            ['trophy', 'Кубок'],
            ['crown', 'Корона'],
            ['gift', 'Подарок'],
            ['diamond', 'Бриллиант'],
            ['bulb', 'Идея'],
            ['bell', 'Колокольчик'],
            ['music', 'Нота'],
            ['headphones', 'Наушники'],
            ['gamepad', 'Геймпад'],
            ['camera', 'Фотоаппарат'],
            ['ghost', 'Призрак'],
            ['alien', 'Пришелец'],
            ['robot', 'Робот'],
            ['skull', 'Череп'],
            ['check', 'Галочка'],
            ['cross', 'Крестик'],
            ['hundred', 'Сто баллов'],
            ['question', 'Вопрос'],
            ['exclaim', 'Восклицание'],
            ['chat', 'Сообщение'],
            ['moneybag', 'Мешок денег'],
            ['key', 'Ключ'],
            ['wand', 'Волшебная палочка'],
            ['eyes', 'Глазки'],
            ['thumbsup', 'Класс'],
            ['confetti', 'Хлопушка']
        ] }
    ];

    const byCode = new Map();
    categories.forEach(function (cat) {
        cat.items.forEach(function (it) { byCode.set(it[0], { code: it[0], title: it[1], cat: cat.title }); });
    });
    const SHORTCODE_RE = /:([a-z0-9_]+):/g;

    function url(code) { return BASE_PATH + code + '.svg'; }

    function makeImg(code) {
        const item = byCode.get(code);
        const img = document.createElement('img');
        img.className = 'custom-emoji';
        img.src = url(code);
        img.alt = ':' + code + ':';
        img.title = item ? item.title : code;
        img.draggable = false;
        img.loading = 'lazy';
        // В тексте сообщения: если файла нет — возвращаем обычный текст :код:, а не битую картинку
        img.addEventListener('error', function () {
            if (img.closest('.emoji-item-custom, .custom-emoji-nav-btn')) return;
            img.replaceWith(document.createTextNode(img.alt));
        });
        return img;
    }

    /** Добавляет в контейнер пикера панель категорий + все секции пака (в начало). */
    function renderSection(container, onPick) {
        const frag = document.createDocumentFragment();

        const nav = document.createElement('div');
        nav.className = 'custom-emoji-nav';
        frag.appendChild(nav);

        categories.forEach(function (cat, idx) {
            const section = document.createElement('section');
            section.className = 'emoji-section custom-emoji-section';
            section.id = 'ce-cat-' + idx;

            const heading = document.createElement('h3');
            heading.className = 'emoji-section-title';
            heading.textContent = cat.title;
            section.appendChild(heading);

            const grid = document.createElement('div');
            grid.className = 'emoji-section-grid';
            cat.items.forEach(function (it) {
                const span = document.createElement('span');
                span.className = 'emoji-item emoji-item-custom';
                span.dataset.emoji = ':' + it[0] + ':';
                span.title = it[1] + '  :' + it[0] + ':';
                span.appendChild(makeImg(it[0]));
                span.addEventListener('click', function () { onPick(this.dataset.emoji); });
                grid.appendChild(span);
            });
            section.appendChild(grid);
            frag.appendChild(section);

            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'custom-emoji-nav-btn';
            // значок категории — первое собственное эмодзи из неё (без обычных Unicode-смайлов)
            btn.appendChild(makeImg(cat.items[0][0]));
            btn.title = cat.title;
            btn.addEventListener('click', function (e) {
                e.preventDefault(); e.stopPropagation();
                // не зависит от position у контейнера: считаем смещение через getBoundingClientRect
                const offset = section.getBoundingClientRect().top - container.getBoundingClientRect().top;
                container.scrollTo({ top: container.scrollTop + offset - nav.offsetHeight, behavior: 'smooth' });
            });
            nav.appendChild(btn);
        });

        container.insertBefore(frag, container.firstChild);
    }

    /** Заменяет :code: на картинки внутри элемента (для текста сообщений). */
    function parse(root) {
        if (!root) return;
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode: function (n) {
                if (!n.nodeValue.includes(':')) return NodeFilter.FILTER_REJECT;
                const tag = n.parentNode && n.parentNode.nodeName;
                return (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA')
                    ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
            }
        });
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);

        nodes.forEach(function (node) {
            const text = node.nodeValue;
            let last = 0, found = false, m;
            const frag = document.createDocumentFragment();
            SHORTCODE_RE.lastIndex = 0;
            while ((m = SHORTCODE_RE.exec(text))) {
                if (!byCode.has(m[1])) { SHORTCODE_RE.lastIndex = m.index + 1; continue; }
                found = true;
                frag.appendChild(document.createTextNode(text.slice(last, m.index)));
                frag.appendChild(makeImg(m[1]));
                last = m.index + m[0].length;
            }
            if (!found) return;
            frag.appendChild(document.createTextNode(text.slice(last)));
            node.parentNode.replaceChild(frag, node);
        });
    }

    window.CustomEmoji = { categories: categories, has: function (c) { return byCode.has(c); }, url: url, renderSection: renderSection, parse: parse };
})();

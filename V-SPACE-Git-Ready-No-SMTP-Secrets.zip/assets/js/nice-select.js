/* nice-select.js — выпадающие списки <select> в стиле сайта (вместо системного белого списка с синей подсветкой).
   Подключается из includes/bottom_nav.php на всех страницах. Работает на компьютере (мышь),
   на телефоне остаётся системный список — он там удобнее.
   Сам <select> остаётся в форме (скрыт): значение отправляется как обычно, onchange срабатывает.
   Не трогаем: multiple, size > 1, скрытые списки и <select data-native>. */
(function () {
    'use strict';
    if (window.__niceSelect) return;
    window.__niceSelect = true;

    var desktop = window.matchMedia('(hover: hover) and (pointer: fine)');
    var enhanced = [];
    var openBox = null;

    function optionText(o) { return (o.textContent || '').replace(/\s+/g, ' ').trim(); }

    function skip(sel) {
        if (sel.multiple || sel.size > 1 || sel.hasAttribute('data-native') || sel.__nice) return true;
        var cs = getComputedStyle(sel);
        return cs.display === 'none' || cs.visibility === 'hidden' || sel.closest('[hidden]');
    }

    function close(box) {
        if (!box) return;
        box.classList.remove('is-open');
        box.__btn.setAttribute('aria-expanded', 'false');
        if (openBox === box) openBox = null;
    }

    function syncLabel(box) {
        var sel = box.__sel, o = sel.options[sel.selectedIndex];
        box.__label.textContent = o ? optionText(o) : '';
        box.__btn.classList.toggle('ns-placeholder', !o || o.value === '');
        box.__btn.disabled = sel.disabled;
        box.__last = sel.selectedIndex;
    }

    function build(box) {
        var sel = box.__sel, list = box.__list, q = (box.__search && box.__search.value || '').toLowerCase();
        list.innerHTML = '';
        var shown = 0;
        Array.prototype.forEach.call(sel.options, function (o, i) {
            if (o.hidden) return;
            var text = optionText(o);
            if (q && text.toLowerCase().indexOf(q) === -1) return;
            var li = document.createElement('li');
            li.className = 'ns-option' + (i === sel.selectedIndex ? ' is-selected' : '') + (o.disabled ? ' is-disabled' : '');
            li.setAttribute('role', 'option');
            li.setAttribute('aria-selected', i === sel.selectedIndex ? 'true' : 'false');
            li.dataset.index = String(i);
            li.textContent = text;
            list.appendChild(li);
            shown++;
        });
        if (!shown) {
            var empty = document.createElement('li');
            empty.className = 'ns-empty';
            empty.textContent = 'Ничего не найдено';
            list.appendChild(empty);
        }
    }

    function setActive(box, li) {
        Array.prototype.forEach.call(box.__list.querySelectorAll('.ns-option.is-active'), function (x) { x.classList.remove('is-active'); });
        if (li) { li.classList.add('is-active'); li.scrollIntoView({ block: 'nearest' }); }
    }

    function choose(box, index) {
        var sel = box.__sel;
        var o = sel.options[index];
        if (!o || o.disabled) return;
        var changed = sel.selectedIndex !== index;
        sel.selectedIndex = index;
        syncLabel(box);
        close(box);
        box.__btn.focus();
        if (changed) {
            sel.dispatchEvent(new Event('input', { bubbles: true }));
            sel.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }

    function open(box) {
        if (box.__sel.disabled) return;
        if (openBox && openBox !== box) close(openBox);
        if (box.__search) box.__search.value = '';
        build(box);
        box.classList.add('is-open');
        box.__btn.setAttribute('aria-expanded', 'true');
        openBox = box;
        // если снизу мало места — открываем вверх
        var r = box.getBoundingClientRect();
        box.classList.toggle('ns-up', window.innerHeight - r.bottom < 260 && r.top > window.innerHeight - r.bottom);
        setActive(box, box.__list.querySelector('.is-selected') || box.__list.querySelector('.ns-option:not(.is-disabled)'));
        if (box.__search) box.__search.focus();
    }

    function move(box, dir) {
        var items = Array.prototype.slice.call(box.__list.querySelectorAll('.ns-option:not(.is-disabled)'));
        if (!items.length) return;
        var cur = box.__list.querySelector('.ns-option.is-active');
        var i = items.indexOf(cur);
        i = i < 0 ? 0 : Math.max(0, Math.min(items.length - 1, i + dir));
        setActive(box, items[i]);
    }

    function enhance(sel) {
        if (skip(sel)) return;
        sel.__nice = true;

        // внешний вид закрытого списка берём у самого <select> — кнопка выглядит так же, как было
        var cs = getComputedStyle(sel);
        var look = {};
        ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth',
         'borderTopStyle', 'borderRightStyle', 'borderBottomStyle', 'borderLeftStyle', 'borderTopColor', 'borderRightColor', 'borderBottomColor', 'borderLeftColor',
         'borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomLeftRadius', 'borderBottomRightRadius',
         'backgroundColor', 'color', 'fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'minHeight', 'height', 'boxShadow', 'letterSpacing'
        ].forEach(function (k) { look[k] = cs[k]; });
        var selW = sel.getBoundingClientRect().width;
        var parent = sel.parentNode, pcs = getComputedStyle(parent);
        var parentW = parent.clientWidth - parseFloat(pcs.paddingLeft || 0) - parseFloat(pcs.paddingRight || 0);
        var full = cs.display === 'block' || Math.abs(selW - parentW) < 3;
        var boxMargin = cs.margin;

        var box = document.createElement('div');
        box.className = 'ns-box';
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = (sel.className ? sel.className + ' ' : '') + 'ns-trigger';
        btn.setAttribute('aria-haspopup', 'listbox');
        btn.setAttribute('aria-expanded', 'false');
        var lbl = sel.getAttribute('aria-label');
        if (lbl) btn.setAttribute('aria-label', lbl);
        if (sel.id) {
            var forLabel = document.querySelector('label[for="' + sel.id + '"]');
            if (forLabel) forLabel.addEventListener('click', function (e) { e.preventDefault(); btn.focus(); });
        }
        var label = document.createElement('span');
        label.className = 'ns-label';
        var chev = document.createElement('span');
        chev.className = 'ns-chev';
        chev.innerHTML = '<svg viewBox="0 0 12 8" width="12" height="8" aria-hidden="true"><path d="M1 1.5l5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        btn.appendChild(label);
        btn.appendChild(chev);

        var pop = document.createElement('div');
        pop.className = 'ns-pop';
        var search = null;
        if (sel.options.length > 10) {
            search = document.createElement('input');
            search.type = 'text';
            search.className = 'ns-search';
            search.placeholder = 'Поиск…';
            search.autocomplete = 'off';
            pop.appendChild(search);
        }
        var list = document.createElement('ul');
        list.className = 'ns-list';
        list.setAttribute('role', 'listbox');
        pop.appendChild(list);

        sel.parentNode.insertBefore(box, sel);
        box.appendChild(sel);
        box.appendChild(btn);
        box.appendChild(pop);
        sel.classList.add('ns-native');
        sel.tabIndex = -1;

        Object.keys(look).forEach(function (k) { btn.style[k] = look[k]; });
        if (look.backgroundColor === 'rgba(0, 0, 0, 0)') btn.style.backgroundColor = '';
        btn.style.paddingRight = 'calc(' + look.paddingRight + ' + 18px)';
        box.style.width = full ? '100%' : (selW ? Math.round(selW) + 'px' : '');
        if (!full) box.style.display = 'inline-block';
        box.style.margin = boxMargin;

        box.__sel = sel; box.__btn = btn; box.__label = label; box.__list = list; box.__search = search;
        syncLabel(box);

        btn.addEventListener('click', function () { box.classList.contains('is-open') ? close(box) : open(box); });
        list.addEventListener('mousedown', function (e) { e.preventDefault(); });
        list.addEventListener('click', function (e) {
            var li = e.target.closest('.ns-option');
            if (li && !li.classList.contains('is-disabled')) choose(box, +li.dataset.index);
        });
        list.addEventListener('mousemove', function (e) {
            var li = e.target.closest('.ns-option');
            if (li && !li.classList.contains('is-active') && !li.classList.contains('is-disabled')) setActive(box, li);
        });
        function keys(e) {
            var isOpen = box.classList.contains('is-open');
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                if (!isOpen) open(box); else move(box, e.key === 'ArrowDown' ? 1 : -1);
            } else if (e.key === 'Enter' || (e.key === ' ' && e.target === btn)) {
                if (!isOpen) { if (e.key === ' ') { e.preventDefault(); open(box); } return; }
                e.preventDefault();
                var a = list.querySelector('.ns-option.is-active');
                if (a) choose(box, +a.dataset.index);
            } else if (e.key === 'Escape' && isOpen) {
                e.preventDefault(); close(box); btn.focus();
            } else if (e.key === 'Tab' && isOpen) {
                close(box);
            }
        }
        btn.addEventListener('keydown', keys);
        if (search) {
            search.addEventListener('keydown', keys);
            search.addEventListener('input', function () {
                build(box);
                setActive(box, list.querySelector('.ns-option:not(.is-disabled)'));
            });
        }
        sel.addEventListener('change', function () { syncLabel(box); });
        if (sel.form) sel.form.addEventListener('reset', function () { setTimeout(function () { syncLabel(box); }, 0); });
        new MutationObserver(function () { syncLabel(box); if (box.classList.contains('is-open')) build(box); })
            .observe(sel, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['disabled'] });
        enhanced.push(box);
    }

    function scan(root) {
        if (!desktop.matches) return;
        Array.prototype.forEach.call((root || document).querySelectorAll('select'), enhance);
    }

    document.addEventListener('mousedown', function (e) {
        if (openBox && !openBox.contains(e.target)) close(openBox);
    });
    window.addEventListener('resize', function () { if (openBox) close(openBox); });
    // значение могли поменять скриптом (select.value = …) — подхватываем
    setInterval(function () {
        enhanced.forEach(function (box) {
            if (box.__sel.selectedIndex !== box.__last || box.__btn.disabled !== box.__sel.disabled) syncLabel(box);
        });
    }, 500);

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { scan(); });
    else scan();
    window.addEventListener('load', function () { scan(); });
    // списки, которые появились позже (окна, вкладки)
    new MutationObserver(function (muts) {
        for (var i = 0; i < muts.length; i++) {
            for (var j = 0; j < muts[i].addedNodes.length; j++) {
                var n = muts[i].addedNodes[j];
                if (n.nodeType === 1 && (n.tagName === 'SELECT' || n.querySelector('select'))) { scan(n.tagName === 'SELECT' ? n.parentNode : n); return; }
            }
        }
    }).observe(document.documentElement, { childList: true, subtree: true });
})();

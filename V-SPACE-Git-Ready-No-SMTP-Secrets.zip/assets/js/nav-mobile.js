/* nav-mobile.js — настройки панели навигации и поведение панели на телефонах.
   1) добавляет viewport-fit=cover, чтобы работали отступы env(safe-area-inset-*);
   2) применяет пользовательские настройки панели (вид, цвет, какие пункты показывать, порядок,
      автоскрытие) — настройки сохраняются отдельно для телефона и ПК; редактор доступен на ПК.
      Если вид не выбран: на телефоне «Док», на ПК — прежний «С подписями» (labels);
   3) на телефоне прокручивает панель к активному пункту;
   4) прячет панель, пока открыта экранная клавиатура, и (по желанию) при прокрутке вниз.
   Стили — assets/css/nav-mobile.css. Для страницы настроек доступен window.NavMobile. */
(function () {
    'use strict';

    var MOBILE_KEY = 'nav_mobile_v1';
    var DESKTOP_KEY = 'nav_desktop_v1';
    var STYLES = ['dock', 'labels', 'compact'];
    var ACCENTS = { red: '#ff2a4a', blue: '#4f8cff', violet: '#9b5cff', green: '#2fd47a', gold: '#ffb020', site: '' };
    var DEFAULTS = { style: '', accent: 'site', custom: '', autohide: false, hidden: [], order: [] };
    var HEX = /^#[0-9a-f]{6}$/i;   // свой цвет подсветки (из палитры): accent = 'custom', значение в cfg.custom   // style '' = по умолчанию для устройства

    /* Иконки пунктов — SVG из папки images: <корень сайта>/images/<ключ пункта>.svg
       (ключ — data-nm, либо имя страницы без .php, у первого пункта — profile).
       Корень определяется по адресу скрипта (assets/js/nav-mobile.js → ../../images/).
       Другая папка: <script src="…nav-mobile.js" data-icons="/путь/к/иконкам/">.
       Другое имя файла для пункта: data-icon="имя" на самой ссылке .nav-item. */
    var ICON_EXT = '.svg';
    var ICON_DIR = (function () {
        var s = document.currentScript, dir = '/images/';
        try {
            if (s && s.getAttribute('data-icons')) dir = new URL(s.getAttribute('data-icons'), document.baseURI).href;
            else if (s && s.src) dir = new URL('../../images/', s.src).href;
        } catch (e) {}
        return dir.replace(/\/?$/, '/');
    })();

    var phone = window.matchMedia('(max-width: 640px)');
    var root = document.documentElement;

    function storageKey() { return phone.matches ? MOBILE_KEY : DESKTOP_KEY; }

    /* ---------- хранилище ---------- */
    function load() {
        var cfg = {}, raw = null;
        try {
            var key = storageKey();
            var stored = localStorage.getItem(key);
            if (stored === null && !phone.matches) {
                stored = localStorage.getItem(MOBILE_KEY);
                if (stored !== null) localStorage.setItem(DESKTOP_KEY, stored);
            }
            raw = JSON.parse(stored || 'null');
        } catch (e) { raw = null; }
        raw = raw && typeof raw === 'object' ? raw : {};
        cfg.style = STYLES.indexOf(raw.style) !== -1 ? raw.style : '';
        cfg.custom = typeof raw.custom === 'string' && HEX.test(raw.custom) ? raw.custom.toLowerCase() : '';
        if (raw.accent === 'custom' && cfg.custom) cfg.accent = 'custom';
        else cfg.accent = Object.prototype.hasOwnProperty.call(ACCENTS, raw.accent) ? raw.accent : DEFAULTS.accent;
        cfg.autohide = raw.autohide === true;
        cfg.hidden = Array.isArray(raw.hidden) ? raw.hidden.filter(function (k) { return typeof k === 'string'; }) : [];
        cfg.order = Array.isArray(raw.order) ? raw.order.filter(function (k) { return typeof k === 'string'; }) : [];
        return cfg;
    }
    function save(cfg) {
        try { localStorage.setItem(storageKey(), JSON.stringify(cfg)); } catch (e) { /* приватный режим — просто не сохраняем */ }
        apply(cfg);
    }
    function reset() {
        try {
            if (phone.matches) localStorage.removeItem(MOBILE_KEY);
            else localStorage.setItem(DESKTOP_KEY, JSON.stringify(DEFAULTS));
        } catch (e) {}
        apply(load());
    }

    // осветлённая пара к своему цвету (как --nm-accent-2 у готовых цветов)
    function lighten(hex) {
        var n = parseInt(hex.slice(1), 16);
        return '#' + [n >> 16 & 255, n >> 8 & 255, n & 255].map(function (v) {
            return ('0' + Math.round(v + (255 - v) * 0.35).toString(16)).slice(-2);
        }).join('');
    }
    // цвет подсветки в виде #rrggbb ('' — «как на сайте»)
    function accentHex(cfg) { return cfg.accent === 'custom' ? cfg.custom : (ACCENTS[cfg.accent] || ''); }

    // вид, который реально применяется: выбранный пользователем или умолчание для устройства
    function effectiveStyle(cfg) { return cfg.style || (phone.matches ? 'dock' : 'labels'); }

    /* ---------- пункты панели ---------- */
    function nav() { return document.getElementById('site-navigator'); }
    function itemKey(a, index) {
        if (a.getAttribute('data-nm')) return a.getAttribute('data-nm');
        if (index === 0) return 'profile';                  // первый пункт — профиль (ссылка по номеру пользователя)
        var href = (a.getAttribute('href') || '').split('?')[0].split('#')[0];
        var base = href.substring(href.lastIndexOf('/') + 1).replace(/\.php$/i, '');
        return base || ('item' + index);
    }
    // подставляет <img src="images/<ключ>.svg"> в .menu-icon, если иконки там ещё нет
    function ensureIcon(a, key) {
        var box = a.querySelector('.menu-icon');
        if (box && box.querySelector('img, svg')) return;      // иконка уже есть
        if (a.getAttribute('data-nm-icon') === 'fail') return;  // файла нет — повторно не запрашиваем
        if (!box) {
            box = document.createElement('span');
            box.className = 'menu-icon';
            a.insertBefore(box, a.querySelector('.nav-label') || a.firstChild);
        }
        var img = new Image();
        img.alt = '';
        img.draggable = false;
        img.onerror = function () {
            a.setAttribute('data-nm-icon', 'fail');
            if (img.parentNode) img.parentNode.removeChild(img);
        };
        img.src = ICON_DIR + encodeURIComponent(a.getAttribute('data-icon') || key) + ICON_EXT;
        box.appendChild(img);
    }
    function items() {
        var n = nav();
        if (!n) return [];
        var list = Array.prototype.slice.call(n.querySelectorAll('a.nav-item, .nav-item')).filter(function (item) {
            return !item.classList.contains('nav-menu-item');
        });
        var seen = [];
        return list.filter(function (a) { return seen.indexOf(a) === -1 && seen.push(a); }).map(function (a, i) {
            var k = itemKey(a, i);
            a.setAttribute('data-nm', k);
            ensureIcon(a, k);
            var label = a.querySelector('.nav-label');
            var icon = a.querySelector('.menu-icon');
            return { key: k, el: a, label: label ? label.textContent.trim() : k, icon: icon ? icon.innerHTML : '' };
        });
    }
    // порядок с учётом сохранённого: сначала по списку order, затем остальные в естественном порядке
    function ordered(cfg) {
        var list = items(), out = [];
        cfg.order.forEach(function (k) {
            list.forEach(function (it) { if (it.key === k && out.indexOf(it) === -1) out.push(it); });
        });
        list.forEach(function (it) { if (out.indexOf(it) === -1) out.push(it); });
        return out;
    }

    /* ---------- применение ---------- */
    function apply(cfg) {
        cfg = cfg || load();
        root.setAttribute('data-nm-style', effectiveStyle(cfg));
        root.setAttribute('data-nm-accent', cfg.accent);
        if (cfg.accent === 'custom') {      // inline-переменные на <html> перекрывают цвета из nav-mobile.css
            root.style.setProperty('--nm-accent', cfg.custom);
            root.style.setProperty('--nm-accent-2', lighten(cfg.custom));
        } else {
            root.style.removeProperty('--nm-accent');
            root.style.removeProperty('--nm-accent-2');
        }
        var autohide = cfg.autohide && !phone.matches;
        if (autohide) root.setAttribute('data-nm-hide', '1'); else root.removeAttribute('data-nm-hide');
        if (!autohide) document.body && document.body.classList.remove('nm-scrolled-down');

        var list = ordered(cfg);
        // хотя бы один пункт должен остаться видимым
        var visible = list.filter(function (it) { return cfg.hidden.indexOf(it.key) === -1; });
        list.forEach(function (it, i) {
            var off = cfg.hidden.indexOf(it.key) !== -1 && visible.length > 0;
            it.el.classList.toggle('nm-off', off);
            it.el.style.setProperty('--nm-order', String((i + 1) * 2));
            if (!it.el.getAttribute('title')) it.el.setAttribute('title', it.label);   // подсказка для режимов без подписей
        });

        // разделитель (между основными пунктами и «Поддержка / О проекте / …») остаётся на своём месте по счёту
        var n = nav(), div = n && n.querySelector('.nav-divider');
        if (div) {
            var kids = Array.prototype.slice.call(n.children).filter(function (c) { return c.classList.contains('nav-item') || c === div; });
            var k = kids.indexOf(div);                      // сколько пунктов было до разделителя
            div.style.setProperty('--nm-div', String(k * 2 + 1));
            var before = list.slice(0, k).filter(function (it) { return cfg.hidden.indexOf(it.key) === -1; }).length;
            var after = list.slice(k).filter(function (it) { return cfg.hidden.indexOf(it.key) === -1; }).length;
            div.classList.toggle('nm-off', before === 0 || after === 0);
        }
        revealActive();
    }

    /* ---------- viewport-fit (safe-area) ---------- */
    var meta = document.querySelector('meta[name="viewport"]');
    if (meta && !/viewport-fit/i.test(meta.content)) {
        meta.setAttribute('content', meta.content + ', viewport-fit=cover');
    }

    /* ---------- показать активный пункт ---------- */
    function revealActive() {
        var n = nav();
        if (!n || !phone.matches) return;
        var a = n.querySelector('.nav-item.active');
        if (!a || a.classList.contains('nm-off')) return;
        n.scrollLeft = Math.max(0, a.offsetLeft - (n.clientWidth - a.offsetWidth) / 2);
    }

    /* ---------- клавиатура ---------- */
    var NON_TEXT = /^(checkbox|radio|button|submit|reset|file|range|color|image)$/i;
    function isTextField(el) {
        if (!el || !el.tagName) return false;
        if (el.isContentEditable) return true;
        if (el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') return true;
        return el.tagName === 'INPUT' && !NON_TEXT.test(el.type || '');
    }
    document.addEventListener('focusin', function (e) {
        if (phone.matches && isTextField(e.target)) document.body.classList.add('nav-kb');
    });
    document.addEventListener('focusout', function () {
        setTimeout(function () {
            if (!isTextField(document.activeElement)) document.body.classList.remove('nav-kb');
        }, 60);
    });

    /* ---------- автоскрытие при прокрутке ---------- */
    var lastY = window.pageYOffset || 0, ticking = false;
    function onScroll() {
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(function () {
            ticking = false;
            if (!phone.matches || root.getAttribute('data-nm-hide') !== '1') return;
            var y = window.pageYOffset || 0, dy = y - lastY;
            var doc = document.documentElement;
            var atBottom = y + window.innerHeight >= doc.scrollHeight - 24;
            if (y < 40 || atBottom || dy < -6) document.body.classList.remove('nm-scrolled-down');
            else if (dy > 8) document.body.classList.add('nm-scrolled-down');
            lastY = y;
        });
    }
    window.addEventListener('scroll', onScroll, { passive: true });

    /* ---------- колокольчик в правом верхнем углу (телефон) ----------
       На телефоне шапка скрыта, а колокольчик живёт в #topCornerControls (position: fixed).
       Он виден только когда страница прокручена до самого верха; как только пошли вниз — прячется,
       и снова появляется лишь при возврате к самому верху. */
    var BELL_TOP = 8;                                   // px от верха, в пределах которых колокольчик ещё виден
    var bellTicking = false;
    function bellPanelOpen() {
        return !!document.querySelector('#topCornerControls .notifications-dropdown.active, #topCornerControls .notifications-dropdown.show, #topCornerControls .notifications-dropdown.open');
    }
    function updateBell() {
        bellTicking = false;
        var box = document.getElementById('topCornerControls');
        if (!box) return;
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        var atTop = y <= BELL_TOP;                      // y < 0 — «резинка» iOS у верха, тоже считаем верхом
        box.classList.toggle('nm-bell-hidden', phone.matches && !atTop && !bellPanelOpen());
    }
    function onBellScroll() {
        if (bellTicking) return;
        bellTicking = true;
        requestAnimationFrame(updateBell);
    }
    window.addEventListener('scroll', onBellScroll, { passive: true });
    window.addEventListener('load', updateBell);
    window.addEventListener('pageshow', updateBell);    // возврат на страницу кнопкой «назад»
    window.addEventListener('resize', onBellScroll);

    /* ---------- запуск ---------- */
    function init() { apply(load()); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
    window.addEventListener('load', revealActive);
    window.addEventListener('storage', function (e) { if (e.key === storageKey()) apply(load()); });   // изменили в другой вкладке
    function onPhoneChange() { apply(load()); }
    if (phone.addEventListener) phone.addEventListener('change', onPhoneChange);
    else if (phone.addListener) phone.addListener(onPhoneChange);

    window.NavMobile = {
        STYLES: STYLES, ACCENTS: ACCENTS, DEFAULTS: DEFAULTS,
        load: load, save: save, reset: reset, apply: apply, effectiveStyle: effectiveStyle, accentHex: accentHex,
        items: items, ordered: ordered
    };
})();

// Отправляет ошибки JavaScript на сервер (log_js_error.php → error.txt)
(function () {
    var sent = {};
    var count = 0;

    function report(message, source, line, stack) {
        var key = message + '|' + source + '|' + line;
        if (sent[key] || count >= 10) return;
        sent[key] = true;
        count++;
        try {
            var body = JSON.stringify({
                message: String(message || ''),
                source: String(source || ''),
                line: line || 0,
                stack: String(stack || ''),
                page: location.href
            });
            if (navigator.sendBeacon) {
                navigator.sendBeacon('log_js_error.php', new Blob([body], { type: 'application/json' }));
            } else {
                fetch('log_js_error.php', { method: 'POST', body: body, keepalive: true });
            }
        } catch (e) { /* не ломаем страницу из-за логгера */ }
    }

    window.addEventListener('error', function (e) {
        if (e.target && e.target !== window) return; // ошибки загрузки ресурсов пропускаем
        report(e.message, e.filename, e.lineno, e.error && e.error.stack);
    });

    window.addEventListener('unhandledrejection', function (e) {
        var r = e.reason;
        report('Unhandled promise rejection: ' + (r && r.message ? r.message : r), '', 0, r && r.stack);
    });
})();

const avatarButton = document.getElementById("avatarButton");
const avatarPopup = document.getElementById("avatarPopup");

avatarButton.addEventListener("click", function(event) {

    event.stopPropagation();

    avatarPopup.classList.toggle("show");

});

document.addEventListener("click", function(event) {

    if (
        !avatarPopup.contains(event.target) &&
        event.target !== avatarButton
    ) {

        avatarPopup.classList.remove("show");

    }

});
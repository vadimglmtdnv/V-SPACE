/* ==========================================================================
   Пространства: сообщения автоматически шифруются сервером при хранении;
   голосовые и видеозвонки используют WebRTC. Поддерживается legacy-шифрование.
   ========================================================================== */
(function () {
    'use strict';

    var CFG = window.SPACES_CFG || {};
    var ME = CFG.userId | 0;
    var CSRF = CFG.csrf || '';

    var enc = new TextEncoder();
    var dec = new TextDecoder();
    var $ = function (id) { return document.getElementById(id); };

    /* ---------------------------------------------------------------- тема */
    // Тема пространств всегда совпадает с темой сайта и меняется вместе с ней, без перезагрузки.
    // Основную работу делает assets/js/theme-switch.js (подключается шапкой). Если его на странице
    // нет, держим тему сами: cookie → localStorage → смена в другой вкладке/окне.
    (function themeSync() {
        function isTheme(t) { return t === 'dark' || t === 'light' || t === 'system'; }
        function stored() {
            var m = /(?:^|; )theme=(dark|light|system)/.exec(document.cookie);
            if (m) return m[1];
            try { var t = localStorage.getItem('theme'); if (isTheme(t)) return t; } catch (e) {}
            return null;
        }
        function set(t) {
            if (isTheme(t) && document.body && document.body.getAttribute('data-theme') !== t) {
                document.body.setAttribute('data-theme', t);
            }
        }
        function pull() { set(stored()); }
        function start() {
            if (window.__themeSwitchInit) return;           // общий синхронизатор уже работает
            pull();
            window.addEventListener('storage', function (e) { if (e.key === 'theme') set(e.newValue); });
            try {
                var bc = new BroadcastChannel('vspace-theme');
                bc.onmessage = function (e) { if (e && e.data) set(e.data.theme); };
            } catch (e) { /* старый браузер: хватит storage */ }
            window.addEventListener('pageshow', pull);
            window.addEventListener('focus', pull);
            document.addEventListener('visibilitychange', function () { if (!document.hidden) pull(); });
        }
        // theme-switch.js подключается с defer — к событию load он уже отработал
        if (document.readyState === 'complete') start(); else window.addEventListener('load', start);
    })();

    /* ---------------------------------------------------------------- base64url */
    function b64u(buf) {
        var bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
        var s = '';
        for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
        return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }
    function unb64u(str) {
        str = str.replace(/-/g, '+').replace(/_/g, '/');
        while (str.length % 4) str += '=';
        var bin = atob(str);
        var out = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
        return out;
    }

    /* ---------------------------------------------------------------- crypto */
    var subtleOk = !!(window.crypto && window.crypto.subtle);
    // без https crypto.subtle недоступен — используем резервный AES-GCM (aesgcm-fallback.js)
    var cryptoOk = !!(window.crypto && window.crypto.getRandomValues && (subtleOk || window.VSAesGcm));
    var keyCache = {};                        // spaceId -> ключ

    var memKeys = {};                         // запасной вариант, если localStorage недоступен (приватный режим)
    var KEY_PREFIX = 'space-key:' + ME + ':';

    function storageKey(spaceId) { return KEY_PREFIX + spaceId; }

    /* Копия ключей в IndexedDB: Safari/iOS периодически чистит localStorage, а на телефонах
       его же сбрасывают «очистители». Если один из хранилищ потерял ключ — берём из другого. */
    var IDB_NAME = 'vspace-keys', IDB_STORE = 'k';
    function idbOpen() {
        return new Promise(function (resolve, reject) {
            var r;
            try { if (!window.indexedDB) return reject(); r = indexedDB.open(IDB_NAME, 1); } catch (e) { return reject(e); }
            r.onupgradeneeded = function () { try { r.result.createObjectStore(IDB_STORE); } catch (e) {} };
            r.onsuccess = function () { resolve(r.result); };
            r.onerror = r.onblocked = function () { reject(r.error); };
        });
    }
    function idbPut(k, v) {
        return idbOpen().then(function (db) {
            return new Promise(function (resolve) {
                try {
                    var tx = db.transaction(IDB_STORE, 'readwrite');
                    tx.objectStore(IDB_STORE).put(v, k);
                    tx.oncomplete = function () { db.close(); resolve(true); };
                    tx.onerror = tx.onabort = function () { db.close(); resolve(false); };
                } catch (e) { db.close(); resolve(false); }
            });
        }).catch(function () { return false; });
    }
    function idbDel(k) {
        return idbOpen().then(function (db) {
            return new Promise(function (resolve) {
                try {
                    var tx = db.transaction(IDB_STORE, 'readwrite');
                    tx.objectStore(IDB_STORE).delete(k);
                    tx.oncomplete = tx.onerror = tx.onabort = function () { db.close(); resolve(); };
                } catch (e) { db.close(); resolve(); }
            });
        }).catch(function () {});
    }
    function idbAll() {
        return idbOpen().then(function (db) {
            return new Promise(function (resolve) {
                var out = {};
                try {
                    var tx = db.transaction(IDB_STORE, 'readonly');
                    var req = tx.objectStore(IDB_STORE).openCursor();
                    req.onsuccess = function () {
                        var c = req.result;
                        if (c) { out[c.key] = c.value; c.continue(); }
                    };
                    tx.oncomplete = function () { db.close(); resolve(out); };
                    tx.onerror = tx.onabort = function () { db.close(); resolve(out); };
                } catch (e) { db.close(); resolve(out); }
            });
        }).catch(function () { return {}; });
    }
    // при старте: достаём ключи, которые пропали из localStorage, и дублируем те, которых нет в IndexedDB
    function syncKeyStores() {
        return idbAll().then(function (saved) {
            Object.keys(saved).forEach(function (k) {
                if (k.indexOf(KEY_PREFIX) !== 0 || !/^[A-Za-z0-9_\-]{43}$/.test(saved[k])) return;
                var have = null;
                try { have = localStorage.getItem(k); } catch (e) {}
                if (!have) {
                    try { localStorage.setItem(k, saved[k]); } catch (e) { memKeys[k] = saved[k]; }
                }
            });
            try {
                for (var i = 0; i < localStorage.length; i++) {
                    var lk = localStorage.key(i);
                    if (lk && lk.indexOf(KEY_PREFIX) === 0 && !saved[lk]) idbPut(lk, localStorage.getItem(lk));
                }
            } catch (e) {}
        });
    }
    function askPersist() {
        try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}
    }

    function getRawKey(spaceId) {
        var k = storageKey(spaceId), v = null;
        try { v = localStorage.getItem(k); } catch (e) {}
        return v || memKeys[k] || null;
    }
    function setRawKey(spaceId, raw) {
        var k = storageKey(spaceId), saved = false;
        try { localStorage.setItem(k, raw); saved = localStorage.getItem(k) === raw; } catch (e) { /* приватный режим */ }
        if (!saved) memKeys[k] = raw;
        idbPut(k, raw);
        askPersist();
        delete keyCache[spaceId];
        return saved;
    }
    function removeRawKey(spaceId) {
        var k = storageKey(spaceId);
        try { localStorage.removeItem(k); } catch (e) {}
        delete memKeys[k];
        idbDel(k);
        delete keyCache[spaceId];
    }
    function newRawKey() {
        return b64u(crypto.getRandomValues(new Uint8Array(32)));
    }
    function importRaw(raw) {
        try {
            var bytes = unb64u(raw);
            if (subtleOk) return crypto.subtle.importKey('raw', bytes, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
            return Promise.resolve({ fb: window.VSAesGcm.importKey(bytes) });
        } catch (e) { return Promise.reject(e); }
    }
    function getKey(spaceId) {
        if (keyCache[spaceId]) return Promise.resolve(keyCache[spaceId]);
        var raw = getRawKey(spaceId);
        if (!raw) return Promise.resolve(null);
        return importRaw(raw)
            .then(function (k) { keyCache[spaceId] = k; return k; })
            .catch(function () { return null; });
    }
    function encryptText(key, text) {
        var iv = crypto.getRandomValues(new Uint8Array(12));
        var p;
        try {
            p = (key && key.fb)
                ? Promise.resolve(window.VSAesGcm.encrypt(key.fb, iv, enc.encode(text)))
                : crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, enc.encode(text));
        } catch (e) { return Promise.reject(e); }
        return p.then(function (ct) { return 'v1.' + b64u(iv) + '.' + b64u(ct); });
    }
    function decryptText(key, packed) {
        var parts = String(packed || '').split('.');
        if (!key || parts.length !== 3 || parts[0] !== 'v1') return Promise.resolve(null);
        var p;
        try {
            p = key.fb
                ? Promise.resolve(window.VSAesGcm.decrypt(key.fb, unb64u(parts[1]), unb64u(parts[2])))
                : crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64u(parts[1]) }, key, unb64u(parts[2]));
        } catch (e) { return Promise.resolve(null); }
        return p.then(function (pt) { return dec.decode(pt); })
            .catch(function () { return null; });
    }

    function storedText(key, value, fallback) {
        value = String(value || '');
        if (value.indexOf('v1.') !== 0) return Promise.resolve(value || fallback);
        if (!key) return Promise.resolve(fallback);
        return decryptText(key, value).then(function (text) { return text === null ? fallback : text; });
    }

    /* ---------------------------------------------------------------- API */
    function api(action, data) {
        return fetch('spaces.php?api=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
            body: JSON.stringify(data || {})
        }).then(function (r) {
            return r.json().catch(function () { return { ok: false, error: 'bad_response' }; });
        }).catch(function () { return { ok: false, error: 'network' }; });
    }

    function uploadApi(action, data) {
        return fetch('spaces.php?api=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'X-CSRF-Token': CSRF },
            body: data
        }).then(function (r) {
            return r.json().catch(function () { return { ok: false, error: 'bad_response' }; });
        }).catch(function () { return { ok: false, error: 'network' }; });
    }

    /* ---------------------------------------------------------------- UI helpers */
    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text != null) n.textContent = text;
        return n;
    }
    function letter(name) { return (name || '?').trim().charAt(0).toUpperCase() || '?'; }
    function displayName(member) { return member && (member.display_name || member.username) || ''; }
    function safeAvatar(path) {
        path = String(path || '');
        if (!path || /^[a-z]+:/i.test(path) || path.indexOf('..') !== -1 || path.charAt(0) === '/') return '';
        return path;
    }
    function avatarNode(name, path, cls) {
        var box = el('div', cls || 'sp-avatar');
        var src = safeAvatar(path);
        if (src) {
            var img = document.createElement('img');
            img.alt = '';
            img.src = src;
            img.draggable = false;
            img.onerror = function () { box.textContent = letter(name); };
            box.appendChild(img);
        } else {
            box.textContent = letter(name);
        }
        return box;
    }
    function toast(text) {
        var t = el('div', 'sp-toast', text);
        document.body.appendChild(t);
        setTimeout(function () { t.classList.add('hide'); }, 2600);
        setTimeout(function () { t.remove(); }, 3200);
    }
    function fmtTime(ts) {
        var d = new Date(ts * 1000), now = new Date();
        var hm = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
        if (d.toDateString() === now.toDateString()) return hm;
        var months = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
        return d.getDate() + ' ' + months[d.getMonth()] + ', ' + hm;
    }

    var paneHost = null;      // если задан — окна рисуются внутри экрана «Настройки сервера», а не поверх
    function modal(title, build, cls) {
        if (paneHost) {
            var pbody = el('div', 'sp-modal-body sp-set-body');
            paneHost.appendChild(pbody);
            build(pbody, function () {});
            return function () {};
        }
        var back = el('div', 'sp-modal-back');
        var box = el('div', 'sp-modal' + (cls ? ' ' + cls : ''));
        var head = el('div', 'sp-modal-head');
        head.appendChild(el('div', 'sp-modal-title', title));
        var x = el('button', 'sp-icon-btn', '✕');
        x.type = 'button';
        head.appendChild(x);
        box.appendChild(head);
        var body = el('div', 'sp-modal-body');
        box.appendChild(body);
        back.appendChild(box);
        document.body.appendChild(back);
        function close() { back.remove(); document.removeEventListener('keydown', onKey); }
        function onKey(e) { if (e.key === 'Escape') close(); }
        document.addEventListener('keydown', onKey);
        x.addEventListener('click', close);
        back.addEventListener('mousedown', function (e) { if (e.target === back) close(); });
        build(body, close);
        return close;
    }

    /* ---------------------------------------------------------------- state */
    var state = {
        spaces: [],            // [{id, name, role, members, in_call, locked}]
        current: null,         // {id, name, role, key, info, lastId, timer}
        names: {}
    };

    var elItems = $('spItems'), elEmpty = $('spEmpty'), elActive = $('spActive'), app = $('spacesApp');
    var elMsgs = $('spMessages'), elTitle = $('spTitle');

    // Низ приложения:
    //  --sp-viewport-bottom — на сколько поднять приложение (экранная клавиатура телефона);
    //  --sp-nav-space — отступ внутри приложения под нижнюю панель навигации (ПК и телефон),
    //  чтобы панель не закрывала поле ввода и кнопки, а под ней не было пустой полосы.
    function syncChatViewport() {
        if (!app) return;
        var keyboard = 0, navSpace = 0;
        var viewport = window.visualViewport;
        var phoneLike = window.innerWidth <= 900;
        if (phoneLike && viewport) keyboard = Math.max(0, Math.round(window.innerHeight - viewport.height - viewport.offsetTop));
        var nav = $('site-navigator');
        var pos = (document.body && document.body.getAttribute('data-nav-pos')) || 'bottom';
        if (nav && (pos === 'bottom' || window.innerWidth <= 640) && !keyboard) {
            var navStyle = window.getComputedStyle(nav);
            var navRect = nav.getBoundingClientRect();
            var navVisible = navStyle.display !== 'none' && navStyle.visibility !== 'hidden'
                && parseFloat(navStyle.opacity || '1') > 0.05
                && !nav.classList.contains('nav-hidden')
                && navRect.height > 0 && navRect.top < window.innerHeight && navRect.bottom > window.innerHeight - 120;
            if (navVisible) {
                var inset = Math.round(window.innerHeight - navRect.top + 10);
                if (inset > 0 && inset < window.innerHeight * 0.4) navSpace = inset;
            }
        }
        app.style.setProperty('--sp-viewport-bottom', keyboard + 'px');
        app.style.setProperty('--sp-nav-space', navSpace + 'px');
    }
    syncChatViewport();
    window.addEventListener('resize', syncChatViewport);
    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', syncChatViewport);
        window.visualViewport.addEventListener('scroll', syncChatViewport);
    }
    var siteNav = $('site-navigator');
    if (siteNav) {
        new MutationObserver(syncChatViewport).observe(siteNav, { attributes: true, attributeFilter: ['class', 'style'] });
        siteNav.addEventListener('transitionend', syncChatViewport);
    }
    setTimeout(syncChatViewport, 400);
    window.addEventListener('load', syncChatViewport);
    if (document.body) new MutationObserver(syncChatViewport).observe(document.body, { attributes: true, attributeFilter: ['class', 'data-nav-pos'] });

    /* ---------------------------------------------------------------- список пространств */
    function decryptName(id, nameEnc) {
        return getKey(id).then(function (key) {
            return storedText(key, nameEnc, 'Пространство #' + id).then(function (text) {
                return { text: text, locked: false };
            });
        });
    }

    function loadList() {
        return api('list').then(function (res) {
            if (!res.ok) { if (res.error !== 'network') toast('Не удалось загрузить список.'); return; }
            return Promise.all(res.spaces.map(function (s) {
                return decryptName(s.id, s.name_enc).then(function (n) {
                    return { id: s.id, name: n.text || ('Сервер #' + s.id), avatar_path: s.avatar_path || '', locked: n.locked, role: s.role, members: s.members, in_call: s.in_call, name_enc: s.name_enc };
                });
            })).then(function (list) {
                state.spaces = list;
                renderList();
            });
        });
    }

    function renderList() {
        elItems.textContent = '';
        if (!state.spaces.length) {
            elItems.appendChild(el('div', 'sp-list-empty', 'Пока нет пространств. Создайте своё или войдите по ссылке-приглашению.'));
            return;
        }
        state.spaces.forEach(function (s) {
            var row = el('button', 'sp-item' + (state.current && state.current.id === s.id ? ' active' : '') + (s.locked ? ' locked' : ''));
            row.type = 'button';
            var ico = el('div', 'sp-item-ico');
            var avatar = safeAvatar(s.avatar_path);
            if (avatar) {
                var image = document.createElement('img');
                image.src = avatar;
                image.alt = '';
                image.onerror = function () { ico.textContent = s.locked ? '🔒' : letter(s.name); };
                ico.appendChild(image);
            } else {
                ico.textContent = s.locked ? '🔒' : letter(s.name);
            }
            var info = el('div', 'sp-item-info');
            info.appendChild(el('div', 'sp-item-name', s.name));
            var meta = s.members + ' ' + plural(s.members, 'участник', 'участника', 'участников');
            info.appendChild(el('div', 'sp-item-meta', meta));
            row.appendChild(ico);
            row.appendChild(info);
            if (s.in_call > 0) row.appendChild(el('span', 'sp-live', 'созвон'));
            var bd = spaceBadge(s.id);
            if (spaceMuted(s.id)) row.classList.add('muted');
            if (bd.m > 0) row.appendChild(el('span', 'sp-mention-badge', bd.m > 99 ? '99+' : String(bd.m)));
            else if (bd.u && !(state.current && state.current.id === s.id)) { row.classList.add('unread'); row.appendChild(el('span', 'sp-unread-dot')); }
            row.addEventListener('click', function () { openSpace(s.id); });
            row.addEventListener('contextmenu', function (e) { e.preventDefault(); openCtx(e.clientX, e.clientY, serverListMenu(s)); });
            longPress(row, function (x, y) { openCtx(x, y, serverListMenu(s)); });
            elItems.appendChild(row);
        });
    }

    function plural(n, a, b, c) {
        var m = n % 100, d = n % 10;
        if (m >= 11 && m <= 14) return c;
        if (d === 1) return a;
        if (d >= 2 && d <= 4) return b;
        return c;
    }

    /* ---------------------------------------------------------------- создание / вход */
    var TEMPLATES = [
        { ico: '🎮', title: 'Игры',          name: 'Игровая комната' },
        { ico: '💖', title: 'Друзья',        name: 'Друзья' },
        { ico: '🍎', title: 'Учебная группа', name: 'Учебная группа' },
        { ico: '📘', title: 'Школьный клуб', name: 'Школьный клуб' }
    ];

    function openCreate() {
        modal('', function (body, close) {
            var uname = String(CFG.username || '').trim();

            function chevron() { return el('span', 'sp-tpl-arrow', '›'); }
            function tplButton(ico, title, onClick) {
                var b = el('button', 'sp-tpl');
                b.type = 'button';
                b.appendChild(el('span', 'sp-tpl-ico', ico));
                b.appendChild(el('span', 'sp-tpl-name', title));
                b.appendChild(chevron());
                b.addEventListener('click', onClick);
                return b;
            }

            // ---- шаг 1: выбор шаблона ----
            function stepTemplates() {
                body.textContent = '';
                body.appendChild(el('h2', 'sp-wiz-title', 'Создайте своё пространство'));
                body.appendChild(el('p', 'sp-wiz-sub', 'Сообщения автоматически шифруются в базе данных, а медиа звонков защищены WebRTC. Ручной ключ не нужен.'));

                var list = el('div', 'sp-tpl-list');
                list.appendChild(tplButton('🎨', 'Свой шаблон', function () {
                    stepName('', uname ? 'Пространство ' + uname : '');
                }));
                list.appendChild(el('div', 'sp-tpl-label', 'Начните с шаблона'));
                TEMPLATES.forEach(function (t) {
                    list.appendChild(tplButton(t.ico, t.title, function () { stepName(t.ico, t.name); }));
                });
                body.appendChild(list);

                var foot = el('div', 'sp-wiz-foot');
                foot.appendChild(el('div', 'sp-wiz-foot-title', 'У вас уже есть приглашение?'));
                var j = el('button', 'sp-btn sp-wiz-join', 'Присоединиться к пространству');
                j.type = 'button';
                j.addEventListener('click', function () { close(); openJoin(); });
                foot.appendChild(j);
                body.appendChild(foot);
            }

            // ---- шаг 2: название ----
            function stepName(ico, suggested) {
                body.textContent = '';
                body.appendChild(el('h2', 'sp-wiz-title', 'Назовите пространство'));
                body.appendChild(el('p', 'sp-wiz-sub', 'Сообщения и названия будут автоматически шифроваться при хранении. Участникам не нужно вводить или передавать ключ вручную.'));
                var input = el('input', 'sp-input');
                input.type = 'text';
                input.maxLength = 60;
                input.placeholder = 'Название пространства';
                input.value = suggested || '';
                body.appendChild(input);
                var row = el('div', 'sp-row');
                var back = el('button', 'sp-btn', 'Назад');
                back.type = 'button';
                var btn = el('button', 'sp-btn primary', 'Создать');
                btn.type = 'button';
                row.appendChild(back);
                row.appendChild(btn);
                body.appendChild(row);
                setTimeout(function () { input.focus(); input.select(); }, 30);

                back.addEventListener('click', stepTemplates);
                function submit() {
                    var name = input.value.trim();
                    if (!name) { input.focus(); return; }
                    btn.disabled = true;
                    api('create', { name_enc: name }).then(function (res) {
                        if (!res.ok) { btn.disabled = false; toast(res.message || 'Не удалось создать пространство.'); return; }
                        close();
                        loadList().then(function () { openSpace(res.id); });
                    }).then(function (res) {
                        if (res && res.ok === false) btn.disabled = false;
                    }).catch(function () {
                        btn.disabled = false;
                        toast('Не удалось создать пространство.');
                    });
                }
                btn.addEventListener('click', submit);
                input.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
            }

            stepTemplates();
        }, 'sp-modal-wiz');
    }

    /* Разбор ссылки/ключа. Понимает: полную ссылку-приглашение (?join=КОД#КЛЮЧ), ссылку переноса
       ключа (?restore=ID#КЛЮЧ), «голый» ключ и ссылки, которые мессенджеры испортили
       (процент-кодирование, пробелы, точка или скобка в конце). */
    function parseInvite(text) {
        text = String(text || '').replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
        if (/%[0-9a-f]{2}/i.test(text)) { try { text = decodeURIComponent(text); } catch (e) {} }
        var code = null, key = null, space = 0, m;
        if ((m = text.match(/[?&]join=([a-f0-9]{24})/i))) code = m[1].toLowerCase();
        else if ((m = text.match(/^([a-f0-9]{24})(?:#|$)/i))) code = m[1].toLowerCase();
        if ((m = text.match(/[?&]restore=(\d+)/i))) space = parseInt(m[1], 10) || 0;
        if ((m = text.match(/#\s*([A-Za-z0-9_\-]{43})(?![A-Za-z0-9_\-])/))) key = m[1];
        else if ((m = text.match(/^([A-Za-z0-9_\-]{43})$/))) key = m[1];
        return (code || key) ? { code: code, key: key, space: space } : null;
    }

    /* Приглашение, которое не должно потеряться, если страницу перезагрузили (вход, PIN-код,
       обновление): хранится недолго и стирается после использования. */
    var PENDING_KEY = 'space-pending-invite';
    function savePending(inv) {
        try { localStorage.setItem(PENDING_KEY, JSON.stringify({ t: Date.now(), inv: inv })); } catch (e) {}
    }
    function readPending() {
        try {
            var v = JSON.parse(localStorage.getItem(PENDING_KEY) || 'null');
            if (v && v.inv && Date.now() - v.t < 3600 * 1000) return v.inv;
        } catch (e) {}
        return null;
    }
    function clearPending() { try { localStorage.removeItem(PENDING_KEY); } catch (e) {} }

    // ищем среди уже доступных мне пространств то, к которому подходит ключ
    function restoreByKey(rawKey) {
        return importRaw(rawKey).then(function (k) {
            var locked = state.spaces.filter(function (x) { return x.name_enc && String(x.name_enc).indexOf('v1.') === 0; });
            return Promise.all(locked.map(function (x) {
                return decryptText(k, x.name_enc).then(function (t) { return t === null ? null : x; });
            }));
        }).then(function (r) {
            return r.filter(Boolean)[0] || null;
        }).catch(function () { return null; });
    }

    function reopenSpace(id) {
        if (state.current && state.current.id === id) { stopPolling(); state.current = null; }
        return loadList().then(function () { openSpace(id); });
    }

    function joinWith(invite, done) {
        if (invite.space && invite.key && cryptoOk && !invite.code) {
            loadList().then(function () {
                var found = state.spaces.filter(function (space) { return space.id === invite.space; })[0];
                if (!found) { toast('Это пространство недоступно в вашем аккаунте.'); return; }
                setRawKey(found.id, invite.key);
                clearPending();
                if (done) done();
                toast('Старый ключ сохранён для прежних сообщений');
                return reopenSpace(found.id);
            });
            return;
        }
        if (!invite.key || !cryptoOk) {
            if (!invite.code) { toast('Для восстановления старого ключа нужен браузер с поддержкой WebCrypto.'); return; }
            doJoin(invite, done);
            return;
        }
        loadList().then(function () {
            return restoreByKey(invite.key);
        }).then(function (found) {
            if (found) {
                // вы уже участник этого пространства — достаточно вернуть ключ на устройство
                setRawKey(found.id, invite.key);
                clearPending();
                if (done) done();
                toast('Ключ восстановлен');
                return reopenSpace(found.id);
            }
            if (!invite.code) { toast('Этот ключ не подходит ни к одному из ваших пространств.'); return; }
            doJoin(invite, done);
        });
    }

    function doJoin(invite, done) {
        api('join', { code: invite.code }).then(function (res) {
            if (!res.ok) { toast(res.message || 'Не удалось войти в пространство.'); return; }
            if (invite.key && cryptoOk) setRawKey(res.id, invite.key);
            var keyPromise = invite.key && cryptoOk ? getKey(res.id) : Promise.resolve(null);
            keyPromise.then(function (key) {
                if (String(res.name_enc || '').indexOf('v1.') === 0 && invite.key && key) {
                    return decryptText(key, res.name_enc).then(function (text) {
                        if (text === null) {
                            removeRawKey(res.id);
                            toast('Ключ из ссылки не подходит к этому пространству.');
                            loadList();
                            return null;
                        }
                        return text;
                    });
                }
                return storedText(key, res.name_enc, 'Пространство #' + res.id);
            }).then(function (name) {
                if (name === null) return;
                clearPending();
                if (done) done();
                loadList().then(function () { openSpace(res.id); });
                toast('Вы в пространстве «' + name + '»');
            });
        });
    }

    // читаем буфер обмена (на телефонах браузер сам спросит разрешение «Вставить»)
    function readClipboard() {
        if (navigator.clipboard && navigator.clipboard.readText && window.isSecureContext) {
            return navigator.clipboard.readText().catch(function () { return ''; });
        }
        return Promise.resolve('');
    }

    // общее окно «вставить ссылку или ключ»; restore=true — вариант для экрана «нет ключа»
    function openJoin(restore, spaceId) {
        var isRestore = restore === true;
        modal(isRestore ? 'Восстановить ключ' : 'Войти по ссылке', function (body, close) {
            body.appendChild(el('p', 'sp-hint', isRestore
                ? 'Вставьте ссылку-приглашение или сам ключ шифрования. Ключ можно скопировать на устройстве, где пространство уже открывается: меню сервера → «Ключ для другого устройства».'
                : 'Вставьте ссылку-приглашение. Ключ для входа и звонков не нужен; он может понадобиться только для старых сообщений, зашифрованных прежней версией.'));
            var input = el('textarea', 'sp-input sp-input-link');
            input.rows = 3;
            input.placeholder = isRestore ? 'Ссылка или ключ' : 'https://…/spaces.php?join=…';
            input.setAttribute('autocapitalize', 'off');
            input.setAttribute('autocomplete', 'off');
            input.setAttribute('autocorrect', 'off');
            input.setAttribute('spellcheck', 'false');
            input.setAttribute('inputmode', 'url');
            body.appendChild(input);
            var row = el('div', 'sp-row');
            var paste = el('button', 'sp-btn', 'Вставить из буфера');
            paste.type = 'button';
            var btn = el('button', 'sp-btn primary', isRestore ? 'Восстановить' : 'Войти');
            btn.type = 'button';
            row.appendChild(paste);
            row.appendChild(btn);
            body.appendChild(row);
            // на ПК фокусируем сразу, на телефоне — нет, иначе клавиатура закроет половину окна
            if (window.matchMedia && !window.matchMedia('(pointer: coarse)').matches) setTimeout(function () { input.focus(); }, 30);

            function submit() {
                var inv = parseInvite(input.value);
                if (!inv) { toast('Не похоже на ссылку-приглашение или ключ.'); input.focus(); return; }
                if (inv.key && spaceId && !inv.space) inv.space = spaceId;
                btn.disabled = true;
                joinWith(inv, close);
                setTimeout(function () { btn.disabled = false; }, 1500);
            }
            paste.addEventListener('click', function () {
                readClipboard().then(function (t) {
                    if (!t) { toast('Нажмите в поле и выберите «Вставить».'); input.focus(); return; }
                    input.value = t.trim();
                    if (parseInvite(t)) submit();
                });
            });
            btn.addEventListener('click', submit);
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); }
            });
            input.addEventListener('paste', function () {
                // после вставки сразу пробуем войти — на телефоне это на одно нажатие меньше
                setTimeout(function () { if (parseInvite(input.value) && parseInvite(input.value).key) submit(); }, 60);
            });
        });
    }

    /* ---------------------------------------------------------------- QR-код (без внешних библиотек)
       Режим «байты», коррекция ошибок L, версии 1–40. Нужен, чтобы перенести ключ с компьютера
       на телефон наведением камеры. */
    var QR = (function () {
        var ECC_PER_BLOCK = [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30];
        var NUM_BLOCKS = [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25];

        function rawModules(v) {
            var r = (16 * v + 128) * v + 64;
            if (v >= 2) { var n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; }
            return r;
        }
        function dataCodewords(v) { return Math.floor(rawModules(v) / 8) - ECC_PER_BLOCK[v] * NUM_BLOCKS[v]; }
        function gfMul(x, y) {
            var z = 0;
            for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; }
            return z;
        }
        function rsDivisor(d) {
            var res = [], i, j;
            for (i = 0; i < d - 1; i++) res.push(0);
            res.push(1);
            var root = 1;
            for (i = 0; i < d; i++) {
                for (j = 0; j < d; j++) {
                    res[j] = gfMul(res[j], root);
                    if (j + 1 < d) res[j] ^= res[j + 1];
                }
                root = gfMul(root, 0x02);
            }
            return res;
        }
        function rsRemainder(data, div) {
            var res = div.map(function () { return 0; });
            data.forEach(function (b) {
                var f = b ^ res.shift();
                res.push(0);
                div.forEach(function (c, i) { res[i] ^= gfMul(c, f); });
            });
            return res;
        }
        function bit(x, i) { return ((x >>> i) & 1) !== 0; }

        function encode(text) {
            var bytes = Array.prototype.slice.call(new TextEncoder().encode(text));
            var ver, i;
            for (ver = 1; ver <= 40; ver++) {
                var need = 4 + (ver < 10 ? 8 : 16) + bytes.length * 8;
                if (need <= dataCodewords(ver) * 8) break;
            }
            if (ver > 40) return null;

            // поток битов данных
            var bits = [];
            function put(val, len) { for (var k = len - 1; k >= 0; k--) bits.push((val >>> k) & 1); }
            put(4, 4);
            put(bytes.length, ver < 10 ? 8 : 16);
            bytes.forEach(function (b) { put(b, 8); });
            var cap = dataCodewords(ver) * 8;
            put(0, Math.min(4, cap - bits.length));
            while (bits.length % 8) bits.push(0);
            var data = [];
            for (i = 0; i < bits.length; i += 8) {
                var by = 0;
                for (var q = 0; q < 8; q++) by = (by << 1) | bits[i + q];
                data.push(by);
            }
            for (var pad = 0xEC; data.length < dataCodewords(ver); pad ^= 0xEC ^ 0x11) data.push(pad);

            // блоки + коды Рида — Соломона
            var nb = NUM_BLOCKS[ver], el_ = ECC_PER_BLOCK[ver];
            var raw = Math.floor(rawModules(ver) / 8);
            var nShort = nb - raw % nb, shortLen = Math.floor(raw / nb);
            var blocks = [], div = rsDivisor(el_), k = 0;
            for (i = 0; i < nb; i++) {
                var dl = shortLen - el_ + (i < nShort ? 0 : 1);
                var dat = data.slice(k, k + dl); k += dl;
                var ecc = rsRemainder(dat, div);
                if (i < nShort) dat.push(0);
                blocks.push(dat.concat(ecc));
            }
            var all = [];
            for (i = 0; i < blocks[0].length; i++) {
                for (var j = 0; j < blocks.length; j++) {
                    if (i !== shortLen - el_ || j >= nShort) all.push(blocks[j][i]);
                }
            }

            // матрица
            var size = ver * 4 + 17;
            var mod = [], fn = [];
            for (i = 0; i < size; i++) { mod.push(new Array(size).fill(false)); fn.push(new Array(size).fill(false)); }
            function setFn(x, y, dark) { mod[y][x] = dark; fn[y][x] = true; }
            for (i = 0; i < size; i++) { setFn(6, i, i % 2 === 0); setFn(i, 6, i % 2 === 0); }
            function finder(cx, cy) {
                for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
                    var d = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy;
                    if (xx >= 0 && xx < size && yy >= 0 && yy < size) setFn(xx, yy, d !== 2 && d !== 4);
                }
            }
            finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
            var pos = [];
            if (ver > 1) {
                var na = Math.floor(ver / 7) + 2;
                var step = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (na * 2 - 2)) * 2;
                pos = [6];
                for (var p = size - 7; pos.length < na; p -= step) pos.splice(1, 0, p);
            }
            for (i = 0; i < pos.length; i++) for (j = 0; j < pos.length; j++) {
                if ((i === 0 && j === 0) || (i === 0 && j === pos.length - 1) || (i === pos.length - 1 && j === 0)) continue;
                for (var ay = -2; ay <= 2; ay++) for (var ax = -2; ax <= 2; ax++) setFn(pos[i] + ax, pos[j] + ay, Math.max(Math.abs(ax), Math.abs(ay)) !== 1);
            }
            function formatBits(mask) {
                var d = (1 << 3) | mask;                         // уровень L = 01
                var r = d;
                for (var n = 0; n < 10; n++) r = (r << 1) ^ ((r >>> 9) * 0x537);
                return ((d << 10) | r) ^ 0x5412;
            }
            function drawFormat(mask) {
                var b = formatBits(mask), n;
                for (n = 0; n <= 5; n++) setFn(8, n, bit(b, n));
                setFn(8, 7, bit(b, 6)); setFn(8, 8, bit(b, 7)); setFn(7, 8, bit(b, 8));
                for (n = 9; n < 15; n++) setFn(14 - n, 8, bit(b, n));
                for (n = 0; n < 8; n++) setFn(size - 1 - n, 8, bit(b, n));
                for (n = 8; n < 15; n++) setFn(8, size - 15 + n, bit(b, n));
                setFn(8, size - 8, true);
            }
            drawFormat(0);
            if (ver >= 7) {
                var rr = ver;
                for (i = 0; i < 12; i++) rr = (rr << 1) ^ ((rr >>> 11) * 0x1F25);
                var vb = (ver << 12) | rr;
                for (i = 0; i < 18; i++) {
                    var c = bit(vb, i), a = size - 11 + i % 3, b2 = Math.floor(i / 3);
                    setFn(a, b2, c); setFn(b2, a, c);
                }
            }
            // данные зигзагом
            var idx = 0;
            for (var right = size - 1; right >= 1; right -= 2) {
                if (right === 6) right = 5;
                for (var vert = 0; vert < size; vert++) {
                    for (j = 0; j < 2; j++) {
                        var x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - vert : vert;
                        if (!fn[y][x] && idx < all.length * 8) { mod[y][x] = bit(all[idx >>> 3], 7 - (idx & 7)); idx++; }
                    }
                }
            }
            // выбор маски по штрафам
            function applyMask(m) {
                for (var y2 = 0; y2 < size; y2++) for (var x2 = 0; x2 < size; x2++) {
                    var inv;
                    switch (m) {
                        case 0: inv = (x2 + y2) % 2 === 0; break;
                        case 1: inv = y2 % 2 === 0; break;
                        case 2: inv = x2 % 3 === 0; break;
                        case 3: inv = (x2 + y2) % 3 === 0; break;
                        case 4: inv = (Math.floor(x2 / 3) + Math.floor(y2 / 2)) % 2 === 0; break;
                        case 5: inv = x2 * y2 % 2 + x2 * y2 % 3 === 0; break;
                        case 6: inv = (x2 * y2 % 2 + x2 * y2 % 3) % 2 === 0; break;
                        default: inv = ((x2 + y2) % 2 + x2 * y2 % 3) % 2 === 0;
                    }
                    if (!fn[y2][x2] && inv) mod[y2][x2] = !mod[y2][x2];
                }
            }
            function penalty() {
                var pen = 0, dark = 0, x2, y2, run, prev;
                for (y2 = 0; y2 < size; y2++) {
                    run = 0; prev = null;
                    for (x2 = 0; x2 < size; x2++) {
                        var v = mod[y2][x2];
                        if (v) dark++;
                        if (v === prev) { run++; if (run === 5) pen += 3; else if (run > 5) pen++; } else { run = 1; prev = v; }
                    }
                }
                for (x2 = 0; x2 < size; x2++) {
                    run = 0; prev = null;
                    for (y2 = 0; y2 < size; y2++) {
                        var w = mod[y2][x2];
                        if (w === prev) { run++; if (run === 5) pen += 3; else if (run > 5) pen++; } else { run = 1; prev = w; }
                    }
                }
                for (y2 = 0; y2 < size - 1; y2++) for (x2 = 0; x2 < size - 1; x2++) {
                    var c0 = mod[y2][x2];
                    if (c0 === mod[y2][x2 + 1] && c0 === mod[y2 + 1][x2] && c0 === mod[y2 + 1][x2 + 1]) pen += 3;
                }
                var total = size * size;
                pen += (Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1) * 10;
                return pen;
            }
            var best = 0, bestPen = Infinity;
            for (var m = 0; m < 8; m++) {
                applyMask(m);
                drawFormat(m);
                var pn = penalty();
                if (pn < bestPen) { bestPen = pn; best = m; }
                applyMask(m);                                    // снимаем маску (XOR обратим)
            }
            applyMask(best);
            drawFormat(best);
            return { size: size, modules: mod };
        }

        // SVG на белом фоне с «тихой зоной» в 4 модуля — иначе камера телефона не распознает код
        function toSvg(text) {
            var qr = encode(text);
            if (!qr) return '';
            var n = qr.size, q = 4, d = '';
            for (var y = 0; y < n; y++) {
                var x = 0;
                while (x < n) {
                    if (qr.modules[y][x]) {
                        var s = x;
                        while (x < n && qr.modules[y][x]) x++;
                        d += 'M' + (s + q) + ' ' + (y + q) + 'h' + (x - s) + 'v1h-' + (x - s) + 'z';
                    } else x++;
                }
            }
            var full = n + q * 2;
            return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + full + ' ' + full + '" shape-rendering="crispEdges" role="img" aria-label="QR-код">' +
                '<rect width="' + full + '" height="' + full + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
        }
        return { encode: encode, toSvg: toSvg };
    })();

    // перенос ключа на другое устройство (телефон ⇄ компьютер)
    function openTransferKey() {
        var cur = state.current;
        if (!cur || !cur.key) return;
        var raw = getRawKey(cur.id);
        if (!raw) { toast('Ключ шифрования не найден.'); return; }
        var link = location.origin + location.pathname + '?restore=' + cur.id + '#' + raw;
        modal('Ключ для другого устройства', function (body) {
            body.appendChild(el('p', 'sp-hint', 'Это старый ключ пространства: он может понадобиться для расшифровки сообщений, созданных прежней версией. Передавайте его только на свои устройства.'));
            try {
                var svg = QR.toSvg(link);
                if (svg) {
                    var qrBox = el('div', 'sp-qr');
                    qrBox.innerHTML = svg;                       // svg собран нашим кодом из чисел, пользовательского текста в нём нет
                    body.appendChild(qrBox);
                }
            } catch (e) { /* без QR остаётся ссылка */ }
            var box = el('input', 'sp-input');
            box.type = 'text';
            box.readOnly = true;
            box.value = link;
            box.addEventListener('focus', function () { box.select(); });
            body.appendChild(box);
            var cp = el('button', 'sp-btn primary', 'Скопировать ссылку');
            cp.type = 'button';
            cp.addEventListener('click', function () { copyText(link, 'Ссылка скопирована'); });
            body.appendChild(cp);
            if (navigator.share) {
                var sh = el('button', 'sp-btn', 'Отправить…');
                sh.type = 'button';
                sh.addEventListener('click', function () {
                    navigator.share({ title: 'Ключ пространства', url: link }).catch(function () {});
                });
                body.appendChild(sh);
            }
            var ck = el('button', 'sp-btn', 'Скопировать только ключ');
            ck.type = 'button';
            ck.addEventListener('click', function () { copyText(raw, 'Ключ скопирован — храните его как пароль'); });
            body.appendChild(ck);
        });
    }

    function handleUrlInvite() {
        var inv = parseInvite(location.search + location.hash);
        if (inv) {
            savePending(inv);                                 // переживёт перезагрузку страницы
            try { history.replaceState(null, '', location.pathname); } catch (e) {}
        } else {
            inv = readPending();
            if (inv) clearPending();                          // показываем один раз, а не при каждой загрузке
        }
        if (!inv) return;
        var restoreOnly = !inv.code;
        modal(restoreOnly ? 'Ключ шифрования' : 'Приглашение в пространство', function (body, close) {
            body.appendChild(el('p', 'sp-hint', restoreOnly
                ? 'Сохранить старый ключ для расшифровки прежних сообщений на этом устройстве?'
                : 'Для входа и звонков ключ не нужен. Старый ключ из ссылки используется только для расшифровки сообщений, созданных прежней версией.'));
            var row = el('div', 'sp-row');
            var yes = el('button', 'sp-btn primary', restoreOnly ? 'Сохранить ключ' : 'Присоединиться');
            var no = el('button', 'sp-btn', 'Отмена');
            yes.type = no.type = 'button';
            row.appendChild(yes); row.appendChild(no);
            body.appendChild(row);
            yes.addEventListener('click', function () { joinWith(inv, close); });
            no.addEventListener('click', function () { clearPending(); close(); });
        });
    }

    /* ---------------------------------------------------------------- открытие пространства */
    function openSpace(id) {
        if (state.current && state.current.id === id) { showView(true); return; }
        if (call.active) leaveCall();
        stopPolling();
        closeCtx();

        var s = state.spaces.filter(function (x) { return x.id === id; })[0];
        var cur = state.current = {
            id: id, name: s && s.name ? s.name : ('Сервер #' + id), avatar_path: s ? (s.avatar_path || '') : '', role: s ? s.role : 'member', key: null, info: null, lastId: 0, rendered: {},
            perms: 0, defaultPerms: 0, channels: [], channelCounts: { text: 0, voice: 0 }, categoryCount: 0, categories: [], roles: [], cn: {}, gn: {}, rn: {},
            chan: null, voice: {}, voiceSig: '', collapsed: {},
            muted: lsGet('space-muted:' + ME + ':' + id, []), hideMuted: !!lsGet('space-hidemuted:' + ME + ':' + id, false)
        };
        polling = false;
        renderList();
        elEmpty.hidden = true;
        elActive.hidden = false;
        elActive.classList.remove('chan-open');
        elMsgs.textContent = '';
        elTitle.textContent = cur.name;
        renderServerHead();
        setMemberPanel(false);
        $('spMemberList').textContent = '';
        $('spChList').textContent = '';
        $('spChanBar').textContent = '';
        showView(true);

        Promise.all([getKey(id), api('info', { space_id: id })]).then(function (r) {
            if (state.current !== cur) return;
            var key = r[0], info = r[1];
            if (!info.ok) { toast('Не удалось открыть пространство.'); closeSpaceView(); return; }
            cur.key = key;
            cur.info = info;
            cur.avatar_path = info.avatar_path || cur.avatar_path;
            cur.role = info.role;
            return storedText(key, info.name_enc, 'Пространство #' + id).then(function (name) {
                if (state.current !== cur) return;
                cur.name = name || ('Сервер #' + id);
                elTitle.textContent = cur.name;
                return applyStructure(cur, info);
            }).then(function () {
                if (state.current !== cur) return;
                return ensureDefaults(cur);
            }).then(function (created) {
                if (state.current !== cur) return;
                if (!created) return;
                return api('info', { space_id: id }).then(function (i2) {
                    if (state.current !== cur || !i2.ok) return;
                    cur.info = i2;
                    return applyStructure(cur, i2);
                });
            }).then(function () {
                if (state.current !== cur) return;
                validateChan(cur);
                renderHead();
                renderLockBanner();
                renderChannels();
                renderChanBar();
                startPolling();
                if (pendingResume && pendingResume.s === id) {
                    var rs = pendingResume; pendingResume = null;
                    var chOk = (rs.c === 0 && cur.channelCounts.voice === 0) || voiceChannels(cur).some(function (v) { return v.id === rs.c; });
                    if (chOk && canChannelAction(cur, rs.c, 'voice', CHANNEL_PERMISSION.CONNECT)) startCall(rs.v, rs.c);
                    else clearResume();
                }
            });
        });
    }

    function closeSpaceView() {
        cancelEdit(); closeMentionPop();
        closeSettings();
        if (call.active) leaveCall();
        stopPolling();
        closeCtx();
        state.current = null;
        syncReplyBar();
        elActive.hidden = true;
        elEmpty.hidden = false;
        showView(false);
        renderList();
    }

    function showView(on) { app.classList.toggle('view-open', !!on); }

    function setMemberPanel(show) {
        var panel = $('spMemberPanel');
        var toggle = $('spMemberToggle');
        if (panel._hideTimer) {
            clearTimeout(panel._hideTimer);
            panel._hideTimer = null;
        }
        if (panel._openFrame) {
            cancelAnimationFrame(panel._openFrame);
            panel._openFrame = null;
        }
        if (show) {
            panel.hidden = false;
            panel._openFrame = requestAnimationFrame(function () {
                panel._openFrame = null;
                if (toggle.getAttribute('aria-expanded') === 'true') panel.classList.add('is-open');
            });
        } else {
            panel.classList.remove('is-open');
            if (window.innerWidth <= 900) {
                panel._hideTimer = setTimeout(function () {
                    panel.hidden = true;
                    panel._hideTimer = null;
                }, 240);
            } else {
                panel.hidden = true;
            }
        }
        toggle.setAttribute('aria-expanded', show ? 'true' : 'false');
        toggle.textContent = show ? 'Скрыть участников' : 'Показать участников';
    }

    function renderMemberPanel() {
        var cur = state.current;
        var list = $('spMemberList');
        var head = $('spMemberPanelHead');
        if (!cur || !cur.info || !list || !head) return;
        head.textContent = 'Участники (' + cur.info.members.length + ')';
        list.textContent = '';
        cur.info.members.forEach(function (m) {
            var row = el('div', 'sp-member-panel-row');
            row.appendChild(avatarNode(displayName(m), m.avatar, 'sp-avatar sm'));
            var details = el('div', 'sp-member-panel-details');
            var nameEl = el('div', 'sp-member-name', displayName(m));
            if (m.role === 'owner' || m.role_id > 0) { var rc = roleOf(cur, m).color; if (rc) nameEl.style.color = rc; }
            details.appendChild(nameEl);
            var presence = m.id === ME ? myStatus : (m.presence || 'offline');
            details.appendChild(el('div', 'sp-pres sp-pres-' + presence, STATUS_LABELS[presence] || STATUS_LABELS.offline));
            row.appendChild(details);
            bindMemberRow(row, m);
            list.appendChild(row);
        });
    }

    function renderHead() {
        var cur = state.current, info = cur.info;
        if (!info) return;
        elActive.dataset.canManageChannels = can(P.CHANNELS) ? 'true' : 'false';
        renderMemberPanel();
        $('spInviteBtn').hidden = !can(P.INVITE) || !info.invite_code;
        renderServerHead();
        $('spRolesBtn').hidden = !can(P.ROLES);
        $('spDeleteBtn').hidden = info.role !== 'owner';
        $('spLeaveBtn').hidden = info.role === 'owner';
        var canSend = !!(cur.chan && canChannelAction(cur, cur.chan.id, 'text', CHANNEL_PERMISSION.SEND));
        $('spComposer').hidden = !canSend;
        $('spNoSend').hidden = canSend;
        $('spNoSend').textContent = cur.chan ? 'У вас нет права писать сообщения в этом канале.' : 'Нет доступных текстовых каналов.';
    }

    function renderLockBanner() {
        var cur = state.current;
        var box = $('spLock');
        box.hidden = true;
        box.textContent = '';
    }

    /* ---------------------------------------------------------------- сообщения */
    var pollTimer = null, polling = false;

    function startPolling() {
        stopPolling();
        pollTimer = setInterval(function () { if (!document.hidden) fetchMessages(false); }, 2500);
    }
    function stopPolling() { if (pollTimer) clearInterval(pollTimer); pollTimer = null; }

    /* fetchMessages / appendMessage — см. блок «Как в Discord» ниже */

    var composer = $('spComposer'), input = $('spInput'), sendBtn = $('spSend');
    var sending = false;

    function sendMessage() {
        var cur = state.current;
        if (!cur || !cur.chan || sending) return;
        if (!canChannelAction(cur, cur.chan.id, 'text', CHANNEL_PERMISSION.SEND)) { toast('У вас нет права писать сообщения в этом канале.'); return; }
        var text = input.value.trim();
        if (!text) return;
        if (text.length > 4000) { toast('Сообщение слишком длинное (до 4000 символов).'); return; }
        sending = true;
        sendBtn.disabled = true;
        var replyId = cur.reply && cur.reply.ch === cur.chan.id ? cur.reply.id : 0;
        api('send', { space_id: cur.id, channel_id: cur.chan.id, body: text, reply_to: replyId }).then(function (res) {
            sending = false;
            sendBtn.disabled = false;
            if (!res.ok) { toast(res.message || 'Не удалось отправить.'); return; }
            cur.reply = null; syncReplyBar(); closeMentionPop();
            notif.hold = null;
            input.value = '';
            autoGrow();
            fetchMessages(false);
            input.focus();
        }).catch(function () {
            sending = false;
            sendBtn.disabled = false;
            toast('Не удалось отправить сообщение.');
        });
    }
    function autoGrow() {
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 140) + 'px';
    }
    composer.addEventListener('submit', function (e) { e.preventDefault(); sendMessage(); });
    input.addEventListener('input', autoGrow);
    input.addEventListener('keydown', function (e) {
        if (composerKeydown(e)) return;
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    });

    /* ---------------------------------------------------------------- кнопки шапки пространства */
    $('spBack').addEventListener('click', closeSpaceView);
    $('spCreateBtn').addEventListener('click', openCreate);
    $('spJoinBtn').addEventListener('click', function () { openJoin(false); });

    $('spInviteBtn').addEventListener('click', function () {
        var cur = state.current;
        if (!cur || !cur.info || !cur.info.invite_code) return;
        var raw = cur.key ? getRawKey(cur.id) : null;
        var link = location.origin + location.pathname + '?join=' + cur.info.invite_code + (raw ? '#' + raw : '');
        modal('Пригласить в пространство', function (body) {
            body.appendChild(el('p', 'sp-hint', 'Передавайте ссылку только тем, кого хотите пригласить: любой с ней сможет читать переписку.'));
            var box = el('input', 'sp-input');
            box.type = 'text';
            box.readOnly = true;
            box.value = link;
            body.appendChild(box);
            var btn = el('button', 'sp-btn primary', 'Скопировать ссылку');
            btn.type = 'button';
            body.appendChild(btn);
            box.addEventListener('focus', function () { box.select(); });
            btn.addEventListener('click', function () {
                box.select();
                var ok = false;
                try { ok = document.execCommand('copy'); } catch (e) {}
                if (navigator.clipboard && window.isSecureContext) {
                    navigator.clipboard.writeText(link).then(function () { toast('Ссылка скопирована'); }, function () { toast(ok ? 'Ссылка скопирована' : 'Скопируйте ссылку вручную'); });
                } else toast(ok ? 'Ссылка скопирована' : 'Скопируйте ссылку вручную');
            });
        });
    });

    $('spMemberToggle').addEventListener('click', function () {
        var show = $('spMemberPanel').hidden;
        setMemberPanel(show);
        if (show) reloadInfo();
    });
    (function enableMobilePanelSwipes() {
        var start = null;
        elActive.addEventListener('touchstart', function (e) {
            start = null;
            if (window.innerWidth > 900) return;
            if (e.touches.length !== 1) return;
            var target = e.target;
            if (target.closest && target.closest('button, input, textarea, select, a, [contenteditable="true"]')) return;
            var panel = target.closest ? target.closest('#spChannels, #spMemberPanel, .sp-main') : null;
            if (!panel) return;
            var touch = e.touches[0];
            start = { x: touch.clientX, y: touch.clientY, panel: panel };
        }, { passive: true });
        elActive.addEventListener('touchend', function (e) {
            if (window.innerWidth > 900 || !start || e.changedTouches.length !== 1) return;
            var touch = e.changedTouches[0];
            var dx = touch.clientX - start.x;
            var dy = touch.clientY - start.y;
            var horizontal = Math.abs(dx) >= 60 && Math.abs(dx) > Math.abs(dy) * 1.3;
            var startedOn = start.panel;
            start = null;
            if (!horizontal) return;

            if (startedOn.id === 'spChannels') {
                if (dx < 0) elActive.classList.remove('chan-open');
                return;
            }
            if (startedOn.id === 'spMemberPanel') {
                if (dx > 0) setMemberPanel(false);
                return;
            }
            if (startedOn.classList.contains('sp-main')) {
                if (!elActive.classList.contains('chan-open') && $('spMemberPanel').hidden) {
                    if (dx > 0) elActive.classList.add('chan-open');
                    else {
                        setMemberPanel(true);
                        reloadInfo();
                    }
                }
            }
        }, { passive: true });
        elActive.addEventListener('touchcancel', function () { start = null; }, { passive: true });
    })();
    $('spRolesBtn').addEventListener('click', openRoles);
    $('spBotsBtn').addEventListener('click', openBots);

    $('spLeaveBtn').addEventListener('click', function () {
        var cur = state.current;
        if (!cur || !confirm('Выйти из пространства «' + cur.name + '»? Сохранённый старый ключ на этом устройстве будет удалён.')) return;
        api('leave', { space_id: cur.id }).then(function (res) {
            if (!res.ok) { toast(res.message || 'Не удалось выйти.'); return; }
            try { localStorage.removeItem(storageKey(cur.id)); } catch (e) {}
            closeSpaceView(); loadList();
        });
    });
    $('spDeleteBtn').addEventListener('click', function () {
        var cur = state.current;
        if (!cur || !confirm('Удалить пространство «' + cur.name + '» вместе со всеми сообщениями? Это нельзя отменить.')) return;
        api('delete', { space_id: cur.id }).then(function (res) {
            if (!res.ok) { toast('Не удалось удалить.'); return; }
            try { localStorage.removeItem(storageKey(cur.id)); } catch (e) {}
            closeSpaceView(); loadList();
        });
    });

    /* ================================================================ КАНАЛЫ, КАТЕГОРИИ, РОЛИ И ПРАВА */
    var P = { SEND: 1, VOICE: 2, CHANNELS: 4, INVITE: 8, ROLES: 16, KICK: 32 };
    var CHANNEL_PERMISSION = { VIEW: 1, SEND: 2, CONNECT: 4, SPEAK: 8 };
    var PERM_LIST = [
        { bit: P.SEND,     title: 'Писать сообщения',            desc: 'Отправлять сообщения в текстовых каналах' },
        { bit: P.VOICE,    title: 'Заходить в голосовые каналы', desc: 'Участвовать в голосовых и видеосозвонах' },
        { bit: P.CHANNELS, title: 'Управлять каналами',          desc: 'Создавать, переименовывать и удалять каналы и категории' },
        { bit: P.INVITE,   title: 'Приглашать участников',       desc: 'Видеть ссылку-приглашение и делиться ей' },
        { bit: P.KICK,     title: 'Удалять участников',          desc: 'Исключать участников из пространства' },
        { bit: P.ROLES,    title: 'Управлять ролями',            desc: 'Создавать роли и назначать их. Выдать это право может только владелец' }
    ];
    var DEFAULT_ROLE_NAME = 'Участник';

    function rname(cur, id) { return cur.rn[id] != null ? cur.rn[id] : '…'; }
    function can(bit) { var c = state.current; return !!(c && (c.perms & bit)); }
    function channelAccess(cur, channelId, type) {
        var channel = cur.channels.filter(function (item) { return item.id === channelId; })[0];
        if (channel && typeof channel.access === 'number') return channel.access;
        var access = CHANNEL_PERMISSION.VIEW;
        if (type === 'text' && (cur.perms & P.SEND)) access |= CHANNEL_PERMISSION.SEND;
        if (type === 'voice' && (cur.perms & P.VOICE)) access |= CHANNEL_PERMISSION.CONNECT | CHANNEL_PERMISSION.SPEAK;
        return access;
    }
    function canChannelAction(cur, channelId, type, permission) {
        return !!(channelAccess(cur, channelId, type) & permission);
    }

    function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
    function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

    /* ---------- контекстное меню ---------- */
    var ctxEl = null, ctxAnchor = null, ctxSubs = [], ctxAt = 0, ctxX = 0, ctxY = 0;
    function closeSubs(from) { while (ctxSubs.length > (from || 0)) ctxSubs.pop().remove(); }
    function closeCtx() {
        closeSubs(0);
        if (ctxEl) { ctxEl.remove(); ctxEl = null; }
        if (ctxAnchor) { ctxAnchor.classList.remove('open'); ctxAnchor.setAttribute('aria-expanded', 'false'); ctxAnchor = null; }
        document.removeEventListener('mousedown', ctxOutside, true);
        document.removeEventListener('keydown', ctxKey, true);
        window.removeEventListener('resize', closeCtx);
    }
    function ctxOutside(e) {
        if (!ctxEl || ctxEl.contains(e.target)) return;
        for (var i = 0; i < ctxSubs.length; i++) if (ctxSubs[i].contains(e.target)) return;
        closeCtx();
    }
    function ctxKey(e) {
        if (e.key === 'Escape') { closeCtx(); return; }
        if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && ctxEl) {
            var root = ctxSubs.length ? ctxSubs[ctxSubs.length - 1] : ctxEl;
            var list = Array.prototype.filter.call(root.querySelectorAll('.sp-ctx-item'), function (b) { return !b.disabled; });
            if (!list.length) return;
            e.preventDefault();
            var i = list.indexOf(document.activeElement);
            i = e.key === 'ArrowDown' ? (i + 1) % list.length : (i <= 0 ? list.length - 1 : i - 1);
            list[i].focus();
        }
    }
    // Значки меню: собственные SVG (линия 1.8, currentColor), подстраиваются под тему
    function ico(paths) {
        return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths + '</svg>';
    }
    var ICONS = {
        invite:   ico('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M19 7.5v6M16 10.5h6"/>'),
        members:  ico('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.4c2.2.7 3.5 2.6 3.5 5.6"/>'),
        roles:    ico('<path d="M12 3l7 3v5.5c0 4.2-2.9 7.6-7 9.5-4.1-1.9-7-5.3-7-9.5V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>'),
        bots:     ico('<rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 8V4.5M9.5 4.5h5"/><circle cx="9" cy="13.5" r="1.2"/><circle cx="15" cy="13.5" r="1.2"/><path d="M2.5 13v2M21.5 13v2"/>'),
        channel:  ico('<path d="M8.5 4l-1.6 12M15.5 4l-1.6 12M4 8.5h11M3.3 13h11"/><path d="M19 15v6M16 18h6"/>'),
        category: ico('<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2.5h6.5A2.5 2.5 0 0 1 21 10v7.5a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/><path d="M12 11v5M9.5 13.5h5"/>'),
        settings: ico('<path d="M4 7h9M17 7h3M4 12h3M11 12h9M4 17h11M19 17h1"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="17" r="2"/>'),
        close:    ico('<path d="M6 6l12 12M18 6L6 18"/>'),
        back:     ico('<path d="M15 5l-7 7 7 7"/>'),
        external: ico('<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v3.5A2.5 2.5 0 0 1 15.5 20h-9A2.5 2.5 0 0 1 4 17.5v-9A2.5 2.5 0 0 1 6.5 6H10"/>'),
        eyeOff:   ico('<path d="M3 12s3.5-6.5 9-6.5S21 12 21 12s-3.5 6.5-9 6.5S3 12 3 12z"/><circle cx="12" cy="12" r="2.8"/><path d="M4 4l16 16"/>'),
        copy:     ico('<rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2.5"/><path d="M15.5 8.5V6A2.5 2.5 0 0 0 13 3.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5"/>'),
        leave:    ico('<path d="M10 4H6.5A2.5 2.5 0 0 0 4 6.5v11A2.5 2.5 0 0 0 6.5 20H10"/><path d="M15 8l4 4-4 4M19 12H9"/>'),
        trash:    ico('<path d="M4 7h16M9.5 7V4.5h5V7M6.5 7l.8 12.2a1.5 1.5 0 0 0 1.5 1.3h6.4a1.5 1.5 0 0 0 1.5-1.3L17.5 7"/><path d="M10 11v6M14 11v6"/>'),
        chevron:  '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>'
    };

    function cleanItems(items) {
        var visible = items.filter(function (it) { return it && !it.hidden; });
        // убираем разделители в начале, в конце и подряд
        visible = visible.filter(function (it, i, a) {
            if (!it.divider) return true;
            return i > 0 && i < a.length - 1 && !a[i - 1].divider;
        });
        while (visible.length && visible[visible.length - 1].divider) visible.pop();
        return visible;
    }
    function fillMenu(m, visible, depth) {
        m.addEventListener('mouseover', function (e) {
            var t = e.target.closest ? e.target.closest('.sp-ctx-item') : null;
            if (t && t.parentNode === m && !t.classList.contains('has-sub')) closeSubs(depth);
        });
        visible.forEach(function (it) {
            if (it.divider) { m.appendChild(el('div', 'sp-ctx-div')); return; }
            if (typeof it.custom === 'function') { m.appendChild(it.custom()); return; }
            if (it.header) { m.appendChild(el('div', 'sp-ctx-head', it.header)); return; }
            var b = el('button', 'sp-ctx-item' + (it.danger ? ' danger' : '') + (it.icon ? ' has-ico' : '') + (it.sub ? ' has-sub' : ''));
            b.type = 'button';
            b.setAttribute('role', it.radio !== undefined ? 'menuitemradio' : (typeof it.checked === 'boolean' ? 'menuitemcheckbox' : 'menuitem'));
            if (it.radio !== undefined || typeof it.checked === 'boolean') b.setAttribute('aria-checked', (it.radio || it.checked) ? 'true' : 'false');
            if (it.disabled) b.disabled = true;
            if (it.icon) {
                var ic = el('span', 'sp-ctx-ico');
                ic.innerHTML = it.icon;      // только наши константы ICONS
                b.appendChild(ic);
            }
            b.appendChild(el('span', 'sp-ctx-label', it.label));
            if (it.hint) b.appendChild(el('span', 'sp-ctx-hint', it.hint));
            if (typeof it.checked === 'boolean') b.appendChild(el('span', 'sp-ctx-check' + (it.checked ? ' on' : ''), it.checked ? '✓' : ''));
            if (it.radio !== undefined) b.appendChild(el('span', 'sp-ctx-radio' + (it.radio ? ' on' : '')));
            if (it.sub) {
                b.appendChild(el('span', 'sp-ctx-arrow', '›'));
                b.setAttribute('aria-haspopup', 'menu');
                var open = function () { openSub(b, it.sub, depth); };
                b.addEventListener('mouseenter', open);
                b.addEventListener('click', function (e) { e.stopPropagation(); open(); });
            } else {
                b.addEventListener('click', function () { closeCtx(); it.run(); });
            }
            m.appendChild(b);
        });
    }
    function openSub(btn, items, depth) {
        closeSubs(depth);
        var visible = cleanItems(items);
        if (!visible.length) return;
        var m = el('div', 'sp-ctx sp-ctx-sub');
        m.setAttribute('role', 'menu');
        fillMenu(m, visible, depth + 1);
        document.body.appendChild(m);
        var r = btn.getBoundingClientRect(), w = m.offsetWidth, h = m.offsetHeight;
        var left = r.right + 2;
        if (left + w > window.innerWidth - 8) left = Math.max(8, r.left - w - 2);
        m.style.left = left + 'px';
        m.style.top = Math.max(8, Math.min(r.top - 6, window.innerHeight - h - 8)) + 'px';
        ctxSubs.push(m);
    }
    // opts: { anchor: элемент, который «нажат» пока меню открыто; width: минимальная ширина меню }
    function openCtx(x, y, items, opts) {
        // долгое нажатие на телефоне плюс contextmenu от самого браузера — второй вызов рядом игнорируем
        if (ctxEl && Date.now() - ctxAt < 600 && Math.abs(x - ctxX) < 40 && Math.abs(y - ctxY) < 40) return;
        closeCtx();
        opts = opts || {};
        var visible = cleanItems(items);
        if (!visible.length) return;
        var m = el('div', 'sp-ctx');
        m.setAttribute('role', 'menu');
        if (opts.width) m.style.minWidth = opts.width + 'px';
        fillMenu(m, visible, 0);
        document.body.appendChild(m);
        var w = m.offsetWidth, h = m.offsetHeight;
        m.style.left = Math.max(8, Math.min(x, window.innerWidth - w - 8)) + 'px';
        m.style.top = Math.max(8, Math.min(y, window.innerHeight - h - 8)) + 'px';
        ctxEl = m; ctxAt = Date.now(); ctxX = x; ctxY = y;
        if (opts.anchor) { ctxAnchor = opts.anchor; ctxAnchor.classList.add('open'); ctxAnchor.setAttribute('aria-expanded', 'true'); }
        setTimeout(function () {
            document.addEventListener('mousedown', ctxOutside, true);
            document.addEventListener('keydown', ctxKey, true);
            window.addEventListener('resize', closeCtx);
        }, 0);
    }
    function menuAt(btn, items) {
        var r = btn.getBoundingClientRect();
        openCtx(r.left, r.bottom + 4, items);
    }

    /* ---------- структура: загрузка, имена, значения по умолчанию ---------- */
    function applyStructure(cur, info) {
        cur.perms = info.perms | 0;
        cur.defaultPerms = info.default_perms | 0;
        cur.channels = info.channels || [];
        cur.channelCounts = info.channel_counts || { text: cur.channels.filter(function (c) { return c.type === 'text'; }).length, voice: cur.channels.filter(function (c) { return c.type === 'voice'; }).length };
        cur.categoryCount = typeof info.category_count === 'number' ? info.category_count : (info.categories || []).length;
        cur.categories = info.categories || [];
        cur.roles = info.roles || [];
        cur.cn = {}; cur.gn = {}; cur.rn = {};
        var jobs = [];
        function names(map, list) {
            list.forEach(function (it) {
                jobs.push(storedText(cur.key, it.name_enc, 'Элемент #' + it.id).then(function (text) {
                    map[it.id] = text;
                }));
            });
        }
        names(cur.cn, cur.channels);
        names(cur.gn, cur.categories);
        names(cur.rn, cur.roles);
        return Promise.all(jobs);
    }

    function reloadInfo() {
        var cur = state.current;
        if (!cur) return Promise.resolve();
        return api('info', { space_id: cur.id }).then(function (info) {
            if (state.current !== cur) return;
            if (!info.ok) { if (info.error === 'forbidden') { toast('Вы больше не участник.'); closeSpaceView(); loadList(); } return; }
            cur.info = info;
            cur.role = info.role;
            return applyStructure(cur, info).then(function () {
                if (state.current !== cur) return;
                validateChan(cur);
                renderHead();
                renderChannels();
                renderChanBar();
            });
        });
    }

    // Новое пространство (или старое без каналов): владелец создаёт «Текстовые каналы / общий» и «Голосовые каналы / Основной».
    function ensureDefaults(cur) {
        if (cur.channelCounts.text || cur.channelCounts.voice || cur.categoryCount || !(cur.perms & P.CHANNELS)) return Promise.resolve(false);
        function mk(action, name, extra) {
            var data = { space_id: cur.id, name_enc: name };
            for (var k in extra) data[k] = extra[k];
            return api(action, data);
        }
        return mk('category_create', 'Текстовые каналы', {}).then(function (c1) {
            return mk('category_create', 'Голосовые каналы', {}).then(function (c2) { return [c1, c2]; });
        }).then(function (c) {
            if (!c[0].ok || !c[1].ok) return false;
            return mk('channel_create', 'общий', { type: 'text', category_id: c[0].id }).then(function () {
                return mk('channel_create', 'Основной', { type: 'voice', category_id: c[1].id });
            }).then(function () { return true; });
        });
    }

    function textChannels(cur) { return cur.channels.filter(function (c) { return c.type === 'text'; }); }
    function voiceChannels(cur) { return cur.channels.filter(function (c) { return c.type === 'voice'; }); }
    function chName(cur, ch) {
        if (ch.id === 0) return ch.type === 'voice' ? 'Созвон' : 'общий-чат';
        return cur.cn[ch.id] != null ? cur.cn[ch.id] : '…';
    }
    function voiceName(cur, id) {
        if (id === 0) return 'Созвон';
        return cur.cn[id] != null ? cur.cn[id] : 'Голосовой канал';
    }

    // Выбранный текстовый канал должен существовать; если нет — берём первый (или «старый общий чат»).
    function validateChan(cur) {
        var texts = textChannels(cur);
        var ok = cur.chan && ((cur.chan.id === 0 && cur.channelCounts.text === 0) || texts.some(function (t) { return t.id === cur.chan.id; }));
        if (ok) {
            var selected = texts.filter(function (item) { return item.id === cur.chan.id; })[0];
            cur.chan.access = selected ? selected.access : null;
            return;
        }
        if (!texts.length && cur.channelCounts.text > 0) {
            cur.chan = null;
            cur.lastId = 0;
            cur.rendered = {};
            elMsgs.textContent = '';
            polling = false;
            return;
        }
        var nid = texts.length ? texts[0].id : 0;
        var channel = texts.filter(function (item) { return item.id === nid; })[0];
        cur.chan = { id: nid, type: 'text', access: channel ? channel.access : null };
        cur.lastId = 0;
        cur.rendered = {};
        elMsgs.textContent = '';
        polling = false;
        fetchMessages(true);
    }

    function selectTextChannel(ch) {
        var cur = state.current;
        if (!cur) return;
        setStage(false);                     // текстовый канал — снова чат (созвон продолжается в компактной панели)
        elActive.classList.remove('chan-open');
        if (cur.chan && cur.chan.id === ch.id) return;
        cancelEdit();
        notif.hold = null;
        cur.chan = { id: ch.id, type: 'text', access: ch.access };
        cur.lastId = 0;
        cur.rendered = {};
        elMsgs.textContent = '';
        polling = false;
        renderChanBar();
        renderChannels();
        fetchMessages(true);
        if (window.innerWidth > 900) input.focus();
    }

    // «Сцена»: нажали на голосовой канал — вместо чата крупные плитки участников и панель управления внизу
    function setStage(v) {
        var m = document.querySelector('.sp-main');
        if (m) m.classList.toggle('stage', !!v && call.active);
    }

    function joinVoice(ch) {
        var cur = state.current;
        if (!cur) return;
        if (!canChannelAction(cur, ch.id, 'voice', CHANNEL_PERMISSION.CONNECT)) { toast('У вас нет права подключаться к этому голосовому каналу.'); return; }
        elActive.classList.remove('chan-open');
        if (call.active) {
            if (call.spaceId === cur.id && call.channelId === ch.id) { setStage(true); return; }
            leaveCall();
            setTimeout(function () { startCall(false, ch.id); }, 350);
            return;
        }
        startCall(false, ch.id);
    }

    function renderChanBar() {
        var cur = state.current;
        var bar = $('spChanBar');
        syncReplyBar();
        bar.textContent = '';
        if (!cur || !cur.chan) return;
        var name = chName(cur, { id: cur.chan.id, type: 'text' });
        bar.appendChild(el('span', 'sp-chan-hash', '#'));
        bar.appendChild(el('span', 'sp-chan-name', name));
        input.placeholder = 'Написать в #' + name;
    }

    /* ---------- заглушённые каналы (хранится в браузере) ---------- */
    function chKey(ch) { return ch.type.charAt(0) + ch.id; }
    function isMuted(cur, ch) { return cur.muted.indexOf(chKey(ch)) !== -1; }
    function toggleMute(cur, ch) {
        var k = chKey(ch), i = cur.muted.indexOf(k);
        if (i === -1) cur.muted.push(k); else cur.muted.splice(i, 1);
        lsSet('space-muted:' + ME + ':' + cur.id, cur.muted);
        renderChannels();
    }
    function setHideMuted(cur, v) {
        cur.hideMuted = !!v;
        lsSet('space-hidemuted:' + ME + ':' + cur.id, cur.hideMuted);
        renderChannels();
    }

    function updateVoice(map) {
        var cur = state.current;
        if (!cur) return;
        var sig = JSON.stringify(map);
        if (sig === cur.voiceSig) return;
        cur.voiceSig = sig;
        cur.voice = map;
        renderChannels();
    }

    /* ---------- боковая панель ---------- */
    function isActiveChannel(cur, ch) {
        if (ch.type === 'text') return !!(cur.chan && cur.chan.id === ch.id);
        return call.active && call.spaceId === cur.id && call.channelId === ch.id;
    }

    function renderChannels() {
        var cur = state.current;
        var list = $('spChList');
        if (!cur || !list) return;
        var scroll = list.scrollTop;
        list.textContent = '';

        var items = cur.channels.map(function (c) { return c; });
        if (!textChannels(cur).length && cur.channelCounts.text === 0) items.push({ id: 0, category_id: 0, type: 'text', virtual: true });
        if (!voiceChannels(cur).length && cur.channelCounts.voice === 0) items.push({ id: 0, category_id: 0, type: 'voice', virtual: true });

        function group(catId) { return items.filter(function (c) { return c.category_id === catId; }); }
        var known = {};
        cur.categories.forEach(function (c) { known[c.id] = true; });
        var loose = items.filter(function (c) { return !c.category_id || !known[c.category_id]; });

        if (loose.length) {
            var wrap0 = el('div', 'sp-ch-group');
            loose.forEach(function (ch) { appendChannel(wrap0, cur, ch); });
            list.appendChild(wrap0);
        }
        cur.categories.forEach(function (cat) {
            var wrap = el('div', 'sp-ch-group');
            var collapsed = !!cur.collapsed[cat.id];
            var head = el('div', 'sp-cat');
            var tgl = el('button', 'sp-cat-name');
            tgl.type = 'button';
            tgl.appendChild(el('span', 'sp-cat-arrow' + (collapsed ? ' closed' : ''), '▾'));
            tgl.appendChild(el('span', 'sp-cat-title', cur.gn[cat.id] != null ? cur.gn[cat.id] : '…'));
            tgl.addEventListener('click', function () { cur.collapsed[cat.id] = !cur.collapsed[cat.id]; renderChannels(); });
            head.appendChild(tgl);
            if (can(P.CHANNELS)) {
                var add = el('button', 'sp-cat-btn', '+');
                add.type = 'button';
                add.title = 'Создать канал';
                add.addEventListener('click', function () { openCreateChannel(cat.id); });
                head.appendChild(add);
            }
            head.addEventListener('contextmenu', function (e) { e.preventDefault(); openCtx(e.clientX, e.clientY, categoryMenu(cur, cat)); });
            wrap.appendChild(head);
            group(cat.id).forEach(function (ch) {
                if (collapsed && !isActiveChannel(cur, ch) && !chanHasUnread(cur, ch)) return;
                appendChannel(wrap, cur, ch);
            });
            list.appendChild(wrap);
        });
        list.scrollTop = scroll;
    }

    function appendChannel(wrap, cur, ch) {
        var muted = isMuted(cur, ch);
        var active = isActiveChannel(cur, ch);
        if (muted && cur.hideMuted && !active) return;

        var users = ch.type === 'voice' ? (cur.voice[String(ch.id)] || []) : [];
        var row = el('div', 'sp-ch' + (active ? ' active' : '') + (muted ? ' muted' : ''));
        var main = el('button', 'sp-ch-main');
        main.type = 'button';
        main.appendChild(el('span', 'sp-ch-ico', ch.type === 'voice' ? '🔊' : '#'));
        main.appendChild(el('span', 'sp-ch-name', chName(cur, ch)));
        if (muted) main.appendChild(el('span', 'sp-ch-mutemark', '🔕'));
        var uk = ch.type === 'text' ? rkey(cur.id, ch.id) : '', mc = uk ? (notif.mentions[uk] || 0) : 0;
        if (mc > 0) main.appendChild(el('span', 'sp-mention-badge', mc > 99 ? '99+' : String(mc)));
        if (uk && (mc > 0 || (notif.unread[uk] && !muted))) row.classList.add('unread');
        main.addEventListener('click', function () {
            if (ch.type === 'voice') joinVoice(ch); else selectTextChannel(ch);
        });
        row.appendChild(main);

        var acts = el('span', 'sp-ch-actions');
        var more = el('button', 'sp-ch-act', '⋯');
        more.type = 'button';
        more.title = 'Действия';
        more.addEventListener('click', function (e) { e.stopPropagation(); menuAt(more, channelMenu(cur, ch)); });
        acts.appendChild(more);
        row.appendChild(acts);
        row.addEventListener('contextmenu', function (e) { e.preventDefault(); openCtx(e.clientX, e.clientY, channelMenu(cur, ch)); });
        longPress(row, function (x, y) { openCtx(x, y, channelMenu(cur, ch)); });
        wrap.appendChild(row);

        if (users.length) {
            var ul = el('div', 'sp-ch-users');
            users.forEach(function (u) {
                var r = el('div', 'sp-ch-user');
                r.appendChild(avatarNode(displayName(u), u.avatar, 'sp-avatar xs'));
                r.appendChild(el('span', 'sp-ch-user-name', displayName(u)));
                r.addEventListener('contextmenu', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    openMemberVolumeMenu(e.clientX, e.clientY, cur.id, u.user_id, displayName(u));
                });
                ul.appendChild(r);
            });
            wrap.appendChild(ul);
        }
    }

    var USER_VOLUME_KEY = 'sp_user_volumes';
    function getUserVolume(spaceId, userId) {
        var values = lsGet(USER_VOLUME_KEY, {});
        var key = String(spaceId) + ':' + String(userId);
        var value = values && typeof values[key] === 'number' ? values[key] : 100;
        return Math.max(0, Math.min(100, value));
    }

    function setUserVolume(spaceId, userId, value) {
        var values = lsGet(USER_VOLUME_KEY, {});
        if (!values || typeof values !== 'object' || Array.isArray(values)) values = {};
        values[String(spaceId) + ':' + String(userId)] = value;
        lsSet(USER_VOLUME_KEY, values);
        if (call.active && call.spaceId === spaceId) {
            var peer = call.peers[String(userId)];
            if (peer && peer.video) peer.video.volume = value / 100;
        }
    }

    /* openMemberVolumeMenu и channelMenu — см. блок «Как в Discord» ниже */

    function openChannelSettings(cur, ch) {
        var channelPerms = [
            { bit: 1, name: 'Просмотр канала' },
            { bit: 2, name: 'Отправка сообщений' },
            { bit: 4, name: 'Подключение к голосу' },
            { bit: 8, name: 'Говорить в голосовом канале' }
        ].filter(function (perm) {
            return ch.type === 'voice' || perm.bit <= 2;
        });
        modal('Параметры канала', function (body, close) {
            var box = body.parentNode;
            var head = box.querySelector('.sp-modal-head');
            var title = box.querySelector('.sp-modal-title');
            var closeButton = head.querySelector('.sp-icon-btn');
            var back = el('button', 'sp-channel-settings-back', '‹');
            back.type = 'button';
            back.setAttribute('aria-label', 'Назад');
            head.insertBefore(back, title);
            closeButton.hidden = true;
            var saveOverview = el('button', 'sp-channel-settings-save', 'Сохранить');
            saveOverview.type = 'button';
            head.insertBefore(saveOverview, closeButton);
            var content = el('div', 'sp-channel-settings-content');
            body.appendChild(content);
            var nameField, topicField, categoryField;
            var permissionPage = false;
            var overviewDraft = {
                name: chName(cur, ch),
                topic: ch.topic || '',
                categoryId: ch.category_id || 0
            };

            function showOverview() {
                permissionPage = false;
                title.textContent = 'Параметры канала';
                saveOverview.hidden = false;
                content.textContent = '';
                var nameGroup = el('div', 'sp-channel-settings-field');
                nameGroup.appendChild(el('label', 'sp-label', 'Название канала'));
                nameField = el('input', 'sp-input');
                nameField.type = 'text';
                nameField.maxLength = 40;
                nameField.value = overviewDraft.name;
                nameField.addEventListener('input', function () { overviewDraft.name = nameField.value; });
                nameGroup.appendChild(nameField);
                content.appendChild(nameGroup);

                var topicGroup = el('div', 'sp-channel-settings-field');
                topicGroup.appendChild(el('label', 'sp-label', 'Тема канала'));
                topicField = el('textarea', 'sp-input sp-channel-topic');
                topicField.maxLength = 1024;
                topicField.value = overviewDraft.topic;
                topicField.placeholder = 'Добавьте описание канала';
                topicField.addEventListener('input', function () { overviewDraft.topic = topicField.value; });
                topicGroup.appendChild(topicField);
                content.appendChild(topicGroup);

                var categoryRow = el('label', 'sp-channel-settings-row');
                categoryRow.appendChild(el('span', 'sp-channel-settings-row-icon', '▦'));
                categoryRow.appendChild(el('span', 'sp-channel-settings-row-title', 'Категория'));
                categoryField = el('select', 'sp-channel-category');
                var noCategory = el('option', null, 'Общее');
                noCategory.value = '0';
                categoryField.appendChild(noCategory);
                cur.categories.forEach(function (category) {
                    var option = el('option', null, cur.gn[category.id] || 'Категория');
                    option.value = String(category.id);
                    categoryField.appendChild(option);
                });
                categoryField.value = String(overviewDraft.categoryId);
                categoryField.addEventListener('change', function () {
                    overviewDraft.categoryId = parseInt(categoryField.value, 10) || 0;
                });
                categoryRow.appendChild(categoryField);
                categoryRow.appendChild(el('span', 'sp-channel-settings-chevron', '›'));
                content.appendChild(categoryRow);

                var permissionsRow = el('button', 'sp-channel-settings-row', '');
                permissionsRow.type = 'button';
                permissionsRow.appendChild(el('span', 'sp-channel-settings-row-icon', '♙'));
                permissionsRow.appendChild(el('span', 'sp-channel-settings-row-title', 'Права канала'));
                permissionsRow.appendChild(el('span', 'sp-channel-settings-chevron', '›'));
                permissionsRow.addEventListener('click', showPermissions);
                content.appendChild(permissionsRow);
                content.appendChild(el('p', 'sp-hint sp-channel-settings-description', 'Измените настройки доступа и определите, как пользователи будут взаимодействовать с этим каналом.'));

                var remove = el('button', 'sp-btn danger sp-channel-settings-delete', 'Удалить канал');
                remove.type = 'button';
                remove.addEventListener('click', function () {
                    close();
                    deleteChannel(cur, ch);
                });
                content.appendChild(remove);
            }

            function showPermissions() {
                permissionPage = true;
                title.textContent = 'Права доступа';
                saveOverview.hidden = true;
                content.textContent = '';
                content.appendChild(el('p', 'sp-hint', 'Настройте права отдельно для ролей и участников. «Наследовать» использует обычные права пространства.'));

                var subject = el('select', 'sp-input sp-select');
                var everyone = el('option', null, 'Роль «Участник»');
                everyone.value = 'role:0';
                subject.appendChild(everyone);
                cur.roles.forEach(function (r) {
                    var option = el('option', null, rname(cur, r.id));
                    option.value = 'role:' + r.id;
                    subject.appendChild(option);
                });
                cur.info.members.forEach(function (member) {
                    if (member.role === 'owner') return;
                    var option = el('option', null, 'Участник: ' + displayName(member));
                    option.value = 'member:' + member.id;
                    subject.appendChild(option);
                });
                content.appendChild(el('label', 'sp-label', 'Роль или участник'));
                content.appendChild(subject);
                var controls = el('div', 'sp-channel-perm-controls');
                content.appendChild(controls);
                var save = el('button', 'sp-btn primary', 'Сохранить права');
                save.type = 'button';
                content.appendChild(save);

                var overrides = [];
                function renderPermissions() {
                    controls.textContent = '';
                    var selected = subject.value.split(':');
                    var override = overrides.filter(function (item) {
                        return item.subject_type === selected[0] && item.subject_id === (parseInt(selected[1], 10) || 0);
                    })[0] || { allow: 0, deny: 0 };
                    channelPerms.forEach(function (perm) {
                        var field = el('label', 'sp-channel-perm-row');
                        field.appendChild(el('span', null, perm.name));
                        var select = el('select', 'sp-input sp-select');
                        [['inherit', 'Наследовать'], ['allow', 'Разрешить'], ['deny', 'Запретить']].forEach(function (choice) {
                            var option = el('option', null, choice[1]);
                            option.value = choice[0];
                            select.appendChild(option);
                        });
                        select.value = (override.allow & perm.bit) ? 'allow' : ((override.deny & perm.bit) ? 'deny' : 'inherit');
                        select.dataset.permissionBit = String(perm.bit);
                        field.appendChild(select);
                        controls.appendChild(field);
                    });
                }

                api('channel_permissions', { space_id: cur.id, channel_id: ch.id }).then(function (res) {
                    if (!res.ok) { toast(res.message || 'Не удалось загрузить права канала.'); return; }
                    overrides = res.overrides || [];
                    renderPermissions();
                }).catch(function () { toast('Не удалось загрузить права канала.'); });
                subject.addEventListener('change', renderPermissions);
                save.addEventListener('click', function () {
                    var selected = subject.value.split(':');
                    var allow = 0, deny = 0;
                    Array.prototype.forEach.call(controls.querySelectorAll('select[data-permission-bit]'), function (select) {
                        var bit = parseInt(select.dataset.permissionBit, 10);
                        if (select.value === 'allow') allow |= bit;
                        if (select.value === 'deny') deny |= bit;
                    });
                    save.disabled = true;
                    api('channel_permission_set', {
                        space_id: cur.id, channel_id: ch.id,
                        subject_type: selected[0], subject_id: parseInt(selected[1], 10) || 0,
                        allow: allow, deny: deny
                    }).then(function (res) {
                        save.disabled = false;
                        if (!res.ok) { toast(res.message || 'Не удалось сохранить права канала.'); return; }
                        overrides = overrides.filter(function (item) {
                            return item.subject_type !== selected[0] || item.subject_id !== (parseInt(selected[1], 10) || 0);
                        });
                        if (allow || deny) overrides.push({
                            subject_type: selected[0], subject_id: parseInt(selected[1], 10) || 0, allow: allow, deny: deny
                        });
                        toast('Права канала сохранены');
                        reloadInfo();
                    }).catch(function () {
                        save.disabled = false;
                        toast('Не удалось сохранить права канала.');
                    });
                });
            }

            saveOverview.addEventListener('click', function () {
                var value = nameField.value.trim();
                if (!value) { nameField.focus(); return; }
                saveOverview.disabled = true;
                api('channel_update', {
                    space_id: cur.id, id: ch.id, name_enc: value,
                    topic: topicField.value, category_id: parseInt(categoryField.value, 10) || 0
                }).then(function (res) {
                    saveOverview.disabled = false;
                    if (!res.ok) { toast(res.message || 'Не удалось сохранить настройки канала.'); return; }
                    ch.topic = topicField.value;
                    ch.category_id = parseInt(categoryField.value, 10) || 0;
                    overviewDraft.name = value;
                    overviewDraft.topic = topicField.value;
                    overviewDraft.categoryId = ch.category_id;
                    return reloadInfo().then(function () {
                        toast('Настройки канала сохранены');
                        close();
                    });
                }).catch(function () {
                    saveOverview.disabled = false;
                    toast('Не удалось сохранить настройки канала.');
                });
            });
            back.addEventListener('click', function () {
                if (permissionPage) showOverview();
                else close();
            });
            showOverview();
        }, 'sp-channel-settings-modal');
    }

    document.addEventListener('spaces:configure-current-channel', function () {
        var cur = state.current;
        if (!cur || !cur.chan || cur.chan.id <= 0) {
            toast('Сначала выберите текстовый канал.');
            return;
        }
        var channel = cur.channels.filter(function (item) {
            return item.id === cur.chan.id && item.type === 'text';
        })[0];
        if (!channel) {
            toast('Не удалось найти выбранный канал.');
            return;
        }
        openChannelSettings(cur, channel);
    });

    function sidebarMenu(cur) {
        return [
            { label: 'Скрыть заглушённые каналы', checked: cur.hideMuted, run: function () { setHideMuted(cur, !cur.hideMuted); } },
            { divider: true, hidden: !(can(P.CHANNELS) || can(P.INVITE)) },
            { label: 'Создать канал', hidden: !can(P.CHANNELS), run: function () { openCreateChannel(0); } },
            { label: 'Создать категорию', hidden: !can(P.CHANNELS), run: openCreateCategory },
            { label: 'Пригласить на сервер', hidden: !(can(P.INVITE) && cur.info && cur.info.invite_code), run: function () { $('spInviteBtn').click(); } }
        ];
    }

    /* ---------- создание / переименование / удаление ---------- */
    function after(res, okText) {
        if (!res.ok) { toast(res.message || 'Не удалось выполнить действие.'); return Promise.resolve(false); }
        if (okText) toast(okText);
        return reloadInfo().then(function () { return true; });
    }

    function openCreateChannel(catId) {
        var cur = state.current;
        if (!cur || !can(P.CHANNELS)) return;
        modal('Создать канал', function (body, close) {
            var type = 'text';
            var types = el('div', 'sp-types');
            var bText = el('button', 'sp-type on'); bText.type = 'button';
            bText.appendChild(el('span', 'sp-type-ico', '#'));
            var tt = el('span', 'sp-type-txt'); tt.appendChild(el('b', null, 'Текстовый')); tt.appendChild(el('small', null, 'Открытый текстовый чат'));
            bText.appendChild(tt);
            var bVoice = el('button', 'sp-type'); bVoice.type = 'button';
            bVoice.appendChild(el('span', 'sp-type-ico', '🔊'));
            var vt = el('span', 'sp-type-txt'); vt.appendChild(el('b', null, 'Голосовой')); vt.appendChild(el('small', null, 'Голос и видео'));
            bVoice.appendChild(vt);
            types.appendChild(bText); types.appendChild(bVoice);
            body.appendChild(types);
            function setType(t) { type = t; bText.classList.toggle('on', t === 'text'); bVoice.classList.toggle('on', t === 'voice'); }
            bText.addEventListener('click', function () { setType('text'); });
            bVoice.addEventListener('click', function () { setType('voice'); });

            body.appendChild(el('label', 'sp-label', 'Название канала'));
            var input2 = el('input', 'sp-input');
            input2.type = 'text'; input2.maxLength = 40; input2.placeholder = 'новый-канал';
            body.appendChild(input2);

            body.appendChild(el('label', 'sp-label', 'Категория'));
            var sel = el('select', 'sp-input sp-select');
            var o0 = el('option', null, 'Без категории'); o0.value = '0'; sel.appendChild(o0);
            cur.categories.forEach(function (c) { var o = el('option', null, cur.gn[c.id]); o.value = String(c.id); sel.appendChild(o); });
            sel.value = String(catId || 0);
            body.appendChild(sel);

            var btn = el('button', 'sp-btn primary', 'Создать канал');
            btn.type = 'button';
            body.appendChild(btn);
            setTimeout(function () { input2.focus(); }, 30);

            function submit() {
                var name = input2.value.trim();
                if (!name) { input2.focus(); return; }
                btn.disabled = true;
                var t = type;
                api('channel_create', { space_id: cur.id, type: t, name_enc: name, category_id: parseInt(sel.value, 10) || 0 }).then(function (res) {
                    btn.disabled = false;
                    if (!res.ok) { toast(res.message || 'Не удалось создать канал.'); return; }
                    close();
                    reloadInfo().then(function () {
                        if (t === 'text' && state.current === cur) selectTextChannel({ id: res.id, type: 'text' });
                    });
                });
            }
            btn.addEventListener('click', submit);
            input2.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
        });
    }

    function openCreateCategory() {
        var cur = state.current;
        if (!cur || !can(P.CHANNELS)) return;
        modal('Создать категорию', function (body, close) {
            body.appendChild(el('label', 'sp-label', 'Название категории'));
            var input2 = el('input', 'sp-input');
            input2.type = 'text'; input2.maxLength = 40; input2.placeholder = 'Новая категория';
            body.appendChild(input2);
            var btn = el('button', 'sp-btn primary', 'Создать категорию');
            btn.type = 'button';
            body.appendChild(btn);
            setTimeout(function () { input2.focus(); }, 30);
            function submit() {
                var name = input2.value.trim();
                if (!name) { input2.focus(); return; }
                btn.disabled = true;
                api('category_create', { space_id: cur.id, name_enc: name }).then(function (res) {
                    btn.disabled = false;
                    if (!res.ok) { toast(res.message || 'Не удалось создать категорию.'); return; }
                    close();
                    reloadInfo();
                });
            }
            btn.addEventListener('click', submit);
            input2.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
        });
    }

    function openMoveChannel(cur, ch) {
        if (!can(P.CHANNELS)) return;
        modal('Переместить канал', function (body, close) {
            body.appendChild(el('p', 'sp-hint', 'Выберите категорию для канала «' + chName(cur, ch) + '».'));
            var select = el('select', 'sp-input sp-select');
            var none = el('option', null, 'Без категории'); none.value = '0'; select.appendChild(none);
            cur.categories.forEach(function (category) {
                var option = el('option', null, cur.gn[category.id] || 'Категория');
                option.value = String(category.id);
                select.appendChild(option);
            });
            select.value = String(ch.category_id || 0);
            body.appendChild(select);
            var save = el('button', 'sp-btn primary', 'Переместить');
            save.type = 'button';
            save.addEventListener('click', function () {
                save.disabled = true;
                api('channel_update', {
                    space_id: cur.id, id: ch.id, name_enc: chName(cur, ch),
                    topic: ch.topic || '', category_id: parseInt(select.value, 10) || 0
                }).then(function (res) {
                    save.disabled = false;
                    if (!res.ok) { toast(res.message || 'Не удалось переместить канал.'); return; }
                    close();
                    return reloadInfo();
                }).catch(function () { save.disabled = false; toast('Не удалось переместить канал.'); });
            });
            body.appendChild(save);
        });
    }

    function openRename(kind, id, current) {
        var cur = state.current;
        if (!cur || !can(P.CHANNELS)) return;
        modal(kind === 'channel' ? 'Переименовать канал' : 'Переименовать категорию', function (body, close) {
            var input2 = el('input', 'sp-input');
            input2.type = 'text'; input2.maxLength = 40; input2.value = current || '';
            body.appendChild(input2);
            var btn = el('button', 'sp-btn primary', 'Сохранить');
            btn.type = 'button';
            body.appendChild(btn);
            setTimeout(function () { input2.focus(); input2.select(); }, 30);
            function submit() {
                var name = input2.value.trim();
                if (!name) { input2.focus(); return; }
                btn.disabled = true;
                api(kind === 'channel' ? 'channel_update' : 'category_update', { space_id: cur.id, id: id, name_enc: name }).then(function (res) {
                    btn.disabled = false;
                    if (!res.ok) { toast(res.message || 'Не удалось переименовать.'); return; }
                    close();
                    reloadInfo();
                });
            }
            btn.addEventListener('click', submit);
            input2.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
        });
    }

    function deleteChannel(cur, ch) {
        var what = ch.type === 'voice' ? 'голосовой канал' : 'канал со всеми его сообщениями';
        if (!confirm('Удалить ' + what + ' «' + chName(cur, ch) + '»? Это нельзя отменить.')) return;
        if (call.active && call.spaceId === cur.id && call.channelId === ch.id) leaveCall();
        api('channel_delete', { space_id: cur.id, id: ch.id }).then(function (res) { after(res, 'Канал удалён'); });
    }
    function deleteCategory(cur, cat) {
        if (!confirm('Удалить категорию «' + cur.gn[cat.id] + '»? Каналы внутри останутся — без категории.')) return;
        api('category_delete', { space_id: cur.id, id: cat.id }).then(function (res) { after(res, 'Категория удалена'); });
    }

    /* ---------- шапка списка каналов: «Имя сервера ⌄» и меню сервера ---------- */
    function copyText(text, okMsg) {
        var done = false;
        function fallback() {
            var t = document.createElement('textarea');
            t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
            document.body.appendChild(t); t.select();
            try { done = document.execCommand('copy'); } catch (e) {}
            t.remove();
            toast(done ? okMsg : 'Не удалось скопировать');
        }
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(function () { toast(okMsg); }, fallback);
        } else fallback();
    }

    function serverMenu(cur) {
        var owner = cur.info ? cur.info.role === 'owner' : cur.role === 'owner';
        var canInvite = can(P.INVITE) && cur.info && cur.info.invite_code;
        var manage = can(P.CHANNELS);
        return [
            { label: 'Пригласить на сервер', icon: ICONS.invite, hidden: !canInvite, run: function () { $('spInviteBtn').click(); } },
            { label: 'Старый ключ для другого устройства', icon: ICONS.invite, hidden: !cur.key, run: openTransferKey },
            { label: 'Настройки сервера', icon: ICONS.settings, run: openSettings },
            { label: 'Настройки уведомлений', icon: ICONS.bell, run: function () { openNotifySettings(cur.id); } },
            serverMuteItem(cur.id),
            serverBadgeItem(cur.id),
            { divider: true },
            { label: 'Создать канал', icon: ICONS.channel, hidden: !manage, run: function () { openCreateChannel(0); } },
            { label: 'Создать категорию', icon: ICONS.category, hidden: !manage, run: openCreateCategory },
            { divider: true, hidden: !manage },
            { label: 'Скрыть заглушённые каналы', icon: ICONS.eyeOff, checked: cur.hideMuted, run: function () { setHideMuted(cur, !cur.hideMuted); } },
            { divider: true },
            { label: 'Копировать ID сервера', icon: ICONS.copy, run: function () { copyText(String(cur.id), 'ID сервера скопирован'); } },
            { divider: true },
            { label: 'Покинуть сервер', icon: ICONS.leave, danger: true, hidden: owner, run: function () { $('spLeaveBtn').click(); } },
            { label: 'Удалить сервер', icon: ICONS.trash, danger: true, hidden: !owner, run: function () { $('spDeleteBtn').click(); } }
        ];
    }

    var chHead = $('spChMenuBtn').closest('.sp-ch-head') || $('spChMenuBtn').parentNode;
    var chHeadTitle = chHead.querySelector('.sp-ch-head-title');
    if (!chHeadTitle) { chHeadTitle = el('span', 'sp-ch-head-title'); chHead.insertBefore(chHeadTitle, chHead.firstChild); }
    chHead.classList.add('sp-server-head');
    chHead.setAttribute('role', 'button');
    chHead.setAttribute('tabindex', '0');
    chHead.setAttribute('aria-haspopup', 'menu');
    chHead.setAttribute('aria-expanded', 'false');

    // справа в шапке теперь кнопка «Пригласить», остальное — в меню сервера
    $('spChMenuBtn').innerHTML = ICONS.invite;
    $('spChMenuBtn').title = 'Пригласить на сервер';
    $('spChMenuBtn').hidden = true;

    function renderServerHead() {
        var cur = state.current;
        if (!cur) return;
        chHeadTitle.textContent = '';
        chHeadTitle.appendChild(el('span', 'sp-ch-head-name', cur.name));
        var chev = el('span', 'sp-ch-head-chev');
        chev.innerHTML = ICONS.chevron;
        chHeadTitle.appendChild(chev);
        $('spChMenuBtn').hidden = !(can(P.INVITE) && cur.info && cur.info.invite_code);
    }

    function toggleServerMenu() {
        var cur = state.current;
        if (!cur) return;
        if (ctxAnchor === chHead) { closeCtx(); return; }
        var r = chHead.getBoundingClientRect();
        openCtx(r.left + 8, r.bottom + 4, serverMenu(cur), { anchor: chHead, width: Math.max(230, r.width - 16) });
    }
    /* Старые кнопки в шапке пространства убраны: всё это теперь в меню сервера и в «Настройках сервера».
       Сами элементы остаются в DOM, потому что меню вызывает их обработчики. */
    (function hideLegacyHeaderButtons() {
        var ids = ['spRolesBtn', 'spBotsBtn', 'spInviteBtn', 'spLeaveBtn', 'spDeleteBtn'];
        var btns = ids.map(function (id) { return $(id); }).filter(Boolean);
        btns.forEach(function (b) { b.classList.add('sp-legacy-act'); });
        var parents = [];
        btns.forEach(function (b) { if (b.parentNode && parents.indexOf(b.parentNode) === -1) parents.push(b.parentNode); });
        parents.forEach(function (p) {
            var onlyLegacy = Array.prototype.every.call(p.children, function (c) { return c.classList.contains('sp-legacy-act'); });
            if (onlyLegacy) p.classList.add('sp-legacy-wrap');   // контейнер, где остались только они, прячем целиком
        });
    })();

    /* ================================================================ НАСТРОЙКИ СЕРВЕРА (отдельный экран) */
    var setEl = null, setPane = null, setTitle = null, setActive = '', setToken = 0, setKeyHandler = null;

    function settingsNav(cur) {
        var canRoles = !!can(P.ROLES);
        var canInv = !!(can(P.INVITE) && cur.info && cur.info.invite_code);
        var canModerate = !!can(P.KICK);
        return [
            { head: 'Сервер ' + cur.name, items: [
                { id: 'profile', label: 'Профиль сервера' },
                { id: 'tag', label: 'Тег сервера', soon: true },
                { id: 'engage', label: 'Вовлечённость', soon: true },
                { id: 'boost', label: 'Бонусы буста', soon: true }
            ] },
            { head: 'Реакции', items: [
                { id: 'emoji', label: 'Эмодзи', soon: true },
                { id: 'stickers', label: 'Стикеры', soon: true },
                { id: 'soundboard', label: 'Звуковая панель', soon: true }
            ] },
            { head: 'Люди', items: [
                { id: 'members', label: 'Участники' },
                { id: 'roles', label: 'Роли', hidden: !canRoles },
                { id: 'invites', label: 'Приглашения', hidden: !canInv },
                { id: 'access', label: 'Доступ', soon: true }
            ] },
            { head: 'Приложения', items: [
                { id: 'integrations', label: 'Интеграция' },
                { id: 'catalog', label: 'Каталог приложений', soon: true, external: true }
            ] },
            { head: 'Модерация', items: [
                { id: 'security', label: 'Настройка безопасности', soon: true },
                { id: 'audit', label: 'Журнал аудита', soon: true },
                { id: 'bans', label: 'Баны', hidden: !canModerate, soon: false },
                { id: 'automod', label: 'Автомод', soon: true }
            ] }
        ];
    }

    function settingsRow(label, node) {
        var r = el('div', 'sp-set-field');
        r.appendChild(el('div', 'sp-set-flabel', label));
        r.appendChild(node);
        return r;
    }

    function renderSettingsSection(id, label, soon) {
        var cur = state.current;
        var token = ++setToken;
        setPane.textContent = '';
        setTitle.textContent = label;
        setActive = id;
        Array.prototype.forEach.call(setEl.querySelectorAll('.sp-set-item'), function (b) { b.classList.toggle('active', b.getAttribute('data-id') === id); });
        setEl.classList.add('in-pane');
        setPane.scrollTop = 0;

        function inPane(fn) {
            paneHost = setPane;
            try { fn(); } finally { paneHost = null; }
        }

        if (id === 'bans') {
            inPane(openBans);
            return;
        }
        if (soon) {
            var box = el('div', 'sp-set-soon');
            box.appendChild(el('div', 'sp-set-soon-title', 'Скоро'));
            box.appendChild(el('p', 'sp-hint', 'Раздел «' + label + '» ещё в разработке и появится в одном из ближайших обновлений.'));
            setPane.appendChild(box);
            return;
        }
        if (id === 'profile') {
            var body = el('div', 'sp-set-body');
            var isOwner = !!(cur.info && cur.info.role === 'owner');
            var name = el('input', 'sp-input'); name.type = 'text'; name.maxLength = 40; name.value = cur.name || ('Сервер #' + cur.id);
            body.appendChild(settingsRow('Название сервера', name));
            var saveName = el('button', 'sp-btn primary', 'Сохранить название');
            saveName.type = 'button';
            saveName.disabled = !isOwner;
            saveName.title = saveName.disabled ? 'Переименовать сервер может только владелец' : '';
            saveName.addEventListener('click', function () {
                saveName.disabled = true;
                api('name_update', { space_id: cur.id, name: name.value }).then(function (res) {
                    if (!res.ok) {
                        toast(res.message || 'Не удалось изменить название сервера.');
                        saveName.disabled = !(cur.info && cur.info.role === 'owner');
                        return;
                    }
                    cur.name = res.name;
                    if (cur.info) cur.info.name_enc = res.name;
                    var listed = state.spaces.filter(function (space) { return space.id === cur.id; })[0];
                    if (listed) listed.name = res.name;
                    name.value = res.name;
                    elTitle.textContent = res.name;
                    renderList();
                    renderServerHead();
                    var serverHeading = setEl && setEl.querySelector('.sp-set-head');
                    if (serverHeading) serverHeading.textContent = 'Сервер ' + res.name;
                    toast('Название сервера сохранено');
                }).catch(function () {
                    toast('Не удалось изменить название сервера.');
                }).then(function () {
                    if (saveName.isConnected) saveName.disabled = !(cur.info && cur.info.role === 'owner');
                });
            });
            body.appendChild(saveName);

            var avatarControls = el('div', 'sp-profile-avatar-controls');
            var avatarPreview = el('div', 'sp-item-ico sp-profile-avatar', cur.avatar_path ? '' : letter(cur.name));
            function renderAvatarPreview(path) {
                avatarPreview.textContent = '';
                var src = safeAvatar(path);
                if (!src) { avatarPreview.textContent = letter(cur.name); return; }
                var previewImage = document.createElement('img');
                previewImage.src = src;
                previewImage.alt = '';
                previewImage.onerror = function () { avatarPreview.textContent = letter(cur.name); };
                avatarPreview.appendChild(previewImage);
            }
            renderAvatarPreview(cur.avatar_path);
            var avatarInput = el('input', 'sp-input');
            avatarInput.type = 'file';
            avatarInput.accept = 'image/jpeg,image/png,image/webp';
            avatarInput.disabled = !isOwner;
            avatarInput.setAttribute('aria-label', 'Изображение сервера');
            var uploadAvatar = el('button', 'sp-btn', 'Загрузить изображение');
            uploadAvatar.type = 'button';
            uploadAvatar.disabled = !isOwner;
            uploadAvatar.addEventListener('click', function () {
                var file = avatarInput.files && avatarInput.files[0];
                if (!file) { toast('Выберите изображение сервера.'); return; }
                var form = new FormData();
                form.append('space_id', String(cur.id));
                form.append('avatar', file);
                uploadAvatar.disabled = true;
                uploadApi('avatar_update', form).then(function (res) {
                    if (!res.ok) {
                        toast(res.message || 'Не удалось изменить изображение сервера.');
                        return;
                    }
                    cur.avatar_path = res.avatar_path || '';
                    if (cur.info) cur.info.avatar_path = cur.avatar_path;
                    var listed = state.spaces.filter(function (space) { return space.id === cur.id; })[0];
                    if (listed) listed.avatar_path = cur.avatar_path;
                    renderAvatarPreview(cur.avatar_path);
                    renderList();
                    removeAvatar.disabled = !isOwner || !cur.avatar_path;
                    toast('Изображение сервера сохранено');
                }).catch(function () {
                    toast('Не удалось изменить изображение сервера.');
                }).then(function () {
                    uploadAvatar.disabled = !isOwner;
                    avatarInput.value = '';
                });
            });
            var removeAvatar = el('button', 'sp-btn danger', 'Удалить изображение');
            removeAvatar.type = 'button';
            removeAvatar.disabled = !isOwner || !cur.avatar_path;
            removeAvatar.addEventListener('click', function () {
                removeAvatar.disabled = true;
                uploadAvatar.disabled = true;
                var form = new FormData();
                form.append('space_id', String(cur.id));
                form.append('remove', '1');
                uploadApi('avatar_update', form).then(function (res) {
                    if (!res.ok) {
                        toast(res.message || 'Не удалось удалить изображение сервера.');
                        return;
                    }
                    cur.avatar_path = '';
                    if (cur.info) cur.info.avatar_path = '';
                    var listed = state.spaces.filter(function (space) { return space.id === cur.id; })[0];
                    if (listed) listed.avatar_path = '';
                    renderAvatarPreview('');
                    renderList();
                    toast('Изображение сервера удалено');
                }).catch(function () {
                    toast('Не удалось удалить изображение сервера.');
                }).then(function () {
                    removeAvatar.disabled = !isOwner || !cur.avatar_path;
                    uploadAvatar.disabled = !isOwner;
                });
            });
            avatarControls.appendChild(avatarPreview);
            avatarControls.appendChild(avatarInput);
            avatarControls.appendChild(uploadAvatar);
            avatarControls.appendChild(removeAvatar);
            body.appendChild(settingsRow('Аватар сервера', avatarControls));

            var idRow = el('div', 'sp-row');
            var idIn = el('input', 'sp-input'); idIn.type = 'text'; idIn.readOnly = true; idIn.value = String(cur.id);
            var idBtn = el('button', 'sp-btn', 'Копировать'); idBtn.type = 'button';
            idBtn.addEventListener('click', function () { copyText(String(cur.id), 'ID сервера скопирован'); });
            idRow.appendChild(idIn); idRow.appendChild(idBtn);
            body.appendChild(settingsRow('ID сервера', idRow));
            var owner = cur.info ? cur.info.role === 'owner' : cur.role === 'owner';
            var n = cur.info && cur.info.members ? cur.info.members.length : 0;
            body.appendChild(settingsRow('Ваша роль', el('div', 'sp-set-value', owner ? 'Владелец' : 'Участник')));
            body.appendChild(settingsRow('Участников', el('div', 'sp-set-value', String(n))));
            body.appendChild(el('p', 'sp-hint', 'Сообщения и названия автоматически шифруются в базе данных. Это не сквозное шифрование: сервер может обработать текст. Для звонков и новых сообщений ключ не нужен.'));
            setPane.appendChild(body);
            return;
        }
        if (id === 'members') {
            reloadInfo().then(function () { if (token === setToken) inPane(openMembers); }, function () { if (token === setToken) inPane(openMembers); });
            return;
        }
        if (id === 'roles') { inPane(openRoles); return; }
        if (id === 'integrations') { inPane(openBots); return; }
        if (id === 'invites') {
            var ib = el('div', 'sp-set-body');
            if (!cur.info || !cur.info.invite_code) {
                ib.appendChild(el('p', 'sp-hint', 'Ссылка-приглашение недоступна.'));
            } else {
                var raw = cur.key ? getRawKey(cur.id) : null;
                var link = location.origin + location.pathname + '?join=' + cur.info.invite_code + (raw ? '#' + raw : '');
                ib.appendChild(el('p', 'sp-hint', 'Ссылка даёт доступ к пространству и его переписке. Передавайте её только тем, кого хотите пригласить.'));
                var lr = el('div', 'sp-row');
                var li = el('input', 'sp-input'); li.type = 'text'; li.readOnly = true; li.value = link;
                li.addEventListener('focus', function () { li.select(); });
                var lb = el('button', 'sp-btn primary', 'Копировать'); lb.type = 'button';
                lb.addEventListener('click', function () { copyText(link, 'Ссылка скопирована'); });
                lr.appendChild(li); lr.appendChild(lb);
                ib.appendChild(settingsRow('Ссылка-приглашение', lr));
            }
            setPane.appendChild(ib);
        }
    }

    function openSettings() {
        var cur = state.current;
        if (!cur) return;
        closeSettings();
        setEl = el('div', 'sp-set');
        setEl.setAttribute('role', 'dialog');
        setEl.setAttribute('aria-label', 'Настройки сервера');

        var side = el('nav', 'sp-set-side');
        var sideTop = el('div', 'sp-set-side-top');          // видна только на телефоне
        sideTop.appendChild(el('div', 'sp-set-side-title', 'Настройки сервера'));
        var sx = el('button', 'sp-set-close'); sx.type = 'button'; sx.title = 'Закрыть'; sx.innerHTML = ICONS.close;
        sx.addEventListener('click', closeSettings);
        sideTop.appendChild(sx);
        side.appendChild(sideTop);
        settingsNav(cur).forEach(function (g, gi) {
            var items = g.items.filter(function (it) { return !it.hidden; });
            if (!items.length) return;
            var grp = el('div', 'sp-set-group');
            grp.appendChild(el('div', 'sp-set-head', g.head));
            items.forEach(function (it) {
                var b = el('button', 'sp-set-item' + (it.soon ? ' soon' : ''));
                b.type = 'button';
                b.setAttribute('data-id', it.id);
                b.appendChild(el('span', 'sp-set-item-label', it.label));
                if (it.external) { var ex = el('span', 'sp-set-ext'); ex.innerHTML = ICONS.external; b.appendChild(ex); }
                b.addEventListener('click', function () { renderSettingsSection(it.id, it.label, !!it.soon); });
                grp.appendChild(b);
            });
            side.appendChild(grp);
        });
        setEl.appendChild(side);

        var main = el('div', 'sp-set-main');
        var top = el('div', 'sp-set-top');
        var back = el('button', 'sp-set-back'); back.type = 'button'; back.title = 'Назад'; back.innerHTML = ICONS.back;
        back.addEventListener('click', function () { setEl.classList.remove('in-pane'); });
        setTitle = el('h2', 'sp-set-title');
        var x = el('button', 'sp-set-close'); x.type = 'button'; x.title = 'Закрыть (Esc)';
        x.innerHTML = ICONS.close;
        x.addEventListener('click', closeSettings);
        var closeWrap = el('div', 'sp-set-closewrap');
        closeWrap.appendChild(x);
        closeWrap.appendChild(el('span', 'sp-set-esc', 'ESC'));
        top.appendChild(back); top.appendChild(setTitle); top.appendChild(closeWrap);
        main.appendChild(top);
        setPane = el('div', 'sp-set-pane');
        main.appendChild(setPane);
        setEl.appendChild(main);
        document.body.appendChild(setEl);

        setKeyHandler = function (e) { if (e.key === 'Escape' && !ctxEl && !document.querySelector('.sp-modal-back')) closeSettings(); };
        document.addEventListener('keydown', setKeyHandler);

        var narrow = window.matchMedia && window.matchMedia('(max-width: 760px)').matches;
        if (narrow) { setActive = ''; setTitle.textContent = 'Настройки сервера'; }
        else renderSettingsSection('profile', 'Профиль сервера', false);
    }

    function closeSettings() {
        setToken++;
        if (setEl) { setEl.remove(); setEl = null; setPane = null; setTitle = null; }
        if (setKeyHandler) { document.removeEventListener('keydown', setKeyHandler); setKeyHandler = null; }
        paneHost = null;
    }

    chHead.addEventListener('click', function (e) {
        if ($('spChMenuBtn').contains(e.target)) return;
        toggleServerMenu();
    });
    chHead.addEventListener('keydown', function (e) {
        if (e.target !== chHead) return;
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleServerMenu(); }
    });
    $('spChMenuBtn').addEventListener('click', function (e) {
        e.stopPropagation();
        $('spInviteBtn').click();
    });
    $('spChList').addEventListener('contextmenu', function (e) {
        var cur = state.current;
        if (!cur || e.defaultPrevented) return;
        e.preventDefault();
        openCtx(e.clientX, e.clientY, sidebarMenu(cur));
    });
    $('spChToggle').addEventListener('click', function () { elActive.classList.toggle('chan-open'); });

    /* ---------- права и роли ---------- */
    function permsOfRoleId(cur, rid) {
        if (rid > 0) {
            var r = cur.roles.filter(function (x) { return x.id === rid; })[0];
            if (r) return r.perms;
        }
        return cur.defaultPerms;
    }
    function memberPerms(cur, m) { return m.role === 'owner' ? 63 : permsOfRoleId(cur, m.role_id); }
    // выше ли права цели, чем у меня (владелец «выше» всех)
    function outranks(cur, targetPerms) { return cur.role !== 'owner' && (targetPerms & ~cur.perms) !== 0; }
    function roleOf(cur, m) {
        if (m.role === 'owner') return { name: 'владелец', color: '#f0b232' };
        var r = cur.roles.filter(function (x) { return x.id === m.role_id; })[0];
        return r ? { name: rname(cur, r.id), color: r.color } : { name: DEFAULT_ROLE_NAME, color: '#99aab5' };
    }
    function permSummary(perms) {
        var n = PERM_LIST.filter(function (p) { return perms & p.bit; }).length;
        return n + ' из ' + PERM_LIST.length + ' прав';
    }

    /* ---------- выбор цвета роли: поле «насыщенность/яркость», оттенок, RGB/HEX, пипетка и палитра ---------- */
    var ROLE_COLORS = ['#5865f2', '#8b7cf6', '#b469e0', '#ee5fa7', '#f23f43', '#f07b3f', '#f0b232', '#e6d24a',
                       '#57d28b', '#23a55a', '#1fbfa5', '#3aa0ea', '#4fd0f0', '#99aab5', '#6d7480', '#f2f3f5'];
    function normHex(v) {
        v = String(v || '').trim();
        if (v.charAt(0) !== '#') v = '#' + v;
        if (/^#[0-9a-f]{3}$/i.test(v)) v = '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
        return /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : null;
    }
    function hsv2rgb(h, s, v) {
        function f(n) { var k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); }
        return [Math.round(f(5) * 255), Math.round(f(3) * 255), Math.round(f(1) * 255)];
    }
    function rgb2hsv(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
        if (d) {
            if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
            h *= 60; if (h < 0) h += 360;
        }
        return { h: h, s: mx ? d / mx : 0, v: mx };
    }
    function rgb2hex(r, g, b) { return '#' + [r, g, b].map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
    function hex2rgb(h) { return [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; }

    function buildColorPicker(initial, disabled, nameInput) {
        var wrap = el('div', 'sp-colors' + (disabled ? ' disabled' : ''));
        var input = el('input');                      // скрытое поле: из него код сохранения роли берёт .value
        input.type = 'hidden';

        var H = 0, S = 1, V = 1;

        /* предпросмотр названия роли */
        var preview = el('div', 'sp-color-preview');
        var pDot = el('span', 'sp-role-dot');
        var pName = el('span', 'sp-color-preview-name', 'Название роли');
        preview.appendChild(pDot); preview.appendChild(pName);
        wrap.appendChild(preview);

        /* поле: слева направо — насыщенность, снизу вверх — яркость */
        var area = el('div', 'sp-cp-area');
        area.tabIndex = 0;
        area.setAttribute('role', 'slider');
        area.setAttribute('aria-label', 'Насыщенность и яркость. Стрелки меняют значение');
        var aThumb = el('div', 'sp-cp-thumb');
        area.appendChild(aThumb);
        wrap.appendChild(area);

        /* пипетка, образец, оттенок */
        var mid = el('div', 'sp-cp-mid');
        var eye = null;
        if (window.EyeDropper) {
            eye = el('button', 'sp-cp-eye');
            eye.type = 'button'; eye.title = 'Пипетка: взять цвет с экрана'; eye.disabled = !!disabled;
            eye.innerHTML = ico('<path d="M14.5 6.5l3 3M4 20l1-4 9-9 3 3-9 9z"/><path d="M15.5 5.5l1.2-1.2a2.1 2.1 0 0 1 3 3L18.5 8.5"/>');
            eye.addEventListener('click', function () {
                new window.EyeDropper().open().then(function (r) { setHex(r.sRGBHex); }, function () {});
            });
            mid.appendChild(eye);
        }
        var big = el('span', 'sp-cp-dot');
        mid.appendChild(big);
        var hue = el('div', 'sp-cp-hue');
        hue.tabIndex = 0;
        hue.setAttribute('role', 'slider');
        hue.setAttribute('aria-label', 'Оттенок. Стрелки влево и вправо меняют значение');
        var hThumb = el('div', 'sp-cp-thumb');
        hue.appendChild(hThumb);
        mid.appendChild(hue);
        wrap.appendChild(mid);

        /* HEX и RGB */
        var fields = el('div', 'sp-cp-fields');
        function field(label, cls, attrs) {
            var box = el('label', 'sp-cp-field');
            var inp = el('input', 'sp-input ' + cls);
            inp.type = 'text'; inp.spellcheck = false; inp.disabled = !!disabled;
            if (attrs) Object.keys(attrs).forEach(function (k) { inp.setAttribute(k, attrs[k]); });
            box.appendChild(inp);
            box.appendChild(el('span', 'sp-cp-flabel', label));
            fields.appendChild(box);
            return inp;
        }
        var fHex = field('HEX', 'sp-cp-hex', { maxlength: '7', 'aria-label': 'Код цвета HEX' });
        var fR = field('R', 'sp-cp-num', { inputmode: 'numeric', maxlength: '3', 'aria-label': 'Красный, 0–255' });
        var fG = field('G', 'sp-cp-num', { inputmode: 'numeric', maxlength: '3', 'aria-label': 'Зелёный, 0–255' });
        var fB = field('B', 'sp-cp-num', { inputmode: 'numeric', maxlength: '3', 'aria-label': 'Синий, 0–255' });
        wrap.appendChild(fields);

        /* готовые цвета */
        var grid = el('div', 'sp-color-grid');
        var sw = [];
        ROLE_COLORS.forEach(function (c) {
            var b = el('button', 'sp-swatch');
            b.type = 'button'; b.disabled = !!disabled;
            b.style.setProperty('--c', c);
            b.setAttribute('data-color', c);
            b.setAttribute('aria-label', 'Цвет ' + c);
            b.addEventListener('click', function () { setHex(c); });
            grid.appendChild(b); sw.push(b);
        });
        wrap.appendChild(grid);

        function render(skip) {
            var rgb = hsv2rgb(H, S, V), hx = rgb2hex(rgb[0], rgb[1], rgb[2]);
            input.value = hx;
            area.style.background = 'linear-gradient(to top, #000, rgba(0,0,0,0)), linear-gradient(to right, #fff, rgba(255,255,255,0)), hsl(' + Math.round(H) + ', 100%, 50%)';
            aThumb.style.left = (S * 100) + '%';
            aThumb.style.top = ((1 - V) * 100) + '%';
            aThumb.style.background = hx;
            hThumb.style.left = (H / 360 * 100) + '%';
            hThumb.style.background = 'hsl(' + Math.round(H) + ', 100%, 50%)';
            big.style.background = hx;
            pDot.style.background = hx;
            pName.style.color = hx;
            sw.forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-color') === hx); });
            if (skip !== fHex) fHex.value = hx;
            if (skip !== fR) fR.value = rgb[0];
            if (skip !== fG) fG.value = rgb[1];
            if (skip !== fB) fB.value = rgb[2];
        }
        function setHex(c, skip) {
            var n = normHex(c);
            if (!n) return;
            var rgb = hex2rgb(n), hsv = rgb2hsv(rgb[0], rgb[1], rgb[2]);
            if (hsv.s > 0 && hsv.v > 0) H = hsv.h;       // у серого и чёрного оттенок не определён — оставляем прежний
            S = hsv.s; V = hsv.v;
            render(skip);
        }

        function bindDrag(node, fn) {
            var active = false;
            function at(e) {
                var r = node.getBoundingClientRect();
                fn(Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height)));
            }
            node.addEventListener('pointerdown', function (e) {
                if (disabled) return;
                active = true;
                try { node.setPointerCapture(e.pointerId); } catch (x) {}
                node.focus();
                at(e);
                e.preventDefault();
            });
            node.addEventListener('pointermove', function (e) { if (active) at(e); });
            node.addEventListener('pointerup', function () { active = false; });
            node.addEventListener('pointercancel', function () { active = false; });
        }
        bindDrag(area, function (x, y) { S = x; V = 1 - y; render(); });
        bindDrag(hue, function (x) { H = x * 360; if (H >= 360) H = 359.99; render(); });

        area.addEventListener('keydown', function (e) {
            var st = e.shiftKey ? 0.1 : 0.01, used = true;
            if (e.key === 'ArrowLeft') S = Math.max(0, S - st);
            else if (e.key === 'ArrowRight') S = Math.min(1, S + st);
            else if (e.key === 'ArrowUp') V = Math.min(1, V + st);
            else if (e.key === 'ArrowDown') V = Math.max(0, V - st);
            else used = false;
            if (used) { e.preventDefault(); render(); }
        });
        hue.addEventListener('keydown', function (e) {
            var st = e.shiftKey ? 15 : 2, used = true;
            if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') H = Math.max(0, H - st);
            else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') H = Math.min(359.99, H + st);
            else used = false;
            if (used) { e.preventDefault(); render(); }
        });

        fHex.addEventListener('input', function () { var n = normHex(fHex.value); if (n) setHex(n, fHex); });
        function rgbFromFields() {
            var v = [fR, fG, fB].map(function (f) {
                var n = parseInt(f.value.replace(/\D/g, ''), 10);
                return isNaN(n) ? 0 : Math.max(0, Math.min(255, n));
            });
            return v;
        }
        [fR, fG, fB].forEach(function (f) {
            f.addEventListener('input', function () {
                f.value = f.value.replace(/\D/g, '').slice(0, 3);
                var v = rgbFromFields();
                setHex(rgb2hex(v[0], v[1], v[2]), f);
            });
        });
        [fHex, fR, fG, fB].forEach(function (f) { f.addEventListener('blur', function () { render(); }); });

        function syncName() { pName.textContent = (nameInput && nameInput.value.trim()) || 'Название роли'; }
        if (nameInput) nameInput.addEventListener('input', syncName);
        syncName();
        setHex(normHex(initial) || '#5865f2');
        return { node: wrap, input: input };
    }

    function openRoles() {
        var cur = state.current;
        if (!cur || !can(P.ROLES)) return;
        modal('Роли и права', function (body, close) {
            function members(rid) {
                return cur.info.members.filter(function (m) { return m.role !== 'owner' && m.role_id === rid; }).length;
            }
            function listView() {
                body.textContent = '';
                body.appendChild(el('p', 'sp-hint', 'Здесь настраивается, что можно и чего нельзя каждой роли. Роль участнику назначают в списке «Участники».'));
                var rows = [{ id: 0, name: DEFAULT_ROLE_NAME, color: '#99aab5', perms: cur.defaultPerms, isDefault: true }]
                    .concat(cur.roles.map(function (r) { return { id: r.id, name: rname(cur, r.id), color: r.color, perms: r.perms }; }));
                rows.forEach(function (r) {
                    var b = el('button', 'sp-role-row');
                    b.type = 'button';
                    var dot = el('span', 'sp-role-dot'); dot.style.background = r.color;
                    b.appendChild(dot);
                    var t = el('span', 'sp-role-info');
                    t.appendChild(el('span', 'sp-role-name', r.name + (r.isDefault ? ' (по умолчанию)' : '')));
                    t.appendChild(el('span', 'sp-role-sub', permSummary(r.perms) + ' · ' + members(r.id) + ' ' + plural(members(r.id), 'участник', 'участника', 'участников')));
                    b.appendChild(t);
                    b.appendChild(el('span', 'sp-tpl-arrow', '›'));
                    b.addEventListener('click', function () { editView(r); });
                    body.appendChild(b);
                });
                if (cur.roles.length < 15) {
                    var add = el('button', 'sp-btn primary', 'Создать роль');
                    add.type = 'button';
                    add.addEventListener('click', function () { editView(null); });
                    body.appendChild(add);
                }
            }

            function editView(r) {
                var isNew = !r, isDef = !!(r && r.isDefault);
                var locked = !isNew && outranks(cur, r.perms);          // права роли выше моих — менять нельзя
                body.textContent = '';
                var back = el('button', 'sp-btn sp-role-back', '‹ Назад');
                back.type = 'button';
                back.addEventListener('click', listView);
                body.appendChild(back);

                var nameInput = null, colorInput = null;
                if (!isDef) {
                    body.appendChild(el('label', 'sp-label', 'Название роли'));
                    nameInput = el('input', 'sp-input');
                    nameInput.type = 'text'; nameInput.maxLength = 30; nameInput.placeholder = 'Например, Модератор';
                    nameInput.value = isNew ? '' : r.name;
                    nameInput.disabled = locked;
                    body.appendChild(nameInput);
                    body.appendChild(el('label', 'sp-label', 'Цвет'));
                    var picker = buildColorPicker(isNew ? '#5865f2' : r.color, locked, nameInput);
                    colorInput = picker.input;           // скрытое поле: из него код ниже берёт .value при сохранении
                    body.appendChild(picker.node);
                } else {
                    body.appendChild(el('p', 'sp-hint', 'Эту роль получают все новые участники, пока им не назначена другая.'));
                }
                if (locked) body.appendChild(el('p', 'sp-hint sp-warn', 'У этой роли есть права, которых нет у вас, — менять её нельзя.'));

                body.appendChild(el('label', 'sp-label', 'Права'));
                var boxes = [];
                PERM_LIST.forEach(function (p) {
                    var row = el('label', 'sp-perm');
                    var txt = el('span', 'sp-perm-txt');
                    txt.appendChild(el('b', null, p.title));
                    txt.appendChild(el('small', null, p.desc));
                    var cb = el('input'); cb.type = 'checkbox';
                    cb.checked = isNew ? !!(p.bit & (P.SEND | P.VOICE)) : !!(r.perms & p.bit);
                    // нельзя выдавать права, которых нет у вас; право на роли выдаёт только владелец
                    cb.disabled = locked || !(cur.perms & p.bit) || (p.bit === P.ROLES && cur.role !== 'owner');
                    var sw = el('span', 'sp-switch');
                    row.appendChild(txt); row.appendChild(cb); row.appendChild(sw);
                    body.appendChild(row);
                    boxes.push({ bit: p.bit, cb: cb });
                });

                var actions = el('div', 'sp-row');
                var save = el('button', 'sp-btn primary', isNew ? 'Создать роль' : 'Сохранить');
                save.type = 'button';
                save.disabled = locked;
                actions.appendChild(save);
                if (!isNew && !isDef) {
                    var del = el('button', 'sp-btn danger', 'Удалить');
                    del.type = 'button';
                    del.disabled = locked;
                    del.addEventListener('click', function () {
                        if (!confirm('Удалить роль «' + r.name + '»? Её участники станут «' + DEFAULT_ROLE_NAME + '».')) return;
                        api('role_delete', { space_id: cur.id, id: r.id }).then(function (res) {
                            if (!res.ok) { toast(res.message || 'Не удалось удалить роль.'); return; }
                            reloadInfo().then(listView);
                        });
                    });
                    actions.appendChild(del);
                }
                body.appendChild(actions);

                save.addEventListener('click', function () {
                    var perms = 0;
                    boxes.forEach(function (b) { if (b.cb.checked) perms |= b.bit; });
                    var name = nameInput ? nameInput.value.trim() : '';
                    if (nameInput && !name) { nameInput.focus(); return; }
                    save.disabled = true;
                    var job;
                    if (isDef) {
                        job = api('role_update', { space_id: cur.id, id: 0, perms: perms });
                    } else {
                        var data = { space_id: cur.id, name_enc: name, color: colorInput.value, perms: perms };
                        if (isNew) job = api('role_create', data);
                        else {
                            data.id = r.id;
                            job = api('role_update', data);
                        }
                    }
                    job.then(function (res) {
                        save.disabled = false;
                        if (!res.ok) { toast(res.message || 'Не удалось сохранить.'); return; }
                        toast('Сохранено');
                        reloadInfo().then(listView);
                    });
                });
            }
            listView();
        });
    }

    /* ---------------------------------------------------------------- боты: API-токены */
    function copyText(text, okMsg) {
        var ok = false;
        try {
            var ta = document.createElement('textarea');
            ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
            document.body.appendChild(ta); ta.select();
            ok = document.execCommand('copy');
            ta.remove();
        } catch (e) {}
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(function () { toast(okMsg); }, function () { toast(ok ? okMsg : 'Скопируйте вручную'); });
        } else toast(ok ? okMsg : 'Скопируйте вручную');
    }

    function openBots() {
        var cur = state.current;
        if (!cur) return;
        modal('Боты и API-токены', function (body) {
            var endpoint = location.origin + location.pathname.replace(/[^\/]*$/, '') + 'spaces.php';

            function row(label, value) {
                var wrap = el('div', 'sp-bot-field');
                wrap.appendChild(el('div', 'sp-label', label));
                var box = el('input', 'sp-input');
                box.type = 'text'; box.readOnly = true; box.value = value;
                box.addEventListener('focus', function () { box.select(); });
                wrap.appendChild(box);
                return wrap;
            }

            function listView() {
                body.textContent = '';
                body.appendChild(el('p', 'sp-hint', 'Токен позволяет боту читать и писать в этом пространстве от вашего имени и с вашими правами. Бот не видит чужие пространства и не может менять каналы, роли и участников.'));
                body.appendChild(el('p', 'sp-hint', 'Сообщения автоматически шифруются в базе данных. Используйте поле body в запросе api=send; токен и HTTPS защищайте как обычно.'));

                var list = el('div', 'sp-bot-list');
                body.appendChild(list);
                list.appendChild(el('div', 'sp-hint', 'Загрузка…'));
                api('token_list', { space_id: cur.id }).then(function (res) {
                    list.textContent = '';
                    if (!res.ok) { list.appendChild(el('div', 'sp-hint', res.message || 'Не удалось загрузить токены.')); return; }
                    if (!res.tokens.length) list.appendChild(el('div', 'sp-hint', 'Токенов пока нет.'));
                    res.tokens.forEach(function (t) {
                        var r = el('div', 'sp-member');
                        var mid = el('div', 'sp-member-mid');
                        mid.appendChild(el('div', 'sp-member-name', t.name));
                        mid.appendChild(el('div', 'sp-bot-sub',
                            t.hint + '… · ' + (t.scope === 'write' ? 'чтение и отправка' : 'только чтение') +
                            ' · ' + (t.used ? 'использован ' + fmtTime(t.used) : 'не использовался')));
                        r.appendChild(mid);
                        var del = el('button', 'sp-btn danger', 'Отозвать');
                        del.type = 'button';
                        del.addEventListener('click', function () {
                            if (!confirm('Отозвать токен «' + t.name + '»? Бот сразу перестанет работать.')) return;
                            api('token_revoke', { space_id: cur.id, id: t.id }).then(function (rr) {
                                if (!rr.ok) { toast('Не удалось отозвать токен.'); return; }
                                toast('Токен отозван');
                                listView();
                            });
                        });
                        r.appendChild(del);
                        list.appendChild(r);
                    });
                    var add = el('button', 'sp-btn primary', 'Создать токен');
                    add.type = 'button';
                    add.disabled = res.tokens.length >= res.max;
                    add.addEventListener('click', createView);
                    list.appendChild(add);
                    if (cur.key) {
                        var kb = el('button', 'sp-btn', 'Скопировать старый ключ');
                        kb.type = 'button';
                        kb.addEventListener('click', function () {
                            var raw = getRawKey(cur.id);
                            if (!raw) { toast('Ключ шифрования не найден.'); return; }
                            copyText(raw, 'Ключ скопирован — храните его как пароль');
                        });
                        list.appendChild(kb);
                    }
                    var doc = el('pre', 'sp-code',
                        'POST ' + endpoint + '?api=send\n' +
                        'Authorization: Bearer <токен>\n' +
                        'Content-Type: application/json\n\n' +
                        '{"space_id": ' + cur.id + ', "channel_id": <id канала>, "body": "Текст сообщения"}\n\n' +
                        'Доступно: api=info, api=messages (поле after), api=send.');
                    list.appendChild(doc);
                });
            }

            function createView() {
                body.textContent = '';
                var back = el('button', 'sp-btn sp-role-back', '‹ Назад');
                back.type = 'button';
                back.addEventListener('click', listView);
                body.appendChild(back);

                body.appendChild(el('label', 'sp-label', 'Название бота'));
                var nameInput = el('input', 'sp-input');
                nameInput.type = 'text'; nameInput.maxLength = 40; nameInput.placeholder = 'Например, Бот уведомлений';
                body.appendChild(nameInput);

                body.appendChild(el('label', 'sp-label', 'Доступ'));
                var scope = can(P.SEND) ? 'write' : 'read';
                var types = el('div', 'sp-types');
                function opt(val, title, sub, disabled) {
                    var b = el('button', 'sp-type' + (scope === val ? ' on' : '')); b.type = 'button';
                    b.disabled = !!disabled;
                    var ico = el('span', 'sp-type-ico', val === 'write' ? '✎' : '👁');
                    b.appendChild(ico);
                    var tt = el('span', 'sp-type-txt');
                    tt.appendChild(el('b', null, title)); tt.appendChild(el('small', null, sub));
                    b.appendChild(tt);
                    b.addEventListener('click', function () {
                        scope = val;
                        Array.prototype.forEach.call(types.children, function (c) { c.classList.remove('on'); });
                        b.classList.add('on');
                    });
                    types.appendChild(b);
                }
                opt('read', 'Только чтение', 'Бот читает сообщения');
                opt('write', 'Чтение и отправка', can(P.SEND) ? 'Бот ещё и пишет сообщения' : 'У вас нет права писать', !can(P.SEND));
                body.appendChild(types);

                var go = el('button', 'sp-btn primary', 'Создать токен');
                go.type = 'button';
                body.appendChild(go);
                go.addEventListener('click', function () {
                    var name = nameInput.value.trim();
                    if (!name) { toast('Введите название бота.'); nameInput.focus(); return; }
                    go.disabled = true;
                    api('token_create', { space_id: cur.id, name: name, scope: scope }).then(function (res) {
                        go.disabled = false;
                        if (!res.ok) { toast(res.message || 'Не удалось создать токен.'); return; }
                        shownView(name, res.token);
                    });
                });
                nameInput.focus();
            }

            function shownView(name, token) {
                body.textContent = '';
                body.appendChild(el('p', 'sp-hint', 'Токен бота «' + name + '» создан. Он показывается только сейчас — на сервере хранится лишь его хэш. Если потеряете, отзовите его и создайте новый.'));
                body.appendChild(row('API-токен', token));
                body.appendChild(row('Адрес API', endpoint));
                body.appendChild(row('ID пространства', String(cur.id)));
                var cp = el('button', 'sp-btn primary', 'Скопировать токен');
                cp.type = 'button';
                cp.addEventListener('click', function () { copyText(token, 'Токен скопирован'); });
                body.appendChild(cp);
                var done = el('button', 'sp-btn', 'Готово');
                done.type = 'button';
                done.addEventListener('click', listView);
                body.appendChild(done);
            }

            listView();
        });
    }

    function openMembers() {
        var cur = state.current;
        if (!cur || !cur.info) return;
        modal('Участники', function (body) {
            function render() {
                body.textContent = '';
                cur.info.members.forEach(function (m) {
                    var entry = el('div', 'sp-member-entry');
                    var row = el('div', 'sp-member');
                    row.appendChild(avatarNode(displayName(m), m.avatar, 'sp-avatar'));
                    var mid = el('div', 'sp-member-mid');
                    mid.appendChild(el('div', 'sp-member-name', displayName(m)));
                    var pr = m.id === ME ? myStatus : (m.presence || 'offline');
                    mid.appendChild(el('div', 'sp-pres sp-pres-' + pr, STATUS_LABELS[pr] || STATUS_LABELS.offline));
                    if (m.voice_muted) mid.appendChild(el('div', 'sp-pres', 'Голосовой мут'));
                    var ro = roleOf(cur, m);
                    var tag = el('span', 'sp-role-tag');
                    var dot = el('span', 'sp-role-dot'); dot.style.background = ro.color;
                    tag.appendChild(dot);
                    tag.appendChild(el('span', null, ro.name));
                    mid.appendChild(tag);
                    row.appendChild(mid);
                    entry.appendChild(row);

                    var manageable = m.role !== 'owner' && m.id !== ME && !outranks(cur, memberPerms(cur, m));
                    var tools = null;
                    if (manageable && can(P.ROLES)) {
                        var sel = el('select', 'sp-select sp-select-sm');
                        var o0 = el('option', null, DEFAULT_ROLE_NAME); o0.value = '0'; sel.appendChild(o0);
                        cur.roles.forEach(function (r) {
                            if (outranks(cur, r.perms)) return;
                            var o = el('option', null, rname(cur, r.id)); o.value = String(r.id); sel.appendChild(o);
                        });
                        sel.value = String(m.role_id);
                        sel.addEventListener('change', function () {
                            sel.disabled = true;
                            api('member_set_role', { space_id: cur.id, user_id: m.id, role_id: parseInt(sel.value, 10) || 0 }).then(function (res) {
                                if (!res.ok) { toast(res.message || 'Не удалось назначить роль.'); }
                                return reloadInfo();
                            }).then(render);
                        });
                        row.appendChild(sel);
                    }
                    if (manageable && can(P.KICK)) {
                        tools = el('div', 'sp-member-tools');
                        var nick = el('input', 'sp-input sp-member-nick');
                        nick.type = 'text';
                        nick.maxLength = 32;
                        nick.placeholder = 'Ник на этом сервере';
                        nick.value = m.server_nick || '';
                        var nickSave = el('button', 'sp-btn sp-btn-sm', 'Сохранить ник');
                        nickSave.type = 'button';
                        nickSave.addEventListener('click', function () {
                            nickSave.disabled = true;
                            api('member_nick', { space_id: cur.id, user_id: m.id, nickname: nick.value }).then(function (res) {
                                nickSave.disabled = false;
                                if (!res.ok) { toast(res.message || 'Не удалось изменить ник.'); return; }
                                toast('Ник на сервере сохранён');
                                return reloadInfo().then(render);
                            }).catch(function () { nickSave.disabled = false; toast('Не удалось изменить ник.'); });
                        });
                        tools.appendChild(nick);
                        tools.appendChild(nickSave);

                        var voiceMute = el('button', 'sp-btn sp-btn-sm', m.voice_muted ? 'Снять голосовой мут' : 'Заглушить голос');
                        voiceMute.type = 'button';
                        voiceMute.addEventListener('click', function () {
                            voiceMute.disabled = true;
                            api('member_voice_mute', { space_id: cur.id, user_id: m.id, muted: !m.voice_muted }).then(function (res) {
                                if (!res.ok) { voiceMute.disabled = false; toast(res.message || 'Не удалось изменить мут.'); return; }
                                toast(res.muted ? 'Участник заглушён в голосовых каналах' : 'Голосовой мут снят');
                                return reloadInfo().then(render);
                            }).catch(function () { voiceMute.disabled = false; toast('Не удалось изменить мут.'); });
                        });
                        tools.appendChild(voiceMute);
                        entry.appendChild(tools);
                    }
                    if (manageable && can(P.KICK)) {
                        var kick = el('button', 'sp-btn danger sp-btn-sm', 'Выгнать');
                        kick.type = 'button';
                        kick.addEventListener('click', function () {
                            if (!confirm('Удалить участника «' + displayName(m) + '» из пространства?')) return;
                            api('member_kick', { space_id: cur.id, user_id: m.id }).then(function (res) {
                                if (!res.ok) { toast(res.message || 'Не удалось удалить участника.'); return; }
                                toast('Участник удалён');
                                return reloadInfo().then(render);
                            });
                        });
                        tools.appendChild(kick);
                    }
                    if (manageable && can(P.KICK)) {
                        var ban = el('button', 'sp-btn danger sp-btn-sm', 'Бан на 7 дней');
                        ban.type = 'button';
                        ban.addEventListener('click', function () {
                            if (!confirm('Заблокировать «' + displayName(m) + '» на этом сервере на 7 дней?')) return;
                            ban.disabled = true;
                            api('member_ban', { space_id: cur.id, user_id: m.id }).then(function (res) {
                                if (!res.ok) { ban.disabled = false; toast(res.message || 'Не удалось заблокировать участника.'); return; }
                                toast('Участник заблокирован на 7 дней');
                                return reloadInfo().then(render);
                            }).catch(function () { ban.disabled = false; toast('Не удалось заблокировать участника.'); });
                        });
                        tools.appendChild(ban);
                    }
                    body.appendChild(entry);
                });
            }
            render();
        });
    }

    function openBans() {
        var cur = state.current;
        if (!cur || !can(P.KICK)) return;
        api('ban_list', { space_id: cur.id }).then(function (res) {
            if (!setPane || !setEl || !setEl.isConnected) return;
            setPane.textContent = '';
            var body = el('div', 'sp-set-body');
            body.appendChild(el('p', 'sp-hint', 'Временные баны действуют 7 дней. Разбан позволяет участнику снова присоединиться по приглашению.'));
            if (!res.ok) {
                body.appendChild(el('div', 'sp-warn', res.message || 'Не удалось загрузить список банов.'));
                setPane.appendChild(body);
                return;
            }
            if (!res.bans.length) {
                body.appendChild(el('div', 'sp-set-value', 'Заблокированных участников нет.'));
            }
            res.bans.forEach(function (banInfo) {
                var row = el('div', 'sp-ban-row');
                var details = el('div', 'sp-member-mid');
                details.appendChild(el('div', 'sp-member-name', banInfo.username));
                details.appendChild(el('div', 'sp-pres', 'До ' + banInfo.banned_until));
                row.appendChild(details);
                var unban = el('button', 'sp-btn sp-btn-sm', 'Разбанить');
                unban.type = 'button';
                unban.addEventListener('click', function () {
                    unban.disabled = true;
                    api('member_unban', { space_id: cur.id, user_id: banInfo.user_id }).then(function (result) {
                        if (!result.ok) { unban.disabled = false; toast(result.message || 'Не удалось снять бан.'); return; }
                        toast('Бан снят');
                        renderSettingsSection('bans', 'Баны', false);
                    }).catch(function () { unban.disabled = false; toast('Не удалось снять бан.'); });
                });
                row.appendChild(unban);
                body.appendChild(row);
            });
            setPane.appendChild(body);
        }).catch(function () {
            if (setPane && setEl && setEl.isConnected) {
                setPane.textContent = '';
                var error = el('div', 'sp-set-body');
                error.appendChild(el('div', 'sp-warn', 'Не удалось загрузить список банов. Проверьте подключение и попробуйте снова.'));
                setPane.appendChild(error);
            } else toast('Не удалось загрузить список банов.');
        });
    }

    /* ================================================================ СОЗВОН (WebRTC, каждый с каждым) */
    var ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }] };
    var call = {
        active: false, spaceId: 0, channelId: 0, key: null, stream: null, video: false,
        speakAllowed: false, serverMuted: false, localName: '', peers: {}, avatars: {}, screen: null, cursor: 0, timer: null, busy: false, orphanIce: {}, absent: {}, names: {}
    };
    var elCall = $('spCall'), elGrid = $('spGrid');

    /* ---------------------------------------------------------------- микрофон (панель внизу списка) */
    var MIC_KEY = 'sp_mic_muted';
    var micMuted = false;
    try { micMuted = localStorage.getItem(MIC_KEY) === '1'; } catch (e) {}

    function applyMicToStream() {
        if (call.stream) call.stream.getAudioTracks().forEach(function (t) { t.enabled = !micMuted && !call.serverMuted; });
    }
    function renderMicBtn() {
        var isMuted = micMuted || call.serverMuted;
        var sm = $('spStMic');
        if (sm) {
            sm.classList.toggle('muted', isMuted);
            sm.disabled = call.active && (!call.speakAllowed || call.serverMuted);
            sm.title = call.serverMuted ? 'Вы заглушены модератором' : (sm.disabled ? 'Нет права говорить в этом канале' : (isMuted ? 'Включить микрофон' : 'Выключить микрофон'));
        }
        var b = $('spMeMic');
        if (!b) return;
        var label = isMuted ? 'Включить микрофон' : 'Выключить микрофон';
        b.disabled = call.active && (!call.speakAllowed || call.serverMuted);
        b.classList.toggle('muted', isMuted);
        b.setAttribute('aria-pressed', isMuted ? 'true' : 'false');
        b.title = call.serverMuted ? 'Вы заглушены модератором' : (b.disabled ? 'Нет права говорить в этом канале' : label);
        b.setAttribute('aria-label', b.title);
    }
    /* ---------- космические звуки: выключили / включили микрофон и наушники (синтез, без файлов) ---------- */
    var sfxCtx = null;
    function spaceSound(kind) {      // 'mic-off' | 'mic-on' | 'deaf-off' | 'deaf-on'
        try {
            var AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            if (!sfxCtx) sfxCtx = new AC();
            if (sfxCtx.state === 'suspended') sfxCtx.resume();
            var ctx = sfxCtx, t = ctx.currentTime + 0.01;
            var down = kind === 'mic-off' || kind === 'deaf-off';
            var deep = kind.indexOf('deaf') === 0;
            var hi = deep ? 620 : 980, lo = deep ? 170 : 300, dur = deep ? 0.55 : 0.4;
            var from = down ? hi : lo, to = down ? lo : hi;

            var master = ctx.createGain();
            master.gain.value = 0.2;
            master.connect(ctx.destination);
            // эхо, как в пустоте: задержка с затухающей обратной связью и срезом верхов
            var delay = ctx.createDelay(1); delay.delayTime.value = 0.17;
            var fb = ctx.createGain(); fb.gain.value = 0.38;
            var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2200;
            delay.connect(lp); lp.connect(fb); fb.connect(delay);
            lp.connect(master);

            function voice(type, f0, f1, vol, vib) {
                var o = ctx.createOscillator(), g = ctx.createGain();
                o.type = type;
                o.frequency.setValueAtTime(f0, t);
                o.frequency.exponentialRampToValueAtTime(f1, t + dur);
                if (vib) {                          // лёгкое «мерцание» высоты
                    var lfo = ctx.createOscillator(), lg = ctx.createGain();
                    lfo.frequency.value = 7; lg.gain.value = f0 * 0.012;
                    lfo.connect(lg); lg.connect(o.frequency);
                    lfo.start(t); lfo.stop(t + dur + 0.1);
                }
                g.gain.setValueAtTime(0.0001, t);
                g.gain.exponentialRampToValueAtTime(vol, t + 0.03);
                g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.08);
                o.connect(g); g.connect(master); g.connect(delay);
                o.start(t); o.stop(t + dur + 0.15);
            }
            voice('sine', from, to, 0.9, true);
            voice('triangle', from * 1.5, to * 1.5, 0.25, true);          // квинта сверху — «звёздный» оттенок
            if (deep) voice('sine', from * 0.5, to * 0.5, 0.5, false);    // для наушников — низкий гул
            setTimeout(function () { try { master.disconnect(); delay.disconnect(); } catch (e) {} }, 2600);
        } catch (e) {}
    }

    function setMicMuted(v, silent) {
        if (!v && call.active && call.serverMuted) return;
        var was = micMuted;
        micMuted = !!v;
        if (was !== micMuted && !silent) spaceSound(micMuted ? 'mic-off' : 'mic-on');
        try { localStorage.setItem(MIC_KEY, micMuted ? '1' : '0'); } catch (e) {}
        applyMicToStream();
        renderMicBtn();
        syncControls();
        if (call.active) broadcastVid();
    }

    function setServerMuted(v) {
        v = !!v;
        if (call.serverMuted === v) return;
        call.serverMuted = v;
        applyMicToStream();
        renderMicBtn();
        syncControls();
        if (call.active) broadcastVid();
    }

    /* ---------------------------------------------------------------- наушники (звук собеседников) */
    var DEAF_KEY = 'sp_deafened';
    var deafened = false;                       // при каждой загрузке страницы звук включён
    try { localStorage.removeItem(DEAF_KEY); } catch (e) {}   // чистим состояние, сохранённое прошлой версией

    function applyDeafToPeers() {
        Object.keys(call.peers).forEach(function (uid) {
            var p = call.peers[uid];
            if (!p) return;
            if (p.video) {
                p.video.muted = deafened;
                p.video.volume = getUserVolume(call.spaceId, p.uid) / 100;
            }
            if (p.remote) p.remote.getAudioTracks().forEach(function (track) { track.enabled = !deafened && !p.muted; });
        });
    }
    function renderDeafBtn() {
        var label = deafened ? 'Включить звук' : 'Выключить звук';
        var sd = $('spStDeaf');
        if (sd) { sd.classList.toggle('muted', deafened); sd.title = deafened ? 'Включить звук' : 'Выключить звук'; }
        var b = $('spMeDeaf');
        if (b) {
            b.classList.toggle('muted', deafened);
            b.setAttribute('aria-pressed', deafened ? 'true' : 'false');
            b.title = label;
            b.setAttribute('aria-label', label);
        }
        var c = $('spDeafBtn');
        if (c) {
            c.classList.toggle('off', deafened);
            c.textContent = deafened ? 'Звук выкл.' : 'Звук';
        }
    }
    function setDeafened(v, silent) {
        var was = deafened;
        deafened = !!v;
        if (was !== deafened && !silent) spaceSound(deafened ? 'deaf-off' : 'deaf-on');
        applyDeafToPeers();
        renderDeafBtn();
        updateLocalTile();
        if (call.active) broadcastVid();
    }

    /* ---------------------------------------------------------------- возврат в голосовой канал после F5 */
    var RESUME_KEY = 'sp_call_resume:' + ME;
    var RESUME_TTL = 90 * 1000;          // дольше этого страница считается закрытой, а не обновлённой
    var pendingResume = null;
    function saveResume() {
        if (!call.active) return;
        try { sessionStorage.setItem(RESUME_KEY, JSON.stringify({ s: call.spaceId, c: call.channelId, v: !!call.video, t: Date.now() })); } catch (e) {}
    }
    function clearResume() { try { sessionStorage.removeItem(RESUME_KEY); } catch (e) {} }
    function readResume() {
        try {
            var r = JSON.parse(sessionStorage.getItem(RESUME_KEY) || 'null');
            if (r && r.s && Date.now() - r.t < RESUME_TTL) return r;
        } catch (e) {}
        clearResume();
        return null;
    }

    // Почему нет доступа к микрофону: браузер отдаёт mediaDevices только на https (или localhost)
    function micUnavailableMsg(forTest) {
        var what = forTest ? 'Для проверки микрофона' : 'Для созвонов';
        if (window.isSecureContext === false) {
            return what + ' откройте сайт по https:// (сейчас адрес не защищён, и браузер блокирует микрофон).';
        }
        return what + ' нужен браузер с поддержкой микрофона. Попробуйте Chrome, Edge, Firefox или Safari последней версии.';
    }

    // Почему браузер отказал: запрет политики сервера, блокировка сайта или просто не нажали «Разрешить»
    function micDenialHint() {
        try {
            var pol = document.permissionsPolicy || document.featurePolicy;
            if (pol && typeof pol.allowsFeature === 'function' && !pol.allowsFeature('microphone')) return Promise.resolve('policy');
        } catch (e) {}
        try {
            if (navigator.permissions && navigator.permissions.query) {
                return navigator.permissions.query({ name: 'microphone' })
                    .then(function (st) { return st && st.state ? st.state : 'unknown'; })
                    .catch(function () { return 'unknown'; });
            }
        } catch (e) {}
        return Promise.resolve('unknown');
    }

    function deviceErrorMsg(err, hint, video) {
        var name = String(err && err.name || '');
        var dev = video ? 'микрофон и камеру' : 'микрофон';
        if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || name === 'SecurityError') {
            if (hint === 'policy') return 'Сервер запрещает микрофон заголовком Permissions-Policy. Нужно разрешить: microphone=(self).';
            if (hint === 'granted') return 'Доступ разрешён, но браузер ещё не применил его. Обновите страницу (F5) и зайдите в канал снова.';
            if (hint === 'denied') return 'Доступ заблокирован для этого сайта. Нажмите на значок слева от адреса, включите ' + dev + ' и обновите страницу (F5).';
            return 'Разрешите доступ в окне браузера и зайдите в канал ещё раз.';
        }
        if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return 'Устройство не найдено. Подключите ' + dev + ' и попробуйте ещё раз.';
        if (name === 'NotReadableError' || name === 'TrackStartError' || name === 'AbortError') return 'Устройство занято другим приложением. Закройте его и попробуйте ещё раз.';
        return 'Не удалось включить устройства.';
    }

    // Некоторые устройства не принимают настройки звука/видео: пробуем без них
    function getDevices(video, audioAllowed) {
        var audio = audioAllowed ? { echoCancellation: true, noiseSuppression: noiseOn } : false;
        return navigator.mediaDevices.getUserMedia({ audio: audio, video: video ? { width: 640, height: 480 } : false })
            .catch(function (err) {
                if (err && err.name === 'OverconstrainedError') return navigator.mediaDevices.getUserMedia({ audio: !!audioAllowed, video: !!video });
                throw err;
            });
    }

    function startCall(video, channelId) {
        var cur = state.current;
        if (!cur || call.active) return;
        channelId = channelId | 0;
        if (!canChannelAction(cur, channelId, 'voice', CHANNEL_PERMISSION.CONNECT)) {
            toast('У вас нет права подключаться к этому голосовому каналу.');
            return;
        }
        var speakAllowed = canChannelAction(cur, channelId, 'voice', CHANNEL_PERMISSION.SPEAK);
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            toast(micUnavailableMsg(false));
            return;
        }
        getDevices(video, speakAllowed)
            .then(function (stream) {
                return api('call_join', { space_id: cur.id, channel_id: channelId }).then(function (res) {
                    if (!res.ok) {
                        stream.getTracks().forEach(function (t) { t.stop(); });
                        toast(res.message || 'Не удалось подключиться к созвону.');
                        return;
                    }
                    call.active = true;
                    call.spaceId = cur.id;
                    call.channelId = channelId;
                    call.key = cur.key || null;
                    call.speakAllowed = speakAllowed;
                    call.serverMuted = !!res.muted;
                    var self = cur.info && cur.info.members && cur.info.members.find(function (m) { return m.id === ME; });
                    call.localName = self ? displayName(self) : (CFG.username || 'Имя');
                    call.stream = stream;
                    if (speakAllowed && !call.serverMuted) setMicMuted(false, true);
                    else applyMicToStream();
                    renderMicBtn();
                    call.video = !!video;
                    call.peers = {};
                    call.names = {};
                    call.avatars = {};
                    call.orphanIce = {};
                    call.absent = {};
                    call.cursor = res.cursor;
                    elCall.hidden = false;
                    setStage(true);
                    $('spCallTitle').textContent = '🔊 ' + voiceName(cur, channelId);
                    call.label = voiceName(cur, channelId);
                    call.spaceName = cur.name;
                    renderVoiceBar();
                    buildLocalTile();
                    syncControls();
                    res.participants.forEach(function (p) {
                        call.names[p.user_id] = p.display_name || p.username;
                        call.avatars[p.user_id] = p.avatar;
                        var peer = createPeer(p.user_id, true);
                        peer.muted = !!p.muted;
                        paintRemoteTile(peer);
                    });
                    saveResume();
                    netHist = []; netLastPeers = [];
                    call.timer = setInterval(pollCall, 1000);
                    renderChannels();
                    fetchMessages(false);
                });
            })
            .catch(function (err) {
                clearResume();
                micDenialHint().then(function (hint) { toast(deviceErrorMsg(err, hint, video)); });
            });
    }

    function sendSignal(to, obj) {
        if (!call.active) return Promise.resolve();
        return api('call_signal', { space_id: call.spaceId, to: to, payload: JSON.stringify(obj) });
    }

    function createPeer(uid, initiator) {
        var previous = call.peers[uid];
        closePeer(uid, true);
        var pc = new RTCPeerConnection(ICE);
        var peer = {
            uid: uid, pc: pc, hasRemote: false, pending: [], tile: previous ? previous.tile : null,
            video: previous ? previous.video : null, remote: new MediaStream()
        };
        call.peers[uid] = peer;

        call.stream.getTracks().forEach(function (t) { pc.addTrack(t, call.stream); });
        if (!call.stream.getVideoTracks().length) pc.addTransceiver('video', { direction: 'sendrecv' });   // место под демонстрацию экрана

        pc.ontrack = function (e) {
            ensureTile(uid);
            var cp = call.peers[uid];
            if (!cp) return;
            if (e.track.kind === 'audio') e.track.enabled = !deafened && !cp.muted;
            if (cp.remote.getTracks().indexOf(e.track) === -1) cp.remote.addTrack(e.track);
            if (cp.video && cp.video.srcObject !== cp.remote) cp.video.srcObject = cp.remote;
        };
        pc.onicecandidate = function (e) {
            if (e.candidate) sendSignal(uid, { k: 'ice', c: e.candidate.toJSON() });
        };
        pc.onconnectionstatechange = function () {
            var st = pc.connectionState;
            if (peer.tile) peer.tile.classList.toggle('connecting', st !== 'connected');
            if (st === 'connected') {                      // новичок сразу узнаёт, что у нас: показ экрана, камера или ничего
                if (call.screen) pushScreenTrack(peer);
                sendSignal(uid, vidState());
            }
        };
        ensureTile(uid);

        if (call.orphanIce[uid]) {
            peer.pending = peer.pending.concat(call.orphanIce[uid]);
            delete call.orphanIce[uid];
        }
        if (initiator) {
            pc.createOffer().then(function (offer) { return pc.setLocalDescription(offer); }).then(function () {
                return sendSignal(uid, { k: 'offer', sdp: pc.localDescription.toJSON() });
            }).catch(function () {});
        }
        return peer;
    }

    function closePeer(uid, keepTile) {
        var p = call.peers[uid];
        if (!p) return;
        try { p.pc.ontrack = p.pc.onicecandidate = p.pc.onconnectionstatechange = null; p.pc.close(); } catch (e) {}
        if (!keepTile && p.tile) p.tile.remove();
        delete call.peers[uid];
    }

    function flushIce(peer) {
        var list = peer.pending; peer.pending = [];
        list.forEach(function (c) { peer.pc.addIceCandidate(c).catch(function () {}); });
    }

    function handleSignal(from, obj) {
        var peer = call.peers[from];
        if (obj.k === 'vid') {
        if (peer) {
            peer.share = !!obj.share; peer.cam = !!obj.cam; peer.muted = !!obj.mic; peer.deaf = !!obj.deaf;
            if (peer.remote) peer.remote.getAudioTracks().forEach(function (track) { track.enabled = !deafened && !peer.muted; });
            paintRemoteTile(peer);
        }
        } else if (obj.k === 'offer') {
            peer = createPeer(from, false);
            peer.pc.setRemoteDescription(obj.sdp).then(function () {
                peer.hasRemote = true; flushIce(peer);
                return peer.pc.createAnswer();
            }).then(function (ans) { return peer.pc.setLocalDescription(ans); }).then(function () {
                return sendSignal(from, { k: 'answer', sdp: peer.pc.localDescription.toJSON() });
            }).catch(function () {});
        } else if (obj.k === 'answer') {
            if (!peer) return;
            peer.pc.setRemoteDescription(obj.sdp).then(function () { peer.hasRemote = true; flushIce(peer); }).catch(function () {});
        } else if (obj.k === 'ice') {
            if (!peer) { (call.orphanIce[from] = call.orphanIce[from] || []).push(obj.c); return; }
            if (peer.hasRemote) peer.pc.addIceCandidate(obj.c).catch(function () {});
            else peer.pending.push(obj.c);
        }
    }

    function pollCall() {
        if (!call.active || call.busy) return;
        call.busy = true;
        var sid = call.spaceId;
        api('call_poll', { space_id: sid, after: call.cursor }).then(function (res) {
            call.busy = false;
            if (!call.active || call.spaceId !== sid) return;
            if (!res.ok) {
                if (res.error === 'forbidden') {
                    toast(res.message || 'Нет права оставаться в этом голосовом канале.');
                    leaveCall();
                }
                return;
            }
            call.cursor = res.cursor;
            saveResume();
            // сигналы обрабатываем по порядку; расшифровка асинхронная, поэтому цепочкой
            var chain = Promise.resolve();
            res.signals.forEach(function (s) {
                chain = chain.then(function () {
                    var payload = String(s.payload || '');
                    if (payload.indexOf('v1.') === 0) {
                        return decryptText(call.key, payload).then(function (plain) {
                            if (plain !== null) {
                                try { handleSignal(s.from, JSON.parse(plain)); } catch (e) {}
                            }
                        });
                    }
                    try { handleSignal(s.from, JSON.parse(payload)); } catch (e) {}
                });
            });
            // кто вышел — убираем плитку (с небольшим запасом по времени)
            var present = {};
            setServerMuted(res.muted);
            res.participants.forEach(function (p) {
                present[p.user_id] = true;
                call.names[p.user_id] = p.display_name || p.username;
                call.avatars[p.user_id] = p.avatar;
                var peer = call.peers[p.user_id];
                if (peer) {
                    peer.muted = !!p.muted;
                    peer.remote.getAudioTracks().forEach(function (track) { track.enabled = !deafened && !peer.muted; });
                    if (peer.tile) {
                        var name = call.names[p.user_id];
                        var nick = peer.tile.querySelector('.sp-tile-ava-nick');
                        var label = peer.tile.querySelector('.sp-tile-name-text');
                        if (nick) nick.textContent = name;
                        if (label) label.textContent = name;
                        paintRemoteTile(peer);
                    }
                }
            });
            Object.keys(call.peers).forEach(function (uid) {
                if (present[uid]) { call.absent[uid] = 0; return; }
                call.absent[uid] = (call.absent[uid] || 0) + 1;
                if (call.absent[uid] >= 4) { closePeer(uid); delete call.absent[uid]; }
            });
            updateGridLayout();
        }).catch(function () { call.busy = false; });
    }

    // пока нет ни камеры, ни показа экрана — по центру плитки аватарка и ник
    function makeTileName(name) {
        var label = el('div', 'sp-tile-name');
        label.appendChild(el('span', 'sp-tile-name-text', name));
        label.appendChild(el('span', 'sp-tile-name-state'));
        return label;
    }

    function paintState(tile, muted, deaf) {
        if (!tile) return;
        var box = tile.querySelector('.sp-tile-name-state');
        if (!box) return;
        box.textContent = '';
        if (muted) {
            var m = el('span', 'sp-tile-name-flag'); m.title = 'Микрофон выключен'; m.appendChild(svgIcon('micoff', 13)); box.appendChild(m);
        }
        if (deaf) {
            var d = el('span', 'sp-tile-name-flag'); d.title = 'Звук выключен'; d.appendChild(svgIcon('deafoff', 13)); box.appendChild(d);
        }
    }

    function makeAva(name, path) {
        var wrap = el('div', 'sp-tile-ava');
        wrap.appendChild(avatarNode(name, path, 'sp-tile-ava-pic'));
        wrap.appendChild(el('div', 'sp-tile-ava-nick', name));
        return wrap;
    }

    function buildLocalTile() {
        elGrid.textContent = '';
        var tile = el('div', 'sp-tile local');
        var v = document.createElement('video');
        v.autoplay = true; v.muted = true; v.playsInline = true;
        v.srcObject = call.stream;
        tile.appendChild(v);
        tile.appendChild(makeAva(call.localName || CFG.username || 'Вы', CFG.avatar));
        tile.appendChild(makeTileName(call.localName || CFG.username || 'Имя'));
        tile.appendChild(el('div', 'sp-tile-voice', '🎙'));
        elGrid.appendChild(tile);
        call.localTile = tile;
        updateLocalTile();
        updateGridLayout();
    }

    function ensureTile(uid) {
        var p = call.peers[uid];
        if (!p || p.tile) return;
        var tile = el('div', 'sp-tile connecting no-video');
        var v = document.createElement('video');
        v.autoplay = true; v.playsInline = true;
        v.muted = deafened;
        tile.appendChild(v);
        tile.appendChild(makeAva(call.names[uid] || ('Участник ' + uid), call.avatars[uid]));
        tile.appendChild(makeTileName(call.names[uid] || ('Участник ' + uid)));
        tile.appendChild(el('div', 'sp-tile-voice', '🎙'));
        tile.appendChild(el('div', 'sp-tile-wait', 'Подключение…'));
        tile.addEventListener('contextmenu', function (e) {
            e.preventDefault();
            openMemberVolumeMenu(e.clientX, e.clientY, call.spaceId, uid, call.names[uid] || ('Участник ' + uid));
        });
        elGrid.appendChild(tile);
        p.tile = tile; p.video = v;
        v.volume = getUserVolume(call.spaceId, uid) / 100;
        updateGridLayout();
    }

    function updateGridLayout() {
        var n = elGrid.children.length;
        elGrid.setAttribute('data-count', String(Math.min(n, 6)));
    }

    function updateLocalTile() {
        if (!call.localTile) return;
        var camOn = !!call.screen || (call.stream && call.stream.getVideoTracks().some(function (t) { return t.enabled; }));
        call.localTile.classList.toggle('no-video', !camOn);
        paintState(call.localTile, micMuted || call.serverMuted, deafened);
    }

    function syncControls() {
        var micOn = call.stream && call.stream.getAudioTracks().some(function (t) { return t.enabled; });
        var hasCam = call.stream && call.stream.getVideoTracks().length > 0;
        var camOn = hasCam && call.stream.getVideoTracks().some(function (t) { return t.enabled; });
        var mb = $('spMicBtn'), cb = $('spCamBtn');
        if (mb) {
            mb.classList.toggle('off', !micOn);
            mb.textContent = micOn ? 'Микрофон' : (call.serverMuted ? 'Мут модератора' : 'Микрофон выкл.');
            mb.disabled = call.active && (!call.speakAllowed || call.serverMuted);
            mb.title = call.serverMuted ? 'Вы заглушены модератором' : '';
        }
        if (cb) { cb.hidden = !hasCam; cb.classList.toggle('off', !camOn); cb.textContent = camOn ? 'Камера' : 'Камера выкл.'; }
        var sc = $('spStCam');
        if (sc) { sc.classList.toggle('off', !camOn); sc.title = camOn ? 'Выключить камеру' : 'Включить камеру'; }
        renderShareBtn();
        updateLocalTile();
    }

    /* ---------------------------------------------------------------- показ экрана: «Весь экран» / «Приложение» */
    function renderShareBtn() {
        var sb = $('spShareBtn');
        if (!sb) return;
        // кнопка в плашке «Голосовая связь подключена»; на телефонах показа экрана в браузере нет
        sb.hidden = !(call.active && navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia);
        sb.classList.toggle('sharing-on', !!call.screen);
        var ss = $('spStShare');
        if (ss) { ss.classList.toggle('sharing-on', !!call.screen); ss.hidden = !(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia); }
        var label = call.screen ? 'Остановить показ экрана' : 'Показ экрана';
        sb.title = label;
        sb.setAttribute('aria-label', label);
    }
    function videoSender(peer) {
        var list = peer.pc.getTransceivers();
        for (var i = 0; i < list.length; i++) {
            var t = list[i];
            if (t.sender && ((t.sender.track && t.sender.track.kind === 'video') || (!t.sender.track && t.receiver && t.receiver.track && t.receiver.track.kind === 'video'))) return t.sender;
        }
        return null;
    }
    function pushScreenTrack(peer) {
        var s = videoSender(peer);
        if (!s || !call.screen) return;
        s.replaceTrack(call.screen.getVideoTracks()[0]).then(function () {
            // потолок битрейта и кадров, иначе WebRTC по умолчанию душит картинку
            var q = SHARE_Q[call.shareQ || shareQ];
            try {
                var prm = s.getParameters();
                if (prm.encodings && prm.encodings.length) {
                    prm.encodings[0].maxBitrate = q.kbps * 1000;
                    prm.encodings[0].maxFramerate = q.fps;
                    prm.degradationPreference = 'maintain-framerate';
                    return s.setParameters(prm);
                }
            } catch (e) {}
        }).catch(function () {});
    }
    function vidState() {
        var cam = !!(call.stream && call.stream.getVideoTracks().some(function (t) { return t.enabled; }));
        return { k: 'vid', share: !!call.screen, cam: cam, mic: !!(micMuted || call.serverMuted), deaf: !!deafened };
    }
    function broadcastVid() {
        Object.keys(call.peers).forEach(function (uid) { sendSignal(uid, vidState()); });
    }
    function paintRemoteTile(peer) {
        if (!peer || !peer.tile) return;
        // пока никто не показывает экран и камера выключена — вместо чёрного квадрата виден двигающийся логотип
        peer.tile.classList.toggle('no-video', !(peer.share || peer.cam));
        peer.tile.classList.toggle('sharing', !!peer.share);
        paintState(peer.tile, peer.muted, peer.deaf);
    }
    function setLocalPreview(stream, sharing) {
        if (!call.localTile) return;
        var v = call.localTile.querySelector('video');
        if (v) v.srcObject = stream;
        call.localTile.classList.toggle('sharing', !!sharing);
    }

    var SHARE_Q = { sd: { w: 1280, h: 720, fps: 30, label: '720p · 30fps', kbps: 2500 }, hd: { w: 1920, h: 1080, fps: 120, label: '1080p · 120fps', kbps: 12000 } };
    var shareQ = 'sd';

    function startShare(kind) {          // kind: 'monitor' (весь экран) | 'window' (приложение)
        if (!call.active || call.screen) return;
        var q = SHARE_Q[shareQ];
        var vc = { displaySurface: kind, width: { ideal: q.w }, height: { ideal: q.h }, frameRate: { ideal: q.fps, max: q.fps } };
        if (kind === 'window') vc.monitorTypeSurfaces = 'exclude';      // в окне выбора только приложения и вкладки (Chrome/Edge)
        navigator.mediaDevices.getDisplayMedia({ video: vc, audio: false, selfBrowserSurface: 'exclude', surfaceSwitching: 'include' })
            .then(function (screen) {
                if (!call.active) { screen.getTracks().forEach(function (t) { t.stop(); }); return; }
                var track = screen.getVideoTracks()[0];
                if (!track) return;
                try { track.contentHint = shareQ === 'hd' ? 'motion' : 'detail'; } catch (e) {}   // HD — плавность важнее резкости
                call.screen = screen;
                call.shareQ = shareQ;
                track.addEventListener('ended', stopShare);             // нажали «Прекратить показ» в браузере
                Object.keys(call.peers).forEach(function (uid) { pushScreenTrack(call.peers[uid]); });
                broadcastVid();
                setLocalPreview(screen, true);
                syncControls();
            })
            .catch(function (err) {
                if (err && err.name === 'NotAllowedError') return;       // человек сам закрыл окно выбора
                toast('Не удалось начать показ экрана.');
            });
    }

    function stopShare() {
        var screen = call.screen;
        if (!screen) return;
        call.screen = null;
        screen.getTracks().forEach(function (t) { t.stop(); });
        var cam = call.stream && call.stream.getVideoTracks()[0];       // вернуть камеру, если была
        Object.keys(call.peers).forEach(function (uid) {
            var s = videoSender(call.peers[uid]);
            if (s) s.replaceTrack(cam || null).catch(function () {});
        });
        broadcastVid();
        setLocalPreview(call.stream, false);
        syncControls();
    }

    /* ---------- камера (вкладка «Устройства») ---------- */
    function setCamTrack(track) {
        var old = call.stream && call.stream.getVideoTracks()[0];
        if (old) { call.stream.removeTrack(old); old.stop(); }
        if (track) call.stream.addTrack(track);
        if (!call.screen) {
            Object.keys(call.peers).forEach(function (uid) {
                var s = videoSender(call.peers[uid]);
                if (s) s.replaceTrack(track || null).catch(function () {});
            });
        }
        call.video = !!track;
        syncControls();
        broadcastVid();
    }
    function useCamera(deviceId) {
        navigator.mediaDevices.getUserMedia({ video: { deviceId: { exact: deviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false })
            .then(function (s) { if (!call.active) { s.getTracks().forEach(function (t) { t.stop(); }); return; } setCamTrack(s.getVideoTracks()[0]); })
            .catch(function () { toast('Не удалось включить камеру.'); });
    }

    /* ---------- окно выбора: Приложения / Весь экран / Устройства ---------- */
    var SVG_NS = 'http://www.w3.org/2000/svg';
    var ICONS = {
        window: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M3 9h18"/><circle cx="6.5" cy="6.5" r=".6" fill="currentColor"/><circle cx="9" cy="6.5" r=".6" fill="currentColor"/>',
        monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
        micoff: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/><line x1="4" y1="4" x2="20" y2="20"/>',
        deafoff: '<path d="M3 15v-3a9 9 0 0 1 18 0v3"/><rect x="3" y="14" width="4" height="7" rx="1.5"/><rect x="17" y="14" width="4" height="7" rx="1.5"/><line x1="4" y1="4" x2="20" y2="20"/>',
        lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        camera: '<path d="M15 8.5V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1.5l5 3.2V5.3z"/>'
    };
    function svgIcon(name, size) {
        var s = document.createElementNS(SVG_NS, 'svg');
        s.setAttribute('viewBox', '0 0 24 24');
        s.setAttribute('width', size || 20); s.setAttribute('height', size || 20);
        s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor');
        s.setAttribute('stroke-width', '2'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
        s.setAttribute('aria-hidden', 'true');
        s.innerHTML = ICONS[name];
        return s;
    }

    function openShareMenu() {
        if (!call.active) return;
        if (call.screen) { stopShare(); return; }
        modal('Показ экрана', function (body, close) {
            var tabs = el('div', 'sp-share-tabs');
            tabs.setAttribute('role', 'tablist');
            var pane = el('div', 'sp-share-pane');
            var foot = el('div', 'sp-share-foot');
            var TABS = [
                { id: 'window', label: 'Приложения', icon: 'window' },
                { id: 'monitor', label: 'Весь экран', icon: 'monitor' },
                { id: 'devices', label: 'Устройства', icon: 'camera' }
            ];
            var btns = {};

            function pickCard(kind, title, text, btnText) {
                pane.textContent = '';
                var card = el('div', 'sp-share-card');
                var ic = el('div', 'sp-share-bigicon');
                ic.appendChild(svgIcon(kind, 44));
                card.appendChild(ic);
                card.appendChild(el('div', 'sp-share-card-title', title));
                card.appendChild(el('div', 'sp-share-card-text', text));
                var go = el('button', 'sp-btn primary', btnText);
                go.type = 'button';
                go.addEventListener('click', function () { close(); startShare(kind); });
                card.appendChild(go);
                pane.appendChild(card);
            }

            function devicesPane() {
                pane.textContent = '';
                var list = el('div', 'sp-share-devs');
                pane.appendChild(list);
                if (!navigator.mediaDevices.enumerateDevices) { list.appendChild(el('div', 'sp-share-card-text', 'Браузер не показывает список устройств.')); return; }
                navigator.mediaDevices.enumerateDevices().then(function (all) {
                    var cams = all.filter(function (d) { return d.kind === 'videoinput'; });
                    var curId = '';
                    var vt = call.stream && call.stream.getVideoTracks()[0];
                    if (vt && vt.getSettings) curId = vt.getSettings().deviceId || '';
                    if (!cams.length) { list.appendChild(el('div', 'sp-share-card-text', 'Камеры не найдены.')); return; }
                    cams.forEach(function (d, i) {
                        var row = el('button', 'sp-share-dev' + (d.deviceId === curId ? ' on' : ''));
                        row.type = 'button';
                        row.appendChild(svgIcon('camera', 22));
                        row.appendChild(el('span', 'sp-share-dev-name', d.label || ('Камера ' + (i + 1))));
                        row.appendChild(el('span', 'sp-share-dev-mark', d.deviceId === curId ? '✓' : ''));
                        row.addEventListener('click', function () { close(); useCamera(d.deviceId); });
                        list.appendChild(row);
                    });
                    if (vt) {
                        var off = el('button', 'sp-share-dev off');
                        off.type = 'button';
                        off.appendChild(el('span', 'sp-share-dev-name', 'Выключить камеру'));
                        off.addEventListener('click', function () { close(); setCamTrack(null); });
                        list.appendChild(off);
                    }
                }).catch(function () { list.appendChild(el('div', 'sp-share-card-text', 'Не удалось получить список камер.')); });
            }

            function show(id) {
                TABS.forEach(function (t) { btns[t.id].classList.toggle('on', t.id === id); btns[t.id].setAttribute('aria-selected', t.id === id ? 'true' : 'false'); });
                foot.hidden = id === 'devices';
                if (id === 'window') pickCard('window', 'Показать приложение', 'Откроется окно выбора браузера: отметьте нужное приложение или вкладку, и участники увидят только его.', 'Выбрать приложение');
                else if (id === 'monitor') pickCard('monitor', 'Показать весь экран', 'Участники увидят всё, что происходит на выбранном экране.', 'Выбрать экран');
                else devicesPane();
            }

            TABS.forEach(function (t) {
                var b = el('button', 'sp-share-tab');
                b.type = 'button';
                b.setAttribute('role', 'tab');
                b.appendChild(svgIcon(t.icon, 18));
                b.appendChild(el('span', '', t.label));
                b.addEventListener('click', function () { show(t.id); });
                btns[t.id] = b;
                tabs.appendChild(b);
            });

            // качество: SD / HD
            var qinfo = el('div', 'sp-share-qinfo');
            var qt = el('div', 'sp-share-qtitle', 'Качество показа');
            var qs = el('div', 'sp-share-qsub');
            qinfo.appendChild(qt); qinfo.appendChild(qs);
            var seg = el('div', 'sp-share-seg');
            function renderQ() {
                qs.textContent = SHARE_Q[shareQ].label;
                Object.keys(segBtns).forEach(function (k) { segBtns[k].classList.toggle('on', k === shareQ); });
            }
            var segBtns = {};
            [['sd', 'SD'], ['hd', 'HD']].forEach(function (q) {
                var b = el('button', 'sp-share-segbtn', q[1]);
                b.type = 'button';
                b.addEventListener('click', function () { shareQ = q[0]; renderQ(); });
                segBtns[q[0]] = b;
                seg.appendChild(b);
            });
            foot.appendChild(qinfo); foot.appendChild(seg);
            renderQ();

            body.appendChild(tabs);
            body.appendChild(pane);
            body.appendChild(foot);
            show('window');
        }, 'sp-modal-share');
    }

    function leaveCall() {
        if (!call.active) return;
        var sid = call.spaceId;
        clearResume();                       // вышли сами — после F5 не возвращаем
        closeNetPanel();
        setStage(false);
        call.active = false;
        call.channelId = 0;
        call.speakAllowed = false;
        call.serverMuted = false;
        call.localName = '';
        renderMicBtn();
        renderVoiceBar();
        renderShareBtn();
        if (call.timer) clearInterval(call.timer);
        call.timer = null;
        Object.keys(call.peers).forEach(function (uid) { closePeer(uid); });
        if (call.screen) { call.screen.getTracks().forEach(function (t) { t.stop(); }); call.screen = null; }
        if (call.stream) call.stream.getTracks().forEach(function (t) { t.stop(); });
        call.stream = null;
        call.localTile = null;
        elGrid.textContent = '';
        elCall.hidden = true;
        api('call_leave', { space_id: sid });
        if (state.current) { renderChannels(); fetchMessages(false); }
    }

    window.addEventListener('pagehide', function (event) {
        if (!call.active || event.persisted) return;
        fetch('spaces.php?api=call_leave', {
            method: 'POST',
            credentials: 'same-origin',
            keepalive: true,
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
            body: JSON.stringify({ space_id: call.spaceId })
        });
    });

    if ($('spHangBtn')) $('spHangBtn').addEventListener('click', leaveCall);

    /* ---------------------------------------------------------------- плашка «Голосовая связь подключена» */
    function renderVoiceBar() {
        var bar = $('spVoiceBar');
        if (!bar) return;
        bar.hidden = !call.active;
        if (call.active) $('spVoiceSub').textContent = (call.label || 'Созвон') + (call.spaceName ? ' · ' + call.spaceName : '');
    }
    if ($('spVoiceLeave')) $('spVoiceLeave').addEventListener('click', leaveCall);
    renderVoiceBar();

    /* ---------------------------------------------------------------- статус: в сети / нет на месте / невидимка */
    var STATUS_LABELS = { online: 'В сети', away: 'Нет на месте', dnd: 'Не беспокоить', invisible: 'Невидимка', offline: 'Не в сети' };
    var STATUS_MENU = [
        { id: 'online', label: '🟢 В сети' },
        { id: 'away', label: '🌙 Нет на месте' },
        { id: 'dnd', label: '⛔ Не беспокоить' },
        { id: 'invisible', label: '⚪ Невидимка' }
    ];
    var myStatus = (CFG.status === 'away' || CFG.status === 'dnd' || CFG.status === 'invisible') ? CFG.status : 'online';

    function renderStatus() {
        var me = $('spMe'), av = $('spMeAvatar');
        if (me) me.setAttribute('data-status', myStatus);
        var st = $('spNetText');
        if (st) st.textContent = STATUS_LABELS[myStatus];
        if (av) av.title = 'Статус: ' + STATUS_LABELS[myStatus] + ' — нажмите, чтобы сменить';
    }
    function setStatus(id) {
        if (id === myStatus) return;
        var prev = myStatus;
        myStatus = id;
        renderStatus();
        api('presence_set', { status: id }).then(function (res) {
            if (!res.ok) { myStatus = prev; renderStatus(); toast('Не удалось сменить статус.'); return; }
            toast(id === 'invisible' ? 'Вы невидимка: другие видят вас не в сети' : 'Статус: ' + STATUS_LABELS[id]);
        });
    }
    function openStatusMenu() {
        var av = $('spMeAvatar');
        if (!av) return;
        var r = av.getBoundingClientRect();
        openCtx(r.left, r.top - 168, STATUS_MENU.map(function (s) {
            return { label: s.label, checked: myStatus === s.id, run: function () { setStatus(s.id); } };
        }));
    }
    if ($('spMeAvatar')) {
        $('spMeAvatar').addEventListener('click', openStatusMenu);
        $('spMeAvatar').addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openStatusMenu(); }
        });
    }
    renderStatus();
    if ($('spMicBtn')) $('spMicBtn').addEventListener('click', function () { setMicMuted(!micMuted); });
    if ($('spMeMic')) $('spMeMic').addEventListener('click', function () { setMicMuted(!micMuted); });
    renderMicBtn();
    if ($('spMeDeaf')) $('spMeDeaf').addEventListener('click', function () { setDeafened(!deafened); });
    if ($('spDeafBtn')) $('spDeafBtn').addEventListener('click', function () { setDeafened(!deafened); });
    renderDeafBtn();
    if ($('spShareBtn')) $('spShareBtn').addEventListener('click', openShareMenu);
    function toggleCamera() {
        if (!call.stream) return;
        var vt = call.stream.getVideoTracks()[0];
        if (vt) { vt.enabled = !vt.enabled; syncControls(); broadcastVid(); return; }
        navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false })
            .then(function (s) { if (!call.active) { s.getTracks().forEach(function (t) { t.stop(); }); return; } setCamTrack(s.getVideoTracks()[0]); })
            .catch(function () { toast('Не удалось включить камеру.'); });
    }
    if ($('spStMic')) $('spStMic').addEventListener('click', function () { setMicMuted(!micMuted); });
    if ($('spStDeaf')) $('spStDeaf').addEventListener('click', function () { setDeafened(!deafened); });
    if ($('spStCam')) $('spStCam').addEventListener('click', toggleCamera);
    if ($('spStShare')) $('spStShare').addEventListener('click', openShareMenu);
    if ($('spStHang')) $('spStHang').addEventListener('click', leaveCall);
    if ($('spCamBtn')) $('spCamBtn').addEventListener('click', function () {
        if (!call.stream) return;
        call.stream.getVideoTracks().forEach(function (t) { t.enabled = !t.enabled; });
        syncControls();
        broadcastVid();
    });

    /* ---------------------------------------------------------------- качество связи */
    (function netMeter() {
        var wrap = $('spMe'), bars = $('spNet');
        if (!wrap) return;
        var samples = [];

        function apply(level, label, ms) {
            wrap.setAttribute('data-level', level);       // цвет точки статуса на аватарке
            netHttpMs = ms;
            if (bars && !call.active) {                    // в созвоне значок ведёт замер самого созвона
                bars.setAttribute('data-level', level);
                bars.title = ms == null ? 'Связь: ' + label : 'Связь: ' + label + ', отклик ' + ms + ' мс';
            }
        }
        function grade(ms) {
            if (ms < 120) return [4, 'Отличная связь'];
            if (ms < 250) return [3, 'Хорошая связь'];
            if (ms < 500) return [2, 'Слабая связь'];
            return [1, 'Очень слабая связь'];
        }
        function offline() { samples = []; apply(0, 'Нет связи', null); }

        function ping() {
            if (document.hidden) return;
            if (navigator.onLine === false) { offline(); return; }
            var ctl = window.AbortController ? new AbortController() : null;
            var timer = setTimeout(function () { if (ctl) ctl.abort(); }, 6000);
            var t0 = performance.now();
            fetch('spaces.php?api=ping', {
                method: 'POST', credentials: 'same-origin', cache: 'no-store',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
                body: '{}', signal: ctl ? ctl.signal : undefined
            }).then(function (r) {
                clearTimeout(timer);
                if (!r.ok) throw new Error('http');
                return r.json();
            }).then(function (d) {
                if (!d || !d.ok) throw new Error('bad');
                samples.push(performance.now() - t0);
                if (samples.length > 3) samples.shift();
                var avg = Math.round(samples.reduce(function (a, b) { return a + b; }, 0) / samples.length);
                var g = grade(avg);
                apply(g[0], g[1], avg);
            }).catch(function () {
                clearTimeout(timer);
                offline();
            });
        }

        window.addEventListener('online', ping);
        window.addEventListener('offline', offline);
        document.addEventListener('visibilitychange', function () { if (!document.hidden) ping(); });
        ping();
        setInterval(ping, 8000);
    })();

    /* ---------------------------------------------------------------- полный экран под шапкой сайта */
    (function fitUnderHeader() {
        var main = document.querySelector('.spaces-main');
        if (!main) return;
        function fit() {
            // приложение начинается сразу под шапкой сайта, без зазора; если шапки не видно (телефон) — от верха экрана
            var top = 0;
            var hdr = document.querySelector('header.header') || document.querySelector('.header');
            if (hdr && getComputedStyle(hdr).display !== 'none') {
                var hb = Math.round(hdr.getBoundingClientRect().bottom);
                if (hb > 0 && hb < window.innerHeight / 2) top = hb;
            }
            document.documentElement.style.setProperty('--sp-top', top + 'px');
        }
        fit();
        window.addEventListener('resize', fit);
        window.addEventListener('load', fit);
        if (window.ResizeObserver) {
            var ro = new ResizeObserver(fit);
            ro.observe(document.body);
            var layout = main.parentNode;
            if (layout) ro.observe(layout);
        }
    })();


    /* ---------------------------------------------------------------- шумоподавление: настройка, анимация, проверка микрофона */
    var NOISE_KEY = 'sp_noise_on';
    var noiseOn = true;
    try { noiseOn = localStorage.getItem(NOISE_KEY) !== '0'; } catch (e) {}

    function applyNoiseTo(stream) {
        if (!stream) return;
        stream.getAudioTracks().forEach(function (t) {
            if (t.applyConstraints) t.applyConstraints({ echoCancellation: true, noiseSuppression: noiseOn }).catch(function () {});
        });
    }
    function setNoise(v) {
        noiseOn = !!v;
        try { localStorage.setItem(NOISE_KEY, noiseOn ? '1' : '0'); } catch (e) {}
        applyNoiseTo(call.stream);      // действует сразу и в идущем созвоне
    }

    function nsRand(seed) { var s = seed; return function () { s = (s * 9301 + 49297) % 233280; return s / 233280; }; }
    function nsNoisy(seed, x0, x1, cy, amp) {
        var r = nsRand(seed), d = 'M' + x0 + ' ' + cy;
        for (var x = x0 + 4; x <= x1; x += 4) d += ' L' + x + ' ' + (cy + (r() - 0.5) * 2 * amp * (0.35 + r() * 0.65)).toFixed(1);
        return d;
    }
    function nsSine(x0, x1, cy, amp, per) {
        var d = 'M' + x0 + ' ' + cy;
        for (var x = x0 + 2; x <= x1; x += 2) d += ' L' + x + ' ' + (cy + Math.sin((x - x0) / per * 6.2832) * amp).toFixed(1);
        return d;
    }

    // SVG-анимация: шумный голос → фильтр → чистый голос (или тот же шум, если выключено)
    function nsAnimSvg() {
        var n1 = nsNoisy(3, 12, 148, 58, 26), n2 = nsNoisy(11, 12, 148, 58, 26), n3 = nsNoisy(27, 12, 148, 58, 26), n4 = nsNoisy(41, 12, 148, 58, 26);
        var o1 = nsNoisy(5, 252, 388, 58, 26), o2 = nsNoisy(17, 252, 388, 58, 26), o3 = nsNoisy(33, 252, 388, 58, 26), o4 = nsNoisy(47, 252, 388, 58, 26);
        var clean = nsSine(212, 428, 58, 15, 36);
        var dots = '', i;
        var ys = [30, 46, 70, 86, 58, 38];
        for (i = 0; i < ys.length; i++) {
            var b = (i * 0.45).toFixed(2) + 's';
            dots += '<circle class="ns-p-on" r="2.6" cy="' + ys[i] + '"><animate attributeName="cx" values="14;156" dur="2.7s" begin="' + b + '" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.12;.8;1" dur="2.7s" begin="' + b + '" repeatCount="indefinite"/></circle>';
            dots += '<circle class="ns-p-off" r="2.6" cy="' + ys[i] + '"><animate attributeName="cx" values="14;386" dur="3.4s" begin="' + b + '" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.9;1" dur="3.4s" begin="' + b + '" repeatCount="indefinite"/></circle>';
        }
        var bars = '';
        [[184, 18], [196, 30], [208, 40], [220, 26], [232, 14]].forEach(function (b2, k) {
            // столбики внутри фильтра «дышат»
            var h = b2[1], y = 58 - h / 2, d = (0.9 + k * 0.13).toFixed(2) + 's';
            bars += '<rect x="' + (b2[0] - 3) + '" width="6" rx="3" fill="#fff"><animate attributeName="height" values="' + h + ';' + (h * 0.35).toFixed(0) + ';' + h + '" dur="' + d + '" repeatCount="indefinite"/><animate attributeName="y" values="' + y + ';' + (58 - h * 0.175).toFixed(1) + ';' + y + '" dur="' + d + '" repeatCount="indefinite"/></rect>';
        });
        function wave(cls, a, b2, c, d2) {
            return '<path class="' + cls + '" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><animate attributeName="d" values="' + a + ';' + b2 + ';' + c + ';' + d2 + ';' + a + '" dur="1.6s" repeatCount="indefinite"/></path>';
        }
        return '<svg viewBox="0 0 400 116" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Как работает шумоподавление">' +
            '<defs>' +
            '<linearGradient id="nsGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5865f2"/><stop offset="1" stop-color="#8e99ff"/></linearGradient>' +
            '<clipPath id="nsClipL"><rect x="8" y="14" width="144" height="88"/></clipPath>' +
            '<clipPath id="nsClipR"><rect x="248" y="14" width="144" height="88"/></clipPath>' +
            '</defs>' +
            '<line x1="8" y1="58" x2="152" y2="58" class="ns-axis"/><line x1="248" y1="58" x2="392" y2="58" class="ns-axis"/>' +
            '<g clip-path="url(#nsClipL)">' + wave('ns-noise', n1, n2, n3, n4) + '</g>' +
            '<g clip-path="url(#nsClipR)">' +
                '<g class="ns-out-noisy">' + wave('ns-noise', o1, o2, o3, o4) + '</g>' +
                '<g class="ns-out-clean"><path class="ns-clean" fill="none" stroke-width="2.6" stroke-linecap="round" d="' + clean + '"><animateTransform attributeName="transform" type="translate" from="0 0" to="36 0" dur="1s" repeatCount="indefinite"/></path></g>' +
            '</g>' +
            '<g class="ns-dots">' + dots + '</g>' +
            '<g class="ns-filter">' +
                '<rect x="160" y="18" width="80" height="80" rx="20" fill="url(#nsGrad)"/>' +
                '<rect class="ns-ring" x="160" y="18" width="80" height="80" rx="20" fill="none" stroke="#8e99ff" stroke-width="2"><animate attributeName="opacity" values=".7;0;.7" dur="2s" repeatCount="indefinite"/><animate attributeName="stroke-width" values="2;10;2" dur="2s" repeatCount="indefinite"/></rect>' +
                bars +
            '</g>' +
            '<text class="ns-cap" x="80" y="112" text-anchor="middle">Голос и шум</text>' +
            '<text class="ns-cap" x="200" y="112" text-anchor="middle">Фильтр</text>' +
            '<text class="ns-cap ns-cap-clean" x="320" y="112" text-anchor="middle">Слышен только голос</text>' +
            '<text class="ns-cap ns-cap-noisy" x="320" y="112" text-anchor="middle">Слышен весь шум</text>' +
            '</svg>';
    }

    function openNoiseSettings() {
        modal('Настройки голоса', function (body, close) {
            // --- переключатель ---
            var head = el('div', 'sp-ns-head');
            head.appendChild(el('div', 'sp-ns-title', 'Шумоподавление'));
            var sw = el('button', 'sp-switch');
            sw.type = 'button';
            sw.setAttribute('role', 'switch');
            sw.appendChild(el('span', 'sp-switch-knob'));
            head.appendChild(sw);
            body.appendChild(head);

            body.appendChild(el('div', 'sp-ns-text', 'Включите шумоподавление: стук клавиш, вентилятор или дождь за окном не попадут в звонок, и собеседники услышат только ваш голос.'));

            // --- SVG-анимация ---
            var anim = el('div', 'sp-ns-anim');
            anim.innerHTML = nsAnimSvg();
            body.appendChild(anim);

            function renderSwitch() {
                sw.classList.toggle('on', noiseOn);
                sw.setAttribute('aria-checked', noiseOn ? 'true' : 'false');
                anim.setAttribute('data-on', noiseOn ? '1' : '0');
            }
            renderSwitch();
            sw.addEventListener('click', function () {
                setNoise(!noiseOn);
                if (testStream) testStream.getAudioTracks().forEach(function (t) { if (t.applyConstraints) t.applyConstraints({ noiseSuppression: noiseOn }).catch(function () {}); });
                renderSwitch();
            });


            // --- проверка микрофона ---
            body.appendChild(el('div', 'sp-ns-sub', 'Проверка микрофона'));
            var row = el('div', 'sp-ns-test');
            var btn = el('button', 'sp-btn', 'Проверка');
            btn.type = 'button';
            var meter = el('div', 'sp-ns-meter');
            var N = 26, cells = [];
            for (var i = 0; i < N; i++) { var c = el('i'); cells.push(c); meter.appendChild(c); }
            row.appendChild(btn); row.appendChild(meter);
            body.appendChild(row);
            var hint = el('div', 'sp-ns-hint', 'Скажите что-нибудь: вы услышите свой голос, а полоски покажут уровень микрофона. На время проверки микрофон и звук собеседников выключаются; после неё их прежнее состояние восстановится.');
            body.appendChild(hint);

            var testStream = null, tctx = null, raf = 0, micMutedBeforeTest = null, deafenedBeforeTest = null;
            function paint(level) {
                var lit = Math.round(level * N);
                for (var k = 0; k < N; k++) cells[k].classList.toggle('on', k < lit);
            }
            function stopTest() {
                if (raf) cancelAnimationFrame(raf);
                raf = 0;
                if (testStream) testStream.getTracks().forEach(function (t) { t.stop(); });
                testStream = null;
                if (tctx) { try { tctx.close(); } catch (e) {} tctx = null; }
                if (micMutedBeforeTest !== null) {
                    setMicMuted(micMutedBeforeTest, true);
                    micMutedBeforeTest = null;
                }
                if (deafenedBeforeTest !== null) {
                    setDeafened(deafenedBeforeTest, true);
                    deafenedBeforeTest = null;
                }
                paint(0);
                btn.textContent = 'Проверка';
            }
            function startTest() {
                var AC = window.AudioContext || window.webkitAudioContext;
                if (!AC || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { toast(micUnavailableMsg(true)); return; }
                navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: noiseOn, autoGainControl: true } }).then(function (s) {
                    if (!body.isConnected) { s.getTracks().forEach(function (t) { t.stop(); }); return; }
                    testStream = s;
                    micMutedBeforeTest = micMuted;
                    deafenedBeforeTest = deafened;
                    if (call.active) setMicMuted(true, true);
                    if (!deafened) setDeafened(true, true);
                    tctx = new AC();
                    var an = tctx.createAnalyser();
                    an.fftSize = 512;
                    var src = tctx.createMediaStreamSource(s);
                    src.connect(an);
                    var monitor = tctx.createGain();
                    monitor.gain.value = 1;
                    src.connect(monitor);
                    monitor.connect(tctx.destination);
                    if (tctx.state === 'suspended') tctx.resume();
                    var buf = new Uint8Array(an.fftSize), smooth = 0;
                    btn.textContent = 'Остановить';
                    (function loop() {
                        if (!body.isConnected || !testStream) { stopTest(); return; }   // окно закрыли — выключаем микрофон
                        an.getByteTimeDomainData(buf);
                        var sum = 0;
                        for (var k = 0; k < buf.length; k++) { var v = (buf[k] - 128) / 128; sum += v * v; }
                        var lvl = Math.min(1, Math.sqrt(sum / buf.length) * 4.5);
                        smooth = lvl > smooth ? lvl : smooth * 0.85;
                        paint(smooth);
                        raf = requestAnimationFrame(loop);
                    })();
                }).catch(function (err) {
                    if (micMutedBeforeTest !== null) {
                        setMicMuted(micMutedBeforeTest, true);
                        micMutedBeforeTest = null;
                    }
                    if (deafenedBeforeTest !== null) {
                        setDeafened(deafenedBeforeTest, true);
                        deafenedBeforeTest = null;
                    }
                    micDenialHint().then(function (hint) { toast(deviceErrorMsg(err, hint, false)); });
                });
            }
            btn.addEventListener('click', function () { if (testStream) stopTest(); else startTest(); });
            paint(0);
        }, 'sp-modal-ns');
    }
    if ($('spMeSet')) $('spMeSet').addEventListener('click', openNoiseSettings);


    /* ---------------------------------------------------------------- состояние связи (ЛКМ по плашке «Голосовая связь подключена») */
    var netHist = [], NET_MAX = 90, netHttpMs = null, netPanel = null, netLastPeers = [];

    function netGrade(ms, loss) {
        var lv = ms == null ? 0 : ms < 120 ? 4 : ms < 250 ? 3 : ms < 500 ? 2 : 1;
        if (loss > 10) lv = Math.min(lv || 1, 1);
        else if (loss > 3) lv = Math.min(lv || 2, 2);
        return lv;
    }

    function collectNetStats() {
        if (!call.active) return Promise.resolve(null);
        var uids = Object.keys(call.peers);
        if (!uids.length) return Promise.resolve({ ms: netHttpMs, loss: 0, peers: [] });
        return Promise.all(uids.map(function (uid) {
            var p = call.peers[uid];
            return p.pc.getStats().then(function (rep) {
                var info = { name: call.names[uid] || ('Участник ' + uid), state: p.pc.connectionState, local: '', remote: '', rtt: null, loss: 0 };
                var pairId = null, lp = null, rp = null;
                rep.forEach(function (s) { if (s.type === 'transport' && s.selectedCandidatePairId) pairId = s.selectedCandidatePairId; });
                rep.forEach(function (s) {
                    if (s.type === 'candidate-pair' && (s.id === pairId || (!pairId && s.nominated && s.state === 'succeeded'))) {
                        if (typeof s.currentRoundTripTime === 'number') info.rtt = s.currentRoundTripTime * 1000;
                        lp = s.localCandidateId; rp = s.remoteCandidateId;
                    }
                    if (s.type === 'remote-inbound-rtp' && typeof s.fractionLost === 'number') info.loss = Math.max(info.loss, s.fractionLost * 100);
                });
                rep.forEach(function (s) {
                    if (s.id === lp) info.local = s.candidateType || '';
                    if (s.id === rp) info.remote = s.candidateType || '';
                });
                return info;
            }).catch(function () { return null; });
        })).then(function (list) {
            list = list.filter(Boolean);
            var rtts = list.map(function (i) { return i.rtt; }).filter(function (v) { return v != null; });
            var ms = rtts.length ? Math.round(Math.max.apply(null, rtts)) : netHttpMs;
            var loss = list.reduce(function (m, i) { return Math.max(m, i.loss); }, 0);
            return { ms: ms, loss: loss, peers: list };
        });
    }

    function netTick() {
        if (!call.active) return;
        collectNetStats().then(function (r) {
            if (!r || !call.active) return;
            netLastPeers = r.peers;
            if (r.ms == null) return;
            netHist.push({ t: Date.now(), ms: Math.round(r.ms), loss: r.loss });
            if (netHist.length > NET_MAX) netHist.shift();
            var lv = netGrade(r.ms, r.loss), bars = $('spNet');
            if (bars) {
                bars.setAttribute('data-level', lv);
                bars.title = 'Задержка ' + Math.round(r.ms) + ' мс, потери ' + r.loss.toFixed(1) + '%';
            }
            if (netPanel) netPanel.update();
        });
    }
    setInterval(netTick, 2000);

    function closeNetPanel() {
        if (!netPanel) return;
        netPanel.close();
        netPanel = null;
        var b = $('spVoiceMain');
        if (b) b.setAttribute('aria-expanded', 'false');
    }

    function hhmm(ts) { var d = new Date(ts); return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }

    function netGraphSvg() {
        var W = 270, H = 112, L = 4, R = 30, T = 8, B = 22;
        var iw = W - L - R, ih = H - T - B;
        var mx = 100;
        netHist.forEach(function (s) { if (s.ms > mx) mx = Math.ceil(s.ms / 50) * 50; });
        function X(i, n) { return L + (n <= 1 ? iw : iw * i / (n - 1)); }
        function Y(v) { return T + ih - ih * Math.min(v, mx) / mx; }
        var g = '';
        [0, 0.5, 1].forEach(function (f) {
            var y = T + ih - ih * f;
            g += '<line x1="' + L + '" x2="' + (L + iw) + '" y1="' + y + '" y2="' + y + '" class="net-grid"/>' +
                 '<text x="' + (W - 2) + '" y="' + (y + 4) + '" text-anchor="end" class="net-ylab">' + Math.round(mx * f) + '</text>';
        });
        var n = netHist.length;
        if (n >= 2) {
            var d = '';
            netHist.forEach(function (s, i) { d += (i ? ' L' : 'M') + X(i, n).toFixed(1) + ' ' + Y(s.ms).toFixed(1); });
            g += '<path d="' + d + '" class="net-line"/>';
            [0, Math.round((n - 1) / 3), Math.round((n - 1) * 2 / 3), n - 1].forEach(function (i, k, arr) {
                if (k && i === arr[k - 1]) return;
                g += '<text x="' + X(i, n).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="' + (k === 0 ? 'start' : k === arr.length - 1 ? 'end' : 'middle') + '" class="net-xlab">' + hhmm(netHist[i].t) + '</text>';
            });
        } else if (n === 1) {
            g += '<circle cx="' + X(0, 1) + '" cy="' + Y(netHist[0].ms) + '" r="3" class="net-dot"/>';
        } else {
            g += '<text x="' + (L + iw / 2) + '" y="' + (T + ih / 2 + 4) + '" text-anchor="middle" class="net-xlab">Идёт замер…</text>';
        }
        return '<svg viewBox="0 0 ' + W + ' ' + H + '" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="График задержки">' + g + '</svg>';
    }

    function netDebugText() {
        var cand = { host: 'в одной сети', srflx: 'через STUN', prflx: 'через STUN', relay: 'через ретранслятор' };
        if (!netLastPeers.length) return 'Других участников в созвоне нет — показана задержка до сервера сайта.';
        return netLastPeers.map(function (i) {
            var how = i.local ? (cand[i.local] || i.local) : '—';
            return i.name + ': ' + i.state + ' · ' + how + ' · RTT ' + (i.rtt == null ? '—' : Math.round(i.rtt) + ' мс') + ' · потери ' + i.loss.toFixed(1) + '%';
        }).join('\n');
    }

    function downloadNetLog() {
        var lines = ['Журнал связи — ' + new Date().toISOString(), 'Канал: ' + (call.label || ''), ''];
        netHist.forEach(function (s) { lines.push(new Date(s.t).toISOString() + '  задержка ' + s.ms + ' мс  потери ' + s.loss.toFixed(1) + '%'); });
        lines.push('', 'Соединения:', netDebugText());
        var blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'spaces-call-log.txt';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
    }

    function openNetPanel() {
        var anchor = $('spVoiceBar');
        if (!anchor || !call.active) return;
        var box = el('div', 'sp-pop sp-netpop');
        box.setAttribute('role', 'dialog');
        box.setAttribute('aria-label', 'Состояние связи');
        var tab = el('div', 'sp-pop-tab', 'Связь');
        var graph = el('div', 'sp-net-graph');
        var title = el('div', 'sp-net-title');
        var stats = el('div', 'sp-net-stats');
        var hint = el('div', 'sp-net-hint', 'При задержке 250 мс или больше звук может отставать. При потере более 10% исходящих пакетов ваш голос может искажаться. Если проблема не исчезнет, отключитесь и повторите попытку.');
        var dbg = el('pre', 'sp-net-debug'); dbg.hidden = true;
        var row = el('div', 'sp-net-btns');
        var bDbg = el('button', 'sp-btn', 'Отладка'); bDbg.type = 'button';
        var bLog = el('button', 'sp-btn', 'Загрузить журнал'); bLog.type = 'button';
        row.appendChild(bDbg); row.appendChild(bLog);
        var foot = el('div', 'sp-net-foot');
        foot.appendChild(svgIcon('lock', 14));
        foot.appendChild(el('span', '', 'Сообщения шифруются при хранении · медиа звонков защищены WebRTC'));
        [tab, graph, title, stats, hint, dbg, row, foot].forEach(function (n) { box.appendChild(n); });

        function line(label, val) {
            var d = el('div', 'sp-net-line');
            d.appendChild(el('b', '', label + ': '));
            d.appendChild(document.createTextNode(val));
            return d;
        }
        function update() {
            graph.innerHTML = netGraphSvg();
            title.textContent = (call.label || 'Созвон') + ' · напрямую между участниками';
            var vals = netHist.map(function (s) { return s.ms; });
            var avg = vals.length ? Math.round(vals.reduce(function (a, b) { return a + b; }, 0) / vals.length) : null;
            var last = netHist.length ? netHist[netHist.length - 1] : null;
            stats.textContent = '';
            stats.appendChild(line('Средняя задержка', avg == null ? '—' : avg + ' мс'));
            stats.appendChild(line('Последняя задержка', last ? last.ms + ' мс' : '—'));
            stats.appendChild(line('Потеря исходящих пакетов', last ? last.loss.toFixed(1) + '%' : '—'));
            if (!dbg.hidden) dbg.textContent = netDebugText();
        }
        bDbg.addEventListener('click', function () { dbg.hidden = !dbg.hidden; bDbg.classList.toggle('on', !dbg.hidden); update(); });
        bLog.addEventListener('click', downloadNetLog);

        document.body.appendChild(box);
        var r = anchor.getBoundingClientRect();
        var w = Math.max(280, Math.min(340, r.width));
        box.style.width = w + 'px';
        box.style.left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8)) + 'px';
        box.style.bottom = Math.max(8, window.innerHeight - r.top + 8) + 'px';

        function outside(e) { if (!box.contains(e.target) && !$('spVoiceMain').contains(e.target)) closeNetPanel(); }
        function onKey(e) { if (e.key === 'Escape') closeNetPanel(); }
        document.addEventListener('mousedown', outside, true);
        document.addEventListener('keydown', onKey, true);
        window.addEventListener('resize', closeNetPanel);
        netPanel = {
            update: update,
            close: function () {
                document.removeEventListener('mousedown', outside, true);
                document.removeEventListener('keydown', onKey, true);
                window.removeEventListener('resize', closeNetPanel);
                box.remove();
            }
        };
        $('spVoiceMain').setAttribute('aria-expanded', 'true');
        update();
        netTick();
    }

    if ($('spVoiceMain')) $('spVoiceMain').addEventListener('click', function () {
        if (netPanel) closeNetPanel(); else openNetPanel();
    });

    /* ================================================================ КАК В DISCORD: ПКМ-МЕНЮ, ОТВЕТЫ, ПРАВКА, УВЕДОМЛЕНИЯ ================================================================ */
    Object.assign(ICONS, {
        reply:    ico('<path d="M9 7L4 12l5 5"/><path d="M4 12h9a7 7 0 0 1 7 7"/>'),
        edit:     ico('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>'),
        mention:  ico('<circle cx="12" cy="12" r="3.5"/><path d="M15.5 12v1.2a2.3 2.3 0 0 0 4.5 0V12a8 8 0 1 0-3.2 6.4"/>'),
        bell:     ico('<path d="M6 9a6 6 0 0 1 12 0c0 5 2 6.5 2 6.5H4S6 14 6 9z"/><path d="M10 19a2 2 0 0 0 4 0"/>'),
        bellOff:  ico('<path d="M6.5 6.5A6 6 0 0 1 18 9c0 3 .8 4.7 1.5 5.7M4 15.5S6 14 6 9"/><path d="M10 19a2 2 0 0 0 4 0"/><path d="M4 4l16 16"/>'),
        check:    ico('<path d="M4.5 12.5l4.5 4.5L19.5 6.5"/>'),
        user:     ico('<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"/>'),
        link:     ico('<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'),
        volume:   ico('<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>'),
        micOff:   ico('<rect x="9" y="3.5" width="6" height="10" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5M4 4l16 16"/>'),
        ban:      ico('<circle cx="12" cy="12" r="8.5"/><path d="M6 6l12 12"/>'),
        more:     ico('<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>'),
        pencil:   ico('<path d="M4 20h4L19 9l-4-4L4 16z"/>')
    });

    function clip(s, n) { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
    function openModalTop(title, build, cls) {          // окна поверх всего, даже если открыт экран «Настройки сервера»
        var saved = paneHost; paneHost = null;
        try { return modal(title, build, cls); } finally { paneHost = saved; }
    }

    /* ---------------------------------------------------------------- настройки уведомлений (хранятся в браузере) */
    var NS_DEF = { enabled: true, sound: true, volume: 70, desktop: true, toast: true, title: true, dnd: true, level: 'all' };
    var NS = (function () {
        var v = lsGet('sp_notify:' + ME, null), o = {};
        for (var k in NS_DEF) o[k] = (v && v[k] !== undefined) ? v[k] : NS_DEF[k];
        return o;
    })();
    function nsSave() { lsSet('sp_notify:' + ME, NS); }
    var NSP = lsGet('sp_notify_spaces:' + ME, {});
    if (!NSP || typeof NSP !== 'object' || Array.isArray(NSP)) NSP = {};
    function nspSave() { lsSet('sp_notify_spaces:' + ME, NSP); }
    function spCfg(sid) { return NSP[sid] || (NSP[sid] = { level: 'default', mute: 0, ch: {} }); }
    function spaceMuted(sid) { var c = NSP[sid]; return !!(c && (c.mute === -1 || (c.mute > 0 && c.mute > Date.now()))); }
    function spaceMuteHint(sid) {
        var c = NSP[sid];
        if (!spaceMuted(sid)) return '';
        return c.mute === -1 ? 'навсегда' : 'до ' + hhmm(c.mute);
    }
    function spaceNameById(sid) { var s = state.spaces.filter(function (x) { return x.id === sid; })[0]; return s ? s.name : ('Сервер #' + sid); }
    function setSpaceMute(sid, ms) {                         // 0 — включить, -1 — навсегда, иначе — на столько миллисекунд
        var c = spCfg(sid);
        c.mute = ms === -1 ? -1 : (ms > 0 ? Date.now() + ms : 0);
        nspSave(); refreshBadges();
        toast(ms === 0 ? 'Уведомления сервера включены' : 'Сервер «' + spaceNameById(sid) + '» заглушён');
        if (ms > 0) setTimeout(refreshBadges, ms + 500 > 2147483000 ? 2147483000 : ms + 500);
    }
    function setSpaceLevel(sid, lvl) { spCfg(sid).level = lvl; nspSave(); }
    function chanLevelSetting(sid, cid) { var c = NSP[sid]; return (c && c.ch && c.ch[cid]) || 'default'; }
    function setChanLevel(sid, cid, lvl) {
        var c = spCfg(sid); if (!c.ch) c.ch = {};
        if (lvl === 'default') delete c.ch[cid]; else c.ch[cid] = lvl;
        nspSave(); toast('Уведомления канала сохранены');
    }
    function levelFor(sid, cid) {
        var cl = chanLevelSetting(sid, cid);
        if (cl !== 'default') return cl;
        var c = NSP[sid];
        if (c && c.level && c.level !== 'default') return c.level;
        return NS.level;
    }
    function chanMutedFor(sid, cid) {
        var list = (state.current && state.current.id === sid) ? state.current.muted : lsGet('space-muted:' + ME + ':' + sid, []);
        return (list || []).indexOf('t' + cid) !== -1;
    }
    var LEVEL_LABELS = { all: 'Все сообщения', mentions: 'Только @упоминания', none: 'Ничего' };

    /* ---------------------------------------------------------------- «прочитано / непрочитано» */
    var readMap = lsGet('sp_read:' + ME, {});
    if (!readMap || typeof readMap !== 'object' || Array.isArray(readMap)) readMap = {};
    var notif = { cursor: 0, ready: false, started: false, unread: {}, mentions: {}, last: {}, hold: null, meta: {}, timer: 0, busy: false };
    function rkey(sid, cid) { return sid + ':' + cid; }
    var readSaveT = 0;
    function saveReads() { clearTimeout(readSaveT); readSaveT = setTimeout(function () { lsSet('sp_read:' + ME, readMap); }, 400); }
    var badgeRaf = 0;
    function refreshBadges() {
        if (badgeRaf) return;
        badgeRaf = requestAnimationFrame(function () {
            badgeRaf = 0;
            renderList();
            if (state.current) renderChannels();
            updateTitle(); updateBell();
        });
    }
    function markRead(sid, cid, id) {
        var k = rkey(sid, cid), changed = false;
        if (id > (readMap[k] || 0)) { readMap[k] = id; saveReads(); }
        if (notif.unread[k]) { delete notif.unread[k]; changed = true; }
        if (notif.mentions[k]) { delete notif.mentions[k]; changed = true; }
        if (changed) refreshBadges();
    }
    function markChannelRead(sid, cid) { markRead(sid, cid, Math.max(notif.last[rkey(sid, cid)] || 0, readMap[rkey(sid, cid)] || 0)); }
    function markSpaceRead(sid) {
        var p = sid + ':';
        Object.keys(notif.unread).concat(Object.keys(notif.mentions)).forEach(function (k) {
            if (k.indexOf(p) === 0) markChannelRead(sid, parseInt(k.slice(p.length), 10) || 0);
        });
        toast('Сервер отмечен как прочитанный');
    }
    function markAllRead() {
        state.spaces.forEach(function (s) { markSpaceRead(s.id); });
        notif.unread = {}; notif.mentions = {}; refreshBadges();
    }
    function spaceBadge(sid) {
        var p = sid + ':', m = 0, u = false, k;
        for (k in notif.mentions) if (k.indexOf(p) === 0) m += notif.mentions[k];
        if (!spaceMuted(sid)) {
            for (k in notif.unread) {
                if (k.indexOf(p) === 0 && !chanMutedFor(sid, parseInt(k.slice(p.length), 10) || 0)) { u = true; break; }
            }
        }
        return { m: m, u: u };
    }
    function chanHasUnread(cur, ch) {
        if (ch.type !== 'text') return false;
        var k = rkey(cur.id, ch.id);
        return !!(notif.mentions[k] || (notif.unread[k] && !isMuted(cur, ch)));
    }
    function totalBadges() {
        var m = 0, u = false;
        state.spaces.forEach(function (s) { var b = spaceBadge(s.id); m += b.m; u = u || b.u; });
        return { m: m, u: u };
    }
    var baseTitle = document.title;
    function updateTitle() {
        var t = totalBadges(), pre = '';
        if (NS.title && NS.enabled) pre = t.m > 0 ? '(' + (t.m > 99 ? '99+' : t.m) + ') ' : (t.u ? '• ' : '');
        document.title = pre + baseTitle;
    }
    function isNearBottom() { return elMsgs.scrollHeight - elMsgs.scrollTop - elMsgs.clientHeight < 160; }
    function chatVisible() {
        var cur = state.current;
        if (!cur || elActive.hidden || document.hidden || !document.hasFocus()) return false;
        if (document.querySelector('.sp-main.stage')) return false;
        if (window.innerWidth <= 900 && elActive.classList.contains('chan-open')) return false;
        return true;
    }
    function isViewing(sid, cid) {
        var cur = state.current;
        if (!cur || cur.id !== sid || !cur.chan || cur.chan.id !== cid) return false;
        return chatVisible() && isNearBottom();
    }
    function markCurrentRead() {
        var cur = state.current;
        if (!cur || !cur.chan || !cur.lastId || !chatVisible() || !isNearBottom()) return;
        var k = rkey(cur.id, cur.chan.id);
        if (notif.hold === k) return;
        notif.last[k] = Math.max(notif.last[k] || 0, cur.lastId);
        markRead(cur.id, cur.chan.id, cur.lastId);
    }

    /* ---------------------------------------------------------------- звук уведомления (синтез, в стиле ваших «космических» звуков, без файлов) */
    function notifySound(kind, force) {                       // 'msg' | 'mention'
        try {
            if (!force && (!NS.enabled || !NS.sound)) return;
            var AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            if (!sfxCtx) sfxCtx = new AC();
            if (sfxCtx.state === 'suspended') sfxCtx.resume();
            var ctx = sfxCtx, t0 = ctx.currentTime + 0.01;
            var master = ctx.createGain();
            master.gain.value = Math.max(0, Math.min(1, NS.volume / 100)) * 0.28;
            master.connect(ctx.destination);
            var delay = ctx.createDelay(1); delay.delayTime.value = 0.16;
            var fb = ctx.createGain(); fb.gain.value = 0.3;
            var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2600;
            delay.connect(lp); lp.connect(fb); fb.connect(delay); lp.connect(master);
            function tone(f, at, dur, vol) {
                ['sine', 'triangle'].forEach(function (type, i) {
                    var o = ctx.createOscillator(), g = ctx.createGain(), s = t0 + at;
                    o.type = type; o.frequency.setValueAtTime(f * (i ? 1.5 : 1), s);
                    g.gain.setValueAtTime(0.0001, s);
                    g.gain.exponentialRampToValueAtTime(vol * (i ? 0.22 : 1), s + 0.02);
                    g.gain.exponentialRampToValueAtTime(0.0001, s + dur);
                    o.connect(g); g.connect(master); g.connect(delay);
                    o.start(s); o.stop(s + dur + 0.05);
                });
            }
            if (kind === 'mention') { tone(784, 0, 0.2, 0.8); tone(1175, 0.11, 0.22, 0.8); tone(1568, 0.23, 0.45, 0.9); }
            else { tone(659, 0, 0.16, 0.7); tone(988, 0.09, 0.34, 0.8); }
            setTimeout(function () { try { master.disconnect(); delay.disconnect(); } catch (e) {} }, 2200);
        } catch (e) {}
    }

    /* ---------------------------------------------------------------- опрос новых сообщений по всем серверам */
    function notifyStart() {
        if (notif.started) return;
        notif.started = true;
        notifyInit();
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) { markCurrentRead(); if (notif.ready) { clearTimeout(notif.timer); notifyTick(); } }
        });
        window.addEventListener('focus', markCurrentRead);
    }
    function notifyInit() {
        api('notify_poll', { after: 0 }).then(function (res) {
            if (!res || !res.ok) { notif.timer = setTimeout(notifyInit, 8000); return; }
            notif.cursor = res.cursor | 0;
            var last = res.last || {};
            Object.keys(last).forEach(function (k) {
                notif.last[k] = last[k];
                if (readMap[k] === undefined) readMap[k] = last[k];       // раньше не заходили — считаем прочитанным
                else if (last[k] > readMap[k]) notif.unread[k] = true;
            });
            saveReads(); notif.ready = true; refreshBadges(); notifySchedule();
        });
    }
    function notifySchedule() { clearTimeout(notif.timer); notif.timer = setTimeout(notifyTick, document.hidden ? 9000 : 3500); }
    function notifyTick() {
        if (notif.busy) return;
        notif.busy = true;
        api('notify_poll', { after: notif.cursor }).then(function (res) {
            notif.busy = false;
            if (res && res.ok) {
                notif.cursor = Math.max(notif.cursor, res.cursor | 0);
                if (res.items && res.items.length) return handleIncoming(res.items);
            }
        }).catch(function () { notif.busy = false; }).then(notifySchedule);
    }
    function mySpaceNames(sid) {
        var names = [CFG.username || ''], cur = state.current, nick = '';
        if (cur && cur.id === sid && cur.info) { var me = memberById(cur, ME); nick = me ? (me.server_nick || '') : ''; }
        else if (notif.meta[sid]) nick = notif.meta[sid].nick || '';
        if (nick) names.push(nick);
        return names.filter(Boolean);
    }
    function isWordCh(c) { return !!c && /[A-Za-z0-9_\u00C0-\u024F\u0400-\u04FF]/.test(c); }
    function mentionsAny(text, names) {
        var low = String(text).toLowerCase();
        return names.some(function (n) {
            n = '@' + String(n).toLowerCase();
            var i = low.indexOf(n);
            while (i !== -1) {
                if (!isWordCh(low.charAt(i + n.length))) return true;
                i = low.indexOf(n, i + 1);
            }
            return false;
        });
    }
    function handleIncoming(items) {
        return Promise.all(items.map(function (it) {
            return getKey(it.space_id).then(function (key) { return storedText(key, it.body_enc, null); }).then(function (text) {
                return { it: it, text: text, mention: !!it.reply_to_me || (text !== null && mentionsAny(text, mySpaceNames(it.space_id))) };
            });
        })).then(function (list) {
            var alerts = [];
            list.forEach(function (x) {
                var it = x.it, k = rkey(it.space_id, it.channel_id);
                notif.last[k] = Math.max(notif.last[k] || 0, it.id);
                if (isViewing(it.space_id, it.channel_id)) { if (notif.hold !== k) markRead(it.space_id, it.channel_id, it.id); return; }
                var muted = spaceMuted(it.space_id) || chanMutedFor(it.space_id, it.channel_id);
                if (x.mention) notif.mentions[k] = (notif.mentions[k] || 0) + 1;
                if (!muted) notif.unread[k] = true;
                if (muted || !NS.enabled || (NS.dnd && myStatus === 'dnd')) return;
                var lvl = levelFor(it.space_id, it.channel_id);
                if (lvl === 'all' || (lvl === 'mentions' && x.mention)) alerts.push(x);
            });
            refreshBadges();
            if (alerts.length) deliver(alerts);
        });
    }
    function deliver(alerts) {
        if (NS.sound && !deafened) notifySound(alerts.some(function (x) { return x.mention; }) ? 'mention' : 'msg');
        var shown = alerts.slice(-3);
        return Promise.all(shown.map(function (x) { return ensureMeta(x.it.space_id); })).then(function () {
            shown.forEach(showAlert);
        });
    }
    function ensureMeta(sid) {
        var m = notif.meta[sid];
        if (m && m.p) return m.p;
        if (m && Date.now() - m.t < 300000) return Promise.resolve(m);
        var p = Promise.all([getKey(sid), api('info', { space_id: sid })]).then(function (r) {
            var key = r[0], info = r[1], meta = { t: Date.now(), cn: {}, name: '', nick: '' };
            if (!info || !info.ok) { notif.meta[sid] = meta; return meta; }
            var jobs = [storedText(key, info.name_enc, '').then(function (t) { meta.name = t; })];
            (info.channels || []).forEach(function (c) { jobs.push(storedText(key, c.name_enc, '').then(function (t) { meta.cn[c.id] = t; })); });
            (info.members || []).forEach(function (mm) { if (mm.id === ME) meta.nick = mm.server_nick || ''; });
            return Promise.all(jobs).then(function () { notif.meta[sid] = meta; return meta; });
        }).catch(function () { var meta = { t: Date.now(), cn: {}, name: '', nick: '' }; notif.meta[sid] = meta; return meta; });
        notif.meta[sid] = { t: 0, p: p, cn: {}, name: '', nick: '' };
        return p;
    }
    function goTo(sid, cid) {
        function pick() {
            var cur = state.current;
            if (!cur || cur.id !== sid) return;
            var ch = cur.channels.filter(function (c) { return c.id === cid && c.type === 'text'; })[0] || (cid === 0 ? { id: 0, type: 'text', access: null } : null);
            if (ch) selectTextChannel(ch);
        }
        if (state.current && state.current.id === sid) { showView(true); pick(); return; }
        openSpace(sid);
        var tries = 0;
        (function wait() {
            var cur = state.current;
            if (cur && cur.id === sid && cur.info && cur.chan) { pick(); return; }
            if (++tries < 40) setTimeout(wait, 150);
        })();
    }
    function showAlert(x) {
        var it = x.it, meta = notif.meta[it.space_id] || {};
        var chn = it.channel_id === 0 ? 'общий-чат' : ((meta.cn && meta.cn[it.channel_id]) || 'канал');
        var title = it.display_name + ' · #' + chn + ' · ' + (meta.name || spaceNameById(it.space_id));
        var body = x.text === null ? 'Новое сообщение' : clip(x.text.replace(/\s+/g, ' '), 140);
        var go = function () { window.focus(); goTo(it.space_id, it.channel_id); };
        var focused = !document.hidden && document.hasFocus();
        if (focused) {
            if (NS.toast) noticeToast({ title: title, text: body, name: it.display_name, avatar: it.avatar, mention: x.mention, onClick: go });
        } else {
            var shownDesktop = NS.desktop && desktopNotice(it, title, body, go);
            if (!shownDesktop && NS.toast && !document.hidden) noticeToast({ title: title, text: body, name: it.display_name, avatar: it.avatar, mention: x.mention, onClick: go });
        }
    }
    function desktopNotice(it, title, body, go) {
        try {
            if (!('Notification' in window) || Notification.permission !== 'granted') return false;
            var n = new Notification(title, { body: body, tag: 'sp-' + it.space_id + '-' + it.channel_id, silent: true });
            n.onclick = function () { go(); n.close(); };
            setTimeout(function () { try { n.close(); } catch (e) {} }, 9000);
            return true;
        } catch (e) { return false; }
    }
    var noticeBox = null;
    function noticeToast(o) {
        if (!noticeBox) { noticeBox = el('div', 'sp-notices'); document.body.appendChild(noticeBox); }
        var n = el('div', 'sp-notice' + (o.mention ? ' mention' : ''));
        n.setAttribute('role', 'status');
        n.appendChild(avatarNode(o.name, o.avatar, 'sp-avatar sm'));
        var mid = el('div', 'sp-notice-mid');
        mid.appendChild(el('div', 'sp-notice-title', o.title));
        mid.appendChild(el('div', 'sp-notice-text', o.text));
        n.appendChild(mid);
        var x = el('button', 'sp-notice-x', '✕'); x.type = 'button'; x.setAttribute('aria-label', 'Закрыть');
        n.appendChild(x);
        var timer = 0;
        function kill() { clearTimeout(timer); n.classList.add('hide'); setTimeout(function () { n.remove(); }, 250); }
        function arm() { clearTimeout(timer); timer = setTimeout(kill, 7000); }
        x.addEventListener('click', function (e) { e.stopPropagation(); kill(); });
        n.addEventListener('click', function () { kill(); if (o.onClick) o.onClick(); });
        n.addEventListener('mouseenter', function () { clearTimeout(timer); });
        n.addEventListener('mouseleave', arm);
        noticeBox.appendChild(n);
        while (noticeBox.children.length > 3) noticeBox.firstChild.remove();
        arm();
    }

    /* ---------------------------------------------------------------- участники: поиск, права */
    function memberById(cur, uid) {
        var l = (cur && cur.info && cur.info.members) || [];
        for (var i = 0; i < l.length; i++) if (l[i].id === uid) return l[i];
        return null;
    }
    function memberName(cur, uid, fb) { var m = memberById(cur, uid); return m ? displayName(m) : (fb || ('Участник ' + uid)); }
    function canSendHere(cur) { return !!(cur && cur.chan && canChannelAction(cur, cur.chan.id, 'text', CHANNEL_PERMISSION.SEND)); }
    function canModerateMsg(cur, uid) {
        if (uid === ME) return true;
        if (!can(P.KICK)) return false;
        var m = memberById(cur, uid);
        if (!m) return true;
        if (m.role === 'owner') return false;
        return !outranks(cur, memberPerms(cur, m));
    }

    /* ---------------------------------------------------------------- текст сообщения: ссылки и @упоминания */
    function escRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
    function mentionSource(cur) {
        if (!cur._mre || cur._mre.info !== cur.info) {
            var names = [];
            ((cur.info && cur.info.members) || []).forEach(function (m) {
                if (m.username) names.push(m.username);
                if (m.server_nick) names.push(m.server_nick);
            });
            names = names.filter(function (n, i, a) { return n && a.indexOf(n) === i; }).sort(function (a, b) { return b.length - a.length; });
            cur._mre = { info: cur.info, src: names.length ? '@(' + names.map(escRe).join('|') + ')(?![A-Za-z0-9_\u00C0-\u024F\u0400-\u04FF])' : null };
        }
        return cur._mre.src;
    }
    function memberByHandle(cur, handle) {
        var h = String(handle).toLowerCase(), l = (cur.info && cur.info.members) || [];
        for (var i = 0; i < l.length; i++) {
            if ((l[i].username || '').toLowerCase() === h || (l[i].server_nick || '').toLowerCase() === h) return l[i];
        }
        return null;
    }
    function renderRich(box, text, cur) {
        var urlSrc = '(https?:\\/\\/[^\\s<>"\']+)';
        var ms = cur ? mentionSource(cur) : null;
        var re = new RegExp(ms ? urlSrc + '|' + ms : urlSrc, 'gi');
        var last = 0, m;
        function plain(t) { if (t) box.appendChild(document.createTextNode(t)); }
        while ((m = re.exec(text)) !== null) {
            plain(text.slice(last, m.index));
            if (m[1]) {
                var url = m[1].replace(/[.,;:!?)\]]+$/, '');
                var a = el('a', 'sp-link', url);
                a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow';
                box.appendChild(a);
                plain(m[1].slice(url.length));
            } else {
                var who = memberByHandle(cur, m[2]);
                var sp = el('span', 'sp-mention' + (who && who.id === ME ? ' me' : ''), '@' + m[2]);
                if (who) sp.dataset.uid = String(who.id);
                box.appendChild(sp);
            }
            last = re.lastIndex;
            if (m[0] === '') re.lastIndex++;
        }
        plain(text.slice(last));
    }
    function paintMsgBody(row, info) {
        var cur = state.current;
        var body = row.querySelector('.sp-msg-text');
        if (!cur || !body) return;
        body.textContent = '';
        body.classList.toggle('broken', info.text === null);
        if (info.text === null) body.textContent = '🔒 Старое сообщение зашифровано — нужен ключ';
        else {
            renderRich(body, info.text, cur);
            if (info.edited) body.appendChild(el('span', 'sp-msg-edited', ' (изменено)'));
        }
        var hit = info.user_id !== ME && ((info.text !== null && mentionsAny(info.text, mySpaceNames(cur.id))) || info.replyUid === ME);
        row.classList.toggle('mentioned', !!hit);
    }

    /* ---------------------------------------------------------------- сообщения: отрисовка, ответы, правка, удаление */
    function newDivider() { var d = el('div', 'sp-newdiv'); d.appendChild(el('span', null, 'Новые сообщения')); return d; }
    function beginDivider(cur, ch) {
        var from = readMap[rkey(cur.id, ch)];
        cur.divider = from !== undefined ? { from: from, placed: false } : null;
    }
    function placeDivider(cur, m) {
        var d = cur.divider;
        if (!d || d.placed || m.id <= d.from || m.user_id === ME) return;
        d.placed = true;
        if (elMsgs.children.length) elMsgs.appendChild(newDivider());
    }
    function replyRefNode(cur, m) {
        var box = el('button', 'sp-reply-ref'); box.type = 'button';
        var r = m.reply;
        if (!r || r.gone) { box.classList.add('gone'); box.textContent = '↩ Исходное сообщение удалено'; box.disabled = true; return box; }
        box.appendChild(el('span', 'sp-reply-name', memberName(cur, r.user_id, r.username)));
        var t = el('span', 'sp-reply-text', '…');
        box.appendChild(t);
        storedText(cur.key, r.body_enc, null).then(function (txt) { t.textContent = txt === null ? '🔒 зашифровано' : clip(txt.replace(/\s+/g, ' '), 90); });
        box.addEventListener('click', function (e) { e.stopPropagation(); jumpToMessage(m.reply_to); });
        return box;
    }
    function jumpToMessage(mid) {
        var row = elMsgs.querySelector('[data-mid="' + mid + '"]');
        if (!row) { toast('Сообщение слишком старое — оно не загружено.'); return; }
        row.scrollIntoView({ block: 'center', behavior: 'smooth' });
        row.classList.add('flash');
        setTimeout(function () { row.classList.remove('flash'); }, 1800);
    }
    function msgTools(cur, mid, mine) {
        var t = el('div', 'sp-msg-tools');
        function btn(icon, title, fn) {
            var b = el('button', 'sp-msg-tool'); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title);
            b.innerHTML = icon;                                   // только наши константы ICONS
            b.addEventListener('click', function (e) { e.stopPropagation(); fn(e); });
            t.appendChild(b);
        }
        if (canSendHere(cur)) btn(ICONS.reply, 'Ответить', function () { startReply(mid); });
        if (mine) btn(ICONS.edit, 'Редактировать', function () { startEdit(mid); });
        btn(ICONS.more, 'Ещё', function (e) { var r = e.currentTarget.getBoundingClientRect(); openMessageMenu(r.left, r.bottom + 4, mid, null); });
        return t;
    }
    function appendMessage(m, text) {
        var cur = state.current;
        if (cur.rendered[m.id]) return;
        cur.rendered[m.id] = true;
        if (!cur.msgs) cur.msgs = {};
        var info = {
            id: m.id, ch: cur.chan ? cur.chan.id : 0, user_id: m.user_id, name: displayName(m), username: m.username || '', avatar: m.avatar,
            text: text, ts: m.ts, edited: m.edited_ts || 0, reply_to: m.reply_to || 0, replyUid: (m.reply && m.reply.user_id) || 0
        };
        cur.msgs[m.id] = info;
        var mine = m.user_id === ME;
        var row = el('div', 'sp-msg' + (mine ? ' mine' : ''));
        row.dataset.mid = String(m.id);
        row.dataset.uid = String(m.user_id);
        if (!mine) {
            var av = avatarNode(displayName(m), m.avatar, 'sp-avatar sm sp-who');
            av.dataset.uid = String(m.user_id);
            row.appendChild(av);
        }
        var bub = el('div', 'sp-bubble');
        if (m.reply_to) bub.appendChild(replyRefNode(cur, m));
        var head = el('div', 'sp-msg-head');
        if (!mine) {
            var nm = el('span', 'sp-msg-name sp-who', displayName(m));
            nm.dataset.uid = String(m.user_id);
            head.appendChild(nm);
        }
        head.appendChild(el('span', 'sp-msg-time', fmtTime(m.ts)));
        bub.appendChild(head);
        bub.appendChild(el('div', 'sp-msg-text'));
        bub.appendChild(msgTools(cur, m.id, mine));
        row.appendChild(bub);
        placeDivider(cur, m);
        elMsgs.appendChild(row);
        paintMsgBody(row, info);
        bindMsgRow(row, m.id);
    }
    function bindMsgRow(row, mid) {
        row.addEventListener('contextmenu', function (e) {
            if (e.target.closest && e.target.closest('.sp-msg-edit')) return;      // в поле правки — обычное меню браузера
            e.preventDefault();
            var who = e.target.closest ? e.target.closest('.sp-who, .sp-mention') : null;
            if (who && who.dataset.uid) { openMemberMenu(e.clientX, e.clientY, parseInt(who.dataset.uid, 10)); return; }
            openMessageMenu(e.clientX, e.clientY, mid, e.target);
        });
        row.addEventListener('click', function (e) {
            var who = e.target.closest ? e.target.closest('.sp-who, .sp-mention') : null;
            if (who && who.dataset.uid) openProfile(parseInt(who.dataset.uid, 10));
        });
        longPress(row, function (x, y, target) {
            var who = target && target.closest ? target.closest('.sp-who, .sp-mention') : null;
            if (who && who.dataset.uid) openMemberMenu(x, y, parseInt(who.dataset.uid, 10));
            else openMessageMenu(x, y, mid, target);
        });
    }
    function longPress(node, fn) {                                  // долгое нажатие на телефоне = ПКМ
        var t = 0, sx = 0, sy = 0;
        function cancel() { clearTimeout(t); t = 0; }
        node.addEventListener('touchstart', function (e) {
            if (e.touches.length !== 1) return;
            sx = e.touches[0].clientX; sy = e.touches[0].clientY;
            var target = e.target;
            cancel();
            t = setTimeout(function () { t = 0; fn(sx, sy, target); }, 480);
        }, { passive: true });
        node.addEventListener('touchmove', function (e) {
            if (Math.abs(e.touches[0].clientX - sx) > 10 || Math.abs(e.touches[0].clientY - sy) > 10) cancel();
        }, { passive: true });
        node.addEventListener('touchend', cancel);
        node.addEventListener('touchcancel', cancel);
    }
    function removeMessageRow(cur, mid) {
        var row = elMsgs.querySelector('[data-mid="' + mid + '"]');
        if (row) row.remove();
        if (cur.editing && cur.editing.mid === mid) cur.editing = null;
        if (cur.reply && cur.reply.id === mid) { cur.reply = null; syncReplyBar(); }
        if (cur.msgs) {
            delete cur.msgs[mid];
            Object.keys(cur.msgs).forEach(function (k) {
                var i = cur.msgs[k];
                if (i.reply_to !== mid) return;
                var r = elMsgs.querySelector('[data-mid="' + k + '"] .sp-reply-ref');
                if (r) { r.classList.add('gone'); r.disabled = true; r.textContent = '↩ Исходное сообщение удалено'; }
            });
        }
    }
    function repaintMessage(cur, mid) {
        var row = elMsgs.querySelector('[data-mid="' + mid + '"]');
        if (row && cur.msgs && cur.msgs[mid]) paintMsgBody(row, cur.msgs[mid]);
    }
    // удаления и правки, сделанные другими: сервер присылает «окно» последних id канала и свежие правки
    function syncRemote(cur, ch, res) {
        cur.editSince = cur.editSince || {};
        if (res.window && cur.msgs) {
            var minId = res.window.length ? res.window[res.window.length - 1] : Infinity, set = {};
            res.window.forEach(function (id) { set[id] = true; });
            Object.keys(cur.msgs).forEach(function (k) {
                var id = parseInt(k, 10), i = cur.msgs[k];
                if (i.ch === ch && (id >= minId || minId === Infinity) && !set[id]) removeMessageRow(cur, id);
            });
        }
        (res.edits || []).forEach(function (e) {
            cur.editSince[ch] = Math.max(cur.editSince[ch] || 0, e.edited_ts);
            var info = cur.msgs && cur.msgs[e.id];
            if (!info || info.ch !== ch || (cur.editing && cur.editing.mid === e.id)) return;
            storedText(cur.key, e.body_enc, null).then(function (t) {
                if (t === info.text && info.edited === e.edited_ts) return;
                info.text = t; info.edited = e.edited_ts; repaintMessage(cur, e.id);
            });
        });
    }
    function fetchMessages(first) {
        var cur = state.current;
        if (!cur || !cur.chan || polling) return;
        var id = cur.id, ch = cur.chan.id;
        cur.editSince = cur.editSince || {};
        polling = true;
        api('messages', { space_id: id, channel_id: ch, after: first ? 0 : cur.lastId, edit_since: cur.editSince[ch] || 0 }).then(function (res) {
            polling = false;
            if (!state.current || state.current.id !== id) return;
            if (!res.ok) {
                if (res.error === 'forbidden') { toast('Вы больше не участник.'); closeSpaceView(); loadList(); }
                else if (res.error === 'bad_channel') { reloadInfo(); }
                return;
            }
            if (typeof res.perms === 'number' && res.perms !== cur.perms) { cur.perms = res.perms; renderHead(); renderChannels(); }
            updateVoice(res.voice || {});
            if (!cur.chan || cur.chan.id !== ch) return;            // за время запроса переключили канал
            syncRemote(cur, ch, res);
            if (first) beginDivider(cur, ch);
            if (!res.messages.length) { cur.divider = null; markCurrentRead(); return; }
            return Promise.all(res.messages.map(function (m) {
                return storedText(cur.key, m.body != null ? m.body : m.body_enc, null).then(function (text) { return { m: m, text: text }; });
            })).then(function (items) {
                if (!state.current || state.current.id !== id || !cur.chan || cur.chan.id !== ch) return;
                var nearBottom = elMsgs.scrollHeight - elMsgs.scrollTop - elMsgs.clientHeight < 120;
                items.forEach(function (it) {
                    appendMessage(it.m, it.text);
                    cur.lastId = Math.max(cur.lastId, it.m.id);
                    if (it.m.edited_ts) cur.editSince[ch] = Math.max(cur.editSince[ch] || 0, it.m.edited_ts);
                });
                cur.divider = null;
                if (first || nearBottom) elMsgs.scrollTop = elMsgs.scrollHeight;
                markCurrentRead();
            });
        }).catch(function () { polling = false; });
    }

    /* ---- ответ на сообщение ---- */
    var replyBar = el('div', 'sp-reply-bar');
    replyBar.hidden = true;
    composer.parentNode.insertBefore(replyBar, composer);
    function startReply(mid) {
        var cur = state.current, info = cur && cur.msgs && cur.msgs[mid];
        if (!info || !canSendHere(cur)) return;
        cur.reply = { id: mid, ch: cur.chan.id, name: info.name, text: info.text };
        syncReplyBar();
        input.focus();
    }
    function cancelReply() { var cur = state.current; if (cur) cur.reply = null; syncReplyBar(); }
    function syncReplyBar() {
        var cur = state.current, r = cur && cur.reply;
        if (r && (!cur.chan || cur.chan.id !== r.ch)) { cur.reply = r = null; }
        replyBar.textContent = '';
        replyBar.hidden = !r;
        if (!r) return;
        replyBar.appendChild(el('span', 'sp-reply-bar-label', 'Ответ для '));
        replyBar.appendChild(el('b', null, r.name));
        replyBar.appendChild(el('span', 'sp-reply-bar-text', r.text === null ? '🔒 зашифровано' : clip(String(r.text).replace(/\s+/g, ' '), 80)));
        var x = el('button', 'sp-icon-btn', '✕'); x.type = 'button'; x.title = 'Отменить ответ'; x.setAttribute('aria-label', 'Отменить ответ');
        x.addEventListener('click', function () { cancelReply(); input.focus(); });
        replyBar.appendChild(x);
    }

    /* ---- правка своего сообщения ---- */
    function cancelEdit() {
        var cur = state.current;
        if (!cur || !cur.editing) return;
        var ed = cur.editing; cur.editing = null;
        if (ed.wrap) ed.wrap.remove();
        if (ed.body) ed.body.hidden = false;
    }
    function startEdit(mid) {
        var cur = state.current, info = cur && cur.msgs && cur.msgs[mid];
        if (!info || info.user_id !== ME || info.text === null) return;
        var row = elMsgs.querySelector('[data-mid="' + mid + '"]');
        if (!row) return;
        cancelEdit();
        var body = row.querySelector('.sp-msg-text');
        var wrap = el('div', 'sp-msg-edit');
        var ta = el('textarea', 'sp-msg-edit-input');
        ta.value = info.text; ta.maxLength = 4000; ta.rows = 1;
        var bar = el('div', 'sp-msg-edit-bar');
        bar.appendChild(el('span', 'sp-msg-edit-hint'));
        var bCancel = el('button', 'sp-btn sp-btn-sm', 'Отмена'); bCancel.type = 'button';
        var bSave = el('button', 'sp-btn primary sp-btn-sm', 'Сохранить'); bSave.type = 'button';
        bar.appendChild(bCancel); bar.appendChild(bSave);
        wrap.appendChild(ta); wrap.appendChild(bar);
        body.hidden = true;
        body.parentNode.insertBefore(wrap, body.nextSibling);
        cur.editing = { mid: mid, wrap: wrap, body: body };
        function grow() { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 220) + 'px'; }
        function save() {
            var t = ta.value.trim();
            if (!t) { cancelEdit(); confirmDelete(mid); return; }
            if (t === info.text) { cancelEdit(); return; }
            bSave.disabled = true;
            api('message_edit', { space_id: cur.id, message_id: mid, body: t }).then(function (res) {
                if (!res.ok) { bSave.disabled = false; toast(res.message || 'Не удалось изменить сообщение.'); if (res.error === 'not_found') { cancelEdit(); removeMessageRow(cur, mid); } return; }
                info.text = t; info.edited = Math.floor(Date.now() / 1000);
                cancelEdit(); repaintMessage(cur, mid);
            });
        }
        ta.addEventListener('input', grow);
        ta.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); save(); }
            else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); cancelEdit(); input.focus(); }
        });
        bCancel.addEventListener('click', cancelEdit);
        bSave.addEventListener('click', save);
        grow(); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
    }

    /* ---- удаление ---- */
    function confirmDelete(mid) {
        var cur = state.current, info = cur && cur.msgs && cur.msgs[mid];
        if (!info) return;
        openModalTop('Удалить сообщение', function (body, close) {
            body.appendChild(el('p', 'sp-hint', 'Вы уверены, что хотите удалить это сообщение? Действие нельзя отменить.'));
            var prev = el('div', 'sp-del-preview');
            prev.appendChild(el('div', 'sp-del-name', info.name));
            prev.appendChild(el('div', 'sp-del-text', info.text === null ? '🔒 зашифровано' : clip(info.text, 300)));
            body.appendChild(prev);
            var row = el('div', 'sp-row');
            var no = el('button', 'sp-btn', 'Отмена'); no.type = 'button';
            var yes = el('button', 'sp-btn danger', 'Удалить'); yes.type = 'button';
            row.appendChild(no); row.appendChild(yes); body.appendChild(row);
            no.addEventListener('click', close);
            yes.addEventListener('click', function () {
                yes.disabled = true;
                api('message_delete', { space_id: cur.id, message_id: mid }).then(function (res) {
                    if (!res.ok) { yes.disabled = false; toast(res.message || 'Не удалось удалить сообщение.'); return; }
                    close();
                    if (state.current === cur) removeMessageRow(cur, mid);
                    toast('Сообщение удалено');
                });
            });
            yes.focus();
        });
    }
    function markUnreadFrom(cur, mid) {
        var cid = cur.chan.id, k = rkey(cur.id, cid);
        readMap[k] = Math.max(0, mid - 1); saveReads();
        notif.unread[k] = true; notif.hold = k;
        var old = elMsgs.querySelector('.sp-newdiv'); if (old) old.remove();
        var row = elMsgs.querySelector('[data-mid="' + mid + '"]');
        if (row) elMsgs.insertBefore(newDivider(), row);
        refreshBadges();
        toast('Отмечено как непрочитанное');
    }

    /* ---- вставка в поле ввода и подсказка @упоминаний ---- */
    function insertText(t) {
        if (composer.hidden) { toast('Здесь нельзя писать.'); return; }
        var s = input.selectionStart == null ? input.value.length : input.selectionStart;
        var e = input.selectionEnd == null ? s : input.selectionEnd;
        var before = input.value.slice(0, s), after = input.value.slice(e);
        var pad = before && !/\s$/.test(before) ? ' ' : '';
        input.value = before + pad + t + after;
        var pos = (before + pad + t).length;
        input.focus(); input.setSelectionRange(pos, pos); autoGrow();
    }
    function insertMention(m) { if (m && m.username) insertText('@' + m.username + ' '); }
    var mpop = null, mst = null;
    function closeMentionPop() { if (mpop) { mpop.remove(); mpop = null; } mst = null; }
    function updateMentionPop() {
        var cur = state.current;
        if (!cur || !cur.info || composer.hidden) { closeMentionPop(); return; }
        var pos = input.selectionStart == null ? 0 : input.selectionStart;
        var mm = /(^|\s)@([^\s@]{0,32})$/.exec(input.value.slice(0, pos));
        if (!mm) { closeMentionPop(); return; }
        var q = mm[2].toLowerCase(), start = pos - mm[2].length - 1;
        var list = cur.info.members.filter(function (m) {
            return (m.username || '').toLowerCase().indexOf(q) !== -1 || (m.server_nick || '').toLowerCase().indexOf(q) !== -1;
        }).sort(function (a, b) {
            var ap = (a.username || '').toLowerCase().indexOf(q) === 0 ? 0 : 1, bp = (b.username || '').toLowerCase().indexOf(q) === 0 ? 0 : 1;
            return ap - bp;
        }).slice(0, 8);
        if (!list.length) { closeMentionPop(); return; }
        var index = mst ? Math.min(mst.index, list.length - 1) : 0;
        mst = { list: list, index: index, start: start };
        if (!mpop) { mpop = el('div', 'sp-mpop'); mpop.setAttribute('role', 'listbox'); document.body.appendChild(mpop); }
        mpop.textContent = '';
        mpop.appendChild(el('div', 'sp-mpop-head', 'Участники'));
        list.forEach(function (m, i) {
            var it = el('div', 'sp-mpop-item' + (i === index ? ' on' : ''));
            it.setAttribute('role', 'option');
            it.appendChild(avatarNode(displayName(m), m.avatar, 'sp-avatar xs'));
            it.appendChild(el('span', 'sp-mpop-name', displayName(m)));
            it.appendChild(el('span', 'sp-mpop-handle', '@' + m.username));
            it.addEventListener('mousedown', function (e) { e.preventDefault(); pickMention(i); });
            mpop.appendChild(it);
        });
        var r = input.getBoundingClientRect();
        mpop.style.left = Math.max(8, r.left) + 'px';
        mpop.style.width = Math.min(r.width, 360) + 'px';
        mpop.style.bottom = (window.innerHeight - r.top + 8) + 'px';
    }
    function pickMention(i) {
        if (!mst) return;
        var m = mst.list[i], start = mst.start, pos = input.selectionStart;
        input.value = input.value.slice(0, start) + '@' + m.username + ' ' + input.value.slice(pos);
        var np = start + m.username.length + 2;
        closeMentionPop(); input.focus(); input.setSelectionRange(np, np); autoGrow();
    }
    function mentionKeydown(e) {
        if (!mpop || !mst) return false;
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            mst.index = (mst.index + (e.key === 'ArrowDown' ? 1 : mst.list.length - 1)) % mst.list.length;
            updateMentionPop();
            return true;
        }
        if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); pickMention(mst.index); return true; }
        if (e.key === 'Escape') { e.preventDefault(); closeMentionPop(); return true; }
        return false;
    }
    function composerKeydown(e) {                            // вызывается из общего обработчика поля ввода
        if (mentionKeydown(e)) return true;
        var cur = state.current;
        if (e.key === 'Escape' && cur && cur.reply) { e.preventDefault(); cancelReply(); return true; }
        if (e.key === 'ArrowUp' && !input.value && cur && cur.chan && cur.msgs) {     // стрелка вверх — править своё последнее сообщение
            var rows = elMsgs.querySelectorAll('.sp-msg.mine');
            if (rows.length) { e.preventDefault(); startEdit(parseInt(rows[rows.length - 1].dataset.mid, 10)); return true; }
        }
        return false;
    }
    input.addEventListener('input', updateMentionPop);
    input.addEventListener('click', updateMentionPop);
    input.addEventListener('blur', function () { setTimeout(closeMentionPop, 120); });
    input.addEventListener('keyup', function (e) {
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(e.key) !== -1) updateMentionPop();
    });

    /* ---------------------------------------------------------------- ПКМ: сообщение */
    function openMessageMenu(x, y, mid, target) {
        var cur = state.current, info = cur && cur.msgs && cur.msgs[mid];
        if (!info) return;
        var mine = info.user_id === ME;
        var link = target && target.closest ? target.closest('a.sp-link') : null;
        var sel = '';
        try { sel = String(window.getSelection ? window.getSelection() : '').trim(); } catch (e) {}
        var canDel = canModerateMsg(cur, info.user_id);
        var author = memberById(cur, info.user_id);
        openCtx(x, y, [
            { label: 'Открыть ссылку', icon: ICONS.external, hidden: !link, run: function () { window.open(link.href, '_blank', 'noopener,noreferrer'); } },
            { label: 'Копировать ссылку', icon: ICONS.link, hidden: !link, run: function () { copyText(link.href, 'Ссылка скопирована'); } },
            { divider: true, hidden: !link },
            { label: 'Копировать выделенное', icon: ICONS.copy, hidden: !sel, run: function () { copyText(sel, 'Скопировано'); } },
            { label: 'Ответить', icon: ICONS.reply, hidden: !canSendHere(cur), run: function () { startReply(mid); } },
            { label: 'Редактировать сообщение', icon: ICONS.edit, hidden: !mine || info.text === null, run: function () { startEdit(mid); } },
            { label: 'Копировать текст', icon: ICONS.copy, hidden: info.text === null, run: function () { copyText(info.text, 'Текст скопирован'); } },
            { label: 'Упомянуть автора', icon: ICONS.mention, hidden: mine || !author || !canSendHere(cur), run: function () { insertMention(author); } },
            { divider: true },
            { label: 'Отметить как непрочитанное', icon: ICONS.bell, run: function () { markUnreadFrom(cur, mid); } },
            { label: 'Копировать ID сообщения', icon: ICONS.copy, run: function () { copyText(String(mid), 'ID сообщения скопирован'); } },
            { divider: true, hidden: !canDel },
            { label: 'Удалить сообщение', icon: ICONS.trash, danger: true, hidden: !canDel, run: function () { confirmDelete(mid); } }
        ]);
    }

    /* ---------------------------------------------------------------- ПКМ: участник */
    function volumeItem(spaceId, userId, name) {
        return {
            custom: function () {
                var box = el('div', 'sp-ctx-volume');
                var title = el('div', 'sp-ctx-volume-title');
                title.appendChild(el('span', null, 'Громкость пользователя'));
                var value = el('span', 'sp-ctx-volume-value');
                title.appendChild(value);
                var slider = el('input', 'sp-ctx-volume-slider');
                slider.type = 'range'; slider.min = '0'; slider.max = '100'; slider.step = '1';
                slider.setAttribute('aria-label', 'Громкость пользователя ' + name);
                function update() {
                    var volume = parseInt(slider.value, 10);
                    value.textContent = volume + '%';
                    slider.style.setProperty('--p', volume + '%');
                    setUserVolume(spaceId, userId, volume);
                }
                slider.value = String(getUserVolume(spaceId, userId));
                slider.addEventListener('input', update);
                slider.addEventListener('change', update);
                value.textContent = slider.value + '%';
                slider.style.setProperty('--p', slider.value + '%');
                box.appendChild(title); box.appendChild(slider);
                return box;
            }
        };
    }
    function openMemberVolumeMenu(x, y, spaceId, userId, name) {         // вызывается из голосового списка и плиток созвона
        if (!userId || userId === ME) return;
        if (state.current && state.current.id === spaceId) openMemberMenu(x, y, userId, name);
        else openCtx(x, y, [volumeItem(spaceId, userId, name)]);
    }
    function afterMember(res, okText) {
        if (!res.ok) { toast(res.message || 'Не удалось выполнить действие.'); return Promise.resolve(false); }
        if (okText) toast(okText);
        return reloadInfo().then(function () { return true; });
    }
    function setMemberRole(cur, m, rid) {
        api('member_set_role', { space_id: cur.id, user_id: m.id, role_id: rid }).then(function (res) { afterMember(res, 'Роль изменена'); });
    }
    function openNickDialog(cur, m) {
        openModalTop('Ник на сервере', function (body, close) {
            body.appendChild(el('p', 'sp-hint', 'Как «' + m.username + '» будет отображаться на этом сервере. Пусто — вернуть обычное имя.'));
            var inp = el('input', 'sp-input'); inp.type = 'text'; inp.maxLength = 32; inp.value = m.server_nick || ''; inp.placeholder = m.username;
            body.appendChild(inp);
            var row = el('div', 'sp-row');
            var no = el('button', 'sp-btn', 'Отмена'); no.type = 'button';
            var yes = el('button', 'sp-btn primary', 'Сохранить'); yes.type = 'button';
            row.appendChild(no); row.appendChild(yes); body.appendChild(row);
            function save() {
                yes.disabled = true;
                api('member_nick', { space_id: cur.id, user_id: m.id, nickname: inp.value }).then(function (res) {
                    yes.disabled = false;
                    if (!res.ok) { toast(res.message || 'Не удалось изменить ник.'); return; }
                    close(); afterMember(res, 'Ник на сервере сохранён');
                });
            }
            no.addEventListener('click', close); yes.addEventListener('click', save);
            inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); save(); } });
            inp.focus(); inp.select();
        });
    }
    function openMemberMenu(x, y, uid, nameHint) {
        var cur = state.current;
        if (!cur) return;
        var m = memberById(cur, uid) || { id: uid, username: nameHint || ('Участник ' + uid), display_name: nameHint || ('Участник ' + uid), role: 'member', role_id: 0, avatar: '' };
        var self = uid === ME, known = !!memberById(cur, uid);
        var manageable = known && m.role !== 'owner' && !self && !outranks(cur, memberPerms(cur, m));
        var mod = manageable && can(P.KICK);
        var roleItems = [{ label: DEFAULT_ROLE_NAME, radio: m.role_id === 0, run: function () { setMemberRole(cur, m, 0); } }];
        cur.roles.forEach(function (r) {
            if (outranks(cur, r.perms)) return;
            roleItems.push({ label: rname(cur, r.id), radio: m.role_id === r.id, run: function () { setMemberRole(cur, m, r.id); } });
        });
        var name = displayName(m);
        openCtx(x, y, [
            { header: name },
            { label: 'Профиль', icon: ICONS.user, hidden: !known, run: function () { openProfile(uid); } },
            { label: 'Упомянуть', icon: ICONS.mention, hidden: !known || !canSendHere(cur), run: function () { insertMention(m); } },
            self || !known ? { hidden: true } : volumeItem(cur.id, uid, name),
            { divider: true, hidden: !(mod || (manageable && can(P.ROLES))) },
            { label: 'Изменить ник на сервере', icon: ICONS.edit, hidden: !mod, run: function () { openNickDialog(cur, m); } },
            { label: 'Роль', icon: ICONS.roles, hidden: !(manageable && can(P.ROLES)), sub: roleItems },
            { label: m.voice_muted ? 'Снять голосовой мут' : 'Заглушить голос', icon: ICONS.micOff, hidden: !mod, run: function () {
                api('member_voice_mute', { space_id: cur.id, user_id: uid, muted: !m.voice_muted }).then(function (res) {
                    afterMember(res, res.muted ? 'Участник заглушён в голосовых каналах' : 'Голосовой мут снят');
                });
            } },
            { divider: true, hidden: !mod },
            { label: 'Выгнать «' + clip(name, 22) + '»', icon: ICONS.leave, danger: true, hidden: !mod, run: function () {
                if (!confirm('Удалить участника «' + name + '» из пространства?')) return;
                api('member_kick', { space_id: cur.id, user_id: uid }).then(function (res) { afterMember(res, 'Участник удалён'); });
            } },
            { label: 'Забанить на 7 дней', icon: ICONS.ban, danger: true, hidden: !mod, run: function () {
                if (!confirm('Заблокировать «' + name + '» на этом сервере на 7 дней?')) return;
                api('member_ban', { space_id: cur.id, user_id: uid }).then(function (res) { afterMember(res, 'Участник заблокирован на 7 дней'); });
            } },
            { divider: true },
            { label: 'Копировать ID пользователя', icon: ICONS.copy, run: function () { copyText(String(uid), 'ID пользователя скопирован'); } }
        ]);
    }
    function openProfile(uid) {
        var cur = state.current, m = cur && memberById(cur, uid);
        if (!m) { toast('Участник больше не на сервере.'); return; }
        openModalTop('Профиль', function (body, close) {
            var top = el('div', 'sp-prof-top');
            top.appendChild(avatarNode(displayName(m), m.avatar, 'sp-avatar sp-prof-ava'));
            var who = el('div', 'sp-prof-who');
            who.appendChild(el('div', 'sp-prof-name', displayName(m)));
            who.appendChild(el('div', 'sp-prof-handle', '@' + m.username));
            var pr = m.id === ME ? myStatus : (m.presence || 'offline');
            who.appendChild(el('div', 'sp-pres sp-pres-' + pr, STATUS_LABELS[pr] || STATUS_LABELS.offline));
            top.appendChild(who);
            body.appendChild(top);
            var ro = roleOf(cur, m);
            var tag = el('span', 'sp-role-tag'), dot = el('span', 'sp-role-dot'); dot.style.background = ro.color;
            tag.appendChild(dot); tag.appendChild(el('span', null, ro.name));
            var rr = el('div', 'sp-prof-roles'); rr.appendChild(tag); body.appendChild(rr);
            if (m.voice_muted) body.appendChild(el('div', 'sp-pres', 'Голосовой мут на этом сервере'));
            var row = el('div', 'sp-row');
            var b1 = el('button', 'sp-btn primary', 'Упомянуть'); b1.type = 'button'; b1.hidden = !canSendHere(cur);
            var b2 = el('button', 'sp-btn', 'Копировать ID'); b2.type = 'button';
            if (!b1.hidden) row.appendChild(b1);
            row.appendChild(b2); body.appendChild(row);
            b1.addEventListener('click', function () { close(); insertMention(m); });
            b2.addEventListener('click', function () { copyText(String(m.id), 'ID пользователя скопирован'); });
        }, 'sp-profile-modal');
    }
    function bindMemberRow(row, m) {
        row.classList.add('sp-who-row');
        row.addEventListener('contextmenu', function (e) { e.preventDefault(); e.stopPropagation(); openMemberMenu(e.clientX, e.clientY, m.id); });
        row.addEventListener('click', function () { openProfile(m.id); });
        longPress(row, function (x, y) { openMemberMenu(x, y, m.id); });
    }

    /* ---------------------------------------------------------------- ПКМ: сервер в списке слева, шапка сервера, каналы, категории */
    var MUTE_CHOICES = [
        { label: 'На 15 минут', ms: 15 * 60000 }, { label: 'На 1 час', ms: 3600000 }, { label: 'На 8 часов', ms: 8 * 3600000 },
        { label: 'На 24 часа', ms: 24 * 3600000 }, { label: 'Пока не включу', ms: -1 }
    ];
    function serverMuteItem(sid) {
        if (spaceMuted(sid)) return { label: 'Включить уведомления сервера', icon: ICONS.bell, hint: spaceMuteHint(sid), run: function () { setSpaceMute(sid, 0); } };
        return { label: 'Заглушить сервер', icon: ICONS.bellOff, sub: MUTE_CHOICES.map(function (c) { return { label: c.label, run: function () { setSpaceMute(sid, c.ms); } }; }) };
    }
    function serverBadgeItem(sid) {
        var b = spaceBadge(sid);
        return { label: 'Отметить как прочитанное', icon: ICONS.check, hidden: !(b.u || b.m), run: function () { markSpaceRead(sid); } };
    }
    function leaveSpaceById(s) {
        if (!confirm('Выйти из пространства «' + s.name + '»? Сохранённый старый ключ на этом устройстве будет удалён.')) return;
        api('leave', { space_id: s.id }).then(function (res) {
            if (!res.ok) { toast(res.message || 'Не удалось выйти.'); return; }
            try { localStorage.removeItem(storageKey(s.id)); } catch (e) {}
            if (state.current && state.current.id === s.id) closeSpaceView();
            loadList();
        });
    }
    function serverListMenu(s) {
        return [
            { header: s.name },
            serverBadgeItem(s.id),
            { divider: true },
            serverMuteItem(s.id),
            { label: 'Настройки уведомлений', icon: ICONS.bell, run: function () { openNotifySettings(s.id); } },
            { divider: true },
            { label: 'Копировать ID сервера', icon: ICONS.copy, run: function () { copyText(String(s.id), 'ID сервера скопирован'); } },
            { divider: true, hidden: s.role === 'owner' },
            { label: 'Покинуть сервер', icon: ICONS.leave, danger: true, hidden: s.role === 'owner', run: function () { leaveSpaceById(s); } }
        ];
    }
    function levelItems(getter, setter) {
        var cur = getter();
        var out = [{ label: 'Как на сервере (по умолчанию)', radio: cur === 'default', run: function () { setter('default'); } }];
        ['all', 'mentions', 'none'].forEach(function (k) { out.push({ label: LEVEL_LABELS[k], radio: cur === k, run: function () { setter(k); } }); });
        return out;
    }
    function bindCtxAreas() {
        $('spMe').addEventListener('contextmenu', function (e) {
            e.preventDefault();
            var items = STATUS_MENU.map(function (s) { return { label: s.label, radio: myStatus === s.id, run: function () { setStatus(s.id); } }; });
            items.unshift({ header: CFG.username || 'Вы' });
            items.push({ divider: true });
            items.push({ label: 'Настройки уведомлений', icon: ICONS.bell, run: function () { openNotifySettings(); } });
            items.push({ label: 'Голос и шумоподавление', icon: ICONS.volume, run: openNoiseSettings });
            items.push({ divider: true });
            items.push({ label: 'Копировать мой ID', icon: ICONS.copy, run: function () { copyText(String(ME), 'ID скопирован'); } });
            openCtx(e.clientX, e.clientY, items);
        });
        chHead.addEventListener('contextmenu', function (e) {
            var cur = state.current;
            if (!cur) return;
            e.preventDefault(); e.stopPropagation();
            openCtx(e.clientX, e.clientY, serverMenu(cur));
        });
        $('spChanBar').addEventListener('contextmenu', function (e) {
            var cur = state.current;
            if (!cur || !cur.chan) return;
            e.preventDefault();
            openCtx(e.clientX, e.clientY, channelMenu(cur, { id: cur.chan.id, type: 'text' }));
        });
        elMsgs.addEventListener('contextmenu', function (e) {
            if (e.defaultPrevented || (e.target.closest && e.target.closest('.sp-msg'))) return;
            var cur = state.current;
            if (!cur || !cur.chan) return;
            e.preventDefault();
            openCtx(e.clientX, e.clientY, [
                { label: 'Отметить канал как прочитанный', icon: ICONS.check, run: function () { notif.hold = null; markChannelRead(cur.id, cur.chan.id); } },
                { label: 'Прокрутить вниз', icon: ICONS.back, run: function () { elMsgs.scrollTop = elMsgs.scrollHeight; } },
                { divider: true },
                { label: isMuted(cur, cur.chan) ? 'Включить звук канала' : 'Заглушить канал', icon: ICONS.bellOff, run: function () { toggleMute(cur, { id: cur.chan.id, type: 'text' }); } }
            ]);
        });
        elMsgs.addEventListener('scroll', function () {
            closeCtx();
            clearTimeout(elMsgs._st); elMsgs._st = setTimeout(markCurrentRead, 250);
        }, { passive: true });
    }
    function chBellState() { return !NS.enabled; }

    /* ---------------------------------------------------------------- настройки уведомлений (окно как в Discord: слева разделы, справа содержимое) */
    function switchRow(title, desc, get, set) {
        var row = el('div', 'sp-us-row');
        var txt = el('div', 'sp-us-txt');
        txt.appendChild(el('div', 'sp-us-title', title));
        if (desc) txt.appendChild(el('div', 'sp-us-desc', desc));
        var sw = el('button', 'sp-switch'); sw.type = 'button'; sw.setAttribute('role', 'switch'); sw.setAttribute('aria-label', title);
        sw.appendChild(el('span', 'sp-switch-knob'));
        function paint() { var on = !!get(); sw.classList.toggle('on', on); sw.setAttribute('aria-checked', on ? 'true' : 'false'); }
        sw.addEventListener('click', function () { set(!get()); paint(); });
        paint();
        row.appendChild(txt); row.appendChild(sw);
        return row;
    }
    function radioGroup(options, get, set) {
        var box = el('div', 'sp-us-radios');
        function paint() { Array.prototype.forEach.call(box.children, function (b) { var on = b.dataset.v === get(); b.classList.toggle('on', on); b.setAttribute('aria-checked', on ? 'true' : 'false'); }); }
        options.forEach(function (o) {
            var b = el('button', 'sp-us-radio'); b.type = 'button'; b.dataset.v = o.v; b.setAttribute('role', 'radio');
            b.appendChild(el('span', 'sp-us-dot'));
            var t = el('span', 'sp-us-radio-txt'); t.appendChild(el('span', 'sp-us-title', o.label)); if (o.desc) t.appendChild(el('span', 'sp-us-desc', o.desc));
            b.appendChild(t);
            b.addEventListener('click', function () { set(o.v); paint(); });
            box.appendChild(b);
        });
        paint();
        return box;
    }
    function openNotifySettings(focusSid) {
        openModalTop('Настройки', function (body) {
            var wrap = el('div', 'sp-us'), nav = el('div', 'sp-us-nav'), pane = el('div', 'sp-us-pane');
            wrap.appendChild(nav); wrap.appendChild(pane); body.appendChild(wrap);

            function renderGlobal() {
                pane.appendChild(el('div', 'sp-us-h', 'Уведомления'));
                pane.appendChild(switchRow('Включить уведомления', 'Выключатель на все серверы сразу. Счётчики непрочитанного остаются.', function () { return NS.enabled; }, function (v) { NS.enabled = v; nsSave(); updateTitle(); updateBell(); }));
                pane.appendChild(el('div', 'sp-us-sub', 'Звук'));
                pane.appendChild(switchRow('Звук уведомлений', 'Короткий сигнал при новом сообщении; отдельный — при упоминании. Не звучит, если выключен звук (наушники).', function () { return NS.sound; }, function (v) { NS.sound = v; nsSave(); }));
                var vol = el('div', 'sp-us-vol');
                vol.appendChild(el('span', 'sp-us-title', 'Громкость'));
                var sl = el('input', 'sp-ctx-volume-slider'); sl.type = 'range'; sl.min = '0'; sl.max = '100'; sl.step = '1'; sl.value = String(NS.volume);
                var val = el('span', 'sp-ctx-volume-value', NS.volume + '%');
                function setVol() { NS.volume = parseInt(sl.value, 10); val.textContent = NS.volume + '%'; sl.style.setProperty('--p', NS.volume + '%'); nsSave(); }
                sl.style.setProperty('--p', NS.volume + '%');
                sl.addEventListener('input', setVol);
                sl.addEventListener('change', function () { setVol(); notifySound('msg', true); });
                vol.appendChild(sl); vol.appendChild(val); pane.appendChild(vol);
                var tests = el('div', 'sp-row');
                var t1 = el('button', 'sp-btn', '▶ Сообщение'); t1.type = 'button';
                var t2 = el('button', 'sp-btn', '▶ Упоминание'); t2.type = 'button';
                t1.addEventListener('click', function () { notifySound('msg', true); });
                t2.addEventListener('click', function () { notifySound('mention', true); });
                tests.appendChild(t1); tests.appendChild(t2); pane.appendChild(tests);

                pane.appendChild(el('div', 'sp-us-sub', 'Оповещения'));
                pane.appendChild(switchRow('Всплывающие уведомления в приложении', 'Карточка в углу экрана — нажмите, чтобы перейти в канал.', function () { return NS.toast; }, function (v) { NS.toast = v; nsSave(); }));
                var deskRow = switchRow('Уведомления на рабочем столе', 'Системные уведомления браузера, когда вкладка свёрнута или окно не активно.', function () { return NS.desktop; }, function (v) { NS.desktop = v; nsSave(); });
                pane.appendChild(deskRow);
                var perm = el('div', 'sp-us-perm');
                var permTxt = el('span', 'sp-us-desc'), permBtn = el('button', 'sp-btn sp-btn-sm', 'Разрешить в браузере'); permBtn.type = 'button';
                function paintPerm() {
                    if (!('Notification' in window)) { permTxt.textContent = 'Этот браузер не поддерживает системные уведомления.'; permBtn.hidden = true; return; }
                    var p = Notification.permission;
                    permTxt.textContent = p === 'granted' ? '✓ Браузер разрешил уведомления' : p === 'denied' ? 'Запрещено. Разрешите уведомления для сайта в настройках браузера (значок замка у адреса).' : 'Браузер ещё не дал разрешение.';
                    permBtn.hidden = p !== 'default';
                }
                permBtn.addEventListener('click', function () {
                    try { var r = Notification.requestPermission(paintPerm); if (r && r.then) r.then(paintPerm); } catch (e) { paintPerm(); }
                });
                paintPerm(); perm.appendChild(permTxt); perm.appendChild(permBtn); pane.appendChild(perm);
                var tst = el('button', 'sp-btn', 'Показать тестовое уведомление'); tst.type = 'button';
                tst.addEventListener('click', function () {
                    notifySound('mention', true);
                    var o = { title: 'Проверка · #общий · ' + (state.current ? state.current.name : 'Сервер'), text: 'Так будут выглядеть уведомления о сообщениях.', name: CFG.username || '?', avatar: CFG.avatar, mention: true, onClick: function () {} };
                    noticeToast(o);
                    desktopNotice({ space_id: 0, channel_id: 0 }, o.title, o.text, function () { window.focus(); });
                });
                pane.appendChild(tst);
                pane.appendChild(switchRow('Счётчик в заголовке вкладки', 'Показывать (3) или • в названии вкладки, пока есть непрочитанное.', function () { return NS.title; }, function (v) { NS.title = v; nsSave(); updateTitle(); }));
                pane.appendChild(switchRow('Не уведомлять в режиме «Не беспокоить»', 'Пока ваш статус «Не беспокоить», звуки и всплывающие окна отключены.', function () { return NS.dnd; }, function (v) { NS.dnd = v; nsSave(); }));

                pane.appendChild(el('div', 'sp-us-sub', 'Уведомлять по умолчанию'));
                pane.appendChild(radioGroup([
                    { v: 'all', label: 'Все сообщения' },
                    { v: 'mentions', label: 'Только @упоминания', desc: 'И ответы на ваши сообщения.' },
                    { v: 'none', label: 'Ничего', desc: 'Без звука и окон; значки непрочитанного остаются.' }
                ], function () { return NS.level; }, function (v) { NS.level = v; nsSave(); }));
                pane.appendChild(el('p', 'sp-us-note', 'Заглушённые серверы и каналы не шумят вовсе — только красный счётчик для упоминаний. Для конкретного сервера или канала уровень можно поменять в разделе «Серверы» или по ПКМ.'));
                var all = el('button', 'sp-btn', 'Отметить всё как прочитанное'); all.type = 'button';
                all.addEventListener('click', function () { markAllRead(); toast('Всё отмечено как прочитанное'); });
                pane.appendChild(all);
            }
            function renderServers() {
                pane.appendChild(el('div', 'sp-us-h', 'Уведомления серверов'));
                if (!state.spaces.length) { pane.appendChild(el('p', 'sp-us-note', 'Вы пока не состоите ни в одном пространстве.')); return; }
                state.spaces.forEach(function (s) {
                    var card = el('div', 'sp-us-server' + (s.id === focusSid ? ' focus' : ''));
                    var head = el('div', 'sp-us-server-head');
                    var ico = el('div', 'sp-item-ico');
                    var av = safeAvatar(s.avatar_path);
                    if (av) { var im = document.createElement('img'); im.src = av; im.alt = ''; ico.appendChild(im); } else ico.textContent = letter(s.name);
                    head.appendChild(ico); head.appendChild(el('div', 'sp-us-title', s.name));
                    card.appendChild(head);
                    var r1 = el('div', 'sp-us-line'); r1.appendChild(el('span', 'sp-us-desc', 'Уведомлять'));
                    var sel = el('select', 'sp-select sp-select-sm');
                    [['default', 'По умолчанию (' + LEVEL_LABELS[NS.level].toLowerCase() + ')'], ['all', LEVEL_LABELS.all], ['mentions', LEVEL_LABELS.mentions], ['none', LEVEL_LABELS.none]].forEach(function (o) {
                        var op = el('option', null, o[1]); op.value = o[0]; sel.appendChild(op);
                    });
                    sel.value = (NSP[s.id] && NSP[s.id].level) || 'default';
                    sel.addEventListener('change', function () { setSpaceLevel(s.id, sel.value); });
                    r1.appendChild(sel); card.appendChild(r1);
                    var r2 = el('div', 'sp-us-line'); r2.appendChild(el('span', 'sp-us-desc', 'Заглушить'));
                    var ms = el('select', 'sp-select sp-select-sm');
                    var opts = [['0', 'Не заглушён'], ['3600000', 'На 1 час'], ['28800000', 'На 8 часов'], ['86400000', 'На 24 часа'], ['-1', 'Пока не включу']];
                    if (spaceMuted(s.id) && NSP[s.id].mute !== -1) opts.splice(1, 0, ['keep', 'Заглушён ' + spaceMuteHint(s.id)]);
                    opts.forEach(function (o) { var op = el('option', null, o[1]); op.value = o[0]; ms.appendChild(op); });
                    ms.value = !spaceMuted(s.id) ? '0' : (NSP[s.id].mute === -1 ? '-1' : 'keep');
                    ms.addEventListener('change', function () { if (ms.value !== 'keep') setSpaceMute(s.id, parseInt(ms.value, 10)); });
                    r2.appendChild(ms); card.appendChild(r2);
                    pane.appendChild(card);
                });
                pane.appendChild(el('p', 'sp-us-note', 'Уведомления отдельного канала настраиваются по ПКМ на канале: «Настройки уведомлений».'));
            }
            function renderVoice() {
                pane.appendChild(el('div', 'sp-us-h', 'Голос и звук'));
                pane.appendChild(el('p', 'sp-us-note', 'Шумоподавление, проверка микрофона и громкость собеседников. Громкость отдельного участника — ПКМ по нему.'));
                var b = el('button', 'sp-btn primary', 'Открыть настройки голоса'); b.type = 'button';
                b.addEventListener('click', openNoiseSettings);
                pane.appendChild(b);
            }
            var sections = [
                { id: 'notif', label: 'Уведомления', icon: ICONS.bell, render: renderGlobal },
                { id: 'servers', label: 'Серверы', icon: ICONS.members, render: renderServers },
                { id: 'voice', label: 'Голос и звук', icon: ICONS.volume, render: renderVoice }
            ];
            var btns = {};
            function show(id) {
                pane.textContent = '';
                sections.forEach(function (s) { btns[s.id].classList.toggle('on', s.id === id); if (s.id === id) s.render(); });
                pane.scrollTop = 0;
            }
            sections.forEach(function (s) {
                var b = el('button', 'sp-us-nav-btn'); b.type = 'button';
                var ic = el('span', 'sp-ctx-ico'); ic.innerHTML = s.icon; b.appendChild(ic); b.appendChild(el('span', null, s.label));
                b.addEventListener('click', function () { show(s.id); });
                nav.appendChild(b); btns[s.id] = b;
            });
            show(focusSid ? 'servers' : 'notif');
            if (focusSid) setTimeout(function () { var f = pane.querySelector('.focus'); if (f && f.scrollIntoView) f.scrollIntoView({ block: 'center' }); }, 30);
        }, 'sp-us-modal');
    }

    /* ---------------------------------------------------------------- кнопка «колокольчик» в панели пользователя */
    function bellButton() {
        var b = $('spMeNotify');
        if (!b) {
            b = el('button', 'sp-me-btn'); b.type = 'button'; b.id = 'spMeNotify';
            b.title = 'Настройки уведомлений'; b.setAttribute('aria-label', 'Настройки уведомлений');
            var ref = $('spMeSet');
            if (ref && ref.parentNode) ref.parentNode.insertBefore(b, ref); else return null;
        }
        if (!b.querySelector('svg')) b.innerHTML = ICONS.bell;
        return b;
    }
    function updateBell() {
        var b = $('spMeNotify'); if (!b) return;
        var t = totalBadges();
        b.classList.toggle('muted', chBellState());
        b.classList.toggle('has-mention', t.m > 0 && NS.enabled);
        b.title = NS.enabled ? (t.m > 0 ? 'Упоминаний: ' + t.m + ' — настройки уведомлений' : 'Настройки уведомлений') : 'Уведомления выключены — настройки';
    }
    (function initDiscordUi() {
        var b = bellButton();
        if (b) {
            b.addEventListener('click', function () { openNotifySettings(); });
            b.addEventListener('contextmenu', function (e) {
                e.preventDefault();
                openCtx(e.clientX, e.clientY, [
                    { label: 'Уведомления включены', checked: NS.enabled, run: function () { NS.enabled = !NS.enabled; nsSave(); updateTitle(); updateBell(); } },
                    { label: 'Звук уведомлений', checked: NS.sound, run: function () { NS.sound = !NS.sound; nsSave(); } },
                    { label: 'Уведомления на рабочем столе', checked: NS.desktop, run: function () { NS.desktop = !NS.desktop; nsSave(); } },
                    { divider: true },
                    { label: 'Отметить всё как прочитанное', icon: ICONS.check, run: function () { markAllRead(); toast('Всё отмечено как прочитанное'); } },
                    { label: 'Настройки уведомлений…', icon: ICONS.bell, run: function () { openNotifySettings(); } }
                ]);
            });
        }
        bindCtxAreas();
        updateBell();
    })();

    /* ---------------------------------------------------------------- меню канала и категории (с уведомлениями) */
    function channelMenu(cur, ch) {
        var real = ch.id > 0, text = ch.type === 'text', manage = real && can(P.CHANNELS);
        var k = rkey(cur.id, ch.id), unread = text && (notif.unread[k] || notif.mentions[k]);
        var muted = isMuted(cur, ch);
        return [
            { label: 'Отметить как прочитанный', icon: ICONS.check, hidden: !unread, run: function () { notif.hold = null; markChannelRead(cur.id, ch.id); } },
            { label: muted ? 'Включить звук канала' : 'Заглушить канал', icon: muted ? ICONS.bell : ICONS.bellOff, run: function () { toggleMute(cur, ch); } },
            { label: 'Настройки уведомлений', icon: ICONS.bell, hidden: !text, sub: levelItems(function () { return chanLevelSetting(cur.id, ch.id); }, function (v) { setChanLevel(cur.id, ch.id, v); }) },
            { divider: true, hidden: !manage },
            { label: 'Переместить в категорию', icon: ICONS.category, hidden: !manage, run: function () { openMoveChannel(cur, ch); } },
            { label: 'Настройки канала', icon: ICONS.settings, hidden: !manage, run: function () { openChannelSettings(cur, ch); } },
            { label: 'Удалить канал', icon: ICONS.trash, danger: true, hidden: !manage, run: function () { deleteChannel(cur, ch); } },
            { divider: true, hidden: !real },
            { label: 'Копировать ID канала', icon: ICONS.copy, hidden: !real, run: function () { copyText(String(ch.id), 'ID канала скопирован'); } }
        ];
    }
    function categoryMenu(cur, cat) {
        var ids = cur.channels.filter(function (c) { return c.category_id === cat.id && c.type === 'text'; }).map(function (c) { return c.id; });
        var hasUnread = ids.some(function (id) { var k = rkey(cur.id, id); return notif.unread[k] || notif.mentions[k]; });
        var collapsed = !!cur.collapsed[cat.id], manage = can(P.CHANNELS);
        return [
            { label: 'Отметить как прочитанную', icon: ICONS.check, hidden: !hasUnread, run: function () { ids.forEach(function (id) { markChannelRead(cur.id, id); }); } },
            { label: collapsed ? 'Развернуть категорию' : 'Свернуть категорию', icon: ICONS.chevron, run: function () { cur.collapsed[cat.id] = !cur.collapsed[cat.id]; renderChannels(); } },
            { divider: true, hidden: !manage },
            { label: 'Создать канал', icon: ICONS.channel, hidden: !manage, run: function () { openCreateChannel(cat.id); } },
            { label: 'Переименовать категорию', icon: ICONS.edit, hidden: !manage, run: function () { openRename('category', cat.id, cur.gn[cat.id]); } },
            { label: 'Удалить категорию', icon: ICONS.trash, danger: true, hidden: !manage, run: function () { deleteCategory(cur, cat); } },
            { divider: true },
            { label: 'Копировать ID категории', icon: ICONS.copy, run: function () { copyText(String(cat.id), 'ID категории скопирован'); } }
        ];
    }

    /* ---------------------------------------------------------------- старт */
    if (window.isSecureContext === false || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        var insecure = $('spInsecure');
        if (insecure) insecure.hidden = false;
    }
    syncKeyStores().then(loadList).then(function () {
        notifyStart();
        handleUrlInvite();
        var rs = readResume();
        if (rs && state.spaces.some(function (x) { return x.id === rs.s; })) {
            pendingResume = rs;
            openSpace(rs.s);
        }
    });
    setInterval(function () { if (!document.hidden && !state.current) loadList(); }, 15000);
})();

document.addEventListener('DOMContentLoaded', function () {

    // =============================================
    // ВЫПАДАЮЩЕЕ МЕНЮ АВАТАРА
    // =============================================

    const avatarBtn = document.getElementById('avatarBtn');
    const dropdown = document.getElementById('avatarDropdown');

    const overlay = document.createElement('div');
    overlay.className = 'dropdown-overlay';
    document.body.appendChild(overlay);

    if (avatarBtn && dropdown) {
        avatarBtn.addEventListener('click', function (e) {
            e.stopPropagation();

            dropdown.classList.toggle('active');
            overlay.classList.toggle('active');
        });
    }

    overlay.addEventListener('click', function (e) {
        if (e.target === overlay) {
            if (dropdown) {
                dropdown.classList.remove('active');
            }

            overlay.classList.remove('active');
        }
    });

    document.addEventListener('click', function (e) {
        if (dropdown && avatarBtn) {
            if (
                !dropdown.contains(e.target) &&
                e.target !== avatarBtn &&
                !avatarBtn.contains(e.target)
            ) {
                dropdown.classList.remove('active');
                overlay.classList.remove('active');
            }
        }
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            if (dropdown) {
                dropdown.classList.remove('active');
            }

            overlay.classList.remove('active');
        }
    });


    // =============================================
    // РЕДАКТИРОВАНИЕ НИКНЕЙМА
    // =============================================

    window.editProfileLink = function () {

        const input = document.getElementById('profileLink');
        const editBtn = document.getElementById('editLinkButton');
        const saveBtn = document.getElementById('saveLinkButton');

        if (!input) {
            return;
        }

        // Разрешаем редактирование
        input.removeAttribute('readonly');
        input.readOnly = false;

        // Показываем курсор
        input.focus();

        // Выделяем текущий никнейм
        input.select();

        // Кнопка "Изменить" исчезает
        if (editBtn) {
            editBtn.style.display = 'none';
        }

        // Кнопка "Изменить адрес" появляется
        if (saveBtn) {
            saveBtn.style.display = 'inline-block';
        }
    };


    // =============================================
    // СОХРАНЕНИЕ НИКНЕЙМА
    // =============================================

    window.saveProfileLink = function () {

        const input = document.getElementById('profileLink');
        const editBtn = document.getElementById('editLinkButton');
        const saveBtn = document.getElementById('saveLinkButton');

        if (!input) {
            return;
        }

        let username = input.value.trim();

        // Если пользователь вставил полный адрес:
        // https://vg.com/username
        if (username.includes('vg.com/')) {
            username = username.split('vg.com/')[1];
        }

        // Убираем лишний слеш
        username = username.replace(/^\/+|\/+$/g, '');

        // Приводим к нижнему регистру
        username = username.toLowerCase();

        // Проверяем длину
        if (username.length < 3) {
            alert('Никнейм должен содержать минимум 3 символа');
            input.focus();
            return;
        }

        // Разрешаем только буквы, цифры, _, -
        if (!/^[a-z0-9_-]+$/i.test(username)) {
            alert('Никнейм может содержать только латинские буквы, цифры, "_" и "-"');
            input.focus();
            return;
        }

        // Возвращаем только никнейм в поле
        input.value = username;

        // Скрытое поле формы
        const hiddenInput = document.getElementById('usernameHidden');

        // Форма
        const editForm = document.getElementById('editForm');

        if (hiddenInput && editForm) {

            hiddenInput.value = username;

            // Перед отправкой блокируем повторное нажатие
            if (saveBtn) {
                saveBtn.disabled = true;
                saveBtn.textContent = 'Сохранение...';
            }

            editForm.submit();

            return;
        }

        // Если формы нет, просто возвращаем поле
        // в режим просмотра
        input.setAttribute('readonly', 'readonly');
        input.readOnly = true;

        if (editBtn) {
            editBtn.style.display = 'inline-block';
        }

        if (saveBtn) {
            saveBtn.style.display = 'none';
        }
    };


    // =============================================
    // ПРЕДОТВРАЩЕНИЕ ПОВТОРНОЙ ОТПРАВКИ ФОРМЫ
    // =============================================

    const editForm = document.getElementById('editForm');
    const saveBtn = document.getElementById('saveBtn');
    const saveIcon = document.getElementById('saveIcon');
    const saveBtnText = document.getElementById('saveBtnText');

    if (editForm) {

        let editSubmitted = false;

        editForm.addEventListener('submit', function (e) {

            if (editSubmitted) {
                e.preventDefault();
                return false;
            }

            editSubmitted = true;

            if (saveBtn) {

                saveBtn.classList.add('saving');
                saveBtn.disabled = true;

                if (saveBtnText) {
                    saveBtnText.textContent = 'Сохранение...';
                }
            }
        });
    }

});
(function () {
    'use strict';

    const list = document.getElementById('notificationsList');
    if (!list) return;

    const badge = document.getElementById('notificationsBadge');
    const countLabel = document.getElementById('notificationsCount');
    const markAllButton = document.getElementById('markAllReadBtn');
    const notificationUrl = 'api/get_notifications.php';
    const markReadUrl = 'api/mark_notification_read.php';
    const mainScriptLoaded = Array.from(document.scripts).some(function (script) {
        return /(?:^|\/)assets\/js\/script\.js(?:\?|$)/.test(script.src);
    });
    let requestInProgress = false;
    let refreshTimer = null;

    function setUnreadCount(count) {
        const unread = Math.max(0, Number(count) || 0);
        if (badge) {
            badge.textContent = unread > 99 ? '99+' : String(unread);
            badge.style.display = unread > 0 ? 'flex' : 'none';
        }
        if (countLabel) {
            countLabel.textContent = unread === 0
                ? (countLabel.dataset.zeroText || '0 новых')
                : unread + ' новых';
        }
        if (markAllButton) markAllButton.style.display = unread > 0 ? '' : 'none';
    }

    function safeNotificationLink(value) {
        try {
            const url = new URL(String(value || '#'), document.baseURI);
            return ['http:', 'https:'].includes(url.protocol) ? url.href : '#';
        } catch (error) {
            return '#';
        }
    }

    function relativeTime(value) {
        const timestamp = new Date(String(value || '').replace(' ', 'T')).getTime();
        if (!Number.isFinite(timestamp)) return '';
        const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
        if (seconds < 60) return 'только что';
        if (seconds < 3600) return Math.floor(seconds / 60) + 'м';
        if (seconds < 86400) return Math.floor(seconds / 3600) + 'ч';
        if (seconds < 604800) return Math.floor(seconds / 86400) + 'д';
        return new Date(timestamp).toLocaleDateString();
    }

    function renderNotifications(notifications) {
        if (!Array.isArray(notifications)) return;
        if (mainScriptLoaded) return;
        list.replaceChildren();

        if (notifications.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'notifications-empty';
            empty.innerHTML = '<div class="empty-icon">🔔</div><div class="empty-text">Нет уведомлений</div><div class="empty-sub">Здесь будут появляться ваши уведомления</div>';
            list.appendChild(empty);
            return;
        }

        notifications.forEach(function (notification) {
            const item = document.createElement('a');
            const unread = Number(notification.is_read) === 0;
            const senderName = String(notification.sender_name || '');
            item.href = safeNotificationLink(notification.link);
            item.className = 'notification-item ' + (unread ? 'unread' : 'read')
                + ' type-' + String(notification.type || 'info').replace(/[^a-z0-9_-]/gi, '');
            item.dataset.notificationId = String(Number(notification.id) || '');

            const avatarWrapper = document.createElement('div');
            avatarWrapper.className = 'notif-avatar-wrapper';
            const avatar = document.createElement('div');
            avatar.className = 'notif-avatar';
            if (notification.sender_avatar) {
                const image = document.createElement('img');
                image.src = safeNotificationLink(notification.sender_avatar);
                image.alt = '';
                avatar.appendChild(image);
            } else {
                const letter = document.createElement('span');
                letter.className = 'avatar-letter';
                letter.textContent = senderName ? senderName.charAt(0).toUpperCase() : '?';
                avatar.appendChild(letter);
            }
            avatarWrapper.append(avatar);

            const content = document.createElement('div');
            content.className = 'notif-content';
            const text = document.createElement('div');
            text.className = 'notif-text';
            if (senderName) {
                const sender = document.createElement('strong');
                sender.className = 'notif-sender';
                sender.textContent = senderName;
                text.appendChild(sender);
            }
            const message = document.createElement('span');
            message.className = 'notif-message';
            let messageText = String(notification.message || '');
            if (senderName && messageText.startsWith(senderName)) {
                messageText = messageText.slice(senderName.length).trimStart();
            }
            message.textContent = messageText;
            text.appendChild(message);

            const meta = document.createElement('div');
            meta.className = 'notif-meta';
            const time = document.createElement('span');
            time.className = 'notif-time';
            time.textContent = relativeTime(notification.created_at);
            meta.appendChild(time);
            content.append(text, meta);
            item.append(avatarWrapper, content);
            if (unread) {
                const dot = document.createElement('span');
                dot.className = 'notif-dot';
                item.appendChild(dot);
            }
            list.appendChild(item);
        });
    }

    async function refreshNotifications() {
        if (document.hidden || requestInProgress) return;
        requestInProgress = true;
        try {
            const response = await fetch(notificationUrl, {
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            if (!response.ok) throw new Error('Notification refresh failed with HTTP ' + response.status);
            const data = await response.json();
            if (!data.success) throw new Error(data.error || 'Notification refresh failed');
            setUnreadCount(data.count);
            renderNotifications(data.notifications);
        } catch (error) {
            console.error('Не удалось обновить уведомления:', error);
        } finally {
            requestInProgress = false;
        }
    }

    function startPolling() {
        if (refreshTimer !== null) return;
        refreshTimer = window.setInterval(refreshNotifications, 30000);
    }

    function stopPolling() {
        if (refreshTimer === null) return;
        window.clearInterval(refreshTimer);
        refreshTimer = null;
    }

    function markUnreadItem(item) {
        if (!item || !item.classList.contains('unread')) return;
        const id = item.dataset.notificationId;
        if (!id) return;

        item.classList.remove('unread');
        item.classList.add('read');
        const dot = item.querySelector('.notif-dot');
        if (dot) dot.remove();

        const currentCount = badge ? Number.parseInt(badge.textContent, 10) : NaN;
        if (Number.isFinite(currentCount) && currentCount < 100) setUnreadCount(Math.max(0, currentCount - 1));
        const body = new URLSearchParams({ id: id });
        if (!navigator.sendBeacon || !navigator.sendBeacon(markReadUrl, body)) {
            fetch(markReadUrl, {
                method: 'POST',
                credentials: 'same-origin',
                keepalive: true,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            }).catch(function (error) {
                console.error('Не удалось отметить уведомление прочитанным:', error);
            });
        }
    }

    document.addEventListener('click', function (event) {
        const target = event.target;
        if (!(target instanceof Element)) return;

        // Телефон: колокольчик сразу ведёт на страницу уведомлений, без выпадающего окна
        if (target.closest('#notificationsBtn') && window.matchMedia('(max-width: 768px)').matches) {
            event.preventDefault();
            event.stopImmediatePropagation();
            if (!/notifications\.php$/.test(window.location.pathname)) {
                window.location.href = 'notifications.php';
            }
            return;
        }

        const item = target.closest('.notification-item');
        if (item) {
            markUnreadItem(item);
            return;
        }

        const button = target.closest('#markAllReadBtn');
        if (!button) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        button.disabled = true;
        fetch(markReadUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=0'
        }).then(function (response) {
            if (!response.ok) throw new Error('Mark notifications read failed with HTTP ' + response.status);
            return response.json();
        }).then(function (data) {
            if (!data.success) throw new Error(data.error || 'Could not mark notifications read');
            list.querySelectorAll('.notification-item.unread').forEach(function (unreadItem) {
                unreadItem.classList.remove('unread');
                unreadItem.classList.add('read');
                const dot = unreadItem.querySelector('.notif-dot');
                if (dot) dot.remove();
            });
            setUnreadCount(0);
        }).catch(function (error) {
            console.error('Не удалось отметить уведомления прочитанными:', error);
        }).finally(function () {
            button.disabled = false;
        });
    }, true);

    document.addEventListener('vspace:notifications-open', refreshNotifications);
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) {
            stopPolling();
        } else {
            refreshNotifications();
            startPolling();
        }
    });
    window.addEventListener('pageshow', refreshNotifications);
    window.addEventListener('focus', refreshNotifications);

    refreshNotifications();
    startPolling();
})();

/**
 * PIN-CELLS.JS — PIN-код по клеточкам + красная обводка при ошибке.
 *
 * Настоящий <input class="pin-input"> остаётся в форме (именно он уходит на сервер),
 * просто становится невидимым и лежит поверх клеточек. Поэтому работают
 * вставка, автозаполнение, цифровая клавиатура на телефоне и Backspace.
 */
(function () {
    var MIN = 4;
    var MAX = 4;

    function setBanner(form, text) {
        var box = form.querySelector('.pin-error');
        if (!text) {
            if (box && box.dataset.client) box.remove();
            return;
        }
        if (!box) {
            box = document.createElement('div');
            box.className = 'pin-error';
            box.setAttribute('role', 'alert');
            var anchor = form.querySelector('.pin-label');
            if (anchor) anchor.parentNode.insertBefore(box, anchor);
            else form.appendChild(box);
        }
        box.dataset.client = '1';
        box.textContent = text;
    }

    function build(input) {
        var wrap = document.createElement('div');
        wrap.className = 'pin-cells';
        var row = document.createElement('div');
        row.className = 'pin-cells-row';
        row.setAttribute('aria-hidden', 'true');

        var hadFocus = document.activeElement === input || input.hasAttribute('autofocus');
        input.parentNode.insertBefore(wrap, input);
        wrap.appendChild(row);
        wrap.appendChild(input);
        input.removeAttribute('placeholder');

        function render() {
            var len = input.value.length;
            var count = len < MIN ? MIN : Math.min(MAX, len + 1);
            while (row.children.length < count) {
                var c = document.createElement('span');
                c.className = 'pin-cell';
                row.appendChild(c);
            }
            while (row.children.length > count) row.removeChild(row.lastChild);

            var focused = wrap.classList.contains('is-focused');
            var active = Math.min(len, MAX - 1);
            for (var i = 0; i < row.children.length; i++) {
                var cell = row.children[i];
                var filled = i < len;
                cell.classList.toggle('filled', filled);
                cell.classList.toggle('active', focused && i === active);
                cell.textContent = filled ? '\u2022' : '';
            }
        }

        function setError(on) {
            wrap.classList.remove('is-error');
            if (on) {
                void wrap.offsetWidth; // перезапуск анимации тряски
                wrap.classList.add('is-error');
            }
        }

        input.addEventListener('input', function () {
            var clean = input.value.replace(/\D/g, '').slice(0, MAX);
            if (clean !== input.value) input.value = clean;
            if (wrap.classList.contains('is-error')) {
                setError(false);
                setBanner(input.form, '');
            }
            render();
        });
        input.addEventListener('focus', function () {
            wrap.classList.add('is-focused');
            var n = input.value.length;
            try { input.setSelectionRange(n, n); } catch (e) {}
            render();
        });
        input.addEventListener('blur', function () {
            wrap.classList.remove('is-focused');
            render();
        });
        // курсор всегда в конце — редактируем только с конца
        input.addEventListener('select', function () {
            var n = input.value.length;
            try { input.setSelectionRange(n, n); } catch (e) {}
        });

        input._pin = { render: render, setError: setError, wrap: wrap };
        if (hadFocus && !input.closest('dialog:not([open])')) input.focus();
        render();
    }

    function validate(form) {
        var inputs = Array.prototype.slice.call(form.querySelectorAll('.pin-input'));
        var first = null;
        var message = '';

        inputs.forEach(function (inp) {
            if (!inp._pin) return;
            var ok = /^\d{4}$/.test(inp.value);
            if (!ok) {
                inp._pin.setError(true);
                if (!first) first = inp;
                if (!message) message = inp.value ? 'PIN-код должен состоять из 4 цифр.' : 'Введите PIN-код.';
            }
        });

        // повтор нового PIN должен совпадать
        var np = form.querySelector('input[name="new_pin"]');
        var cp = form.querySelector('input[name="new_pin_confirm"]');
        if (np && cp && !first && np.value !== cp.value) {
            cp._pin.setError(true);
            first = cp;
            message = 'PIN-коды не совпадают.';
        }

        if (first) {
            setBanner(form, message);
            first.focus();
            return false;
        }
        return true;
    }

    function markServerError(form) {
        var banner = form.querySelector('.pin-error');
        if (!banner || banner.dataset.client) return;
        var text = banner.textContent || '';
        var inputs = form.querySelectorAll('.pin-input');
        var current = form.querySelector('input[name="current_pin"]');
        var confirm = form.querySelector('input[name="new_pin_confirm"]');
        var np = form.querySelector('input[name="new_pin"]');

        if (current) {
            // окно смены PIN: подсвечиваем именно то поле, где ошибка
            if (/Текущий/i.test(text)) { current._pin.setError(true); current.focus(); }
            else if (/не совпадают/i.test(text)) { confirm._pin.setError(true); np._pin.setError(true); np.focus(); }
            else { np._pin.setError(true); np.focus(); }
        } else {
            // экран входа / создания PIN: подсвечиваем все поля
            inputs.forEach(function (inp) { if (inp._pin) inp._pin.setError(true); });
            if (inputs[0]) inputs[0].focus();
        }
    }

    function init() {
        var inputs = document.querySelectorAll('.pin-input');
        var forms = [];
        inputs.forEach(function (inp) {
            build(inp);
            if (inp.form && forms.indexOf(inp.form) === -1) forms.push(inp.form);
        });

        forms.forEach(function (form) {
            // отключаем стандартное всплывающее «Заполните это поле»
            form.noValidate = true;
            form.addEventListener('submit', function (e) {
                if (!validate(form)) e.preventDefault();
            });
            form.addEventListener('reset', function () {
                setTimeout(function () {
                    form.querySelectorAll('.pin-input').forEach(function (inp) {
                        if (inp._pin) { inp._pin.setError(false); inp._pin.render(); }
                    });
                    setBanner(form, '');
                }, 0);
            });
            markServerError(form);
        });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();

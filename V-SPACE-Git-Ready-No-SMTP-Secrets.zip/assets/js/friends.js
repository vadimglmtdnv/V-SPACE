document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    var params = new URLSearchParams(window.location.search);

    // ===== Автоскрытие уведомлений =====
    document.querySelectorAll('.notification').forEach(function (n) {
        setTimeout(function () {
            n.style.transition = 'all 0.3s ease';
            n.style.opacity = '0';
            n.style.transform = 'translateX(-50%) translateY(-20px)';
            setTimeout(function () { n.remove(); }, 300);
        }, 3000);
    });

    // ===== Поиск: отправка по Enter или кнопке, фокус сохраняется =====
    var searchInput = document.querySelector('.friend-search input');
    if (searchInput) {
        if (params.get('action') === 'add' || params.get('search')) {
            setTimeout(function () {
                searchInput.focus();
                var len = searchInput.value.length;
                searchInput.setSelectionRange(len, len);
            }, 100);
        }
    }

    // ===== Прокрутка к результатам поиска =====
    if (params.get('search')) {
        var sections = document.querySelectorAll('.section');
        for (var i = 0; i < sections.length; i++) {
            var title = sections[i].querySelector('.section-title');
            if (title && title.textContent.indexOf('Результаты поиска') !== -1) {
                (function (el) {
                    setTimeout(function () { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 300);
                })(sections[i]);
                break;
            }
        }
    }

    // ===== Запоминаем последний диалог =====
    document.querySelectorAll('.friend-button[href*="messages.php"]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var m = this.href.match(/dialog=(\d+)/);
            if (m) {
                try { localStorage.setItem('last_dialog_id', m[1]); } catch (e) {}
            }
        });
    });

    // ===== Подтверждение отклонения заявки =====
    document.querySelectorAll('button[name="reject_request"]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            if (!confirm('Отклонить заявку в друзья?')) e.preventDefault();
        });
    });

    // ===== Подтверждение выхода =====
    document.querySelectorAll('.logout-item').forEach(function (item) {
        item.addEventListener('click', function (e) {
            if (!confirm('Вы уверены, что хотите выйти?')) e.preventDefault();
        });
    });
});

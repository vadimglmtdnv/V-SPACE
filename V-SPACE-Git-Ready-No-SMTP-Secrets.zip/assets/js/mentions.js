(function () {
    'use strict';

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function setupMentionInput(input) {
        if (!input || input.dataset.mentionsReady === '1') return;
        input.dataset.mentionsReady = '1';

        const wrapper = document.createElement('div');
        wrapper.className = 'mention-input-wrapper';
        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);

        const list = document.createElement('div');
        list.className = 'mention-suggestions';
        list.hidden = true;
        wrapper.appendChild(list);

        let users = [];
        let activeIndex = -1;

        function close() {
            list.hidden = true;
            list.innerHTML = '';
            users = [];
            activeIndex = -1;
        }

        function render() {
            list.innerHTML = users.map(function (user, index) {
                return '<button type="button" class="mention-suggestion' +
                    (index === activeIndex ? ' is-active' : '') +
                    '" data-index="' + index + '">' +
                    escapeHtml(user.username) + '</button>';
            }).join('');
            list.hidden = users.length === 0;
        }

        function insertUser(user) {
            const value = input.value;
            const cursor = input.selectionStart || value.length;
            const before = value.slice(0, cursor);
            const match = before.match(/(^|[\s])@([^\s@()]*)$/u);
            if (!match) return close();

            const start = cursor - match[0].length + match[1].length;
            const accountNumber = String(user.id).padStart(5, '0');
            const replacement = '@' + user.username + ' (' + accountNumber + ') ';
            input.value = value.slice(0, start) + replacement + value.slice(cursor);
            const nextCursor = start + replacement.length;
            input.setSelectionRange(nextCursor, nextCursor);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            close();
        }

        list.addEventListener('click', function (event) {
            const button = event.target.closest('.mention-suggestion');
            if (button) insertUser(users[Number(button.dataset.index)]);
        });

        input.addEventListener('input', function () {
            const cursor = input.selectionStart || 0;
            const match = input.value.slice(0, cursor).match(/(^|[\s])@([^\s@()]*)$/u);
            if (!match) return close();

            const query = match[2];
            if (query.length < 1) return close();

            fetch('messages.php?api=users&q=' + encodeURIComponent(query), {
                credentials: 'same-origin'
            })
                .then(function (response) { return response.json(); })
                .then(function (data) {
                    users = data.success && Array.isArray(data.users) ? data.users.slice(0, 8) : [];
                    activeIndex = -1;
                    render();
                })
                .catch(function () { close(); });
        });

        input.addEventListener('keydown', function (event) {
            if (list.hidden || users.length === 0) return;
            if (event.key === 'ArrowDown') {
                event.preventDefault();
                activeIndex = (activeIndex + 1) % users.length;
                render();
            } else if (event.key === 'ArrowUp') {
                event.preventDefault();
                activeIndex = (activeIndex - 1 + users.length) % users.length;
                render();
            } else if (event.key === 'Enter' && activeIndex >= 0) {
                event.preventDefault();
                insertUser(users[activeIndex]);
            } else if (event.key === 'Escape') {
                close();
            }
        });
    }

    function init() {
        document.querySelectorAll('#messageInput, .comment-form input[name="comment"], .comment-form-modal input[name="comment"]')
            .forEach(setupMentionInput);
    }

    document.addEventListener('DOMContentLoaded', init);
    window.setupMentionInputs = init;
})();

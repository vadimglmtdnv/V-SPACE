'use strict';
const api = window.shellApi;
const $ = (s) => document.querySelector(s);
let state = null;

function render(s) {
  state = s;
  document.body.classList.toggle('mac', s.platform === 'darwin');
  $('#setup').hidden = s.mode !== 'setup';
  $('#lock').hidden = s.mode !== 'locked';
  $('#rail').classList.toggle('off', s.mode !== 'app');
  $('#offline').hidden = !(s.offline && s.mode === 'app');
  $('#reload').hidden = s.mode !== 'app';
  if (s.mode === 'locked') { $('#pin').value = ''; $('#pin').focus(); }
  if (s.mode === 'setup') $('#setupUrl').focus();
  if (!$('#dlg').hidden) fillDialog();
}

/* ---------- навигация ---------- */
document.querySelectorAll('[data-nav]').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('[data-nav]').forEach((x) => x.classList.toggle('on', x === b));
  api.nav(b.dataset.nav);
}));
$('#reload').addEventListener('click', () => api.reload());
$('#lockBtn').addEventListener('click', () => api.lock());
api.onTitle((t) => { $('#pageTitle').textContent = t; });

/* ---------- первый запуск ---------- */
async function connect() {
  const r = await api.setServer($('#setupUrl').value);
  $('#setupErr').textContent = r && !r.ok ? r.error : '';
}
$('#setupGo').addEventListener('click', connect);
$('#setupUrl').addEventListener('keydown', (e) => { if (e.key === 'Enter') connect(); });

/* ---------- блокировка ---------- */
async function unlock() {
  const r = await api.unlock($('#pin').value);
  if (r && r.ok) return;
  $('#pinErr').textContent = r && r.wait ? `Слишком много попыток. Подождите ${r.wait} с` : 'Неверный PIN';
  const f = $('#pin');
  f.value = '';
  f.classList.remove('shake'); void f.offsetWidth; f.classList.add('shake');
  f.focus();
}
$('#unlockGo').addEventListener('click', unlock);
$('#pin').addEventListener('keydown', (e) => { if (e.key === 'Enter') unlock(); });
$('#pin').addEventListener('input', () => { $('#pinErr').textContent = ''; });

/* ---------- активность (для автоблокировки) ---------- */
let lastPing = 0;
['pointerdown', 'keydown', 'wheel'].forEach((ev) => window.addEventListener(ev, () => {
  const now = Date.now();
  if (now - lastPing > 5000) { lastPing = now; api.activity(); }
}, true));

/* ---------- настройки ---------- */
function say(text, ok) {
  const m = $('#dlgMsg');
  m.textContent = text || '';
  m.classList.toggle('ok', !!ok);
}
function fillDialog() {
  $('#srv').value = state.server;
  $('#idle').value = String(state.lockMinutes);
  $('#shield').checked = state.contentProtection;
  $('#pinCur').hidden = !state.hasPin;
  $('#pinOff').hidden = !state.hasPin;
  $('#idle').disabled = !state.hasPin;
}
function openDialog() {
  api.overlay(true);
  $('#dlg').hidden = false;
  $('#pinCur').value = ''; $('#pinNew').value = ''; say('');
  fillDialog();
}
function closeDialog() { $('#dlg').hidden = true; api.overlay(false); }

$('#openSettings').addEventListener('click', openDialog);
$('#dlgClose').addEventListener('click', closeDialog);
$('#dlg').addEventListener('click', (e) => { if (e.target === $('#dlg')) closeDialog(); });
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#dlg').hidden) closeDialog(); });

$('#srvSave').addEventListener('click', async () => {
  const r = await api.setServer($('#srv').value);
  if (r && r.ok) closeDialog(); else say(r && r.error);
});
$('#pinSave').addEventListener('click', async () => {
  const r = await api.setPin({ current: $('#pinCur').value, next: $('#pinNew').value });
  $('#pinCur').value = ''; $('#pinNew').value = '';
  if (r && r.ok) say('PIN сохранён', true); else say(r && r.error);
});
$('#pinOff').addEventListener('click', async () => {
  const r = await api.clearPin($('#pinCur').value);
  $('#pinCur').value = '';
  if (r && r.ok) say('PIN отключён', true); else say(r && r.error);
});
const saveOptions = () => api.setOptions({ lockMinutes: Number($('#idle').value), contentProtection: $('#shield').checked });
$('#idle').addEventListener('change', saveOptions);
$('#shield').addEventListener('change', saveOptions);

api.onState(render);
api.getState().then(render);

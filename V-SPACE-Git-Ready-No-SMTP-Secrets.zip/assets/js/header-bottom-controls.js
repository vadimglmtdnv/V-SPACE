(function () {
    'use strict';

    var phone = window.matchMedia('(max-width: 640px)');
    var nav = document.getElementById('site-navigator');
    var bottomTarget = document.getElementById('bottomUtilityControls');
    var cornerTarget = document.getElementById('topCornerControls');
    var controls = [];

    function rememberControl(selector, target) {
        var element = document.querySelector(selector);
        if (!element || !element.parentNode) return;
        var marker = document.createComment('header-control-position');
        element.parentNode.insertBefore(marker, element);
        controls.push({ element: element, marker: marker, target: target });
    }

    rememberControl('.notifications-wrapper', cornerTarget);
    rememberControl('.header-right .avatar-dropdown', bottomTarget);

    function positionControls() {
        if (!nav || !bottomTarget || !cornerTarget) return;
        if (phone.matches) {
            controls.forEach(function (control) {
                control.target.appendChild(control.element);
            });
            bottomTarget.hidden = !controls.some(function (control) {
                return control.target === bottomTarget;
            });
            cornerTarget.hidden = !controls.some(function (control) {
                return control.target === cornerTarget;
            });
            return;
        }

        controls.forEach(function (control) {
            if (control.marker.parentNode) {
                control.marker.parentNode.insertBefore(control.element, control.marker.nextSibling);
            }
        });
        bottomTarget.hidden = true;
        cornerTarget.hidden = true;
    }

    function suppressNativeTooltips() {
        var titled = document.querySelectorAll('[title]');
        Array.prototype.forEach.call(titled, function (element) {
            if (phone.matches) {
                element.setAttribute('data-mobile-title', element.getAttribute('title'));
                element.removeAttribute('title');
            }
        });

        if (!phone.matches) {
            var stored = document.querySelectorAll('[data-mobile-title]');
            Array.prototype.forEach.call(stored, function (element) {
                if (!element.hasAttribute('title')) {
                    element.setAttribute('title', element.getAttribute('data-mobile-title'));
                }
                element.removeAttribute('data-mobile-title');
            });
        }
    }

    positionControls();
    suppressNativeTooltips();

    var tooltipObserver = new MutationObserver(function (mutations) {
        if (!phone.matches) return;
        mutations.forEach(function (mutation) {
            var element = mutation.target;
            if (element.hasAttribute && element.hasAttribute('title')) {
                element.setAttribute('data-mobile-title', element.getAttribute('title'));
                element.removeAttribute('title');
            }
        });
    });
    tooltipObserver.observe(document.body, {
        attributes: true,
        attributeFilter: ['title'],
        subtree: true
    });

    function onViewportChange() {
        positionControls();
        suppressNativeTooltips();
    }
    if (phone.addEventListener) phone.addEventListener('change', onViewportChange);
    else if (phone.addListener) phone.addListener(onViewportChange);
    window.addEventListener('resize', onViewportChange);
})();

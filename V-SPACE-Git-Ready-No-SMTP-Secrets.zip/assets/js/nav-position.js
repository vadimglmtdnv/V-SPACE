/* Положение и закрепление панели навигации.
   1) Если атрибутов data-nav-pos / data-nav-pin ещё нет (страницы, где их не ставит PHP) — берём значения из кук
      nav_pos и nav_pin.
   2) Считает высоту шапки в --nav-offset (панель «сверху» выезжает под шапкой).
   3) Для режимов «сверху / слева» рисует язычок у края экрана и связывает его со штатным #handleBtn.
   4) Если панель закреплена (nav_pin = 1) — она всегда на виду и никуда не уезжает. */
(function () {
    var ALLOWED = ['bottom', 'top', 'left'];
    var root = document.documentElement;
    var pinSetup = false;
    var phoneMq = window.matchMedia('(max-width: 640px)');
    var saved = null;   // положение и закрепление, выбранные на ПК

    // На телефоне панель всегда снизу; сохранённое «сверху / слева» возвращается на ПК
    function applyPhoneRule() {
        var body = document.body;
        if (!body) return;
        if (saved === null) {
            saved = { pos: body.getAttribute('data-nav-pos') || 'bottom', pin: body.getAttribute('data-nav-pin') || '0' };
        }
        if (phoneMq.matches) {
            body.setAttribute('data-nav-pos', 'bottom');
            body.setAttribute('data-nav-pin', readCookie('nav_pin') === '1' ? '1' : '0');
        } else {
            body.setAttribute('data-nav-pos', saved.pos);
            body.setAttribute('data-nav-pin', saved.pin);
        }
    }

    function readCookie(name) {
        var m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
        return m ? decodeURIComponent(m[1]) : '';
    }

    function attr(name) {
        var el = document.querySelector('[' + name + ']');
        return el ? el.getAttribute(name) : '';
    }

    function currentPos() {
        var pos = attr('data-nav-pos');
        return ALLOWED.indexOf(pos) !== -1 ? pos : 'bottom';
    }

    function isPinned() {
        return attr('data-nav-pin') === '1';
    }

    if (!document.querySelector('[data-nav-pos]')) {
        var savedPos = readCookie('nav_pos');
        root.setAttribute('data-nav-pos', ALLOWED.indexOf(savedPos) !== -1 ? savedPos : 'bottom');
    }
    if (!document.querySelector('[data-nav-pin]')) {
        root.setAttribute('data-nav-pin', readCookie('nav_pin') === '1' ? '1' : '0');
    }

    function updateOffset() {
        var header = document.querySelector('header.header') || document.querySelector('.header');
        var offset = 0;
        if (header) {
            var position = window.getComputedStyle(header).position;
            if (position === 'fixed' || position === 'sticky') {
                offset = Math.round(header.getBoundingClientRect().height);
            }
        }
        root.style.setProperty('--nav-offset', offset + 'px');
    }

    function setupEdgeHandle() {
        var pos = currentPos();
        var handle = document.getElementById('handleBtn');
        var nav = document.getElementById('site-navigator');
        if (pos === 'bottom' || !handle || !nav || document.querySelector('.nav-edge-handle')) return;

        var edge = document.createElement('button');
        edge.type = 'button';
        edge.className = 'nav-edge-handle';
        edge.setAttribute('aria-label', 'Панель навигации');
        edge.innerHTML = '<span class="nav-edge-bar"></span>';
        document.body.appendChild(edge);

        // Язычок виден только пока панель спрятана (так же, как штатный)
        function sync() {
            edge.classList.toggle('is-hidden', !nav.classList.contains('nav-hidden'));
        }
        new MutationObserver(sync).observe(nav, { attributes: true, attributeFilter: ['class'] });
        sync();

        // Наведение — панель выезжает (как у штатного язычка)
        edge.addEventListener('mouseenter', function () {
            handle.dispatchEvent(new MouseEvent('mouseenter'));
        });
        // Клик (в том числе на сенсорном экране) — выезжает, если ещё спрятана
        edge.addEventListener('click', function () {
            if (nav.classList.contains('nav-hidden')) handle.click();
        });
    }

    // Закреплённая панель: сразу показываем и не даём скриптам страницы её спрятать
    function setupPin() {
        var nav = document.getElementById('site-navigator');
        var handle = document.getElementById('handleBtn');
        var phone = window.matchMedia('(max-width: 640px)');
        if (!nav || pinSetup) return;
        pinSetup = true;

        function enforce() {
            if (phone.matches || !isPinned()) return;
            if (nav.classList.contains('nav-hidden')) nav.classList.remove('nav-hidden');
            if (handle && !handle.classList.contains('handle-hidden')) handle.classList.add('handle-hidden');
        }
        enforce();
        new MutationObserver(enforce).observe(nav, { attributes: true, attributeFilter: ['class'] });
        if (handle) new MutationObserver(enforce).observe(handle, { attributes: true, attributeFilter: ['class'] });
        new MutationObserver(enforce).observe(document.body, { attributes: true, attributeFilter: ['data-nav-pin'] });
        if (phone.addEventListener) phone.addEventListener('change', enforce);
        else if (phone.addListener) phone.addListener(enforce);
    }

    document.addEventListener('DOMContentLoaded', function () {
        applyPhoneRule();
        updateOffset();
        setupEdgeHandle();
        setupPin();
    });
    window.addEventListener('load', function () {
        updateOffset();
        setupPin();
    });
    window.addEventListener('resize', updateOffset);
    if (phoneMq.addEventListener) phoneMq.addEventListener('change', applyPhoneRule);
    else if (phoneMq.addListener) phoneMq.addListener(applyPhoneRule);
})();

(function () {
    'use strict';

    const layout = document.querySelector('.layout');
    const main = layout && layout.querySelector(':scope > main');
    const sidebar = layout && layout.querySelector(':scope > .right-sidebar');
    const anchor = document.querySelector('[data-mobile-friends-anchor]');
    if (!layout || !main || !sidebar || !anchor) return;

    const mobileLayout = window.matchMedia('(max-width: 860px)');

    function positionFriends() {
        if (mobileLayout.matches) {
            sidebar.classList.add('is-mobile-friends');
            anchor.insertAdjacentElement('afterend', sidebar);
        } else {
            sidebar.classList.remove('is-mobile-friends');
            main.insertAdjacentElement('afterend', sidebar);
        }
    }

    positionFriends();
    if (mobileLayout.addEventListener) {
        mobileLayout.addEventListener('change', positionFriends);
    } else {
        mobileLayout.addListener(positionFriends);
    }
})();

document.addEventListener('DOMContentLoaded', function() {

    // Экранирование текста для вставки в HTML (в т.ч. в атрибуты)
    function escapeHtml(text) {
        return String(text == null ? '' : text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    // Разрешаем только http(s), относительные пути и data:image — блокируем javascript: и т.п.
    function safeUrl(url, fallback) {
        url = String(url == null ? '' : url).trim();
        if (url === '') return fallback || '';
        if (/^(https?:)?\/\//i.test(url) || /^data:image\/(png|jpe?g|gif|webp);/i.test(url)) return url;
        if (/^[a-z][a-z0-9+.-]*:/i.test(url)) return fallback || '';
        return url;
    }

    const avatarBtn = document.getElementById('avatarBtn');
    const dropdown = document.getElementById('avatarDropdown');

    if (avatarBtn && dropdown) {
        const overlay = document.createElement('div');
        overlay.className = 'dropdown-overlay';
        document.body.appendChild(overlay);

        function closeDropdown() {
            dropdown.classList.remove('active');
            overlay.classList.remove('active');
        }

        avatarBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            dropdown.classList.toggle('active');
            overlay.classList.toggle('active');
        });

        overlay.addEventListener('click', function(e) {
            e.preventDefault();
            closeDropdown();
        });

        document.addEventListener('click', function(e) {
            if (!dropdown.contains(e.target) && !avatarBtn.contains(e.target)) {
                closeDropdown();
            }
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closeDropdown();
        });

        dropdown.querySelectorAll('a.dropdown-item').forEach(function(item) {
            item.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href && href !== '#') {
                    closeDropdown();
                    window.location.href = href;
                }
            });
        });
    }

    const themeTrigger = document.getElementById('themeTrigger');
    const themeSubmenu = document.getElementById('themeSubmenu');
    const themeArrow = document.getElementById('themeArrow');

    if (themeTrigger && themeSubmenu && themeArrow) {
        themeTrigger.addEventListener('click', function(e) {
            e.stopPropagation();
            themeSubmenu.classList.toggle('open');
            themeArrow.classList.toggle('open');
        });

    }

    document.addEventListener('click', function(e) {
        if (themeTrigger && themeSubmenu && themeArrow) {
            if (!themeTrigger.contains(e.target) && !themeSubmenu.contains(e.target)) {
                themeSubmenu.classList.remove('open');
                themeArrow.classList.remove('open');
            }
        }
    });

    const postImageInput = document.getElementById('postImage');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const removeImageBtn = document.getElementById('removeImageBtn');

    if (postImageInput && imagePreviewContainer && imagePreview) {
        postImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreviewContainer.classList.add('show');
                };
                reader.readAsDataURL(file);
            } else {
                imagePreviewContainer.classList.remove('show');
            }
        });
    }

    if (imagePreview) {
        imagePreview.style.cursor = 'zoom-in';
        imagePreview.addEventListener('click', function() {
            var modal = document.getElementById('photoModal');
            var modalImage = document.getElementById('modalImage');
            if (!modal || !modalImage || !imagePreview.getAttribute('src')) return;

            modalImage.src = imagePreview.src;
            modal.classList.add('active', 'preview-only');
            document.body.style.overflow = 'hidden';
        });
    }

    if (removeImageBtn) {
        removeImageBtn.addEventListener('click', function() {
            if (postImageInput) postImageInput.value = '';
            if (imagePreviewContainer) imagePreviewContainer.classList.remove('show');
        });
    }

    const notificationsDropdown = document.getElementById('notificationsDropdown');
    const notificationsList = document.getElementById('notificationsList');
    const notificationsBadge = document.querySelector('.notifications-badge');
    const markAllReadBtn = document.getElementById('markAllReadBtn');

    function getTimeAgo(datetime) {
        const timestamp = new Date(datetime).getTime();
        const now = Date.now();
        const diff = Math.floor((now - timestamp) / 1000);
        
        if (diff < 60) return 'только что';
        if (diff < 3600) return Math.floor(diff / 60) + 'м';
        if (diff < 86400) return Math.floor(diff / 3600) + 'ч';
        if (diff < 604800) return Math.floor(diff / 86400) + 'д';
        return new Date(datetime).toLocaleDateString('ru-RU');
    }

    function loadNotifications() {
        if (!notificationsList) return;
        
        fetch('api/get_notifications.php')
            .then(function(response) { 
                if (!response.ok) {
                    throw new Error('Ошибка HTTP: ' + response.status);
                }
                return response.json(); 
            })
            .then(function(data) {
                if (data.success) {
                    renderNotifications(data.notifications);
                    updateBadge(data.count);
                }
            })
            .catch(function(error) {
                notificationsList.innerHTML = '<div class="notifications-empty">Ошибка загрузки</div>';
            });
    }

    function renderNotifications(notifications) {
        if (!notificationsList) return;

        if (!notifications || notifications.length === 0) {
            notificationsList.innerHTML = `
                <div class="notifications-empty">
                    <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
                    <div class="empty-text">Нет уведомлений</div>
                    <div class="empty-sub">Здесь будут появляться ваши уведомления</div>
                </div>
            `;
            return;
        }

        notificationsList.innerHTML = '';
        notifications.forEach(function(notif) {
            const item = document.createElement('a');
            const isUnread = notif.is_read == 0;
            item.className = 'notification-item' + (isUnread ? ' unread' : ' read');
            item.href = safeUrl(notif.link, '#') || '#';
            item.dataset.notificationId = String(parseInt(notif.id, 10) || '');

            const timeStr = getTimeAgo(notif.created_at);
            
            const senderName = notif.sender_name || '';
            const senderAvatar = notif.sender_avatar || '';
            const avatarLetter = senderName ? senderName.charAt(0).toUpperCase() : '?';
            const safeAvatar = safeUrl(senderAvatar, '');

            // Ник уже выведен жирным — не повторяем его в начале текста
            let message = String(notif.message || '');
            if (senderName && message.indexOf(senderName) === 0) {
                message = message.slice(senderName.length).replace(/^\s+/, '');
            }

            item.innerHTML = 
                '<div class="notif-avatar-wrapper">' +
                    '<div class="notif-avatar">' +
                        (safeAvatar ? '<img src="' + escapeHtml(safeAvatar) + '" alt="">' : '<span class="avatar-letter">' + escapeHtml(avatarLetter) + '</span>') +
                    '</div>' +
                '</div>' +
                '<div class="notif-content">' +
                    '<div class="notif-text">' +
                        (senderName ? '<strong class="notif-sender">' + escapeHtml(senderName) + '</strong>' : '') +
                        '<span class="notif-message">' + escapeHtml(message) + '</span>' +
                    '</div>' +
                    '<div class="notif-meta">' +
                        '<span class="notif-time">' + escapeHtml(timeStr) + '</span>' +
                    '</div>' +
                '</div>' +
                (isUnread ? '<span class="notif-dot"></span>' : '');

            item.addEventListener('click', function(e) {
                const notifId = this.dataset.notificationId;
                if (notifId) {
                    markAsRead(notifId);
                }
            });

            notificationsList.appendChild(item);
        });
    }

    function markAsRead(notificationId) {
        fetch('api/mark_notifications_read.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + encodeURIComponent(notificationId)
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                loadNotifications();
            }
        })
        .catch(function() {});
    }

    function updateBadge(count) {
        if (!notificationsBadge) return;
        if (count > 0) {
            notificationsBadge.textContent = count > 99 ? '99+' : count;
            notificationsBadge.style.display = 'flex';
        } else {
            notificationsBadge.style.display = 'none';
        }
        // Обновляем счетчик в заголовке
        const notifCountElem = document.getElementById('notificationsCount');
        if (notifCountElem) {
            notifCountElem.textContent = count + ' новых';
        }
        // Показываем/скрываем кнопку "Все прочитано"
        if (markAllReadBtn) {
            if (count > 0) {
                markAllReadBtn.style.display = 'inline-block';
            } else {
                markAllReadBtn.style.display = 'none';
            }
        }
    }

    document.addEventListener('vspace:notifications-open', function () {
        loadNotifications();
    });

    // ===== КНОПКА "ВСЕ ПРОЧИТАНО" =====
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const btn = this;
            const originalText = btn.textContent;
            btn.textContent = '⏳...';
            btn.disabled = true;
            
            fetch('api/mark_notifications_read.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=0'
            })
            .then(function(response) { 
                if (!response.ok) {
                    throw new Error('Ошибка HTTP: ' + response.status);
                }
                return response.json(); 
            })
            .then(function(data) {
                if (data.success) {
                    loadNotifications();
                    updateBadge(0);
                    if (notificationsList) {
                        notificationsList.innerHTML = `
                            <div class="notifications-empty">
                                <div class="empty-icon"><svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg></div>
                                <div class="empty-text">Все уведомления прочитаны</div>
                                <div class="empty-sub">Новых уведомлений нет</div>
                            </div>
                        `;
                    }
                } else {
                    alert('Ошибка при отметке уведомлений');
                }
            })
            .catch(function(error) {
                console.error('Ошибка:', error);
                alert('Ошибка при отметке уведомлений');
            })
            .finally(function() {
                btn.textContent = originalText;
                btn.disabled = false;
            });
        });
    }

    // Загружаем уведомления при загрузке
    loadNotifications();

    const audio = document.querySelector(".voice-audio");
    const playButton = document.querySelector(".voice-play");
    const waveform = document.querySelector(".waveform");
    const waveBars = document.querySelector(".wave-bars");
    const currentTimeElement = document.querySelector(".current-time");
    const durationElement = document.querySelector(".duration");

    if (audio && playButton && waveform && waveBars) {
        const BAR_COUNT = 55;

        for (var i = 0; i < BAR_COUNT; i++) {
            const bar = document.createElement("div");
            bar.className = "wave-bar";
            bar.style.height = (Math.floor(Math.random() * 25) + 7) + "px";
            waveBars.appendChild(bar);
        }

        const bars = Array.from(document.querySelectorAll(".wave-bar"));

        function formatTime(seconds) {
            if (!isFinite(seconds) || isNaN(seconds)) return "0:00";
            seconds = Math.floor(seconds);
            const minutes = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return minutes + ":" + String(secs).padStart(2, "0");
        }

        audio.addEventListener("loadedmetadata", function() {
            durationElement.textContent = formatTime(audio.duration);
        });

        playButton.addEventListener("click", function() {
            audio.paused ? audio.play() : audio.pause();
        });

        audio.addEventListener("play", function() {
            playButton.classList.add("playing");
        });

        audio.addEventListener("pause", function() {
            playButton.classList.remove("playing");
        });

        audio.addEventListener("timeupdate", function() {
            const current = audio.currentTime;
            const duration = audio.duration;
            currentTimeElement.textContent = formatTime(current);

            if (!duration) return;

            const progress = current / duration;
            const playedCount = Math.floor(progress * bars.length);

            bars.forEach(function(bar, index) {
                bar.classList.toggle("played", index < playedCount);
            });
        });

        waveform.addEventListener("click", function(event) {
            const rect = waveform.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const percent = Math.max(0, Math.min(1, x / rect.width));
            audio.currentTime = percent * audio.duration;
        });

        audio.addEventListener("ended", function() {
            playButton.classList.remove("playing");
            currentTimeElement.textContent = "0:00";
            bars.forEach(function(bar) {
                bar.classList.remove("played");
            });
            audio.currentTime = 0;
        });
    }

    const handleBtn = document.getElementById('handleBtn');
    const bottomNav = document.querySelector('.bottom-nav') || document.querySelector('app-navigation.bottom-nav');
    let lastScrollTop = 0;
    let hoverTimeout = null;
    let isNavVisible = false;

    function showNav() {
        if (!bottomNav) return;
        bottomNav.classList.remove('nav-hidden');
        if (handleBtn) handleBtn.classList.add('handle-hidden');
        isNavVisible = true;
    }

    function hideNav() {
        if (!bottomNav) return;
        bottomNav.classList.add('nav-hidden');
        if (handleBtn) handleBtn.classList.remove('handle-hidden');
        isNavVisible = false;
    }

    if (handleBtn && bottomNav && !bottomNav.hasAttribute('data-managed-by-partial')) {
        // По умолчанию навигация скрыта
        hideNav();

        handleBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (bottomNav.classList.contains('nav-hidden')) {
                showNav();
            } else {
                hideNav();
            }
        });

        handleBtn.addEventListener('mouseenter', function() {
            if (hoverTimeout) {
                clearTimeout(hoverTimeout);
                hoverTimeout = null;
            }
            showNav();
        });

        handleBtn.addEventListener('mouseleave', function() {
            hoverTimeout = setTimeout(function() {
                if (bottomNav && !bottomNav.matches(':hover')) {
                    hideNav();
                }
            }, 400);
        });

        if (bottomNav) {
            bottomNav.addEventListener('mouseenter', function() {
                if (hoverTimeout) {
                    clearTimeout(hoverTimeout);
                    hoverTimeout = null;
                }
            });

            bottomNav.addEventListener('mouseleave', function() {
                if (handleBtn && !handleBtn.matches(':hover')) {
                    hideNav();
                }
            });
        }
    }

    if (bottomNav && !bottomNav.hasAttribute('data-managed-by-partial')) {
        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollTop > lastScrollTop && scrollTop > 100) {
                // Скролл вниз - показываем навигацию
                showNav();
            } else if (scrollTop < lastScrollTop && scrollTop > 50) {
                // Скролл вверх - скрываем навигацию
                hideNav();
            } else if (scrollTop <= 50) {
                // В самом верху - скрываем
                hideNav();
            }

            lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
        });
    }

    document.querySelectorAll('.toggle-comments').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var postId = this.dataset.postId;
            var comments = document.getElementById('comments-' + postId);
            if (comments) {
                if (comments.style.display === 'none' || comments.style.display === '') {
                    comments.style.display = 'block';
                } else {
                    comments.style.display = 'none';
                }
            }
        });
    });

    /* ===== Шапка поста в модалке: аватар, ник, время, лайк и «поделиться» ===== */
    function getFeedPost(postId) {
        return document.querySelector('.post-item[data-post-id="' + postId + '"]');
    }

    function currentModalPostId() {
        var hidden = document.getElementById('modalPostId');
        return hidden ? hidden.value : '';
    }

    // Копирует состояние кнопок лайка/репоста из ленты в модалку
    window.syncModalPostActions = function(postId) {
        if (String(postId) !== String(currentModalPostId())) return;
        var post = getFeedPost(postId);
        if (!post) return;
        [
            ['.ajax-like-form', 'modalLikeBtn'],
            ['.ajax-repost-form', 'modalRepostBtn']
        ].forEach(function(pair) {
            var src = post.querySelector(pair[0] + ' .post-action-btn');
            var dst = document.getElementById(pair[1]);
            if (!src || !dst) return;
            dst.className = src.className;
            dst.querySelector('.action-icon').innerHTML = src.querySelector('.action-icon').innerHTML;
            dst.querySelector('.action-count').textContent = src.querySelector('.action-count').textContent;
        });
    };

    window.fillModalPost = function(postId) {
        var info = document.getElementById('modalPostInfo');
        if (!info) return;

        var post = getFeedPost(postId);
        if (!post) { info.hidden = true; return; }

        var srcAvatar = post.querySelector('.post-header .post-avatar');
        var srcAuthor = post.querySelector('.post-header .post-author');
        var srcTime   = post.querySelector('.post-header .post-time');

        var avatarBox = document.getElementById('modalPostAvatar');
        var authorEl  = document.getElementById('modalPostAuthor');
        var timeEl    = document.getElementById('modalPostTime');

        if (avatarBox) {
            avatarBox.innerHTML = '';
            if (srcAvatar) {
                var clone = srcAvatar.cloneNode(true);
                var dot = clone.querySelector('.status-dot-small');
                if (dot) dot.remove();
                avatarBox.innerHTML = clone.innerHTML.trim();
            }
        }
        if (authorEl) {
            authorEl.textContent = srcAuthor ? srcAuthor.textContent.trim() : '';
            authorEl.setAttribute('href', srcAuthor ? (srcAuthor.getAttribute('href') || '#') : '#');
        }
        if (timeEl) timeEl.textContent = srcTime ? srcTime.textContent.trim() : '';

        info.hidden = false;
        window.syncModalPostActions(postId);
    };

    // Клик по лайку / «поделиться» в модалке = клик по соответствующей форме в ленте
    [
        ['modalLikeBtn', '.ajax-like-form'],
        ['modalRepostBtn', '.ajax-repost-form']
    ].forEach(function(pair) {
        var btn = document.getElementById(pair[0]);
        if (!btn) return;
        btn.addEventListener('click', function() {
            var post = getFeedPost(currentModalPostId());
            var form = post && post.querySelector(pair[1]);
            if (!form) return;
            if (form.requestSubmit) {
                form.requestSubmit();
            } else {
                form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
            }
        });
    });

    window.openPhotoModal = function(postId, imageSrc) {
        var modal = document.getElementById('photoModal');
        var modalImage = document.getElementById('modalImage');
        var modalPostId = document.getElementById('modalPostId');
        
        if (!modal || !modalImage || !modalPostId) return;
        
        modalImage.src = imageSrc;
        modalPostId.value = postId;
        modal.classList.remove('preview-only');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        window.fillModalPost(postId);
        loadModalComments(postId);
    };

    window.closePhotoModal = function() {
        var modal = document.getElementById('photoModal');
        if (modal) {
            modal.classList.remove('active', 'preview-only');
            document.body.style.overflow = '';
        }
    };

    var photoModal = document.getElementById('photoModal');
    if (photoModal) {
        photoModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closePhotoModal();
            }
        });

        var photoModalImageBox = photoModal.querySelector('.photo-modal-image');
        if (photoModalImageBox) {
            photoModalImageBox.style.cursor = 'zoom-out';
            photoModalImageBox.addEventListener('click', function() {
                closePhotoModal();
            });
        }
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closePhotoModal();
            var dropdownMenu = document.getElementById('avatarDropdown');
            if (dropdownMenu) {
                dropdownMenu.classList.remove('active');
                var overlay = document.querySelector('.dropdown-overlay');
                if (overlay) overlay.classList.remove('active');
            }
            if (notificationsDropdown) {
                notificationsDropdown.style.display = 'none';
                notificationsDropdown.classList.remove('active');
            }
        }
    });

    function loadModalComments(postId) {
        var list = document.getElementById('modalCommentsList');
        if (!list) return;
        
        list.innerHTML = '<div class="no-comments">Загрузка...</div>';
        
        fetch('api/get_post_comments.php?post_id=' + encodeURIComponent(postId))
            .then(function(response) { 
                if (!response.ok) {
                    throw new Error('Сервер вернул ошибку: ' + response.status);
                }
                return response.json(); 
            })
            .then(function(data) {
                if (data.success && Array.isArray(data.comments) && data.comments.length > 0) {
                    var html = '';
                    data.comments.forEach(function(comment) {
                        var commentAvatar = safeUrl(comment.avatar, '');
                        var avatarHtml = commentAvatar
                            ? '<img src="' + escapeHtml(commentAvatar) + '" alt="">'
                            : escapeHtml(comment.letter || '?');
                        html += `
                            <div class="comment-item-modal">
                                <div class="comment-avatar-modal">${avatarHtml}</div>
                                <div class="comment-body-modal">
                                    <a href="index.php?user=${parseInt(comment.user_id, 10) || 0}" class="comment-author-modal">${escapeHtml(comment.username || 'Пользователь')}</a>
                                    <span class="comment-time-modal">${escapeHtml(comment.time || '')}</span>
                                    <div class="comment-text-modal">${escapeHtml(comment.comment || '')}</div>
                                </div>
                            </div>
                        `;
                    });
                    list.innerHTML = html;
                } else {
                    list.innerHTML = '<div class="no-comments">Нет комментариев</div>';
                }
            })
            .catch(function() {
                list.innerHTML = '<div class="no-comments">Ошибка загрузки комментариев</div>';
            });
    }

    const chatInput = document.querySelector('.chat-input');
    const sendBtn = document.querySelector('.send-btn');
    const chatMessages = document.querySelector('.chat-messages');

    if (sendBtn && chatInput) {
        sendBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const message = chatInput.value.trim();
            if (message === '') {
                chatInput.style.borderColor = '#da373c';
                chatInput.placeholder = 'Пожалуйста, введите сообщение...';
                return;
            }
            chatInput.style.borderColor = '';
            chatInput.placeholder = 'Введите сообщение...';
            sendMessage(message);
        });

        chatInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                sendBtn.click();
            }
        });

        chatInput.addEventListener('input', function() {
            if (this.style.borderColor === 'rgb(218, 55, 60)') {
                this.style.borderColor = '';
                this.placeholder = 'Введите сообщение...';
            }
        });
    }

    function sendMessage(message) {
        if (!chatMessages) return;
        
        const messageElement = document.createElement('div');
        messageElement.className = 'message-item message-sent';
        messageElement.innerHTML = `
            <div class="message-bubble">
                <span class="message-text">${escapeHtml(message)}</span>
                <span class="message-time">${new Date().toLocaleTimeString()}</span>
            </div>
        `;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        if (chatInput) chatInput.value = '';

        fetch('api/send_message.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message })
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success && data.reply) {
                const replyElement = document.createElement('div');
                replyElement.className = 'message-item message-received';
                replyElement.innerHTML = `
                    <div class="message-bubble">
                        <span class="message-text">${escapeHtml(data.reply)}</span>
                        <span class="message-time">${new Date().toLocaleTimeString()}</span>
                    </div>
                `;
                chatMessages.appendChild(replyElement);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        })
        .catch(function() {});
    }

    const searchInput = document.querySelector('.search-input');
    const searchResults = document.querySelector('.search-results');

    if (searchInput) {
        let searchTimeout = null;

        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const query = this.value.trim();
            
            if (query.length < 2) {
                if (searchResults) {
                    searchResults.innerHTML = '';
                    searchResults.style.display = 'none';
                }
                return;
            }

            searchTimeout = setTimeout(function() {
                performSearch(query);
            }, 400);
        });

        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                this.value = '';
                if (searchResults) {
                    searchResults.innerHTML = '';
                    searchResults.style.display = 'none';
                }
                this.blur();
            }
        });

        document.addEventListener('click', function(e) {
            if (searchResults && searchInput) {
                if (!searchResults.contains(e.target) && e.target !== searchInput) {
                    searchResults.style.display = 'none';
                }
            }
        });
    }

    function performSearch(query) {
        if (!searchResults) return;
        
        fetch('api/search.php?q=' + encodeURIComponent(query))
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success && data.results && data.results.length > 0) {
                    var html = '';
                    data.results.forEach(function(item) {
                        html += `
                            <a href="index.php?user=${parseInt(item.id, 10) || 0}" class="search-result-item">
                                <div class="search-result-avatar">
                                    ${safeUrl(item.avatar, '') ? '<img src="' + escapeHtml(safeUrl(item.avatar, '')) + '" alt="">' : escapeHtml(item.avatar_letter || '?')}
                                </div>
                                <div class="search-result-info">
                                    <div class="search-result-name">${escapeHtml(item.username)}</div>
                                    <div class="search-result-status ${item.status === 'online' ? 'online' : 'offline'}">${item.status === 'online' ? 'В сети' : 'Не в сети'}</div>
                                </div>
                            </a>
                        `;
                    });
                    searchResults.innerHTML = html;
                    searchResults.style.display = 'block';
                } else {
                    searchResults.innerHTML = '<div class="search-empty">Ничего не найдено</div>';
                    searchResults.style.display = 'block';
                }
            })
            .catch(function() {
                searchResults.innerHTML = '<div class="search-empty">Ошибка поиска</div>';
                searchResults.style.display = 'block';
            });
    }

    window.scrollToTop = function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.scrollToBottom = function() {
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    };

    const backToTop = document.querySelector('.back-to-top');
    if (backToTop) {
        backToTop.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollToTop();
        });

        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        });
    }

    const dropdownItems = document.querySelectorAll('.dropdown-item');
    dropdownItems.forEach(function(item) {
        item.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href && href.startsWith('http')) {
                e.preventDefault();
                window.open(href, '_blank');
            }
        });
    });

    // ===== ПЕРЕЗАПУСК АНИМАЦИИ HANDLE-BAR =====
    (function() {
        const handleBar = document.querySelector('.bottom-handle .handle-bar');
        if (handleBar) {
            const bottomNav = document.querySelector('.bottom-nav') ||
                              document.querySelector('app-navigation.bottom-nav');
            let animationTimeout = null;

            function stopAnimation() {
                if (animationTimeout) {
                    clearTimeout(animationTimeout);
                    animationTimeout = null;
                }
                handleBar.style.animation = 'none';
                handleBar.style.width = '40px';
            }

            function animateAfterDelay() {
                stopAnimation();
                if (!bottomNav || !bottomNav.classList.contains('nav-hidden')) return;

                animationTimeout = setTimeout(function() {
                    animationTimeout = null;
                    if (bottomNav.classList.contains('nav-hidden')) {
                        handleBar.style.animation = 'handleStretch 2s ease-in-out 1 forwards';
                    }
                }, 3000);
            }

            handleBar.addEventListener('animationend', function() {
                handleBar.style.animation = 'none';
                handleBar.style.width = '40px';
            });

            animateAfterDelay();
            
            // Также перезапускаем при наведении на handle
            const handle = document.getElementById('handleBtn');
            if (handle) {
                handle.addEventListener('mouseenter', function() {
                    animateAfterDelay();
                });
            }
            
            // Перезапускаем при показе навигации
            if (bottomNav) {
                const observer = new MutationObserver(function(mutations) {
                    mutations.forEach(function(mutation) {
                        if (mutation.attributeName === 'class') {
                            if (!bottomNav.classList.contains('nav-hidden')) {
                                stopAnimation();
                            } else {
                                animateAfterDelay();
                            }
                        }
                    });
                });
                observer.observe(bottomNav, { attributes: true });
            }
        }
    })();

});

(function() {
    'use strict';

    let statusUpdated = false;

    function updateUserStatus(status) {
        fetch('api/update_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: status || 'offline'
            })
        }).catch(function() {});
    }

    window.addEventListener('beforeunload', function() {
        if (!statusUpdated) {
            statusUpdated = true;
            
            const formData = new FormData();
            formData.append('status', 'offline');
            
            if (navigator.sendBeacon) {
                navigator.sendBeacon('api/update_status.php', formData);
            } else {
                fetch('api/update_status.php', {
                    method: 'POST',
                    body: JSON.stringify({ status: 'offline' }),
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    keepalive: true
                }).catch(function() {});
            }
        }
    });

    document.addEventListener('visibilitychange', function() {
        if (document.hidden && !statusUpdated) {
            statusUpdated = true;
            updateUserStatus('offline');
        } else if (!document.hidden) {
            statusUpdated = false;
            updateUserStatus('online');
        }
    });

})();
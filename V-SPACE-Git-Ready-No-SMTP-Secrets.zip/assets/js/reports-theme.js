/**
 * REPORTS-THEME.JS — Смена темы
 */

(function() {
    const C = 'theme';
    const D = 'dark';
    const L = 'light';
    const S = 'system';

    let btn = document.getElementById('themeToggleBtn');
    let menu = document.getElementById('themeMenu');
    let items = menu ? menu.querySelectorAll('.theme-item') : [];

    function setCookie(name, value, days) {
        const d = new Date();
        d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000);
        document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/';
    }

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : null;
    }

    function getSystemTheme() {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? D : L;
    }

    function updateMenu(active) {
        if (!items || !items.length) return;
        items.forEach(function(item) {
            const theme = item.getAttribute('data-theme');
            const check = item.querySelector('.theme-check');
            if (theme === active) {
                item.classList.add('active');
                if (check) check.textContent = '✓';
            } else {
                item.classList.remove('active');
                if (check) check.textContent = '';
            }
        });
    }

    function applyTheme(theme) {
        const effective = theme === S ? getSystemTheme() : theme;
        document.body.setAttribute('data-theme', effective);
        setCookie(C, theme, 365);
        updateMenu(theme);
    }

    function toggleMenu(e) {
        if (e) e.stopPropagation();
        if (menu) menu.classList.toggle('active');
    }

    function closeMenu() {
        if (menu) menu.classList.remove('active');
    }

    const currentTheme = getCookie(C) || D;
    applyTheme(currentTheme);

    if (btn) btn.addEventListener('click', toggleMenu);

    if (items && items.length) {
        items.forEach(function(item) {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const theme = this.getAttribute('data-theme');
                if (theme) {
                    applyTheme(theme);
                    closeMenu();
                }
            });
        });
    }

    document.addEventListener('click', function(e) {
        if (menu && btn && !menu.contains(e.target) && e.target !== btn && !btn.contains(e.target)) {
            closeMenu();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeMenu();
    });

    const media = window.matchMedia('(prefers-color-scheme: dark)');
    media.addEventListener('change', function() {
        if (getCookie(C) === S) applyTheme(S);
    });
})();
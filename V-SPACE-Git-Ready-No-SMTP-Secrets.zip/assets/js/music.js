document.addEventListener('DOMContentLoaded', function () {

    // Поиск: фокус в поле и выделение текста, если запрос уже введён
    var musicSearch = document.getElementById('musicSearch');
    if (musicSearch) {
        musicSearch.focus();
        if (musicSearch.value) {
            musicSearch.select();
        }
    }

    // Подтверждение для ссылок и кнопок с data-confirm (удаление трека, снятие роли)
    document.addEventListener('click', function (e) {
        var el = e.target.closest('[data-confirm]');
        if (!el) return;
        if (!window.confirm(el.getAttribute('data-confirm'))) {
            e.preventDefault();
        }
    });

    // «Моя музыка»: кнопка «+ / ✓» на чужом треке добавляет его себе или убирает
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.track-lib');
        if (!btn || btn.disabled) return;
        e.preventDefault();

        var id = btn.getAttribute('data-track-id');
        var adding = !btn.classList.contains('is-added');
        btn.disabled = true;

        fetch('music.php', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=' + (adding ? 'library_add' : 'library_remove') +
                  '&track_id=' + encodeURIComponent(id) +
                  '&csrf_token=' + encodeURIComponent(btn.getAttribute('data-csrf') || '')
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data || !data.ok) throw new Error('fail');
                var title = data.in ? 'Убрать из моей музыки' : 'Добавить в мою музыку';

                // Тот же трек может быть на странице дважды («Моя музыка» и общий список) — обновляем все кнопки
                var same = document.querySelectorAll('.track-lib[data-track-id="' + id + '"]');
                for (var i = 0; i < same.length; i++) {
                    same[i].classList.toggle('is-added', data.in);
                    same[i].setAttribute('aria-pressed', data.in ? 'true' : 'false');
                    same[i].setAttribute('title', title);
                    same[i].setAttribute('aria-label', title);
                }

                // Убрали трек прямо из блока «Моя музыка» — строка исчезает
                var mine = document.getElementById('myMusicList');
                if (!data.in && mine && mine.contains(btn)) {
                    var row = btn.closest('.track');
                    if (row) row.parentNode.removeChild(row);
                    var left = mine.querySelectorAll('.track').length;
                    var counter = document.getElementById('myMusicCount');
                    if (counter) counter.textContent = left;
                    if (!left) {
                        mine.hidden = true;
                        var empty = document.getElementById('myMusicEmpty');
                        if (empty) empty.hidden = false;
                    }
                }
            })
            .catch(function () {
                window.alert('Не удалось обновить «Мою музыку». Попробуйте ещё раз.');
            })
            .then(function () { btn.disabled = false; });
    });

    // Иконки рядом с поиском: открывают/закрывают панели «Загрузить музыку» и «Новый альбом» под поиском
    var toggles = document.querySelectorAll('.icon-btn[data-panel], .artist-add-btn[data-panel]');
    for (var i = 0; i < toggles.length; i++) {
        toggles[i].addEventListener('click', function () {
            var panel = document.getElementById(this.getAttribute('data-panel'));
            if (!panel) return;
            var open = panel.hidden;               // сейчас скрыта — значит откроем
            panel.hidden = !open;
            this.setAttribute('aria-expanded', open ? 'true' : 'false');
            this.classList.toggle('is-active', open);
            if (open) {
                var first = panel.querySelector('input:not([type="hidden"]), select, textarea');
                if (first && first.type !== 'file') first.focus();
            }
        });
    }

    // Страница артиста: смена шапки отправляется сразу после выбора картинки
    var bannerInput = document.getElementById('bannerInput');
    if (bannerInput) {
        bannerInput.addEventListener('change', function () {
            var f = bannerInput.files && bannerInput.files[0];
            if (!f) return;
            if (f.size > 8 * 1024 * 1024) {
                window.alert('Шапка не должна быть больше 8 МБ.');
                bannerInput.value = '';
                return;
            }
            bannerInput.form.submit();
        });
    }

    // «Показать все» плавно прокручивает к полному списку треков
    var allLink = document.getElementById('artistAll');
    if (allLink) {
        allLink.addEventListener('click', function (e) {
            var target = document.getElementById('artistTracks');
            if (!target) return;
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    }

    // «Популярное» и кнопка «Слушать»
    var pop = document.getElementById('artistPopular');
    if (pop) {
        var rows = [].slice.call(pop.querySelectorAll('.pop-row'));
        var listenBtn = document.getElementById('artistListen');
        var csrf = pop.getAttribute('data-csrf') || '';
        var audio = new Audio();
        audio.preload = 'none';
        var current = -1;
        var counted = {};
        var STD_KBPS = [64, 96, 112, 128, 160, 192, 224, 256, 320];

        function fmtTime(sec) {
            var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
            return m + ':' + (s < 10 ? '0' : '') + s;
        }

        // Длительность и битрейт берём из самих файлов: в базе их нет
        rows.forEach(function (row) {
            var probe = new Audio();
            probe.preload = 'metadata';
            probe.addEventListener('loadedmetadata', function () {
                var d = probe.duration;
                if (!isFinite(d) || d <= 0) return;
                row.querySelector('.pop-dur').textContent = fmtTime(d);
                var size = parseInt(row.getAttribute('data-size') || '0', 10);
                var kbps = size * 8 / d / 1000;
                if (kbps >= 40) {
                    var best = STD_KBPS[0];
                    STD_KBPS.forEach(function (v) { if (Math.abs(v - kbps) < Math.abs(best - kbps)) best = v; });
                    var badge = row.querySelector('.pop-kbps');
                    badge.textContent = best;
                    badge.hidden = false;
                }
            });
            probe.src = row.getAttribute('data-src');
        });

        function paint(playing) {
            rows.forEach(function (r, k) {
                r.classList.toggle('is-current', k === current);
                r.classList.toggle('is-playing', k === current && playing);
            });
            if (listenBtn) {
                listenBtn.classList.toggle('is-playing', playing);
                listenBtn.querySelector('span').textContent = playing ? 'Пауза' : 'Слушать';
            }
        }

        function pauseOthers() {
            var all = document.querySelectorAll('audio');
            for (var i = 0; i < all.length; i++) {
                if (!all[i].paused) all[i].pause();
            }
        }

        function playIndex(i) {
            var row = rows[i];
            if (!row) return;
            if (current === i) {                       // тот же трек: пауза / продолжить
                if (audio.paused) { pauseOthers(); audio.play().catch(function () {}); } else { audio.pause(); }
                return;
            }
            pauseOthers();
            current = i;
            audio.src = row.getAttribute('data-src');
            audio.play().catch(function () { paint(false); });
        }

        audio.addEventListener('play', function () {
            paint(true);
            var id = rows[current] ? rows[current].getAttribute('data-id') : '';
            if (id && !counted[id]) {                  // одно прослушивание на трек за визит
                counted[id] = true;
                try {
                    fetch('music.php', {
                        method: 'POST',
                        credentials: 'same-origin',
                        keepalive: true,
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'action=track_play&track_id=' + encodeURIComponent(id) + '&csrf_token=' + encodeURIComponent(csrf)
                    });
                } catch (e) {}
            }
        });
        audio.addEventListener('pause', function () { paint(false); });
        audio.addEventListener('ended', function () {
            if (current + 1 < rows.length) { playIndex(current + 1); } else { paint(false); }
        });

        // Другой плеер на странице включился — этот замолкает
        document.addEventListener('play', function (e) {
            if (e.target !== audio && e.target.tagName === 'AUDIO' && !audio.paused) audio.pause();
        }, true);

        rows.forEach(function (row, i) {
            row.addEventListener('click', function () { playIndex(i); });
        });

        if (listenBtn) {
            listenBtn.addEventListener('click', function () { playIndex(current >= 0 ? current : 0); });
        }
    }

    // Страница артиста: смена имени (кнопка есть только у самого артиста)
    var nameBtn = document.getElementById('artistNameBtn');
    var nameForm = document.getElementById('artistNameForm');
    var titleRow = document.getElementById('artistTitleRow');
    if (nameBtn && nameForm && titleRow) {
        var nameInput = nameForm.querySelector('.artist-name-input');
        var closeName = function () {
            nameForm.hidden = true;
            titleRow.hidden = false;
            nameBtn.focus();
        };
        nameBtn.addEventListener('click', function () {
            titleRow.hidden = true;
            nameForm.hidden = false;
            nameInput.focus();
            nameInput.select();
        });
        document.getElementById('artistNameCancel').addEventListener('click', closeName);
        nameInput.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeName();
        });
    }

    // Загрузка MP3: проверка файла в браузере до отправки (сервер всё равно проверяет заново)
    var form = document.getElementById('uploadForm');
    if (!form) return;

    var fileInput = form.querySelector('input[type="file"]');
    var submitBtn = form.querySelector('button[type="submit"]');
    var errorBox  = document.getElementById('uploadError');
    var maxBytes  = parseInt(form.getAttribute('data-max-bytes') || '0', 10);
    var coverInput = form.querySelector('input[name="track_cover"]');

    function showError(text) {
        if (!errorBox) return;
        errorBox.textContent = text;
        errorBox.hidden = !text;
    }

    function validateCover() {
        var cover = coverInput && coverInput.files && coverInput.files[0];
        if (!cover) return '';
        if (!/\.(jpe?g|png|webp)$/i.test(cover.name)) return 'Обложка должна быть JPG, PNG или WEBP.';
        if (cover.size > 8 * 1024 * 1024) return 'Обложка не должна быть больше 8 МБ.';
        return '';
    }

    function validate() {
        var file = fileInput.files && fileInput.files[0];
        if (!file) return 'Выберите MP3-файл.';
        if (!/\.mp3$/i.test(file.name)) return 'Разрешены только MP3-файлы.';
        if (maxBytes && file.size > maxBytes) {
            return 'Максимальный размер файла — ' + Math.round(maxBytes / 1024 / 1024) + ' МБ.';
        }
        return validateCover();
    }

    fileInput.addEventListener('change', function () {
        showError(fileInput.files.length ? validate() : '');
    });

    if (coverInput) {
        coverInput.addEventListener('change', function () {
            showError(validateCover());
        });
    }

    form.addEventListener('submit', function (e) {
        var problem = validate();
        if (problem) {
            e.preventDefault();
            showError(problem);
            return;
        }
        showError('');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Загрузка...';
        }
    });
});

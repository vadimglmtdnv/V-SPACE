(function () {
    var form = document.getElementById('bugForm');
    var btn = document.getElementById('submitBtn');
    var btnText = document.getElementById('submitText');
    var desc = document.getElementById('bugDesc');
    var count = document.getElementById('descCount');

    // Счётчик символов описания
    function updateCount() { if (desc && count) count.textContent = desc.value.length; }
    if (desc) { desc.addEventListener('input', updateCount); updateCount(); }

    // Защита от двойной отправки
    if (!form || !btn) return;

    // Язык берём из <html lang>: при English сервер ставит lang="en".
    // Исходную подпись кнопки запоминаем со страницы (она уже переведена сервером).
    var isEn = (document.documentElement.lang || '').toLowerCase().indexOf('en') === 0;
    var sendingText = isEn ? 'Sending...' : 'Отправка...';
    var idleText = btnText ? btnText.textContent : '';
    form.addEventListener('submit', function (e) {
        if (btn.disabled) { e.preventDefault(); return; }
        btn.disabled = true;
        btnText.textContent = sendingText;
    });

    // Возврат кнопкой «Назад» (bfcache) — кнопка снова должна работать.
    window.addEventListener('pageshow', function () {
        btn.disabled = false;
        btnText.textContent = idleText;
    });
})();

/* ============================================================
   theme-switch.js — переключатель темы «ночь ↔ день» в меню профиля.
   Общий для всех страниц: подключается из includes/site_header.php
   и страниц со своей шапкой (donate, favorite, help, messages, notifications).

   Свет расходится кругом от переключателя, тёмная тема «втягивается» в него.
   Переключатель встаёт в строку «Тема» (.theme-trigger); если её нет — над списком
   тем (.theme-submenu); если нет и его — плавает в углу.
   Стили: assets/css/theme-switch.css

   Синхронизация: тема хранится в профиле пользователя и периодически синхронизируется
   с сервером между устройствами. Cookie/localStorage, BroadcastChannel и событие
   storage обеспечивают мгновенное обновление в текущем браузере.
   Страницы могут слушать событие document 'vspace:themechange' (detail.theme / detail.effective).
   ============================================================ */
(function () {
    'use strict';

    // Страница может подключить скрипт дважды (например, шапка включена в нескольких ветках) — второй запуск не нужен.
    if (window.__themeSwitchInit) return;
    window.__themeSwitchInit = true;

    function init() {

          var root = document.documentElement;
          var body = document.body;

          function effective() {
              var t = body.getAttribute('data-theme');
              if (t === 'system') return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
              return t === 'light' ? 'light' : 'dark';
          }

          var csrfToken = '';
          var localThemeRevision = 0;
          var serverSyncDisabled = false;
          var serverSyncInFlight = false;
          var serverSaveInFlight = false;
          var pendingServerTheme = null;
          var themeSyncApi = new URL('../../api/theme_sync.php', document.currentScript.src).toString();

          /* --- сам переключатель в шапке --- */
          var sw = document.createElement('span');
          sw.className = 'theme-switch';
          sw.setAttribute('role', 'switch');
          sw.tabIndex = 0;
          sw.innerHTML =
              '<span class="ts-layer ts-night"><svg viewBox="0 0 56 30" aria-hidden="true">' +
                '<circle cx="30" cy="9" r="1.1" fill="#fff"/><circle cx="38" cy="19" r=".9" fill="#cfd6ff"/>' +
                '<circle cx="45" cy="8" r="1.3" fill="#fff"/><circle cx="48" cy="21" r=".8" fill="#cfd6ff"/>' +
                '<circle cx="35" cy="24" r=".7" fill="#fff"/>' +
                '<path d="M41 13l.9 1.9 1.9.9-1.9.9-.9 1.9-.9-1.9-1.9-.9 1.9-.9z" fill="#fff" opacity=".9"/>' +
              '</svg></span>' +
              '<span class="ts-layer ts-day"><svg viewBox="0 0 56 30" aria-hidden="true">' +
                '<path d="M9 22.5a4 4 0 0 1 .9-7.9 5.2 5.2 0 0 1 10-.6 3.8 3.8 0 0 1 .6 7.6z" fill="#fff" opacity=".95"/>' +
                '<path d="M14 25.5a3 3 0 0 1 .4-5.9 4 4 0 0 1 7.6.2 2.9 2.9 0 0 1 .3 5.7z" fill="#fff" opacity=".6"/>' +
              '</svg></span>' +
              '<span class="theme-switch-knob">' +
                '<svg class="ts-moon" viewBox="0 0 24 24" aria-hidden="true">' +
                  '<path d="M20.2 14.6A8.4 8.4 0 0 1 9.4 3.8a.6.6 0 0 0-.8-.7A9.4 9.4 0 1 0 20.9 15.4a.6.6 0 0 0-.7-.8z" fill="currentColor"/>' +
                  '<circle cx="14.5" cy="13.5" r="1.1" fill="#fff" opacity=".35"/><circle cx="10.5" cy="17" r=".8" fill="#fff" opacity=".35"/>' +
                '</svg>' +
                '<svg class="ts-sun" viewBox="0 0 24 24" aria-hidden="true">' +
                  '<circle cx="12" cy="12" r="4.6" fill="currentColor"/>' +
                  '<g stroke="currentColor" stroke-width="2" stroke-linecap="round">' +
                    '<path d="M12 2.2v2.6M12 19.2v2.6M2.2 12h2.6M19.2 12h2.6M5.1 5.1l1.8 1.8M17.1 17.1l1.8 1.8M5.1 18.9l1.8-1.8M17.1 6.9l1.8-1.8"/>' +
                  '</g>' +
                '</svg>' +
              '</span>';
          /* кладём в выпадающую панель профиля: в строку «Тема», а если её нет — над списком тем */
          var trigger = document.querySelector('.theme-trigger');
          var submenu = document.querySelector('.theme-submenu');
          if (trigger) { sw.classList.add('in-menu'); trigger.insertBefore(sw, trigger.querySelector('.theme-arrow')); }
          else if (submenu) { sw.classList.add('in-menu', 'in-menu-block'); submenu.parentNode.insertBefore(sw, submenu); }
          else { sw.classList.add('is-floating'); body.appendChild(sw); }

          function syncSwitch() {
              var light = effective() === 'light';
              sw.classList.toggle('is-on', light);
              sw.setAttribute('aria-checked', light ? 'true' : 'false');
              sw.setAttribute('aria-label', light ? 'Светлая тема. Включить тёмную' : 'Тёмная тема. Включить светлую');
          }
          syncSwitch();
          window.__syncThemeSwitch = syncSwitch;

          function apply(t, silent) {
              body.setAttribute('data-theme', t);
              document.cookie = 'theme=' + t + '; path=/; max-age=31536000; samesite=lax';
              try { localStorage.setItem('theme', t); } catch (e) {}
              var cur = document.querySelector('.theme-current');
              var item = document.querySelector('.theme-item[href*="theme=' + t + '"]');
              if (cur && item) cur.textContent = item.textContent.replace('✓', '').trim();
              var check = document.querySelector('.theme-check');
              document.querySelectorAll('.theme-item').forEach(function (it) {
                  var on = (it.getAttribute('href') || '').indexOf('theme=' + t) !== -1;
                  it.classList.toggle('active', on);
                  if (on && check) it.appendChild(check);
              });
              syncSwitch();
              notify(t, silent);
              if (!silent) {
                  localThemeRevision++;
                  saveServerTheme(t);
              }
          }

          /* ===== Синхронизация темы между страницами, вкладками, iframe и «Пространствами» ===== */
          var bc = null;
          try { if (window.BroadcastChannel) bc = new BroadcastChannel('vspace-theme'); } catch (e) {}

          function isTheme(t) { return t === 'dark' || t === 'light' || t === 'system'; }

          function saveServerTheme(t) {
              if (!isTheme(t)) return;
              pendingServerTheme = t;
              if (!csrfToken || serverSyncDisabled || serverSaveInFlight) return;

              var themeToSave = pendingServerTheme;
              pendingServerTheme = null;
              serverSaveInFlight = true;
              var saveFailed = false;
              fetch(themeSyncApi, {
                  method: 'POST',
                  credentials: 'same-origin',
                  cache: 'no-store',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-Token': csrfToken
                  },
                  body: JSON.stringify({ theme: themeToSave })
              }).then(function (response) {
                  if (!response.ok) throw new Error('Не удалось сохранить тему на сервере (HTTP ' + response.status + ').');
                  return response.json();
              }).then(function (data) {
                  if (!data.success) throw new Error(data.error || 'Не удалось сохранить тему на сервере.');
              }).catch(function (error) {
                  console.error('Синхронизация темы:', error);
                  pendingServerTheme = pendingServerTheme || themeToSave;
                  saveFailed = true;
              }).then(function () {
                  serverSaveInFlight = false;
                  if (!saveFailed && pendingServerTheme && !serverSyncDisabled) saveServerTheme(pendingServerTheme);
              });
          }

          function syncServerTheme() {
              if (serverSyncDisabled || serverSyncInFlight || document.hidden) return;
              serverSyncInFlight = true;
              var revisionAtRequest = localThemeRevision;
              fetch(themeSyncApi, {
                  credentials: 'same-origin',
                  cache: 'no-store'
              }).then(function (response) {
                  if (response.status === 401) {
                      serverSyncDisabled = true;
                      return null;
                  }
                  if (!response.ok) throw new Error('Не удалось получить тему с сервера (HTTP ' + response.status + ').');
                  return response.json();
              }).then(function (data) {
                  if (!data) return;
                  if (!data.success) throw new Error(data.error || 'Не удалось получить тему с сервера.');
                  csrfToken = typeof data.csrf_token === 'string' ? data.csrf_token : '';
                  if (pendingServerTheme) {
                      saveServerTheme(pendingServerTheme);
                  } else if (serverSaveInFlight) {
                      return;
                  } else if (localThemeRevision !== revisionAtRequest) {
                      saveServerTheme(body.getAttribute('data-theme'));
                  } else if (isTheme(data.theme)) {
                      applyRemote(data.theme, true);
                  } else {
                      saveServerTheme(body.getAttribute('data-theme'));
                  }
              }).catch(function (error) {
                  console.error('Синхронизация темы:', error);
              }).then(function () {
                  serverSyncInFlight = false;
              });
          }

          function stored() {                       // cookie главнее localStorage (её же читает сервер)
              var m = /(?:^|; )theme=(dark|light|system)/.exec(document.cookie);
              if (m) return m[1];
              try { var t = localStorage.getItem('theme'); if (isTheme(t)) return t; } catch (e) {}
              return null;
          }

          function notify(t, silent) {
              if (!silent && bc) { try { bc.postMessage({ theme: t }); } catch (e) {} }
              try {
                  document.dispatchEvent(new CustomEvent('vspace:themechange', { detail: { theme: t, effective: effective() } }));
              } catch (e) {}
          }

          /* тему сменили в другом месте: применяем у себя, не рассылая её обратно */
          function applyRemote(t, instant) {
              if (!isTheme(t) || body.getAttribute('data-theme') === t) return;
              var fade = !instant && !document.hidden;
              if (fade) root.classList.add('theme-fade');
              apply(t, true);
              if (fade) setTimeout(function () { root.classList.remove('theme-fade'); }, 800);
          }

          function reconcile(instant) {
              var t = stored();
              if (t && body.getAttribute('data-theme') !== t) applyRemote(t, instant === true);
              else syncSwitch();
          }

          if (bc) bc.onmessage = function (e) { if (e && e.data) applyRemote(e.data.theme); };
          window.addEventListener('storage', function (e) { if (e.key === 'theme') applyRemote(e.newValue); });
          window.addEventListener('pageshow', function () { reconcile(true); syncServerTheme(); });
          window.addEventListener('focus', function () { reconcile(); syncServerTheme(); });
          document.addEventListener('visibilitychange', function () {
              if (!document.hidden) {
                  reconcile();
                  syncServerTheme();
              }
          });

          /* «Системная» тема: переключатель следует за настройкой ОС */
          function onOsThemeChange() {
              syncSwitch();
              if (body.getAttribute('data-theme') === 'system') notify('system', true);
          }
          var mq = window.matchMedia('(prefers-color-scheme: light)');
          if (mq.addEventListener) mq.addEventListener('change', onOsThemeChange);
          else if (mq.addListener) mq.addListener(onOsThemeChange);

          window.VSTheme = {
              get: function () { return body.getAttribute('data-theme'); },
              effective: effective
          };

          reconcile(true);                          // страница могла открыться из кэша или с устаревшей темой
          syncServerTheme();
          window.setInterval(syncServerTheme, 5000);

          function setTheme(t, origin) {
              if (effective() === t && body.getAttribute('data-theme') === t) return;
              var el = origin || sw;
              var r = el.getBoundingClientRect();
              var x = r.left + r.width / 2, y = r.top + r.height / 2;
              var radius = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
              var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

              if (!document.startViewTransition || reduce) {      // запасной вариант: простое затухание
                  root.classList.add('theme-fade');
                  apply(t);
                  setTimeout(function () { root.classList.remove('theme-fade'); }, 800);
                  return;
              }

              var toLight = t === 'light';
              root.classList.add('theme-vt', toLight ? 'vt-spread' : 'vt-shrink');
              var vt = document.startViewTransition(function () { apply(t); });
              vt.ready.then(function () {
                  var from = 'circle(0px at ' + x + 'px ' + y + 'px)';
                  var full = 'circle(' + radius + 'px at ' + x + 'px ' + y + 'px)';
                  root.animate(
                      { clipPath: toLight ? [from, full] : [full, from] },
                      {
                          duration: 750,
                          easing: 'cubic-bezier(.4, 0, .2, 1)',
                          fill: 'both',
                          pseudoElement: toLight ? '::view-transition-new(root)' : '::view-transition-old(root)'
                      }
                  );
              }).catch(function () {});
              vt.finished.finally(function () { root.classList.remove('theme-vt', 'vt-spread', 'vt-shrink'); });
          }

          function toggle(e) {
              e.preventDefault();
              e.stopPropagation();          // не сворачиваем и не разворачиваем меню тем
              setTheme(effective() === 'light' ? 'dark' : 'light', sw);
          }
          sw.addEventListener('click', toggle);
          if (trigger) trigger.addEventListener('click', toggle, true);
          sw.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') toggle(e); });

          /* пункты «Тёмная / Светлая» в меню профиля работают так же («Системная» — как раньше) */
          document.addEventListener('click', function (e) {
              var a = e.target.closest('a[href*="theme="]');
              if (!a) return;
              var m = /[?&]theme=(dark|light|system)(?:&|$)/.exec(a.getAttribute('href') || '');
              if (!m) return;
              e.preventDefault();
              e.stopPropagation();
              setTheme(m[1], sw);
          }, true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

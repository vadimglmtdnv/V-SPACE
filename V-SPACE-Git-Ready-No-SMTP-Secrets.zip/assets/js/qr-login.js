(function () {
    'use strict';

    const toggle = document.getElementById('qrLoginToggle');
    const panel = document.getElementById('qrLoginPanel');
    const image = document.getElementById('qrLoginImage');
    const status = document.getElementById('qrLoginStatus');
    const close = document.getElementById('qrLoginClose');
    if (!toggle || !panel || !image || !status || !close) return;

    let pollTimer = null;
    let expiryTimer = null;
    let active = false;
    let pollInFlight = false;

    function stopPolling() {
        active = false;
        if (pollTimer !== null) window.clearInterval(pollTimer);
        if (expiryTimer !== null) window.clearTimeout(expiryTimer);
        pollTimer = null;
        expiryTimer = null;
    }

    async function poll(token) {
        if (!active || pollInFlight) return;
        pollInFlight = true;
        try {
            const response = await fetch('qr_login.php?action=poll', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
                body: new URLSearchParams({ token: token })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Не удалось проверить подтверждение.');
            if (data.status === 'logged_in') {
                stopPolling();
                window.location.assign('index.php');
                return;
            }
            if (data.status === 'approved') {
                status.textContent = 'Подтверждено. Выполняем вход…';
            } else if (data.status === 'expired' || data.status === 'rejected' || data.status === 'consumed') {
                stopPolling();
                status.textContent = 'QR-код истёк или уже использован. Нажмите кнопку входа по QR-коду ещё раз.';
            }
        } catch (error) {
            if (active) {
                stopPolling();
                status.textContent = error.message || 'Не удалось проверить подтверждение. Попробуйте ещё раз.';
            }
        } finally {
            pollInFlight = false;
        }
    }

    async function createQr() {
        stopPolling();
        image.replaceChildren();
        status.textContent = 'Подготавливаем QR-код…';
        try {
            const response = await fetch('qr_login.php?action=start', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
                body: ''
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Не удалось создать QR-код.');
            if (typeof window.qrcode !== 'function') throw new Error('Не загрузился модуль QR-кода.');

            const approveUrl = new URL('qr_login.php', window.location.href);
            approveUrl.searchParams.set('approve', data.token);
            const qr = window.qrcode(0, 'M');
            qr.addData(approveUrl.toString());
            qr.make();
            image.innerHTML = qr.createSvgTag(6, 8);
            status.textContent = 'Ожидаем подтверждение в приложении. Код действует 2 минуты.';
            active = true;
            pollTimer = window.setInterval(function () { poll(data.token); }, 2000);
            expiryTimer = window.setTimeout(function () {
                if (active) {
                    stopPolling();
                    status.textContent = 'Срок действия QR-кода истёк. Нажмите кнопку входа по QR-коду ещё раз.';
                }
            }, Number(data.expires_in) * 1000);
        } catch (error) {
            stopPolling();
            status.textContent = error.message || 'Не удалось создать QR-код.';
        }
    }

    toggle.addEventListener('click', function () {
        const open = panel.hidden;
        panel.hidden = !open;
        toggle.setAttribute('aria-expanded', String(open));
        if (open) createQr();
        else stopPolling();
    });
    close.addEventListener('click', function () {
        stopPolling();
        panel.hidden = true;
        toggle.setAttribute('aria-expanded', 'false');
    });
    window.addEventListener('pagehide', stopPolling);
}());

// ============================================================
// messages.js — под разметку messages.php
// Кнопки: #voiceBtn (микрофон), #sendBtn (отправка текста)
// Поля:   #messageInput, #voiceFileInput, #voiceDuration,
//         #photoInput, #videoInput, форма #chatForm
//
// ВАЖНО: пикер эмодзи реализован в emoji.js.
// Здесь его НЕТ, чтобы не дублировать обработчик кнопки #emojiBtn.
// ============================================================

// ============================================================
// ПЛАВНАЯ СМЕНА ТЕМЫ
// change() должна синхронно поменять data-theme на body.
// Где есть View Transitions API (Chrome, Edge, Safari 18+), вся страница плавно перетекает
// из старого вида в новый. В остальных браузерах включается плавная смена цветов через CSS.
// ============================================================
window.runThemeTransition = function (change) {
    const root = document.documentElement;
    const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) {
        change();
        return;
    }
    if (typeof document.startViewTransition === 'function') {
        try {
            document.startViewTransition(change);
            return;
        } catch (error) {}
    }
    root.classList.add('theme-fade');
    change();
    window.setTimeout(function () { root.classList.remove('theme-fade'); }, 1000);
};

// CSRF-токен на теге <body> (data-csrf-token) — доступен всегда, даже когда на странице
// нет открытого диалога (а значит и формы #chatForm с собственным полем csrf_token).
function getCsrfToken() {
    return (document.body && document.body.dataset.csrfToken) || '';
}

document.addEventListener('DOMContentLoaded', function () {
    restoreSelectedDialog();
    formatMessageTimes();
    updateLastSeen();
    fixVoiceMessages();
    setupVoicePlayback();
    setupActionButtons();
    setupRecording();
    setupFormGuard();
    setupAvatarDropdown();
    setupNotifications();
    // setupEmojiPicker();   ← удалено, эмодзи живут в emoji.js
    scrollChatToBottom();
    setupDialogRead();
    setupAjaxNavigation();
    setupAttachmentSubmit();
    setupBottomNav();
    setupSearchModalClose();
    setupResizer();
    setupMessageActions();
    setupMessageDraft();
    setupDialogDraftPreviews();
    setupPhotoViewer();
    parseCustomEmoji();
    restoreChatScroll();
});

function restoreSelectedDialog() {
    const body = document.body;
    if (!body) return;
    // Мини-окно на другой странице (iframe): список диалогов должен оставаться списком,
    // а не перекидывать на последний открытый диалог
    if (document.documentElement.classList.contains('is-embedded')) return;

    // Телефон: список и чат — отдельные экраны. Если на нажатие «‹» (назад к списку) снова
    // открывать последний диалог, список мелькает и тут же откидывает обратно в чат.
    // Поэтому на узком экране последний диалог сам не открываем (запоминать его по-прежнему можно).
    const isPhone = window.matchMedia && window.matchMedia('(max-width: 699px), (hover: none) and (pointer: coarse)').matches;

    const currentDialogId = Number.parseInt(body.dataset.dialogId || '0', 10);
    const storedKey = 'messages-selected-dialog:' + (body.dataset.userId || '0');
    let storedDialogId = 0;

    try {
        storedDialogId = Number.parseInt(localStorage.getItem(storedKey) || '0', 10);
    } catch (error) {}

    if (currentDialogId > 0) {
        try {
            localStorage.setItem(storedKey, String(currentDialogId));
        } catch (error) {}
        return;
    }

    if (storedDialogId > 0 && !isPhone) {
        const url = new URL(window.location.href);
        url.searchParams.set('dialog', String(storedDialogId));
        window.location.replace(url.toString());
    }
}

// Кастомные эмодзи: превращает :код: в <img> в сообщениях и превью диалогов.
// Безопасно вызывать повторно — уже заменённые узлы больше не содержат ':код:'.
// Сбой в custom-emoji.js не должен ломать страницу (раньше из-за него отправка падала и сообщение уходило повторно).
function safeEmojiParse(node) {
    try {
        if (window.CustomEmoji && node) window.CustomEmoji.parse(node);
    } catch (error) {
        console.error('Не удалось показать кастомные эмодзи:', error);
    }
}

function parseCustomEmoji() {
    if (!window.CustomEmoji) return;
    ['#chatMessages', '.dialogs-sidebar'].forEach(function (selector) {
        safeEmojiParse(document.querySelector(selector));
    });
}

// ============================================================
// «Был(а) в сети …» — считается в локальном времени браузера (сервер хранит UTC).
//  < 1 мин → «только что»; < 60 мин → «5 минут назад»; < 6 ч → «час назад», «3 часа назад»;
//  дальше → «сегодня в 13:20», «вчера в 13:20», «12 октября в 13:20» (с годом, если он другой).
// ============================================================
var LAST_SEEN_RELATIVE_HOURS = 6;

function lastSeenPlural(n, one, few, many) {
    n = Math.abs(n) % 100;
    var n1 = n % 10;
    if (n > 10 && n < 20) return many;
    if (n1 > 1 && n1 < 5) return few;
    if (n1 === 1) return one;
    return many;
}

function formatLastSeen(ts) {
    ts = Number(ts);
    if (!ts) return 'Был(а) в сети недавно';
    var then = new Date(ts * 1000);
    var now  = new Date();
    var diff = Math.max(0, Math.floor((now.getTime() - then.getTime()) / 1000));

    if (diff < 60) return 'Был(а) в сети только что';
    if (diff < 3600) {
        var m = Math.floor(diff / 60);
        return 'Был(а) в сети ' + m + ' ' + lastSeenPlural(m, 'минуту', 'минуты', 'минут') + ' назад';
    }
    if (diff < LAST_SEEN_RELATIVE_HOURS * 3600) {
        var h = Math.floor(diff / 3600);
        return 'Был(а) в сети ' + (h === 1 ? 'час' : h + ' ' + lastSeenPlural(h, 'час', 'часа', 'часов')) + ' назад';
    }

    function pad(x) { return String(x).padStart(2, '0'); }
    var time = pad(then.getHours()) + ':' + pad(then.getMinutes());
    var startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    var thenTs = then.getTime();
    if (thenTs >= startToday) return 'Был(а) в сети сегодня в ' + time;
    if (thenTs >= startToday - 86400000) return 'Был(а) в сети вчера в ' + time;

    var months = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
    var date = then.getDate() + ' ' + months[then.getMonth()];
    if (then.getFullYear() !== now.getFullYear()) date += ' ' + then.getFullYear();
    return 'Был(а) в сети ' + date + ' в ' + time;
}
window.formatLastSeen = formatLastSeen;

function updateLastSeen() {
    document.querySelectorAll('.last-seen-text[data-last-seen]').forEach(function (el) {
        var ts = parseInt(el.getAttribute('data-last-seen') || '0', 10);
        if (!ts) return;
        var text = formatLastSeen(ts);
        if (el.textContent !== text) el.textContent = text;
    });
}
setInterval(updateLastSeen, 30000);   // «5 минут назад» → «6 минут назад», «час назад» → «2 часа назад» без перезагрузки

function formatMessageTimes() {
    const formatter = new Intl.DateTimeFormat(undefined, {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    });

    document.querySelectorAll('.msg-time[data-timestamp]').forEach(function (element) {
        const timestamp = Number.parseInt(element.dataset.timestamp || '0', 10);
        if (timestamp > 0) {
            element.textContent = formatter.format(new Date(timestamp * 1000));
        }
    });
}

function setupAjaxNavigation() {
    document.addEventListener('click', function (event) {
        const link = event.target.closest('.dialog-link, a[href*="toggle_favorite"]');
        if (!link || event.defaultPrevented || event.button !== 0 ||
            event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) {
            return;
        }

        event.preventDefault();
        const dialogId = link.closest('.dialog-item')?.dataset.dialogId ||
            new URL(link.href, window.location.href).searchParams.get('dialog') ||
            '';
        if (dialogId) {
            try {
                localStorage.setItem(
                    'messages-selected-dialog:' + (document.body.dataset.userId || '0'),
                    String(dialogId)
                );
            } catch (error) {}
        }
        loadMessagesPage(link.href, true);
    });
    window.addEventListener('popstate', function () {
        loadMessagesPage(window.location.href, false);
    });
}

// Подменяет область чата и список диалогов на полученный HTML (без перезагрузки страницы)
function applyMessagesHtml(html, url, updateHistory) {
    const currentChat = document.querySelector('.chat-area');
    const currentSidebar = document.querySelector('.dialogs-sidebar');
    const parsed = new DOMParser().parseFromString(html, 'text/html');
    const nextChat = parsed.querySelector('.chat-area');
    const nextSidebar = parsed.querySelector('.dialogs-sidebar');
    if (!currentChat || !nextChat) throw new Error('В ответе отсутствует область чата');

    currentChat.replaceWith(nextChat);
    if (currentSidebar && nextSidebar) currentSidebar.replaceWith(nextSidebar);
    if (updateHistory) window.history.pushState({}, '', url);

    const nextDialogId = new URL(url, window.location.href).searchParams.get('dialog') || '0';
    document.body.dataset.dialogId = nextDialogId;
    if (nextDialogId !== '0') {
        try {
            localStorage.setItem(
                'messages-selected-dialog:' + (document.body.dataset.userId || '0'),
                nextDialogId
            );
        } catch (error) {}
    }

    setupVoicePlayback();
    setupActionButtons();
    setupRecording();
    setupFormGuard();
    setupAttachmentSubmit();
    setupDialogRead();
    setupMessageActions();
    setupMessageDraft();
    setupDialogDraftPreviews();
    formatMessageTimes();
    updateLastSeen();
    parseCustomEmoji();
    if (typeof window.setupMentionInputs === 'function') {
        window.setupMentionInputs();
    }
    if (typeof window.setupEmojiPicker === 'function') {
        window.setupEmojiPicker();
    }
    restoreChatScroll();
    scrollChatToBottom();
    if (typeof window.captchaOpenIfNeeded === 'function') window.captchaOpenIfNeeded();
}

async function loadMessagesPage(url, updateHistory) {
    const currentChat = document.querySelector('.chat-area');
    if (!currentChat) {
        window.location.assign(url);
        return;
    }

    currentChat.classList.add('is-loading');
    try {
        const response = await fetch(url, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            credentials: 'same-origin'
        });
        if (!response.ok) throw new Error('Не удалось загрузить диалог');

        applyMessagesHtml(await response.text(), url, updateHistory);
    } catch (error) {
        console.error('Ошибка AJAX-навигации:', error);
        window.location.assign(url);
    } finally {
        const chat = document.querySelector('.chat-area');
        if (chat) chat.classList.remove('is-loading');
    }
}

// ============================================================
// 0. АВТОСКРОЛЛ ЧАТА ВНИЗ
// ============================================================
function scrollChatToBottom() {
    const chat = document.getElementById('chatMessages');
    const body = document.body;
    if (!chat || !body) return;

    const key = 'messages-scroll:' + (body.dataset.userId || '0') + ':' + (body.dataset.dialogId || '0');
    let saved = 0;
    try {
        saved = Number.parseInt(localStorage.getItem(key) || '', 10);
    } catch (error) {}

    if (!Number.isFinite(saved) || saved <= 0) {
        chat.scrollTop = chat.scrollHeight;
    }
}

// ============================================================
// 1. ФИКС ВРЕМЕНИ ДЛЯ УЖЕ ЗАГРУЖЕННЫХ ГОЛОСОВЫХ
// ============================================================
function fixVoiceMessages() {
    document.querySelectorAll('.voice-message').forEach(function (voiceMsg) {
        if (voiceMsg.dataset.fixInit === '1') return;
        voiceMsg.dataset.fixInit = '1';
        const audio      = voiceMsg.querySelector('.voice-audio');
        const durationEl = voiceMsg.querySelector('.duration');
        const currentEl  = voiceMsg.querySelector('.current-time');

        if (!audio || !durationEl) return;

        function fmt(sec) {
            if (!isFinite(sec) || sec < 0 || sec > 86400) sec = 0;
            const m = String(Math.floor(sec / 60)).padStart(2, '0');
            const s = String(Math.floor(sec % 60)).padStart(2, '0');
            return m + ':' + s;
        }

        function updateDuration() {
            if (audio.duration && isFinite(audio.duration) && audio.duration > 0) {
                durationEl.textContent = fmt(audio.duration);
            }
        }

        audio.addEventListener('loadedmetadata', updateDuration);
        audio.addEventListener('durationchange', updateDuration);
        audio.addEventListener('error', function () {
            durationEl.textContent = durationEl.textContent || '0:00';
        });

        if (audio.readyState >= 1) updateDuration();
        else audio.load();

        if (currentEl) {
            audio.addEventListener('timeupdate', function () {
                // Дослушанное показывает 0:00 и сразу после окончания, и после F5
                const total = audio.duration;
                const atEnd = audio.ended || (Number.isFinite(total) && total > 0 && audio.currentTime >= total - 0.05);
                currentEl.textContent = atEnd ? '0:00' : fmt(audio.currentTime);
            });
            audio.addEventListener('ended', function () {
                currentEl.textContent = '0:00';
                const btn = voiceMsg.querySelector('.voice-play');
                if (btn) btn.classList.remove('playing');
            });
        }
    });
}

// ============================================================
// 2. ВОСПРОИЗВЕДЕНИЕ (пауза других при старте одного)
// ============================================================
function setupVoicePlayback() {
    document.querySelectorAll('.voice-message').forEach(function (voiceMsg) {
        if (voiceMsg.dataset.playInit === '1') return;
        voiceMsg.dataset.playInit = '1';
        const audio = voiceMsg.querySelector('.voice-audio');
        const btn   = voiceMsg.querySelector('.voice-play');
        const waveform = voiceMsg.querySelector('.waveform');
        if (!audio || !btn) return;
        const body = document.body;
        const voiceId = voiceMsg.dataset.voiceId || '';
        const positionKey = 'voice-position:v1:' + (body?.dataset.userId || '0') + ':' +
            (body?.dataset.dialogId || '0') + ':' + voiceId;

        // Запись через MediaRecorder (webm) не содержит длительности: audio.duration = Infinity,
        // и перемотка не работает. Поэтому длительность берём из файла, а если её нет,
        // из data-duration, которую PHP берёт из базы.
        let fixingDuration = false;
        let blobPromise = null;      // запасной режим: файл целиком в памяти
        let swappingToBlob = false;
        let lastSeekTarget = 0;
        let verifyTimer = null;

        function knownDuration() {
            if (audio.duration && isFinite(audio.duration) && audio.duration > 0) return audio.duration;
            const stored = Number.parseFloat(voiceMsg.dataset.duration || '');
            return Number.isFinite(stored) && stored > 0 ? stored : 0;
        }

        // Заставляем браузер вычислить настоящую длительность: перемотка в «бесконечность» и обратно
        function fixInfiniteDuration() {
            if (audio.duration !== Infinity || fixingDuration) return;
            fixingDuration = true;

            const finish = function () {
                audio.removeEventListener('timeupdate', finish);
                window.clearTimeout(guard);
                try { audio.currentTime = 0; } catch (error) {}
                fixingDuration = false;
                restorePosition();
                updateSlider();
            };
            const guard = window.setTimeout(finish, 3000);
            audio.addEventListener('timeupdate', finish);
            try {
                audio.currentTime = 1e101;
            } catch (error) {
                finish();
            }
        }

        // Если сервер не поддерживает HTTP Range (например, php -S), браузер не умеет перематывать
        // и сбрасывает позицию в 0. Тогда один раз загружаем файл целиком и играем из памяти (blob:).
        function whenStable(resolve, waited) {
            if (!fixingDuration || waited > 3000) { resolve(); return; }
            window.setTimeout(function () { whenStable(resolve, waited + 50); }, 50);
        }

        function switchToBlob() {
            if (blobPromise) return blobPromise;
            const src = btn.dataset.src || audio.currentSrc;
            if (!src || !window.fetch || !window.URL) return Promise.resolve(false);
            blobPromise = fetch(src, { credentials: 'same-origin' })
                .then(function (response) {
                    if (!response.ok) throw new Error('HTTP ' + response.status);
                    return response.blob();
                })
                .then(function (blob) {
                    const wasPlaying = !audio.paused;
                    swappingToBlob = true;
                    return new Promise(function (resolve) {
                        const ready = function () {
                            audio.removeEventListener('loadedmetadata', ready);
                            whenStable(function () {
                                swappingToBlob = false;
                                resolve(wasPlaying);
                            }, 0);
                        };
                        audio.addEventListener('loadedmetadata', ready);
                        audio.src = URL.createObjectURL(blob);
                        audio.load();
                    });
                })
                .catch(function (error) {
                    console.error('Не удалось загрузить голосовое для перемотки:', error);
                    swappingToBlob = false;
                    return false;
                });
            return blobPromise;
        }

        function verifySeek() {
            window.clearTimeout(verifyTimer);
            const target = lastSeekTarget;
            verifyTimer = window.setTimeout(function () {
                if (audio.seeking) return;
                const expected = target + (audio.paused ? 0 : 0.4);
                if (Math.abs(audio.currentTime - expected) <= 0.5) return;   // перемотка сработала
                switchToBlob().then(function (wasPlaying) {
                    try { audio.currentTime = target; } catch (error) { return; }
                    if (wasPlaying) audio.play().catch(function () {});
                    updateSlider();
                });
            }, 400);
        }

        function formatClock(seconds) {
            const total = Number.isFinite(seconds) && seconds > 0 ? Math.floor(seconds) : 0;
            return String(Math.floor(total / 60)).padStart(2, '0') + ':' + String(total % 60).padStart(2, '0');
        }

        // Позиция запоминается для КАЖДОГО голосового (и моего, и собеседника) отдельно: ключ содержит id сообщения.
        // Число = секунды, 'end' = дослушано до конца (в таком виде оно и остаётся после F5).
        function savePosition() {
            // Пока метаданные не загрузились, currentTime = 0: не затираем сохранённое
            if (fixingDuration || swappingToBlob || !voiceId || audio.readyState < 1) return;
            const time = audio.currentTime;
            if (!Number.isFinite(time)) return;
            const duration = knownDuration();
            try {
                if (audio.ended || (duration > 0 && time >= duration - 0.05)) {
                    localStorage.setItem(positionKey, 'end');
                } else if (time <= 0) {
                    localStorage.removeItem(positionKey);
                } else {
                    localStorage.setItem(positionKey, String(time));
                }
            } catch (error) {}
        }

        function restorePosition() {
            const duration = knownDuration();
            if (swappingToBlob || !voiceId || !duration || audio.duration === Infinity) return;
            try {
                const raw = localStorage.getItem(positionKey) || '';
                const realDuration = Number.isFinite(audio.duration) ? audio.duration : 0;

                if (raw === 'end') {
                    if (realDuration > 0) audio.currentTime = realDuration;   // все столбики закрашены, как после прослушивания
                    return;
                }

                const saved = Number.parseFloat(raw);
                if (!Number.isFinite(saved) || saved <= 0) return;
                if (saved >= duration - 0.05 && realDuration > 0) {
                    audio.currentTime = realDuration;
                    return;
                }
                audio.currentTime = saved;
                const currentEl = voiceMsg.querySelector('.current-time');
                if (currentEl) currentEl.textContent = formatClock(saved);
            } catch (error) {}
        }

        function updateProgress() {
            const bars = voiceMsg.querySelectorAll('.wave-bar');
            const duration = knownDuration();
            const progress = duration > 0 ? Math.min(1, audio.currentTime / duration) : 0;
            const activeBars = Math.ceil(progress * bars.length);
            bars.forEach(function (bar, index) {
                bar.classList.toggle('played', index < activeBars);
            });
            return progress;
        }

        function updateSlider() {
            if (fixingDuration) return;
            const progress = updateProgress();
            const duration = knownDuration();
            if (waveform && duration) {
                waveform.style.setProperty('--voice-progress', String(progress));
                waveform.setAttribute('aria-valuemin', '0');
                waveform.setAttribute('aria-valuemax', String(Math.round(duration)));
                waveform.setAttribute('aria-valuenow', String(Math.round(audio.currentTime)));
            }
        }

        btn.addEventListener('click', function () {
            if (audio.paused) {
                // Дослушанное (в том числе после F5) проигрывается заново с начала
                const totalTime = knownDuration();
                if (audio.ended || (totalTime > 0 && audio.currentTime >= totalTime - 0.05)) {
                    try { audio.currentTime = 0; } catch (error) {}
                }
                document.querySelectorAll('.voice-audio').forEach(function (other) {
                    if (other !== audio && !other.paused) {
                        other.pause();
                        const ob = other.closest('.voice-message')?.querySelector('.voice-play');
                        if (ob) ob.classList.remove('playing');
                    }
                });
                audio.play().catch(function (err) {
                    console.error('Ошибка воспроизведения:', err);
                });
                btn.classList.add('playing');
            } else {
                audio.pause();
                btn.classList.remove('playing');
            }
        });

        if (waveform) {
            waveform.setAttribute('role', 'slider');
            waveform.setAttribute('tabindex', '0');
            waveform.setAttribute('aria-label', 'Перемотка голосового сообщения');

            function seekTo(seconds) {
                const duration = knownDuration();
                if (!duration) return;
                const target = Math.max(0, Math.min(duration, seconds));
                lastSeekTarget = target;
                try { audio.currentTime = target; } catch (error) { return; }
                const currentEl = voiceMsg.querySelector('.current-time');
                if (currentEl) currentEl.textContent = formatClock(target);
                const ratio = target / duration;
                updateProgress();
                waveform.style.setProperty('--voice-progress', String(ratio));
                waveform.setAttribute('aria-valuenow', String(Math.round(target)));
            }

            function seekFromClientX(clientX) {
                const duration = knownDuration();
                if (!duration) return;
                const rect = waveform.getBoundingClientRect();
                if (!rect.width) return;
                const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
                seekTo(ratio * duration);
            }

            waveform.addEventListener('pointerdown', function (event) {
                if (!knownDuration()) return;
                event.preventDefault();
                event.stopPropagation();
                waveform.setPointerCapture(event.pointerId);
                waveform.classList.add('is-seeking');
                seekFromClientX(event.clientX);
            });

            waveform.addEventListener('pointermove', function (event) {
                if (waveform.classList.contains('is-seeking')) {
                    seekFromClientX(event.clientX);
                }
            });

            waveform.addEventListener('pointerup', function (event) {
                if (waveform.classList.contains('is-seeking')) {
                    seekFromClientX(event.clientX);
                    waveform.classList.remove('is-seeking');
                    if (waveform.hasPointerCapture(event.pointerId)) {
                        waveform.releasePointerCapture(event.pointerId);
                    }
                    verifySeek();
                    savePosition();
                }
            });

            waveform.addEventListener('pointercancel', function () {
                waveform.classList.remove('is-seeking');
            });

            waveform.addEventListener('keydown', function (event) {
                const duration = knownDuration();
                if (!duration) return;
                const step = event.shiftKey ? 10 : 5;
                if (event.key === 'ArrowLeft') {
                    event.preventDefault();
                    seekTo(audio.currentTime - step);
                } else if (event.key === 'ArrowRight') {
                    event.preventDefault();
                    seekTo(audio.currentTime + step);
                } else if (event.key === 'Home') {
                    event.preventDefault();
                    seekTo(0);
                } else if (event.key === 'End') {
                    event.preventDefault();
                    seekTo(duration);
                } else {
                    return;
                }
                verifySeek();
            });
        }

        audio.addEventListener('timeupdate', function () {
            // Пока палец/мышь на ползунке, позицию задаёт пользователь, а не плеер
            if (waveform && waveform.classList.contains('is-seeking')) return;
            updateSlider();
        });
        audio.addEventListener('timeupdate', savePosition);
        audio.addEventListener('loadedmetadata', onMetadata);
        audio.addEventListener('durationchange', function () {
            if (audio.duration !== Infinity) updateSlider();
        });
        audio.addEventListener('pause', savePosition);
        audio.addEventListener('pause', function () {
            if (!audio.ended) btn.classList.remove('playing');
        });
        audio.addEventListener('play', function () {
            btn.classList.add('playing');
        });
        audio.addEventListener('ended', function () {
            if (fixingDuration) return;
            updateProgress();
            btn.classList.remove('playing');
            savePosition();
        });
        window.addEventListener('pagehide', savePosition);

        function onMetadata() {
            fixInfiniteDuration();
            restorePosition();
            updateSlider();
        }
        // Метаданные могли загрузиться до подключения обработчиков
        if (audio.readyState >= 1) onMetadata();
        updateSlider();
    });
}

// ============================================================
// 3. ПЕРЕКЛЮЧЕНИЕ КНОПОК voiceBtn / sendBtn
// ============================================================
function setupActionButtons() {
    const input    = document.getElementById('messageInput');
    const voiceBtn = document.getElementById('voiceBtn');
    const sendBtn  = document.getElementById('sendBtn');
    if (!input || !voiceBtn || !sendBtn) return;

    function toggle() {
        const hasText = input.value.trim().length > 0;
        if (hasText) {
            voiceBtn.style.display = 'none';
            sendBtn.style.display  = '';
        } else {
            voiceBtn.style.display = '';
            sendBtn.style.display  = 'none';
        }
    }

    input.addEventListener('input', toggle);
    sendBtn.addEventListener('click', function (event) {
        if (isRecording) {
            event.preventDefault();
            stopRecording();
        }
    });
    toggle();
}

// ============================================================
// 4. ЗАЩИТА ОТ ПУСТОЙ ОТПРАВКИ
// ============================================================
function setupFormGuard() {
    const form = document.getElementById('chatForm');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        if (typeof isRecording !== 'undefined' && isRecording) {
            e.preventDefault();
            return false;
        }

        function setupMessageDraft() {
            const input = document.getElementById('messageInput');
            const replyInput = document.getElementById('replyToId');
            const replyCompose = document.getElementById('replyCompose');
            const replyText = document.getElementById('replyComposeText');
            const body = document.body;
            if (!input || !replyInput || !replyCompose || !body) return;

            const userId = body.dataset.userId || '0';
            const dialogId = body.dataset.dialogId || '0';
            const storageKey = 'messages-draft:v2:' + userId + ':' + dialogId;

            function readDraft() {
                try {
                    const value = localStorage.getItem(storageKey);
                    return value ? JSON.parse(value) : null;
                } catch (error) {
                    return null;
                }

                function setupDialogDraftPreviews() {
                    const body = document.body;
                    if (!body) return;
                    const userId = body.dataset.userId || '0';

                    document.querySelectorAll('.dialog-item[data-dialog-id]').forEach(function (dialog) {
                        const dialogId = dialog.dataset.dialogId || '0';
                        const preview = dialog.querySelector('[data-dialog-preview]');
                        if (!preview || dialogId === '0') return;

                        let draft = null;
                        try {
                            draft = JSON.parse(localStorage.getItem('messages-draft:v2:' + userId + ':' + dialogId) || 'null');
                        } catch (error) {
                            draft = null;
                        }
                        if (!draft || (!String(draft.text || '').trim() && String(draft.replyId || '0') === '0')) return;

                        const text = String(draft.text || '').trim();
                        const replyText = String(draft.replyText || '').trim();
                        const draftContent = text || (replyText ? 'Ответ на сообщение ' + replyText : 'Ответ на сообщение');
                        preview.textContent = draftContent.slice(0, 120);
                        preview.classList.add('is-draft');

                        const label = document.createElement('span');
                        label.className = 'dialog-draft-label';
                        label.textContent = 'Черновик';
                        preview.insertBefore(label, preview.firstChild);
                        safeEmojiParse(preview);
                    });
                }
            }

            function saveDraft() {
                const text = input.value;
                const replyId = replyInput.value || '0';
                if (!text.trim() && replyId === '0') {
                    localStorage.removeItem(storageKey);
                    return;
                }
                try {
                    localStorage.setItem(storageKey, JSON.stringify({
                        text: text,
                        replyId: replyId,
                        replyText: replyText ? replyText.textContent : ''
                    }));
                } catch (error) {
                    // Draft persistence is optional when browser storage is unavailable.
                }
            }

            function clearDraft() {
                try {
                    localStorage.removeItem(storageKey);
                } catch (error) {}
            }

            const draft = readDraft();
            if (draft) {
                input.value = typeof draft.text === 'string' ? draft.text : '';
                if (draft.replyId && draft.replyId !== '0') {
                    replyInput.value = String(draft.replyId);
                    if (replyText) replyText.textContent = String(draft.replyText || 'Сообщение').slice(0, 120);
                    replyCompose.hidden = false;
                }
                input.dispatchEvent(new Event('input', { bubbles: true }));
            }

            input.addEventListener('input', saveDraft);
            replyInput.addEventListener('change', saveDraft);

            const form = document.getElementById('chatForm');
            if (form) {
                form.addEventListener('submit', clearDraft);
            }

            const cancelReply = document.getElementById('cancelReplyBtn');
            if (cancelReply) {
                cancelReply.addEventListener('click', function () {
                    window.setTimeout(saveDraft, 0);
                });
            }

            window.addEventListener('beforeunload', saveDraft);
        }

        const input    = document.getElementById('messageInput');
        const hasText  = input && input.value.trim().length > 0;
        const hasPhoto = (document.getElementById('photoInput')?.files.length || 0) > 0;
        const hasVideo = (document.getElementById('videoInput')?.files.length || 0) > 0;
        const hasVoice = (document.getElementById('voiceFileInput')?.files.length || 0) > 0;

        if (hasVoice) {
            const waveformInput = document.getElementById('voiceWaveform');
            if (waveformInput && !isValidWaveformValue(waveformInput.value)) {
                waveformInput.value = JSON.stringify(new Array(32).fill(25));
            }
        }

        if (!hasText && !hasPhoto && !hasVideo && !hasVoice) {
            e.preventDefault();
            return false;
        }
    });
}

function isValidWaveformValue(value) {
    try {
        const points = JSON.parse(value || '');
        return Array.isArray(points)
            && points.length >= 8
            && points.every(function (point) {
                return Number.isFinite(Number(point));
            });
    } catch (error) {
        return false;
    }
}

function setupMessageDraft() {
        const input = document.getElementById('messageInput');
        const replyInput = document.getElementById('replyToId');
        const replyCompose = document.getElementById('replyCompose');
        const replyText = document.getElementById('replyComposeText');
        if (!input || !replyInput || !replyCompose) return;

        const body = document.body;
        const key = 'messages-draft:v2:' + (body.dataset.userId || '0') + ':' + (body.dataset.dialogId || '0');
        const pendingKey = key + ':send-pending';
        let messageWasSent = false;

        try {
            if (sessionStorage.getItem(pendingKey) === '1') {
                // если сервер вернул ошибку капчи, сообщение не ушло — черновик не стираем
                if (!/[?&]error=captcha/.test(window.location.search)) {
                    localStorage.removeItem(key);
                }
                sessionStorage.removeItem(pendingKey);
            }
        } catch (error) {}

        function save() {
            if (messageWasSent) return;
            const text = input.value;
            const replyId = replyInput.value || '0';
            if (!text.trim() && replyId === '0') {
                try {
                    localStorage.removeItem(key);
                } catch (error) {}
                return;
            }
            try {
                localStorage.setItem(key, JSON.stringify({
                    text: text,
                    replyId: replyId,
                    replyText: replyText ? replyText.textContent : ''
                }));
            } catch (error) {}
        }

        let draft = null;
        try {
            draft = JSON.parse(localStorage.getItem(key) || 'null');
        } catch (error) {}
        if (draft) {
            input.value = typeof draft.text === 'string' ? draft.text : '';
            if (draft.replyId && draft.replyId !== '0') {
                replyInput.value = String(draft.replyId);
                if (replyText) replyText.textContent = String(draft.replyText || 'Сообщение').slice(0, 120);
                replyCompose.hidden = false;
            }
            input.dispatchEvent(new Event('input', { bubbles: true }));
        }
        input.addEventListener('input', save);
        replyInput.addEventListener('change', save);
        const form = document.getElementById('chatForm');
        if (form) {
            form.addEventListener('submit', function (event) {
                if (event.defaultPrevented) return;
                messageWasSent = true;
                try {
                    sessionStorage.setItem(pendingKey, '1');
                } catch (error) {}
            });
        }

        document.querySelectorAll('.dialog-link').forEach(function (link) {
            link.addEventListener('click', save);
        });
        save();
        window.addEventListener('beforeunload', save);
        window.addEventListener('pagehide', save);
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'hidden') save();
        });
    }

function restoreChatScroll() {
    const chat = document.getElementById('chatMessages');
    const body = document.body;
    if (!chat || !body) return;

    const key = 'messages-scroll:' + (body.dataset.userId || '0') + ':' + (body.dataset.dialogId || '0');
    try {
        const saved = Number.parseInt(localStorage.getItem(key) || '', 10);
        const applyScroll = function () {
            if (Number.isFinite(saved) && saved > 0) {
                chat.scrollTop = Math.min(saved, chat.scrollHeight);
            } else {
                chat.scrollTop = chat.scrollHeight;
            }
        };
        applyScroll();   // сразу, до первой отрисовки, чтобы не было прыжка
        window.requestAnimationFrame(function () {
            window.requestAnimationFrame(applyScroll);   // повтор после загрузки картинок и вёрстки
        });
    } catch (error) {
        chat.scrollTop = chat.scrollHeight;
    }

    const saveScroll = function () {
        try {
            localStorage.setItem(key, String(chat.scrollTop));
        } catch (error) {}
    };
    chat.addEventListener('scroll', saveScroll, { passive: true });
    window.addEventListener('pagehide', saveScroll);
}

function setupDialogDraftPreviews() {
        const body = document.body;
        if (!body) return;
        const userId = body.dataset.userId || '0';
        document.querySelectorAll('.dialog-item[data-dialog-id]').forEach(function (dialog) {
            const preview = dialog.querySelector('[data-dialog-preview]');
            const dialogId = dialog.dataset.dialogId || '0';
            if (!preview || dialogId === '0') return;
            let draft = null;
            try {
                draft = JSON.parse(localStorage.getItem('messages-draft:v2:' + userId + ':' + dialogId) || 'null');
            } catch (error) {}
            if (!draft || (!String(draft.text || '').trim() && String(draft.replyId || '0') === '0')) return;
            const text = String(draft.text || '').trim();
            const reply = String(draft.replyText || '').trim();
            preview.textContent = (text || (reply ? 'Ответ на сообщение ' + reply : 'Ответ на сообщение')).slice(0, 120);
            preview.classList.add('is-draft');
            const label = document.createElement('span');
            label.className = 'dialog-draft-label';
            label.textContent = 'Черновик';
            preview.insertBefore(label, preview.firstChild);
            safeEmojiParse(preview);
        });
}

function storeVoiceWaveform(values) {
    const input = document.getElementById('voiceWaveform');
    if (!input) return;

    const points = Array.from(values || [])
        .map(function (value) {
            const number = Number(value);
            return Number.isFinite(number) ? Math.max(5, Math.min(100, Math.round(number))) : 25;
        });

    while (points.length < 32) points.push(points[points.length - 1] || 25);
    input.value = JSON.stringify(points.slice(0, 32));
}

// ============================================================
// 4.1. АВТООТПРАВКА ПРИ ВЫБОРЕ ФОТО/ВИДЕО
// ============================================================
function setupAttachmentSubmit() {
    const form = document.getElementById('chatForm');
    if (!form) return;

    setupAttachMenu(form);

    ['photoInput', 'videoInput'].forEach(function (id) {
        const input = document.getElementById(id);
        if (!input) return;

        input.addEventListener('change', function () {
            if (this.files && this.files.length > 0) {
                if (typeof form.requestSubmit === 'function') {
                    form.requestSubmit();
                } else {
                    form.submit();
                }
            }
        });
    });
}

// ============================================================
// 4.2. КНОПКА «+» И МИНИ-ПАНЕЛЬ ВЛОЖЕНИЙ
// Наведение открывает панель средствами CSS; здесь — нажатие (телефон/клавиатура), закрытие и обработка
// музыки и файла. Фото и видео работают как раньше (setupAttachmentSubmit).
// ============================================================
let attachMenuGlobalBound = false;

function closeAttachMenu() {
    const menu = document.getElementById('attachMenu');
    if (!menu) return;
    menu.classList.remove('open');
    const plus = document.getElementById('attachPlusBtn');
    if (plus) plus.setAttribute('aria-expanded', 'false');
}

function setupAttachMenu(form) {
    if (!attachMenuGlobalBound) {
        attachMenuGlobalBound = true;
        // «Нажатие» на «+» (на тач-экране наведения нет) и закрытие по клику вне панели / Esc
        document.addEventListener('click', function (event) {
            const menu = document.getElementById('attachMenu');
            if (!menu) return;
            const plus = event.target.closest && event.target.closest('#attachPlusBtn');
            if (plus) {
                const open = !menu.classList.contains('open');
                menu.classList.toggle('open', open);
                plus.setAttribute('aria-expanded', open ? 'true' : 'false');
                return;
            }
            if (!menu.contains(event.target)) closeAttachMenu();
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') closeAttachMenu();
        });
    }

    const panel = document.getElementById('attachPanel');
    if (!panel || panel.dataset.attachInit === '1') return;
    panel.dataset.attachInit = '1';

    // Выбор фото/видео/музыки закрывает панель (само окно выбора файла открывает <label for=...>)
    panel.addEventListener('click', function (event) {
        if (event.target.closest('.attach-item')) window.setTimeout(closeAttachMenu, 0);
    });

    // Музыка: отправляется как аудио-вложение через то же поле, что и голосовое (#voiceFileInput)
    const musicInput = document.getElementById('musicInput');
    if (musicInput) {
        musicInput.addEventListener('change', function () {
            const file = this.files && this.files[0];
            if (!file) return;
            const voiceFileInput = document.getElementById('voiceFileInput');
            if (!voiceFileInput || typeof DataTransfer === 'undefined') {
                showVoiceNotice('Не удалось подготовить файл. Попробуйте ещё раз.');
                this.value = '';
                return;
            }
            const dt = new DataTransfer();
            dt.items.add(file);
            voiceFileInput.files = dt.files;
            const durationInput = document.getElementById('voiceDuration');
            if (durationInput) durationInput.value = '0';
            const waveformInput = document.getElementById('voiceWaveform');
            if (waveformInput) waveformInput.value = JSON.stringify(new Array(32).fill(25));
            this.value = '';
            if (typeof form.requestSubmit === 'function') {
                form.requestSubmit();
            } else {
                form.submit();
            }
        });
    }

    // Файл: кнопка и выбор готовы, но сервер пока принимает только фото, видео и аудио
    const docInput = document.getElementById('docInput');
    if (docInput) {
        docInput.addEventListener('change', function () {
            if (!this.files || this.files.length === 0) return;
            this.value = '';
            showVoiceNotice('Отправка файлов пока не поддерживается.');
        });
    }
}

// ============================================================
// 5. ЗАПИСЬ ГОЛОСОВОГО
// ============================================================
let mediaRecorder    = null;
let audioChunks      = [];
let isRecording      = false;
let recordingTimer   = null;
let recordingSeconds = 0;
let currentStream    = null;
let chosenMimeType   = 'audio/webm';
let recordingAudioContext = null;
let recordingAnalyser = null;
let recordingWaveAnimation = null;
let recordingWaveformData = [];
let recordingStopHandled = false;
let recordingPreviewUrl = null;
let recordingStarting = false;   // идёт запрос доступа к микрофону (пока висит окно разрешения)
let voiceNoticeTimer = null;

// Неблокирующее уведомление вместо alert(): не открывает окно браузера, само исчезает
function showVoiceNotice(text) {
    let el = document.getElementById('voiceNotice');
    if (!el) {
        el = document.createElement('div');
        el.id = 'voiceNotice';
        el.className = 'voice-notice';
        el.setAttribute('role', 'status');
        el.addEventListener('click', function () { el.classList.remove('show'); });
        document.body.appendChild(el);
    }
    el.textContent = text;
    void el.offsetWidth;                 // перезапуск анимации, если уведомление уже было на экране
    el.classList.add('show');
    window.clearTimeout(voiceNoticeTimer);
    voiceNoticeTimer = window.setTimeout(function () { el.classList.remove('show'); }, 6000);
}

// Почему браузер отказал в микрофоне. Вызывается уже ПОСЛЕ отказа getUserMedia,
// чтобы не блокировать запись из-за устаревшего значения Permissions API.
async function describeMicrophoneDenial() {
    try {
        const policy = document.permissionsPolicy || document.featurePolicy;
        if (policy && typeof policy.allowsFeature === 'function' && !policy.allowsFeature('microphone')) {
            return 'policy';
        }
    } catch (error) {}
    try {
        if (navigator.permissions && navigator.permissions.query) {
            const status = await navigator.permissions.query({ name: 'microphone' });
            return status && status.state ? status.state : 'unknown';   // denied | granted | prompt
        }
    } catch (error) {}
    return 'unknown';
}

// Общее неблокирующее уведомление. В проекте не используются window.alert / confirm / prompt:
// вместо них есть эта плашка и таблички (удаление, изменение сообщения).
function showNotice(text) {
    showVoiceNotice(text);
}

function voiceErrorMessage(err, hint) {
    const name = String(err && err.name || '');
    if (err && err.voiceKind === 'insecure') {
        return 'Запись голоса работает только по HTTPS или на localhost. Откройте сайт по защищённому адресу.';
    }
    if (err && err.voiceKind === 'unsupported') {
        return 'Ваш браузер не поддерживает запись голоса.';
    }
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || name === 'SecurityError') {
        if (hint === 'policy') {
            return 'Сервер запрещает микрофон заголовком Permissions-Policy. Разрешите его: microphone=(self).';
        }
        if (hint === 'granted') {
            return 'Доступ разрешён, но браузер ещё не применил его. Обновите страницу (F5) и нажмите на микрофон снова.';
        }
        if (hint === 'denied') {
            return 'Микрофон заблокирован для этого сайта. Нажмите на значок слева от адреса, включите «Микрофон» и обновите страницу (F5).';
        }
        return 'Нужен доступ к микрофону. Разрешите его в окне браузера и нажмите на микрофон ещё раз.';
    }
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
        return 'Микрофон не найден. Подключите микрофон и попробуйте ещё раз.';
    }
    if (name === 'NotReadableError' || name === 'TrackStartError' || name === 'AbortError') {
        return 'Микрофон занят другим приложением или недоступен. Закройте его и попробуйте ещё раз.';
    }
    return 'Не удалось начать запись. Попробуйте ещё раз.';
}

// Запрашивает микрофон. Если разрешение ещё не выдано, браузер сам покажет окно,
// а запись начнётся сразу после «Разрешить», без повторного нажатия на кнопку.
async function requestMicrophoneStream() {
    if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
        const error = new Error(window.isSecureContext === false ? 'insecure context' : 'getUserMedia unsupported');
        error.voiceKind = window.isSecureContext === false ? 'insecure' : 'unsupported';
        throw error;
    }
    if (typeof window.MediaRecorder === 'undefined') {
        const error = new Error('MediaRecorder unsupported');
        error.voiceKind = 'unsupported';
        throw error;
    }

    try {
        return await navigator.mediaDevices.getUserMedia({
            audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
        });
    } catch (error) {
        // Некоторые устройства не принимают эти настройки: пробуем без них
        if (error && error.name === 'OverconstrainedError') {
            return navigator.mediaDevices.getUserMedia({ audio: true });
        }
        throw error;
    }
}

function setupRecording() {
    const voiceBtn = document.getElementById('voiceBtn');
    if (!voiceBtn) return;

    voiceBtn.addEventListener('click', function () {
        if (isRecording) stopRecording();
        else             startRecording();
    });

    const stopBtn = document.querySelector('.voice-stop-btn');
    if (stopBtn) {
        stopBtn.addEventListener('click', function (e) {
            e.preventDefault();
            stopRecording();
        });
    }

    document.getElementById('cancelVoiceBtn')?.addEventListener('click', cancelVoicePreview);
    document.getElementById('continueVoiceBtn')?.addEventListener('click', function () {
        clearVoicePreview(false);
        startRecording(true);
    });
    document.getElementById('previewVoiceBtn')?.addEventListener('click', function () {
        const audio = document.getElementById('voicePreviewAudio');
        if (!audio) return;
        if (audio.paused) {
            audio.play().catch(function (err) {
                console.error('Ошибка прослушивания записи:', err);
            });
        } else {
            audio.pause();
        }
    });
}

async function startRecording(preserveExisting = false) {
    if (isRecording || recordingStarting) return;
    recordingStarting = true;

    const voiceBtn       = document.getElementById('voiceBtn');
    const voiceIndicator = document.getElementById('voiceIndicator');
    const voiceTimerEl   = document.getElementById('voiceTimer');
    const recordingWaveform = document.getElementById('recordingWaveform');

    try {
        currentStream = await requestMicrophoneStream();

        // Анимация волны не критична: если AudioContext не создался, запись всё равно идёт
        const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
        if (recordingWaveform && AudioContextCtor) try {
            recordingAudioContext = new AudioContextCtor();
            if (recordingAudioContext.state === 'suspended') recordingAudioContext.resume().catch(function () {});
            recordingAnalyser = recordingAudioContext.createAnalyser();
            recordingAnalyser.fftSize = 64;
            recordingAnalyser.smoothingTimeConstant = 0.75;
            recordingAudioContext.createMediaStreamSource(currentStream).connect(recordingAnalyser);

            const levels = new Uint8Array(recordingAnalyser.frequencyBinCount);
            const bars = recordingWaveform.querySelectorAll('.recording-wave-bar');
            const updateRecordingWaveform = function () {
                if (!recordingAnalyser) return;
                recordingAnalyser.getByteFrequencyData(levels);
                bars.forEach(function (bar, index) {
                    const level = levels[index % levels.length] / 255;
                    const height = Math.max(12, Math.round(level * 100));
                    recordingWaveformData[index] = height;
                    bar.style.height = height + '%';
                });
                recordingWaveAnimation = requestAnimationFrame(updateRecordingWaveform);
            };
            updateRecordingWaveform();
        } catch (waveError) {
            console.warn('Волна записи недоступна:', waveError);
            stopRecordingWaveform();
        }

        const candidates = [
            'audio/webm;codecs=opus',
            'audio/webm',
            'audio/ogg;codecs=opus',
            'audio/mp4'
        ];
        chosenMimeType = candidates.find(function (t) {
            return window.MediaRecorder && MediaRecorder.isTypeSupported(t);
        }) || '';

        const options = chosenMimeType
            ? { mimeType: chosenMimeType, audioBitsPerSecond: 128000 }
            : { audioBitsPerSecond: 128000 };

        try {
            mediaRecorder = new MediaRecorder(currentStream, options);
        } catch (recorderError) {
            // Браузер не принял тип или битрейт: пишем в формате по умолчанию
            console.warn('MediaRecorder с параметрами не создан, пробуем по умолчанию:', recorderError);
            mediaRecorder = new MediaRecorder(currentStream);
            chosenMimeType = mediaRecorder.mimeType || chosenMimeType;
        }

        if (!preserveExisting) {
            audioChunks = [];
            recordingSeconds = 0;
            recordingWaveformData = new Array(32).fill(25);
        }
        recordingStopHandled = false;
        isRecording      = true;

        if (voiceIndicator) voiceIndicator.classList.add('active');
        if (voiceIndicator) voiceIndicator.classList.remove('preview');
        const status = document.getElementById('voiceRecordingStatus');
        if (status) status.textContent = 'Идёт запись...';
        if (voiceTimerEl)   voiceTimerEl.textContent = '0:00';
        const sendBtn = document.getElementById('sendBtn');
        if (sendBtn) sendBtn.style.display = '';

        if (voiceBtn) {
            voiceBtn.style.visibility = 'hidden';
            voiceBtn.classList.add('recording');
            voiceBtn.title = 'Завершить запись и подготовить отправку';
            voiceBtn.innerHTML = `
                <svg class="icon-send" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
                    <path d="M3.4 20.4l17.45-7.48a1 1 0 0 0 0-1.84L3.4 3.6a.993.993 0 0 0-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91z"/>
                </svg>`;
        }

        recordingTimer = setInterval(function () {
            recordingSeconds++;
            const m = Math.floor(recordingSeconds / 60);
            const s = String(recordingSeconds % 60).padStart(2, '0');
            if (voiceTimerEl) voiceTimerEl.textContent = m + ':' + s;
        }, 1000);

        mediaRecorder.ondataavailable = function (e) {
            if (e.data && e.data.size > 0) audioChunks.push(e.data);
        };

        mediaRecorder.onstop = function () {
            if (recordingStopHandled) return;
            recordingStopHandled = true;

            setTimeout(function () {
            if (recordingTimer) {
                clearInterval(recordingTimer);
                recordingTimer = null;
            }
            isRecording = false;

            if (currentStream) {
                currentStream.getTracks().forEach(function (t) { t.stop(); });
                currentStream = null;
            }

            stopRecordingWaveform();

            if (voiceIndicator) voiceIndicator.classList.add('preview');
            if (voiceIndicator) voiceIndicator.classList.add('active');
            const status = document.getElementById('voiceRecordingStatus');
            if (status) status.textContent = 'Запись готова';

            if (audioChunks.length === 0) {
                resetRecordingUI();
                return;
            }

            const blob = new Blob(audioChunks, {
                type: chosenMimeType || 'audio/webm'
            });

            if (blob.size < 1500) {
                resetRecordingUI();
                showVoiceNotice('Запись слишком короткая. Удерживайте запись подольше.');
                return;
            }

            const ext  = chosenMimeType.includes('mp4')
                ? 'mp4'
                : (chosenMimeType.includes('ogg') ? 'ogg' : 'webm');
            const file = new File(
                [blob],
                'voice_' + Date.now() + '.' + ext,
                { type: chosenMimeType || 'audio/webm' }
            );

            const voiceFileInput = document.getElementById('voiceFileInput');
            if (!voiceFileInput || typeof DataTransfer === 'undefined') {
                resetRecordingUI();
                showVoiceNotice('Не удалось подготовить голосовое сообщение. Попробуйте ещё раз.');
                return;
            }

            const dt = new DataTransfer();
            dt.items.add(file);
            voiceFileInput.files = dt.files;
            if (!voiceFileInput.files || voiceFileInput.files.length === 0) {
                resetRecordingUI();
                showVoiceNotice('Не удалось подготовить голосовое сообщение. Попробуйте ещё раз.');
                return;
            }

            const voiceDurationEl = document.getElementById('voiceDuration');
            if (voiceDurationEl) {
                voiceDurationEl.value = Math.max(1, recordingSeconds);
            }
            storeVoiceWaveform(recordingWaveformData);

            const previewAudio = document.getElementById('voicePreviewAudio');
            if (previewAudio) {
                if (recordingPreviewUrl) URL.revokeObjectURL(recordingPreviewUrl);
                recordingPreviewUrl = URL.createObjectURL(blob);
                previewAudio.src = recordingPreviewUrl;
            }

            resetRecordingUI(false);
            const voiceBtnEl = document.getElementById('voiceBtn');
            const sendBtnEl = document.getElementById('sendBtn');
            if (voiceBtnEl) {
                voiceBtnEl.style.display = 'none';
                voiceBtnEl.style.visibility = '';
            }
            if (sendBtnEl) {
                sendBtnEl.style.display = '';
            }

            const form = document.getElementById('chatForm');
            if (form) {
                form.dataset.voiceReady = '1';
                if (typeof form.requestSubmit === 'function') {
                    form.requestSubmit();
                } else {
                    form.submit();
                }
            }
            }, 50);
        };

        mediaRecorder.start(100);

    } catch (err) {
        console.error('Ошибка записи голоса:', err);
        if (currentStream) {
            currentStream.getTracks().forEach(function (track) { track.stop(); });
            currentStream = null;
        }
        stopRecordingWaveform();
        isRecording = false;
        resetRecordingUI();
        const denied = err && (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError' || err.name === 'SecurityError');
        showVoiceNotice(voiceErrorMessage(err, denied ? await describeMicrophoneDenial() : ''));
    } finally {
        recordingStarting = false;
    }
}

function stopRecording() {
    if (!isRecording || !mediaRecorder) return;
    if (mediaRecorder.state !== 'inactive') {
        mediaRecorder.requestData();
        mediaRecorder.stop();
    }
}

function clearVoicePreview(resetFile = true) {
    const indicator = document.getElementById('voiceIndicator');
    const previewAudio = document.getElementById('voicePreviewAudio');
    if (previewAudio) {
        previewAudio.pause();
        previewAudio.removeAttribute('src');
        previewAudio.load();
    }
    if (recordingPreviewUrl) {
        URL.revokeObjectURL(recordingPreviewUrl);
        recordingPreviewUrl = null;
    }
    if (resetFile) {
        const fileInput = document.getElementById('voiceFileInput');
        const waveformInput = document.getElementById('voiceWaveform');
        const durationInput = document.getElementById('voiceDuration');
        if (fileInput) fileInput.value = '';
        if (waveformInput) waveformInput.value = '';
        if (durationInput) durationInput.value = '0';
    }
    if (indicator) {
        indicator.classList.remove('active', 'preview');
    }
}

function cancelVoicePreview() {
    audioChunks = [];
    recordingSeconds = 0;
    clearVoicePreview(true);
    resetRecordingUI();
}

function cancelRecording() {
    if (!isRecording || !mediaRecorder) return;

    audioChunks = [];
    if (mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    isRecording = false;

    if (recordingTimer) {
        clearInterval(recordingTimer);
        recordingTimer = null;
    }
    if (currentStream) {
        currentStream.getTracks().forEach(function (t) { t.stop(); });
        currentStream = null;
    }
    stopRecordingWaveform();
    resetRecordingUI();
}

function stopRecordingWaveform() {
    if (recordingWaveAnimation) {
        cancelAnimationFrame(recordingWaveAnimation);
        recordingWaveAnimation = null;
    }
    if (recordingAudioContext) {
        recordingAudioContext.close();
        recordingAudioContext = null;
    }
    recordingAnalyser = null;
    document.querySelectorAll('.recording-wave-bar').forEach(function (bar) {
        bar.style.height = '25%';
    });
}

function resetRecordingUI(hideIndicator = true) {
    const voiceBtn       = document.getElementById('voiceBtn');
    const voiceIndicator = document.getElementById('voiceIndicator');
    const input          = document.getElementById('messageInput');

    if (voiceIndicator && hideIndicator) voiceIndicator.classList.remove('active', 'preview');

    if (voiceBtn) {
        voiceBtn.style.visibility = '';
        voiceBtn.classList.remove('recording');
        voiceBtn.title = 'Записать голосовое';
        voiceBtn.innerHTML = `
            <svg class="icon-mic" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
                <path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v5a3 3 0 0 0 3 3z"/>
                <path d="M19 11a1 1 0 1 0-2 0 5 5 0 0 1-10 0 1 1 0 1 0-2 0 7 7 0 0 0 6 6.92V21a1 1 0 1 0 2 0v-3.08A7 7 0 0 0 19 11z"/>
            </svg>`;
    }

    if (input && input.value.trim().length === 0) {
        const voiceBtnEl = document.getElementById('voiceBtn');
        const sendBtnEl  = document.getElementById('sendBtn');
        if (voiceBtnEl) voiceBtnEl.style.display = '';
        if (sendBtnEl)  sendBtnEl.style.display  = 'none';
    }
}

// Экспортируем функции для inline-обработчиков в HTML
window.stopRecording   = stopRecording;
window.cancelRecording = cancelRecording;

// ============================================================
// 6. AVATAR DROPDOWN + ТЕМА
// ============================================================
function setupAvatarDropdown() {
    const avatarBtn    = document.getElementById('avatarBtn');
    const dropdown     = document.getElementById('avatarDropdown');
    const themeTrigger = document.getElementById('themeTrigger');
    const themeSubmenu = document.getElementById('themeSubmenu');
    const themeArrow   = document.getElementById('themeArrow');

    if (avatarBtn && dropdown) {
        avatarBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            // закрываем окно уведомлений, чтобы открыто было только одно
            const notifDropdown = document.getElementById('notificationsDropdown');
            if (notifDropdown) notifDropdown.classList.remove('active');
            dropdown.classList.toggle('active');
        });

        document.addEventListener('click', function (e) {
            if (!e.target.closest('.avatar-dropdown')) {
                dropdown.classList.remove('active');
            }
        });
    }

    if (themeTrigger && themeSubmenu) {
        themeTrigger.addEventListener('click', function (e) {
            e.stopPropagation();
            themeSubmenu.classList.toggle('open');
            themeTrigger.classList.toggle('open');
            if (themeArrow) {
                themeArrow.textContent = themeSubmenu.classList.contains('open') ? '▲' : '▼';
            }
        });

        // Выбор темы без перезагрузки страницы: плавный переход, а выбор запоминается в cookie на сервере
        const themeNames = { dark: 'Тёмная', light: 'Светлая', system: 'Системная' };
        themeSubmenu.addEventListener('click', function (e) {
            const item = e.target.closest('.theme-item');
            if (!item) return;
            let mode = '';
            try {
                mode = new URL(item.href, window.location.href).searchParams.get('theme') || '';
            } catch (error) {}
            if (!themeNames[mode]) return;   // незнакомая ссылка: пусть работает как обычно

            e.preventDefault();
            e.stopPropagation();
            if (document.body.dataset.theme === mode) return;

            window.runThemeTransition(function () {
                document.body.dataset.theme = mode;
                document.body.dataset.themeMode = 'manual';
            });

            themeSubmenu.querySelectorAll('.theme-item').forEach(function (other) {
                const active = other === item;
                other.classList.toggle('active', active);
                const check = other.querySelector('.theme-check');
                if (active && !check) {
                    const mark = document.createElement('span');
                    mark.className = 'theme-check';
                    mark.textContent = '✓';
                    other.appendChild(mark);
                } else if (!active && check) {
                    check.remove();
                }
            });
            const current = themeTrigger.querySelector('.theme-current');
            if (current) current.textContent = themeNames[mode];

            // Сервер сохраняет тему в cookie и отвечает редиректом, тело страницы нам не нужно
            fetch('messages.php?theme=' + encodeURIComponent(mode), {
                credentials: 'same-origin',
                redirect: 'manual'
            }).catch(function () {});
        });
    }
}

// ============================================================
// 7. УВЕДОМЛЕНИЯ (dropdown)
// ============================================================
function setupNotifications() {
    const btn      = document.getElementById('notificationsBtn');
    const dropdown = document.getElementById('notificationsDropdown');
    const markAll  = document.getElementById('markAllReadBtn');

    if (btn && dropdown) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            // закрываем меню профиля, чтобы открыто было только одно
            const avatarMenu = document.getElementById('avatarDropdown');
            if (avatarMenu) avatarMenu.classList.remove('active');
            dropdown.classList.toggle('active');
        });

        document.addEventListener('click', function (e) {
            if (!e.target.closest('.notifications-wrapper')) {
                dropdown.classList.remove('active');
            }
        });
    }

    if (markAll) {
        markAll.addEventListener('click', function (e) {
            e.stopPropagation();
            fetch('notifications_read.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'mark_all=1'
            }).then(function () {
                document.querySelectorAll('.notification-item.unread').forEach(function (el) {
                    el.classList.remove('unread');
                    el.classList.add('read');
                    const dot = el.querySelector('.notif-dot');
                    if (dot) dot.remove();
                });
                const badge = btn ? btn.querySelector('.notifications-badge') : null;
                if (badge) badge.remove();
                markAll.remove();
            }).catch(function () {});
        });
    }
}

// ============================================================
// 8. СНЯТИЕ БЕЙДЖА .dialog-unread
//    (эмодзи-пикер живёт в emoji.js, здесь только диалоги)
// ============================================================
function setupDialogRead() {
    const items = document.querySelectorAll('.dialog-item:not(.dialog-self)');
    if (!items.length) return;

    document.querySelectorAll('.dialog-item.active:not(.dialog-self)').forEach(function (item) {
        removeUnreadFromItem(item, /*sendAjax=*/true);
    });

    items.forEach(function (item) {
        if (item.dataset.readInit === '1') return;
        item.dataset.readInit = '1';

        const link = item.querySelector('.dialog-link');
        if (link) {
            link.addEventListener('click', function () {
                if (item.classList.contains('active')) return;
                removeUnreadFromItem(item, /*sendAjax=*/true);
            });
        }

        let hoverTimer = null;

        item.addEventListener('mouseenter', function () {
            if (!item.querySelector('.dialog-unread')) return;
            if (item.classList.contains('active')) return;

            hoverTimer = setTimeout(function () {
                removeUnreadFromItem(item, /*sendAjax=*/true);
            }, 250);
        });

        item.addEventListener('mouseleave', function () {
            if (hoverTimer) {
                clearTimeout(hoverTimer);
                hoverTimer = null;
            }
        });
    });
}

function removeUnreadFromItem(dialogItem, sendAjax) {
    if (!dialogItem) return;
    if (dialogItem.classList.contains('dialog-self')) return;

    const dialogId = dialogItem.getAttribute('data-dialog-id');
    const badge    = dialogItem.querySelector('.dialog-unread');
    if (!badge) return;

    badge.remove();
    recalcNavUnreadBadge();

    if (
        sendAjax &&
        dialogId &&
        dialogId !== '0' &&
        dialogItem.dataset.markedRead !== '1'
    ) {
        dialogItem.dataset.markedRead = '1';

        fetch('api/messages.php?api=mark_read', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-Token': getCsrfToken()
            },
            body: 'dialog=' + encodeURIComponent(dialogId) + '&csrf_token=' + encodeURIComponent(getCsrfToken())
        }).catch(function () {});
    }
}

function recalcNavUnreadBadge() {
    const navItem = document.querySelector('.bottom-nav .nav-item.active');
    if (!navItem) return;

    let total = 0;
    document.querySelectorAll('.dialog-item:not(.dialog-self) .dialog-unread').forEach(function (b) {
        const txt = (b.textContent || '').trim();
        if (txt === '99+') { total += 99; return; }
        const n = parseInt(txt, 10);
        if (!isNaN(n)) total += n;
    });

    let badge = navItem.querySelector('.notification-badge');

    if (total > 0) {
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'notification-badge';
            navItem.appendChild(badge);
        }
        badge.textContent = total > 99 ? '99+' : String(total);
    } else if (badge) {
        badge.remove();
    }
}

// ============================================================
// 9. НИЖНЯЯ ПАНЕЛЬ
// ============================================================
function setupBottomNav() {
    const handleBtn = document.getElementById('handleBtn');
    const bottomNav = document.querySelector('.bottom-nav') ||
                      document.querySelector('app-navigation.bottom-nav');

    if (!handleBtn || !bottomNav) return;
    if (bottomNav.hasAttribute('data-managed-by-partial')) return;
    if (handleBtn.dataset.navInit === '1') return;
    handleBtn.dataset.navInit = '1';

    let lastScrollTop = 0;
    let hoverTimeout  = null;
    let isNavVisible  = false;

    const handleBar = document.querySelector('.bottom-handle .handle-bar');
    let animationTimeout = null;

    function startAnimation() {
        if (!handleBar) return;
        if (animationTimeout) {
            clearTimeout(animationTimeout);
            animationTimeout = null;
        }
        handleBar.style.animation = 'none';
        handleBar.style.width = '40px';
        animationTimeout = setTimeout(function () {
            animationTimeout = null;
            if (bottomNav.classList.contains('nav-hidden')) {
                handleBar.style.animation = 'handleStretch 2s ease-in-out 1 forwards';
            }
        }, 3000);
    }

    function stopAnimation() {
        if (!handleBar) return;
        if (animationTimeout) {
            clearTimeout(animationTimeout);
            animationTimeout = null;
        }
        handleBar.style.animation = 'none';
        handleBar.style.width = '40px';
    }

    if (handleBar) {
        handleBar.addEventListener('animationend', function () {
            handleBar.style.animation = 'none';
            handleBar.style.width = '40px';
        });
    }

    function showNav() {
        if (isNavVisible) return;
        bottomNav.classList.remove('nav-hidden');
        handleBtn.classList.add('handle-hidden');
        isNavVisible = true;
        stopAnimation();
    }

    function hideNav() {
        bottomNav.classList.add('nav-hidden');
        handleBtn.classList.remove('handle-hidden');
        isNavVisible = false;
        startAnimation();
    }

    hideNav();

    handleBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (bottomNav.classList.contains('nav-hidden')) {
            showNav();
        } else {
            hideNav();
        }
    });

    handleBtn.addEventListener('mouseenter', function () {
        if (hoverTimeout) {
            clearTimeout(hoverTimeout);
            hoverTimeout = null;
        }
        showNav();
    });

    handleBtn.addEventListener('mouseleave', function () {
        hoverTimeout = setTimeout(function () {
            if (!bottomNav.matches(':hover')) {
                hideNav();
            }
        }, 400);
    });

    bottomNav.addEventListener('mouseenter', function () {
        if (hoverTimeout) {
            clearTimeout(hoverTimeout);
            hoverTimeout = null;
        }
    });

    bottomNav.addEventListener('mouseleave', function () {
        if (!handleBtn.matches(':hover')) {
            hideNav();
        }
    });

    window.addEventListener('scroll', function () {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (scrollTop > lastScrollTop && scrollTop > 100) {
            showNav();
        } else if (scrollTop < lastScrollTop && scrollTop > 50) {
            hideNav();
        } else if (scrollTop <= 50) {
            hideNav();
        }

        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
    });

    (function () {
        if (!handleBar) return;

        handleBtn.addEventListener('mouseenter', function () {
            if (bottomNav.classList.contains('nav-hidden')) {
                startAnimation();
            }
        });

        const observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                if (mutation.attributeName === 'class') {
                    if (bottomNav.classList.contains('nav-hidden')) {
                        setTimeout(startAnimation, 200);
                    } else {
                        stopAnimation();
                    }
                }
            });
        });
        observer.observe(bottomNav, { attributes: true });
    })();
}

// ============================================================
// 10. RESIZER
// ============================================================
function setupResizer() {
    const layout  = document.querySelector('.messages-layout');
    let   sidebar = document.querySelector('.dialogs-sidebar');   // let: узел списка подменяется целиком (см. syncSidebar)
    const resizer = document.querySelector('.resizer');
    const handle  = document.getElementById('sidebarResizeHandle');
    if (!layout || !sidebar || !resizer) return;

    const MIN_SIDEBAR = 200;
    const MIN_CHAT    = 250;
    const MAX_SIDEBAR = 500;
    const COLLAPSED_W = 72;
    const COLLAPSE_AT = 140;      // потянули уже этого — список сворачивается
    const DEFAULT_W   = 300;
    const KEY_W = 'messages-dialogs-width';       // ширина РАЗВЁРНУТОГО списка
    const KEY_C = 'messages-dialogs-collapsed';   // '1' — список свёрнут
    const root = document.documentElement;
    const mobileMq = window.matchMedia('(max-width: 600px)');   // на телефоне разделителя нет

    function load(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }
    function store(key, val) { try { localStorage.setItem(key, String(val)); } catch (e) {} }

    function maxWidth() {
        return Math.max(MIN_SIDEBAR, Math.min(MAX_SIDEBAR, layout.getBoundingClientRect().width - MIN_CHAT));
    }
    function clampW(w) {
        return Math.max(MIN_SIDEBAR, Math.min(maxWidth(), Math.round(w)));
    }

    // Состояние. В старой версии свёрнутый список хранился как ширина < 200 — учитываем это.
    const savedW = Number.parseInt(load(KEY_W) || '', 10);
    let collapsed = load(KEY_C) === '1' || (Number.isFinite(savedW) && savedW < MIN_SIDEBAR);
    let hasCustomWidth = Number.isFinite(savedW) && savedW >= MIN_SIDEBAR;   // пока не меняли — ширина из CSS
    let expandedWidth = hasCustomWidth ? savedW : DEFAULT_W;

    resizer.setAttribute('aria-valuemin', String(MIN_SIDEBAR));
    resizer.setAttribute('aria-valuemax', String(MAX_SIDEBAR));

    // Запомнить текущую ширину перед сворачиванием, чтобы потом вернуть её же
    function rememberWidth(width) {
        if (!hasCustomWidth) {
            expandedWidth = clampW(width);
            hasCustomWidth = true;
        }
    }

    let liveW = null;   // ширина прямо под курсором во время перетаскивания (null — не тянем)

    function apply() {
        const live = liveW !== null && !mobileMq.matches;
        const isCollapsed = live ? liveW < COLLAPSE_AT : (collapsed && !mobileMq.matches);   // на телефоне список всегда развёрнут
        sidebar.classList.toggle('is-collapsed', isCollapsed);
        sidebar.classList.toggle('is-resizing', live);
        if (live) {
            root.style.setProperty('--dialogs-width', liveW + 'px');   // список идёт строго за курсором
        } else if (isCollapsed) {
            root.style.setProperty('--dialogs-width', COLLAPSED_W + 'px');
        } else if (hasCustomWidth) {
            root.style.setProperty('--dialogs-width', clampW(expandedWidth) + 'px');   // и при сужении окна
        } else {
            root.style.removeProperty('--dialogs-width');
        }
        if (handle && !live) {   // стрелка меняется только по итогу, а не на лету во время перетаскивания
            const c = collapsed && !mobileMq.matches;
            handle.textContent = c ? '›' : '‹';
            handle.setAttribute('aria-expanded', c ? 'false' : 'true');
        }
        resizer.setAttribute('aria-valuenow',
            String(live ? liveW : (isCollapsed ? COLLAPSED_W : clampW(hasCustomWidth ? expandedWidth : sidebar.getBoundingClientRect().width))));
    }

    // Плавная «доводка» после отпускания / клика по кнопке / стрелок
    let snapTimer = null;
    function snap() {
        sidebar.classList.add('is-snapping');
        clearTimeout(snapTimer);
        snapTimer = setTimeout(function () { sidebar.classList.remove('is-snapping'); }, 240);
    }

    function persist() {
        store(KEY_C, collapsed ? '1' : '0');
        if (hasCustomWidth) store(KEY_W, clampW(expandedWidth));
    }

    function setCollapsed(next) {
        if (next && !collapsed) rememberWidth(sidebar.getBoundingClientRect().width);
        collapsed = next;
        snap();
        apply();
        persist();
    }

    // ----- Перетаскивание (мышь, палец, перо — одни и те же pointer-события) -----
    let drag = null;

    resizer.addEventListener('pointerdown', function (e) {
        if (mobileMq.matches) return;
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        // Если ещё идёт «доводка» после клика по кнопке — обрываем её, иначе ширина лагает за курсором
        clearTimeout(snapTimer);
        sidebar.classList.remove('is-snapping');
        drag = {
            id: e.pointerId,
            startX: e.clientX,
            startW: sidebar.getBoundingClientRect().width,
            moved: false,
            onHandle: !!(handle && handle.contains(e.target))   // нажали на кнопку-стрелку: клик — свернуть/развернуть, с движением — тянет разделитель
        };
        try { resizer.setPointerCapture(e.pointerId); } catch (err) {}   // курсор может выйти за окно — события не теряются
        e.preventDefault();                                              // не выделять текст при перетаскивании
    });

    resizer.addEventListener('pointermove', function (e) {
        if (!drag || e.pointerId !== drag.id) return;
        const dx = e.clientX - drag.startX;
        if (!drag.moved) {
            if (Math.abs(dx) < 4) return;          // это ещё клик, а не перетаскивание
            drag.moved = true;
            resizer.classList.add('dragging');
            document.body.style.cursor = 'col-resize';
            document.body.style.userSelect = 'none';
        }
        // Список плавно идёт за курсором от свёрнутого вида (72px) до максимума; итог фиксируем при отпускании
        liveW = Math.max(COLLAPSED_W, Math.min(maxWidth(), Math.round(drag.startW + dx)));
        apply();
    });

    function endDrag(e) {
        if (!drag || e.pointerId !== drag.id) return;
        const d = drag;
        drag = null;
        try { resizer.releasePointerCapture(d.id); } catch (err) {}
        resizer.classList.remove('dragging');
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        if (d.moved) {
            const w = liveW;
            liveW = null;
            if (w !== null && w < COLLAPSE_AT) {
                rememberWidth(Math.max(d.startW, MIN_SIDEBAR));
                collapsed = true;                   // отпустили узко — прилипает к свёрнутому виду
            } else if (w !== null) {
                expandedWidth = clampW(w);          // иначе — запоминаем ширину (не уже 200px)
                hasCustomWidth = true;
                collapsed = false;
            }
            snap();
            apply();
            persist();                              // в localStorage — один раз в конце, а не на каждое движение
        } else if (d.onHandle && e.type === 'pointerup') {
            setCollapsed(!collapsed);               // просто нажали на кнопку-стрелку
        }
    }
    resizer.addEventListener('pointerup', endDrag);
    resizer.addEventListener('pointercancel', endDrag);
    resizer.addEventListener('lostpointercapture', endDrag);   // страховка: перетаскивание никогда не «залипает», даже если pointerup потерялся

    // Двойной клик по линии — вернуть ширину по умолчанию
    resizer.addEventListener('dblclick', function (e) {
        // из-за pointer capture целью dblclick всегда становится resizer, поэтому кнопку определяем по координатам
        if (handle) {
            const r = handle.getBoundingClientRect();
            if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) return;
        }
        collapsed = false;
        expandedWidth = DEFAULT_W;
        hasCustomWidth = true;
        apply();
        persist();
    });

    // Клавиатура: ←/→ меняют ширину (Shift — крупнее), Enter/Пробел — свернуть/развернуть
    resizer.addEventListener('keydown', function (e) {
        if (mobileMq.matches) return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setCollapsed(!collapsed);
            return;
        }
        if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
        e.preventDefault();
        const dir = e.key === 'ArrowRight' ? 1 : -1;
        const step = e.shiftKey ? 48 : 16;
        if (collapsed) {
            if (dir < 0) return;
            collapsed = false;
            if (!hasCustomWidth) { expandedWidth = DEFAULT_W; hasCustomWidth = true; }
        } else {
            const cur = hasCustomWidth ? expandedWidth : sidebar.getBoundingClientRect().width;
            const next = cur + dir * step;
            if (dir < 0 && next < MIN_SIDEBAR) {
                rememberWidth(cur);
                collapsed = true;
            } else {
                expandedWidth = clampW(next);
                hasCustomWidth = true;
            }
        }
        snap();
        apply();
        persist();
    });

    // Окно изменилось (в т.ч. стало узким) — подгоняем ширину, чтобы чат не сжимался
    window.addEventListener('resize', apply);
    if (mobileMq.addEventListener) mobileMq.addEventListener('change', apply);

    // Список диалогов подменяется целиком (опрос новых сообщений, AJAX-переход между диалогами):
    // новый узел приходит с сервера без классов is-collapsed / is-resizing, а ссылка на старый устаревает —
    // из-за этого свёрнутый список «сам» разворачивался до 200px. После каждой подмены берём свежий узел
    // и заново применяем состояние (колбэк MutationObserver срабатывает до отрисовки — мигания нет).
    function syncSidebar() {
        const fresh = layout.querySelector('.dialogs-sidebar');
        if (!fresh || fresh === sidebar) return;
        sidebar = fresh;
        apply();
    }
    if (window.MutationObserver) {
        new MutationObserver(syncSidebar).observe(sidebar.parentNode || layout, { childList: true });
    }

    apply();
}

// ============================================================
// 11. ПОИСК ЛЮДЕЙ (модалка)
// ============================================================
function openSearchModal() {
    const modal = document.getElementById('searchModal');
    if (!modal) return;
    modal.classList.add('active');

    const input = document.getElementById('searchInput');
    if (input) {
        input.value = '';
        setTimeout(function () { input.focus(); }, 50);
    }

    const results = document.getElementById('searchResults');
    if (results) {
        results.innerHTML = '<div class="search-placeholder">Введите имя для поиска</div>';
    }
}

function closeSearchModal() {
    const modal = document.getElementById('searchModal');
    if (modal) modal.classList.remove('active');
}

let searchUsersTimer = null;

function searchUsers() {
    const input   = document.getElementById('searchInput');
    const results = document.getElementById('searchResults');
    if (!input || !results) return;

    const q = input.value.trim();

    if (searchUsersTimer) {
        clearTimeout(searchUsersTimer);
        searchUsersTimer = null;
    }

    if (q.length < 1) {
        results.innerHTML = '<div class="search-placeholder">Введите имя для поиска</div>';
        return;
    }

    searchUsersTimer = setTimeout(function () {
        fetch('api/messages.php?api=users&q=' + encodeURIComponent(q), {
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data.success || !data.users || data.users.length === 0) {
                results.innerHTML = '<div class="search-placeholder">Ничего не найдено</div>';
                return;
            }

            let html = '';
            data.users.forEach(function (u) {
                const avatarHtml = u.avatar
                    ? '<img src="' + escapeHtmlSearch(u.avatar) + '" alt="">'
                    : (u.username ? escapeHtmlSearch(u.username.charAt(0).toUpperCase()) : '?');

                const statusClass = u.status === 'online' ? 'online' : '';
                const statusText  = u.status === 'online' ? 'В сети' : 'Не в сети';

                html +=
                    '<a class="search-result-item" href="messages.php?dialog=' + u.id + '">' +
                        '<div class="search-result-avatar">' + avatarHtml + '</div>' +
                        '<div class="search-result-name">' + escapeHtmlSearch(u.username || 'Пользователь') + '</div>' +
                        '<div class="search-result-status ' + statusClass + '" data-user-presence="' + Number(u.id) + '">' + statusText + '</div>' +
                    '</a>';
            });
            results.innerHTML = html;
        })
        .catch(function () {
            results.innerHTML = '<div class="search-error">Ошибка поиска</div>';
        });
    }, 300);
}

function escapeHtmlSearch(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function setupSearchModalClose() {
    const modal = document.getElementById('searchModal');
    if (!modal) return;

    modal.addEventListener('click', function (e) {
        if (e.target === modal) closeSearchModal();
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeSearchModal();
    });
}

// ============================================================
// 12. ДЕЙСТВИЯ СООБЩЕНИЙ
// ============================================================
// ============================================================
// ОКНО ПРОСМОТРА ФОТО + ПОЛЗУНОК СКРУГЛЕНИЯ УГЛОВ
// Модалка #photoViewerModal лежит вне .chat-area, поэтому её кнопки
// достаточно навесить один раз при загрузке страницы. А вот сами фото
// (.msg-photo-viewable) каждый раз перерисовываются AJAX-навигацией
// (loadMessagesPage меняет .chat-area целиком) — для клика по ним
// используется делегирование на document, чтобы не перевешивать
// обработчик заново после каждого перехода между диалогами.
// ============================================================
function setupPhotoViewer() {
    const modal = document.getElementById('photoViewerModal');
    if (!modal) return;

    const stageImg       = document.getElementById('photoViewerImage');
    const closeBtn        = document.getElementById('photoViewerClose');
    const openOriginal    = document.getElementById('photoViewerOpenOriginal');

    // Блок «кто отправил / когда / переслать» над фото
    const infoBox     = document.getElementById('photoViewerInfo');
    const infoAvatar  = document.getElementById('photoViewerAvatar');
    const infoAuthor  = document.getElementById('photoViewerAuthor');
    const infoTime    = document.getElementById('photoViewerTime');
    const shareBtn    = document.getElementById('photoViewerShare');
    const likeBtn     = document.getElementById('photoViewerLike');
    const likeCount   = document.getElementById('photoViewerLikeCount');
    const shareCount  = document.getElementById('photoViewerShareCount');

    // Своё сообщение — аватар и ник текущего пользователя (лежат в data-атрибутах блока),
    // чужое — собеседник из шапки открытого диалога (читаем в момент открытия: шапка
    // перерисовывается AJAX-навигацией).
    function fillPhotoViewerInfo(photoEl) {
        if (!infoBox) return;
        const messageEl = photoEl.closest('.chat-message');
        const isMine = !!messageEl && messageEl.dataset.isMine === '1';

        let name = '';
        infoAvatar.innerHTML = '';

        if (isMine) {
            name = infoBox.dataset.meName || '';
            if (infoBox.dataset.meAvatar) {
                const img = document.createElement('img');
                img.src = infoBox.dataset.meAvatar;
                img.alt = '';
                infoAvatar.appendChild(img);
            } else {
                infoAvatar.textContent = infoBox.dataset.meLetter || '?';
            }
        } else {
            const headerAvatar = document.querySelector('.chat-header-avatar');
            const headerName   = document.querySelector('.chat-header-name-text');
            name = headerName ? headerName.textContent.trim() : '';
            if (headerAvatar) {
                const clone = headerAvatar.cloneNode(true);
                const dot = clone.querySelector('.chat-header-online-dot');
                if (dot) dot.remove();
                infoAvatar.innerHTML = clone.innerHTML.trim();
            }
        }
        infoAuthor.textContent = name;

        // Время отправки: берём unix-timestamp сообщения и показываем дату + время в часовом поясе браузера
        let timeText = '';
        const timeEl = messageEl ? messageEl.querySelector('.msg-time') : null;
        const ts = timeEl ? Number.parseInt(timeEl.dataset.timestamp || '0', 10) : 0;
        if (ts > 0) {
            timeText = chatDateTime(ts);
            infoTime.title = new Date(ts * 1000).toLocaleString('ru-RU', {
                day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
            });
        } else if (timeEl) {
            timeText = timeEl.textContent.trim();
        }
        infoTime.textContent = timeText;

        infoBox.hidden = false;
    }

    // ===== Комментарии к фото =====
    const commentsList  = document.getElementById('photoViewerComments');
    const commentForm   = document.getElementById('photoViewerCommentForm');
    const commentInput  = document.getElementById('photoViewerCommentInput');
    const commentSend   = document.getElementById('photoViewerCommentSend');
    let commentsMsgId   = null;   // сообщение, чьи комментарии сейчас показаны (защита от устаревших ответов)
    let commentSending  = false;

    function commentsApi(action, data) {
        const body = new URLSearchParams(data || {});
        body.set('csrf_token', getCsrfToken());
        return fetch('api/messages.php?api=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': getCsrfToken() },
            body: body.toString()
        }).then(function (response) {
            return response.json().catch(function () { return { success: false }; });
        });
    }

    function setCommentsNote(text) {
        commentsList.innerHTML = '';
        const note = document.createElement('div');
        note.className = 'photo-viewer-comments-note';
        note.textContent = text;
        commentsList.appendChild(note);
    }

    function formatCommentTime(ts) {
        if (!ts) return '';
        return new Date(ts * 1000).toLocaleString('ru-RU', {
            day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
        });
    }

    function buildComment(comment) {
        const item = document.createElement('div');
        item.className = 'photo-viewer-comment';
        item.dataset.commentId = String(comment.id);

        const avatar = document.createElement('div');
        avatar.className = 'photo-viewer-comment-avatar';
        if (comment.avatar) {
            const img = document.createElement('img');
            img.src = comment.avatar;
            img.alt = '';
            avatar.appendChild(img);
        } else {
            avatar.textContent = (comment.username || '?').charAt(0).toUpperCase();
        }

        const main = document.createElement('div');
        main.className = 'photo-viewer-comment-main';

        const head = document.createElement('div');
        head.className = 'photo-viewer-comment-head';
        const name = document.createElement('span');
        name.className = 'photo-viewer-comment-name';
        name.textContent = comment.username;
        const time = document.createElement('span');
        time.className = 'photo-viewer-comment-time';
        time.textContent = formatCommentTime(comment.ts);
        head.appendChild(name);
        head.appendChild(time);

        if (comment.can_delete) {
            const del = document.createElement('button');
            del.type = 'button';
            del.className = 'photo-viewer-comment-delete';
            del.title = 'Удалить комментарий';
            del.setAttribute('aria-label', 'Удалить комментарий');
            del.textContent = '×';
            del.addEventListener('click', function () {
                del.disabled = true;
                commentsApi('photo_comment_delete', { comment_id: comment.id }).then(function (result) {
                    if (result && result.success) {
                        item.remove();
                        if (!commentsList.querySelector('.photo-viewer-comment')) setCommentsNote('Нет комментариев');
                    } else {
                        del.disabled = false;
                    }
                }).catch(function () { del.disabled = false; });
            });
            head.appendChild(del);
        }

        const text = document.createElement('div');
        text.className = 'photo-viewer-comment-text';
        text.textContent = comment.content;

        main.appendChild(head);
        main.appendChild(text);
        item.appendChild(avatar);
        item.appendChild(main);
        return item;
    }

    function renderComments(comments) {
        if (!comments.length) {
            setCommentsNote('Нет комментариев');
            return;
        }
        commentsList.innerHTML = '';
        comments.forEach(function (comment) { commentsList.appendChild(buildComment(comment)); });
        commentsList.scrollTop = commentsList.scrollHeight;
    }

    // Лайки и пересылки фото: счётчики и состояние сердечка
    function applyPhotoStats(st) {
        st = st || {};
        if (likeCount) likeCount.textContent = String(st.likes || 0);
        if (shareCount) shareCount.textContent = String(st.forwards || 0);
        if (likeBtn) likeBtn.classList.toggle('active', !!st.liked);
    }

    if (likeBtn) {
        likeBtn.addEventListener('click', function () {
            if (!commentsMsgId || likeBtn.disabled) return;
            const id = commentsMsgId;
            likeBtn.disabled = true;
            commentsApi('photo_like', { message_id: id }).then(function (res) {
                if (commentsMsgId === id && res && res.success && res.stats) applyPhotoStats(res.stats);
            }).catch(function () {}).finally(function () { likeBtn.disabled = false; });
        });
    }

    function loadComments(msgId) {
        applyPhotoStats(null);
        commentsMsgId = msgId;
        commentForm.hidden = !msgId;
        commentInput.value = '';
        commentSend.disabled = true;
        if (!msgId) { setCommentsNote('Комментарии недоступны'); return; }

        setCommentsNote('Загрузка...');
        fetch('api/messages.php?api=photo_comments&message_id=' + encodeURIComponent(msgId), { credentials: 'same-origin' })
            .then(function (response) { return response.json(); })
            .then(function (result) {
                if (commentsMsgId !== msgId) return;   // окно уже закрыли или открыли другое фото
                if (result && result.success) {
                    applyPhotoStats(result.stats);
                    renderComments(result.comments || []);
                } else {
                    setCommentsNote('Не удалось загрузить комментарии');
                }
            })
            .catch(function () {
                if (commentsMsgId === msgId) setCommentsNote('Не удалось загрузить комментарии');
            });
    }

    function sendComment() {
        const text = commentInput.value.trim();
        if (!text || !commentsMsgId || commentSending) return;
        commentSending = true;
        commentSend.disabled = true;
        const msgId = commentsMsgId;

        commentsApi('photo_comment_add', { message_id: msgId, content: text }).then(function (result) {
            if (commentsMsgId !== msgId) return;
            if (result && result.success && result.comment) {
                const note = commentsList.querySelector('.photo-viewer-comments-note');
                if (note) note.remove();
                commentsList.appendChild(buildComment(result.comment));
                commentsList.scrollTop = commentsList.scrollHeight;
                commentInput.value = '';
            }
        }).catch(function () {}).finally(function () {
            commentSending = false;
            commentSend.disabled = commentInput.value.trim() === '';
            commentInput.focus();
        });
    }

    commentInput.addEventListener('input', function () {
        commentSend.disabled = commentSending || commentInput.value.trim() === '';
    });
    commentInput.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendComment();
        }
    });
    commentSend.addEventListener('click', sendComment);

    let activePhoto  = null;   // <img> самого сообщения в переписке — в него пишем итог

    function openViewer(photoEl) {
        activePhoto = photoEl;
        const src = photoEl.getAttribute('src') || '';

        stageImg.src = src;
        stageImg.style.borderRadius = '8px';
        openOriginal.href = src;

        fillPhotoViewerInfo(photoEl);

        const msgEl = photoEl.closest('.chat-message');
        loadComments(msgEl ? msgEl.dataset.messageId : null);

        modal.hidden = false;
        document.body.classList.add('photo-viewer-open');
    }

    function closeViewer() {
        modal.hidden = true;
        document.body.classList.remove('photo-viewer-open');
        stageImg.src = '';
        activePhoto = null;
        commentsMsgId = null;
    }

    // Клик по любому фото в переписке (сообщение может быть перерисовано AJAX-навигацией)
    document.addEventListener('click', function (event) {
        const photo = event.target.closest('.msg-photo-viewable');
        if (!photo) return;
        event.preventDefault();
        openViewer(photo);
    });

    // «Переслать» — то же окно выбора диалога, что и у пункта «Переслать» в меню сообщения
    if (shareBtn) {
        shareBtn.addEventListener('click', function () {
            const messageEl = activePhoto && activePhoto.closest('.chat-message');
            const msgId = messageEl && messageEl.dataset.messageId;
            if (msgId && typeof window.openForwardForMessages === 'function') {
                window.openForwardForMessages([msgId]);
            }
        });
    }

    closeBtn.addEventListener('click', closeViewer);
    modal.addEventListener('click', function (event) {
        if (event.target === modal) closeViewer();   // клик по тёмному фону — закрыть
    });
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && !modal.hidden) closeViewer();
    });

}

function setupMessageActions() {
    const chat = document.getElementById('chatMessages');
    if (!chat) return;

    let activeMessage = null;
    let forwardMessageIds = [];
    let activeSwipe = null;
    // Токен берём в момент запроса, а не один раз при инициализации: он может смениться (например, после
    // «завершить сеансы»), и тогда старый токен давал отказ — «Не удалось удалить сообщение у всех участников».
    function csrfNow() {
        const input = document.querySelector('input[name="csrf_token"]');
        return (input && input.value) || getCsrfToken();
    }
    const context = document.getElementById('messageContextMenu');
    const forwardModal = document.getElementById('forwardDialogModal');
    const forwardSearch = document.getElementById('forwardDialogSearch');
    const forwardList = forwardModal ? forwardModal.querySelector('.forward-dialog-list') : null;
    const closeForwardButton = document.getElementById('closeForwardBtn');
    const toolbar = document.getElementById('messageSelectionToolbar');
    const replyInput = document.getElementById('replyToId');
    const replyCompose = document.getElementById('replyCompose');
    const replyText = document.getElementById('replyComposeText');
    let pendingLongPress = null;
    let suppressedLongPressClick = null;
    let pendingDesktopReply = null;

    function clearPendingLongPress() {
        if (!pendingLongPress) return;
        window.clearTimeout(pendingLongPress.timer);
        pendingLongPress = null;
    }

    function clearSuppressedLongPressClick() {
        if (!suppressedLongPressClick) return;
        window.clearTimeout(suppressedLongPressClick.timer);
        suppressedLongPressClick = null;
    }

    function clearPendingDesktopReply() {
        if (!pendingDesktopReply) return;
        window.clearTimeout(pendingDesktopReply.timer);
        pendingDesktopReply = null;
    }

    function ensureSwipeIndicator(message) {
        let indicator = message.querySelector(':scope > .msg-swipe-action');
        if (indicator) return indicator;

        indicator = document.createElement('span');
        indicator.className = 'msg-swipe-action';
        indicator.setAttribute('aria-hidden', 'true');
        indicator.innerHTML =
            '<svg class="msg-swipe-icon msg-swipe-icon-reply" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
                '<path d="M9 14 4 9l5-5"/><path d="M4 9h9a7 7 0 0 1 7 7v3"/>' +
            '</svg>' +
            '<span class="msg-swipe-label msg-swipe-label-reply">Ответить</span>' +
            '<svg class="msg-swipe-icon msg-swipe-icon-forward" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
                '<path d="M14 5h5v5"/><path d="m19 5-8 8"/><path d="M18 13v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>' +
            '</svg>' +
            '<span class="msg-swipe-label msg-swipe-label-forward">Переслать</span>';
        message.appendChild(indicator);
        return indicator;
    }

    function resetSwipe(swipe) {
        if (!swipe) return;
        swipe.message.classList.remove('is-swiping');
        swipe.message.classList.add('swipe-return');
        swipe.message.style.transform = '';
        swipe.indicator.classList.remove('is-visible', 'is-reply', 'is-forward');
        window.clearTimeout(swipe.message._swipeReturnTimer);
        swipe.message._swipeReturnTimer = window.setTimeout(function () {
            swipe.message.classList.remove('swipe-return');
        }, 220);
    }

    function updateSwipe(swipe, clientX) {
        const deltaX = clientX - swipe.x;
        const direction = deltaX < 0 ? 'reply' : 'forward';
        const distance = Math.min(Math.abs(deltaX), 112);
        const offset = Math.sign(deltaX) * Math.min(distance * 0.65, 76);
        swipe.message.style.transform = 'translateX(' + offset + 'px)';
        swipe.indicator.classList.toggle('is-reply', direction === 'reply');
        swipe.indicator.classList.toggle('is-forward', direction === 'forward');
        swipe.indicator.classList.toggle('is-visible', distance >= 38);
        swipe.direction = direction;
        swipe.distance = distance;
    }

    function selectedMessages() {
        return Array.from(chat.querySelectorAll('.chat-message.selected'));
    }

    // Своё, ещё не удалённое сообщение: только такие можно удалить у всех участников
    function isDeletable(message) {
        return message.dataset.isMine === '1' && !message.classList.contains('is-deleted');
    }

    function updateSelectionToolbar() {
        const selected = selectedMessages();
        const count = selected.length;
        chat.classList.toggle('is-selecting', count > 0);   // кружки слева видны только пока что-то выбрано
        chat.querySelectorAll('.msg-select').forEach(function (circle) {
            const message = circle.closest('.chat-message');
            circle.setAttribute('aria-pressed', message && message.classList.contains('selected') ? 'true' : 'false');
        });
        if (toolbar) {
            toolbar.hidden = count === 0;
            const countEl = document.getElementById('selectedMessageCount');
            if (countEl) countEl.textContent = String(count);
        }
    }

    function setSelected(message, selected) {
        if (!message) return;
        if (selected && message.classList.contains('is-deleted')) return;   // удалённые не выделяются
        message.classList.toggle('selected', selected);
        updateSelectionToolbar();
    }

    // Кружок слева у каждого сообщения: только для выделения
    function ensureSelectCircles() {
        chat.querySelectorAll('.chat-message').forEach(function (message) {
            if (message.querySelector(':scope > .msg-select')) return;
            const circle = document.createElement('button');
            circle.type = 'button';
            circle.className = 'msg-select';
            circle.setAttribute('aria-label', 'Выбрать сообщение');
            circle.setAttribute('aria-pressed', 'false');
            message.insertBefore(circle, message.firstChild);
        });
    }
    ensureSelectCircles();

    function api(action, data) {
        const token = csrfNow();
        const body = new URLSearchParams(data || {});
        body.set('csrf_token', token);
        // удаление у всех, отмена и удаление «у меня» обрабатываются в messages.php; остальные действия — как раньше в api/messages.php
        const endpoint = (action === 'delete' || action === 'restore' || action === 'hide') ? 'messages.php' : 'api/messages.php';
        return fetch(endpoint + '?api=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': token },
            body: body.toString()
        }).then(function (response) {
            return response.json().catch(function () { return { success: false }; }).then(function (result) {
                result = result || { success: false };
                if (!result.success) {
                    result.httpStatus = response.status;
                    console.error('messages api "' + action + '" failed:', response.status, result);
                }
                if (result.csrf_token) {   // сервер выдал новый токен — запоминаем
                    document.body.dataset.csrfToken = result.csrf_token;
                    document.querySelectorAll('input[name="csrf_token"]').forEach(function (input) { input.value = result.csrf_token; });
                }
                return result;
            });
        });
    }

    function copyMessage(message) {
        const text = (message && message.dataset.messageText) || '';
        if (!text) return Promise.resolve(false);
        const done = function () {
            if (message.classList) {
                message.classList.add('copied');
                setTimeout(function () { message.classList.remove('copied'); }, 900);
            }
            return true;
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text).then(done).catch(function () { return false; });
        }
        const area = document.createElement('textarea');
        area.value = text;
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        let ok = false;
        try { ok = document.execCommand('copy'); } catch (error) {}
        area.remove();
        return Promise.resolve(ok ? done() : false);
    }

    function startReply(message) {
        if (!message || !replyInput || !replyCompose) return;
        replyInput.value = message.dataset.messageId || '0';
        if (replyText) replyText.textContent = (message.dataset.messageText || 'Сообщение').slice(0, 120);
        replyCompose.hidden = false;
        replyInput.dispatchEvent(new Event('change', { bubbles: true }));
        const input = document.getElementById('messageInput');
        if (input) input.focus();
    }

    function clearReply() {
        if (replyInput) replyInput.value = '0';
        if (replyCompose) replyCompose.hidden = true;
        if (replyText) replyText.textContent = '';
    }

    function openForward(ids) {
        forwardMessageIds = (ids || []).filter(Boolean);
        if (forwardModal) {
            if (forwardSearch) forwardSearch.value = '';
            if (forwardList) {
                forwardList.querySelectorAll('.forward-dialog-item').forEach(function (item) {
                    item.hidden = false;
                });
                const empty = forwardList.querySelector('.forward-dialog-empty');
                if (empty) {
                    empty.textContent = 'Нет доступных чатов';
                    empty.hidden = forwardList.querySelectorAll('.forward-dialog-item').length > 0;
                }
            }
            forwardModal.hidden = false;
            if (forwardSearch) forwardSearch.focus();
        }
    }

    // Нужно окну просмотра фото (setupPhotoViewer лежит вне этого замыкания)
    window.openForwardForMessages = openForward;

    function closeForward() {
        forwardMessageIds = [];
        if (forwardModal) forwardModal.hidden = true;
    }

    if (forwardSearch && forwardList) {
        forwardSearch.addEventListener('input', function () {
            const query = forwardSearch.value.trim().toLocaleLowerCase();
            let visibleCount = 0;
            forwardList.querySelectorAll('.forward-dialog-item').forEach(function (item) {
                const name = item.querySelector('.forward-dialog-name');
                const matches = name && name.textContent.toLocaleLowerCase().includes(query);
                item.hidden = !matches;
                if (matches) visibleCount++;
            });
            const empty = forwardList.querySelector('.forward-dialog-empty');
            if (empty) {
                empty.textContent = query ? 'Ничего не найдено' : 'Нет доступных чатов';
                empty.hidden = visibleCount > 0;
            }
        });
        forwardSearch.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                event.preventDefault();
                closeForward();
            }
        });
    }

    function forwardTo(receiverId) {
        const ids = forwardMessageIds.slice();
        closeForward();
        return ids.reduce(function (promise, id) {
            return promise.then(function () {
                return api('forward', { msg_id: id, receiver_id: receiverId });
            });
        }, Promise.resolve()).then(function () {
            ids.forEach(function (id) {
                const message = Array.from(chat.querySelectorAll('.chat-message')).find(function (item) {
                    return item.dataset.messageId === String(id);
                });
                if (message) message.classList.add('forwarded');
            });
        });
    }

    // Табличка «Изменить сообщение» (вместо window.prompt). Enter сохраняет, Shift+Enter: новая строка, Esc: отмена.
    function askEditText(current) {
        return new Promise(function (resolve) {
            const overlay = document.createElement('div');
            overlay.className = 'delete-modal';
            overlay.setAttribute('role', 'dialog');
            overlay.setAttribute('aria-modal', 'true');
            overlay.setAttribute('aria-labelledby', 'editModalTitle');

            const card = document.createElement('div');
            card.className = 'delete-modal-card';
            const title = document.createElement('h3');
            title.id = 'editModalTitle';
            title.textContent = 'Изменить сообщение';

            const field = document.createElement('textarea');
            field.className = 'edit-modal-field';
            field.maxLength = 10000;
            field.rows = 4;
            field.value = current;
            field.setAttribute('aria-label', 'Текст сообщения');

            const actions = document.createElement('div');
            actions.className = 'delete-modal-actions';
            const saveButton = document.createElement('button');
            saveButton.type = 'button';
            saveButton.className = 'delete-btn-save';
            saveButton.textContent = 'Сохранить';
            const cancelButton = document.createElement('button');
            cancelButton.type = 'button';
            cancelButton.className = 'delete-btn-cancel';
            cancelButton.textContent = 'Отмена';
            actions.appendChild(saveButton);
            actions.appendChild(cancelButton);

            card.appendChild(title);
            card.appendChild(field);
            card.appendChild(actions);
            overlay.appendChild(card);
            document.body.appendChild(overlay);
            window.requestAnimationFrame(function () { overlay.classList.add('show'); });

            const canSave = function () {
                const value = field.value.trim();
                return value !== '' && value !== current.trim();
            };
            const refresh = function () { saveButton.disabled = !canSave(); };
            let closed = false;
            const close = function (result) {
                if (closed) return;
                closed = true;
                document.removeEventListener('keydown', onKey, true);
                overlay.classList.remove('show');
                window.setTimeout(function () { overlay.remove(); }, 160);
                resolve(result);
            };
            const save = function () { if (canSave()) close(field.value.trim()); };
            function onKey(event) {
                if (event.key === 'Escape') {
                    event.preventDefault();
                    event.stopPropagation();
                    close(null);
                } else if (event.key === 'Enter' && !event.shiftKey && event.target === field) {
                    event.preventDefault();
                    save();
                } else if (event.key === 'Tab') {                     // фокус остаётся внутри таблички
                    const order = [field, saveButton.disabled ? null : saveButton, cancelButton].filter(Boolean);
                    const index = order.indexOf(document.activeElement);
                    const next = event.shiftKey ? index - 1 : index + 1;
                    event.preventDefault();
                    order[(next + order.length) % order.length].focus();
                }
            }
            document.addEventListener('keydown', onKey, true);
            field.addEventListener('input', refresh);
            saveButton.addEventListener('click', save);
            cancelButton.addEventListener('click', function () { close(null); });
            overlay.addEventListener('mousedown', function (event) {
                if (event.target === overlay) close(null);
            });
            refresh();
            field.focus();
            field.setSelectionRange(field.value.length, field.value.length);
        });
    }

    function editMessage(message) {
        if (!message || message.dataset.isMine !== '1' || message.dataset.messageType !== 'text') return;
        const current = message.dataset.messageText || '';
        askEditText(current).then(function (next) {
            if (next === null || !next.trim() || next.trim() === current) return;
            applyEdit(message, next.trim());
        });
    }

    function applyEdit(message, next) {
        api('edit', { msg_id: message.dataset.messageId, message: next }).then(function (result) {
            if (!result.success) {
                showNotice('Не удалось изменить сообщение.');
                return;
            }
            message.dataset.messageText = result.message || next;
            const text = message.querySelector('.msg-text');
            if (text) {
                text.textContent = result.message || next;
                safeEmojiParse(text);
            }
            const meta = message.querySelector('.msg-meta-inline');
            if (meta && !meta.querySelector('.msg-edited-label')) {
                const label = document.createElement('span');
                label.className = 'msg-edited-label';
                label.textContent = 'изменено';
                meta.insertBefore(label, meta.firstChild);
            }
            message.classList.add('edited');
        });
    }

    // Заглушка «Сообщение удалено»: внутри пузыря кружок с падающей кометой, потом мини-грибок и «бум».
    // restorable: можно ли восстановить (только удаление у всех; «удалить у меня» не восстанавливается).
    function showDeletedPlaceholder(message, restorable) {
        message.dataset.messageText = '';
        message.classList.add('is-deleted');
        const content = message.querySelector('.msg-content');
        // Время отправки остаётся видно и у заглушки; берём его у сообщения, которое сейчас удаляем
        const existingTime = message.querySelector('.msg-time');
        const timeHtml = existingTime ? existingTime.outerHTML : '';
        if (content) content.innerHTML = '<div class="msg-bubble msg-deleted-text"><span class="msg-text">Сообщение удалено</span><span class="msg-meta-inline">' + timeHtml + '</span></div>';
        message.classList.remove('selected');
        updateSelectionToolbar();
        message.dataset.canRestore = restorable ? '1' : '0';
        startDeletedCountdown(message, DELETE_TTL, true);   // удаляем прямо сейчас: показываем всю анимацию
    }

    // Подтверждение делает табличка deleteWithDialog: здесь окон нет
    function deleteMessage(message) {
        if (!message || message.classList.contains('is-deleted')) return Promise.resolve(false);
        return api('delete', { msg_id: message.dataset.messageId }).then(function (result) {
            if (!result.success) {
                if (result.error && !/^[a-z_]+$/.test(result.error)) showNotice(result.error);   // понятная причина от сервера (например, «чужое сообщение»); технические коды не показываем
                return false;
            }
            showDeletedPlaceholder(message, true);   // 10 секунд можно восстановить
            return true;
        });
    }

    function restoreMessage(message) {
        if (!message || !message.classList.contains('is-deleted')) return Promise.resolve(false);
        return api('restore', { msg_id: message.dataset.messageId }).then(function (result) {
            if (!result.success) {
                showNotice('Не удалось восстановить сообщение: прошло больше ' + DELETE_TTL + ' секунд или текст не сохранился.');
                return false;
            }
            window.location.reload();
            return true;
        });
    }

    // ------------------------------------------------------------
    // Удалённое сообщение живёт DELETE_TTL секунд (по умолчанию 10): внутри пузыря летит комета
    // как таймер, потом пузырь растворяется и убирается из чата. Значение берётся из PHP
    // (DELETED_MESSAGE_TTL) через data-delete-ttl у <body>, сервер стирает запись в то же время.
    // ------------------------------------------------------------
    const DELETE_TTL = Math.max(1, Number.parseFloat(document.body.dataset.deleteTtl || '') || 10);

    function removeMessageNode(message) {
        const previous = message.previousElementSibling;
        const next = message.nextElementSibling;
        message.remove();
        // Если под этой датой больше нет сообщений, убираем и разделитель даты
        if (previous && previous.classList.contains('chat-date-divider') &&
            (!next || next.classList.contains('chat-date-divider'))) {
            previous.remove();
        }
        if (!chat.querySelector('.chat-message')) {
            chat.innerHTML = '<div class="empty-chat"><div class="empty-icon">💬</div><div>Нет сообщений. Напишите первым!</div></div>';
        }
    }

    // «Бум»: пузырь рассыпается на осколки, которые разлетаются от кружка с кометой
    function explodeDeletedMessage(message) {
        const bubble = message.querySelector('.msg-deleted-text');
        if (!bubble) return 0;
        const rand = function (min, max) { return min + Math.random() * (max - min); };
        const clamp = function (v, lo, hi) { return Math.max(lo, Math.min(hi, v)); };

        const msgRect = message.getBoundingClientRect();
        const b = bubble.getBoundingClientRect();
        const timer = bubble.querySelector('.msg-timer');
        const mushroom = bubble.querySelector('.msg-mushroom');
        const t = (mushroom || timer) ? (mushroom || timer).getBoundingClientRect() : b;
        const originX = (t.left + t.width / 2) - b.left;    // взрыв начинается из грибка
        const originY = (t.top + t.height / 2) - b.top;

        const layer = document.createElement('div');
        layer.className = 'msg-shatter';
        layer.setAttribute('aria-hidden', 'true');
        layer.style.left = (b.left - msgRect.left) + 'px';
        layer.style.top = (b.top - msgRect.top) + 'px';
        layer.style.width = b.width + 'px';
        layer.style.height = b.height + 'px';

        const cols = clamp(Math.round(b.width / 15), 4, 12);
        const rows = clamp(Math.round(b.height / 11), 2, 4);
        const cellW = b.width / cols;
        const cellH = b.height / rows;
        let longest = 0;

        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const shard = bubble.cloneNode(true);
                const cloneTimer = shard.querySelector('.msg-timer');
                if (cloneTimer) cloneTimer.remove();
                shard.classList.add('msg-shard');
                shard.style.position = 'absolute';
                shard.style.left = '0';
                shard.style.top = '0';
                shard.style.margin = '0';
                shard.style.boxSizing = 'border-box';
                shard.style.width = b.width + 'px';
                shard.style.height = b.height + 'px';
                shard.style.clipPath = 'inset(' + (r * cellH) + 'px ' + (b.width - (c + 1) * cellW) + 'px ' +
                    (b.height - (r + 1) * cellH) + 'px ' + (c * cellW) + 'px)';
                const centerX = c * cellW + cellW / 2;
                const centerY = r * cellH + cellH / 2;
                shard.style.transformOrigin = centerX + 'px ' + centerY + 'px';

                // Направление: от кружка наружу, плюс разброс и «гравитация» вниз
                let vx = centerX - originX;
                let vy = centerY - originY;
                const len = Math.hypot(vx, vy);
                if (len < 1) { const a = rand(0, Math.PI * 2); vx = Math.cos(a); vy = Math.sin(a); }
                else { vx /= len; vy /= len; }
                const dist = rand(26, 78);
                const dx = vx * dist + rand(-10, 10);
                const dy = vy * dist + rand(6, 34);
                const rot = rand(-95, 95);
                const duration = rand(650, 1000);
                longest = Math.max(longest, duration);

                shard.animate([
                    { transform: 'translate(0, 0) rotate(0deg) scale(1)', opacity: 1 },
                    { transform: 'translate(' + (dx * 0.55) + 'px, ' + (dy * 0.45) + 'px) rotate(' + (rot * 0.5) + 'deg) scale(.9)', opacity: 1, offset: 0.4 },
                    { transform: 'translate(' + dx + 'px, ' + dy + 'px) rotate(' + rot + 'deg) scale(.35)', opacity: 0 }
                ], { duration: duration, easing: 'cubic-bezier(.15,.7,.3,1)', fill: 'forwards' });
                layer.appendChild(shard);
            }
        }

        const boom = document.createElement('i');
        boom.className = 'msg-boom';
        boom.style.left = originX + 'px';
        boom.style.top = originY + 'px';
        layer.appendChild(boom);

        // Искры от взорвавшегося грибка
        for (let i = 0; i < 12; i++) {
            const spark = document.createElement('i');
            spark.className = 'msg-spark';
            spark.style.left = originX + 'px';
            spark.style.top = originY + 'px';
            const angle = rand(0, Math.PI * 2);
            const reach = rand(16, 40);
            spark.animate([
                { transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
                { transform: 'translate(calc(-50% + ' + (Math.cos(angle) * reach) + 'px), calc(-50% + ' + (Math.sin(angle) * reach + 6) + 'px)) scale(.2)', opacity: 0 }
            ], { duration: rand(300, 560), easing: 'cubic-bezier(.1,.7,.3,1)', fill: 'forwards' });
            layer.appendChild(spark);
        }

        message.appendChild(layer);
        bubble.style.visibility = 'hidden';
        return longest + 60;
    }

    // showBoom: полный «бум» с осколками — только для сообщения, удалённого прямо сейчас, у нас на глазах.
    // Сообщение, которое уже было удалено ДО открытия чата (пришло таким с сервера), при истечении
    // срока просто тихо убирается — «если удалено, значит удалено», без повторного взрыва при каждом F5.
    function vanishDeletedMessage(message, showBoom) {
        if (!message || !message.isConnected || message.classList.contains('is-vanishing')) return;
        message.classList.add('is-vanishing');
        message.dataset.canRestore = '0';

        const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (!showBoom || reduceMotion) {
            collapseMessage(message);
            return;
        }

        // 1) взрыв на осколки, 2) освободившееся место плавно схлопывается, 3) сообщение убирается
        const explosionTime = explodeDeletedMessage(message);
        window.setTimeout(function () { collapseMessage(message); }, explosionTime);
    }

    // Освободившееся место схлопывается, потом сообщение убирается из чата
    function collapseMessage(message) {
        if (!message || !message.isConnected) return;
        message.style.setProperty('--vanish-h', message.offsetHeight + 'px');
        message.style.setProperty('--vanish-mb', window.getComputedStyle(message).marginBottom);
        message.classList.add('is-collapsing');
        let finished = false;
        const finish = function () {
            if (finished) return;
            finished = true;
            if (message.isConnected) removeMessageNode(message);
        };
        message.addEventListener('animationend', function (event) {
            if (event.target === message) finish();
        });
        window.setTimeout(finish, 600);   // на случай, если animationend не придёт
    }

    function hideMessageForMe(message) {
        if (!message || message.classList.contains('is-deleted')) return Promise.resolve(false);
        return api('hide', { msg_id: message.dataset.messageId }).then(function (result) {
            if (!result.success) {
                showVoiceNotice('Не удалось удалить сообщение у вас. Обновите страницу и попробуйте ещё раз.');
                return false;
            }
            showDeletedPlaceholder(message, false);   // та же анимация: комета, грибок, «бум»
            return true;
        });
    }

    // ------------------------------------------------------------
    // Табличка «Удалить сообщение?»: у меня / у всех / отмена
    // «У всех» доступно только для своих сообщений.
    // ------------------------------------------------------------
    function askDeleteMode(messages) {
        return new Promise(function (resolve) {
            const total = messages.length;
            const own = messages.filter(isDeletable).length;

            const overlay = document.createElement('div');
            overlay.className = 'delete-modal';
            overlay.setAttribute('role', 'dialog');
            overlay.setAttribute('aria-modal', 'true');
            overlay.setAttribute('aria-labelledby', 'deleteModalTitle');

            const card = document.createElement('div');
            card.className = 'delete-modal-card';

            const title = document.createElement('h3');
            title.id = 'deleteModalTitle';
            title.textContent = total === 1 ? 'Удалить сообщение?' : 'Удалить сообщения (' + total + ')?';

            const text = document.createElement('p');
            const noun = total === 1 ? 'Сообщение' : 'Сообщения';
            if (own === total) {
                text.textContent = noun + ' можно удалить только у себя или у всех участников диалога. ' +
                    'У всех удалённое можно восстановить в течение ' + DELETE_TTL + ' секунд.';
            } else if (own === 0) {
                text.textContent = (total === 1 ? 'Чужое сообщение' : 'Чужие сообщения') +
                    ' можно удалить только у себя: у собеседника ' + (total === 1 ? 'оно останется.' : 'они останутся.');
            } else {
                text.textContent = 'У всех можно удалить только свои сообщения (' + own + ' из ' + total + '). ' +
                    'Остальные удалятся только у вас.';
            }

            const actions = document.createElement('div');
            actions.className = 'delete-modal-actions';

            const makeButton = function (className, label) {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = className;
                button.textContent = label;
                actions.appendChild(button);
                return button;
            };
            const meButton = makeButton('delete-btn-me', total > 1 ? 'Удалить у меня (' + total + ')' : 'Удалить у меня');
            const allButton = own > 0
                ? makeButton('delete-btn-all', own === total ? 'Удалить у всех' : 'Удалить у всех (' + own + ')')
                : null;
            const cancelButton = makeButton('delete-btn-cancel', 'Отмена');

            card.appendChild(title);
            card.appendChild(text);
            card.appendChild(actions);
            overlay.appendChild(card);
            document.body.appendChild(overlay);
            window.requestAnimationFrame(function () { overlay.classList.add('show'); });

            let closed = false;
            const buttons = [meButton, allButton, cancelButton].filter(Boolean);
            const close = function (result) {
                if (closed) return;
                closed = true;
                document.removeEventListener('keydown', onKey, true);
                overlay.classList.remove('show');
                window.setTimeout(function () { overlay.remove(); }, 160);
                resolve(result);
            };
            function onKey(event) {
                if (event.key === 'Escape') {
                    event.preventDefault();
                    event.stopPropagation();
                    close(null);
                } else if (event.key === 'Tab') {                     // фокус остаётся внутри таблички
                    const index = buttons.indexOf(document.activeElement);
                    const next = event.shiftKey ? index - 1 : index + 1;
                    event.preventDefault();
                    buttons[(next + buttons.length) % buttons.length].focus();
                }
            }
            document.addEventListener('keydown', onKey, true);

            meButton.addEventListener('click', function () { close('me'); });
            if (allButton) allButton.addEventListener('click', function () { close('all'); });
            cancelButton.addEventListener('click', function () { close(null); });
            overlay.addEventListener('mousedown', function (event) {
                if (event.target === overlay) close(null);
            });
            meButton.focus();
        });
    }

    function performDelete(messages, mode) {
        const targets = messages.filter(function (message) { return !message.classList.contains('is-deleted'); });
        const list = mode === 'all' ? targets.filter(isDeletable) : targets;
        const action = mode === 'all'
            ? function (message) { return deleteMessage(message); }
            : hideMessageForMe;
        return list.reduce(function (promise, message) {
            return promise.then(function () { return action(message); });
        }, Promise.resolve()).then(function () {
            messages.forEach(function (message) { setSelected(message, false); });   // выбор снимается, кружки исчезают
        });
    }

    function deleteWithDialog(messages) {
        const list = messages.filter(function (message) {
            return message && message.isConnected && !message.classList.contains('is-deleted');
        });
        if (!list.length) return;
        askDeleteMode(list).then(function (mode) {
            if (mode) performDelete(list, mode);
        });
    }

    // remaining: сколько секунд осталось жить заглушке.
    // live: true — сообщение удалили сейчас, у нас на глазах (видно кольцо, комету, потом взрыв).
    //       false — сообщение уже было удалено до открытия чата (пришло таким с сервера при загрузке
    //       или после F5): никакой анимации, просто текст «Сообщение удалено», а по истечении срока
    //       оно тихо убирается, без повторного «удаления».
    function startDeletedCountdown(message, remaining, live) {
        if (!message || !message.classList.contains('is-deleted') || message.classList.contains('is-vanishing')) return;
        const left = Math.max(0, Math.min(DELETE_TTL, Number.isFinite(remaining) ? remaining : DELETE_TTL));

        const bubble = message.querySelector('.msg-deleted-text');
        if (live && bubble && !bubble.querySelector('.msg-timer')) {
            // Кружок справа: кольцо заполняется, а внутри вниз летит комета
            const timer = document.createElement('span');
            timer.className = 'msg-timer';
            timer.setAttribute('aria-hidden', 'true');
            timer.style.setProperty('--ttl', DELETE_TTL + 's');
            timer.style.setProperty('--elapsed', '-' + (DELETE_TTL - left).toFixed(2) + 's');   // если часть времени уже прошла (F5)
            const sky = document.createElement('span');     // внутренний круг: всё внутри обрезано по нему
            sky.className = 'msg-timer-sky';
            const comet = document.createElement('i');
            comet.className = 'msg-comet';
            const mushroom = document.createElement('i');   // мини-грибок на месте падения кометы
            mushroom.className = 'msg-mushroom';
            sky.appendChild(comet);
            sky.appendChild(mushroom);
            timer.appendChild(sky);
            bubble.appendChild(timer);
        }

        window.clearTimeout(message._deleteTimer);
        message._deleteTimer = window.setTimeout(function () {
            vanishDeletedMessage(message, live);
        }, left * 1000);
    }

    // Сообщения, которые уже были удалены до открытия чата (пришли такими с сервера: обычная
    // загрузка страницы или F5 в эти 10 секунд). Показываем их СТАТИЧНО, без кольца и кометы —
    // само удаление уже произошло раньше, повторно проигрывать анимацию незачем.
    function scheduleDeletedMessageRemoval(message) {
        if (!message || !message.classList.contains('is-deleted')) return;
        // Остаток времени считает сервер (часовые пояса браузера и MySQL могут не совпадать)
        const remaining = Number.parseFloat(message.dataset.deleteRemaining || '');
        startDeletedCountdown(message, Number.isFinite(remaining) ? remaining : DELETE_TTL, false);
    }

    chat.querySelectorAll('.chat-message.is-deleted').forEach(scheduleDeletedMessageRemoval);

    function runAction(action, message) {
        if (!message) return;
        activeMessage = message;
        if (action === 'reply') startReply(message);
        if (action === 'copy') copyMessage(message);
        if (action === 'forward') openForward([message.dataset.messageId]);
        if (action === 'delete') deleteWithDialog([message]);
        if (action === 'edit') editMessage(message);
        if (action === 'restore') restoreMessage(message);
        if (action === 'select') setSelected(message, !message.classList.contains('selected'));
        if (context) context.hidden = true;
    }

    chat.addEventListener('pointerdown', function (event) {
        if (event.pointerType !== 'touch' || event.button !== 0) return;
        const message = event.target.closest('.chat-message');
        if (
            !message
            || message.classList.contains('is-deleted')
            || event.target.closest('a, button, input, textarea, select, video, audio, .waveform, [data-message-action]')
        ) {
            return;
        }

        clearPendingLongPress();
        clearSuppressedLongPressClick();
        message.classList.remove('swipe-return');
        window.clearTimeout(message._swipeReturnTimer);

        const press = {
            message: message,
            pointerId: event.pointerId,
            x: event.clientX,
            y: event.clientY,
            target: event.target,
            timer: 0
        };
        press.timer = window.setTimeout(function () {
            if (pendingLongPress !== press) return;
            pendingLongPress = null;
            activeMessage = message;
            setSelected(message, !message.classList.contains('selected'));
            suppressedLongPressClick = {
                message: message,
                timer: window.setTimeout(clearSuppressedLongPressClick, 900)
            };
        }, 500);
        pendingLongPress = press;
    });

    document.addEventListener('pointermove', function (event) {
        if (activeSwipe && event.pointerId === activeSwipe.pointerId) {
            event.preventDefault();
            updateSwipe(activeSwipe, event.clientX);
            return;
        }

        if (!pendingLongPress || event.pointerId !== pendingLongPress.pointerId) return;
        const deltaX = event.clientX - pendingLongPress.x;
        const deltaY = event.clientY - pendingLongPress.y;
        const distance = Math.hypot(deltaX, deltaY);
        if (distance > 18) {
            const press = pendingLongPress;
            clearPendingLongPress();
            if (Math.abs(deltaX) > Math.abs(deltaY) * 1.2) {
                const message = press.message;
                const pointerId = event.pointerId;
                if (message && !message.classList.contains('is-deleted') && !chat.classList.contains('is-selecting')) {
                    activeSwipe = {
                        message: message,
                        pointerId: pointerId,
                        x: event.clientX - deltaX,
                        y: event.clientY - deltaY,
                        indicator: ensureSwipeIndicator(message),
                        direction: '',
                        distance: 0
                    };
                    message.classList.add('is-swiping');
                    event.preventDefault();
                    updateSwipe(activeSwipe, event.clientX);
                }
            }
        }
    });

    document.addEventListener('pointerup', function (event) {
        if (pendingLongPress && event.pointerId === pendingLongPress.pointerId) {
            clearPendingLongPress();
        }
        if (!activeSwipe || event.pointerId !== activeSwipe.pointerId) return;

        const swipe = activeSwipe;
        activeSwipe = null;
        const shouldRunAction = swipe.distance >= 72 && swipe.direction;
        resetSwipe(swipe);
        if (!shouldRunAction) return;

        clearSuppressedLongPressClick();
        suppressedLongPressClick = {
            message: swipe.message,
            timer: window.setTimeout(clearSuppressedLongPressClick, 900)
        };
        if (swipe.direction === 'reply') {
            startReply(swipe.message);
        } else {
            openForward([swipe.message.dataset.messageId]);
        }
    });

    document.addEventListener('pointercancel', function (event) {
        if (pendingLongPress && event.pointerId === pendingLongPress.pointerId) {
            clearPendingLongPress();
        }
        if (activeSwipe && event.pointerId === activeSwipe.pointerId) {
            const swipe = activeSwipe;
            activeSwipe = null;
            resetSwipe(swipe);
        }
    });

    function updateContextMenuVisibility(message) {
        if (!context || !message) return;
        const isMine = message.dataset.isMine === '1';
        const isDeleted = message.classList.contains('is-deleted');
        const canRestore = message.dataset.canRestore === '1';

        context.querySelectorAll('[data-context-action="delete"]').forEach(function (menuButton) {
            menuButton.hidden = isDeleted || message.classList.contains('selected');
        });
        context.querySelectorAll('[data-context-action="restore"]').forEach(function (menuButton) {
            menuButton.hidden = !isDeleted || !canRestore;
        });
    }

    function openMessageContextMenu(message, x, y) {
        if (!message || !context) return;
        activeMessage = message;
        context.hidden = false;
        context.style.left = Math.max(0, Math.min(x, window.innerWidth - 190)) + 'px';
        context.style.top = Math.max(0, Math.min(y, window.innerHeight - 260)) + 'px';
        updateContextMenuVisibility(message);
    }

    chat.addEventListener('click', function (event) {
        if (event.button !== 0) return;
        const clickedMessage = event.target.closest('.chat-message');
        if (suppressedLongPressClick && clickedMessage === suppressedLongPressClick.message) {
            event.preventDefault();
            event.stopPropagation();
            clearSuppressedLongPressClick();
            return;
        }
        // Кружок слева: выбрать / снять выбор
        const circle = event.target.closest('.msg-select');
        if (circle) {
            event.preventDefault();
            event.stopPropagation();
            const target = circle.closest('.chat-message');
            if (target) setSelected(target, !target.classList.contains('selected'));
            return;
        }
        // В режиме выбора клик по сообщению добавляет его в выделение.
        const clicked = event.target.closest('.chat-message');
        if (clicked && chat.classList.contains('is-selecting') &&
            !event.target.closest('.waveform, .voice-play, video, audio, [data-message-action]')) {
            event.preventDefault();
            if (!clicked.classList.contains('is-deleted')) setSelected(clicked, !clicked.classList.contains('selected'));
            return;
        }
        const button = event.target.closest('[data-message-action]');
        if (button) {
            event.preventDefault();
            event.stopPropagation();
            runAction(button.dataset.messageAction, button.closest('.chat-message'));
            return;
        }
        const message = event.target.closest('.chat-message');
        if (!message || !context || event.target.closest('a, button, input, video, audio, .waveform')) return;
        event.preventDefault();
        if (event.detail >= 2) return;

        const isDesktop = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;
        if (isDesktop) {
            clearPendingDesktopReply();
            pendingDesktopReply = {
                message: message,
                timer: window.setTimeout(function () {
                    const target = pendingDesktopReply && pendingDesktopReply.message;
                    pendingDesktopReply = null;
                    if (target && !target.classList.contains('is-deleted')) startReply(target);
                }, 450)
            };
            return;
        }
    });
    chat.addEventListener('dblclick', function (event) {
        if (event.target.closest('a, button, input, video, audio, .waveform, [data-message-action]')) return;
        const message = event.target.closest('.chat-message');
        if (!message || message.classList.contains('is-deleted')) return;
        event.preventDefault();
        const isDesktop = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;
        if (!isDesktop) {
            clearSuppressedLongPressClick();
            openMessageContextMenu(message, event.clientX, event.clientY);
            return;
        }
        clearPendingDesktopReply();
        setSelected(message, true);
    });

    chat.addEventListener('contextmenu', function (event) {
        const message = event.target.closest('.chat-message');
        if (!message || !context) return;
        const isTouchDevice = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
        if (isTouchDevice) {
            event.preventDefault();
            context.hidden = true;
            return;
        }
        if (
            (pendingLongPress && pendingLongPress.message === message)
            || (suppressedLongPressClick && suppressedLongPressClick.message === message)
        ) {
            event.preventDefault();
            return;
        }
        event.preventDefault();
        openMessageContextMenu(message, event.clientX, event.clientY);
    });
    if (context) {
        context.addEventListener('click', function (event) {
            const button = event.target.closest('[data-context-action]');
            if (button) runAction(button.dataset.contextAction, activeMessage);
        });
    }
    document.addEventListener('click', function (event) {
        if (context && !event.target.closest('#messageContextMenu')) context.hidden = true;
    });
    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape' || !chat.classList.contains('is-selecting')) return;
        selectedMessages().forEach(function (message) { setSelected(message, false); });
    });

    document.querySelectorAll('[data-selection-action]').forEach(function (button) {
        button.addEventListener('click', function () {
            const action = button.dataset.selectionAction;
            const messages = selectedMessages();
            if (action === 'clear') {
                messages.forEach(function (message) { setSelected(message, false); });
            } else if (action === 'copy') {
                copyMessage({ dataset: { messageText: messages.map(function (m) { return m.dataset.messageText || ''; }).filter(Boolean).join('\n') } });
            } else if (action === 'forward') {
                openForward(messages.map(function (m) { return m.dataset.messageId; }));
            } else if (action === 'unread') {
                Promise.all(messages.map(function (m) {
                    return api('mark_unread', { msg_id: m.dataset.messageId });
                })).then(function () {
                    messages.forEach(function (m) {
                        m.dataset.isRead = '0';
                        m.classList.add('has-unread-status');
                    });
                });
            } else if (action === 'delete') {
                deleteWithDialog(messages);   // табличка: у меня / у всех
            }
        });
    });

    document.querySelectorAll('.forward-dialog-item').forEach(function (button) {
        button.addEventListener('click', function () { forwardTo(button.dataset.forwardUser); });
    });
    const cancelForward = document.getElementById('cancelForwardBtn');
    if (cancelForward) cancelForward.addEventListener('click', closeForward);
    if (closeForwardButton) closeForwardButton.addEventListener('click', closeForward);
    if (forwardModal) forwardModal.addEventListener('click', function (event) {
        if (event.target === forwardModal) closeForward();
    });
    const cancelReply = document.getElementById('cancelReplyBtn');
    if (cancelReply) cancelReply.addEventListener('click', clearReply);

    const notifyButton = document.getElementById('dialogNotifyBtn');
    if (notifyButton) {
        notifyButton.addEventListener('click', function () {
            const dialog = document.querySelector('.dialog-item.active');
            if (!dialog) return;
            api('mute', { dialog: dialog.dataset.dialogId }).then(function (result) {
                if (!result.success) return;
                notifyButton.dataset.muted = result.muted ? '1' : '0';
                notifyButton.classList.toggle('muted', result.muted);
                notifyButton.textContent = result.muted ? '🔕' : '🔔';
                notifyButton.title = result.muted ? 'Включить уведомления' : 'Выключить уведомления';
            });
        });
    }
}

// Экспортируем в window для inline onclick / onkeyup
window.openSearchModal  = openSearchModal;
window.closeSearchModal = closeSearchModal;
window.searchUsers      = searchUsers;

(() => {
    const userId = document.body.dataset.userId || 'guest';
    const storageKey = 'playerchat:ui:' + userId;
    const transientClass = /drag|resiz|hover|focus|pressed|loading/i;
    const targets = {
        body: { el: document.body },
        layout: { el: document.querySelector('.layout') },
        nav: { el: document.getElementById('site-navigator') },
        handle: { el: document.getElementById('handleBtn') },
        messages: { el: document.getElementById('messagesLayout'), styled: true },
        sidebar: { el: document.getElementById('dialogsSidebar'), styled: true }
    };

    function loadState() {
        try {
            const value = localStorage.getItem(storageKey);
            return value ? JSON.parse(value) : {};
        } catch (error) {
            return {};
        }
    }

    function saveState(state) {
        try {
            localStorage.setItem(storageKey, JSON.stringify(state));
        } catch (error) {
            return;
        }
    }

    Object.values(targets).forEach(function (target) {
        if (!target.el) return;
        target.baseClasses = new Set(
            Array.from(target.el.classList).filter(function (className) {
                return !transientClass.test(className);
            })
        );
    });

    const saved = loadState();
    Object.entries(targets).forEach(function (entry) {
        const name = entry[0];
        const target = entry[1];
        const state = saved[name];
        if (!target.el || !state) return;

        (state.remove || []).forEach(function (className) {
            target.el.classList.remove(className);
        });
        (state.add || []).forEach(function (className) {
            target.el.classList.add(className);
        });
        if (target.styled && typeof state.style === 'string') {
            if (state.style) {
                target.el.setAttribute('style', state.style);
            } else {
                target.el.removeAttribute('style');
            }
        }
    });

    if (targets.nav.el && typeof saved.navScroll === 'number') {
        targets.nav.el.scrollLeft = saved.navScroll;
    }

    function snapshot() {
        const state = {};
        Object.entries(targets).forEach(function (entry) {
            const name = entry[0];
            const target = entry[1];
            if (!target.el) return;

            const currentClasses = new Set(
                Array.from(target.el.classList).filter(function (className) {
                    return !transientClass.test(className);
                })
            );
            state[name] = {
                add: Array.from(currentClasses).filter(function (className) {
                    return !target.baseClasses.has(className);
                }),
                remove: Array.from(target.baseClasses).filter(function (className) {
                    return !currentClasses.has(className);
                })
            };
            if (target.styled) {
                state[name].style = target.el.getAttribute('style') || '';
            }
        });
        if (targets.nav.el) {
            state.navScroll = Math.round(targets.nav.el.scrollLeft);
        }
        return state;
    }

    let saveTimer = null;
    function scheduleSave() {
        window.clearTimeout(saveTimer);
        saveTimer = window.setTimeout(function () {
            saveState(snapshot());
        }, 150);
    }

    const observer = new MutationObserver(scheduleSave);
    Object.values(targets).forEach(function (target) {
        if (!target.el) return;
        observer.observe(target.el, {
            attributes: true,
            attributeFilter: target.styled ? ['class', 'style'] : ['class']
        });
    });
    if (targets.nav.el) {
        targets.nav.el.addEventListener('scroll', scheduleSave, { passive: true });
    }
    window.addEventListener('pagehide', function () {
        saveState(snapshot());
    });
})();

(() => {
    'use strict';

    const LAT = 50.11;
    const LON = 8.68;
    const COMPARISON_TIMEZONE = 'UTC';
    const DAY_START_MINUTES = 7 * 60;
    const NIGHT_START_MINUTES = 19 * 60 + 30;
    const header = document.querySelector('.header');
    const body = document.body;
    if (!header || !body) return;
    body.dataset.comparisonTimezone = COMPARISON_TIMEZONE;

    const RAD = Math.PI / 180;
    const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
    const lerp = (a, b, t) => a + (b - a) * t;
    const mix = (a, b, t) => a.map((value, index) => Math.round(lerp(value, b[index], t)));
    document.querySelectorAll('.sky-layer, .sky-times').forEach(element => element.remove());
    document.querySelectorAll('.header-shooting-stars > .sky-cloud, .header-shooting-stars > .sky-rain, .header-shooting-stars > .sky-snow, .header-shooting-stars > .sky-fog, .header-shooting-stars > .sky-flash').forEach(element => element.remove());
    function sunState(date) {
        const n = date.getTime() / 86400000 + 2440587.5 - 2451545;
        const longitude = (280.460 + .9856474 * n) * RAD;
        const anomaly = (357.528 + .9856003 * n) * RAD;
        const lambda = (280.460 + .9856474 * n + 1.915 * Math.sin(anomaly) + .020 * Math.sin(2 * anomaly)) * RAD;
        const dec = Math.asin(Math.sin(23.439 * RAD) * Math.sin(lambda));
        const ra = Math.atan2(Math.cos(23.439 * RAD) * Math.sin(lambda), Math.cos(lambda));
        const gmst = (((18.697374558 + 24.06570982441908 * n) % 24) + 24) % 24;
        const hourAngle = Math.atan2(Math.sin((gmst * 15 + LON) * RAD - ra), Math.cos((gmst * 15 + LON) * RAD - ra));
        return { dec, hourAngle, longitude };
    }
    const elevation = (hourAngle, dec) => Math.asin(Math.sin(LAT * RAD) * Math.sin(dec) + Math.cos(LAT * RAD) * Math.cos(dec) * Math.cos(hourAngle)) / RAD;
    const halfArc = dec => Math.acos(clamp(-Math.tan(LAT * RAD) * Math.tan(dec), -1, 1));
    const bodyY = (elev, maxElev, height) => lerp(height + 8, height * .2, Math.sqrt(clamp((elev + 4) / (maxElev + 4), 0, 1)));
    const stops = [
        [-18, [5, 8, 20], [10, 18, 48]], [-12, [10, 16, 42], [26, 36, 82]],
        [-6, [34, 38, 96], [150, 70, 110]], [-1, [70, 80, 150], [255, 110, 60]],
        [5, [80, 125, 195], [255, 175, 95]], [15, [58, 128, 215], [150, 205, 245]],
        [40, [40, 110, 210], [130, 195, 245]]
    ];
    function skyColors(elev) {
        if (elev <= stops[0][0]) return [stops[0][1], stops[0][2]];
        for (let i = 0; i < stops.length - 1; i += 1) {
            if (elev <= stops[i + 1][0]) {
                const t = (elev - stops[i][0]) / (stops[i + 1][0] - stops[i][0]);
                return [mix(stops[i][1], stops[i + 1][1], t), mix(stops[i][2], stops[i + 1][2], t)];
            }
        }
        return [stops[stops.length - 1][1], stops[stops.length - 1][2]];
    }

    let timesCache = { key: '', value: { rise: null, set: null } };
    function solarTimes(date) {
        const key = date.toISOString().slice(0, 10);
        if (timesCache.key === key) return timesCache.value;
        const start = new Date(date);
        start.setUTCHours(0, 0, 0, 0);
        let previous = null;
        let rise = null;
        let set = null;
        for (let minutes = 0; minutes <= 1500; minutes += 4) {
            const time = start.getTime() + minutes * 60000;
            const state = sunState(new Date(time));
            const value = elevation(state.hourAngle, state.dec) + .833;
            if (previous && previous.value * value < 0) {
                const crossing = previous.time + previous.value / (previous.value - value) * (time - previous.time);
                if (value > 0 && rise === null) rise = new Date(crossing);
                if (value < 0 && set === null) set = new Date(crossing);
            }
            previous = { time, value };
        }
        timesCache = { key, value: { rise, set } };
        return timesCache.value;
    }

    const formatTime = date => date ? date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', hour12: false }) : '—';
    let previewDate = null;
    let previewing = false;
    function applyTheme(date) {
        if (body.dataset.themeMode !== 'auto') return;
        const current = body.dataset.theme;
        const minutes = date.getHours() * 60 + date.getMinutes();
        const next = minutes >= DAY_START_MINUTES && minutes < NIGHT_START_MINUTES
            ? 'light'
            : 'dark';
        if (next !== current) {
            window.runThemeTransition(() => { body.dataset.theme = next; });
        }
        if (!previewing) {
            try {
                localStorage.setItem('pc:autotheme', next);
                localStorage.setItem('pc:theme-mode', 'auto');
            } catch (error) {}
        }
    }

    function update() {
        const date = previewDate || new Date();
        const state = sunState(date);
        const elev = elevation(state.hourAngle, state.dec);
        const isNight = elev <= -1;
        const isTwilight = elev < 8;
        const phase = isNight
            ? 'night'
            : isTwilight && state.hourAngle < 0
                ? 'sunrise'
                : isTwilight
                    ? 'sunset'
                    : 'day';
        body.dataset.sunPhase = phase;
        const sun = document.querySelector('.logo .light-theme-sun');
        if (sun) {
            sun.style.setProperty('--sun-opacity', String(clamp((elev + 2) / 4, 0, 1)));
            sun.style.setProperty('--sun-scale', (1 + clamp((8 - elev) / 40, 0, .08)).toFixed(3));
        }
        applyTheme(date);
    }

    update();
    window.setInterval(update, 30000);
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') update();
    });
    window.addEventListener('resize', update);
    window.skyPreview = function (value) {
        if (!value) { previewDate = null; previewing = false; return update(); }
        const solar = solarTimes(new Date());
        if (value === 'sunrise' || value === 'sunset') {
            const base = value === 'sunrise' ? solar.rise : solar.set;
            previewDate = base ? new Date(base.getTime() + (value === 'sunrise' ? 8 : -8) * 60000) : null;
        } else {
            const parts = String(value).split(':').map(Number);
            previewDate = new Date();
            previewDate.setUTCHours(parts[0] || 0, parts[1] || 0, 0, 0);
        }
        previewing = true;
        update();
    };
})();

// ============================================================
// КАПЧА: отдельное окно. Показывается, когда сервер требует код
// (форма помечена data-captcha="1"). Сообщение уходит только после ввода кода.
// ============================================================
(function () {
    let modal = null;
    let bypass = false;      // повторная отправка формы уже с кодом
    let pendingForm = null;

    function build() {
        if (modal) return modal;
        modal = document.createElement('div');
        modal.className = 'captcha-modal';
        modal.id = 'captchaModal';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'captchaTitle');
        modal.innerHTML =
            '<div class="captcha-dialog">' +
                '<div class="captcha-title" id="captchaTitle">Проверка безопасности</div>' +
                '<div class="captcha-text">Вы отправляете сообщения слишком часто. ' +
                    'Введите код с картинки — английские буквы и цифры.</div>' +
                '<div class="captcha-image-row">' +
                    '<img class="captcha-img" id="captchaImg" width="230" height="76" alt="CAPTCHA" draggable="false">' +
                    '<button type="button" class="captcha-refresh" id="captchaRefresh" title="Другой код" aria-label="Другой код">↻</button>' +
                '</div>' +
                '<input type="text" class="captcha-input" id="captchaInput" maxlength="5" ' +
                    'autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Enter code">' +
                '<div class="captcha-error" id="captchaError" hidden></div>' +
                '<div class="captcha-actions">' +
                    '<button type="button" class="captcha-btn captcha-btn-cancel" id="captchaCancel">Отмена</button>' +
                    '<button type="button" class="captcha-btn captcha-btn-ok" id="captchaOk">Подтвердить</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(modal);

        const input = modal.querySelector('#captchaInput');
        input.addEventListener('input', function () {
            input.value = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
            input.classList.remove('invalid');
            showError('');
        });
        input.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); confirm(); }
        });
        modal.querySelector('#captchaRefresh').addEventListener('click', reload);
        modal.querySelector('#captchaCancel').addEventListener('click', close);
        modal.querySelector('#captchaOk').addEventListener('click', confirm);
        modal.addEventListener('mousedown', function (e) { if (e.target === modal) close(); });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && modal.classList.contains('active')) close();
        });
        return modal;
    }

    function showError(text) {
        const el = document.getElementById('captchaError');
        if (!el) return;
        el.textContent = text;
        el.hidden = !text;
    }

    function reload() {
        const img = document.getElementById('captchaImg');
        const input = document.getElementById('captchaInput');
        if (img) img.src = 'api/messages.php?api=captcha&t=' + Date.now();
        if (input) { input.value = ''; input.classList.remove('invalid'); input.focus(); }
    }

    function open(form, errorText) {
        build();
        pendingForm = form || document.getElementById('chatForm');
        modal.classList.add('active');
        showError(errorText || '');
        reload();
    }

    function close() {
        if (modal) modal.classList.remove('active');
        pendingForm = null;
    }

    function confirm() {
        const input = document.getElementById('captchaInput');
        const form = pendingForm || document.getElementById('chatForm');
        const code = input ? input.value.trim() : '';
        if (code.length < 5) {
            if (input) { input.classList.add('invalid'); input.focus(); }
            showError('Введите все 5 символов');
            return;
        }
        const hidden = form && form.querySelector('#captchaCode');
        if (!form || !hidden) { close(); return; }
        hidden.value = code;
        close();
        bypass = true;
        if (typeof form.requestSubmit === 'function') form.requestSubmit();
        else form.submit();
    }

    // Отправка сообщения без перезагрузки страницы (+ окно капчи, если сервер её требует)
    let sending = false;

    async function sendViaAjax(form) {
        if (sending) return;

        const input = form.querySelector('#messageInput');
        const hasText = !!(input && input.value.trim());
        const hasFile = ['photoInput', 'videoInput', 'voiceFileInput'].some(function (id) {
            const f = form.querySelector('#' + id);
            return f && f.files && f.files.length > 0;
        });
        if (!hasText && !hasFile) return; // пустое сообщение — ничего не делаем

        sending = true;
        form.classList.add('is-sending');
        const userId = document.body.dataset.userId || '0';
        const dialogId = document.body.dataset.dialogId || '0';
        let response;
        try {
            response = await fetch(form.action || window.location.href, {
                method: 'POST',
                body: new FormData(form),
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
        } catch (networkError) {
            // запрос вообще не дошёл до сервера — только тогда отправляем обычным способом
            console.error('Не удалось отправить без перезагрузки, отправляю обычным способом:', networkError);
            sending = false;
            form.classList.remove('is-sending');
            HTMLFormElement.prototype.submit.call(form);
            return;
        }

        try {
            const finalUrl = response.url || window.location.href;
            const html = await response.text();
            if (!response.ok) {
                // сервер ответил ошибкой (например, 429): показываем его страницу ошибки, но форму НЕ отправляем повторно —
                // иначе сообщение, которое уже дошло, ушло бы второй раз и упёрлось бы в лимит «1 сообщение в секунду»
                sending = false;
                form.classList.remove('is-sending');
                document.open();
                document.write(html);
                document.close();
                return;
            }
            const failed = /[?&]error=/.test(finalUrl);

            if (!failed) {
                // сообщение ушло: стираем черновик и позицию прокрутки, чтобы чат ушёл вниз
                try {
                    localStorage.removeItem('messages-draft:v2:' + userId + ':' + dialogId);
                    localStorage.removeItem('messages-scroll:' + userId + ':' + dialogId);
                } catch (error) {}
            }
            window.history.replaceState({}, '', finalUrl);
            applyMessagesHtml(html, finalUrl, false);

            const nextInput = document.getElementById('messageInput');
            if (nextInput && !failed) nextInput.focus({ preventScroll: true });
        } catch (error) {
            // сообщение уже ушло, сломалась только отрисовка: просто перезагружаем чат обычным GET-запросом
            console.error('Сообщение отправлено, но чат не удалось обновить без перезагрузки:', error);
            sending = false;
            form.classList.remove('is-sending');
            window.location.assign(window.location.href);
            return;
        }
        sending = false;
    }

    document.addEventListener('submit', function (event) {
        const form = event.target;
        if (!form || form.id !== 'chatForm') return;

        // идёт запись голоса — отправку блокирует существующая защита
        if (typeof isRecording !== 'undefined' && isRecording) {
            event.preventDefault();
            event.stopImmediatePropagation();
            return;
        }

        event.preventDefault();
        event.stopImmediatePropagation();

        if (form.dataset.captcha === '1' && !bypass) {
            open(form, '');
            return;
        }
        bypass = false;
        sendViaAjax(form);
    }, true);

    // Сервер вернул диалог после ошибки капчи — сразу показываем окно
    function openIfNeeded() {
        const form = document.getElementById('chatForm');
        if (!form || form.dataset.captcha !== '1' || form.dataset.captchaOpen !== '1') return;
        form.dataset.captchaOpen = '0';
        open(form, form.dataset.captchaError === 'wrong' ? 'Неверный код. Попробуйте ещё раз' : '');
    }
    window.captchaOpenIfNeeded = openIfNeeded;
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', openIfNeeded);
    } else {
        openIfNeeded();
    }
})();

// ============================================================
// АВТООБНОВЛЕНИЕ ЧАТА (без F5): новые сообщения, голосовые,
// записи о входящих/исходящих звонках, статусы прочтения, список диалогов
// ============================================================
(function () {
    const POLL_INTERVAL = 2500;
    let busy = false;
    let timer = null;

    function chatBox() { return document.getElementById('chatMessages'); }

    function messageSignature(el) {
        return [
            el.dataset.isRead || '',
            el.dataset.deletedAt || '',
            el.dataset.messageType || '',
            el.dataset.messageText || ''
        ].join('|');
    }

    function hasPlayingAudio(el) {
        return Array.from(el.querySelectorAll('audio')).some(function (a) { return !a.paused && !a.ended; });
    }

    function canPoll() {
        if (document.visibilityState !== 'visible') return false;
        if (!chatBox()) return false;
        const dialogId = document.body.dataset.dialogId || '0';
        if (dialogId === '0') return false;
        if (typeof isRecording !== 'undefined' && isRecording) return false;
        const form = document.getElementById('chatForm');
        if (form && form.classList.contains('is-sending')) return false;
        return true;
    }

    function applyChatUpdate(nextChat) {
        const chat = chatBox();
        if (!chat || !nextChat) return false;

        const nearBottom = (chat.scrollHeight - chat.scrollTop - chat.clientHeight) < 200;
        let changed = false;
        let addedMine = false;

        const current = {};
        chat.querySelectorAll('.chat-message[data-message-id]').forEach(function (el) {
            current[el.dataset.messageId] = el;
        });

        let pendingDivider = null;
        Array.from(nextChat.children).forEach(function (node) {
            if (node.classList.contains('chat-date-divider')) {
                pendingDivider = node;
                return;
            }
            if (!node.classList.contains('chat-message') || !node.dataset.messageId) return;

            const id = node.dataset.messageId;
            const existing = current[id];

            if (!existing) {
                const empty = chat.querySelector('.empty-chat');
                if (empty) empty.remove();

                if (pendingDivider) {
                    const dividers = chat.querySelectorAll('.chat-date-divider');
                    const lastText = dividers.length
                        ? (dividers[dividers.length - 1].textContent || '').trim() : '';
                    if ((pendingDivider.textContent || '').trim() !== lastText) {
                        chat.appendChild(document.importNode(pendingDivider, true));
                    }
                }
                const clone = document.importNode(node, true);
                chat.appendChild(clone);
                current[id] = clone;
                if (clone.dataset.isMine === '1') addedMine = true;
                changed = true;
            } else if (messageSignature(existing) !== messageSignature(node) && !hasPlayingAudio(existing)) {
                const clone = document.importNode(node, true);
                if (existing.classList.contains('selected')) clone.classList.add('selected');
                existing.replaceWith(clone);
                current[id] = clone;
                changed = true;
            }
            pendingDivider = null;
        });

        // Сообщение удалили у всех: сервер его больше не отдаёт — убираем и у собеседника (раньше опрос
        // только добавлял и обновлял, поэтому у собеседника оно оставалось до перезагрузки страницы).
        // Заглушки с обратным отсчётом (is-deleted / is-vanishing) не трогаем — их убирает свой таймер.
        const serverIds = new Set();
        Array.from(nextChat.children).forEach(function (node) {
            if (node.dataset && node.dataset.messageId) serverIds.add(node.dataset.messageId);
        });
        if (serverIds.size > 0) {
            Object.keys(current).forEach(function (id) {
                const el = current[id];
                if (serverIds.has(id) || !el.isConnected) return;
                if (el.classList.contains('is-deleted') || el.classList.contains('is-vanishing')) return;
                try { el.querySelectorAll('audio').forEach(function (a) { a.pause(); }); } catch (e) {}
                const prev = el.previousElementSibling;
                const next = el.nextElementSibling;
                el.remove();
                // не оставляем «осиротевший» разделитель даты
                if (prev && prev.classList.contains('chat-date-divider') &&
                    (!next || next.classList.contains('chat-date-divider'))) prev.remove();
                changed = true;
            });
        }

        if (changed) {
            formatMessageTimes();
            fixVoiceMessages();
            setupVoicePlayback();
            parseCustomEmoji();
            if (nearBottom || addedMine) {
                chat.scrollTop = chat.scrollHeight;
            }
        }
        return changed;
    }

    function applySidebarUpdate(nextSidebar) {
        const sidebar = document.querySelector('.dialogs-sidebar');
        if (!sidebar || !nextSidebar) return;
        if (sidebar.innerHTML === nextSidebar.innerHTML) return;
        // не трогаем список, пока пользователь что-то вводит в нём (поле поиска и т.п.)
        const active = document.activeElement;
        if (active && sidebar.contains(active) && /^(INPUT|TEXTAREA)$/.test(active.tagName)) return;

        const scrollTop = sidebar.scrollTop;
        sidebar.replaceWith(nextSidebar);
        const fresh = document.querySelector('.dialogs-sidebar');
        if (fresh) fresh.scrollTop = scrollTop;
        if (typeof setupDialogRead === 'function') setupDialogRead();
        if (typeof setupDialogDraftPreviews === 'function') setupDialogDraftPreviews();
        formatMessageTimes();
        parseCustomEmoji();
    }

    async function poll() {
        if (busy || !canPoll()) return;
        busy = true;
        const dialogId = document.body.dataset.dialogId || '0';
        try {
            const response = await fetch(window.location.href, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin',
                cache: 'no-store'
            });
            if (!response.ok) return;
            const html = await response.text();
            // за время запроса пользователь мог переключить диалог или начать отправку
            if ((document.body.dataset.dialogId || '0') !== dialogId || !canPoll()) return;

            const parsed = new DOMParser().parseFromString(html, 'text/html');
            const nextChat = parsed.getElementById('chatMessages');
            if (!nextChat) return;
            if ((parsed.body.dataset.dialogId || '0') !== dialogId) return;

            applyChatUpdate(nextChat);
            applySidebarUpdate(parsed.querySelector('.dialogs-sidebar'));
        } catch (error) {
            // сеть могла моргнуть — просто попробуем в следующий раз
        } finally {
            busy = false;
        }
    }

    function start() {
        if (timer) return;
        timer = window.setInterval(poll, POLL_INTERVAL);
    }

    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') poll();
    });
    window.addEventListener('focus', poll);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
})();

// ============================================================
// Точная дата и время: «24 сентября в 22:30» (с годом, если он не текущий)
// ============================================================
function chatDateTime(ts, short) {
    const d = new Date(Number(ts) * 1000);
    if (isNaN(d.getTime())) return '';
    const sameYear = d.getFullYear() === new Date().getFullYear();
    const dateOpts = { day: 'numeric', month: short ? 'short' : 'long' };
    if (!sameYear) dateOpts.year = 'numeric';
    const date = d.toLocaleDateString('ru-RU', dateOpts).replace(/\s*г\.$/, '');
    const time = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', hour12: false });
    return date + ' в ' + time;
}

// ============================================================
// Просмотр поста прямо в чате: клик по карточке «Открыть пост →»
// открывает то же окно, что и в ленте: слева картинка, справа автор, текст,
// лайк, репост, комментарии и поле для своего комментария — без перехода
// на страницу автора.
// Ctrl/⌘/Shift-клик и средняя кнопка по-прежнему открывают ссылку как обычно.
// ============================================================
(function () {
    let overlay = null;
    let current = null;      // { id, shell, data }

    function csrf() {
        return typeof getCsrfToken === 'function' ? getCsrfToken() : ((document.body && document.body.dataset.csrfToken) || '');
    }

    function api(action, data) {
        const body = new URLSearchParams(data || {});
        body.set('csrf_token', csrf());
        return fetch('api/messages.php?api=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': csrf() },
            body: body.toString()
        }).then(function (r) { return r.json().catch(function () { return { success: false }; }); });
    }

    function closeViewer() {
        if (!overlay) return;
        overlay.remove();
        overlay = null;
        current = null;
        document.removeEventListener('keydown', onKey, true);
    }

    function onKey(e) {
        if (e.key === 'Escape') { e.stopPropagation(); closeViewer(); }
    }

    function el(tag, cls, text) {
        const n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined) n.textContent = text;
        return n;
    }

    function avatarNode(url, name, cls) {
        const a = el('div', cls);
        if (url) {
            const img = document.createElement('img');
            img.src = url;
            img.alt = '';
            a.appendChild(img);
        } else {
            a.textContent = (name || '?').charAt(0).toUpperCase();
        }
        return a;
    }

    function openShell() {
        closeViewer();
        overlay = el('div', 'photo-viewer-modal post-viewer-modal');
        const content = el('div', 'photo-viewer-content');
        const stage = el('div', 'photo-viewer-stage');
        const side = el('aside', 'photo-viewer-sidebar');

        const head = el('div', 'photo-viewer-sidebar-header');
        head.appendChild(el('span', '', 'Комментарии'));
        const close = el('button', 'photo-viewer-close', '×');
        close.type = 'button';
        close.setAttribute('aria-label', 'Закрыть');
        close.addEventListener('click', closeViewer);
        head.appendChild(close);
        side.appendChild(head);

        const info = el('div', 'photo-viewer-info');
        const list = el('div', 'photo-viewer-comments');
        side.appendChild(info);
        side.appendChild(list);

        const form = el('div', 'photo-viewer-comment-form');
        form.hidden = true;
        const input = document.createElement('input');
        input.type = 'text';
        input.maxLength = 1000;
        input.autocomplete = 'off';
        input.placeholder = 'Написать комментарий...';
        const send = el('button', 'photo-viewer-comment-send');
        send.type = 'button';
        send.disabled = true;
        send.setAttribute('aria-label', 'Отправить');
        send.innerHTML = '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M2.5 20.5l19-8.5-19-8.5v6.6l13.6 1.9-13.6 1.9z"/></svg>';
        form.appendChild(input);
        form.appendChild(send);
        side.appendChild(form);

        content.appendChild(stage);
        content.appendChild(side);
        overlay.appendChild(content);
        overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) closeViewer(); });
        document.body.appendChild(overlay);
        document.addEventListener('keydown', onKey, true);
        return { content: content, stage: stage, info: info, list: list, form: form, input: input, send: send };
    }

    function showStatus(shell, text) {
        shell.stage.hidden = true;
        shell.content.classList.add('is-text-only');
        shell.form.hidden = true;
        shell.info.textContent = '';
        shell.list.textContent = '';
        shell.list.appendChild(el('div', 'photo-viewer-comments-note', text));
    }

    function setNote(shell, text) {
        shell.list.textContent = '';
        shell.list.appendChild(el('div', 'photo-viewer-comments-note', text));
    }

    function actionBtn(iconSrc, cls) {
        const b = el('button', 'post-viewer-action ' + cls);
        b.type = 'button';
        const icon = document.createElement('img');
        icon.src = iconSrc;
        icon.alt = '';
        const count = el('span', 'post-viewer-action-count', '0');
        b.appendChild(icon);
        b.appendChild(count);
        return { btn: b, count: count };
    }

    function buildComment(cm, postId, shell) {
        const item = el('div', 'photo-viewer-comment');
        item.appendChild(avatarNode(cm.avatar, cm.username, 'photo-viewer-comment-avatar'));
        const main = el('div', 'photo-viewer-comment-main');
        const head = el('div', 'photo-viewer-comment-head');
        head.appendChild(el('span', 'photo-viewer-comment-name', cm.username || 'Пользователь'));
        head.appendChild(el('span', 'photo-viewer-comment-time', cm.ts ? chatDateTime(cm.ts, true) : ''));
        if (cm.can_delete) {
            const del = el('button', 'photo-viewer-comment-delete', '×');
            del.type = 'button';
            del.title = 'Удалить комментарий';
            del.addEventListener('click', function () {
                api('post_comment_delete', { comment_id: cm.id }).then(function (res) {
                    if (res && res.success) {
                        item.remove();
                        if (!shell.list.querySelector('.photo-viewer-comment')) setNote(shell, 'Нет комментариев');
                    }
                });
            });
            head.appendChild(del);
        }
        main.appendChild(head);
        main.appendChild(el('div', 'photo-viewer-comment-text', cm.text));
        item.appendChild(main);
        return item;
    }

    function render(shell, p) {
        const postId = p.id;

        // Картинка слева; без неё — только панель
        shell.stage.textContent = '';
        if (p.image) {
            shell.stage.hidden = false;
            shell.content.classList.remove('is-text-only');
            const img = document.createElement('img');
            img.className = 'photo-viewer-image';
            img.src = p.image;
            img.alt = '';
            shell.stage.appendChild(img);
        } else {
            shell.stage.hidden = true;
            shell.content.classList.add('is-text-only');
        }

        // Автор + время, текст, лайк и репост
        shell.info.textContent = '';
        const row = el('div', 'photo-viewer-author-row');
        row.appendChild(avatarNode(p.author_avatar, p.author_name, 'photo-viewer-avatar'));
        const meta = el('div', 'photo-viewer-meta');
        meta.appendChild(el('span', 'photo-viewer-author', p.author_name || 'Пользователь'));
        if (p.created_at) {
            const d = new Date(String(p.created_at).replace(' ', 'T') + 'Z');
            if (!isNaN(d.getTime())) {
                const t = el('span', 'photo-viewer-time', chatDateTime(d.getTime() / 1000));
                t.title = d.toLocaleString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
                meta.appendChild(t);
            }
        }
        row.appendChild(meta);
        shell.info.appendChild(row);

        if (p.text) shell.info.appendChild(el('div', 'post-viewer-text', p.text));

        const actions = el('div', 'post-viewer-actions');
        const like = actionBtn('images/heart.svg', 'is-like');
        const repost = actionBtn('images/share.svg', 'is-repost');
        function paint() {
            like.btn.classList.toggle('active', !!p.liked);
            repost.btn.classList.toggle('active', !!p.reposted);
            like.count.textContent = String(p.likes || 0);
            repost.count.textContent = String(p.reposts || 0);
        }
        paint();
        like.btn.setAttribute('aria-label', 'Лайк');
        repost.btn.setAttribute('aria-label', 'Поделиться');
        function toggle(action, ref) {
            if (ref.btn.disabled) return;
            ref.btn.disabled = true;
            api(action, { post_id: postId }).then(function (res) {
                if (res && res.success) {
                    p.likes = res.likes; p.reposts = res.reposts;
                    p.liked = res.liked; p.reposted = res.reposted;
                    paint();
                }
            }).finally(function () { ref.btn.disabled = false; });
        }
        like.btn.addEventListener('click', function () { toggle('post_like', like); });
        repost.btn.addEventListener('click', function () { toggle('post_repost', repost); });
        actions.appendChild(like.btn);
        actions.appendChild(repost.btn);
        shell.info.appendChild(actions);

        // Комментарии
        const comments = p.comments || [];
        shell.list.textContent = '';
        if (!comments.length) setNote(shell, 'Нет комментариев');
        comments.forEach(function (cm) { shell.list.appendChild(buildComment(cm, postId, shell)); });

        // Поле для своего комментария
        shell.form.hidden = false;
        let sending = false;
        function refreshSend() { shell.send.disabled = sending || shell.input.value.trim() === ''; }
        function sendComment() {
            const text = shell.input.value.trim();
            if (!text || sending) return;
            sending = true;
            refreshSend();
            api('post_comment_add', { post_id: postId, comment: text }).then(function (res) {
                if (res && res.success && res.comment) {
                    const note = shell.list.querySelector('.photo-viewer-comments-note');
                    if (note) note.remove();
                    shell.list.appendChild(buildComment(res.comment, postId, shell));
                    shell.list.scrollTop = shell.list.scrollHeight;
                    shell.input.value = '';
                }
            }).finally(function () {
                sending = false;
                refreshSend();
                shell.input.focus();
            });
        }
        shell.input.addEventListener('input', refreshSend);
        shell.input.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendComment(); }
        });
        shell.send.addEventListener('click', sendComment);
        refreshSend();
    }

    document.addEventListener('click', function (e) {
        const link = e.target.closest ? e.target.closest('a.message-link-post[data-post-id]') : null;
        if (!link) return;
        if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
        e.preventDefault();
        e.stopPropagation();

        const shell = openShell();
        showStatus(shell, 'Загрузка…');
        current = { id: link.dataset.postId, shell: shell };

        fetch('api/messages.php?api=get_post&post_id=' + encodeURIComponent(link.dataset.postId), {
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
            .then(function (r) { return r.json().catch(function () { return { success: false }; }); })
            .then(function (data) {
                if (!overlay || !current || current.shell !== shell) return; // окно уже закрыли
                if (data && data.success) {
                    render(shell, data);
                } else {
                    showStatus(shell, data && data.error === 'post_not_found' ? 'Пост удалён или недоступен' : 'Не удалось загрузить пост');
                }
            })
            .catch(function () {
                if (overlay && current && current.shell === shell) showStatus(shell, 'Не удалось загрузить пост');
            });
    }, true);
})();


// ===== Меню «ещё» (три точки) в шапке диалога =====
// Обработчики висят на document: при переходе между диалогами .chat-area заменяется целиком,
// и обработчики, повешенные прямо на кнопки, пропадали бы.
(function () {
    function csrfToken() {
        const input = document.querySelector('input[name="csrf_token"]');
        return input ? input.value : (document.body.dataset.csrfToken || '');
    }

    function dlgPost(action, dialogId) {
        const token = csrfToken();
        return fetch('api/messages.php?api=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': token },
            body: 'dialog=' + encodeURIComponent(dialogId) + '&csrf_token=' + encodeURIComponent(token)
        }).then(function (r) { return r.json().catch(function () { return { success: false }; }); });
    }

    function notice(text) {
        if (typeof showVoiceNotice === 'function') showVoiceNotice(text);
    }

    function closeMenus() {
        document.querySelectorAll('.dlg-more.open').forEach(function (box) {
            box.classList.remove('open');
            const b = box.querySelector('.dlg-more-btn');
            if (b) b.setAttribute('aria-expanded', 'false');
        });
    }

    document.addEventListener('click', function (event) {
        const target = event.target;
        if (!target || !target.closest) return;

        // три точки: на телефоне открывают меню по нажатию
        const moreBtn = target.closest('.dlg-more-btn');
        if (moreBtn) {
            event.stopPropagation();
            const box = moreBtn.closest('.dlg-more');
            const willOpen = !box.classList.contains('open');
            closeMenus();
            if (willOpen) {
                box.classList.add('open');
                moreBtn.setAttribute('aria-expanded', 'true');
            }
            return;
        }

        const item = target.closest('.dlg-item');
        const box = item ? item.closest('.dlg-more') : null;
        if (!item || !box) { closeMenus(); return; }
        const dialogId = box.dataset.dialogId;

        if (item.id === 'dlgMute') {
            dlgPost('mute', dialogId).then(function (d) {
                if (!d || !d.success) return;
                item.textContent = d.muted ? 'Включить уведомления' : 'Отключить уведомления';
                const bell = document.getElementById('dialogNotifyBtn');
                if (bell) { bell.dataset.muted = d.muted ? '1' : '0'; bell.classList.toggle('muted', !!d.muted); }
                notice(d.muted ? 'Уведомления отключены' : 'Уведомления включены');
            });
        } else if (item.id === 'dlgClear') {
            if (!window.confirm('Очистить историю переписки? У собеседника сообщения останутся.')) return;
            dlgPost('clear_history', dialogId).then(function (d) {
                if (d && d.success) window.location.reload();
            });
        } else if (item.id === 'dlgBlock') {
            dlgPost('block', dialogId).then(function (d) {
                if (d && d.success) window.location.reload();
            });
        }
        closeMenus();
    });
})();


// ===== «печатает...» в списке диалогов =====
// Раз в пару секунд спрашиваем, кто сейчас печатает нам, и вместо последнего сообщения
// показываем «печатает...». Исходный текст не трогаем — его просто прячет CSS (класс is-typing).
(function () {
    function applyTyping(ids) {
        const typing = new Set(ids.map(String));
        document.querySelectorAll('.dialog-item[data-dialog-id]').forEach(function (item) {
            const on = typing.has(String(item.dataset.dialogId));
            item.classList.toggle('is-typing', on);
            if (!on) return;
            const preview = item.querySelector('.dialog-preview');
            if (preview && !preview.querySelector('.dialog-typing-text')) {
                const el = document.createElement('span');
                el.className = 'dialog-typing-text';
                el.innerHTML = '<svg class="typing-pencil" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>' + '<span>печатает<span class="typing-dots"><i>.</i><i>.</i><i>.</i></span></span>';
                preview.insertBefore(el, preview.firstChild);
            }
        });
    }

    function poll() {
        if (document.hidden || !document.querySelector('.dialog-item[data-dialog-id]')) return;
        fetch('api/messages.php?api=typing_all', { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (d) { applyTyping(d && Array.isArray(d.typing) ? d.typing : []); })
            .catch(function () {});
    }

    setInterval(poll, 2000);
    poll();
})();


// Меню «⋯»: закрывается при нажатии где угодно снаружи (уведомления, профиль, другие кнопки).
// Слушаем pointerdown в фазе перехвата, чтобы не зависеть от stopPropagation в чужих обработчиках.
(function () {
    function closeAll() {
        document.querySelectorAll('.dlg-more').forEach(function (box) {
            box.classList.remove('open');
            const b = box.querySelector('.dlg-more-btn');
            if (b) b.setAttribute('aria-expanded', 'false');
            if (box.contains(document.activeElement) && document.activeElement.blur) document.activeElement.blur();
        });
    }
    document.addEventListener('pointerdown', function (e) {
        if (e.target && e.target.closest && e.target.closest('.dlg-more')) return;
        closeAll();
    }, true);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeAll(); });
    window.addEventListener('blur', closeAll);
})();

/* ============================================================
   news.js — лента новостей (news.php)
   Лайки и реакции, комментарии, «Поделиться», подтверждение
   удаления и живое обновление короткого времени под постом.
   Подключается ПОСЛЕ assets/js/script.js.
   ============================================================ */
(function () {
    'use strict';

    var EMOJI = { laugh: '😆', wow: '😲', love: '😍', sad: '😢', angry: '😡' };
    var HEART = '<img class="like-heart" src="images/heart.svg" alt="">';

    function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    /* ---------- Всплывающее сообщение об ошибке ---------- */
    function toast(msg) {
        msg = String(msg || 'Что-то пошло не так. Попробуйте ещё раз.');
        var box = document.getElementById('newsToasts');
        if (!box) {
            box = document.createElement('div');
            box.id = 'newsToasts';
            box.className = 'news-toasts';
            box.setAttribute('role', 'alert');
            box.setAttribute('aria-live', 'assertive');
            document.body.appendChild(box);
        }
        // одинаковое сообщение не дублируем
        var same = Array.prototype.some.call(box.children, function (t) { return t.textContent === msg; });
        if (same) return;

        var t = document.createElement('div');
        t.className = 'news-toast';
        t.textContent = msg;
        t.addEventListener('click', function () { t.remove(); });
        box.appendChild(t);
        setTimeout(function () { t.remove(); }, 7000);
    }
    window.newsToast = toast;

    function errText(err) {
        return (err && err.message) ? err.message : 'Что-то пошло не так. Попробуйте ещё раз.';
    }

    function postJson(form, extra) {
        var fd = new FormData(form);
        if (extra) Object.keys(extra).forEach(function (k) { fd.set(k, extra[k]); });
        return fetch(form.action || window.location.href, {
            method: 'POST',
            body: fd,
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (r) {
            return r.text().then(function (text) {
                var data = null;
                try { data = JSON.parse(text); } catch (e) { /* не JSON */ }
                if (!data) {
                    throw new Error(r.ok ? 'Сервер вернул неожиданный ответ.' : 'Ошибка сервера (' + r.status + ').');
                }
                if (!r.ok || !data.success) {
                    throw new Error(data.message || 'Не удалось выполнить действие (' + r.status + ').');
                }
                return data;
            });
        }, function () {
            throw new Error('Нет связи с сервером. Проверьте интернет и попробуйте снова.');
        });
    }

    /* ---------- Кнопка лайка: сердце или выбранная реакция ---------- */
    window.setLikeReaction = function (btn, reaction) {
        var icon = btn.querySelector('.action-icon');
        btn.classList.toggle('liked', !!reaction);
        btn.dataset.reaction = reaction || '';
        icon.innerHTML = EMOJI[reaction]
            ? '<span class="reaction-emoji">' + EMOJI[reaction] + '</span>'
            : HEART;
    };

    /* ============================================================
       Отправка форм: лайк / «поделиться» / комментарий
       ============================================================ */
    document.addEventListener('submit', function (e) {
        var form = e.target;

        // «Поделиться» не переключает репост напрямую, а открывает окно выбора получателя
        if (form.classList.contains('ajax-repost-form')) {
            e.preventDefault();
            if (window.openShareDialog) window.openShareDialog(form.dataset.postId);
            return;
        }

        // Обычный клик по лайку: поставить / снять
        if (form.classList.contains('ajax-like-form')) {
            e.preventDefault();
            var btn = form.querySelector('.post-action-btn');
            if (btn.disabled) return;
            btn.disabled = true;

            postJson(form)
                .then(function (data) {
                    window.setLikeReaction(btn, data.reaction);
                    btn.querySelector('.action-count').textContent = data.count;
                })
                .catch(function (err) { console.error('Like error:', err); toast(errText(err)); })
                .then(function () { btn.disabled = false; });
            return;
        }

        // Комментарий: новый блок появляется сразу, счётчик обновляется
        if (form.classList.contains('ajax-comment-form')) {
            e.preventDefault();
            var input = form.querySelector('input[name="comment"]');
            var sendBtn = form.querySelector('.comment-send');
            if (!input || !input.value.trim() || (sendBtn && sendBtn.disabled)) return;
            if (sendBtn) sendBtn.disabled = true;

            postJson(form)
                .then(function (data) {
                    if (data.html) form.insertAdjacentHTML('beforebegin', data.html);
                    input.value = '';

                    var postId = form.dataset.postId;
                    var counter = document.querySelector('.toggle-comments[data-post-id="' + postId + '"] .action-count');
                    if (counter) counter.textContent = data.count;
                })
                .catch(function (err) { console.error('Comment error:', err); toast(errText(err)); })
                .then(function () { if (sendBtn) sendBtn.disabled = false; });
        }
    });

    /* ============================================================
       Открытие комментариев — переключение делает script.js,
       здесь только переводим фокус в поле ввода.
       ============================================================ */
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.toggle-comments');
        if (!btn) return;
        var section = document.getElementById('comments-' + btn.dataset.postId);
        if (!section || section.style.display === 'none') return;
        var input = section.querySelector('input[name="comment"]');
        if (input) input.focus({ preventScroll: true });
    });

    document.addEventListener('keydown', function (e) {
        var icon = e.target.closest ? e.target.closest('.comment-action-icon') : null;
        if (!icon || (e.key !== 'Enter' && e.key !== ' ')) return;
        e.preventDefault();
        icon.closest('.toggle-comments').click();
    });

    /* ============================================================
       Реакции: окно при наведении на лайк (на телефоне — долгое нажатие)
       ============================================================ */
    (function () {
        var popup  = document.getElementById('reactionPopup');
        var footer = document.getElementById('reactionPopupFooter');
        if (!popup) return;

        var BTN_SEL = '.ajax-like-form .post-action-btn';
        var showTimer = null, hideTimer = null, pressTimer = null;
        var currentBtn = null, longPressed = false;
        var cache = {};

        function plural(n) {
            var m10 = n % 10, m100 = n % 100;
            if (m10 === 1 && m100 !== 11) return n + ' реакция';
            if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return n + ' реакции';
            return n + ' реакций';
        }

        function renderFooter(data) {
            footer.innerHTML = '';
            if (!data || !data.total) { footer.hidden = true; return; }

            var stack = document.createElement('span');
            stack.className = 'reaction-avatars';
            (data.users || []).forEach(function (u) {
                var av = document.createElement('span');
                av.className = 'reaction-avatar';
                if (u.avatar) {
                    var img = document.createElement('img');
                    img.src = u.avatar;
                    img.alt = '';
                    av.appendChild(img);
                } else {
                    av.textContent = (u.username || '?').charAt(0).toUpperCase();
                }
                av.title = u.username;
                stack.appendChild(av);
            });

            var text = document.createElement('span');
            text.textContent = plural(data.total);
            footer.appendChild(stack);
            footer.appendChild(text);
            footer.hidden = false;
        }

        function loadFooter(postId) {
            if (cache[postId]) { renderFooter(cache[postId]); return; }
            footer.hidden = true;
            fetch('news.php?post_reactions=' + encodeURIComponent(postId), {
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(function (r) {
                    return r.json().then(function (data) {
                        if (!r.ok || (data && data.success === false)) {
                            throw new Error((data && data.message) || 'Не удалось загрузить реакции (' + r.status + ').');
                        }
                        return data;
                    });
                })
                .then(function (data) {
                    cache[postId] = data;
                    var form = currentBtn && currentBtn.closest('.ajax-like-form');
                    if (form && form.dataset.postId === String(postId)) {
                        renderFooter(data);
                        place(currentBtn);
                    }
                })
                .catch(function (err) { console.error('Reactions error:', err); toast(errText(err)); });
        }

        function place(btn) {
            var r = btn.getBoundingClientRect();
            var pw = popup.offsetWidth, ph = popup.offsetHeight;
            var left = Math.max(8, Math.min(r.left, window.innerWidth - pw - 8));
            var top = r.top - ph - 8;
            if (top < 8) top = r.bottom + 8;
            popup.style.left = left + 'px';
            popup.style.top = top + 'px';
        }

        function show(btn) {
            clearTimeout(hideTimer);
            currentBtn = btn;
            popup.hidden = false;
            var form = btn.closest('.ajax-like-form');
            var mine = btn.dataset.reaction || (btn.classList.contains('liked') ? 'like' : '');
            popup.querySelectorAll('.reaction-opt').forEach(function (o) {
                o.classList.toggle('active', o.dataset.reaction === mine);
            });
            loadFooter(form.dataset.postId);
            place(btn);
        }

        function hide() {
            clearTimeout(showTimer);
            clearTimeout(hideTimer);
            popup.hidden = true;
            currentBtn = null;
        }

        function choose(reaction) {
            var btn = currentBtn;
            if (!btn) return;
            var form = btn.closest('.ajax-like-form');
            var postId = form.dataset.postId;
            hide();

            // Повторный выбор той же реакции снимает её — это решает сервер
            postJson(form, { reaction: reaction })
                .then(function (data) {
                    window.setLikeReaction(btn, data.reaction);
                    btn.querySelector('.action-count').textContent = data.count;
                    delete cache[postId];
                })
                .catch(function (err) { console.error('Reaction error:', err); toast(errText(err)); });
        }

        // Мышь: небольшая задержка, чтобы окно не мигало
        document.addEventListener('mouseover', function (e) {
            var btn = e.target.closest(BTN_SEL);
            if (btn) {
                clearTimeout(hideTimer);
                if (currentBtn !== btn || popup.hidden) {
                    clearTimeout(showTimer);
                    showTimer = setTimeout(function () { show(btn); }, 350);
                }
            } else if (e.target.closest('#reactionPopup')) {
                clearTimeout(hideTimer);
            }
        });
        document.addEventListener('mouseout', function (e) {
            var from = e.target.closest ? e.target.closest(BTN_SEL + ', #reactionPopup') : null;
            if (!from) return;
            var to = e.relatedTarget && e.relatedTarget.closest
                ? e.relatedTarget.closest(BTN_SEL + ', #reactionPopup') : null;
            if (to) return;
            clearTimeout(showTimer);
            hideTimer = setTimeout(hide, 250);
        });

        popup.addEventListener('click', function (e) {
            var opt = e.target.closest('.reaction-opt');
            if (opt) choose(opt.dataset.reaction);
        });

        // Телефон: долгое нажатие открывает окно, обычное — ставит лайк
        document.addEventListener('touchstart', function (e) {
            var btn = e.target.closest(BTN_SEL);
            if (!btn) return;
            longPressed = false;
            pressTimer = setTimeout(function () { longPressed = true; show(btn); }, 450);
        }, { passive: true });
        ['touchend', 'touchmove', 'touchcancel'].forEach(function (type) {
            document.addEventListener(type, function () { clearTimeout(pressTimer); }, { passive: true });
        });
        document.addEventListener('click', function (e) {
            if (longPressed && e.target.closest(BTN_SEL)) {
                e.preventDefault();
                e.stopPropagation();
                longPressed = false;
                return;
            }
            if (!popup.hidden && !e.target.closest('#reactionPopup') && !e.target.closest(BTN_SEL)) hide();
        }, true);

        window.addEventListener('scroll', hide, true);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && !popup.hidden) hide();
        });
    })();

    /* ============================================================
       Поделиться → В личном сообщении
       ============================================================ */
    (function () {
        var overlay = document.getElementById('shareDialog');
        if (!overlay) return;

        var combo   = document.getElementById('shareCombo');
        var search  = document.getElementById('shareSearch');
        var list    = document.getElementById('shareList');
        var sendBtn = document.getElementById('shareSend');
        var cancel  = document.getElementById('shareCancel');

        var targets = [];
        var postId = null;
        var receiverId = null;
        var sending = false;

        function avatarHtml(t) {
            if (t.is_self) return '<span class="share-avatar share-avatar-self">&#128278;</span>';
            if (t.avatar) return '<span class="share-avatar"><img src="' + esc(t.avatar) + '" alt=""></span>';
            return '<span class="share-avatar">' + esc((t.username || '?').charAt(0).toUpperCase()) + '</span>';
        }

        function renderList(filter) {
            var q = (filter || '').trim().toLowerCase();
            var items = targets.filter(function (t) {
                return !q || t.username.toLowerCase().indexOf(q) !== -1;
            });
            if (!items.length) {
                list.innerHTML = '<div class="share-empty">Ничего не найдено</div>';
                return;
            }
            list.innerHTML = items.map(function (t) {
                return '<button type="button" class="share-item" data-id="' + t.id + '">' +
                    avatarHtml(t) + '<span class="share-item-name">' + esc(t.username) + '</span></button>';
            }).join('');
        }

        function showList() { list.hidden = false; combo.classList.add('open'); }
        function hideList() { list.hidden = true;  combo.classList.remove('open'); }

        function resetSendBtn() {
            sendBtn.textContent = 'Отправить';
            sendBtn.disabled = receiverId === null;
        }

        window.openShareDialog = function (id) {
            postId = id;
            receiverId = null;
            sending = false;
            search.value = '';
            resetSendBtn();
            list.innerHTML = '<div class="share-empty">Загрузка...</div>';
            overlay.hidden = false;
            showList();
            search.focus();

            fetch('messages.php?api=share_targets', { credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    targets = (data && data.success && Array.isArray(data.targets)) ? data.targets : [];
                    renderList(search.value);
                })
                .catch(function () {
                    list.innerHTML = '<div class="share-empty">Не удалось загрузить список</div>';
                });
        };

        function closeShare() {
            overlay.hidden = true;
            hideList();
            postId = null;
            receiverId = null;
        }

        search.addEventListener('input', function () {
            receiverId = null;          // текст поменяли — выбор сброшен
            resetSendBtn();
            renderList(search.value);
            showList();
        });
        search.addEventListener('focus', function () { renderList(search.value); showList(); });
        combo.addEventListener('click', function (e) {
            if (e.target.closest('.share-combo-arrow')) {
                if (list.hidden) { renderList(search.value); showList(); search.focus(); }
                else hideList();
            }
        });

        list.addEventListener('click', function (e) {
            var item = e.target.closest('.share-item');
            if (!item) return;
            var t = targets.find(function (x) { return String(x.id) === item.dataset.id; });
            if (!t) return;
            receiverId = t.id;
            search.value = t.username;
            hideList();
            resetSendBtn();
        });

        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) { closeShare(); return; }
            if (!e.target.closest('.share-combo')) hideList();
        });
        cancel.addEventListener('click', closeShare);
        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape' || overlay.hidden) return;
            e.stopPropagation();
            if (!list.hidden) hideList(); else closeShare();
        }, true);

        // Отправка = репост: если пост ещё не в репостах, засчитываем его (счётчик растёт на 1)
        function countShareAsRepost(id) {
            var form = document.querySelector('.ajax-repost-form[data-post-id="' + id + '"]');
            if (!form) return;
            var btn = form.querySelector('.post-action-btn');
            if (!btn || btn.classList.contains('reposted')) return;
            postJson(form).then(function (data) {
                btn.classList.toggle('reposted', !!data.reposted);
                btn.querySelector('.action-count').textContent = data.count;
            }).catch(function (err) { toast(errText(err)); });
        }

        sendBtn.addEventListener('click', function () {
            if (sending || receiverId === null || !postId) return;
            sending = true;
            sendBtn.disabled = true;
            sendBtn.textContent = 'Отправка...';

            var fd = new FormData();
            fd.append('post_id', postId);
            fd.append('receiver_id', receiverId);
            fd.append('csrf_token', window.SHARE_CSRF);
            var sentPostId = postId;

            fetch('messages.php?api=share_post', {
                method: 'POST',
                body: fd,
                credentials: 'same-origin',
                headers: { 'X-CSRF-Token': window.SHARE_CSRF }
            })
            .then(function (r) {
                return r.json().catch(function () {
                    return { success: false, message: 'Ошибка сервера (' + r.status + ').' };
                });
            }, function () {
                return { success: false, message: 'Нет связи с сервером. Проверьте интернет.' };
            })
            .then(function (res) {
                if (!res || !res.success) {
                    var m = res && (res.message || res.error);
                    throw new Error(typeof m === 'string' && m ? m : 'Не удалось отправить сообщение.');
                }
                sendBtn.textContent = 'Отправлено ✓';
                countShareAsRepost(sentPostId);
                setTimeout(function () { sending = false; closeShare(); }, 700);
            })
            .catch(function (err) {
                sending = false;
                sendBtn.textContent = 'Ошибка, повторить';
                sendBtn.disabled = false;
                toast(errText(err));
            });
        });
    })();

    /* ============================================================
       Окно подтверждения (удаление комментария)
       ============================================================ */
    (function () {
        var overlay = document.getElementById('confirmOverlay');
        if (!overlay) return;
        var textEl = document.getElementById('confirmText');
        var okBtn = document.getElementById('confirmOk');
        var cancelBtn = document.getElementById('confirmCancel');
        var pending = null;

        function close() {
            overlay.classList.remove('active');
            overlay.setAttribute('aria-hidden', 'true');
            pending = null;
        }

        document.addEventListener('click', function (e) {
            var el = e.target.closest('[data-confirm]');
            if (!el) return;
            e.preventDefault();
            e.stopPropagation();
            pending = el;
            textEl.textContent = el.getAttribute('data-confirm');
            overlay.classList.add('active');
            overlay.setAttribute('aria-hidden', 'false');
            okBtn.focus();
        }, true);

        okBtn.addEventListener('click', function () {
            var el = pending;
            close();
            if (el && el.tagName === 'A' && el.href) window.location.href = el.href;
        });
        cancelBtn.addEventListener('click', close);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    })();

    /* ============================================================
       Фото и видео открываются поверх ленты — без перехода на страницу автора
       ============================================================ */
    (function () {
        var box = document.getElementById('newsLightbox');
        if (!box) return;
        var stage = document.getElementById('newsLightboxStage');
        var closeBtn = document.getElementById('newsLightboxClose');
        var lastFocus = null;

        function open(type, src) {
            lastFocus = document.activeElement;
            stage.innerHTML = '';

            var el;
            if (type === 'video') {
                el = document.createElement('video');
                el.src = src;
                el.controls = true;
                el.autoplay = true;
                el.playsInline = true;
            } else {
                el = document.createElement('img');
                el.src = src;
                el.alt = '';
            }
            stage.appendChild(el);

            box.hidden = false;
            document.body.style.overflow = 'hidden';
            closeBtn.focus();
        }

        function close() {
            if (box.hidden) return;
            var v = stage.querySelector('video');
            if (v) { v.pause(); v.removeAttribute('src'); v.load(); }   // остановить звук и загрузку
            stage.innerHTML = '';
            box.hidden = true;
            document.body.style.overflow = '';
            if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
        }

        // Клик по медиа в посте
        document.addEventListener('click', function (e) {
            var media = e.target.closest('.post-media');
            if (!media) return;
            e.preventDefault();
            e.stopPropagation();   // не «проваливаемся» в ссылки и обработчики выше
            open(media.dataset.mediaType, media.dataset.src);
        });

        // С клавиатуры: Enter / пробел
        document.addEventListener('keydown', function (e) {
            var media = e.target.closest ? e.target.closest('.post-media') : null;
            if (!media || (e.key !== 'Enter' && e.key !== ' ')) return;
            e.preventDefault();
            open(media.dataset.mediaType, media.dataset.src);
        });

        // Закрытие: крестик, фон, Esc
        closeBtn.addEventListener('click', close);
        box.addEventListener('click', function (e) {
            if (e.target === box || e.target === stage) close();
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && !box.hidden) { e.stopPropagation(); close(); }
        }, true);
    })();

    /* ============================================================
       Ссылка на пост (news.php#post-ID): прокрутить, подсветить, раскрыть комментарии
       ============================================================ */
    (function () {
        function showToast(text) {
            var toast = document.createElement('div');
            toast.className = 'post-toast';
            toast.textContent = text;
            document.body.appendChild(toast);
            setTimeout(function () { toast.classList.add('hide'); }, 3000);
            setTimeout(function () { toast.remove(); }, 3500);
        }

        function openSharedPost() {
            var match = /^#post-(\d+)$/.exec(window.location.hash);
            if (!match) return;

            var post = document.getElementById('post-' + match[1]);
            if (!post) { showToast('Пост не найден или уже удалён'); return; }

            var section = document.getElementById('comments-' + match[1]);
            if (section) section.style.display = 'block';

            post.scrollIntoView({ behavior: 'smooth', block: 'start' });
            post.classList.remove('post-highlight');
            void post.offsetWidth;
            post.classList.add('post-highlight');
            setTimeout(function () { post.classList.remove('post-highlight'); }, 3500);
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', openSharedPost);
        } else {
            openSharedPost();
        }
        window.addEventListener('hashchange', openSharedPost);
    })();

    /* ============================================================
       Короткое время под постом: «только что» → «1 мин» → «3 часа».
       Живёт, пока пост моложе суток; дальше («вчера», «3 окт»)
       метку выставляет сервер при загрузке страницы.
       ============================================================ */
    (function () {
        var dates = document.querySelectorAll('.post-date[data-rel="1"]');
        if (!dates.length) return;

        // Часы сервера и браузера могут расходиться — считаем по серверным
        var offset = window.NEWS_SERVER_TS ? window.NEWS_SERVER_TS * 1000 - Date.now() : 0;

        function pluralHours(n) {
            var m10 = n % 10, m100 = n % 100;
            if (m100 >= 11 && m100 <= 19) return 'часов';
            if (m10 === 1) return 'час';
            if (m10 >= 2 && m10 <= 4) return 'часа';
            return 'часов';
        }

        function label(sec) {
            if (sec < 60) return 'только что';
            if (sec < 3600) return Math.floor(sec / 60) + ' мин';
            var h = Math.floor(sec / 3600);
            return h + ' ' + pluralHours(h);
        }

        function tick() {
            var nowSec = (Date.now() + offset) / 1000;
            dates.forEach(function (el) {
                if (el.getAttribute('data-rel') !== '1') return;
                var sec = Math.max(0, Math.floor(nowSec - Number(el.dataset.ts)));
                if (sec >= 86400) { el.removeAttribute('data-rel'); return; }
                el.textContent = label(sec);
            });
        }

        setInterval(tick, 30000);
    })();
})();

/* Страница «Фото»: все фото, альбомы (закрытые и открытые), просмотр.
   Все запросы идут на photos.php (?api=...). Картинки приходят расшифрованными:
   владельцу — всегда, остальным — только из открытых альбомов. */
(function () {
    var cfg = window.PHOTOS_CFG || {};
    var root = document.querySelector('[data-md-kind="photo"]');
    if (!root) return;

    function $(id) { return document.getElementById(id); }
    var input = $('mdInput'), drop = $('mdDrop'), grid = $('mdGrid'), toolbar = $('mdToolbar'), countEl = $('mdCount');
    var viewer = $('mdViewer'), stage = $('mdStage'), vcap = $('mdVcap');
    var tabs = $('mdTabs'), ahead = $('mdAhead'), albumsEl = $('mdAlbums'), note = $('mdNote');
    var heroTitle = $('mdTitle'), heroSub = $('mdSub');
    var modal = $('mdModal'), modalCard = $('mdModalCard');

    var photos = [];        // все мои фото
    var albums = [];        // мои альбомы
    var foreign = [];       // альбомы другого пользователя (режим просмотра)
    var shown = [];         // что сейчас в сетке
    var view = 'all';       // all | albums | album
    var album = null;       // открытый альбом
    var readonly = false;   // смотрим чужое
    var ownLoaded = false, loaded = false;
    var current = -1;
    var ownerName = '', ownerId = 0;
    var NOTE_DEFAULT = note.textContent;

    /* ---------- утилиты ---------- */
    function h(tag, cls, text) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        if (text != null) e.textContent = text;
        return e;
    }
    function plural(n, one, few, many) {
        var a = n % 10, b = n % 100;
        if (a === 1 && b !== 11) return one;
        if (a >= 2 && a <= 4 && (b < 10 || b >= 20)) return few;
        return many;
    }
    function findBy(list, id) {
        for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
        return null;
    }
    function imgUrl(id) { return cfg.api + '?api=img&id=' + id; }
    function get(q) { return fetch(cfg.api + '?' + q, { credentials: 'same-origin' }).then(function (r) { return r.json(); }); }
    function post(action, data) {
        var fd = new FormData();
        Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
        fd.append('csrf', cfg.csrf);
        return fetch(cfg.api + '?api=' + action, {
            method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': cfg.csrf }
        }).then(function (r) { return r.json(); });
    }

    var toast = h('div', 'md-toast');
    document.body.appendChild(toast);
    var toastTimer;
    function say(text, kind, sticky) {
        toast.textContent = text;
        toast.className = 'md-toast show' + (kind ? ' ' + kind : '');
        clearTimeout(toastTimer);
        if (!sticky) toastTimer = setTimeout(function () { toast.classList.remove('show'); }, 4500);
    }
    function netErr() { say('Нет связи с сервером', 'err'); }

    /* ---------- данные ---------- */
    function photosOf(aid) { return photos.filter(function (p) { return p.album === aid; }); }

    function refreshStats() {
        albums.forEach(function (a) {
            var list = photosOf(a.id);
            a.count = list.length;
            a.cover = list.length ? list[0].id : null;
        });
    }

    function loadOwn() {
        return get('api=list').then(function (d) {
            loaded = true;
            if (!d.ok) { say(d.error || 'Не удалось загрузить список', 'err'); return; }
            photos = d.items; albums = d.albums; ownLoaded = true;
            refreshStats();
        }).catch(function () { loaded = true; netErr(); });
    }

    /* ---------- отрисовка ---------- */
    function makeEl(item) {
        var el = h('div', 'md-item');
        var img = h('img'); img.src = imgUrl(item.id); img.alt = item.title; img.loading = 'lazy';
        el.appendChild(img);
        el.appendChild(h('div', 'md-cap', item.title));

        if (!readonly) {
            var del = h('button', 'md-del', '×'); del.type = 'button'; del.title = 'Удалить фото';
            del.addEventListener('click', function (e) { e.stopPropagation(); removePhoto(item); });
            el.appendChild(del);
            if (view === 'album') {
                var out = h('button', 'md-out', '↩'); out.type = 'button'; out.title = 'Убрать из альбома';
                out.addEventListener('click', function (e) { e.stopPropagation(); moveOut(item); });
                el.appendChild(out);
            }
        }
        el.addEventListener('click', function () { openViewer(shown.indexOf(item)); });
        return el;
    }

    function drawGrid() {
        grid.innerHTML = '';
        shown.forEach(function (it) { grid.appendChild(makeEl(it)); });
    }

    function albumCard(a) {
        var card = h('div', 'md-album');
        var cover = h('div', 'md-album-cover');
        if (a.cover) { var im = h('img'); im.src = imgUrl(a.cover); im.alt = ''; im.loading = 'lazy'; cover.appendChild(im); }
        else cover.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5.2-5.2a1.5 1.5 0 0 0-2.1 0L5 19"/></svg>';
        card.appendChild(cover);
        card.appendChild(h('span', 'md-badge floating ' + (a.public ? 'pub' : 'priv'), a.public ? '🌐 Открытый' : '🔒 Закрытый'));
        var info = h('div', 'md-album-info');
        info.appendChild(h('strong', null, a.title));
        info.appendChild(h('small', null, a.count + ' ' + plural(a.count, 'фото', 'фото', 'фото')));
        card.appendChild(info);
        card.addEventListener('click', function () { openAlbum(a.id); });
        return card;
    }

    function drawAlbums() {
        albumsEl.innerHTML = '';
        var list = readonly ? foreign : albums;
        if (!readonly) {
            var add = h('div', 'md-album md-album-new');
            add.innerHTML = '<div class="md-album-plus">+</div>';
            add.appendChild(h('strong', null, 'Новый альбом'));
            add.addEventListener('click', function () { openForm(null); });
            albumsEl.appendChild(add);
        }
        list.forEach(function (a) { albumsEl.appendChild(albumCard(a)); });
        if (!list.length && readonly) albumsEl.appendChild(h('p', 'md-empty', 'У пользователя нет открытых альбомов.'));
    }

    function paint() {
        var inAlbum = view === 'album';
        root.classList.toggle('readonly', readonly);
        tabs.hidden = readonly || inAlbum;
        Array.prototype.forEach.call(tabs.querySelectorAll('button'), function (b) {
            b.classList.toggle('active', b.getAttribute('data-tab') === view);
        });
        ahead.hidden = !inAlbum;
        albumsEl.hidden = view !== 'albums';

        var gridView = view === 'all' || inAlbum;
        var has = shown.length > 0;
        grid.hidden = !(gridView && has);
        toolbar.hidden = !(gridView && has);
        drop.hidden = !(gridView && !has && loaded && !readonly);
        $('mdHeroUpload').hidden = readonly || view === 'albums';
        countEl.innerHTML = shown.length + ' <span>' + plural(shown.length, 'фото', 'фото', 'фото') + '</span>';

        heroTitle.textContent = readonly ? 'Альбомы: ' + ownerName : 'Фото';
        heroSub.textContent = readonly
            ? 'Вы смотрите открытые альбомы другого пользователя.'
            : 'Ваши снимки в одном месте. Перетащите файлы в окно или выберите их на компьютере.';
        note.textContent = (readonly && inAlbum && !has) ? 'В этом альбоме пока нет фото.' : NOTE_DEFAULT;

        if (inAlbum && album) {
            $('mdATitle').textContent = album.title;
            var badge = $('mdABadge');
            badge.textContent = album.public ? '🌐 Открытый' : '🔒 Закрытый';
            badge.className = 'md-badge ' + (album.public ? 'pub' : 'priv');
            $('mdAMeta').textContent = shown.length + ' ' + plural(shown.length, 'фото', 'фото', 'фото') +
                (readonly && ownerName ? ' · ' + ownerName : '');
            $('mdAToggle').textContent = album.public ? 'Сделать закрытым' : 'Сделать открытым';
            $('mdACopy').hidden = !album.public;
            $('mdBack').textContent = readonly ? '← Альбомы автора' : '← Альбомы';
        }
        if (view === 'albums') drawAlbums();
        if (gridView) drawGrid();
    }

    /* ---------- навигация ---------- */
    function showTab(t) {
        view = t; album = null;
        shown = t === 'all' ? photos : [];
        paint();
    }

    function openAlbum(id) {
        var a = findBy(albums, id);
        if (ownLoaded && a && !readonly) {
            album = a; view = 'album'; shown = photosOf(a.id); paint();
            return Promise.resolve();
        }
        return get('api=album_get&id=' + id).then(function (d) {
            loaded = true;
            if (!d.ok) { say(d.error || 'Альбом недоступен', 'err'); paint(); return; }
            if (d.mine) {
                readonly = false;
                return loadOwn().then(function () {
                    var mine = findBy(albums, id);
                    if (!mine) { say('Альбом не найден', 'err'); return; }
                    album = mine; view = 'album'; shown = photosOf(id); paint();
                });
            }
            readonly = true;
            album = d.album; ownerName = d.album.owner || ''; ownerId = d.album.user;
            view = 'album'; shown = d.items; paint();
        }).catch(netErr);
    }

    function showUser(uid) {
        return get('api=user_albums&uid=' + uid).then(function (d) {
            loaded = true;
            if (!d.ok) { say(d.error || 'Не удалось загрузить', 'err'); return; }
            readonly = !d.mine; ownerName = d.owner; ownerId = uid;
            foreign = d.albums; view = 'albums'; shown = []; paint();
        }).catch(netErr);
    }

    $('mdBack').addEventListener('click', function () {
        if (readonly && ownerId) { window.location.href = cfg.api + '?user=' + ownerId; return; }
        showTab('albums');
    });
    Array.prototype.forEach.call(tabs.querySelectorAll('button'), function (b) {
        b.addEventListener('click', function () { showTab(b.getAttribute('data-tab')); });
    });

    /* ---------- действия с фото ---------- */
    function upload(files) {
        if (readonly) return;
        var list = Array.prototype.filter.call(files, function (f) { return /^image\//.test(f.type); });
        if (!list.length) { say('Выберите изображения (JPG, PNG, GIF, WebP)', 'err'); return; }
        if (list.length > 20) { list = list.slice(0, 20); say('За один раз — не больше 20 файлов', 'err'); }

        var fd = new FormData();
        list.forEach(function (f) { fd.append('photos[]', f); });
        fd.append('csrf', cfg.csrf);
        if (view === 'album' && album) fd.append('album_id', album.id);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', cfg.api + '?api=upload');
        xhr.setRequestHeader('X-CSRF-Token', cfg.csrf);
        xhr.upload.addEventListener('progress', function (e) {
            if (e.lengthComputable) say('Загрузка и шифрование… ' + Math.round(e.loaded / e.total * 100) + '%', '', true);
        });
        xhr.addEventListener('load', function () {
            var d; try { d = JSON.parse(xhr.responseText); } catch (e) { d = null; }
            if (!d) { say('Ошибка сервера. Возможно, файлы больше лимита post_max_size в php.ini', 'err'); return; }
            if (!d.ok) { say(d.error || 'Не удалось загрузить', 'err'); return; }
            d.items.slice().reverse().forEach(function (it) { photos.unshift(it); });
            refreshStats();
            shown = view === 'album' && album ? photosOf(album.id) : photos;
            paint();
            if (d.errors && d.errors.length) say(d.errors.slice(0, 3).join('\n'), 'err');
            else say('Загружено и зашифровано: ' + d.items.length, 'ok');
        });
        xhr.addEventListener('error', netErr);
        xhr.send(fd);
    }

    function removePhoto(item) {
        if (!confirm('Удалить это фото без возможности восстановления?')) return;
        post('delete', { id: item.id }).then(function (d) {
            if (!d.ok) { say(d.error || 'Не удалось удалить', 'err'); return; }
            photos.splice(photos.indexOf(item), 1);
            refreshStats();
            shown = view === 'album' && album ? photosOf(album.id) : photos;
            if (viewer.classList.contains('open')) closeViewer();
            paint();
        }).catch(netErr);
    }

    function moveOut(item) {
        post('photo_move', { ids: item.id, album: 0 }).then(function (d) {
            if (!d.ok) { say(d.error || 'Не удалось убрать', 'err'); return; }
            item.album = null; refreshStats();
            shown = photosOf(album.id); paint();
        }).catch(netErr);
    }

    /* ---------- модальные окна ---------- */
    function openModal(node) {
        modalCard.innerHTML = '';
        modalCard.appendChild(node);
        modal.classList.add('open');
    }
    function closeModal() { modal.classList.remove('open'); modalCard.innerHTML = ''; }
    modal.addEventListener('click', function (e) { if (e.target === modal) closeModal(); });

    function btn(text, cls, fn) {
        var b = h('button', 'md-btn ' + (cls || ''), text); b.type = 'button';
        if (fn) b.addEventListener('click', fn);
        return b;
    }

    function openForm(edit) {
        var wrap = h('div');
        wrap.appendChild(h('h3', 'md-modal-title', edit ? 'Изменить альбом' : 'Новый альбом'));

        var inp = h('input', 'md-input'); inp.type = 'text'; inp.maxLength = 80;
        inp.placeholder = 'Название альбома'; inp.value = edit ? edit.title : '';
        wrap.appendChild(inp);

        var opts = h('div', 'md-radios');
        function opt(val, title, desc) {
            var lab = h('label', 'md-radio');
            var r = document.createElement('input'); r.type = 'radio'; r.name = 'mdPriv'; r.value = val;
            var b = h('div'); b.appendChild(h('strong', null, title)); b.appendChild(h('small', null, desc));
            lab.appendChild(r); lab.appendChild(b); opts.appendChild(lab);
            return r;
        }
        var rPriv = opt('0', '🔒 Закрытый', 'Альбом и фото в нём видите только вы. Для остальных он не существует.');
        var rPub = opt('1', '🌐 Открытый', 'Все пользователи сайта смогут смотреть альбом по ссылке.');
        (edit && edit.public ? rPub : rPriv).checked = true;
        wrap.appendChild(opts);

        var row = h('div', 'md-modal-actions');
        row.appendChild(btn('Отмена', 'ghost', closeModal));
        var save = btn(edit ? 'Сохранить' : 'Создать', '', function () {
            var title = inp.value.trim();
            if (!title) { inp.focus(); say('Введите название альбома', 'err'); return; }
            save.disabled = true;
            var data = { title: title, public: rPub.checked ? 1 : 0 };
            if (edit) data.id = edit.id;
            post(edit ? 'album_update' : 'album_create', data).then(function (d) {
                save.disabled = false;
                if (!d.ok) { say(d.error || 'Не удалось сохранить', 'err'); return; }
                closeModal();
                if (edit) {
                    edit.title = d.album.title; edit.public = d.album.public;
                    paint();
                } else {
                    albums.unshift(d.album);
                    openAlbum(d.album.id);
                }
            }).catch(function () { save.disabled = false; netErr(); });
        });
        row.appendChild(save);
        wrap.appendChild(row);
        openModal(wrap);
        setTimeout(function () { inp.focus(); }, 30);
        inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') save.click(); });
    }

    function openPicker() {
        var candidates = photos.filter(function (p) { return p.album !== album.id; });
        var wrap = h('div');
        wrap.appendChild(h('h3', 'md-modal-title', 'Добавить фото в альбом'));
        if (!candidates.length) {
            wrap.appendChild(h('p', 'md-modal-text', 'Других фото пока нет. Загрузите новые кнопкой «Выбрать фото» — они сразу попадут в этот альбом.'));
            var r0 = h('div', 'md-modal-actions'); r0.appendChild(btn('Понятно', '', closeModal)); wrap.appendChild(r0);
            openModal(wrap); return;
        }
        wrap.appendChild(h('p', 'md-modal-text', 'Выберите фото. Если фото уже лежит в другом альбоме, оно будет перенесено.'));
        var pick = h('div', 'md-pick');
        var chosen = [];
        var addBtn;
        candidates.forEach(function (p) {
            var c = h('div', 'md-pick-item');
            var im = h('img'); im.src = imgUrl(p.id); im.alt = p.title; im.loading = 'lazy';
            c.appendChild(im); c.appendChild(h('span', 'md-pick-check', '✓'));
            c.addEventListener('click', function () {
                var i = chosen.indexOf(p.id);
                if (i > -1) chosen.splice(i, 1); else chosen.push(p.id);
                c.classList.toggle('on', i === -1);
                addBtn.textContent = chosen.length ? 'Добавить (' + chosen.length + ')' : 'Добавить';
                addBtn.disabled = !chosen.length;
            });
            pick.appendChild(c);
        });
        wrap.appendChild(pick);
        var row = h('div', 'md-modal-actions');
        row.appendChild(btn('Отмена', 'ghost', closeModal));
        addBtn = btn('Добавить', '', function () {
            if (!chosen.length) return;
            addBtn.disabled = true;
            post('photo_move', { ids: chosen.join(','), album: album.id }).then(function (d) {
                if (!d.ok) { addBtn.disabled = false; say(d.error || 'Не удалось добавить', 'err'); return; }
                chosen.forEach(function (id) { var p = findBy(photos, id); if (p) p.album = album.id; });
                refreshStats(); closeModal();
                shown = photosOf(album.id); paint();
                say('Добавлено фото: ' + chosen.length, 'ok');
            }).catch(function () { addBtn.disabled = false; netErr(); });
        });
        addBtn.disabled = true;
        row.appendChild(addBtn);
        wrap.appendChild(row);
        openModal(wrap);
    }

    /* ---------- кнопки альбома ---------- */
    $('mdAAdd').addEventListener('click', openPicker);
    $('mdARename').addEventListener('click', function () { if (album) openForm(album); });

    $('mdAToggle').addEventListener('click', function () {
        if (!album) return;
        var makePublic = !album.public;
        if (makePublic && !confirm('Сделать альбом открытым? Все пользователи сайта смогут видеть его фото.')) return;
        post('album_update', { id: album.id, public: makePublic ? 1 : 0 }).then(function (d) {
            if (!d.ok) { say(d.error || 'Не удалось изменить доступ', 'err'); return; }
            album.public = d.album.public; paint();
            say(album.public ? 'Альбом открыт для всех' : 'Альбом закрыт — видите только вы', 'ok');
        }).catch(netErr);
    });

    $('mdACopy').addEventListener('click', function () {
        if (!album) return;
        var link = new URL(cfg.api + '?album=' + album.id, window.location.href).href;
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(link).then(function () { say('Ссылка скопирована', 'ok'); },
                function () { window.prompt('Скопируйте ссылку:', link); });
        } else { window.prompt('Скопируйте ссылку:', link); }
    });

    $('mdADel').addEventListener('click', function () {
        if (!album) return;
        if (!confirm('Удалить альбом «' + album.title + '»? Фото останутся в разделе «Все фото».')) return;
        post('album_delete', { id: album.id }).then(function (d) {
            if (!d.ok) { say(d.error || 'Не удалось удалить', 'err'); return; }
            photos.forEach(function (p) { if (p.album === album.id) p.album = null; });
            albums.splice(albums.indexOf(album), 1);
            refreshStats(); showTab('albums');
        }).catch(netErr);
    });

    /* ---------- просмотрщик ---------- */
    function openViewer(i) {
        if (i < 0 || i >= shown.length) return;
        current = i;
        stage.innerHTML = '';
        var it = shown[i];
        var node = h('img'); node.src = imgUrl(it.id); node.alt = it.title;
        stage.appendChild(node);
        vcap.textContent = it.title + '  ·  ' + (i + 1) + ' / ' + shown.length;
        viewer.classList.add('open');
        document.body.style.overflow = 'hidden';
    }
    function closeViewer() {
        viewer.classList.remove('open');
        stage.innerHTML = '';
        document.body.style.overflow = '';
        current = -1;
    }
    function step(d) { if (shown.length > 1) openViewer((current + d + shown.length) % shown.length); }

    viewer.addEventListener('click', function (e) { if (e.target === viewer) closeViewer(); });
    viewer.querySelector('.close').addEventListener('click', closeViewer);
    viewer.querySelector('.prev').addEventListener('click', function (e) { e.stopPropagation(); step(-1); });
    viewer.querySelector('.next').addEventListener('click', function (e) { e.stopPropagation(); step(1); });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            if (modal.classList.contains('open')) closeModal();
            else if (viewer.classList.contains('open')) closeViewer();
        } else if (viewer.classList.contains('open')) {
            if (e.key === 'ArrowLeft') step(-1);
            else if (e.key === 'ArrowRight') step(1);
        }
    });

    /* ---------- загрузка файлов ---------- */
    input.addEventListener('change', function () { upload(input.files); input.value = ''; });
    ['dragenter', 'dragover'].forEach(function (ev) {
        document.addEventListener(ev, function (e) { e.preventDefault(); if (!readonly) drop.classList.add('over'); });
    });
    ['dragleave', 'drop'].forEach(function (ev) {
        document.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); });
    });
    document.addEventListener('drop', function (e) {
        if (view === 'albums' || readonly) return;
        if (e.dataTransfer && e.dataTransfer.files.length) upload(e.dataTransfer.files);
    });

    Array.prototype.forEach.call(document.querySelectorAll('.md-seg button'), function (b) {
        b.addEventListener('click', function () {
            Array.prototype.forEach.call(document.querySelectorAll('.md-seg button'), function (x) { x.classList.remove('active'); });
            b.classList.add('active');
            grid.setAttribute('data-size', b.getAttribute('data-size'));
        });
    });

    /* ---------- старт ---------- */
    drop.hidden = true;
    if (cfg.openAlbum) {
        openAlbum(cfg.openAlbum);
    } else if (cfg.openUser && cfg.openUser !== cfg.me) {
        showUser(cfg.openUser);
    } else {
        loadOwn().then(function () { shown = photos; paint(); });
    }
})();

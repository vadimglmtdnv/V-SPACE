        document.addEventListener('DOMContentLoaded', function() {
            var handle = document.getElementById('handleBtn');
            var nav = document.getElementById('site-navigator');
            if (!handle || !nav) return;
            if (nav.hasAttribute('data-managed-by-partial')) return;

            nav.classList.add('nav-hidden');
            handle.classList.remove('handle-hidden');

            handle.addEventListener('click', function() {
                nav.classList.toggle('nav-hidden');
                handle.classList.toggle('handle-hidden');
            });

            handle.addEventListener('mouseenter', function() {
                nav.classList.remove('nav-hidden');
                handle.classList.add('handle-hidden');
            });

            nav.addEventListener('mouseleave', function() {
                if (!handle.matches(':hover')) {
                    nav.classList.add('nav-hidden');
                    handle.classList.remove('handle-hidden');
                }
            });
        });

        // Шапка как в messages.php: колокольчик уведомлений и меню профиля
        // с подменю темы — открываются по клику, закрываются кликом снаружи.
        document.addEventListener('DOMContentLoaded', function () {
            var notifBtn = document.getElementById('notificationsBtn');
            var notifDropdown = document.getElementById('notificationsDropdown');
            var avatarBtn = document.getElementById('avatarBtn');
            var avatarDropdown = document.getElementById('avatarDropdown');
            var themeTrigger = document.getElementById('themeTrigger');
            var themeSubmenu = document.getElementById('themeSubmenu');
            var themeArrow = document.getElementById('themeArrow');

            function closeNotifications() {
                if (notifDropdown) notifDropdown.classList.remove('open');
            }
            function closeAvatarMenu() {
                if (avatarDropdown) avatarDropdown.classList.remove('open');
                if (themeSubmenu) themeSubmenu.classList.remove('open');
                if (themeArrow) themeArrow.classList.remove('open');
            }

            if (notifBtn && notifDropdown) {
                notifBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    closeAvatarMenu();
                    notifDropdown.classList.toggle('open');
                });
            }

            if (avatarBtn && avatarDropdown) {
                avatarBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    closeNotifications();
                    avatarDropdown.classList.toggle('open');
                });
            }

            if (themeTrigger && themeSubmenu) {
                themeTrigger.addEventListener('click', function (e) {
                    e.stopPropagation();
                    themeSubmenu.classList.toggle('open');
                    if (themeArrow) themeArrow.classList.toggle('open');
                });
            }

            document.addEventListener('click', function (e) {
                if (notifDropdown && !notifDropdown.contains(e.target) && e.target !== notifBtn) {
                    closeNotifications();
                }
                if (avatarDropdown && !avatarDropdown.contains(e.target) && e.target !== avatarBtn) {
                    closeAvatarMenu();
                }
            });
        });

        // Плавная смена темы без перезагрузки страницы.
        // Кука сохраняется запросом ?theme=..., цвета меняются CSS-переходом.
        document.addEventListener('DOMContentLoaded', function () {
            var names = { dark: 'Тёмная', light: 'Светлая', system: 'Системная' };
            var root = document.documentElement;
            var animTimer = null;

            function animateThemeChange() {
                root.classList.add('theme-anim');
                clearTimeout(animTimer);
                animTimer = setTimeout(function () {
                    root.classList.remove('theme-anim');
                }, 500);
            }

            function applyTheme(theme) {
                animateThemeChange();
                document.body.setAttribute('data-theme', theme);

                var current = document.querySelector('.theme-current');
                if (current) current.textContent = names[theme] || names.dark;

                document.querySelectorAll('.theme-item').forEach(function (item) {
                    var itemTheme = (item.getAttribute('href') || '').split('theme=')[1];
                    var isActive = itemTheme === theme;
                    item.classList.toggle('active', isActive);
                    var check = item.querySelector('.theme-check');
                    if (isActive && !check) {
                        check = document.createElement('span');
                        check.className = 'theme-check';
                        check.textContent = '✓';
                        item.appendChild(check);
                    } else if (!isActive && check) {
                        check.remove();
                    }
                });
            }

            document.querySelectorAll('.theme-item').forEach(function (item) {
                item.addEventListener('click', function (e) {
                    var href = item.getAttribute('href') || '';
                    var theme = href.split('theme=')[1];
                    if (!names[theme]) return;
                    e.preventDefault();
                    e.stopPropagation();
                    applyTheme(theme);
                    fetch(href, { credentials: 'same-origin', redirect: 'manual' })
                        .catch(function () { window.location.href = href; });
                });
            });

            // Системная тема: плавно реагируем на смену темы в ОС
            if (window.matchMedia) {
                var mq = window.matchMedia('(prefers-color-scheme: light)');
                var onChange = function () {
                    if (document.body.getAttribute('data-theme') === 'system') animateThemeChange();
                };
                if (mq.addEventListener) mq.addEventListener('change', onChange);
                else if (mq.addListener) mq.addListener(onChange);
            }
        });

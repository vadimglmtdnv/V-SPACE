/* ==========================================================================
   Страница поддержки (support.php)
   Тексты, которые видит пользователь, лежат в разметке (data-* атрибуты),
   а не в этом файле, чтобы их обрабатывал переводчик страницы.
   ========================================================================== */
(function () {
    'use strict';

    var $ = function (selector, root) { return (root || document).querySelector(selector); };
    var $$ = function (selector, root) { return Array.prototype.slice.call((root || document).querySelectorAll(selector)); };

    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ---------- FAQ: один открытый вопрос за раз ---------- */
    function initFaq() {
        var items = $$('.faq-item');
        if (!items.length) return;

        function setOpen(item, open) {
            item.classList.toggle('open', open);
            var button = $('.faq-question', item);
            if (button) button.setAttribute('aria-expanded', open ? 'true' : 'false');
        }

        items.forEach(function (item) {
            var button = $('.faq-question', item);
            if (!button) return;
            button.addEventListener('click', function () {
                var willOpen = !item.classList.contains('open');
                items.forEach(function (other) { setOpen(other, false); });
                setOpen(item, willOpen);
            });
        });
    }

    /* ---------- Форма обращения ---------- */
    function initForm() {
        var form = $('[data-support-form]');
        if (!form) return;

        var subject = $('#subject', form);
        var message = $('#message', form);
        var counter = $('[data-counter]', form);
        var submitBtn = $('.sp-btn', form);
        var chips = $$('[data-subject]', form);

        // Быстрый выбор темы
        function syncChips() {
            chips.forEach(function (chip) {
                chip.setAttribute('aria-pressed', chip.getAttribute('data-subject') === subject.value ? 'true' : 'false');
            });
        }

        chips.forEach(function (chip) {
            chip.addEventListener('click', function () {
                subject.value = chip.getAttribute('data-subject');
                syncChips();
                message.focus();
            });
        });
        subject.addEventListener('input', syncChips);
        syncChips();

        // Автовысота поля и счётчик символов
        function resizeMessage() {
            message.style.height = 'auto';
            var max = parseInt(window.getComputedStyle(message).maxHeight, 10) || 380;
            message.style.height = Math.min(message.scrollHeight, max) + 'px';
            message.style.overflowY = message.scrollHeight > max ? 'auto' : 'hidden';
        }

        function updateCounter() {
            if (!counter) return;
            var max = message.maxLength > 0 ? message.maxLength : 0;
            var len = message.value.length;
            counter.textContent = max ? len + ' / ' + max : String(len);
            counter.classList.toggle('is-near', max > 0 && len >= max * 0.9);
        }

        message.addEventListener('input', function () {
            resizeMessage();
            updateCounter();
        });
        resizeMessage();
        updateCounter();

        // Ctrl/Cmd + Enter отправляет форму
        form.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' && (event.ctrlKey || event.metaKey) && submitBtn) {
                event.preventDefault();
                if (typeof form.requestSubmit === 'function') {
                    form.requestSubmit(submitBtn);
                } else {
                    submitBtn.click();
                }
            }
        });

        // Защита от двойной отправки. Кнопку не отключаем: у неё есть name,
        // и сервер ищет его в $_POST, а отключённые кнопки в запрос не попадают.
        var sending = false;

        form.addEventListener('submit', function (event) {
            if (sending) {
                event.preventDefault();
                return;
            }
            sending = true;
            form.setAttribute('aria-busy', 'true');
            if (submitBtn) submitBtn.classList.add('is-loading');
        });

        // Возврат кнопкой «Назад» из кеша браузера
        window.addEventListener('pageshow', function (event) {
            if (!event.persisted) return;
            sending = false;
            form.removeAttribute('aria-busy');
            if (submitBtn) submitBtn.classList.remove('is-loading');
        });

        // Ссылка «Напишите нам» в блоке FAQ
        $$('[data-focus-form]').forEach(function (trigger) {
            trigger.addEventListener('click', function () {
                form.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
                subject.focus({ preventScroll: true });
            });
        });

        // После отправки показываем результат, даже если он ниже экрана
        var alertBox = $('.sp-alert');
        if (alertBox) {
            alertBox.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
        }
    }

    /* ---------- Список обращений ---------- */
    function initTickets() {
        var tickets = $$('.ticket');
        if (!tickets.length) return;

        // Убираем нижнюю границу у последней видимой записи
        function markEdges() {
            var visible = tickets.filter(function (ticket) { return !ticket.hidden; });
            tickets.forEach(function (ticket) { ticket.classList.remove('is-last'); });
            if (visible.length) visible[visible.length - 1].classList.add('is-last');
        }

        // Фильтр по статусу
        var filterButtons = $$('[data-filter]');
        var emptyFilter = $('[data-empty-filter]');

        filterButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                var value = button.getAttribute('data-filter');
                filterButtons.forEach(function (other) {
                    other.setAttribute('aria-pressed', other === button ? 'true' : 'false');
                });

                var shown = 0;
                tickets.forEach(function (ticket) {
                    var match = value === 'all' || ticket.getAttribute('data-status') === value;
                    ticket.hidden = !match;
                    if (match) shown++;
                });

                if (emptyFilter) emptyFilter.hidden = shown !== 0;
                markEdges();
                clampAll();
            });
        });

        // Длинные сообщения сворачиваются до четырёх строк
        function clampOne(ticket) {
            var text = $('.ticket__text', ticket);
            var more = $('.ticket__more', ticket);
            if (!text || !more || ticket.hidden) return;
            if (more.getAttribute('aria-expanded') === 'true') return;

            text.classList.add('is-clamped');
            var overflows = text.scrollHeight > text.clientHeight + 1;
            if (!overflows) text.classList.remove('is-clamped');
            more.hidden = !overflows;
        }

        function clampAll() {
            tickets.forEach(clampOne);
        }

        $$('.ticket__more').forEach(function (button) {
            button.addEventListener('click', function () {
                var text = $('.ticket__text', button.closest('.ticket'));
                var expand = button.getAttribute('aria-expanded') !== 'true';
                button.setAttribute('aria-expanded', expand ? 'true' : 'false');
                text.classList.toggle('is-clamped', !expand);
                button.textContent = button.getAttribute(expand ? 'data-less' : 'data-more');
            });
        });

        markEdges();
        clampAll();

        var resizeTimer;
        window.addEventListener('resize', function () {
            window.clearTimeout(resizeTimer);
            resizeTimer = window.setTimeout(clampAll, 150);
        });
    }

    function init() {
        initFaq();
        initForm();
        initTickets();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

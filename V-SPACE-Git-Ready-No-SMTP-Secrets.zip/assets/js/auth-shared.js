/**
 * Общий скрипт страниц входа и регистрации.
 *  1. Плавный переход login <-> register (запасной вариант для браузеров без View Transitions)
 *  2. Кнопка «Войти через Google»: передаём «запомнить меня» и часовой пояс, показываем загрузку
 *
 * Подключается в <head> без defer: класс .no-vt должен появиться до первой отрисовки.
 * Все обработчики — через делегирование, поэтому ждать DOMContentLoaded не нужно.
 */
(function () {
    'use strict';

    var root = document.documentElement;
    var nativeTransitions = 'CSSViewTransitionRule' in window;
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Нет нативных переходов -> включаем CSS-анимации появления/ухода карточки
    if (!nativeTransitions) {
        root.classList.add('no-vt');
    }

    function isPlainLeftClick(e) {
        return !e.defaultPrevented && e.button === 0 &&
               !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;
    }

    document.addEventListener('click', function (e) {
        if (!e.target.closest) return;

        // ---------- ссылки «Регистрация» / «Войти» ----------
        var switchLink = e.target.closest('a[data-auth-switch]');
        if (switchLink) {
            // с нативными переходами браузер всё сделает сам
            if (nativeTransitions || reduceMotion) return;
            if (!isPlainLeftClick(e) || switchLink.target === '_blank') return;

            e.preventDefault();
            root.classList.add('auth-leaving');
            setTimeout(function () {
                window.location.href = switchLink.href;
            }, 260);
            return;
        }

        // ---------- кнопка Google ----------
        var googleBtn = e.target.closest('a[data-google-login]');
        if (googleBtn) {
            var url = new URL(googleBtn.getAttribute('href'), window.location.href);

            // «Запомнить меня» есть только на странице входа
            var remember = document.getElementById('remember');
            if (remember && remember.checked) {
                url.searchParams.set('remember', '1');
            }

            // часовой пояс нужен, если Google-вход создаст новый аккаунт
            try {
                var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
                if (tz) url.searchParams.set('tz', tz);
            } catch (err) { /* не критично */ }

            googleBtn.href = url.toString();

            if (isPlainLeftClick(e)) {
                googleBtn.classList.add('is-loading');
                googleBtn.setAttribute('aria-busy', 'true');
            }
        }
    });

    // Вернулись кнопкой «Назад» (страница из bfcache) — сбрасываем состояния
    window.addEventListener('pageshow', function (e) {
        if (!e.persisted) return;
        root.classList.remove('auth-leaving');
        var btn = document.querySelector('a[data-google-login]');
        if (btn) {
            btn.classList.remove('is-loading');
            btn.removeAttribute('aria-busy');
        }
    });
})();

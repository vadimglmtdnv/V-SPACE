/* nav-bubble.js — при наведении под пунктом панели навигации загорается красная «космическая» полоска,
   которая плавно переезжает от пункта к пункту. Пункты не двигаются.
   Нужен assets/css/nav-bubble.css. Отключается на экранах до 640px, без мыши и в положении «слева». */
(function () {
    'use strict';

    var INSET = 6;   // полоска чуть уже пункта с каждой стороны, px

    var mq = window.matchMedia('(min-width: 641px) and (hover: hover) and (pointer: fine)');
    var nav, disc, cur = null, visible = false;

    function attr(name) {
        var el = document.querySelector('[' + name + ']');
        return el ? el.getAttribute(name) : '';
    }
    function pos() { var p = attr('data-nav-pos') || 'bottom'; return p === 'top' ? 'top' : (p === 'bottom' ? 'bottom' : ''); }
    function items() { return Array.prototype.slice.call(nav.querySelectorAll('.nav-item')); }
    function isHidden() { return nav.classList.contains('nav-hidden'); }

    function enabled() { return mq.matches && !!pos() && document.documentElement.getAttribute('data-nm-style') === 'labels'; }

    function sync() {
        if (enabled()) nav.classList.add('nb-on');
        else { setHover(null); nav.classList.remove('nb-on'); }
    }

    // Положение пункта в координатах панели (от внутреннего края рамки — туда же привязана absolute-полоска)
    function geom(item) {
        var left = 0, el = item;
        while (el && el !== nav) { left += el.offsetLeft; el = el.offsetParent; }
        if (el !== nav) {
            var a = item.getBoundingClientRect(), n = nav.getBoundingClientRect();
            left = a.left - n.left - nav.clientLeft;
        }
        return { left: left + INSET, width: Math.max(16, item.offsetWidth - 2 * INSET), down: pos() === 'top' };
    }

    function place(g) {
        disc.style.left = g.left + 'px';
        disc.style.width = g.width + 'px';
        disc.setAttribute('data-dir', g.down ? 'down' : 'up');
    }

    function setHover(item) {
        if (item === cur) return;
        if (cur) cur.classList.remove('nb-up');
        cur = item;
        if (!item) {
            visible = false;
            disc.classList.remove('show');
            return;
        }
        var g = geom(item);
        if (!visible) {                                      // полоска появляется — без «заезда» со старого места
            disc.style.transition = 'none';
            place(g);
            void disc.offsetWidth;
            disc.style.transition = '';
            visible = true;
        } else {
            place(g);                                        // уже виден — плавно переезжает к соседнему пункту
        }
        disc.classList.add('show');
        item.classList.add('nb-up');
    }

    function onMove(e) {
        if (!enabled() || isHidden()) return;
        var r = nav.getBoundingClientRect();
        // определяем пункт под курсором по горизонтали
        if (e.clientY >= r.top && e.clientY <= r.bottom) {
            var hit = null, list = items();
            for (var i = 0; i < list.length; i++) {
                var b = list[i].getBoundingClientRect();
                if (e.clientX >= b.left - 6 && e.clientX <= b.right + 6) { hit = list[i]; break; }
            }
            setHover(hit);
        }
    }

    function init() {
        nav = document.getElementById('site-navigator');
        if (!nav) return;
        disc = document.createElement('div'); disc.className = 'nb-disc'; disc.setAttribute('aria-hidden', 'true');
        nav.insertBefore(disc, nav.firstChild);

        nav.addEventListener('mousemove', onMove);
        nav.addEventListener('mouseleave', function () { setHover(null); });
        nav.addEventListener('focusin', function (e) {       // с клавиатуры (Tab) тоже подсвечиваем
            var it = e.target.closest && e.target.closest('.nav-item');
            if (it && enabled() && !isHidden() && it.matches(':focus-visible')) setHover(it);
        });
        nav.addEventListener('focusout', function () { if (!nav.contains(document.activeElement)) setHover(null); });

        new MutationObserver(function () { if (isHidden()) setHover(null); })
            .observe(nav, { attributes: true, attributeFilter: ['class'] });
        window.addEventListener('resize', function () { if (cur) { var c = cur; cur = null; setHover(c); } });
        new MutationObserver(sync).observe(document.documentElement, { attributes: true, attributeFilter: ['data-nm-style'] });
        if (mq.addEventListener) mq.addEventListener('change', sync); else if (mq.addListener) mq.addListener(sync);
        sync();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();

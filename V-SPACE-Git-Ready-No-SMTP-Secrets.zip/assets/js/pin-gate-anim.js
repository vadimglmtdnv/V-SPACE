/* pin-gate-anim.js — анимация входа по PIN-коду на экране «Доступ к модерации» (reports.php).
   Форма уходит на сервер запросом в фоне. Если PIN верный — 4 клеточки «крутятся» со случайными цифрами
   (настоящий PIN на экране не показывается), затем «Отлично! Добро пожаловать» и переход в панель.
   Если неверный — красная обводка, тряска и сообщение об ошибке прямо на этом экране.
   Без JS или в старом браузере форма работает как обычно. */
(function () {
    'use strict';

    var form = document.querySelector('form.pin-card');
    if (!form || !window.fetch || !window.FormData) return;
    var input = form.querySelector('input[name="pin"]');
    if (!input || !form.querySelector('input[name="pin_gate_unlock"]')) return;   // только экран ввода, не создание PIN

    var STOP_FIRST = 950;      // когда останавливается первая клеточка, мс
    var STOP_STEP = 230;       // следующие — позже на столько
    var AFTER_LAST = 450;      // пауза после последней клеточки до «Отлично!»
    var HOLD_OK = 1000;        // сколько показывать «Добро пожаловать» до перехода
    var CHECK_SVG = '<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>';

    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var busy = false;
    var btn = form.querySelector('.pin-submit');
    var btnText = btn ? btn.textContent : '';

    function rnd() { return String(Math.floor(Math.random() * 10)); }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (busy) return;
        busy = true;
        form.classList.add('is-busy');
        if (btn) { btn.disabled = true; btn.textContent = 'Проверка…'; }

        fetch(form.getAttribute('action') || window.location.href, {
            method: 'POST',
            body: new FormData(form),
            headers: { 'X-Requested-With': 'fetch', 'Accept': 'application/json' },
            credentials: 'same-origin'
        })
        .then(function (r) { return r.json(); })
        .then(function (d) { if (d && d.ok) success(); else fail(d && d.error ? d.error : 'Не удалось проверить PIN-код.'); })
        .catch(function () { window.location.reload(); });      // что-то пошло не так (сессия, токен) — обычная перезагрузка
    });

    function fail(msg) {
        busy = false;
        form.classList.remove('is-busy');
        if (btn) { btn.disabled = false; btn.textContent = btnText; }

        var err = form.querySelector('.pin-error');
        if (!err) {
            err = document.createElement('div');
            err.className = 'pin-error';
            err.setAttribute('role', 'alert');
            form.insertBefore(err, form.querySelector('.pin-label'));
        }
        err.textContent = msg;

        form.classList.remove('has-error'); void form.offsetWidth; form.classList.add('has-error');   // тряска карточки
        var wrap = form.querySelector('.pin-cells');
        if (wrap) {
            wrap.classList.remove('is-error'); void wrap.offsetWidth; wrap.classList.add('is-error');
            setTimeout(function () { wrap.classList.remove('is-error'); }, 700);
        }
        input.value = '';
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.focus();
    }

    function success() {
        var wrap = form.querySelector('.pin-cells');
        var cells = wrap ? [].slice.call(wrap.querySelectorAll('.pin-cell')) : [];
        var h1 = form.querySelector('h1');
        var sub = form.querySelector('.pin-sub');
        var icon = form.querySelector('.pin-icon');
        var welcome = form.getAttribute('data-welcome') || 'Добро пожаловать!';

        input.readOnly = true;
        input.blur();
        if (btn) btn.textContent = 'Проверка…';

        function showOk() {
            form.classList.add('is-ok');
            if (h1) h1.textContent = 'Отлично!';
            if (sub) sub.textContent = welcome;
            if (icon) icon.innerHTML = CHECK_SVG;
            setTimeout(function () { window.location.replace('reports.php'); }, reduce ? 500 : HOLD_OK);
        }

        if (reduce || !cells.length) { showOk(); return; }

        form.classList.add('is-spinning');
        wrap.classList.add('is-spinning');
        if (sub) sub.textContent = 'Проверяем PIN-код…';

        var timers = [];
        var scramble = setInterval(function () {
            cells.forEach(function (c) { if (!c.classList.contains('ok')) c.textContent = rnd(); });
        }, 70);

        cells.forEach(function (c, i) {
            c.style.setProperty('--i', i);
            c.classList.remove('active');
            c.textContent = rnd();
            timers.push(setTimeout(function () {
                c.textContent = rnd();
                c.classList.add('ok');
            }, STOP_FIRST + i * STOP_STEP));
        });

        setTimeout(function () {
            clearInterval(scramble);
            showOk();
        }, STOP_FIRST + (cells.length - 1) * STOP_STEP + AFTER_LAST);
    }
})();

(function () {
    if (window.__headerMenusBound) return;
    window.__headerMenusBound = true;

    var openClasses = ['active', 'show', 'open'];

    function byId(id) {
        return document.getElementById(id);
    }

    function isOpen(element) {
        return !!element && openClasses.some(function (className) {
            return element.classList.contains(className);
        });
    }

    function setOpen(element, open) {
        if (!element) return;
        openClasses.forEach(function (className) {
            element.classList.toggle(className, open);
        });
    }

    function setExpanded(element, open) {
        if (element) element.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    function closeNotifications() {
        setOpen(byId('notificationsDropdown'), false);
        setExpanded(byId('notificationsBtn'), false);
    }

    function closeProfile() {
        setOpen(byId('avatarDropdown'), false);
        setOpen(byId('themeSubmenu'), false);
        setOpen(byId('themeArrow'), false);
        setOpen(document.querySelector('.dropdown-overlay'), false);
        setExpanded(byId('avatarBtn'), false);
        setExpanded(byId('themeTrigger'), false);
    }

    function toggleNotifications() {
        var dropdown = byId('notificationsDropdown');
        if (!dropdown) return;
        var open = !isOpen(dropdown);
        closeProfile();
        setOpen(dropdown, open);
        setExpanded(byId('notificationsBtn'), open);
        if (open) {
            document.dispatchEvent(new CustomEvent('vspace:notifications-open'));
        }
    }

    function toggleProfile() {
        var dropdown = byId('avatarDropdown');
        if (!dropdown) return;
        var open = !isOpen(dropdown);
        closeNotifications();
        setOpen(dropdown, open);
        setOpen(document.querySelector('.dropdown-overlay'), open);
        setExpanded(byId('avatarBtn'), open);
        if (!open) closeProfile();
    }

    document.addEventListener('click', function (event) {
        var target = event.target;
        if (!target || !target.closest) return;

        var handler = null;
        if (target.closest('#notificationsBtn')) handler = toggleNotifications;
        else if (target.closest('#avatarBtn')) handler = toggleProfile;

        if (handler) {
            event.preventDefault();
            event.stopImmediatePropagation();
            handler();
            return;
        }

        if (!target.closest('#notificationsDropdown')) closeNotifications();
        if (!target.closest('#avatarDropdown')) closeProfile();
    }, true);

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closeNotifications();
            closeProfile();
        }
    });
})();

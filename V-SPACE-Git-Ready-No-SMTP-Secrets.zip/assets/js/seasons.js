/* Сезоны и праздники: частицы + плашка с поздравлением.
   Читает data-атрибуты <body>, которые выставляет includes/seasons.php. */
(function () {
    'use strict';

    var THEMES = {
        winter:    { emoji: ['❄', '❅', '❆'],            count: 28, size: [12, 24], dur: [10, 18] },
        spring:    { emoji: ['🌸', '🌷', '🍃'],          count: 20, size: [14, 22], dur: [11, 18] },
        summer:    { emoji: ['✨', '☀'],                  count: 12, size: [12, 20], dur: [10, 16], mode: 'rise', butterflies: true },
        autumn:    { kind: 'leaf', count: 34, size: [24, 46], dur: [11, 20] },
        newyear:   { emoji: ['❄', '🎄', '⭐', '🎁'],      count: 30, size: [14, 24], dur: [9, 16] },
        march8:    { emoji: ['🌷', '🌸', '💐', '🌹'],    count: 24, size: [16, 26], dur: [10, 17] },
        mayday:    { emoji: ['🌿', '🌼', '🍃', '🎈'],    count: 20, size: [16, 24], dur: [10, 17] },
        knowledge: { emoji: ['📚', '✏️', '🍎', '🔔'],    count: 18, size: [16, 26], dur: [10, 17] },
        halloween: { emoji: ['🎃', '🦇', '👻', '🕸️'],    count: 24, size: [18, 30], dur: [9, 16] }
    };

    // Случайность для РИСУНКА гирлянд фиксирована (одинакова после F5 и при изменении размера окна);
    // падающие частицы и движение по-прежнему случайные.
    var rnd = Math.random;
    function rand(a, b) { return a + rnd() * (b - a); }
    function withSeed(seed, fn) {
        var old = rnd, s = seed >>> 0;
        rnd = function () {
            s = (s + 0x6D2B79F5) >>> 0;
            var t = s;
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
        try { return fn(); } finally { rnd = old; }
    }


    /* ---------- Осенняя листва (SVG, переливается цветами) ---------- */
    var LEAF_COLORS = ['#d9541e', '#e8a020', '#b5361b', '#c98a2b', '#e0701f', '#9c4a1a', '#f0b429'];
    var LEAF_SHAPES = [
        // клён
        '<path d="M12 2l2.2 4.4 3.9-1.3-1 4.7 4.1 1.3-3.3 2.9 1.3 3.5-4.3-.7L12 22l-.9-6.6-4.3.7 1.3-3.5L4.8 9.8l4.1-1.3-1-4.7 3.9 1.3z"/>',
        // берёза / ольха
        '<path d="M12 2C18.5 6.5 19.5 14.5 12 22 4.5 14.5 5.5 6.5 12 2z"/><path d="M12 5v16" stroke="rgba(0,0,0,.28)" stroke-width="1" fill="none"/>',
        // дуб
        '<path d="M12 2c2 1.5 2.5 3 2 4.5 2-.5 3.5.5 3.5 2.2 1.8.3 2.5 1.8 1.7 3.2 1.3 1.3.8 3.3-1.2 3.8-.2 2.3-2.6 3.3-4.5 2.4V22h-3v-3.9c-2 .9-4.3-.1-4.5-2.4-2-.5-2.5-2.5-1.2-3.8-.8-1.4-.1-2.9 1.7-3.2 0-1.7 1.5-2.7 3.5-2.2-.5-1.5 0-3 2-4.5z"/>'
    ];

    function makeLeaf(p, size, colors) {
        var pal = colors || LEAF_COLORS;
        var c = pal[Math.floor(Math.random() * pal.length)];
        var shape = LEAF_SHAPES[Math.floor(Math.random() * LEAF_SHAPES.length)];
        p.className += ' is-leaf';
        p.style.setProperty('--tumble', rand(1.8, 4).toFixed(1) + 's');
        p.innerHTML = '<span class="leaf-in"><svg viewBox="0 0 24 24" width="' + size + '" height="' + size +
            '" fill="' + c + '" aria-hidden="true">' + shape + '</svg></span>';
    }

    /* ---------- Летние бабочки: улетают, если подвести курсор ---------- */
    var BF_COLORS = [['#f59e0b', '#fde68a'], ['#3b82f6', '#bfdbfe'], ['#ec4899', '#fbcfe8'], ['#8b5cf6', '#ddd6fe'], ['#14b8a6', '#99f6e4'], ['#ef4444', '#fecaca']];
    var BF_SVG = '<svg viewBox="0 0 40 40" width="100%" height="100%" aria-hidden="true">' +
        '<g class="bf-wing bf-l"><path class="bf-up" d="M20 19C13 3 2 5 3 15c1 7 9 8 17 4z"/><path class="bf-low" d="M20 21c-7 1-14 7-10 13 4 3 9-3 10-13z"/></g>' +
        '<g class="bf-wing bf-r"><path class="bf-up" d="M20 19C27 3 38 5 37 15c-1 7-9 8-17 4z"/><path class="bf-low" d="M20 21c7 1 14 7 10 13-4 3-9-3-10-13z"/></g>' +
        '<ellipse cx="20" cy="21" rx="1.6" ry="9" fill="#2b2230"/>' +
        '<path d="M19.5 12C17 7 15 6 14 6M20.5 12C23 7 25 6 26 6" stroke="#2b2230" stroke-width="1" fill="none" stroke-linecap="round"/></svg>';

    function initButterflies() {
        var wrap = document.createElement('div');
        wrap.className = 'season-butterflies';
        wrap.setAttribute('aria-hidden', 'true');
        document.body.appendChild(wrap);

        var W = window.innerWidth, H = window.innerHeight;
        var N = W < 640 ? 5 : 9;
        var R = 120;                       // радиус «испуга» вокруг курсора, px
        var mouse = { x: -9999, y: -9999 };
        var list = [];

        function spawn(b, edge) {
            if (edge) {
                var side = Math.floor(Math.random() * 4);
                b.x = side === 0 ? -50 : side === 1 ? W + 50 : rand(0, W);
                b.y = side === 2 ? -50 : side === 3 ? H + 50 : rand(0, H);
            } else {
                b.x = rand(30, W - 30); b.y = rand(60, H - 30);
            }
            b.state = 'wander';
            b.vx = 0; b.vy = 0;
            pick(b);
            b.el.classList.remove('is-scared');
        }
        function pick(b) { b.tx = rand(30, W - 30); b.ty = rand(60, H - 30); b.sp = rand(0.5, 1.1); }

        for (var i = 0; i < N; i++) {
            var el = document.createElement('div');
            el.className = 'season-butterfly';
            var col = BF_COLORS[i % BF_COLORS.length];
            var sz = rand(36, 54);
            el.style.width = el.style.height = sz.toFixed(0) + 'px';
            el.style.setProperty('--c1', col[0]);
            el.style.setProperty('--c2', col[1]);
            el.style.setProperty('--flap', rand(0.22, 0.34).toFixed(2) + 's');
            el.innerHTML = BF_SVG;
            wrap.appendChild(el);
            var b = { el: el, sz: sz, t: rand(0, 6), timer: 0 };
            spawn(b, false);
            list.push(b);
        }

        function setMouse(e) {
            var pt = e.touches && e.touches[0] ? e.touches[0] : e;
            mouse.x = pt.clientX; mouse.y = pt.clientY;
        }
        window.addEventListener('mousemove', setMouse, { passive: true });
        window.addEventListener('touchstart', setMouse, { passive: true });
        window.addEventListener('touchmove', setMouse, { passive: true });
        window.addEventListener('mouseout', function (e) { if (!e.relatedTarget) { mouse.x = mouse.y = -9999; } });
        window.addEventListener('resize', function () { W = window.innerWidth; H = window.innerHeight; });

        var last = performance.now();
        function tick(now) {
            var k = Math.min(3, (now - last) / 16.67); last = now;
            for (var i = 0; i < list.length; i++) {
                var b = list[i];
                if (b.state === 'gone') {
                    b.timer -= (k * 16.67);
                    if (b.timer <= 0) spawn(b, true);
                    continue;
                }
                var dx = b.x + b.sz / 2 - mouse.x, dy = b.y + b.sz / 2 - mouse.y;
                var d = Math.sqrt(dx * dx + dy * dy);
                if (b.state === 'wander' && d < R) {          // испугалась — улетает прочь от курсора
                    var a = Math.atan2(dy, dx) + rand(-0.5, 0.5);
                    b.vx = Math.cos(a) * 7; b.vy = Math.sin(a) * 7;
                    b.state = 'flee';
                    b.el.classList.add('is-scared');
                }
                if (b.state === 'flee') {
                    b.x += b.vx * k; b.y += b.vy * k;
                    if (b.x < -80 || b.x > W + 80 || b.y < -80 || b.y > H + 80) {
                        b.state = 'gone'; b.timer = rand(1500, 4500);
                        b.el.style.opacity = '0';
                        continue;
                    }
                } else {                                        // спокойно порхает от точки к точке
                    var tx = b.tx - b.x, ty = b.ty - b.y, td = Math.sqrt(tx * tx + ty * ty);
                    if (td < 20) pick(b);
                    else {
                        b.vx += (tx / td * b.sp * 1.6 - b.vx) * 0.04 * k;
                        b.vy += (ty / td * b.sp * 1.6 - b.vy) * 0.04 * k;
                    }
                    b.t += 0.06 * k;
                    b.x += (b.vx + Math.cos(b.t * 2) * 0.5) * k;
                    b.y += (b.vy + Math.sin(b.t * 3) * 0.6) * k;
                }
                b.el.style.opacity = '';
                var ang = Math.atan2(b.vy, b.vx) * 180 / Math.PI + 90;
                b.el.style.transform = 'translate3d(' + b.x.toFixed(1) + 'px,' + b.y.toFixed(1) + 'px,0) rotate(' + ang.toFixed(0) + 'deg)';
            }
            requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    /* ---------- Ёлочка рядом с логотипом (Новый год) ---------- */
    var TREE_SVG = '<svg viewBox="0 0 28 36" height="100%" aria-hidden="true">' +
        '<polygon points="14,0.5 16,5.5 21.5,5.8 17.3,9.3 18.8,14.6 14,11.7 9.2,14.6 10.7,9.3 6.5,5.8 12,5.5" fill="#ffd54a"/>' +
        '<polygon points="14,6 22,17 6,17" fill="#2fb868"/>' +
        '<polygon points="14,11 24,24 4,24" fill="#27a05a"/>' +
        '<polygon points="14,17 26,31 2,31" fill="#1f8a4c"/>' +
        '<rect x="12" y="31" width="4" height="5" rx="1" fill="#7a4a24"/>' +
        '<circle class="tl a" cx="12" cy="14" r="1.5" fill="#ff5252"/>' +
        '<circle class="tl b" cx="17" cy="21" r="1.5" fill="#4fc3f7"/>' +
        '<circle class="tl c" cx="10" cy="24" r="1.5" fill="#ffd54a"/>' +
        '<circle class="tl a" cx="19" cy="28" r="1.5" fill="#ff80ab"/>' +
        '<circle class="tl b" cx="8" cy="29" r="1.5" fill="#fff"/>' +
        '<circle class="tl c" cx="14" cy="27" r="1.5" fill="#ff5252"/></svg>';

    function addTree() {
        var logo = document.querySelector('.logo');
        if (!logo || logo.querySelector('.season-tree')) return;
        var t = document.createElement('span');
        t.className = 'season-tree';
        t.setAttribute('aria-hidden', 'true');
        t.innerHTML = TREE_SVG;
        logo.appendChild(t);
    }

    /* ================= Праздничные сцены (нарисованы вручную) =================
       У каждого праздника своя механика, а не одни и те же падающие эмодзи:
       Новый год — гирлянда, снег в три слоя, сугробы
       Хэллоуин  — луна, летучие мыши, паутина с паучком, туман, тыквы
       1 Мая     — флажки, воздушные шарики, лозунг, зелёные листья
       1 сентября — тетрадный лист, мел, бумажные самолётики, звонок, букет
    */
    var SVGNS = 'http://www.w3.org/2000/svg';

    function sv(tag, attrs, parent) {
        var n = document.createElementNS(SVGNS, tag);
        for (var k in attrs) { if (attrs.hasOwnProperty(k)) n.setAttribute(k, attrs[k]); }
        if (parent) parent.appendChild(n);
        return n;
    }
    function hd(cls, parent, html) {
        var d = document.createElement('div');
        d.className = cls;
        if (html) d.innerHTML = html;
        if (parent) parent.appendChild(d);
        return d;
    }
    function choice(a) { return a[Math.floor(rnd() * a.length)]; }
    function isSmall() { return window.innerWidth < 640; }
    function motionOff() {
        return !document.body.hasAttribute('data-season-force') &&
            !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    }
    function scene(name) {
        var s = hd('season-fx sx-scene sx-' + name, document.body);
        s.setAttribute('aria-hidden', 'true');
        return s;
    }
    function onResize(fn) {
        var t;
        window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(fn, 150); });
    }
    function clearNode(n) { while (n.firstChild) n.removeChild(n.firstChild); }

    // Верёвка, провисающая дугами. Возвращает путь и точки с углом касательной.
    function ropePoints(W, seg, sag, y0, perSeg) {
        var pts = [], d = 'M-10 ' + y0, n = Math.ceil((W + 20) / seg);
        for (var i = 0; i < n; i++) {
            var x0 = -10 + i * seg, x1 = x0 + seg, cx = (x0 + x1) / 2, cy = y0 + sag * 2;
            d += ' Q' + cx + ' ' + cy + ' ' + x1 + ' ' + y0;
            for (var j = 0; j < perSeg; j++) {
                var t = (j + 0.5) / perSeg, u = 1 - t;
                pts.push({
                    x: u * u * x0 + 2 * u * t * cx + t * t * x1,
                    y: u * u * y0 + 2 * u * t * cy + t * t * y0,
                    a: Math.atan2(2 * u * (cy - y0) + 2 * t * (y0 - cy), 2 * u * (cx - x0) + 2 * t * (x1 - cx)) * 180 / Math.PI
                });
            }
        }
        return { d: d, pts: pts };
    }
    // Слой поверх шапки сайта (гирлянда, флажки)
    function topLayer(cls, h) {
        var w = document.createElementNS(SVGNS, 'svg');
        w.setAttribute('class', 'sx-top ' + cls);
        w.setAttribute('aria-hidden', 'true');
        w.setAttribute('width', '100%');
        w.setAttribute('height', h);
        document.body.appendChild(w);
        return w;
    }
    function fallingLeaves(s, colors, count, lo, hi) {
        for (var i = 0; i < count; i++) {
            var p = hd('season-particle', s), size = rand(lo, hi);
            makeLeaf(p, size.toFixed(0), colors);
            p.style.setProperty('--x', rand(0, 100).toFixed(1) + '%');
            p.style.setProperty('--o', rand(0.6, 0.95).toFixed(2));
            p.style.setProperty('--dur', rand(12, 20).toFixed(1) + 's');
            p.style.setProperty('--delay', (-rand(0, 20)).toFixed(1) + 's');
            p.style.setProperty('--sway', rand(15, 45).toFixed(0) + 'px');
            p.style.setProperty('--sway-dur', rand(3, 6).toFixed(1) + 's');
            p.style.setProperty('--spin', (rand(60, 200) * (Math.random() < 0.5 ? -1 : 1)).toFixed(0) + 'deg');
        }
    }

    /* ---------- НОВЫЙ ГОД ---------- */
    // Слой, который крепится к нижнему краю шапки и свисает вниз
    function headerHang() {
        var hdr = document.querySelector('.header');
        var layer = hd('sx-hang-layer', null);
        layer.setAttribute('aria-hidden', 'true');
        var svg = document.createElementNS(SVGNS, 'svg');
        layer.appendChild(svg);
        if (hdr) {
            if (getComputedStyle(hdr).position === 'static') hdr.style.position = 'relative';
            hdr.style.setProperty('overflow', 'visible', 'important');
            hdr.appendChild(layer);
        } else {
            layer.className += ' is-fixed';
            document.body.appendChild(layer);
        }
        return svg;
    }
    function drawGarland(svg) { return withSeed(101, function () { return drawGarlandRaw(svg); }); }
    function drawGarlandRaw(svg) {
        clearNode(svg);
        var W = window.innerWidth, seg = isSmall() ? 120 : 190;
        svg.setAttribute('width', W);
        svg.setAttribute('height', 70);
        var r = ropePoints(W, seg, 15, 3, isSmall() ? 3 : 4);
        sv('path', { d: r.d, fill: 'none', stroke: '#173a28', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, svg);
        var cols = ['#ff4d4d', '#ffd34d', '#4dd0ff', '#7dff6b', '#ff7ad9'];
        r.pts.forEach(function (p, i) {
            var g = sv('g', { transform: 'translate(' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ') rotate(' + (p.a * 0.6).toFixed(1) + ') scale(.85)' }, svg);
            var c = cols[i % cols.length];
            sv('rect', { x: -2.5, y: -1, width: 5, height: 6, rx: 1, fill: '#1d1d1d' }, g);
            var b = sv('path', { d: 'M0 4C-7 8-8 18 0 23 8 18 7 8 0 4z', fill: c, 'class': 'sx-bulb sx-b' + (i % 3) }, g);
            b.style.setProperty('--c', c);
            sv('ellipse', { cx: -2.4, cy: 11, rx: 1.4, ry: 3, fill: 'rgba(255,255,255,.55)' }, g);
        });
    }
    function sceneNewYear() {
        var s = scene('newyear'), n = isSmall() ? 34 : 70;
        for (var i = 0; i < n; i++) {
            var layer = i % 3;                         // 0 — далёкие, 1 — средние, 2 — ближние (размытые)
            var size = layer === 0 ? rand(2, 4) : layer === 1 ? rand(4, 7) : rand(9, 14);
            var f = hd('sx-flake', s);
            f.style.setProperty('--x', rand(0, 100).toFixed(1) + '%');
            f.style.setProperty('--s', size.toFixed(1) + 'px');
            f.style.setProperty('--o', (layer === 0 ? rand(0.4, 0.6) : layer === 1 ? rand(0.6, 0.85) : rand(0.5, 0.75)).toFixed(2));
            f.style.setProperty('--dur', (layer === 0 ? rand(16, 24) : layer === 1 ? rand(10, 15) : rand(6, 9)).toFixed(1) + 's');
            f.style.setProperty('--delay', (-rand(0, 24)).toFixed(1) + 's');
            f.style.setProperty('--sway', rand(10, 40).toFixed(0) + 'px');
            f.style.setProperty('--sway-dur', rand(3, 6).toFixed(1) + 's');
            f.style.setProperty('--spin', '0deg');
            if (layer === 2) f.style.filter = 'blur(1.6px)';
        }
        hd('sx-drifts', s,
            '<svg viewBox="0 0 1200 80" preserveAspectRatio="none" width="100%" height="100%">' +
            '<path d="M0 80V46C120 20 240 52 380 38S640 14 800 40 1060 24 1200 42V80z" fill="#cfe0f3" opacity=".9"/>' +
            '<path d="M0 80V62C150 44 300 66 460 56S780 40 920 58 1120 52 1200 60V80z" fill="#fff"/></svg>');
        var g = headerHang();                 // гирлянда висит под шапкой, а не на ней
        drawGarland(g);
        onResize(function () { drawGarland(g); });
    }

    /* ---------- ХЭЛЛОУИН ---------- */
    // Летучая мышь спереди: тело + два крыла, которые машут вокруг «плеча» (30,13)
    var BAT_WING = 'M31 11C38 4 48 2 59 5C56 7 55 10 54 13C52 11 49 11 47 14C45 12 42 12 40 16C38 14 35 15 32 19Z';
    function aWeb() {
        var d = '', i, k, R = 188, ang = [0, 18, 36, 54, 72, 90], rad = [38, 72, 106, 140, 174];
        function P(r, a) { var t = a * Math.PI / 180; return [r * Math.cos(t), r * Math.sin(t)]; }
        for (i = 0; i < ang.length; i++) { var e = P(R, ang[i]); d += 'M0 0L' + e[0].toFixed(1) + ' ' + e[1].toFixed(1); }
        for (k = 0; k < rad.length; k++) {
            for (i = 0; i < ang.length - 1; i++) {
                var p1 = P(rad[k], ang[i]), p2 = P(rad[k], ang[i + 1]), c = P(rad[k] * 0.86, (ang[i] + ang[i + 1]) / 2);
                d += 'M' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) + 'Q' + c[0].toFixed(1) + ' ' + c[1].toFixed(1) + ' ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1);
            }
        }
        return '<svg viewBox="0 0 190 190" width="190" height="190"><path d="' + d + '" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="1.1" stroke-linecap="round"/></svg>';
    }
    function aPumpkin(w) {
        return '<svg viewBox="0 0 120 100" width="' + w + '" height="' + (w * 100 / 120) + '">' +
            '<ellipse cx="38" cy="58" rx="30" ry="34" fill="#d9650f"/><ellipse cx="82" cy="58" rx="30" ry="34" fill="#d9650f"/>' +
            '<ellipse cx="60" cy="56" rx="30" ry="38" fill="#f08a24"/>' +
            '<path d="M44 20C36 45 36 70 44 94M76 20C84 45 84 70 76 94" fill="none" stroke="#a8480a" stroke-width="2" opacity=".55"/>' +
            '<path d="M56 20C54 10 58 5 67 3L65 12C63 14 63 18 65 20z" fill="#4a6b2a"/>' +
            '<g class="sx-pk-face"><path d="M40 52L52 52 46 38zM68 52L80 52 74 38zM56 60L64 60 60 53z"/>' +
            '<path d="M36 66Q60 90 84 66L77 66 73 73 67 66 60 75 53 66 47 73 43 66z"/></g></svg>';
    }
    function sceneHalloween() {
        var s = scene('halloween'), i;
        var back = scene('halloween-back');   // слой позади текста: луна, паутина, паук
        hd('sx-moon', back,
            '<svg viewBox="0 0 130 130" width="120" height="120"><circle cx="65" cy="65" r="58" fill="#fff2c4"/>' +
            '<circle cx="45" cy="48" r="11" fill="#e8d79b" opacity=".7"/><circle cx="82" cy="40" r="6" fill="#e8d79b" opacity=".6"/>' +
            '<circle cx="78" cy="82" r="14" fill="#e8d79b" opacity=".6"/><circle cx="40" cy="88" r="5" fill="#e8d79b" opacity=".6"/></svg>');
        hd('sx-fog', s); hd('sx-fog sx-fog2', s);
        hd('sx-web', back, aWeb());
        // Паук ползёт по нити паутины (луч под углом 54°) вниз, разворачивается и поднимается обратно
        var spAng = 54 * Math.PI / 180, r0 = 20, r1 = 168;
        var sp = hd('sx-spider', back, '<div class="sx-spider-walk">' +
            '<svg viewBox="0 0 28 26" width="30" height="28" fill="#2a1236" stroke="#a87bd6" stroke-width="1" stroke-linecap="round">' +
            '<path class="sx-leg la" fill="none" d="M10 14L2 8M10 17L2 23M18 15L27 15M17 18L23 25"/>' +
            '<path class="sx-leg lb" fill="none" d="M10 15L1 15M11 18L5 25M18 14L26 8M18 17L26 23"/>' +
            '<circle cx="14" cy="17" r="6"/><circle cx="14" cy="9" r="4"/><circle cx="12.5" cy="8" r="1" fill="#ff4a4a" stroke="none"/><circle cx="15.5" cy="8" r="1" fill="#ff4a4a" stroke="none"/></svg></div>');
        sp.style.setProperty('--x0', (r0 * Math.cos(spAng)).toFixed(1) + 'px');
        sp.style.setProperty('--y0', (r0 * Math.sin(spAng)).toFixed(1) + 'px');
        sp.style.setProperty('--x1', (r1 * Math.cos(spAng)).toFixed(1) + 'px');
        sp.style.setProperty('--y1', (r1 * Math.sin(spAng)).toFixed(1) + 'px');
        sp.style.setProperty('--rd', (54 + 90) + 'deg');    // головой вниз по лучу
        sp.style.setProperty('--ru', (54 - 90) + 'deg');    // головой вверх
        sp.style.setProperty('--d', rand(16, 20).toFixed(1) + 's');
        for (i = 0; i < (isSmall() ? 7 : 14); i++) {
            var em = hd('sx-ember', s), es = rand(2, 4.5);
            em.style.setProperty('--x', rand(2, 98).toFixed(1) + '%');
            em.style.setProperty('--s', es.toFixed(1) + 'px');
            em.style.setProperty('--dur', rand(7, 13).toFixed(1) + 's');
            em.style.setProperty('--delay', (-rand(0, 13)).toFixed(1) + 's');
            em.style.setProperty('--sway', rand(12, 35).toFixed(0) + 'px');
            em.style.setProperty('--sway-dur', rand(2.5, 5).toFixed(1) + 's');
        }
        if (isSmall()) return;   // на телефоне без тыкв: луна, паутина с пауком, туман и искры остаются
        hd('sx-pk-glow', s);
        hd('sx-pumpkin', s, aPumpkin(124));
        hd('sx-pumpkin sx-pumpkin2', s, aPumpkin(70));
    }

    /* ---------- 1 МАЯ ---------- */
    function drawBunting(svg) { return withSeed(202, function () { return drawBuntingRaw(svg); }); }
    function drawBuntingRaw(svg) {
        clearNode(svg);
        var W = window.innerWidth, seg = isSmall() ? 130 : 210;
        var r = ropePoints(W, seg, 14, 4, isSmall() ? 4 : 6);
        sv('path', { d: r.d, fill: 'none', stroke: '#7a5230', 'stroke-width': 1.6, 'stroke-linecap': 'round' }, svg);
        var cols = ['#d6403a', '#e8574f', '#b9302b', '#f4efe4', '#3fa66a', '#f2b84b'];
        r.pts.forEach(function (p, i) {
            var g = sv('g', { transform: 'translate(' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ') rotate(' + (p.a * 0.9).toFixed(1) + ')' }, svg);
            var fl = sv('g', { 'class': 'sx-flag' }, g);
            fl.style.setProperty('--w', (1.1 + (i % 5) * 0.23).toFixed(2) + 's');
            fl.style.animationDelay = (-(i % 7) * 0.3).toFixed(1) + 's';
            sv('polygon', { points: '-10,0 10,0 0,30', fill: cols[(i * 5 + (i >> 2)) % cols.length], stroke: 'rgba(0,0,0,.18)', 'stroke-width': 0.8 }, fl);
        });
    }
    var BALLOON_COLORS = ['#e0423b', '#f4efe4', '#3fa66a', '#f2b84b', '#d6403a', '#4aa3e8'];
    function aBalloon(c, w) {
        return '<svg viewBox="0 0 40 82" width="' + w + '" height="' + (w * 82 / 40).toFixed(0) + '">' +
            '<path d="M20 78C14 66 26 62 20 51" fill="none" stroke="rgba(255,255,255,.7)" stroke-width="1"/>' +
            '<path d="M20 2C8 2 2 12 4 24 6 36 15 44 20 47 25 44 34 36 36 24 38 12 32 2 20 2z" fill="' + c + '"/>' +
            '<path d="M20 47C25 44 34 36 36 24 37 34 30 42 20 47z" fill="rgba(0,0,0,.18)"/>' +
            '<path d="M17 47H23L20 52z" fill="' + c + '"/><ellipse cx="12" cy="14" rx="3.2" ry="6" transform="rotate(25 12 14)" fill="rgba(255,255,255,.45)"/></svg>';
    }
    function sceneMayDay() {
        var s = scene('mayday'), i;
        fallingLeaves(s, ['#4faa55', '#7cc35a', '#2f8a46', '#a6d25f', '#3f9a4d'], isSmall() ? 8 : 15, 28, 46);
        for (i = 0; i < (isSmall() ? 5 : 9); i++) {
            var w = rand(34, 56), bl = hd('sx-balloon', s, aBalloon(BALLOON_COLORS[i % BALLOON_COLORS.length], w.toFixed(0)));
            bl.style.setProperty('--x', rand(3, 94).toFixed(1) + '%');
            bl.style.setProperty('--dur', rand(15, 26).toFixed(1) + 's');
            bl.style.setProperty('--delay', (-rand(0, 26)).toFixed(1) + 's');
            bl.style.setProperty('--sway', rand(14, 38).toFixed(0) + 'px');
            bl.style.setProperty('--sway-dur', rand(3, 5.5).toFixed(1) + 's');
        }
        hd('sx-banner', s, '<span>МИР! ТРУД! МАЙ!</span>');
        var g = topLayer('sx-bunting', 52);
        drawBunting(g);
        onResize(function () { drawBunting(g); });
    }

    /* ---------- 1 СЕНТЯБРЯ ---------- */
    function aAster(cx, cy, r, c) {
        var out = '<g transform="translate(' + cx + ' ' + cy + ')">', n = 14, i;
        for (i = 0; i < n; i++) {
            out += '<ellipse cx="0" cy="' + (-r * 0.6).toFixed(1) + '" rx="' + (r * 0.13).toFixed(1) + '" ry="' + (r * 0.46).toFixed(1) +
                '" fill="' + c + '" transform="rotate(' + (i * 360 / n).toFixed(0) + ')"/>';
        }
        return out + '<circle r="' + (r * 0.2).toFixed(1) + '" fill="#f6c74a"/></g>';
    }
    function aBouquet() {
        var fl = [[58, 62, 22, '#ff7ab8'], [100, 44, 23, '#ffffff'], [132, 76, 21, '#b48cff'], [80, 96, 22, '#ff5c8a'], [114, 108, 20, '#ffd1e8']];
        var out = '<svg viewBox="0 0 180 200" width="170" height="189"><g class="sx-bq">', i;
        for (i = 0; i < fl.length; i++) {
            out += '<path d="M88 135Q' + ((88 + fl[i][0]) / 2) + ' ' + ((135 + fl[i][1]) / 2 + 8) + ' ' + fl[i][0] + ' ' + fl[i][1] + '" stroke="#3a8a4a" stroke-width="3" fill="none"/>';
        }
        out += '<path d="M88 135l-22-28 34 6zM86 140l-34-26 32-1z" fill="#3f9a4d"/>';
        for (i = 0; i < fl.length; i++) out += aAster(fl[i][0], fl[i][1], fl[i][2], fl[i][3]);
        out += '<path d="M88 198L38 124Q88 108 138 124z" fill="rgba(255,255,255,.92)"/>' +
            '<path d="M38 124Q88 108 138 124L128 134Q88 120 48 134z" fill="#e8e1d2"/>' +
            '<path d="M88 128l-10 12 10-3 10 3z" fill="#e0423b"/></g></svg>';
        return out;
    }
    /* ---------- Бумажные самолётики: настоящие складки, мёртвые петли и пунктирный след ---------- */
    var PLANE_PAL = [['#ffffff', '#cfd9ea', '#9fb3d1'], ['#fff7cf', '#e8dca6', '#c9b878'], ['#eaf4ff', '#b9d3f0', '#86a9d4']];
    function aPlane(p, w) {
        return '<svg viewBox="0 0 100 50" width="' + w + '" height="' + (w / 2).toFixed(0) + '">' +
            '<path d="M96 20L8 6 34 27z" fill="' + p[0] + '"/>' +
            '<path d="M96 20L34 27 40 44z" fill="' + p[1] + '"/>' +
            '<path d="M34 27L40 44 52 33z" fill="' + p[2] + '"/>' +
            '<path d="M96 20L34 27M8 6L34 27" stroke="rgba(70,90,130,.45)" stroke-width="1" fill="none" stroke-linejoin="round"/></svg>';
    }
    function flyPlanes(s, n) {
        var tr = document.createElementNS(SVGNS, 'svg'), list = [], i;
        tr.setAttribute('class', 'sx-trails');
        s.appendChild(tr);
        function wrap(a) { return Math.atan2(Math.sin(a), Math.cos(a)); }
        for (i = 0; i < n; i++) {
            var w = rand(74, 106);
            list.push({
                el: hd('sx-plane2', s, aPlane(PLANE_PAL[i % 3], w.toFixed(0))),
                path: sv('path', { fill: 'none', stroke: 'rgba(255,255,255,.6)', 'stroke-width': 1.6, 'stroke-dasharray': '4 7', 'stroke-linecap': 'round' }, tr),
                w: w, trail: [], alive: false, wait: i * 1.8
            });
        }
        function spawn(pl) {
            pl.x = -90; pl.y = rand(window.innerHeight * 0.25, window.innerHeight * 0.8);
            pl.base = rand(-22, -6) * Math.PI / 180; pl.th = pl.base;
            pl.spd = rand(150, 230); pl.phase = rand(0, 6);
            pl.loop = 0; pl.dir = 1; pl.next = rand(1.5, 4);
            pl.trail = []; pl.alive = true;
        }
        var last = performance.now(), t = 0;
        function frame(now) {
            var dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
            var W = window.innerWidth, H = window.innerHeight;
            list.forEach(function (pl) {
                if (!pl.alive) {
                    pl.wait -= dt;
                    if (pl.wait > 0) { pl.el.style.opacity = 0; return; }
                    spawn(pl);
                }
                if (pl.loop > 0) {                                   // мёртвая петля
                    var d = pl.dir * 300 * Math.PI / 180 * dt;
                    pl.th += d; pl.loop -= Math.abs(d);
                    if (pl.loop <= 0) { pl.loop = 0; pl.th = pl.base + wrap(pl.th - pl.base); }
                } else {                                              // спокойное покачивание
                    pl.th += (Math.sin(t * 1.3 + pl.phase) * 0.55 - wrap(pl.th - pl.base) * 1.4) * dt;
                    pl.next -= dt;
                    if (pl.next <= 0) { pl.loop = Math.PI * 2; pl.dir = Math.random() < 0.5 ? -1 : 1; pl.next = rand(3.5, 7); }
                }
                pl.x += Math.cos(pl.th) * pl.spd * dt;
                pl.y += Math.sin(pl.th) * pl.spd * dt;
                if (pl.y < 80) pl.base = Math.abs(pl.base); else if (pl.y > H - 80) pl.base = -Math.abs(pl.base);
                pl.y = Math.max(20, Math.min(H - 20, pl.y));
                pl.el.style.transform = 'translate(' + (pl.x - pl.w / 2).toFixed(1) + 'px,' + (pl.y - pl.w / 4).toFixed(1) + 'px) rotate(' + (pl.th * 180 / Math.PI).toFixed(1) + 'deg)';
                pl.el.style.opacity = 1;
                pl.trail.push(pl.x.toFixed(0) + ' ' + pl.y.toFixed(0));
                if (pl.trail.length > 90) pl.trail.shift();
                pl.path.setAttribute('d', 'M' + pl.trail.join('L'));
                if (pl.x > W + 120) { pl.alive = false; pl.wait = rand(1, 4); pl.path.setAttribute('d', ''); }
            });
            requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
    }

    function sceneKnowledge() {
        var s = scene('knowledge'), i;
        var glyphs = ['А', 'Б', 'В', 'Г', 'Д', 'Ж', 'З', 'И', 'К', 'М', 'Я', 'a', 'b', 'c', 'Σ', 'π', '√', '=', '+', '2+2', '7×8', '1', '2', '3', '9', 'E=mc²', '✎'];
        var chalk = ['#ffffff', '#fff3b0', '#bfe3ff', '#ffd1e0', '#d4f7c4'];
        for (i = 0; i < (isSmall() ? 10 : 22); i++) {
            var c = hd('sx-chalk', s, ''), g = choice(glyphs);
            c.textContent = g;
            c.style.setProperty('--x', rand(1, 96).toFixed(1) + '%');
            c.style.setProperty('--s', (g.length > 2 ? rand(18, 26) : rand(24, 46)).toFixed(0) + 'px');
            c.style.setProperty('--c', choice(chalk));
            c.style.setProperty('--o', rand(0.45, 0.85).toFixed(2));
            c.style.setProperty('--dur', rand(14, 24).toFixed(1) + 's');
            c.style.setProperty('--delay', (-rand(0, 24)).toFixed(1) + 's');
            c.style.setProperty('--sway', rand(12, 36).toFixed(0) + 'px');
            c.style.setProperty('--sway-dur', rand(3, 6).toFixed(1) + 's');
            c.style.setProperty('--spin', (rand(30, 120) * (Math.random() < 0.5 ? -1 : 1)).toFixed(0) + 'deg');
        }
        fallingLeaves(s, ['#e8a020', '#f0b429', '#9bbf3a', '#c98a2b'], isSmall() ? 4 : 8, 22, 34);
        flyPlanes(s, isSmall() ? 2 : 4);
        hd('sx-bell', s,
            '<svg viewBox="0 0 70 84" width="64" height="77"><defs><linearGradient id="sxg" x1="0" x2="1"><stop offset="0" stop-color="#f6d56a"/><stop offset=".5" stop-color="#e0a52a"/><stop offset="1" stop-color="#b9791a"/></linearGradient></defs>' +
            '<circle cx="35" cy="8" r="5" fill="none" stroke="#c88a22" stroke-width="3"/>' +
            '<g class="sx-bell-in"><path d="M35 13C21 13 17 29 16 43 15 51 10 55 7 62H63C60 55 55 51 54 43 53 29 49 13 35 13z" fill="url(#sxg)"/>' +
            '<rect x="6" y="61" width="58" height="5" rx="2.5" fill="#c88a22"/><circle class="sx-clap" cx="35" cy="71" r="6" fill="#b9791a"/></g></svg>');
        hd('sx-bouquet', s, aBouquet());
    }

    /* ---------- ОСЕНЬ: гирлянда из листьев и ягод под шапкой (ничего не падает) ---------- */
    var AUTUMN_COLORS = ['#d9541e', '#e8a020', '#b5361b', '#c98a2b', '#e0701f', '#f0b429', '#9c4a1a'];

    function hangLeaf(g, len, color) {
        var sc = rand(1.1, 1.9);
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#6b4a2a', 'stroke-width': 1.1 }, g);
        var lg = sv('g', { transform: 'translate(0 ' + len + ') scale(' + sc.toFixed(2) + ') translate(-12 -2)', fill: color }, g);
        lg.innerHTML = choice(LEAF_SHAPES);
        sv('path', { d: 'M12 4V19', stroke: 'rgba(0,0,0,.22)', 'stroke-width': 0.7, fill: 'none' }, lg);
    }
    function hangRowan(g, len) {
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#6b4a2a', 'stroke-width': 1.1 }, g);
        var c = sv('g', { transform: 'translate(0 ' + len + ')' }, g);
        sv('path', { d: 'M0 0C-8-6-15-3-17 3 -9 4-3 3 0 0z', fill: '#5f8f3a' }, c);
        var b = [[-4, 3], [3, 1], [-1, 8], [6, 8], [-6, 11], [2, 14]];
        b.forEach(function (p) {
            sv('circle', { cx: p[0], cy: p[1], r: 3.4, fill: '#d3322b' }, c);
            sv('circle', { cx: p[0] - 1, cy: p[1] - 1, r: 1, fill: 'rgba(255,255,255,.55)' }, c);
        });
    }
    function hangAcorn(g, len) {
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#6b4a2a', 'stroke-width': 1.1 }, g);
        var c = sv('g', { transform: 'translate(0 ' + len + ')' }, g);
        sv('path', { d: 'M-5.5 3C-5.5 11-2 15 0 16 2 15 5.5 11 5.5 3z', fill: '#c98a3b' }, c);
        sv('path', { d: 'M-7 4C-7-3 7-3 7 4z', fill: '#6e4a26' }, c);
        sv('rect', { x: -1, y: -3, width: 2, height: 3, fill: '#6e4a26' }, c);
    }
    function hangPumpkin(g, len) {
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#6b4a2a', 'stroke-width': 1.1 }, g);
        var c = sv('g', { transform: 'translate(0 ' + len + ')' }, g);
        sv('ellipse', { cx: -4, cy: 8, rx: 6, ry: 7, fill: '#d9650f' }, c);
        sv('ellipse', { cx: 4, cy: 8, rx: 6, ry: 7, fill: '#d9650f' }, c);
        sv('ellipse', { cx: 0, cy: 8, rx: 5.5, ry: 8, fill: '#f08a24' }, c);
        sv('path', { d: 'M-1 1C-1-2 1-4 4-4L3 0z', fill: '#4a6b2a' }, c);
    }
    function drawAutumn(svg) { return withSeed(303, function () { return drawAutumnRaw(svg); }); }
    function drawAutumnRaw(svg) {
        clearNode(svg);
        var W = Math.max(window.innerWidth, 320), small = isSmall();
        var seg = small ? 130 : 200;
        svg.setAttribute('width', W);
        svg.setAttribute("height", 110);
        var rope = ropePoints(W, seg, 13, 3, small ? 3 : 4);
        sv('path', { d: rope.d, fill: 'none', stroke: '#6b4a2a', 'stroke-width': 2, 'stroke-linecap': 'round' }, svg);

        // мелкие листочки прямо на верёвке — получается венок
        var fine = ropePoints(W, seg, 13, 3, Math.round(seg / 24));
        fine.pts.forEach(function (p, i) {
            var g = sv('g', { transform: 'translate(' + p.x.toFixed(1) + ' ' + (p.y + 1).toFixed(1) + ') rotate(' + (p.a + rand(-40, 40)).toFixed(0) + ') scale(' + rand(0.5, 0.8).toFixed(2) + ')', fill: choice(AUTUMN_COLORS) }, svg);
            var l = sv('g', { transform: 'translate(-12 -2)' }, g);
            l.innerHTML = LEAF_SHAPES[i % 3];
        });

        // подвески (длинные листья, рябина, жёлуди, тыквы) убраны — остаётся только гирлянда
    }
    function sceneAutumn() {
        var hdr = document.querySelector('.header');
        var layer = hd('sx-autumn-layer', null);
        layer.setAttribute('aria-hidden', 'true');
        var svg = document.createElementNS(SVGNS, 'svg');
        layer.appendChild(svg);
        if (hdr) {
            if (getComputedStyle(hdr).position === 'static') hdr.style.position = 'relative';
            hdr.style.setProperty('overflow', 'visible', 'important');   // чтобы гирлянда свисала за край шапки
            hdr.appendChild(layer);
        } else {
            layer.className += ' is-fixed';
            document.body.appendChild(layer);
        }
        // Один жёлудь живёт отдельно от гирлянды (свой слой) и остаётся, даже если гирлянду отключить.
        var acornSvg = document.createElementNS(SVGNS, 'svg');
        layer.appendChild(acornSvg);
        drawAcorn(acornSvg);
        onResize(function () { drawAcorn(acornSvg); });
        startAcornLoop();

        // Гирлянда в своей «шторке»: по клику на жёлудь плавно уезжает под шапку и возвращается (состояние помним).
        var KEY = 'sx-garland-off';
        var off = false;
        try { off = localStorage.getItem(KEY) === '1'; } catch (e) {}
        var blind = document.createElement('div');
        blind.className = 'sx-garland-clip' + (off ? ' is-off' : '');
        ACORN.down = off;   // жёлудь опускается на длинной верёвке, когда гирлянда убрана
        ACORN.L = off ? ACORN.LDOWN : ACORN.LREST;
        layer.insertBefore(blind, acornSvg);
        blind.appendChild(svg);
        // плавность включаем после первого кадра, чтобы при загрузке гирлянда не «ехала»
        requestAnimationFrame(function () { requestAnimationFrame(function () { blind.className += ' is-ready'; }); });
        drawAutumn(svg);
        onResize(function () { drawAutumn(svg); });
        // Жёлудь оторвался: с шансом 50 на 50 гирлянда тоже убирается и остаётся убранной (вернуть её можно кликом по новому жёлудю)
        ACORN.onSnap = function () {
            if (off || Math.random() >= 0.5) return;
            off = true;
            try { localStorage.setItem(KEY, '1'); } catch (e) {}
            blind.classList.add('is-off');
            ACORN.down = true;
        };
        acornSvg.addEventListener('click', function (ev) {
            if (!ev.target.closest || !ev.target.closest('.sx-acorn')) return;
            if (ACORN.broken) return;
            off = !off;
            try { localStorage.setItem(KEY, off ? '1' : '0'); } catch (e) {}
            if (off) blind.classList.add('is-off'); else blind.classList.remove('is-off');
            ACORN.down = off;
        });
    }
    /* Жёлудь на гибкой верёвке: маятник на пружине, верёвка — кривая, которая изгибается при движении */
    var ACORN = { LREST: 34, LDOWN: 62, L: 34, ang: 0, vel: 0, down: false, hover: false, rope: null, body: null, hit: null, hitG: null,
                  started: false, last: 0, tension: 0, broken: false, fallen: false, regrowAt: 0, alpha: 1,
                  px: 0, py: 34, prot: 0, fx: 0, fy: 0, fvx: 0, fvy: 0, frot: 0, fspin: 0 };
    function drawAcorn(svg) {
        clearNode(svg);
        var W = Math.max(window.innerWidth, 320);
        svg.setAttribute('width', W);
        svg.setAttribute('height', 110);
        var outer = sv('g', { transform: 'translate(' + (W - (isSmall() ? 36 : 60)) + ' 2)' }, svg);
        ACORN.rope = sv('path', { d: 'M0 0L0 34', fill: 'none', stroke: '#6b4a2a', 'stroke-width': 1.5, 'stroke-linecap': 'round' }, outer);
        var body = sv('g', {}, outer);
        hangAcorn(body, 0);
        ACORN.body = body;
        // Неподвижная невидимая область под жёлудем: он качается, а курсор остаётся «на нём» и жёлудь не убегает
        var hit = sv('g', { 'class': 'sx-acorn' }, outer);
        ACORN.hit = sv('rect', { x: -26, y: -6, width: 52, height: ACORN.L + 26, fill: 'transparent' }, hit);
        ACORN.hitG = hit;
        if (ACORN.broken) hit.style.display = 'none';
        hit.addEventListener('mouseenter', function () {
            ACORN.hover = true;
        });
        hit.addEventListener('mouseleave', function () { ACORN.hover = false; });
        acornFrame(0);
    }
    // Верёвка порвалась: жёлудь падает, остаётся обрывок, потом вырастает новый жёлудь
    function acornSnap() {
        var A = ACORN;
        A.broken = true; A.fallen = false; A.hover = false; A.tension = 0;
        A.fx = A.px; A.fy = A.py; A.frot = A.prot;
        A.fvx = -A.L * A.vel * 0.8 + (Math.random() - 0.5) * 30;
        A.fvy = -45;
        A.fspin = (A.fvx >= 0 ? 1 : -1) * rand(160, 320);
        A.vel += (Math.random() < 0.5 ? -1 : 1) * 3.5;       // обрывок верёвки хлёстко дёргается
        if (A.hitG) A.hitG.style.display = 'none';
        if (A.onSnap) A.onSnap();
    }
    function acornFrame(dt) {
        var A = ACORN;
        if (!A.rope || !A.body) return;
        var calm = motionOff();
        var now = performance.now() / 1000;
        if (!calm) {
            A.tension = Math.max(0, A.tension - dt * 0.35);
        }
        var idle = calm ? 0 : Math.sin(now * 2 * Math.PI / 3.6) * 0.1;      // жёлудь сам лёгко покачивается
        var target = idle;                                                  // от курсора жёлудь не двигается
        var Lt = A.broken ? 9 : (A.down ? A.LDOWN : A.LREST);
        if (calm) { A.ang = target; A.vel = 0; A.L = Lt; A.alpha = 1; }
        else {
            var k = 38, c = 5.2;                                            // пружина и затухание — мягкое «живое» движение
            A.vel += ((target - A.ang) * k - A.vel * c) * dt;
            A.ang += A.vel * dt;
            A.L += (Lt - A.L) * Math.min(1, dt * 4.2);                      // плавное опускание / подъём
        }
        var tn = A.broken ? 0 : Math.min(A.tension, 1);
        var L = A.L + tn * 5;                                               // верёвка натягивается перед разрывом
        if (A.hit) A.hit.setAttribute('height', (A.L + 26).toFixed(1));
        var bx = -L * Math.sin(A.ang), by = L * Math.cos(A.ang);
        var off = Math.max(-9, Math.min(9, L * A.vel * 0.045)) * (1 - tn * 0.8);   // верёвка отстаёт от жёлудя и изгибается
        var cx = bx * 0.5 + off, cy = by * 0.5;
        A.rope.setAttribute('d', 'M0 0Q' + cx.toFixed(2) + ' ' + cy.toFixed(2) + ' ' + bx.toFixed(2) + ' ' + by.toFixed(2));
        A.rope.setAttribute('stroke-width', (1.5 - tn * 0.6).toFixed(2));
        var rot = Math.atan2(-(bx - cx), by - cy) * 180 / Math.PI;           // жёлудь повёрнут по направлению верёвки
        A.px = bx; A.py = by; A.prot = rot;
        if (A.broken) {
            if (A.fallen) { A.body.setAttribute('opacity', '0'); }   // жёлудь упал и не возвращается, остаётся обрывок верёвки
            else {
                A.fvy += 950 * dt; A.fy += A.fvy * dt; A.fx += A.fvx * dt; A.frot += A.fspin * dt;
                var op = Math.max(0, Math.min(1, 1 - (A.fy - 40) / 110));
                A.body.setAttribute('transform', 'translate(' + A.fx.toFixed(1) + ' ' + A.fy.toFixed(1) + ') rotate(' + A.frot.toFixed(0) + ')');
                A.body.setAttribute('opacity', op.toFixed(2));
                if (op <= 0) A.fallen = true;
            }
        } else {
            if (A.alpha < 1) A.alpha = Math.min(1, A.alpha + dt * 1.8);
            A.body.setAttribute('transform', 'translate(' + bx.toFixed(2) + ' ' + by.toFixed(2) + ') rotate(' + rot.toFixed(1) + ')');
            A.body.setAttribute('opacity', A.alpha.toFixed(2));
        }
    }
    function startAcornLoop() {
        if (ACORN.started) return;
        ACORN.started = true;
        ACORN.last = performance.now();
        (function loop(ts) {
            var dt = Math.min(0.033, Math.max(0.001, (ts - ACORN.last) / 1000));
            ACORN.last = ts;
            acornFrame(dt);
            requestAnimationFrame(loop);
        })(ACORN.last);
    }

    /* ---------- ЗИМА: морозная гирлянда под шапкой — сосульки, снежинки, шары, еловые веточки ---------- */
    function snowflake(g, len) {
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#9fc2e6', 'stroke-width': 1 }, g);
        var r = rand(9, 13), c = sv('g', { transform: 'translate(0 ' + (len + r) + ') rotate(' + rand(0, 60).toFixed(0) + ')', stroke: '#eaf6ff', 'stroke-width': 1.5, 'stroke-linecap': 'round', fill: 'none' }, g), k;
        for (k = 0; k < 6; k++) {
            var a = k * 60 * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
            var bx = ca * r * 0.6, by = sa * r * 0.6, px = -sa * r * 0.28, py = ca * r * 0.28;
            sv('path', { d: 'M0 0L' + (ca * r).toFixed(1) + ' ' + (sa * r).toFixed(1) +
                'M' + bx.toFixed(1) + ' ' + by.toFixed(1) + 'l' + (px + ca * 3).toFixed(1) + ' ' + (py + sa * 3).toFixed(1) +
                'M' + bx.toFixed(1) + ' ' + by.toFixed(1) + 'l' + (-px + ca * 3).toFixed(1) + ' ' + (-py + sa * 3).toFixed(1) }, c);
        }
        sv('circle', { r: 1.6, fill: '#fff', stroke: 'none' }, c);
    }
    function iceBauble(g, len) {
        var col = choice(['#4a8fd8', '#9cc9ee', '#c9d6ea', '#d9534f', '#6aa7e6']), r = rand(6, 8.5);
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#9fc2e6', 'stroke-width': 1 }, g);
        var c = sv('g', { transform: 'translate(0 ' + len + ')' }, g);
        sv('rect', { x: -2.5, y: 0, width: 5, height: 3.5, rx: 1, fill: '#c9d3df' }, c);
        sv('circle', { cx: 0, cy: 3.5 + r, r: r, fill: col }, c);
        sv('path', { d: 'M' + (-r * 0.9) + ' ' + (3.5 + r) + 'Q0 ' + (3.5 + r * 1.6) + ' ' + (r * 0.9) + ' ' + (3.5 + r), fill: 'none', stroke: 'rgba(255,255,255,.55)', 'stroke-width': 1.2 }, c);
        sv('ellipse', { cx: -r * 0.35, cy: 3.5 + r * 0.6, rx: r * 0.22, ry: r * 0.36, fill: 'rgba(255,255,255,.65)' }, c);
    }
    function pineSprig(g, len) {
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#9fc2e6', 'stroke-width': 1 }, g);
        var c = sv('g', { transform: 'translate(0 ' + len + ')', stroke: '#2f6f4a', 'stroke-width': 2.4, 'stroke-linecap': 'round', fill: 'none' }, g), i;
        sv('line', { x1: 0, y1: 0, x2: 0, y2: 24 }, c);
        for (i = 0; i < 4; i++) {
            var y = 2 + i * 6, w = 11 - i * 2;
            sv('path', { d: 'M0 ' + y + 'L' + (-w) + ' ' + (y + 6) + 'M0 ' + y + 'L' + w + ' ' + (y + 6) }, c);
            sv('circle', { cx: -w, cy: y + 6, r: 1.9, fill: '#fff', stroke: 'none' }, c);
            sv('circle', { cx: w, cy: y + 6, r: 1.9, fill: '#fff', stroke: 'none' }, c);
        }
        sv('circle', { cx: -2, cy: 26, r: 2.4, fill: '#d3322b', stroke: 'none' }, c);
        sv('circle', { cx: 2.4, cy: 27, r: 2.4, fill: '#d3322b', stroke: 'none' }, c);
    }
    // Зима: новогодняя мишура и ёлочные шарики (без электрических огоньков — они только на Новый год)
    var WINTER_BALLS = [['#ff8a8a', '#d6303f', '#7d0f20'], ['#ffe9a0', '#f0b429', '#a8700a'], ['#9fd4ff', '#2f7fe0', '#143c85'],
                        ['#9ff5cb', '#2fb67c', '#0e5f40'], ['#e3c6ff', '#9a5be0', '#4b1f86'], ['#ffffff', '#cfd8e6', '#7b8ba3']];
    function drawWinter(svg) { return withSeed(404, function () { return drawWinterRaw(svg); }); }
    function drawWinterRaw(svg) {
        clearNode(svg);
        var W = Math.max(window.innerWidth, 320), small = isSmall(), seg = small ? 130 : 200;
        svg.setAttribute('width', W);
        svg.setAttribute('height', 96);
        var defs = sv('defs', {}, svg);
        WINTER_BALLS.forEach(function (c, i) {
            var gr = sv('radialGradient', { id: 'sxWb' + i, cx: '35%', cy: '30%', r: '75%' }, defs);
            sv('stop', { offset: 0, 'stop-color': c[0] }, gr);
            sv('stop', { offset: 0.55, 'stop-color': c[1] }, gr);
            sv('stop', { offset: 1, 'stop-color': c[2] }, gr);
        });

        // мишура: тёмная сердцевина и очень густой разноцветный ворс во все стороны
        var rope = ropePoints(W, seg, 11, 3, 1);
        sv('path', { d: rope.d, fill: 'none', stroke: '#5c1022', 'stroke-width': 11, 'stroke-linecap': 'round' }, svg);
        function fluff(count, cols, lmin, lmax, wid, spread) {
            ropePoints(W, seg, 11, 3, Math.round(seg / count)).pts.forEach(function (p, i) {
                var side = i % 2 ? 90 : -90;
                var a = (p.a + side + rand(-spread, spread)) * Math.PI / 180, l = rand(lmin, lmax);
                var x0 = p.x + Math.cos(a) * 1.5, y0 = p.y + Math.sin(a) * 1.5;
                sv('line', { x1: x0.toFixed(1), y1: y0.toFixed(1), x2: (p.x + Math.cos(a) * l).toFixed(1), y2: (p.y + Math.sin(a) * l).toFixed(1),
                    stroke: cols[Math.floor(rand(0, cols.length))], 'stroke-width': wid, 'stroke-linecap': 'round' }, svg);
            });
        }
        fluff(1.3, ['#7a1a2d', '#8f1f33', '#6a1426'], 9, 14, 2.1, 85);                        // густой тёмный подшёрсток
        fluff(1.6, ['#c42f48', '#d23a50', '#b3283f'], 8, 13, 1.9, 85);                        // красный ворс
        fluff(2.0, ['#ff5f6d', '#ff7a88', '#e84b5c'], 7, 12, 1.7, 85);                        // яркий ворс сверху
        fluff(2.4, ['#f4f7ff', '#dfe9f7', '#ffffff'], 6, 11, 1.4, 85);                        // серебристые нити
        fluff(6, ['#ffd36b', '#ffe9a0'], 5, 9, 1.5, 85);                                      // золотые искорки
        // блёстки бегут по мишуре
        var glint = sv('path', { d: rope.d, fill: 'none', stroke: '#fff7c9', 'stroke-width': 1.6, 'stroke-linecap': 'round', 'stroke-dasharray': '1 13', 'class': 'sx-glint' }, svg);
        glint.setAttribute('opacity', 0.95);

        // шарики на ниточках — слегка покачиваются
        var kinds = ['round', 'stripe', 'round', 'drop', 'dots', 'round', 'stripe'];
        ropePoints(W, seg, 11, 3, small ? 2 : 3).pts.forEach(function (p, i) {
            var outer = sv('g', { transform: 'translate(' + p.x.toFixed(1) + ' ' + (p.y + 1).toFixed(1) + ')' }, svg);
            var sw = sv('g', { 'class': 'sx-swing' }, outer);
            sw.style.setProperty('--a', rand(2.5, 6).toFixed(1) + 'deg');
            sw.style.setProperty('--p', rand(3.2, 5).toFixed(1) + 's');
            sw.style.setProperty('--dl', (-(p.x / W) * 3.4 - rand(0, 0.8)).toFixed(2) + 's');
            var len = rand(7, 26), r = small ? rand(6, 8.5) : rand(7.5, 11), ci = (i * 5 + Math.floor(rand(0, 3))) % WINTER_BALLS.length;
            var kind = kinds[(i * 3 + Math.floor(rand(0, 4))) % kinds.length], ry = kind === 'drop' ? r * 1.3 : r;
            sv('line', { x1: 0, y1: 0, x2: 0, y2: len.toFixed(1), stroke: 'rgba(255,255,255,.6)', 'stroke-width': 1 }, sw);
            var b = sv('g', { transform: 'translate(0 ' + len.toFixed(1) + ')' }, sw), cy = 3.6 + ry;
            sv('rect', { x: -2.6, y: -0.5, width: 5.2, height: 4.6, rx: 1.1, fill: '#e9c46a', stroke: 'rgba(0,0,0,.28)', 'stroke-width': 0.5 }, b);
            sv('ellipse', { cx: 0, cy: cy.toFixed(1), rx: r.toFixed(1), ry: ry.toFixed(1), fill: 'url(#sxWb' + ci + ')', stroke: 'rgba(0,0,0,.18)', 'stroke-width': 0.6 }, b);
            if (kind === 'stripe') sv('ellipse', { cx: 0, cy: cy.toFixed(1), rx: (r * 0.97).toFixed(1), ry: (r * 0.34).toFixed(1), fill: 'none', stroke: 'rgba(255,255,255,.55)', 'stroke-width': 1.5 }, b);
            if (kind === 'dots') [[-0.45, 0.1], [0.3, -0.35], [0.4, 0.4], [-0.1, 0.55]].forEach(function (d) {
                sv('circle', { cx: (d[0] * r).toFixed(1), cy: (cy + d[1] * ry).toFixed(1), r: (r * 0.13).toFixed(1), fill: 'rgba(255,255,255,.7)' }, b);
            });
            sv('ellipse', { cx: (-r * 0.36).toFixed(1), cy: (cy - ry * 0.4).toFixed(1), rx: (r * 0.26).toFixed(1), ry: (r * 0.16).toFixed(1), fill: 'rgba(255,255,255,.65)', transform: 'rotate(-35 ' + (-r * 0.36).toFixed(1) + ' ' + (cy - ry * 0.4).toFixed(1) + ')' }, b);
        });
    }
    function sceneWinter() {
        var svg = headerHang();
        drawWinter(svg);
        onResize(function () { drawWinter(svg); });
    }

    /* ---------- ВЕСНА: под шапкой висят веточки с почками — при наведении курсора распускаются цветы и листья ---------- */
    var SPRING_GREENS = ['#7cc35a', '#4faa55', '#a6d25f', '#5fb85e', '#3f9a4d'];
    var BLOOMS = [['#ffc2d9', '#ff8fb8'], ['#ffffff', '#ffd1e0'], ['#d9c2ff', '#b48cff'], ['#ffe08a', '#ffc13b'], ['#ffb3a7', '#ff8a78']];

    function blossom(g, r, pal) {
        var i;
        for (i = 0; i < 5; i++) {
            sv('ellipse', { cx: 0, cy: -r * 0.62, rx: r * 0.44, ry: r * 0.64, fill: pal[0], stroke: pal[1], 'stroke-width': 0.6, transform: 'rotate(' + (i * 72) + ')' }, g);
        }
        for (i = 0; i < 6; i++) {
            var a = i * 60 * Math.PI / 180;
            sv('circle', { cx: (Math.cos(a) * r * 0.3).toFixed(1), cy: (Math.sin(a) * r * 0.3).toFixed(1), r: 0.9, fill: '#d98a1c' }, g);
        }
        sv('circle', { r: r * 0.2, fill: '#f6c74a' }, g);
    }
    function sprigLeaf(g, size, side, color) {
        sv('path', { d: 'M0 0C-5-6-4-14 0-20 4-14 5-6 0 0z', fill: color, transform: 'rotate(' + (180 + side * 55) + ') scale(' + size.toFixed(2) + ')' }, g);
        sv('path', { d: 'M0 -2V-16', stroke: 'rgba(0,0,0,.2)', 'stroke-width': 0.8, fill: 'none', transform: 'rotate(' + (180 + side * 55) + ') scale(' + size.toFixed(2) + ')' }, g);
    }
    function drawSpring(state) { return withSeed(505, function () { return drawSpringRaw(state); }); }
    function drawSpringRaw(state) {
        var svg = state.svg;
        clearNode(svg);
        state.slots = [];
        var W = Math.max(window.innerWidth, 320), small = isSmall(), seg = small ? 130 : 200;
        svg.setAttribute('width', W);
        svg.setAttribute('height', 100);
        var rope = ropePoints(W, seg, 8, 3, 1);
        sv('path', { d: rope.d, fill: 'none', stroke: '#4d8a3a', 'stroke-width': 2.6, 'stroke-linecap': 'round' }, svg);

        // мелкие листочки на самой лозе — всегда видны
        var fine = ropePoints(W, seg, 8, 3, Math.round(seg / 22));
        fine.pts.forEach(function (p, i) {
            sv('path', { d: 'M0 0C3-3 9-2 11 2 6 5 2 4 0 0z', fill: SPRING_GREENS[i % SPRING_GREENS.length],
                transform: 'translate(' + p.x.toFixed(1) + ' ' + (p.y + 1).toFixed(1) + ') rotate(' + (p.a + (i % 2 ? 160 : 20)).toFixed(0) + ')' }, svg);
        });

        // веточки с почками: цветы и листья раскрываются
        var pts = ropePoints(W, seg, 8, 3, small ? 2 : 3).pts;
        pts.forEach(function (p, i) {
            var len = rand(16, 40), outer = sv('g', { transform: 'translate(' + p.x.toFixed(1) + ' ' + (p.y + 1).toFixed(1) + ')' }, svg);
            sv('path', { d: 'M0 0Q' + rand(-5, 5).toFixed(1) + ' ' + (len / 2).toFixed(0) + ' 0 ' + len.toFixed(0), fill: 'none', stroke: '#5c8a3a', 'stroke-width': 1.5, 'stroke-linecap': 'round' }, outer);
            [0.38, 0.72].forEach(function (t, j) {
                var at = sv('g', { transform: 'translate(0 ' + (len * t).toFixed(0) + ')' }, outer);
                var lf = sv('g', { 'class': 'sx-lf' }, at);
                lf.style.setProperty('--ld', (0.1 + j * 0.15).toFixed(2) + 's');
                sprigLeaf(lf, rand(0.7, 1.0), (i + j) % 2 ? 1 : -1, choice(SPRING_GREENS));
            });
            var end = sv('g', { transform: 'translate(0 ' + len.toFixed(0) + ')' }, outer);
            var bud = sv('g', { 'class': 'sx-bud-c' }, end);
            bud.style.animationDelay = (-rand(0, 2.6)).toFixed(1) + 's';
            var pal = choice(BLOOMS);
            sv('ellipse', { cx: 0, cy: 3, rx: 2.8, ry: 4.2, fill: pal[1] }, bud);
            sv('path', { d: 'M-2.8 1.5C-1 4 1 4 2.8 1.5', stroke: '#4d8a3a', 'stroke-width': 1.2, fill: 'none' }, bud);
            var pos = sv('g', { transform: 'translate(0 ' + (4 + 0).toFixed(0) + ')' }, end);
            var fl = sv('g', { 'class': 'sx-fl' }, pos);
            blossom(fl, rand(7, 11), pal);
            state.slots.push({ el: outer, x: p.x, y: p.y + len * 0.7, t: 0 });
            if (motionOff()) outer.setAttribute('class', 'is-open');
        });
    }
    function sceneSpring() {
        var state = { svg: headerHang(), slots: [] };
        drawSpring(state);
        onResize(function () { drawSpring(state); });
        function hover(x, y) {
            var rc = state.svg.getBoundingClientRect(), mx = x - rc.left, my = y - rc.top, now = Date.now();
            if (my < -24 || my > 130) return;
            state.slots.forEach(function (s) {
                var dx = s.x - mx, dy = s.y - my;
                if (dx * dx + dy * dy < 5200) { s.t = now; s.el.setAttribute('class', 'is-open'); }
            });
        }
        window.addEventListener('mousemove', function (e) { hover(e.clientX, e.clientY); }, { passive: true });
        function touch(e) { var t = e.touches && e.touches[0]; if (t) hover(t.clientX, t.clientY); }
        window.addEventListener('touchstart', touch, { passive: true });
        window.addEventListener('touchmove', touch, { passive: true });
        if (motionOff()) return;
        // цветы закрываются через несколько секунд после ухода курсора
        setInterval(function () {
            var now = Date.now();
            state.slots.forEach(function (s) { if (s.t && now - s.t > 9000) { s.t = 0; s.el.setAttribute('class', ''); } });
        }, 1000);
        // подсказка: изредка одна веточка сама раскрывается на пару секунд
        setInterval(function () {
            if (!state.slots.length) return;
            var s = choice(state.slots);
            if (s.t) return;
            s.t = Date.now() - 6500;
            s.el.setAttribute('class', 'is-open');
        }, 5000);
    }

    /* ---------- 8 МАРТА: цветочная гирлянда под шапкой (тюльпаны, мимоза, розы, банты) ---------- */
    var M8_PINKS = ['#ff6fa5', '#ff8fb8', '#e8416a', '#c95cd6', '#ff9bc2'];

    function m8Tulip(g, len) {
        var c = choice(M8_PINKS);
        sv('path', { d: 'M0 0Q' + rand(-4, 4).toFixed(1) + ' ' + (len / 2).toFixed(0) + ' 0 ' + len.toFixed(0), fill: 'none', stroke: '#4d8a3a', 'stroke-width': 1.6, 'stroke-linecap': 'round' }, g);
        var h = sv('g', { transform: 'translate(0 ' + len.toFixed(0) + ')' }, g);
        sv('path', { d: 'M0 -2C-9 0-10 11-6 16-3 13-1 14 0 17 1 14 3 13 6 16 10 11 9 0 0 -2z', fill: c, stroke: 'rgba(0,0,0,.18)', 'stroke-width': 0.6 }, h);
        sv('path', { d: 'M0 -1V15', stroke: 'rgba(255,255,255,.4)', 'stroke-width': 1, fill: 'none' }, h);
        sv('path', { d: 'M-4 0C-8 6-7 11-5 14', stroke: 'rgba(0,0,0,.14)', 'stroke-width': 1, fill: 'none' }, h);
        sv('path', { d: 'M0 ' + (len * 0.4).toFixed(0) + 'C-6 ' + (len * 0.3).toFixed(0) + ' -10 ' + (len * 0.5).toFixed(0) + ' -11 ' + (len * 0.7).toFixed(0) + ' -5 ' + (len * 0.7).toFixed(0) + ' -1 ' + (len * 0.6).toFixed(0) + ' 0 ' + (len * 0.4).toFixed(0) + 'z', fill: '#5fb85e' }, g);
    }
    function m8Mimosa(g, len) {
        sv('path', { d: 'M0 0Q' + rand(-6, 6).toFixed(1) + ' ' + (len / 2).toFixed(0) + ' ' + rand(-3, 3).toFixed(1) + ' ' + len.toFixed(0), fill: 'none', stroke: '#5c8a3a', 'stroke-width': 1.3, 'stroke-linecap': 'round' }, g);
        var i, n = 8;
        for (i = 0; i < n; i++) {
            var t = i / (n - 1), x = (i % 2 ? 1 : -1) * rand(2, 6) * (0.4 + t), y = 6 + t * (len + 10);
            sv('path', { d: 'M0 ' + (y - 3).toFixed(0) + 'L' + x.toFixed(1) + ' ' + y.toFixed(1), stroke: '#5c8a3a', 'stroke-width': 0.9, fill: 'none' }, g);
            sv('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: rand(2.3, 3.6).toFixed(1), fill: choice(['#ffd23f', '#ffc107', '#ffe066']) }, g);
            sv('circle', { cx: (x - 0.8).toFixed(1), cy: (y - 0.9).toFixed(1), r: 0.9, fill: 'rgba(255,255,255,.7)' }, g);
        }
        sv('path', { d: 'M0 ' + (len * 0.35).toFixed(0) + 'C8 ' + (len * 0.2).toFixed(0) + ' 14 ' + (len * 0.4).toFixed(0) + ' 15 ' + (len * 0.6).toFixed(0) + ' 8 ' + (len * 0.6).toFixed(0) + ' 2 ' + (len * 0.5).toFixed(0) + ' 0 ' + (len * 0.35).toFixed(0) + 'z', fill: '#7cc35a' }, g);
    }
    function m8Rose(g, len) {
        var c = choice(['#e8416a', '#ff6fa5', '#f4a0bf', '#d6336c']);
        sv('line', { x1: 0, y1: 0, x2: 0, y2: len, stroke: '#4d8a3a', 'stroke-width': 1.5 }, g);
        var h = sv('g', { transform: 'translate(0 ' + (len + 6) + ')' }, g);
        sv('circle', { r: 7.5, fill: c, stroke: 'rgba(0,0,0,.2)', 'stroke-width': 0.6 }, h);
        sv('path', { d: 'M-5 1A5 5 0 0 1 5 1M-3.4 -1.6A3.4 3.4 0 0 0 3.4 -1.6M-1.6 0.6A1.8 1.8 0 0 1 1.6 0.6', fill: 'none', stroke: 'rgba(120,0,40,.45)', 'stroke-width': 1, 'stroke-linecap': 'round' }, h);
        sv('ellipse', { cx: -3, cy: -3.5, rx: 2, ry: 1.2, fill: 'rgba(255,255,255,.5)', transform: 'rotate(-30 -3 -3.5)' }, h);
        sv('path', { d: 'M-7 -3C-12 -2-13 3-10 5-8 2-7 0-7 -3zM7 -3C12 -2 13 3 10 5 8 2 7 0 7 -3z', fill: '#4faa55' }, h);
    }
    function m8Bow(g) {
        var c = '#f06a9a', d = '#c9467a';
        sv('path', { d: 'M0 0C-14 -9-20 -2-16 5-12 9-4 5 0 0zM0 0C14 -9 20 -2 16 5 12 9 4 5 0 0z', fill: c, stroke: d, 'stroke-width': 0.8 }, g);
        sv('path', { d: 'M0 1L-7 24 -3 21 0 27 3 21 7 24z', fill: c, stroke: d, 'stroke-width': 0.8, 'stroke-linejoin': 'round' }, g);
        sv('circle', { cx: 0, cy: 0, r: 3.2, fill: d }, g);
    }
    function drawMarch8(svg) { return withSeed(606, function () { return drawMarch8Raw(svg); }); }
    function drawMarch8Raw(svg) {
        clearNode(svg);
        var W = Math.max(window.innerWidth, 320), small = isSmall(), seg = small ? 130 : 200;
        svg.setAttribute('width', W);
        svg.setAttribute('height', 110);
        var rope = ropePoints(W, seg, 10, 3, small ? 3 : 4);
        sv('path', { d: rope.d, fill: 'none', stroke: '#f08ab0', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, svg);
        // листочки вдоль ленты
        var fine = ropePoints(W, seg, 10, 3, Math.round(seg / 24));
        fine.pts.forEach(function (p, i) {
            sv('path', { d: 'M0 0C3-3 9-2 11 2 6 5 2 4 0 0z', fill: SPRING_GREENS[i % SPRING_GREENS.length],
                transform: 'translate(' + p.x.toFixed(1) + ' ' + (p.y + 1).toFixed(1) + ') rotate(' + (p.a + (i % 2 ? 160 : 20)).toFixed(0) + ')' }, svg);
        });
        // банты там, где лента крепится
        var n = Math.ceil((W + 20) / seg), i;
        for (i = 0; i <= n; i++) {
            var bg = sv('g', { transform: 'translate(' + (-10 + i * seg) + ' 3)' }, svg);
            var bs = sv('g', { 'class': 'sx-swing' }, bg);
            bs.style.setProperty('--a', '5deg'); bs.style.setProperty('--p', '3.8s');
            m8Bow(bs);
        }
        // подвески: тюльпаны, мимоза, розы — «распускаются» слева направо при загрузке
        var kinds = ['tulip', 'mimosa', 'rose', 'tulip', 'mimosa', 'rose', 'tulip', 'rose', 'mimosa'];
        rope.pts.forEach(function (p, j) {
            var outer = sv('g', { transform: 'translate(' + p.x.toFixed(1) + ' ' + (p.y + 1).toFixed(1) + ')' }, svg);
            var gr = sv('g', { 'class': 'sx-grow' }, outer);
            gr.style.animationDelay = (0.2 + (p.x / W) * 1.6 + rand(0, 0.3)).toFixed(2) + 's';
            var sw = sv('g', { 'class': 'sx-swing' }, gr);
            sw.style.setProperty('--a', rand(3, 7).toFixed(1) + 'deg');
            sw.style.setProperty('--p', rand(3.2, 5).toFixed(1) + 's');
            sw.style.setProperty('--dl', (-(p.x / W) * 3.4 - rand(0, 0.8)).toFixed(2) + 's');
            var k = kinds[(j * 2 + Math.floor(rand(0, 2))) % kinds.length];
            if (k === 'tulip') m8Tulip(sw, rand(10, 28));
            else if (k === 'mimosa') m8Mimosa(sw, rand(14, 30));
            else m8Rose(sw, rand(8, 24));
        });
    }
    function sceneMarch8() {
        var svg = headerHang();
        drawMarch8(svg);
        onResize(function () { drawMarch8(svg); });
    }

    var RICH = { march8: sceneMarch8, spring: sceneSpring, autumn: sceneAutumn, newyear: sceneNewYear, halloween: sceneHalloween, mayday: sceneMayDay, knowledge: sceneKnowledge };

    function init() {
        var body = document.body;
        if (!body || document.querySelector('.season-fx')) return;

        var theme = body.getAttribute('data-season-theme') || '';

        // Лето: обычный сайт, без эффектов
        if (theme === 'summer') return;

        // Зима: гирлянда под шапкой + обычный снегопад
        if (theme === 'winter') sceneWinter();

        // Праздники с собственной нарисованной сценой
        if (RICH[theme]) {
            if (!motionOff() || theme === 'autumn' || theme === 'spring' || theme === 'march8') RICH[theme]();   // осенняя гирлянда статична и без движения
            if (theme === 'newyear') addTree();
            showBadge(body);
            return;
        }

        var cfg = THEMES[theme];
        if (!cfg) return;

        // На телефонах частиц меньше, чтобы не нагружать устройство
        var count = window.innerWidth < 640 ? Math.ceil(cfg.count / 2) : cfg.count;

        var layer = document.createElement('div');
        layer.className = 'season-fx';
        layer.setAttribute('aria-hidden', 'true');
        if (cfg.mode) layer.setAttribute('data-mode', cfg.mode);

        for (var i = 0; i < count; i++) {
            var p = document.createElement('span');
            p.className = 'season-particle';
            var psize = rand(cfg.size[0], cfg.size[1]);
            if (cfg.kind === 'leaf') makeLeaf(p, psize.toFixed(0));
            else p.textContent = cfg.emoji[Math.floor(Math.random() * cfg.emoji.length)];
            p.style.setProperty('--x', rand(0, 100).toFixed(1) + '%');
            p.style.setProperty('--s', psize.toFixed(0) + 'px');
            p.style.setProperty('--o', rand(0.45, 0.9).toFixed(2));
            p.style.setProperty('--dur', rand(cfg.dur[0], cfg.dur[1]).toFixed(1) + 's');
            p.style.setProperty('--delay', (-rand(0, cfg.dur[1])).toFixed(1) + 's');
            p.style.setProperty('--sway', rand(15, 50).toFixed(0) + 'px');
            p.style.setProperty('--sway-dur', rand(3, 6).toFixed(1) + 's');
            p.style.setProperty('--spin', (rand(cfg.kind === 'leaf' ? 60 : 120, cfg.kind === 'leaf' ? 200 : 540) * (Math.random() < 0.5 ? -1 : 1)).toFixed(0) + 'deg');
            layer.appendChild(p);
        }
        body.appendChild(layer);

        if (cfg.butterflies && !motionOff()) initButterflies();
        if (theme === 'newyear') addTree();

        showBadge(body);
    }

    // Поздравление показывается один раз в день для каждого праздника
    function showBadge(body) {
        return;   // плашка с поздравлением отключена (телефон и ПК)
        var holiday = body.getAttribute('data-holiday');
        var text = body.getAttribute('data-holiday-greeting');
        if (!holiday || !text) return;

        var key = 'season_badge_' + holiday + '_' + new Date().toISOString().slice(0, 10);
        try { if (localStorage.getItem(key)) return; } catch (e) {}

        var badge = document.createElement('div');
        badge.className = 'season-badge';
        badge.setAttribute('role', 'status');

        var span = document.createElement('span');
        span.textContent = text;
        var close = document.createElement('button');
        close.type = 'button';
        close.setAttribute('aria-label', 'Закрыть');
        close.textContent = '✕';

        badge.appendChild(span);
        badge.appendChild(close);
        body.appendChild(badge);

        function hide() {
            try { localStorage.setItem(key, '1'); } catch (e) {}
            badge.classList.add('is-hiding');
            setTimeout(function () { badge.remove(); }, 350);
        }
        close.addEventListener('click', hide);
        setTimeout(hide, 9000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

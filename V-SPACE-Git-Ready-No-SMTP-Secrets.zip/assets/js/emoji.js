/**
 * ============================================================
 * EMOJI PICKER — Скрипт для вставки эмодзи
 * ============================================================
 * Поддерживает:
 * - Открытие/закрытие панели эмодзи
 * - Вставку эмодзи в поле ввода #messageInput (или .message-input)
 * - Показ только собственных эмодзи (window.CustomEmoji, images/icons/custom-emoji);
 *   стандартные Unicode-эмодзи из панели убраны
 * - Автоматическое закрытие при клике вне панели и по Escape
 *
 * ВАЖНО: после отправки сообщения / смены диалога messages.js заменяет
 * весь .chat-area (вместе с #emojiBtn и #emojiPicker). Поэтому обработчики
 * кнопки навешаны на document (делегирование), а панель создаётся заново,
 * если её нет в DOM. Дополнительно доступна window.setupEmojiPicker().
 * ============================================================
 */

document.addEventListener('DOMContentLoaded', function () {

    // =========================================================
    // СОЗДАНИЕ ПАНЕЛИ ЭМОДЗИ
    // =========================================================
    function createEmojiPicker() {
        // Уже есть в DOM — ничего не делаем.
        if (document.getElementById('emojiPicker')) return;

        const picker = document.createElement('div');
        picker.id = 'emojiPicker';
        picker.className = 'emoji-picker';

        // Контейнер эмодзи
        const emojisContainer = document.createElement('div');
        emojisContainer.className = 'emoji-container';

        picker.appendChild(emojisContainer);
        emojisContainer.setAttribute('aria-label', 'Список эмодзи');
        emojisContainer.setAttribute('tabindex', '0');
        const inputWrap = document.querySelector('.message-input-wrap');
        const form = document.getElementById('chatForm');
        (inputWrap || form || document.body).appendChild(picker);

        renderAllEmojis(emojisContainer);

        // Прокручиваем только содержимое picker, не страницу под ним.
        emojisContainer.addEventListener('wheel', function (event) {
            if (this.scrollHeight > this.clientHeight) {
                event.stopPropagation();
            }
        }, { passive: true });
    }

    function renderAllEmojis(container) {
        container = container || document.querySelector('#emojiPicker .emoji-container');
        if (!container) return;

        container.innerHTML = '';

        // Показываем только собственные эмодзи (images/icons/custom-emoji).
        // Обычные Unicode-эмодзи убраны.
        if (window.CustomEmoji && typeof window.CustomEmoji.renderSection === 'function') {
            window.CustomEmoji.renderSection(container, insertEmoji);
        }

        if (!container.children.length) {
            const empty = document.createElement('div');
            empty.className = 'emoji-empty';
            empty.style.cssText = 'padding:16px;text-align:center;opacity:.6;font-size:13px;';
            empty.textContent = 'Нет доступных эмодзи';
            container.appendChild(empty);
        }
    }

    // =========================================================
    // ВСТАВКА ЭМОДЗИ
    // =========================================================
    function insertEmoji(emoji) {
        const activeInput = document.activeElement;
        let targetInput = null;

        // 1) Если фокус уже в поле сообщения — используем его
        if (
            activeInput &&
            activeInput.tagName === 'INPUT' &&
            (activeInput.id === 'messageInput' ||
             activeInput.classList.contains('message-input'))
        ) {
            targetInput = activeInput;
        }

        // 2) Иначе ищем #messageInput, потом .message-input
        if (!targetInput) {
            targetInput =
                document.getElementById('messageInput') ||
                document.querySelector('.message-input');
        }

        if (targetInput) {
            const start = targetInput.selectionStart ?? targetInput.value.length;
            const end   = targetInput.selectionEnd   ?? targetInput.value.length;
            const text  = targetInput.value;

            targetInput.value = text.substring(0, start) + emoji + text.substring(end);
            targetInput.focus();
            targetInput.selectionStart = targetInput.selectionEnd = start + emoji.length;

            // Триггерим input — чтобы кнопка отправки/микрофона переключилась
            targetInput.dispatchEvent(new Event('input', { bubbles: true }));
        }

        closeEmojiPicker();
    }

    function closeEmojiPicker() {
        openedByHover = false;
        const picker = document.getElementById('emojiPicker');
        const btn    = document.getElementById('emojiBtn');
        if (picker) picker.classList.remove('active');
        if (btn)    btn.classList.remove('active');
    }

    function openEmojiPicker() {
        createEmojiPicker();   // панель могла исчезнуть вместе со старым .chat-area
        const picker = document.getElementById('emojiPicker');
        const btn    = document.getElementById('emojiBtn');
        if (!picker) return;

        picker.classList.add('active');
        if (btn) btn.classList.add('active');

        const container = picker.querySelector('.emoji-container');
        if (container) container.scrollTop = 0;
    }

    function toggleEmojiPicker() {
        const picker = document.getElementById('emojiPicker');
        if (picker && picker.classList.contains('active')) {
            closeEmojiPicker();
        } else {
            openEmojiPicker();
        }
    }

    // =========================================================
    // ИНИЦИАЛИЗАЦИЯ
    // =========================================================
    let globalHandlersBound = false;
    let hoverCloseTimer = null;
    let openedByHover = false;   // панель открыта наведением, а не кликом

    function isEmojiTarget(target) {
        return !!(target && target.closest && target.closest('#emojiBtn, #emojiPicker'));
    }

    function bindGlobalHandlers() {
        if (globalHandlersBound) return;
        globalHandlersBound = true;

        // Клик: по кнопке — переключить, вне панели и кнопки — закрыть.
        // Делегирование на document, потому что #emojiBtn пересоздаётся
        // каждый раз, когда messages.js подменяет .chat-area.
        document.addEventListener('click', function (e) {
            const target = e.target;
            const onBtn = target && target.closest && target.closest('#emojiBtn');
            if (onBtn) {
                e.preventDefault();
                clearTimeout(hoverCloseTimer);
                const current = document.getElementById('emojiPicker');
                if (openedByHover && current && current.classList.contains('active')) {
                    // Панель только что открылась по наведению (или по эмулированному
                    // mouseover на тач-экране) — клик не должен её сразу закрывать.
                    openedByHover = false;
                    return;
                }
                toggleEmojiPicker();
                return;
            }

            const picker = document.getElementById('emojiPicker');
            if (!picker) return;
            if (!picker.contains(target)) closeEmojiPicker();
        });

        // Наведение: открываем при наведении на кнопку, закрываем с задержкой,
        // когда курсор ушёл и с кнопки, и с панели.
        document.addEventListener('mouseover', function (e) {
            if (!isEmojiTarget(e.target)) return;
            clearTimeout(hoverCloseTimer);

            const onBtn = e.target.closest('#emojiBtn');
            if (onBtn) {
                const picker = document.getElementById('emojiPicker');
                if (!picker || !picker.classList.contains('active')) {
                    openEmojiPicker();
                    openedByHover = true;
                }
            }
        });

        document.addEventListener('mouseout', function (e) {
            if (!isEmojiTarget(e.target)) return;
            clearTimeout(hoverCloseTimer);
            hoverCloseTimer = setTimeout(function () {
                const picker = document.getElementById('emojiPicker');
                const btn    = document.getElementById('emojiBtn');
                const hovered = (picker && picker.matches(':hover')) || (btn && btn.matches(':hover'));
                if (!hovered) closeEmojiPicker();
            }, 180);
        });

        // Escape — закрываем
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeEmojiPicker();
        });
    }

    function initEmojiPicker() {
        bindGlobalHandlers();
        createEmojiPicker();   // безопасно вызывать повторно
    }

    // messages.js вызывает это после замены .chat-area
    window.setupEmojiPicker = initEmojiPicker;

    initEmojiPicker();

    // Если скрипт custom-emoji подгрузился позже этого — перерисуем панель
    window.addEventListener('load', function () {
        const c = document.querySelector('#emojiPicker .emoji-container');
        if (c && (c.querySelector('.emoji-empty') || !c.children.length)) renderAllEmojis(c);
    });
});

(function () {
    'use strict';

    const ship = document.querySelector('.header-space .hs-ship');
    if (!ship) return;

    const storageKey = 'playerchat-header-ship-next-launch';
    const launchInterval = 50 * 60 * 1000;
    let nextLaunchAt;

    try {
        nextLaunchAt = Number(window.localStorage.getItem(storageKey));
        if (!Number.isFinite(nextLaunchAt) || nextLaunchAt <= 0) {
            nextLaunchAt = Date.now() + launchInterval;
            window.localStorage.setItem(storageKey, String(nextLaunchAt));
        }
    } catch (error) {
        console.error('Could not persist the header ship schedule:', error);
        return;
    }

    function launchShip() {
        try {
            nextLaunchAt = Date.now() + launchInterval;
            window.localStorage.setItem(storageKey, String(nextLaunchAt));
        } catch (error) {
            console.error('Could not update the header ship schedule:', error);
            return;
        }

        ship.classList.remove('is-flying');
        void ship.offsetWidth;
        ship.classList.add('is-flying');
    }

    const delay = Math.max(0, nextLaunchAt - Date.now());
    window.setTimeout(launchShip, delay);
})();

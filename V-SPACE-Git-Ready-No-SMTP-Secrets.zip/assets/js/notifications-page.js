document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    // ===== Автоскрытие всплывающих сообщений =====
    document.querySelectorAll('.notification').forEach(function (n) {
        setTimeout(function () {
            n.style.transition = 'all 0.3s ease';
            n.style.opacity = '0';
            n.style.transform = 'translateX(-50%) translateY(-20px)';
            setTimeout(function () { n.remove(); }, 300);
        }, 3000);
    });

    // ===== Подтверждение для форм с data-confirm (например, «Очистить все») =====
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            if (!confirm(form.getAttribute('data-confirm'))) e.preventDefault();
        });
    });

    // ===== Подтверждение выхода =====
    document.querySelectorAll('.logout-item').forEach(function (item) {
        item.addEventListener('click', function (e) {
            if (!confirm('Вы уверены, что хотите выйти?')) e.preventDefault();
        });
    });
});

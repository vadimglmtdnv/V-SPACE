(function () {
    'use strict';

    const endpoint = 'api/user_presence.php';
    const csrfTokenElement = document.querySelector('[data-presence-csrf]');
    const csrfToken = csrfTokenElement ? csrfTokenElement.dataset.presenceCsrf : '';
    if (!csrfToken) return;
    const activeWindowMs = 2 * 60 * 1000;
    let lastActivityAt = 0;
    let lastHeartbeatAt = 0;

    document.querySelectorAll('[data-user-presence], [data-presence-dot], [data-presence-avatar], [data-presence-avatar-device]')
        .forEach(function (element) {
            element.setAttribute('data-presence-pending', '');
        });

    function markActive() {
        const now = Date.now();
        lastActivityAt = now;
        if (now - lastHeartbeatAt >= 10000) {
            lastHeartbeatAt = now;
            refreshPresence(true);
        }
    }

    ['pointerdown', 'keydown', 'scroll', 'touchstart', 'mousemove'].forEach(function (eventName) {
        document.addEventListener(eventName, markActive, { passive: true, capture: true });
    });

    function getUserIds() {
        const elements = Array.from(document.querySelectorAll('[data-presence-avatar]'))
            .concat(Array.from(document.querySelectorAll('[data-user-presence], [data-presence-dot]')));
        return Array.from(new Set(
            elements.map(function (element) {
                return Number(element.dataset.presenceAvatar || element.dataset.userPresence || element.dataset.presenceDot);
            }).filter(function (id) { return Number.isInteger(id) && id > 0; })
        )).slice(0, 100);
    }

    function lastSeenLabel(value) {
        if (value === null || value === undefined || value === '') return 'неизвестно';
        const seconds = Number(value);
        if (!Number.isFinite(seconds) || seconds < 0) return 'неизвестно';
        if (seconds < 60) return 'только что';
        if (seconds < 3600) return Math.floor(seconds / 60) + ' мин. назад';
        if (seconds < 86400) return Math.floor(seconds / 3600) + ' ч. назад';
        return Math.floor(seconds / 86400) + ' дн. назад';
    }

    function createPhoneIcon() {
        const namespace = 'http://www.w3.org/2000/svg';
        const icon = document.createElementNS(namespace, 'svg');
        icon.setAttribute('viewBox', '0 0 24 24');
        icon.setAttribute('aria-hidden', 'true');
        icon.classList.add('presence-phone-icon');

        const body = document.createElementNS(namespace, 'rect');
        body.setAttribute('x', '5.5');
        body.setAttribute('y', '1');
        body.setAttribute('width', '13');
        body.setAttribute('height', '22');
        body.setAttribute('rx', '3');
        body.setAttribute('fill', '#39ed88');

        const screen = document.createElementNS(namespace, 'rect');
        screen.setAttribute('x', '7.5');
        screen.setAttribute('y', '4');
        screen.setAttribute('width', '9');
        screen.setAttribute('height', '14');
        screen.setAttribute('rx', '1');
        screen.setAttribute('fill', '#075b36');

        const speaker = document.createElementNS(namespace, 'rect');
        speaker.setAttribute('x', '10');
        speaker.setAttribute('y', '2.5');
        speaker.setAttribute('width', '4');
        speaker.setAttribute('height', '0.8');
        speaker.setAttribute('rx', '0.4');
        speaker.setAttribute('fill', '#075b36');

        const homeButton = document.createElementNS(namespace, 'circle');
        homeButton.setAttribute('cx', '12');
        homeButton.setAttribute('cy', '20.5');
        homeButton.setAttribute('r', '0.8');
        homeButton.setAttribute('fill', '#075b36');

        icon.append(body, screen, speaker, homeButton);
        return icon;
    }

    function setDeviceMarker(element, device, online) {
        const isPhone = device === 'Android' || device === 'iPhone';
        element.replaceChildren();
        element.classList.toggle('is-device', isPhone);
        element.style.backgroundColor = isPhone ? 'transparent' : (online ? '#43b581' : '#80848e');
        element.style.display = online ? 'inline-flex' : 'none';
        element.setAttribute('aria-label', online ? (isPhone ? device + ', в сети' : 'Компьютер, в сети') : 'Не в сети');

        if (!online || !isPhone) return;

        element.appendChild(createPhoneIcon());
        element.setAttribute('aria-label', device + (online ? ', в сети' : ', не в сети'));
    }

    function updatePresence(presence) {
        Object.keys(presence || {}).forEach(function (rawId) {
            const id = Number(rawId);
            const item = presence[rawId];
            const online = Boolean(item.online);

            document.querySelectorAll('[data-user-presence="' + id + '"]').forEach(function (element) {
                element.removeAttribute('data-presence-pending');
                const lastSeenAge = item.last_seen_age_seconds;
                element.textContent = online
                    ? 'В сети'
                    : (lastSeenAge === null || lastSeenAge === undefined || lastSeenAge === ''
                        ? 'Не в сети'
                        : 'Был(а) в сети ' + lastSeenLabel(lastSeenAge));
                element.classList.toggle('online', online);
                element.classList.toggle('offline', !online);
                element.setAttribute('aria-label', element.textContent);
                const profileStatus = element.closest('.profile-status');
                if (profileStatus) {
                    profileStatus.classList.toggle('online', online);
                    profileStatus.classList.toggle('offline', !online);
                }
            });
            const markerDevice = Array.isArray(item.devices)
                ? item.devices.find(function (device) { return device === 'Android' || device === 'iPhone'; })
                : null;
            document.querySelectorAll('[data-presence-dot="' + id + '"]').forEach(function (element) {
                element.removeAttribute('data-presence-pending');
                element.classList.toggle('offline', !online);
                element.classList.toggle('online', online);
                setDeviceMarker(element, markerDevice, online);
            });
            document.querySelectorAll('[data-presence-avatar="' + id + '"]').forEach(function (element) {
                element.removeAttribute('data-presence-pending');
                element.classList.toggle('is-online', online);
                element.classList.toggle('is-offline', !online);
            });
            document.querySelectorAll('[data-presence-avatar-device="' + id + '"]').forEach(function (element) {
                element.removeAttribute('data-presence-pending');
                const device = Array.isArray(item.devices)
                    ? item.devices.find(function (value) { return value === 'Android' || value === 'iPhone'; })
                    : null;
                element.replaceChildren();
                element.hidden = !online || !device;
                if (!online || !device) return;

                element.appendChild(createPhoneIcon());
                element.setAttribute('aria-label', device + (online ? ', в сети' : ', не в сети'));
            });
        });
    }

    async function refreshPresence(recordActivity) {
        if (document.hidden) return;
        const ids = getUserIds();
        try {
            const shouldRecordActivity = recordActivity === true
                && Date.now() - lastActivityAt <= activeWindowMs;
            const options = {
                method: shouldRecordActivity ? 'POST' : 'GET',
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            };
            const url = shouldRecordActivity
                ? endpoint
                : endpoint + '?ids=' + encodeURIComponent(ids.join(','));
            if (shouldRecordActivity) {
                options.headers['Content-Type'] = 'application/json';
                options.headers['X-CSRF-Token'] = csrfToken;
                options.body = JSON.stringify({ ids: ids });
            }
            const response = await fetch(url, options);
            if (!response.ok) throw new Error('Presence request failed with HTTP ' + response.status);
            const data = await response.json();
            if (!data.success) throw new Error(data.error || 'Presence request failed');
            updatePresence(data.presence);
        } catch (error) {
            console.error('Could not refresh user presence:', error);
        }
    }

    refreshPresence(false);
    window.setInterval(function () { refreshPresence(false); }, 30000);
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) {
            refreshPresence(false);
        }
    });
})();

/**
 * ============================================================
 * PLAYERCHAT — Управление темами (JavaScript)
 * ============================================================
 */

(function() {
    'use strict';

    // ============================================================
    // КОНСТАНТЫ
    // ============================================================
    const THEME_COOKIE = 'theme';
    const THEME_DARK = 'dark';
    const THEME_LIGHT = 'light';
    const THEME_SYSTEM = 'system';
    const COOKIE_EXPIRY = 365; // дней

    // ============================================================
    // DOM ЭЛЕМЕНТЫ
    // ============================================================
    let themeToggleBtn = null;
    let themeMenu = null;
    let themeItems = [];
    let body = null;

    // ============================================================
    // ФУНКЦИИ ДЛЯ РАБОТЫ С COOKIE
    // ============================================================
    function setCookie(name, value, days) {
        const expires = new Date();
        expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
        document.cookie = name + '=' + value + ';expires=' + expires.toUTCString() + ';path=/';
    }

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : null;
    }

    // ============================================================
    // ОПРЕДЕЛЕНИЕ СИСТЕМНОЙ ТЕМЫ
    // ============================================================
    function getSystemTheme() {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? THEME_DARK : THEME_LIGHT;
    }

    // ============================================================
    // ПРИМЕНЕНИЕ ТЕМЫ
    // ============================================================
    function applyTheme(theme) {
        if (!body) return;

        let effectiveTheme = theme;

        // Если системная тема — определяем тему системы
        if (theme === THEME_SYSTEM) {
            effectiveTheme = getSystemTheme();
        }

        // Применяем тему к body
        body.setAttribute('data-theme', effectiveTheme);

        // Сохраняем выбранную тему в cookie
        setCookie(THEME_COOKIE, theme, COOKIE_EXPIRY);

        // Обновляем активные пункты в меню
        updateThemeMenu(theme);
    }

    // ============================================================
    // ОБНОВЛЕНИЕ МЕНЮ ТЕМЫ
    // ============================================================
    function updateThemeMenu(activeTheme) {
        if (!themeItems || themeItems.length === 0) return;

        themeItems.forEach(function(item) {
            const theme = item.getAttribute('data-theme');
            const check = item.querySelector('.theme-check');

            if (theme === activeTheme) {
                item.classList.add('active');
                if (check) {
                    check.textContent = '✓';
                }
            } else {
                item.classList.remove('active');
                if (check) {
                    check.textContent = '';
                }
            }
        });
    }

    // ============================================================
    // ОТКРЫТИЕ/ЗАКРЫТИЕ МЕНЮ
    // ============================================================
    function toggleMenu(e) {
        if (e) {
            e.stopPropagation();
        }

        if (themeMenu) {
            themeMenu.classList.toggle('active');
        }
    }

    function closeMenu() {
        if (themeMenu) {
            themeMenu.classList.remove('active');
        }
    }

    // ============================================================
    // СЛУШАТЕЛЬ ИЗМЕНЕНИЙ СИСТЕМНОЙ ТЕМЫ
    // ============================================================
    function setupSystemThemeListener() {
        const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

        darkModeMediaQuery.addEventListener('change', function(e) {
            const currentTheme = getCookie(THEME_COOKIE) || THEME_DARK;

            // Если выбрана системная тема — обновляем
            if (currentTheme === THEME_SYSTEM) {
                applyTheme(THEME_SYSTEM);
            }
        });
    }

    // ============================================================
    // ИНИЦИАЛИЗАЦИЯ
    // ============================================================
    function init() {
        // Получаем DOM элементы
        body = document.body;
        themeToggleBtn = document.getElementById('themeToggleBtn');
        themeMenu = document.getElementById('themeMenu');

        if (themeMenu) {
            themeItems = themeMenu.querySelectorAll('.theme-item');
        }

        // Получаем текущую тему из cookie или используем по умолчанию
        let currentTheme = getCookie(THEME_COOKIE) || THEME_DARK;

        // Применяем тему
        applyTheme(currentTheme);

        // ============================================================
        // НАВЕШИВАЕМ ОБРАБОТЧИКИ
        // ============================================================

        // Клик по кнопке с тремя точками
        if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', toggleMenu);
        }

        // Клик по пунктам меню
        if (themeItems && themeItems.length > 0) {
            themeItems.forEach(function(item) {
                item.addEventListener('click', function(e) {
                    const theme = this.getAttribute('data-theme');
                    if (theme) {
                        applyTheme(theme);
                        closeMenu();

                        // Обновляем URL без перезагрузки (если нужно)
                        // Можно добавить параметр ?theme=... в URL
                        const url = new URL(window.location);
                        url.searchParams.set('theme', theme);
                        window.history.pushState({ theme: theme }, '', url);
                    }
                });
            });
        }

        // Закрытие меню при клике вне
        document.addEventListener('click', function(e) {
            if (themeMenu && themeToggleBtn) {
                if (!themeMenu.contains(e.target) && 
                    e.target !== themeToggleBtn && 
                    !themeToggleBtn.contains(e.target)) {
                    closeMenu();
                }
            }
        });

        // Закрытие по Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeMenu();
            }
        });

        // Закрытие при прокрутке
        window.addEventListener('scroll', function() {
            closeMenu();
        });

        // ============================================================
        // СЛУШАТЕЛЬ ИЗМЕНЕНИЙ СИСТЕМНОЙ ТЕМЫ
        // ============================================================
        setupSystemThemeListener();

        // ============================================================
        // ВОССТАНОВЛЕНИЕ ТЕМЫ ИЗ URL (если есть параметр)
        // ============================================================
        const urlParams = new URLSearchParams(window.location.search);
        const themeFromUrl = urlParams.get('theme');
        if (themeFromUrl && [THEME_DARK, THEME_LIGHT, THEME_SYSTEM].includes(themeFromUrl)) {
            applyTheme(themeFromUrl);
        }

        // ============================================================
        // ЛОГИРОВАНИЕ (для отладки)
        // ============================================================
        console.log('[Themes] Инициализация завершена. Текущая тема:', getCookie(THEME_COOKIE) || THEME_DARK);
    }

    // ============================================================
    // ЗАПУСК ПОСЛЕ ЗАГРУЗКИ DOM
    // ============================================================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
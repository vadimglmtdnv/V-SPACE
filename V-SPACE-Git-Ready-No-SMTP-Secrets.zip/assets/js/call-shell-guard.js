/* call-shell-guard.js — страница открыта поверх идущего звонка (встроенное окно из calls.js).
   Переходы «Профиль … Избранное» остаются внутри окна — звонок продолжается.
   Настройки, поддержка, «О проекте», «Разработчикам», модерация и выход открываются во всём окне браузера,
   страница со звонком закрывается — звонок завершается. Подключается из includes/bottom_nav.php. */
(function () {
    'use strict';
    var topWin = null;
    try { if (window.top !== window.self && window.top.__vsCallShell) topWin = window.top; } catch (e) { return; }
    if (!topWin) return;
    document.documentElement.classList.add('in-call-shell');

    var BLOCK = ['settings.php', 'support.php', 'help.php', 'about.php', 'developers.php', 'reports.php', 'logout.php'];

    document.addEventListener('click', function (e) {
        var a = e.target.closest && e.target.closest('a[href]');
        if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        if (a.hasAttribute('download') || a.target === '_blank') return;
        var u;
        try { u = new URL(a.href, location.href); } catch (err) { return; }
        if (u.origin !== location.origin) return;
        var page = (u.pathname.split('/').pop() || 'index.php').toLowerCase();
        if (BLOCK.indexOf(page) === -1 && a.target !== '_top') return;   // обычный раздел — переход внутри окна
        e.preventDefault();
        e.stopPropagation();
        topWin.__vsCallLeave = true;     // ушли намеренно — к звонку не возвращаемся
        topWin.location.href = u.href;   // страница со звонком уходит — звонок завершается
    }, true);
})();

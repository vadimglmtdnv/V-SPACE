/* ==========================================================
   donate.php — поведение страницы V+ Premium
   ========================================================== */
document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    /* ---------- Тема «Системная» ----------
       Сервер отдаёт data-theme="system", а CSS знает только dark/light —
       определяем реальную тему по настройкам ОС. */
    (function () {
        if (document.body.getAttribute('data-theme') !== 'system') return;
        const mq = window.matchMedia('(prefers-color-scheme: light)');
        function apply() {
            document.body.setAttribute('data-theme-resolved', mq.matches ? 'light' : 'dark');
            document.body.setAttribute('data-theme', mq.matches ? 'light' : 'dark');
        }
        apply();
        if (mq.addEventListener) mq.addEventListener('change', apply);
    })();

    /* ---------- Плавный счётчик баланса и срока ---------- */
    (function () {
        const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const fmt = new Intl.NumberFormat('ru-RU');
        const bal = document.getElementById('vpBalance');
        if (!bal || reduce) return;
        const to = parseInt(bal.dataset.value, 10) || 0;
        if (to === 0) return;
        const start = performance.now(), dur = 700;
        (function tick(now) {
            const t = Math.min(1, (now - start) / dur);
            const e = 1 - Math.pow(1 - t, 3);
            bal.textContent = fmt.format(Math.round(to * e)) + ' VS';
            if (t < 1) requestAnimationFrame(tick);
        })(start);
    })();

    /* ---------- Модальные окна (<dialog>): пополнение и PDF ---------- */
    (function () {
        const dialogs = document.querySelectorAll('dialog.vp-modal');
        if (!dialogs.length) return;

        function syncScrollLock() {
            const anyOpen = Array.prototype.some.call(dialogs, function (d) { return d.open; });
            document.body.classList.toggle('vp-modal-open', anyOpen);
        }

        function openDialog(d) {
            if (typeof d.showModal === 'function') d.showModal();
            else d.setAttribute('open', '');
            syncScrollLock();
        }

        dialogs.forEach(function (d) {
            d.addEventListener('close', syncScrollLock);
            // Клик по затемнённому фону закрывает окно (содержимое занимает весь <dialog>).
            d.addEventListener('click', function (e) {
                if (e.target === d) d.close();
            });
            d.querySelectorAll('[data-modal-close]').forEach(function (b) {
                b.addEventListener('click', function () { d.close(); });
            });
        });

        // --- Пополнение: открытие и сводка выбора ---
        const topup = document.getElementById('topupModal');
        if (topup) {
            const summary = document.getElementById('topupSummary');
            const fmt = new Intl.NumberFormat('ru-RU');

            function updateSummary() {
                if (!summary) return;
                const amt = topup.querySelector('input[name="topup_amount"]:checked');
                const pay = topup.querySelector('input[name="payment_method"]:checked');
                if (!amt || !pay) { summary.textContent = ''; return; }
                summary.innerHTML = '';
                const a = document.createElement('span');
                a.textContent = 'Зачислится: ';
                const av = document.createElement('strong');
                av.textContent = fmt.format(parseInt(amt.value, 10)) + ' VS';
                const b = document.createElement('span');
                b.textContent = ' · Оплата: ';
                const bv = document.createElement('strong');
                bv.textContent = pay.dataset.label || '';
                summary.append(a, av, b, bv);
            }
            topup.addEventListener('change', updateSummary);
            updateSummary();

            document.querySelectorAll('[data-open-topup]').forEach(function (btn) {
                btn.addEventListener('click', function () { openDialog(topup); });
            });
        }

        // --- PDF: показываем в окне, а если браузер не умеет — обычная ссылка ---
        const pdf = document.getElementById('pdfModal');
        const frame = document.getElementById('pdfFrame');
        if (pdf && frame) {
            document.querySelectorAll('[data-pdf-open]').forEach(function (link) {
                link.addEventListener('click', function (e) {
                    // Мобильные браузеры часто не умеют показывать PDF в iframe — пусть откроется в новой вкладке.
                    if (navigator.pdfViewerEnabled === false || typeof pdf.showModal !== 'function') return;
                    e.preventDefault();
                    if (!frame.getAttribute('src')) frame.setAttribute('src', frame.dataset.src);
                    openDialog(pdf);
                });
            });
        }
    })();

    /* ---------- Защита от двойной отправки ----------
       Токен формы одноразовый: второй клик по кнопке дал бы «Недействительный запрос». */
    (function () {
        function submitButtons(form) {
            return form.querySelectorAll('button[type="submit"]');
        }

        document.querySelectorAll('form[data-lock]').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                if (form.dataset.submitting === '1') {
                    e.preventDefault();
                    return;
                }
                form.dataset.submitting = '1';
                const submitter = e.submitter;
                if (submitter) submitter.dataset.label = submitter.textContent;
                // Откладываем disable, чтобы браузер успел собрать данные формы.
                setTimeout(function () {
                    document.querySelectorAll('form[data-lock]').forEach(function (f) {
                        submitButtons(f).forEach(function (b) { b.disabled = true; });
                    });
                    if (submitter && form.contains(submitter) && submitter.classList.contains('vp-btn')) {
                        submitter.textContent = 'Обработка...';
                    }
                }, 0);
            });
        });

        // Возврат кнопкой «Назад» (bfcache) — формы снова должны быть активны.
        window.addEventListener('pageshow', function () {
            document.querySelectorAll('form[data-lock]').forEach(function (form) {
                form.dataset.submitting = '0';
                submitButtons(form).forEach(function (b) {
                    b.disabled = false;
                    if (b.dataset.label) b.textContent = b.dataset.label;
                });
            });
        });
    })();

    /* ---------- Нижняя панель навигации ---------- */
    (function () {
        const nav = document.getElementById('site-navigator');
        const handle = document.getElementById('handleBtn');
        if (!nav || !handle) return;

        let lastScrollY = window.scrollY;
        let isNavHidden = false;
        let hideTimeout;

        function showNav() {
            nav.classList.remove('nav-hidden');
            handle.classList.remove('handle-hidden');
            isNavHidden = false;
        }

        function hideNav() {
            nav.classList.add('nav-hidden');
            handle.classList.remove('handle-hidden');
            isNavHidden = true;
        }

        function updateNavVisibility() {
            const delta = window.scrollY - lastScrollY;
            if (delta > 10 && !isNavHidden) hideNav();
            else if (delta < -10 && isNavHidden) showNav();
            lastScrollY = window.scrollY;
        }

        handle.addEventListener('click', function (e) {
            e.stopPropagation();
            if (isNavHidden) showNav();
        });

        handle.addEventListener('mouseenter', function () {
            clearTimeout(hideTimeout);
            if (isNavHidden) showNav();
        });

        nav.addEventListener('mouseenter', function () {
            clearTimeout(hideTimeout);
        });

        nav.addEventListener('mouseleave', function () {
            clearTimeout(hideTimeout);
            hideTimeout = setTimeout(function () {
                if (!isNavHidden && window.scrollY > 100) hideNav();
            }, 3000);
        });

        let ticking = false;
        window.addEventListener('scroll', function () {
            if (ticking) return;
            ticking = true;
            window.requestAnimationFrame(function () {
                updateNavVisibility();
                ticking = false;
            });
        }, { passive: true });

        if (window.scrollY > 100) hideNav();
    })();
});

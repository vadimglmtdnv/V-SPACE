/**
 * PLAYERCHAT — Регистрация
 * Клиентская валидация формы
 */

document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // ============================================
    // ПОЛУЧЕНИЕ ЭЛЕМЕНТОВ
    // ============================================
    const form = document.getElementById('registerForm');
    const submitBtn = document.getElementById('submitBtn');
    
    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const passwordConfirm = document.getElementById('password_confirm');
    const timezone = document.getElementById('timezone');

    if (timezone && window.Intl && Intl.DateTimeFormat) {
        const detectedTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        if (detectedTimezone) timezone.value = detectedTimezone;
    }
    
    const usernameError = document.getElementById('usernameError');
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const passwordConfirmError = document.getElementById('passwordConfirmError');

    // ============================================
    // НАСТРОЙКИ ВАЛИДАЦИИ
    // ============================================
    const VALIDATION_RULES = {
        username: {
            minLength: 3,
            maxLength: 50,
            pattern: /^[a-zA-Zа-яА-Я0-9_]+$/,
            required: true,
            getError: function(value) {
                if (!value) return 'Имя пользователя обязательно.';
                if (value.length < 3) return 'Имя пользователя должно содержать минимум 3 символа.';
                if (value.length > 50) return 'Имя пользователя не должно превышать 50 символов.';
                if (!/^[a-zA-Zа-яА-Я0-9_]+$/.test(value)) {
                    return 'Имя пользователя может содержать только буквы, цифры и подчеркивание.';
                }
                return null;
            }
        },
        email: {
            pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
            required: true,
            getError: function(value) {
                if (!value) return 'Email обязателен.';
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                    return 'Введите корректный email адрес.';
                }
                return null;
            }
        },
        password: {
            minLength: 6,
            maxLength: 100,
            required: true,
            getError: function(value) {
                if (!value) return 'Пароль обязателен.';
                if (value.length < 6) return 'Пароль должен содержать минимум 6 символов.';
                if (value.length > 100) return 'Пароль не должен превышать 100 символов.';
                return null;
            }
        },
        password_confirm: {
            required: true,
            getError: function(value) {
                if (!value) return 'Подтверждение пароля обязательно.';
                if (value !== password.value) return 'Пароли не совпадают.';
                return null;
            }
        }
    };

    // ============================================
    // ФУНКЦИЯ ВАЛИДАЦИИ ПОЛЯ
    // ============================================
    function validateField(field) {
        const value = field.value.trim();
        const fieldName = field.id;
        const rules = VALIDATION_RULES[fieldName];
        const errorElement = document.getElementById(fieldName + 'Error');
        
        if (!rules || !errorElement) return true;

        const error = rules.getError(value);
        
        if (error) {
            errorElement.textContent = error;
            field.classList.add('error');
            field.classList.remove('success');
            return false;
        } else {
            errorElement.textContent = '';
            field.classList.remove('error');
            field.classList.add('success');
            return true;
        }
    }

    // ============================================
    // ФУНКЦИЯ ВАЛИДАЦИИ ВСЕХ ПОЛЕЙ
    // ============================================
    // silent = true: только пересчитать состояние кнопки, не показывая ошибки под полями
    function validateForm(silent) {
        const fields = [username, email, password, passwordConfirm];
        let allValid = true;
        let allFilled = true;

        fields.forEach(function(field) {
            const isValid = silent
                ? !VALIDATION_RULES[field.id].getError(field.value.trim())
                : validateField(field);
            if (!isValid) allValid = false;
            if (field.value.trim().length === 0) allFilled = false;
        });

        // Дополнительная проверка для подтверждения пароля
        if (passwordConfirm.value.length > 0 && passwordConfirm.value !== password.value) {
            allValid = false;
        }

        const isValid = allValid && allFilled;
        submitBtn.disabled = !isValid;
        return isValid;
    }

    // ============================================
    // ФУНКЦИЯ ДЛЯ ПОКАЗА ВСЕХ ОШИБОК
    // ============================================
    function showAllErrors() {
        const fields = [username, email, password, passwordConfirm];
        let firstError = null;

        fields.forEach(function(field) {
            const isValid = validateField(field);
            if (!isValid && !firstError) {
                firstError = field;
            }
        });

        if (firstError) {
            firstError.focus();
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    // ============================================
    // ФУНКЦИЯ ДЛЯ СКРЫТИЯ ОШИБОК
    // ============================================
    function clearFieldErrors(field) {
        const errorElement = document.getElementById(field.id + 'Error');
        if (errorElement) errorElement.textContent = '';
        field.classList.remove('error');
        field.classList.remove('success');
    }

    // ============================================
    // ОБРАБОТЧИКИ СОБЫТИЙ
    // ============================================
    function setupFieldEvents(field) {
        // При вводе
        field.addEventListener('input', function() {
            if (this.value.trim().length > 0) {
                validateField(this);
                validateForm();
            } else {
                clearFieldErrors(this);
                validateForm();
            }
        });

        // При потере фокуса
        field.addEventListener('blur', function() {
            if (this.value.trim().length > 0) {
                validateField(this);
                validateForm();
            } else {
                clearFieldErrors(this);
                validateForm();
            }
        });
    }

    // Настраиваем события для всех полей
    [username, email, password, passwordConfirm].forEach(setupFieldEvents);

    // Специальная обработка для подтверждения пароля
    password.addEventListener('input', function() {
        if (passwordConfirm.value.length > 0) {
            validateField(passwordConfirm);
            validateForm();
        }
    });

    // ============================================
    // ОТПРАВКА ФОРМЫ
    // ============================================
    form.addEventListener('submit', function(e) {
        if (!validateForm()) {
            e.preventDefault();
            showAllErrors();
            return false;
        }

        // Блокируем кнопку при отправке
        submitBtn.disabled = true;
        submitBtn.textContent = '⏳ Регистрация...';

        // Таймаут для разблокировки (если форма не отправилась)
        setTimeout(function() {
            if (!submitBtn.disabled) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Зарегистрироваться';
            }
        }, 10000);
    });

    // ============================================
    // ОБРАБОТКА СООБЩЕНИЙ ОТ СЕРВЕРА
    // ============================================
    // Если сервер вернул ошибку - разблокируем кнопку
    if (document.querySelector('.login-error')) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Зарегистрироваться';
    }

    // Если регистрация успешна
    if (document.querySelector('.login-success')) {
        submitBtn.disabled = true;
        submitBtn.textContent = '✓ Зарегистрирован';
        submitBtn.style.background = '#4CAF50';
        submitBtn.style.color = 'white';

        // Перенаправление на страницу входа через 5 секунд
        setTimeout(function() {
            window.location.href = 'login.php';
        }, 5000);
    }

    // ============================================
    // НАЧАЛЬНАЯ ВАЛИДАЦИЯ
    // ============================================
    // Тихо: на пустой форме ошибки не показываем, пока пользователь не начал вводить
    validateForm(true);

    console.log('📝 Registration form initialized');
});